package matera.spi.main.domain.service.event;

import com.matera.spi.messaging.api.MessagesApi;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.IpAccountOwnerEntity;
import matera.spi.main.domain.model.event.EventStatus;
import matera.spi.main.domain.model.event.EventType;
import matera.spi.main.domain.model.event.EventTypeEntity;
import matera.spi.main.domain.model.event.IpAccountOwnerStatus;
import matera.spi.main.domain.model.event.IpAccountOwnerUpdateEventEntity;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.domain.service.event.receiver.MessageReceiver;
import matera.spi.main.dto.IpAccountOwnerUpdateEventSpecificationDTO;
import matera.spi.main.dto.MessageReceiverEventDTO;
import matera.spi.main.dto.event.EventSpecificationFromReceivedMessageDTO;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.EventTypeRepository;
import matera.spi.main.persistence.IpAccountOwnerRepository;
import matera.spi.main.utils.EntityCreationUtils;
import matera.spi.main.utils.MockMessagingHelper;
import matera.spi.utils.DocumentUtils;

import org.assertj.core.api.SoftAssertions;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.opentest4j.AssertionFailedError;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Commit;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import java.time.LocalDateTime;

import static matera.spi.main.domain.model.event.EventStatus.SUCCESS;
import static matera.spi.main.domain.model.event.IpAccountOwnerStatus.ACTIVE;
import static matera.spi.main.domain.model.event.IpAccountOwnerStatus.INACTIVE;
import static matera.spi.main.domain.model.event.IpAccountOwnerStatus.REJECTED;
import static matera.spi.main.utils.EntityCreationUtils.buildEventEntity;
import static matera.spi.main.utils.EntityCreationUtils.buildIpAccountOwnerEntityWithRequiredFields;
import static matera.spi.main.utils.FileUtils.getDocumentFromXmlFile;
import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.createMessageSentResponseDTO;
import static matera.spi.main.utils.MessageCreationUtils.buildMessageReceiverJson;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import static java.time.format.DateTimeFormatter.ISO_DATE_TIME;

@IntegrationTest
class IpAccountOwnerUpdateEventIT {

    private static final String FROM_SUCCESS_REDA016 = "reda.016/reda.016_sucesso_msg.xml";
    private static final String FROM_REJECT_REDA016 = "reda.016/reda.016_erro_msg.xml";
    public static final String REDA_016_REJECT_ORIGINAL_MESSAGE_ID = "M9999901012345678901234567890123";

    @Autowired
    private EventFactory eventFactory;
    @Autowired
    private EventRepository eventRepository;
    @Autowired
    private EventTypeRepository eventTypeRepository;
    @Autowired
    private EventStatusService eventStatusService;
    @Autowired
    private IpAccountOwnerRepository ipAccountOwnerRepository;
    @Autowired
    private MockMessagingHelper mockMessagingHelper;
    @Autowired
    private MessageReceiver messageReceiver;
    @Autowired
    private TransactionTemplate transactionTemplate;

    @BeforeEach
    void setUp() {
        MessagesApi messagesApiMock = mockMessagingHelper.mock();
        when(messagesApiMock.sendsMessageV1(any())).thenReturn(createMessageSentResponseDTO());
    }

    @AfterEach
    void tearDown() {
        mockMessagingHelper.restore();
    }

    @Test
    @DisplayName("when eventFactory.createNewEvent is called with IpAccountOwnerEntity should create an IpAccountOwnerUpdateEventEntity")
    void shouldCreateAnIpAccountOwnerUpdateWhenEventFactoryWithReda022WasCalled() {
        //given
        IpAccountOwnerEntity ipAccountOwnerEntity = createIpAccountOwnerEntity();

        //when
        IpAccountOwnerUpdateEventSpecificationDTO eventSpecification = new IpAccountOwnerUpdateEventSpecificationDTO(ipAccountOwnerEntity);
        eventSpecification.setInitiatorIspb(PARTICIPANT_ISPB);
        String responsible = "SOME_RESPONSIBLE";
        eventSpecification.setResponsible(responsible);
        IpAccountOwnerUpdateEvent event = (IpAccountOwnerUpdateEvent) eventFactory.createNewEvent(eventSpecification);

        //then
        IpAccountOwnerUpdateEventEntity eventEntity = event.getEventEntity();
        SoftAssertions softly = new SoftAssertions();
        softly.assertThat(eventEntity.getStatus().getDescription()).isEqualTo("Waiting update sent confirm");
        softly.assertThat(eventEntity.getIpAccountOwnerEntity()).isEqualTo(ipAccountOwnerEntity);
        softly.assertThat(eventEntity.getInitiatorIspb()).isEqualTo(PARTICIPANT_ISPB);
        softly.assertThat(eventEntity.getResponsible()).isEqualTo(responsible);
        softly.assertAll();
    }

    @Transactional
    @Commit
    @ParameterizedTest(name = "{0} should update event to {1} status")
    @DisplayName("when receive reda.016 with MessageStatus should update event status to expected status")
    @CsvSource(value = {FROM_SUCCESS_REDA016 + ",Success", FROM_REJECT_REDA016 + ",Rejected"})
    void shouldUpdateStatusToExpectedStatusWhenReceiveAReda016WithMessageStatus(String message, String expectedStatus) {
        //given
        IpAccountOwnerUpdateEventEntity eventEntity = createEventEntityWithStatusWaitingConfirm();

        //when
        Event event = eventFactory.findByEventEntity(eventEntity);
        event.updateStatusFromReplyMessage(getEventSpecificationFromReceivedMessageDTO(message));

        //then
        assertThat(event.getEventEntity().getStatus().getDescription()).isEqualTo(expectedStatus);
    }

    @Transactional
    @Commit
    @ParameterizedTest(name = "to {0} then current owner status should be {1} and last owner {2}")
    @DisplayName("when updating event status")
    @CsvSource({ "SUCCESS,ACTIVE,INACTIVE", "REJECTED,REJECTED,ACTIVE", "ERROR,ERROR,ACTIVE"})
    void shouldRejectCurrentOwnerWhenUpdatingEventStatusToRejected(EventStatus eventStatus,
                                                                   IpAccountOwnerStatus expectedCurrentOwnerStatus,
                                                                   IpAccountOwnerStatus expectedLastOwnerStatus) {

        //given
        IpAccountOwnerEntity lastIpAccountOwner = buildIpAccountOwnerEntityWithRequiredFields();
        lastIpAccountOwner.setStatus(ACTIVE);
        ipAccountOwnerRepository.saveAndFlush(lastIpAccountOwner);

        IpAccountOwnerUpdateEventEntity eventEntity = createEventEntityWithStatusWaitingConfirm();

        //when
        IpAccountOwnerUpdateEvent event = (IpAccountOwnerUpdateEvent) eventFactory.findByEventEntity(eventEntity);
        event.fireStatusTransition(eventStatus);

        //then
        IpAccountOwnerStatus currentOwnerStatus = event.getEventEntity().getIpAccountOwnerEntity().getStatus();
        assertThat(currentOwnerStatus).isEqualTo(expectedCurrentOwnerStatus);
        assertThat(lastIpAccountOwner.getStatus()).isEqualTo(expectedLastOwnerStatus);
    }

    @Test
    @DisplayName("when received a reda.016 actionsForReplyMessage should update clearingTimestamp of the event and the ipAccountOwner")
    void shouldUpdateEventAndIpAccountOwnerClearingTimestampWhenReceivingAReda016() {
        //given
        LocalDateTime reda016SuccessTimestamp  = LocalDateTime.parse("2020-01-01T08:30:12.000Z", ISO_DATE_TIME);
        IpAccountOwnerUpdateEventEntity eventEntity = createEventEntityWithStatusWaitingConfirm();

        //when
        IpAccountOwnerUpdateEvent event = (IpAccountOwnerUpdateEvent) eventFactory.findByEventEntity(eventEntity);
        EventSpecificationFromReceivedMessageDTO eventSpecificationFromReceivedMessageDTO =
            getEventSpecificationFromReceivedMessageDTO(FROM_SUCCESS_REDA016);
        event.actionsForReplyMessage(eventSpecificationFromReceivedMessageDTO);

        //then
        assertThat(event.getEventEntity().getClearingTimestampUTC()).isEqualTo(reda016SuccessTimestamp);
        LocalDateTime ipAccountOwnerClearingTimestamp = event.getEventEntity().getIpAccountOwnerEntity().getClearingTimestamp();
        assertThat(ipAccountOwnerClearingTimestamp).isEqualTo(reda016SuccessTimestamp);
        MessageEntity messageEntity = eventSpecificationFromReceivedMessageDTO.getMessageEntity();
        assertThat(messageEntity.getClearingTimestampUtc()).isEqualTo(reda016SuccessTimestamp);
    }

    @Test
    @DisplayName("when received a reda.016 with reject reason should insert reject reason at IpAccountOwner")
    void shouldInsertRejectReasonAtIpAccountOwnerWhenReceivingReda016WithRejectReason() {
        //given
        IpAccountOwnerUpdateEventEntity eventEntity =
            createEventEntityWithStatusWaitingConfirm();
        eventEntity.setCorrelationId(REDA_016_REJECT_ORIGINAL_MESSAGE_ID);
        eventRepository.saveAndFlush(eventEntity);

        String expectedRejectReason = "PCH8";
        String reda016WithRejectStatus = getStringFromXmlFile(FROM_REJECT_REDA016)
            .replace("<Id>99999010</Id>", "<Id>" + String.valueOf(PARTICIPANT_ISPB) + "</Id>")
            .replace("IND2", expectedRejectReason);
        //when
        messageReceiver.readIncomingMessage(buildMessageReceiverJson(reda016WithRejectStatus));

        //then
        SoftAssertions softly = new SoftAssertions();
        transactionTemplate.execute((status) -> {
            IpAccountOwnerEntity ipAccountOwnerEntity = ipAccountOwnerRepository.findAll().get(0);
            softly.assertThat(ipAccountOwnerEntity.getStatus()).isEqualTo(REJECTED);
            softly.assertThat(ipAccountOwnerEntity.getRejectReasonCode()).isEqualTo(expectedRejectReason);
            softly.assertThat(ipAccountOwnerEntity.getRejectReason().getCode()).isEqualTo(expectedRejectReason);
            softly.assertThat(ipAccountOwnerEntity.getRejectReason().getName()).isEqualTo("Palavra-chave não informada");
            softly.assertThat(ipAccountOwnerEntity.getRejectReason().getDescription()).isEqualTo("Participante Direto solicita a atualização das informações de contato, porém deixa de informar a palavra-chave.");
            return null;
        });
        softly.assertAll();
    }

    @NotNull
    private IpAccountOwnerUpdateEventEntity createEventEntityWithStatusWaitingConfirm() {
        Integer ipAccountOwnerUpdateCode = EventType.IP_ACCOUNT_OWNER_UPDATE.getCode();
        IpAccountOwnerUpdateEventEntity eventEntity = (IpAccountOwnerUpdateEventEntity)  buildEventEntity(ipAccountOwnerUpdateCode);
        eventEntity.setClearingTimestampUTC(null);
        EventTypeEntity eventTypeEntity = eventTypeRepository.findById(ipAccountOwnerUpdateCode)
            .orElseThrow(() -> new AssertionFailedError("Not found Event Type: " + ipAccountOwnerUpdateCode));
        eventEntity.setEventTypeEntity(eventTypeEntity);

        eventEntity.setStatus(eventStatusService.findById(EventStatus.WAITING_UPDATE_SENT_CONFIRM.getCode()));

        IpAccountOwnerEntity ipAccountOwnerEntity = createIpAccountOwnerEntity();
        eventEntity.setIpAccountOwnerEntity(ipAccountOwnerEntity);

        eventRepository.saveAndFlush(eventEntity);

        return eventEntity;
    }

    private IpAccountOwnerEntity createIpAccountOwnerEntity() {
        IpAccountOwnerEntity ipAccountOwnerEntity = buildIpAccountOwnerEntityWithRequiredFields();
        return ipAccountOwnerRepository.saveAndFlush(ipAccountOwnerEntity);
    }

    @NotNull
    private EventSpecificationFromReceivedMessageDTO getEventSpecificationFromReceivedMessageDTO(String message) {
        MessageReceiverEventDTO messageReceiverEventDTO = getMessageReceiverEventDTOFromReda016(message);
        String replyElementXpath = messageReceiverEventDTO.getMessageTypeEntity().getReplyElement();

        Node expectedReplyElementNode =  DocumentUtils
            .getElementsByExpression(messageReceiverEventDTO.getMessageDocument(), replyElementXpath).item(0);

        return new EventSpecificationFromReceivedMessageDTO(messageReceiverEventDTO, expectedReplyElementNode);
    }

    private MessageReceiverEventDTO getMessageReceiverEventDTOFromReda016(String message) {
        Document reda016 = getDocumentFromXmlFile(message);
        MessageEntity messageEntity = EntityCreationUtils.buildReda016MessageEntity();

        return MessageReceiverEventDTO.builder()
            .messageEntity(messageEntity)
            .messageDocument(reda016)
            .build();
    }

}
