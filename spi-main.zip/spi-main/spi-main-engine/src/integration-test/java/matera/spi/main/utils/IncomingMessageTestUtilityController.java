package matera.spi.main.utils;

import matera.spi.main.domain.service.event.receiver.MessageReceiver;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class IncomingMessageTestUtilityController {

    @Autowired
    private MessageReceiver messageReceiver;

    @RequestMapping(method= RequestMethod.POST, path = "/test/incoming-message", consumes = "text/plain")
    public void incomingMessage(@RequestBody String bodyMessage) {
        messageReceiver.readIncomingMessage(bodyMessage);
    }
}
