package matera.spi.main.utils.verifier;

import com.matera.spi.messaging.api.MessagesApi;
import com.matera.spi.messaging.model.MessageSpecificationDTO;

import matera.spi.utils.IspbUtils;

import org.assertj.core.api.SoftAssertions;
import org.mockito.ArgumentCaptor;

import static matera.spi.main.utils.InstantPaymentCreationUtils.BACEN_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ISPB;

import static org.mockito.Mockito.verify;

public class MessageSenderVerifier {

    private MessageSenderVerifier() {/*Utility classes should not be instantiated*/}

    public static void verifyMessagesApiWasCalledWithExternalOriginAndDestination(MessagesApi mockedMessagesApi) {
        ArgumentCaptor<MessageSpecificationDTO> sendMessageArgCaptor = ArgumentCaptor.forClass(MessageSpecificationDTO.class);

        verify(mockedMessagesApi).sendsMessageV1(sendMessageArgCaptor.capture());

        MessageSpecificationDTO actualMessageSpecificationDTO = sendMessageArgCaptor.getValue();
        SoftAssertions softly = new SoftAssertions();
        softly.assertThat(actualMessageSpecificationDTO.getOrigin())
                .as("external payment should specify origin ispb as the direct psp")
                .isEqualTo(IspbUtils.leftPadIspb(PARTICIPANT_ISPB));
        softly.assertThat(actualMessageSpecificationDTO.getDestination())
                .as("external payment should specify destination ispb as the clearing ispb")
                .isEqualTo(IspbUtils.leftPadIspb(BACEN_ISPB));
        softly.assertAll();
    }

}
