package matera.spi.main.utils;

import com.github.tomakehurst.wiremock.common.FileSource;
import com.github.tomakehurst.wiremock.extension.Parameters;
import com.github.tomakehurst.wiremock.extension.ResponseTransformer;
import com.github.tomakehurst.wiremock.http.Request;
import com.github.tomakehurst.wiremock.http.Response;
import lombok.Getter;
import org.apache.commons.lang3.RandomStringUtils;

public class DynamicPiResourceIdStubResponseTransformer extends ResponseTransformer {

    public static final String DYNAMIC_PI_RESOURCE_ID_RESPONSE_TRANSFORMER =
        "dynamic-piResourceId-response-transformer";

    @Getter
    private String lastPiResourceId;

    @Override
    public Response transform(Request request, Response response, FileSource files, Parameters parameters) {
        String randomChars = RandomStringUtils.randomAlphanumeric(28);

        lastPiResourceId = "INT-" + randomChars;

        return Response.Builder.like(response).but()
            .body("{ \"data\": {\"PI-Resource-ID\":\"" + lastPiResourceId + "\"} }").build();
    }

    public void clearLastPiResourceId(){
        lastPiResourceId = null;
    }

    @Override
    public String getName() {
        return DYNAMIC_PI_RESOURCE_ID_RESPONSE_TRANSFORMER;
    }

    @Override
    public boolean applyGlobally() {
        return false;
    }

}
