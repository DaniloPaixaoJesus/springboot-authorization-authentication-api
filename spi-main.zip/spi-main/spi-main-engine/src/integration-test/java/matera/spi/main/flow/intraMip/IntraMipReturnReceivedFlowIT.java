package matera.spi.main.flow.intraMip;

import com.matera.commons.rest.dto.MateraRestReturnDTO;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.AccountTypeDTO;
import matera.spi.dto.InstantPaymentSettlementRequestDTO;
import matera.spi.dto.ReturnSettlementUIWapperDTO;
import matera.spi.dto.SettlementPayerDTO;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.service.event.receiver.MessageReceiver;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.ParticipantMipRepository;
import matera.spi.main.utils.AccountTransactionMocker;
import matera.spi.main.utils.WireMockUtils;

import com.github.tomakehurst.wiremock.WireMockServer;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import static matera.spi.main.domain.service.CorrelationIdGenerator.generateCorrelactionIdPacs004;
import static matera.spi.main.utils.InstantPaymentCreationUtils.ADDITIONAL_INFORMATION;
import static matera.spi.main.utils.InstantPaymentCreationUtils.CHARGE_BEARER_SLEV;
import static matera.spi.main.utils.InstantPaymentCreationUtils.EXTERNAL_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.INSTRUCTION_PRIORITY_HIGH;
import static matera.spi.main.utils.InstantPaymentCreationUtils.LEFT_PADDED_EXTERNAL_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.LEFT_PADDED_PARTICIPANT_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_TAX_ID;
import static matera.spi.main.utils.InstantPaymentCreationUtils.SETTLEMENT_METHOD_CLRG;
import static matera.spi.main.utils.InstantPaymentCreationUtils.getRandomPiResourceId;
import static matera.spi.main.utils.InstantPaymentSettlementRequestCreationUtils.createSettlementRequestDTO;
import static matera.spi.main.utils.MessageCreationUtils.PAYMENT_SUCCESS_STATUS;
import static matera.spi.main.utils.MessageCreationUtils.buildPacs002Response;
import static matera.spi.main.utils.MessageCreationUtils.buildReceivedPacs004;
import static matera.spi.main.utils.MessageCreationUtils.buildTxInfAndSts;
import static matera.spi.main.utils.WireMockUtils.V_1_MESSAGES;
import static matera.spi.main.utils.WireMockUtils.never;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.exactly;
import static com.github.tomakehurst.wiremock.client.WireMock.matching;
import static com.github.tomakehurst.wiremock.client.WireMock.matchingJsonPath;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.resetAllRequests;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlMatching;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;
import static org.assertj.core.api.Assertions.assertThat;

@IntegrationTest
class IntraMipReturnReceivedFlowIT {

    @LocalServerPort
    private int port;

    @Autowired
    private ParticipantMipRepository participantMipRepository;

    @Autowired
    private MessageReceiver messageReceiver;

    @Autowired
    private EventRepository eventRepository;

    @Autowired
    private AccountTransactionMocker accountTransactionMocker;

    private static WireMockServer wireMockServer;

    @BeforeAll
    static void beforeAll() {
        wireMockServer = WireMockUtils.start();

        WireMockUtils.stubMessaging();

        WireMockUtils.stubStandin();

    }

    @AfterAll
    static void afterAll() {
        wireMockServer.stop();
    }

    @BeforeEach
    void setUp() {
        resetAllRequests();

        WireMockUtils.stubStandinEntryValidation();

        participantMipRepository
            .findByIspb(PARTICIPANT_ISPB)
            .ifPresent(participantMipEntity -> {
                participantMipEntity.setIspb(EXTERNAL_ISPB);
                participantMipEntity.setDirectParticipant(false);
                participantMipRepository.saveAndFlush(participantMipEntity);
            });

        accountTransactionMocker.spyExecutor();
    }

    @AfterEach
    void tearDown() {
        participantMipRepository
            .findByIspb(EXTERNAL_ISPB)
            .ifPresent(participantMipRepository::delete);

        accountTransactionMocker.restoreAll();
    }

    @Test
    @DisplayName("return should call v1/messages passing destination with receiver isbp")
    void returnShouldCallV1MessagesPassingDestinationWithReceiverIsbp() {
        //Given
        makePayment();

        //when
        receivePacs004();

        //then
        verify(exactly(1),
            postRequestedFor(urlMatching(V_1_MESSAGES))
                .withRequestBody(matchingJsonPath("$.origin", equalTo(LEFT_PADDED_PARTICIPANT_ISPB)))
                .withRequestBody(matchingJsonPath("$.destination", equalTo(LEFT_PADDED_EXTERNAL_ISPB)))
                .withRequestBody(matchingJsonPath("$.messageDefinitionIdentifier", matching("pacs.002.spi.*")))
                .withRequestBody(matchingJsonPath("$.messageContent", containing("<TxSts>ACSP</TxSts>")))
        );
    }
    @Test
    @DisplayName("return should generate a pacs.002 with reject status when credit validation fails")
    void returnShouldGeneratePacs002WithStatusRejectWhenCreditValidationFails() {
        //Given
        makePayment();

        stubBadRequestCreditValidation();

        //when
        receivePacs004();

        //then
        verify(exactly(1),
            postRequestedFor(urlMatching(V_1_MESSAGES))
                .withRequestBody(matchingJsonPath("$.origin", equalTo(LEFT_PADDED_PARTICIPANT_ISPB)))
                .withRequestBody(matchingJsonPath("$.destination", equalTo(LEFT_PADDED_EXTERNAL_ISPB)))
                .withRequestBody(matchingJsonPath("$.messageDefinitionIdentifier", matching("pacs.002.spi.*")))
                .withRequestBody(matchingJsonPath("$.messageContent", containing("<TxSts>RJCT</TxSts>")))
        );
    }


    @Test
    void intraMipReceiptFirstLegShouldNotDoAnyTransaction() {
        //Given
        makePayment();

        //when
        receivePacs004();

        verify(never(),
            postRequestedFor(urlMatching("/api/v2/contas/[0-9]+/[0-9]+/lancamentos"))
        );

    }

    private void receivePacs004() {
        String returnEndToEndId = generateCorrelactionIdPacs004(String.valueOf(PARTICIPANT_ISPB));
        ReturnSettlementUIWapperDTO returnDTO = buildReturnSettlementUIWapperDTO(returnEndToEndId, getOriginalEventCorrelationId(), BigDecimal.ONE);
        receiveAMessage(buildReceivedPacs004(List.of(returnDTO),  getRandomPiResourceId(), "1.4"));
    }

    private ReturnSettlementUIWapperDTO buildReturnSettlementUIWapperDTO(String returnEndToEndId,
                                                                         String originalEndToEndId,
                                                                         BigDecimal value) {
        // @formatter:off
        return new ReturnSettlementUIWapperDTO()
            .returnEndToEndIdentification(returnEndToEndId)
            .originalEndToEndIdentification(originalEndToEndId)
            .creationDateTime(LocalDateTime.parse("2020-06-03T21:11:46.120"))
            .settlementMethod(SETTLEMENT_METHOD_CLRG)
            .settlementPriority(INSTRUCTION_PRIORITY_HIGH)
            .chargeBearer(CHARGE_BEARER_SLEV)
            .additionalInformation(ADDITIONAL_INFORMATION)
            .unstructured(" MORE ADDITIONAL INFO ")
            .returnReasonInformation(ReturnSettlementUIWapperDTO.ReturnReasonInformationEnum.AM05)
            .returnedInterbankSettlementAmount(value);
        // @formatter:on
    }

    protected void stubBadRequestCreditValidation() {
        stubCreditValidation(HttpStatus.BAD_REQUEST.value());
    }

    protected void stubInternalServerErrorCreditValidation() {
        stubCreditValidation(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    private void stubCreditValidation(int status) {
        stubFor(post(urlMatching("/api/v1/accounts/[0-9]+/[0-9]+/entry/validation"))
            .willReturn(aResponse()
                .withStatus(status)
            )
        );
    }


    private void receiveAMessage(String message) {
        messageReceiver.readIncomingMessage(message);
    }

    private void makePayment(){
        sendPaymentByAPI(port);
        receivePacs002();
        resetAllRequests();
    }

    private void receivePacs002() {
        String endToEndId = getOriginalEventCorrelationId();
        receiveAMessage(buildPacs002Response(buildTxInfAndSts(endToEndId, PAYMENT_SUCCESS_STATUS)));
    }

    private String getOriginalEventCorrelationId() {
        List<EventEntity> events = eventRepository.findAll(Sort.by(Sort.Direction.ASC, "initiationTimestampUTC"));
        assertThat(events).hasSize(1);

        EventEntity originalEventEntity = events.get(0);

        String endToEndId = originalEventEntity.getCorrelationId();
        return endToEndId;
    }

    private static void sendPaymentByAPI(Integer port) {
        InstantPaymentSettlementRequestDTO instantPaymentSettlementRequestDTO = getInstantPaymentSettlementRequestDTO();

        RestTemplate restTemplate = new RestTemplate();

        HttpHeaders headers = new HttpHeaders();
        headers.add("IdempotencyId", RandomStringUtils.randomAlphanumeric(10));
        headers.add("Authorization", "Bearer " + RandomStringUtils.randomAlphanumeric(10));

        HttpEntity<InstantPaymentSettlementRequestDTO>
            request = new HttpEntity<>(instantPaymentSettlementRequestDTO, headers);

        String url = "http://localhost:" + port + "/api/v1/settlements/instant-payments";

        restTemplate.postForObject(url, request, MateraRestReturnDTO.class);
    }

    private static InstantPaymentSettlementRequestDTO getInstantPaymentSettlementRequestDTO() {
        InstantPaymentSettlementRequestDTO instantPaymentSettlementRequestDTO = createSettlementRequestDTO();
        instantPaymentSettlementRequestDTO.getPayer().setTaxId(PARTICIPANT_TAX_ID);
        instantPaymentSettlementRequestDTO.getPayer().setPersonType(SettlementPayerDTO.PersonTypeEnum.PF);
        instantPaymentSettlementRequestDTO.getPayer().getAccount().setAccountType(AccountTypeDTO.CACC);
        return instantPaymentSettlementRequestDTO;
    }

}
