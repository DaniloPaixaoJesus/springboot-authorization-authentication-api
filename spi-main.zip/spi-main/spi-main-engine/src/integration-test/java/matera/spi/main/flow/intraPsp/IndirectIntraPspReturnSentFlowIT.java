package matera.spi.main.flow.intraPsp;

import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventType;
import matera.spi.main.utils.WireMockUtils;

import com.github.tomakehurst.wiremock.client.CountMatchingStrategy;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;

import java.util.List;

import static matera.spi.main.utils.WireMockUtils.V1_CREDITS;
import static matera.spi.main.utils.WireMockUtils.never;
import static matera.spi.main.utils.verifier.EventVerifier.ERROR;
import static matera.spi.main.utils.verifier.EventVerifier.RETURN_INITIATED;
import static matera.spi.main.utils.verifier.EventVerifier.RETURN_RECEIVED;
import static matera.spi.main.utils.verifier.EventVerifier.RETURN_REJECTED;
import static matera.spi.main.utils.verifier.EventVerifier.WAITING_CREDIT_VALIDATION;
import static matera.spi.main.utils.verifier.EventVerifier.verifyAllStatusTransactions;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.resetAllRequests;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static org.assertj.core.api.Assertions.assertThat;

@ActiveProfiles("indirects")
class IndirectIntraPspReturnSentFlowIT extends IntraPspReturnSentFlowIT {

    @BeforeEach
    void setUpIndirect() {
        WireMockUtils.stubV1CreditsEntryValidation();
        WireMockUtils.stubV1IpAccount();

        WireMockUtils.stubV1IndirectsForIntraMip();
    }

    @Override
    @Test
    @DisplayName("intra psp return should set event status to rejected when credit validation got internal server error")
    void intraPspReturnShouldHandleCreditValidationInternalServerError() {

        //Given
        makeIntraPspPaymentAndReceipt();

        stubInternalServerErrorCreditValidation();

        sendReturnByAPI(getReceiptEvent(), port);

        String pacs004 = getPacs004FromReturnSent();
        resetAllRequests();
        receiveAMessage(pacs004);

        //When
        String pacs002 = getPacs002FromReturnReceived();
        receiveAMessage(pacs002);

        //Then
        transactionTemplate.execute(status -> {
            List<EventEntity> events = eventRepository.findAll(Sort.by(Sort.Direction.ASC, "initiationTimestampUTC"));
            assertThat(events).hasSize(4);

            EventEntity returnSent = events.get(2);
            EventEntity returnReceived = events.get(3);

            assertThat(returnSent.getEventType()).isEqualTo(EventType.RETURN_SENDER);
            assertThat(returnReceived.getEventType()).isEqualTo(EventType.RETURN_RECEIVER);
            assertThat(returnSent.getCorrelationId()).isEqualTo(returnReceived.getCorrelationId());

            verifyAllStatusTransactions(returnSent, List.of(RETURN_INITIATED, WAITING_CREDIT_VALIDATION, RETURN_REJECTED));

            verifyAllStatusTransactions(returnReceived, List.of(RETURN_RECEIVED, ERROR));

            return null;
        });

    }

    @Override
    protected CountMatchingStrategy customerTransactionCalls() {
        return never();
    }

    @Override
    protected void stubBadRequestCreditValidation() {
        stubFor(post(V1_CREDITS)
            .willReturn(aResponse()
                .withStatus(HttpStatus.BAD_REQUEST.value())
                .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .withBody("{\"rejectionReason\": {\"rejectionReasonCode\": \"AC07\" } }")
            )
        );
    }

    @Override
    protected void stubInternalServerErrorCreditValidation() {
        stubFor(post(V1_CREDITS)
            .willReturn(aResponse()
                .withStatus(HttpStatus.INTERNAL_SERVER_ERROR.value())
            )
        );
    }

}
