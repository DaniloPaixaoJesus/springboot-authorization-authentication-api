package matera.spi.main.application.service;

import com.matera.spi.messaging.model.MessageSpecificationDTO;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.AccountTypeDTO;
import matera.spi.dto.InstantPaymentSettlementRequestDTO;
import matera.spi.dto.InstructionPriorityDTO;
import matera.spi.dto.SettlementPayerDTO;
import matera.spi.main.domain.model.transaction.TransactionEntity;
import matera.spi.main.persistence.TransactionRepository;
import matera.spi.main.utils.WireMockUtils;

import com.github.tomakehurst.wiremock.WireMockServer;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Stream;

import static matera.spi.main.utils.InstantPaymentSettlementRequestCreationUtils.createSettlementRequestDTO;
import static matera.spi.main.utils.WireMockUtils.V_1_MESSAGES;

import static com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.resetAllRequests;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static org.assertj.core.api.Assertions.assertThat;

@IntegrationTest
class SettlementsServiceIT {

    private static final String RECEIVER_TAX_ID = "78232003090";
    private static final String URL = "/api/v1/settlements/instant-payments";
    private static final String MESSAGE_ERROR_FROM_BRANCH_ACCOUNT_IS_EQUALS =
        "The account number and branch from payer and receiver cannot be the same on an internal payment";
    private static final String AUTHORIZATION_HEADER = "Authorization";
    private static final String AUTHORIZATION_HEADER_VALUE = "Bearer random";
    private static final String IDEMPOTENCY_ID_HEADER = "IdempotencyId";
    private static final String IDEMPOTENCY_ID_HEADER_VALUE = "RANDOMIDEMPOTENCYID";

    @LocalServerPort
    private int port;

    @Autowired
    private TransactionRepository transactionRepository;

    private static final WireMockServer wireMockServer = WireMockUtils.start();

    @BeforeAll
    static void beforeAll() {
        WireMockUtils.stubMessaging();
    }

    @AfterAll
    static void afterAll() {
        wireMockServer.stop();
    }

    private static Stream<Arguments> instructionPriorityArgSource() {
        return Stream.of(
            Arguments.of(null, "HIGH"),
            Arguments.of(InstructionPriorityDTO.HIGH, "HIGH"),
            Arguments.of(InstructionPriorityDTO.NORM, "NORM")
        );
    }

    @BeforeEach
    void setUp() {
        RestAssured.port = port;
        resetAllRequests();
    }

    @ParameterizedTest
    @MethodSource("instructionPriorityArgSource")
    void InstantPaymentApiShouldSetInstructionPriority(InstructionPriorityDTO endpointInstructionPriority, String expectedInstruction) {
        InstantPaymentSettlementRequestDTO instantPaymentSettlementRequestDTO = createSettlementRequestDTO();
        instantPaymentSettlementRequestDTO.setInstructionPriority(endpointInstructionPriority);

        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(instantPaymentSettlementRequestDTO)
            .header(AUTHORIZATION_HEADER, AUTHORIZATION_HEADER_VALUE)
            .header(IDEMPOTENCY_ID_HEADER, IDEMPOTENCY_ID_HEADER_VALUE + LocalDateTime.now())
            .when()
            .post(URL)
            .then()
            .statusCode(202);

        List<TransactionEntity> transactions = transactionRepository.findAll();
        TransactionEntity transactionEntity = transactions.get(0);

        assertThat(transactionEntity.getPriority().getCode()).isEqualTo(expectedInstruction);

        MessageSpecificationDTO messagingBody =
            WireMockUtils.getFirstBodyFrom(postRequestedFor(urlEqualTo(V_1_MESSAGES)), MessageSpecificationDTO.class);

        assertThat(messagingBody.getMessageContent()).contains("<InstrPrty>" + expectedInstruction + "</InstrPrty>");
    }

    @Test
    void InstantPaymentApiShouldReturnBadRequestWithoutPayerType() {
        InstantPaymentSettlementRequestDTO instantPaymentSettlementRequestDTO = createSettlementRequestDTO();
        instantPaymentSettlementRequestDTO.getPayer().setTaxId("22222222222");

        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(instantPaymentSettlementRequestDTO)
            .header(AUTHORIZATION_HEADER, AUTHORIZATION_HEADER_VALUE)
            .header(IDEMPOTENCY_ID_HEADER, IDEMPOTENCY_ID_HEADER_VALUE)
            .when()
            .post(URL)
            .then()
            .log().all().and()
            .statusCode(400)
            .assertThat().body("error[0].message", Matchers.containsString("Validation failed: PersonType is required when taxId is informed"));
    }

    @Test
    void InstantPaymentApiShouldReturnBadRequestWithInvalidTaxId() {
        InstantPaymentSettlementRequestDTO instantPaymentSettlementRequestDTO = createSettlementRequestDTO();
        instantPaymentSettlementRequestDTO.getPayer().setTaxId("22222222222");
        instantPaymentSettlementRequestDTO.getPayer().setPersonType(SettlementPayerDTO.PersonTypeEnum.PF);

        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(instantPaymentSettlementRequestDTO)
            .header(AUTHORIZATION_HEADER, AUTHORIZATION_HEADER_VALUE)
            .header(IDEMPOTENCY_ID_HEADER, IDEMPOTENCY_ID_HEADER_VALUE)
            .when()
            .post(URL)
            .then()
            .log().all().and()
            .statusCode(400)
            .assertThat().body("error[0].message", Matchers.containsString("22222222222 taxId invalid"));
    }

    @Test
    void InstantPaymentApiShouldReturnBadRequestWithInvalidTaxIdForPersonType() {
        InstantPaymentSettlementRequestDTO instantPaymentSettlementRequestDTO = createSettlementRequestDTO();
        instantPaymentSettlementRequestDTO.getPayer().setTaxId("78232003090");
        instantPaymentSettlementRequestDTO.getPayer().setPersonType(SettlementPayerDTO.PersonTypeEnum.PJ);

        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(instantPaymentSettlementRequestDTO)
            .header(AUTHORIZATION_HEADER, AUTHORIZATION_HEADER_VALUE)
            .header(IDEMPOTENCY_ID_HEADER, IDEMPOTENCY_ID_HEADER_VALUE)
            .when()
            .post(URL)
            .then()
            .log().all().and()
            .statusCode(400)
            .assertThat().body("error[0].message", Matchers.containsString("78232003090 taxId invalid"));
    }

    @Test
    void InstantPaymentApiShouldReturnBadRequestWithInvalidValueScale() {
        InstantPaymentSettlementRequestDTO instantPaymentSettlementRequestDTO = createSettlementRequestDTO();
        instantPaymentSettlementRequestDTO.setValue(new BigDecimal("0.123"));

        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(instantPaymentSettlementRequestDTO)
            .header(AUTHORIZATION_HEADER, AUTHORIZATION_HEADER_VALUE)
            .header(IDEMPOTENCY_ID_HEADER, IDEMPOTENCY_ID_HEADER_VALUE)
            .when()
            .post(URL)
            .then()
            .log().all().and()
            .statusCode(400)
            .assertThat().body("error[0].message", Matchers.containsString("Only 2 digits are allowed to the right of the decimal point"));
    }

    @Test
    void InstantPaymentApiShouldReturnBadRequestWithTooBigIdempotencyId() {
        InstantPaymentSettlementRequestDTO instantPaymentSettlementRequestDTO = createSettlementRequestDTO();
        String idempotencyId =
            "RANDOMIDEMPOTENCYID_RANDOMIDEMPOTENCYID_RANDOMIDEMPOTENCYID_RANDOMIDEMPOTENCYID_RANDOMIDEMPOTENCYID_RANDOMIDEMPOTENCYID_RANDOMIDEMPOTENCYID_RANDOMIDEMPOTENCYID_RANDOMIDEMPOTENCYID_RANDOMIDEMPOTENCYID_RANDOMIDEMPOTENCYID_RANDOMIDEMPOTENCYID_RANDOMIDEMPOTENCYID_RANDOMIDEMPOTENCYID_RANDOMIDEMPOTENCYID_R";

        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(instantPaymentSettlementRequestDTO)
            .header(AUTHORIZATION_HEADER, AUTHORIZATION_HEADER_VALUE)
            .header(IDEMPOTENCY_ID_HEADER, idempotencyId)
            .when()
            .post(URL)
            .then()
            .log().all().and()
            .statusCode(400)
            .assertThat().body("error[0].message", Matchers.containsString("IdempotencyId should not have more than 300 characteres"));
    }

    @Test
    void InstantPaymentApiShouldReturnSuccess() {
        InstantPaymentSettlementRequestDTO instantPaymentSettlementRequestDTO = createSettlementRequestDTO();
        instantPaymentSettlementRequestDTO.getPayer().setTaxId("78232003090");
        instantPaymentSettlementRequestDTO.getPayer().setPersonType(SettlementPayerDTO.PersonTypeEnum.PF);
        instantPaymentSettlementRequestDTO.getPayer().getAccount().setAccountType(AccountTypeDTO.SLRY);
        instantPaymentSettlementRequestDTO.setValue(BigDecimal.valueOf(555));

        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(instantPaymentSettlementRequestDTO)
            .header(AUTHORIZATION_HEADER, AUTHORIZATION_HEADER_VALUE)
            .header(IDEMPOTENCY_ID_HEADER, IDEMPOTENCY_ID_HEADER_VALUE)
            .when()
            .post(URL)
            .then()
            .log().all().and()
            .statusCode(202);

        List<TransactionEntity> transactions = transactionRepository.findAll();
        TransactionEntity transactionEntity = transactions.get(0);

        assertThat(transactionEntity.getPayerAccount().getTaxId()).isEqualTo("78232003090");
        assertThat(transactionEntity.getPayerAccount().getPersonType()).isEqualTo(SettlementPayerDTO.PersonTypeEnum.PF.toString());
        assertThat(transactionEntity.getPayerAccount().getAccountType()).isEqualTo(AccountTypeDTO.SLRY.toString());
    }

    @Test
    void settlementsApiShouldReturnHttpStatus200WithTotalElementsAndTotalPages() {
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .when()
            .get("/api/v1/settlements?pageSize=10&pageNumber=0&eventType=ALL&eventStatus=ALL")
            .then()
            .assertThat()
            .statusCode(200)
            .body("data.totalElements", Matchers.notNullValue())
            .body("data.totalPages", Matchers.notNullValue());
    }


    @ParameterizedTest
    @MethodSource("getValuesDifferentToBranchAndAccountNumber")
    void InstantPaymentApiShouldReturnBadRequestWhenBranchAndAccountNumberFromReceiverIsEqualFromThePayer(String branch, String accountNumber) {
        InstantPaymentSettlementRequestDTO instantPaymentSettlementRequestDTO = createSettlementRequestDTO();
        createPayer(instantPaymentSettlementRequestDTO);
        createReceiver(branch, accountNumber, instantPaymentSettlementRequestDTO);

        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(instantPaymentSettlementRequestDTO)
            .header(AUTHORIZATION_HEADER, AUTHORIZATION_HEADER_VALUE)
            .header(IDEMPOTENCY_ID_HEADER, IDEMPOTENCY_ID_HEADER_VALUE)
            .when()
            .post(URL)
            .then()
            .statusCode(400)
            .assertThat()
            .body("error[0].code", Matchers.equalTo("SPI-ME-024"))
            .body("error[0].message", Matchers.equalTo(MESSAGE_ERROR_FROM_BRANCH_ACCOUNT_IS_EQUALS));
    }

    private void createReceiver(String branch,
                                String accountNumber,
                                InstantPaymentSettlementRequestDTO instantPaymentSettlementRequestDTO) {

        instantPaymentSettlementRequestDTO.getReceiver().setReceiverTaxId(RECEIVER_TAX_ID);
        instantPaymentSettlementRequestDTO.getReceiver().getAccount().setAccountType(AccountTypeDTO.SLRY);
        instantPaymentSettlementRequestDTO.getReceiver().getAccount().setBranch(branch);
        instantPaymentSettlementRequestDTO.getReceiver().getAccount().setAccountNumber(accountNumber);
        instantPaymentSettlementRequestDTO.getReceiver().setReceiverInstitutionISPB(13370835);
    }

    private void createPayer(InstantPaymentSettlementRequestDTO instantPaymentSettlementRequestDTO) {
        instantPaymentSettlementRequestDTO.getPayer().setTaxId(RECEIVER_TAX_ID);
        instantPaymentSettlementRequestDTO.getPayer().setPersonType(SettlementPayerDTO.PersonTypeEnum.PF);
        instantPaymentSettlementRequestDTO.getPayer().getAccount().setAccountType(AccountTypeDTO.SLRY);
        instantPaymentSettlementRequestDTO.setValue(BigDecimal.valueOf(555));
    }

    private static Stream<Arguments> getValuesDifferentToBranchAndAccountNumber() {
        return Stream.of(
            Arguments.arguments("01","035"),
            Arguments.arguments("001","0035"),
            Arguments.arguments("00-1","0035"),
            Arguments.arguments("001","003-5"));
    }

}
