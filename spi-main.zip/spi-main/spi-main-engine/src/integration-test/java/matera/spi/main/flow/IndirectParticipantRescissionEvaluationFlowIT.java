package matera.spi.main.flow;

import com.matera.commons.utils.exception.BusinessException;

import matera.spi.commons.IntegrationTest;
import matera.spi.indirect.domain.model.ParticipantMipIndirectEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectHistoryEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectHistoryEntity.Type;
import matera.spi.indirect.domain.model.ParticipantMipIndirectStatusEntity;
import matera.spi.indirect.domain.service.IndirectParticipantHistoryService;
import matera.spi.indirect.domain.service.IndirectParticipantMipService;
import matera.spi.indirect.exception.message.ExceptionMessages;
import matera.spi.indirect.persistence.ParticipantMipIndirectContactsRepository;
import matera.spi.indirect.persistence.ParticipantMipIndirectHistoryRepository;
import matera.spi.indirect.persistence.ParticipantMipIndirectRepository;
import matera.spi.indirect.persistence.ParticipantMipIndirectStatusRepository;
import matera.spi.indirect.util.ParticipantMipIndirectDataSetUtil;
import matera.spi.lm.application.service.LMEmailSenderService;
import matera.spi.main.apisInterface.EmailSenderApiService;
import matera.spi.main.domain.service.event.receiver.MessageReceiver;
import matera.spi.main.dto.MessageReceiverDTO;
import matera.spi.main.persistence.ParticipantMipRepository;
import matera.spi.main.persistence.ParticipantRescissionEmailNotificationRepository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDateTime;

import static matera.spi.indirect.domain.model.enums.IndirectParticipantStatusEnum.WAITING_TO_SEND_DEREGISTRATION_TO_CLEARING;
import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static matera.spi.utils.LocalDateTimeUtils.parseLocalDateTimeUTC;

import static org.apache.commons.lang3.math.NumberUtils.LONG_ONE;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;

@IntegrationTest
public class IndirectParticipantRescissionEvaluationFlowIT {

    public static final Integer INDIRECT_ISPB = 123454;
    public static final LocalDateTime EXPECTED_EXPIRE_TIMESTAMP = parseLocalDateTimeUTC("2020-01-02T08:30:12.000Z");

    private static final String REDA_017_XML = getStringFromXmlFile("reda.017/reda.017_msg.xml");

    @Autowired
    private ParticipantMipIndirectRepository participantMipIndirectRepository;

    @Autowired
    private ParticipantMipRepository participantMipRepository;

    @Autowired
    private ParticipantMipIndirectStatusRepository participantMipIndirectStatusRepository;

    @Autowired
    private IndirectParticipantMipService indirectParticipantMipService;

    @Autowired
    private MessageReceiver messageReceiver;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private IndirectParticipantHistoryService indirectParticipantHistoryService;

    @Autowired
    private ParticipantMipIndirectContactsRepository participantMipIndirectContactsRepository;

    @Autowired
    private ParticipantMipIndirectHistoryRepository participantMipIndirectHistoryRepositor;

    @Autowired
    private LMEmailSenderService emailSenderService;

    @Autowired
    private EmailSenderApiService emailSenderApiService;

    @Mock
    private EmailSenderApiService emailSenderApiServiceMock;

    @Autowired
    private ParticipantRescissionEmailNotificationRepository participantRescissionEmailNotificationRepository;

    @BeforeEach
    void beforeEach() {
        ReflectionTestUtils.setField(emailSenderService, "emailSenderApiService", emailSenderApiServiceMock);
    }

    @AfterEach
    void afterEach() {
        ReflectionTestUtils.setField(emailSenderService, "emailSenderApiService", emailSenderApiService);
        participantRescissionEmailNotificationRepository.deleteAll();

        ParticipantMipIndirectDataSetUtil.cleanIndirectParticipantTablesData(participantMipIndirectHistoryRepositor,
            participantMipIndirectContactsRepository, participantMipIndirectRepository, participantMipRepository);
    }

    @Test
    void shouldProcessReda017() {
        final ParticipantMipIndirectEntity participantMipIndirectEntity = participantMipIndirectRepository.saveAndFlush(
            ParticipantMipIndirectDataSetUtil.createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                ParticipantMipIndirectDataSetUtil.createParticipantMip()));
        final Page<ParticipantMipIndirectHistoryEntity> indirectParticipantHistoryListBeforeMessage = getIndirectParticipantHistory(INDIRECT_ISPB);
        Assertions.assertEquals(INDIRECT_ISPB, participantMipIndirectEntity.getParticipantMip().getIspb());
        Assertions.assertTrue(indirectParticipantHistoryListBeforeMessage.isEmpty());

        messageReceiver.readIncomingMessage(buildMessageReceiverDTO(REDA_017_XML));

        final ParticipantMipIndirectEntity actualIndirectParticipant = getIndirectParticipantByIspb(INDIRECT_ISPB);
        final ParticipantMipIndirectStatusEntity actualIndirectParticipantStatus = actualIndirectParticipant.getStatus();
        final Page<ParticipantMipIndirectHistoryEntity> actualIndirectParticipantHistoryPage = getIndirectParticipantHistory(INDIRECT_ISPB);
        Assertions.assertEquals(WAITING_TO_SEND_DEREGISTRATION_TO_CLEARING.getId(), actualIndirectParticipantStatus.getId());
        Assertions.assertEquals(EXPECTED_EXPIRE_TIMESTAMP, actualIndirectParticipant.getCurrentStatusExpireTimestamp());

        Assertions.assertFalse(actualIndirectParticipantHistoryPage.isEmpty());
        Assertions.assertEquals(LONG_ONE, actualIndirectParticipantHistoryPage.getTotalElements());
        final ParticipantMipIndirectHistoryEntity actualHistoryEntity = actualIndirectParticipantHistoryPage.getContent().get(0);
        Assertions.assertEquals(Type.CLEARING_RESCISSION_INCOMING_MESSAGE, actualHistoryEntity.getType());

        verify(emailSenderApiServiceMock).sendEmail(anyString(), anyString());
        Assertions.assertEquals(1, participantRescissionEmailNotificationRepository.findAll().size());
    }

    private Page<ParticipantMipIndirectHistoryEntity> getIndirectParticipantHistory(Integer indirectIspb) {
        final PageRequest pageable = PageRequest.of(0, 10);
        return indirectParticipantHistoryService.findHistoryByIspb(pageable, indirectIspb);
    }

    private ParticipantMipIndirectEntity getIndirectParticipantByIspb(int ispb) {
        return indirectParticipantMipService.findByIspb(ispb)
            .orElseThrow(() -> ExceptionMessages.SPI_IND_001.asSupplier(BusinessException.class).get());
    }

    private String buildMessageReceiverDTO(String reda017) {
        final MessageReceiverDTO messageReceiverDTO =
            MessageReceiverDTO.builder()
                .messageType("reda.017.spi.1.0")
                .piResourceId("TEST_PI_RESOURCE_ID")
                .xml(reda017)
                .build();
        try {
            return objectMapper.writeValueAsString(messageReceiverDTO);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        return "";
    }

}
