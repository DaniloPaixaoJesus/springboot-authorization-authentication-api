package matera.spi.main.flow.intraMip;

import matera.spi.main.utils.WireMockUtils;

import org.junit.jupiter.api.BeforeEach;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;

import static matera.spi.main.utils.WireMockUtils.V1_CREDITS;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;

@ActiveProfiles("indirects")
class IndirectIntraMipReturnReceivedFlowIT extends IntraMipReturnReceivedFlowIT {

    @BeforeEach
    void setUpIndirect() {
        WireMockUtils.stubV1CreditsEntryValidation();
        WireMockUtils.stubV1IpAccount();

        WireMockUtils.stubV1IndirectsForIntraMip();
    }

    @Override
    protected void stubBadRequestCreditValidation() {
        stubFor(post(V1_CREDITS)
            .willReturn(aResponse()
                .withStatus(HttpStatus.BAD_REQUEST.value())
                .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .withBody("{\"rejectionReason\": {\"rejectionReasonCode\": \"AC07\" } }")
            )
        );
    }
}
