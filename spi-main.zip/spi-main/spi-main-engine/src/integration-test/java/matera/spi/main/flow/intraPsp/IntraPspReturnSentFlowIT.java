package matera.spi.main.flow.intraPsp;

import com.matera.commons.rest.dto.MateraRestReturnDTO;
import com.matera.spi.messaging.model.MessageSpecificationDTO;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.AccountTypeDTO;
import matera.spi.dto.InstantPaymentSettlementRequestDTO;
import matera.spi.dto.ReturnSettlementUIWapperDTO;
import matera.spi.dto.ReturnSettlementWrapperDTO;
import matera.spi.dto.SettlementPayerDTO;
import matera.spi.main.domain.model.ConfigEntity;
import matera.spi.main.domain.model.IpAccountConfigEntity;
import matera.spi.main.domain.model.ParticipantMipEntity;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventType;
import matera.spi.main.domain.model.event.transaction.PaymentEventEntity;
import matera.spi.main.domain.model.event.transaction.ReceiptEventEntity;
import matera.spi.main.domain.service.ConfigurationService;
import matera.spi.main.domain.service.CorrelationIdGenerator;
import matera.spi.main.domain.service.IpAccountConfigurationService;
import matera.spi.main.domain.service.event.receiver.AccountTransactionReceiver;
import matera.spi.main.domain.service.event.receiver.MessageReceiver;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.ParticipantMipRepository;
import matera.spi.main.utils.AccountTransactionMocker;
import matera.spi.main.utils.MessageCreationUtils;
import matera.spi.main.utils.WireMockUtils;
import matera.spi.main.utils.verifier.EventVerifier;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.CountMatchingStrategy;
import com.sun.istack.NotNull;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import static matera.spi.main.utils.InstantPaymentCreationUtils.ADDITIONAL_INFORMATION;
import static matera.spi.main.utils.InstantPaymentCreationUtils.CHARGE_BEARER_SLEV;
import static matera.spi.main.utils.InstantPaymentCreationUtils.EXTERNAL_ACCOUNT;
import static matera.spi.main.utils.InstantPaymentCreationUtils.EXTERNAL_BRANCH;
import static matera.spi.main.utils.InstantPaymentCreationUtils.INSTRUCTION_PRIORITY_HIGH;
import static matera.spi.main.utils.InstantPaymentCreationUtils.LEFT_PADDED_PARTICIPANT_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ACCOUNT;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_BRANCH;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_TAX_ID;
import static matera.spi.main.utils.InstantPaymentCreationUtils.SETTLEMENT_METHOD_CLRG;
import static matera.spi.main.utils.InstantPaymentSettlementRequestCreationUtils.createSettlementRequestDTO;
import static matera.spi.main.utils.MessageCreationUtils.buildMessageReceiverJson;
import static matera.spi.main.utils.WireMockUtils.V_1_MESSAGES;
import static matera.spi.main.utils.WireMockUtils.never;
import static matera.spi.main.utils.verifier.EventVerifier.PENDING_CREDIT_ACCOUNT_HOLDER;
import static matera.spi.main.utils.verifier.EventVerifier.RETURN_INITIATED;
import static matera.spi.main.utils.verifier.EventVerifier.RETURN_RECEIVED;
import static matera.spi.main.utils.verifier.EventVerifier.RETURN_REJECTED;
import static matera.spi.main.utils.verifier.EventVerifier.RETURN_REJECTION_CONFIRMED;
import static matera.spi.main.utils.verifier.EventVerifier.SUCCESS;
import static matera.spi.main.utils.verifier.EventVerifier.WAITING_CREDIT_VALIDATION;
import static matera.spi.main.utils.verifier.EventVerifier.WAITING_RETURN_CONFIRM;
import static matera.spi.main.utils.verifier.EventVerifier.verifyAllStatusTransactions;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.exactly;
import static com.github.tomakehurst.wiremock.client.WireMock.matching;
import static com.github.tomakehurst.wiremock.client.WireMock.matchingJsonPath;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.resetAllRequests;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlMatching;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.containsString;

@IntegrationTest
class IntraPspReturnSentFlowIT {

    @LocalServerPort
    protected int port;

    @Autowired
    private ParticipantMipRepository participantMipRepository;

    @Autowired
    private AccountTransactionReceiver accountTransactionReceiver;

    @Autowired
    private MessageReceiver messageReceiver;

    @Autowired
    protected EventRepository eventRepository;

    @Autowired
    protected TransactionTemplate transactionTemplate;

    @Autowired
    private AccountTransactionMocker accountTransactionMocker;

    @Autowired
    private IpAccountConfigurationService ipAccountConfigurationService;

    @Autowired
    protected ConfigurationService configurationService;

    private static WireMockServer wireMockServer;

    @BeforeAll
    static void beforeAll() {
        wireMockServer = WireMockUtils.start();

        WireMockUtils.stubMessaging();

        WireMockUtils.stubStandin();

    }

    @AfterAll
    static void afterAll() {
        wireMockServer.stop();
    }

    @BeforeEach
    void setUp() {
        RestAssured.port = port;

        resetAllRequests();

        WireMockUtils.stubStandinEntryValidation();

        accountTransactionMocker.mockReverter();
        accountTransactionMocker.spyExecutor();
    }

    @AfterEach
    void tearDown() {
        accountTransactionMocker.restoreAll();
    }

    @Test
    @DisplayName("intra psp return sent should set event status to success")
    void intraPspReturnSentShouldSetEventSuccess() {

        //Given
        makeIntraPspPaymentAndReceipt();

        sendReturnByAPI(getReceiptEvent(), port);

        String pacs004 = getPacs004FromReturnSent();
        resetAllRequests();
        receiveAMessage(pacs004);

        //When
        String pacs002 = getPacs002FromReturnReceived();
        receiveAMessage(pacs002);

        //Then
        transactionTemplate.execute(status -> {
            List<EventEntity> events = eventRepository.findAll(Sort.by(Sort.Direction.ASC, "initiationTimestampUTC"));
            assertThat(events).hasSize(4);

            EventEntity returnSent = events.get(2);
            EventEntity returnReceived = events.get(3);

            assertThat(returnSent.getEventType()).isEqualTo(EventType.RETURN_SENDER);
            assertThat(returnReceived.getEventType()).isEqualTo(EventType.RETURN_RECEIVER);
            assertThat(returnSent.getCorrelationId()).isEqualTo(returnReceived.getCorrelationId());

            assertThat(returnSent.getStatus().getDescription()).isEqualTo(SUCCESS);
            verifyAllStatusTransactions(returnSent, List.of(RETURN_INITIATED, WAITING_CREDIT_VALIDATION, SUCCESS));

            assertThat(returnReceived.getStatus().getDescription()).isEqualTo(PENDING_CREDIT_ACCOUNT_HOLDER);
            verifyAllStatusTransactions(returnReceived, List.of(RETURN_RECEIVED, WAITING_RETURN_CONFIRM, PENDING_CREDIT_ACCOUNT_HOLDER));

            return null;
        });

    }

    @Test
    @DisplayName("intra psp return should set event status to rejected when credit validation got internal server error")
    void intraPspReturnShouldHandleCreditValidationInternalServerError() {

        //Given
        makeIntraPspPaymentAndReceipt();

        stubInternalServerErrorCreditValidation();

        sendReturnByAPI(getReceiptEvent(), port);

        String pacs004 = getPacs004FromReturnSent();
        resetAllRequests();
        receiveAMessage(pacs004);

        //When
        String pacs002 = getPacs002FromReturnReceived();
        receiveAMessage(pacs002);

        //Then
        transactionTemplate.execute(status -> {
            List<EventEntity> events = eventRepository.findAll(Sort.by(Sort.Direction.ASC, "initiationTimestampUTC"));
            assertThat(events).hasSize(4);

            EventEntity returnSent = events.get(2);
            EventEntity returnReceived = events.get(3);

            assertThat(returnSent.getEventType()).isEqualTo(EventType.RETURN_SENDER);
            assertThat(returnReceived.getEventType()).isEqualTo(EventType.RETURN_RECEIVER);
            assertThat(returnSent.getCorrelationId()).isEqualTo(returnReceived.getCorrelationId());

            verifyAllStatusTransactions(returnSent, List.of(RETURN_INITIATED, WAITING_CREDIT_VALIDATION, RETURN_REJECTED));

            verifyAllStatusTransactions(returnReceived, List.of(RETURN_RECEIVED, RETURN_REJECTED, RETURN_REJECTION_CONFIRMED));

            return null;
        });

    }

    @Test
    @DisplayName("intra psp return should set event status to rejected")
    void intraPspReturnShouldHandleWhenCreditValidationGotBadRequest() {
        //Given
        makeIntraPspPaymentAndReceipt();

        stubBadRequestCreditValidation();

        sendReturnByAPI(getReceiptEvent(), port);

        String pacs004 = getPacs004FromReturnSent();
        resetAllRequests();
        receiveAMessage(pacs004);

        //When
        String pacs002 = getPacs002FromReturnReceived();
        receiveAMessage(pacs002);

        //Then
        transactionTemplate.execute(status -> {
            List<EventEntity> events = eventRepository.findAll(Sort.by(Sort.Direction.ASC, "initiationTimestampUTC"));
            assertThat(events).hasSize(4);

            EventEntity returnSent = events.get(2);
            EventEntity returnReceived = events.get(3);

            assertThat(returnSent.getEventType()).isEqualTo(EventType.RETURN_SENDER);
            assertThat(returnReceived.getEventType()).isEqualTo(EventType.RETURN_RECEIVER);
            assertThat(returnSent.getCorrelationId()).isEqualTo(returnReceived.getCorrelationId());

            verifyAllStatusTransactions(returnSent, List.of(RETURN_INITIATED, WAITING_CREDIT_VALIDATION, RETURN_REJECTED));

            verifyAllStatusTransactions(returnReceived, List.of(RETURN_RECEIVED, RETURN_REJECTED, RETURN_REJECTION_CONFIRMED));

            return null;
        });

    }

    @Test
    void intraPspPaymentShouldNotPublishMessage() {

        //Given
        makeIntraPspPaymentAndReceipt();

        sendReturnByAPI(getReceiptEvent(), port);

        String pacs004 = getPacs004FromReturnSent();
        resetAllRequests();
        receiveAMessage(pacs004);

        //When
        String pacs002 = getPacs002FromReturnReceived();
        resetAllRequests();
        receiveAMessage(pacs002);

        //Then
        verify(never(), postRequestedFor(urlMatching(V_1_MESSAGES)));

    }

    @Test
    @DisplayName("return should call v1/messages passing destination with receiver isbp")
    void returnShouldCallV1MessagesPassingDestinationWithReceiverIsbp() {
        //given
        makeIntraPspPaymentAndReceipt();
        resetAllRequests();

        //when
        sendReturnByAPI(getReceiptEvent(), port);

        //then
        verify(exactly(1),
            postRequestedFor(urlMatching(V_1_MESSAGES))
                .withRequestBody(matchingJsonPath("$.origin", equalTo(LEFT_PADDED_PARTICIPANT_ISPB)))
                .withRequestBody(matchingJsonPath("$.destination", equalTo(LEFT_PADDED_PARTICIPANT_ISPB)))
                .withRequestBody(matchingJsonPath("$.messageDefinitionIdentifier", matching("pacs.004.spi.*")))
        );
    }

    @Test
    @DisplayName("intra psp return sent should set event status to waiting credit validation after sending")
    void intraPspReturnSentShouldSetEventStatusToWaitingCreditValidationAfterSending() {
        //given
        makeIntraPspPaymentAndReceipt();
        resetAllRequests();

        //when
        sendReturnByAPI(getReceiptEvent(), port);

        //then
        transactionTemplate.execute(status -> {
            List<EventEntity> events = eventRepository.findAll(Sort.by(Sort.Direction.ASC, "initiationTimestampUTC"));
            assertThat(events).hasSize(3);

            EventEntity returnSentEventEntity = events.get(2);
            assertThat(returnSentEventEntity.getEventType().getCode()).isEqualTo(EventType.RETURN_SENDER.getCode());
            EventVerifier
                .verifyAllStatusTransactions(returnSentEventEntity, List.of(RETURN_INITIATED, WAITING_CREDIT_VALIDATION));

            return null;
        });

    }

    @Test
    @DisplayName("intra psp return should not do managerial transaction and mirror transaction")
    void intraPspReturnShouldNotDoManagerialTransactionAndMirrorTransaction() {
        //given
        makeIntraPspPaymentAndReceipt();
        resetAllRequests();

        //when
        sendReturnByAPI(getReceiptEvent(), port);

        //then
        ParticipantMipEntity participantMip = participantMipRepository.findByIspb(PARTICIPANT_ISPB)
            .orElseThrow(() -> new RuntimeException("Not found participantMip " + PARTICIPANT_ISPB));
        verify(never(),
            postRequestedFor(urlEqualTo("/api/v2/contas/" + participantMip.getBranch() + "/" + participantMip.getAccountNumber() + "/lancamentos"))
        );

        IpAccountConfigEntity mirrorAccountConfig = ipAccountConfigurationService.findConfig()
            .orElseThrow(() ->  new RuntimeException("Not found mirrorAccountConfig"));
        verify(never(),
            postRequestedFor(urlEqualTo("/api/v2/contas/" + mirrorAccountConfig.getBranch() + "/" + mirrorAccountConfig.getAccountNumber() + "/lancamentos"))
        );
    }

    @DisplayName("intra psp return by API should do customer transaction")
    @Test
    void intraPspReturnByAPIShouldDoCustomerTransaction() {
        //given
        makeIntraPspPaymentAndReceipt();
        resetAllRequests();

        //when
        sendReturnByAPI(getReceiptEvent(), port);

        //then
        ConfigEntity customerConfig = configurationService.findConfig();
        String receiverAccount = EXTERNAL_ACCOUNT.replace("-","");
        verify(customerTransactionCalls(),
            postRequestedFor(urlEqualTo("/api/v2/contas/" + EXTERNAL_BRANCH + "/" + receiverAccount + "/lancamentos"))
                .withRequestBody(matchingJsonPath("$.lancamentos[?(@.historico == " + customerConfig.getCustIntraPspDrawbSentTransType() + " )]"))
        );

    }

    @DisplayName("intra psp return by API should do customer transaction")
    @Test
    void intraPspReturnReceivedByAPIShouldDoCustomerTransaction() {
        //given
        makeIntraPspPaymentAndReceipt();
        resetAllRequests();
        sendReturnByAPI(getReceiptEvent(), port);

        String pacs004 = getPacs004FromReturnSent();
        resetAllRequests();
        receiveAMessage(pacs004);

        String pacs002 = getPacs002FromReturnReceived();
        receiveAMessage(pacs002);
        resetAllRequests();
        //when
        processCreditWorkQueueForReturnReceived();

        //then
        ConfigEntity customerConfig = configurationService.findConfig();

        verify(customerTransactionCalls(),
            postRequestedFor(urlEqualTo("/api/v2/contas/" + PARTICIPANT_BRANCH + "/" + PARTICIPANT_ACCOUNT + "/lancamentos"))
                .withRequestBody(matchingJsonPath("$.lancamentos[?(@.historico == " + customerConfig.getCustIntraPspDrawbReceivedTransType() + " )]"))
        );

    }

    protected CountMatchingStrategy customerTransactionCalls() {
        return exactly(1);
    }

    @Test
    void returnReceivedShouldCallV1MessagesPassingOriginAndDestinationWithParticipantIsbp() {
        //Given
        makeIntraPspPaymentAndReceipt();

        sendReturnByAPI(getReceiptEvent(), port);

        //When
        String pacs004 = getPacs004FromReturnSent();
        receiveAMessage(pacs004);

        //Then
        verify(exactly(1),
            postRequestedFor(urlMatching(V_1_MESSAGES))
                .withRequestBody(matchingJsonPath("$.origin", equalTo(LEFT_PADDED_PARTICIPANT_ISPB)))
                .withRequestBody(matchingJsonPath("$.destination", equalTo(LEFT_PADDED_PARTICIPANT_ISPB)))
                .withRequestBody(matchingJsonPath("$.messageDefinitionIdentifier", matching("pacs.002.spi.*")))
        );
    }

    @Test
    void intraPSPReturnReceivedShouldGenerateAEventWithTheSameReturnSentCorrelationIdAndStatusEqualWaitingReturnConfirm() {

        //Given
        makeIntraPspPaymentAndReceipt();

        sendReturnByAPI(getReceiptEvent(), port);

        //When
        String pacs004 = getPacs004FromReturnSent();
        receiveAMessage(pacs004);

        //Then
        transactionTemplate.execute(status -> {
            List<EventEntity> events = eventRepository.findAll(Sort.by(Sort.Direction.ASC, "initiationTimestampUTC"));
            assertThat(events).hasSize(4);

            EventEntity returnSent = events.get(2);
            EventEntity returnReceived = events.get(3);

            assertThat(returnSent.getEventType()).isEqualTo(EventType.RETURN_SENDER);
            assertThat(returnReceived.getEventType()).isEqualTo(EventType.RETURN_RECEIVER);
            assertThat(returnSent.getCorrelationId()).isEqualTo(returnReceived.getCorrelationId());

            verifyAllStatusTransactions(returnSent, List.of(RETURN_INITIATED, WAITING_CREDIT_VALIDATION));

            verifyAllStatusTransactions(returnReceived, List.of(RETURN_RECEIVED, WAITING_RETURN_CONFIRM));

            return null;
        });
    }

    @Test
    void shouldIgnoreDuplicatedIntraPSPReturnReceiver() {
        //Given
        makeIntraPspPaymentAndReceipt();

        sendReturnByAPI(getReceiptEvent(), port);

        String pacs004 = getPacs004FromReturnSent();
        receiveAMessage(pacs004);

        //When
        receiveAMessage(pacs004);

        //Then
        transactionTemplate.execute(status -> {
            List<EventEntity> events = eventRepository.findAll(Sort.by(Sort.Direction.ASC, "initiationTimestampUTC"));
            assertThat(events).hasSize(4);

            EventEntity returnSent = events.get(2);
            EventEntity returnReceived = events.get(3);

            assertThat(returnSent.getEventType()).isEqualTo(EventType.RETURN_SENDER);
            assertThat(returnReceived.getEventType()).isEqualTo(EventType.RETURN_RECEIVER);
            assertThat(returnSent.getCorrelationId()).isEqualTo(returnReceived.getCorrelationId());

            verifyAllStatusTransactions(returnSent, List.of(RETURN_INITIATED, WAITING_CREDIT_VALIDATION));

            verifyAllStatusTransactions(returnReceived, List.of(RETURN_RECEIVED, WAITING_RETURN_CONFIRM));

            return null;
        });
    }

    @Test
    void intraPspReturnSentByUIShouldReturnBadRequest() {
        // Given
        makeIntraPspPaymentAndReceipt();

        ReturnSettlementUIWapperDTO returnSettlementUIWapperDTO = createReturnSettlementUIWapperDTO(getReceiptEvent());

        //when
        RestAssured
            .given()
                .header("Authorization", "Bearer teste")
                .contentType(ContentType.JSON)
                .body(returnSettlementUIWapperDTO)
            .when()
                .post("/ui/v1/settlement/return")
            .then()
                .statusCode(HttpStatus.BAD_REQUEST.value())
                .body(containsString("It is not possible to transfer intra MIP or intra PSP through the frontend"));

        //then
        List<EventEntity> events = eventRepository.findAll(Sort.by(Sort.Direction.ASC, "initiationTimestampUTC"));
        assertThat(events).as("Should only exist the payment/receipt event and not the return event").hasSize(2);

        EventEntity paymentEventEntity = events.get(0);
        assertThat(paymentEventEntity).isInstanceOf(PaymentEventEntity.class);

        EventEntity receiptEventEntity = events.get(1);
        assertThat(receiptEventEntity).isInstanceOf(ReceiptEventEntity.class);
    }

    private static ReturnSettlementUIWapperDTO createReturnSettlementUIWapperDTO(EventEntity originalEvent) {


        String returnEndToEndId =
            CorrelationIdGenerator.generateCorrelactionIdPacs004(String.valueOf(PARTICIPANT_ISPB));

        return new ReturnSettlementUIWapperDTO()
            .originalEndToEndIdentification(originalEvent.getCorrelationId())
            .returnEndToEndIdentification(returnEndToEndId)
            .creationDateTime(LocalDateTime.parse("2020-06-03T21:11:46.120"))
            .settlementMethod(SETTLEMENT_METHOD_CLRG)
            .settlementPriority(INSTRUCTION_PRIORITY_HIGH)
            .chargeBearer(CHARGE_BEARER_SLEV)
            .additionalInformation(ADDITIONAL_INFORMATION)
            .unstructured(" MORE ADDITIONAL INFO ")
            .returnReasonInformation(ReturnSettlementUIWapperDTO.ReturnReasonInformationEnum.AM05)
            .returnedInterbankSettlementAmount(BigDecimal.ONE);
    }

    protected void makeIntraPspPaymentAndReceipt() {
        sendPaymentByAPI(port);
        String pacs008 = getPacs008FromPayment();

        resetAllRequests();
        receiveAMessage(pacs008);

        String pacs002 = getPacs002FromReceipt();
        resetAllRequests();

        receiveAMessage(pacs002);
        processCreditWorkQueue();

        resetAllRequests();
    }

    protected String getPacs004FromReturnSent() {
        return getMessageContent("pacs.004.spi.1.4");
    }

    protected String getPacs008FromPayment() {
        return getMessageContent("pacs.008.spi.1.4");
    }

    protected String getPacs002FromReceipt() {
        return getMessageContent("pacs.002.spi.1.4");
    }

    protected String getPacs002FromReturnReceived() {
        return getMessageContent("pacs.002.spi.1.4");
    }

    protected void stubBadRequestCreditValidation() {
        stubCreditValidation(HttpStatus.BAD_REQUEST.value());
    }

    protected void stubInternalServerErrorCreditValidation() {
        stubCreditValidation(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    private void stubCreditValidation(int status) {
        stubFor(post(urlMatching("/api/v1/accounts/[0-9]+/[0-9]+/entry/validation"))
            .willReturn(aResponse()
                .withStatus(status)
            )
        );
    }

    @NotNull
    private String getMessageContent(String messageIdentifier) {
        MessageSpecificationDTO messageSpecification =
            WireMockUtils.getFirstBodyFrom(postRequestedFor(urlMatching(V_1_MESSAGES)), MessageSpecificationDTO.class);

        String xml = MessageCreationUtils
            .addAppHeader(messageSpecification.getMessageContent(), messageIdentifier, LEFT_PADDED_PARTICIPANT_ISPB,
                LEFT_PADDED_PARTICIPANT_ISPB);

        return buildMessageReceiverJson(WireMockUtils.getLastPiResourceId(), xml);
    }


    protected static void sendPaymentByAPI(Integer port) {
        InstantPaymentSettlementRequestDTO instantPaymentSettlementRequestDTO = getInstantPaymentSettlementRequestDTO();
        instantPaymentSettlementRequestDTO.getReceiver().setReceiverInstitutionISPB(PARTICIPANT_ISPB);

        RestTemplate restTemplate = new RestTemplate();

        HttpHeaders headers = new HttpHeaders();
        headers.add("IdempotencyId", RandomStringUtils.randomAlphanumeric(10));
        headers.add("Authorization", "Bearer " + RandomStringUtils.randomAlphanumeric(10));

        HttpEntity<InstantPaymentSettlementRequestDTO> request = new HttpEntity<>(instantPaymentSettlementRequestDTO, headers);

        String url = "http://localhost:" + port + "/api/v1/settlements/instant-payments";

        restTemplate.postForObject(url, request, MateraRestReturnDTO.class);
    }

    private static InstantPaymentSettlementRequestDTO getInstantPaymentSettlementRequestDTO() {
        InstantPaymentSettlementRequestDTO instantPaymentSettlementRequestDTO = createSettlementRequestDTO();
        instantPaymentSettlementRequestDTO.getReceiver().setReceiverInstitutionISPB(PARTICIPANT_ISPB);
        instantPaymentSettlementRequestDTO.getPayer().setTaxId(PARTICIPANT_TAX_ID);
        instantPaymentSettlementRequestDTO.getPayer().setPersonType(SettlementPayerDTO.PersonTypeEnum.PF);
        instantPaymentSettlementRequestDTO.getPayer().getAccount().setAccountType(AccountTypeDTO.CACC);
        return instantPaymentSettlementRequestDTO;
    }

    private void processCreditWorkQueueForReturnReceived() {
        EventEntity receiptEventEntity = getReturnReceivedEvent();
        accountTransactionReceiver.onMessage(new GenericMessage<>("{\"eventId\": \"" + receiptEventEntity.getId() + "\"}"));
    }

    protected EventEntity getReturnReceivedEvent() {
        List<EventEntity> events = eventRepository.findAll(Sort.by(Sort.Direction.ASC, "initiationTimestampUTC"));

        assertThat(events).as("Should exist the payment and receipt event here").hasSize(4);

        return events.get(3);
    }

    private void processCreditWorkQueue() {
        EventEntity receiptEventEntity = getReceiptEvent();
        accountTransactionReceiver.onMessage(new GenericMessage<>("{\"eventId\": \"" + receiptEventEntity.getId() + "\"}"));
    }

    protected EventEntity getReceiptEvent() {
        List<EventEntity> events = eventRepository.findAll(Sort.by(Sort.Direction.ASC, "initiationTimestampUTC"));

        assertThat(events).as("Should exist the payment and receipt event here").hasSize(2);

        return events.get(1);
    }

    protected static void sendReturnByAPI(EventEntity originalEvent, Integer port) {
        ReturnSettlementWrapperDTO returnSettlementWrapperDTO = new ReturnSettlementWrapperDTO()
            .originSystem("matera")
            .returnedAmount(originalEvent.getValue().setScale(2))
            .additionalInformation(ADDITIONAL_INFORMATION)
            .returnReasonCode("AM05")
            .returnReasonInformation("Return reason information")
            .demandsImmediateReturn(true);

        RestTemplate restTemplate = new RestTemplate();

        HttpHeaders headers = new HttpHeaders();
        headers.add("IdempotencyId", RandomStringUtils.randomAlphanumeric(10));
        headers.add("Authorization", "Bearer " + RandomStringUtils.randomAlphanumeric(10));

        HttpEntity<ReturnSettlementWrapperDTO> request = new HttpEntity<>(returnSettlementWrapperDTO, headers);

        String receiptId = originalEvent.getId().toString();
        String url = "http://localhost:" + port + "/api/v1/settlements/instant-payments/" + receiptId + "/returns";

        restTemplate.postForObject(url, request, MateraRestReturnDTO.class);
    }

    protected void receiveAMessage(String message) {
        messageReceiver.readIncomingMessage(message);
    }

}
