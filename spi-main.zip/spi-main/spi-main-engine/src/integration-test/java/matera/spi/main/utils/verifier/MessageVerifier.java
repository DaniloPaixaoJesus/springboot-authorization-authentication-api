package matera.spi.main.utils.verifier;

import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.utils.verifier.expected.dto.ExpectedMessageDTO;

import static matera.spi.main.utils.CustomAssertions.assertThatIsCloseToNow;
import static matera.spi.main.utils.InstantPaymentCreationUtils.BACEN_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.CLEARING_RESPONSE_DATE_TIME;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ISPB;

import static org.assertj.core.api.Assertions.assertThat;

public class MessageVerifier {

    private static final String PACS_002 = "pacs.002";
    private static final String PACS_004 = "pacs.004";
    private static final String PACS_008 = "pacs.008";

    private MessageVerifier() {/*utility classes should not be instantiated*/}

	private static void verifyMessage(MessageEntity actualMessageEntity, ExpectedMessageDTO expected) {
		assertThat(actualMessageEntity.getMessageTypeEntity().getCode()).isEqualTo(expected.getTypeCode());
		assertThat(actualMessageEntity.getVersion()).isEqualTo(expected.getVersion());
		assertThatIsCloseToNow(actualMessageEntity.getTimestampUtc());
		assertThat(actualMessageEntity.getPiResourceId()).isEqualTo(expected.getPiResourceId());
		assertThat(actualMessageEntity.getSenderParticipant().getIspb()).isEqualTo(expected.getSenderISPB());
		assertThat(actualMessageEntity.getReceiverParticipant().getIspb()).isEqualTo(expected.getReceiverISPB());
		if (expected.isClearingTimestampCloseToUTC()) {
			assertThatIsCloseToNow(actualMessageEntity.getClearingTimestampUtc());
		} else {
			assertThat(actualMessageEntity.getClearingTimestampUtc()).isEqualTo(expected.getClearingTimestamp());
		}
	}

	public static void verifyMessageEventRelation(MessageEntity messageEntity, EventEntity eventEntity) {
		assertThat(eventEntity.getMessages())
				.as("Event related only to the message").contains(messageEntity);
		assertThat(messageEntity.getEvents())
				.as("Message related only to the event").contains(eventEntity);
	}

	public static void verifyReceivedMessageIsPacs002(MessageEntity actual, String expectedPiResourceId, String version) {
		ExpectedMessageDTO expectedMessage = ExpectedMessageDTO.builder()
				.piResourceId(expectedPiResourceId)
				.typeCode("pacs.002")
				.version(version)
				.senderISPB(BACEN_ISPB)
				.receiverISPB(PARTICIPANT_ISPB)
				.clearingTimestamp(CLEARING_RESPONSE_DATE_TIME)
				.build();
		verifyMessage(actual, expectedMessage);
	}

	public static void verifySentMessageIsPacs002(MessageEntity actual, String expectedPiResourceId, String version) {
		ExpectedMessageDTO expectedMessage = ExpectedMessageDTO.builder()
				.piResourceId(expectedPiResourceId)
				.typeCode(PACS_002)
				.version(version)
				.senderISPB(PARTICIPANT_ISPB)
				.receiverISPB(BACEN_ISPB)
				.build();
		verifyMessage(actual, expectedMessage);
	}

	public static void verifyReceivedMessageIsPacs008(MessageEntity actual, String expectedPiResourceId, String version) {
		ExpectedMessageDTO expectedMessage = ExpectedMessageDTO.builder()
				.piResourceId(expectedPiResourceId)
				.typeCode(PACS_008)
				.version(version)
				.senderISPB(BACEN_ISPB)
				.receiverISPB(PARTICIPANT_ISPB)
				.clearingTimestampCloseToUTC(true)
				.build();
		verifyMessage(actual, expectedMessage);
	}

	public static void verifySentMessageIsPacs008(MessageEntity actual, String expectedPiResourceId, String version) {
		ExpectedMessageDTO expectedMessage = ExpectedMessageDTO.builder()
				.piResourceId(expectedPiResourceId)
				.typeCode(PACS_008)
				.version(version)
				.senderISPB(PARTICIPANT_ISPB)
				.receiverISPB(BACEN_ISPB)
				.build();
		verifyMessage(actual, expectedMessage);
	}

    public static void verifySentMessageIsPacs004(MessageEntity actual, String expectedPiResourceId, String version) {
        ExpectedMessageDTO expectedMessage = ExpectedMessageDTO.builder()
            .piResourceId(expectedPiResourceId)
            .typeCode(PACS_004)
            .version(version)
            .senderISPB(PARTICIPANT_ISPB)
            .receiverISPB(BACEN_ISPB)
            .build();
        verifyMessage(actual, expectedMessage);
    }

    public static void verifyReceivedMessageIsPacs004(MessageEntity actual, String expectedPiResourceId, String version) {
        ExpectedMessageDTO expectedMessage = ExpectedMessageDTO.builder()
            .piResourceId(expectedPiResourceId)
            .typeCode(PACS_004)
            .version(version)
            .senderISPB(BACEN_ISPB)
            .receiverISPB(PARTICIPANT_ISPB)
            .clearingTimestampCloseToUTC(true)
            .build();
        verifyMessage(actual, expectedMessage);
    }


}
