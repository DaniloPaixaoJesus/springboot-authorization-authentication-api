package matera.spi.main.utils.verifier;

import matera.spi.dto.InstantPaymentsUIDTO;
import matera.spi.dto.PaymentsUIDTO;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.transaction.PaymentEventEntity;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.domain.model.transaction.TransactionEntity;
import matera.spi.main.utils.verifier.expected.dto.ExpectedTransactionDTO;

import lombok.Builder;
import lombok.Data;
import lombok.NonNull;

import java.util.function.BiConsumer;

@Data
@Builder
public class PaymentVerifier {

    @NonNull EventEntity eventEntity;
    @NonNull TransactionEntity transactionEntity;

    @NonNull MessageEntity pacs008;
    @NonNull String expectedPacs008PiResourceId;
    @NonNull String expectedPacs008Version;

    @NonNull InstantPaymentsUIDTO instantPaymentsUIDTO;
    @NonNull BiConsumer<EventEntity, PaymentsUIDTO> eventVerifier;

	MessageEntity pacs002;
	String expectedPacs002PiResourceId;
	String expectedPacs002Version;

    private void verifyEvent() {
        eventVerifier.accept(eventEntity, instantPaymentsUIDTO.getPayments().get(0));
    }

    private void verifyTransaction() {
        TransactionVerifier.verifyTransaction(transactionEntity, ExpectedTransactionDTO.paymentFromInstantPaymentsUIDTO(instantPaymentsUIDTO));
        TransactionVerifier.verifyTransactionAndEventRelation((PaymentEventEntity) eventEntity, transactionEntity);
    }

    private void verifyPacs008Message() {
        MessageVerifier.verifySentMessageIsPacs008(pacs008, expectedPacs008PiResourceId, expectedPacs008Version);
        MessageVerifier.verifyMessageEventRelation(pacs008, eventEntity);
    }

	private void verifyPacs002Message() {
		if (pacs002 != null) {
			MessageVerifier.verifyReceivedMessageIsPacs002(pacs002, expectedPacs002PiResourceId, expectedPacs002Version);
			MessageVerifier.verifyMessageEventRelation(pacs002, eventEntity);
		}
	}

    public void verify() {
        verifyEvent();
        verifyTransaction();
        verifyPacs008Message();
        verifyPacs002Message();
    }
}
