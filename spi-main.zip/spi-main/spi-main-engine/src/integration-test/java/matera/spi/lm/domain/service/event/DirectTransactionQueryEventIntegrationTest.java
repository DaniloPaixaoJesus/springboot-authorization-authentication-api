package matera.spi.lm.domain.service.event;

import matera.spi.lm.domain.model.TransactionQueryEntity;
import matera.spi.lm.domain.model.event.TransactionQueryEventEntity;
import matera.spi.lm.dto.event.TransactionQueryEventSpecificationDTO;
import matera.spi.main.domain.service.event.Event;
import matera.spi.main.dto.event.EventSpecificationFromReceivedMessageDTO;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;

public class DirectTransactionQueryEventIntegrationTest extends AbstractTransactionQueryEventIntegrationTest {

    @Test
    void shouldReplyMsg() {
        Mockito.doReturn(buildMessageSentResponseDTO()).when(messagesApi).sendsMessageV1(Mockito.any());
        final TransactionQueryEventSpecificationDTO specificationDTO = buildEventSpecificationDTO();

        Event event = eventFactory.createNewEvent(specificationDTO);
        assertThat(event).isNotNull();

        TransactionQueryEvent actual = (TransactionQueryEvent) event;
        TransactionQueryEventEntity eventEntity = assertEventEntity(actual);

        TransactionQueryEntity transactionQueryEntity = eventEntity.getTransactionQueryEntity();
        assertThat(transactionQueryEntity).isNotNull();
        assertThat(transactionQueryEntity.getEndToEndID()).isEqualTo(END_TO_END_ID);

        final EventSpecificationFromReceivedMessageDTO eventSpecificationDTO = buildMessageReceivedDTO(CAMT_054_DOCUMENT);
        actual.actionsForReplyMessage(eventSpecificationDTO);

        assertDetailsAfterReply(transactionQueryEntity);
        assertThat(eventSpecificationDTO.getMessageEntity().getHasPermission()).isTrue();
    }

}
