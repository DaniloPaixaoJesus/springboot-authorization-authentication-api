package matera.spi.main.utils;

import matera.spi.dto.AccountTypeDTO;
import matera.spi.dto.InstantPaymentSettlementRequestDTO;
import matera.spi.dto.LocalAccountBaseDTO;
import matera.spi.dto.ReceiverDTO;
import matera.spi.dto.RemoteAccountDTO;
import matera.spi.dto.SettlementPayerDTO;
import matera.spi.main.domain.service.CorrelationIdGenerator;
import matera.spi.utils.LocalDateTimeUtils;

import org.jetbrains.annotations.NotNull;

import java.math.BigDecimal;

import static matera.spi.main.utils.InstantPaymentCreationUtils.EXTERNAL_ACCOUNT;
import static matera.spi.main.utils.InstantPaymentCreationUtils.EXTERNAL_BRANCH;
import static matera.spi.main.utils.InstantPaymentCreationUtils.EXTERNAL_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.EXTERNAL_TAX_ID;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ACCOUNT;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_BRANCH;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ISPB;

public class InstantPaymentSettlementRequestCreationUtils {

    private InstantPaymentSettlementRequestCreationUtils() {/*utility class should not be instantiated*/}

    public static InstantPaymentSettlementRequestDTO createSettlementRequestDTO() {
        return (InstantPaymentSettlementRequestDTO)
            new InstantPaymentSettlementRequestDTO()
                .value(BigDecimal.valueOf(1000))
                .additionalInformation("ADDITIONAL INFORMATION")
                .customerInitiationTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime())
                .originalSystemTransactionIdentifier("ORIGINAL SYSTEM TRANSACTION IDENTIFIER")
                .initiatingInstitution(76187362000103L)
                .demandsImmediateReturn(true)
                .historicComplement("HISTORIC COMPLEMENT")
                .informationAccountHolder("INFORMATION ACCOUNT HOLDER")
                .originSystem("matera")
                .payer(createPayer())
                .receiver(createReceiver());
    }

    @NotNull
    private static SettlementPayerDTO createPayer() {
        return new SettlementPayerDTO()
            .checkCustomerAccountBalance(true)
            .name("SOME PAYER NAME")
            .account(createPayerBaseAccountDTO());
    }

    @NotNull
    private static LocalAccountBaseDTO createPayerBaseAccountDTO() {
        return new LocalAccountBaseDTO()
            .accountNumber(Long.valueOf(PARTICIPANT_ACCOUNT))
            .branch(Integer.valueOf(PARTICIPANT_BRANCH));
    }

    private static ReceiverDTO createReceiver() {
        String endToEndIdQuery = CorrelationIdGenerator.generateCorrelactionIdPacs008(String.valueOf(PARTICIPANT_ISPB));
        return new ReceiverDTO()
            .receiverInstitutionISPB(EXTERNAL_ISPB)
            .receiverTaxId(EXTERNAL_TAX_ID)
            .addressingKey(EXTERNAL_TAX_ID)
            .endToEndIdQuery(endToEndIdQuery)
            .account(createReceiverAccountDTO());
    }

    @NotNull
    private static RemoteAccountDTO createReceiverAccountDTO() {
        return new RemoteAccountDTO()
            .branch(EXTERNAL_BRANCH)
            .accountNumber(EXTERNAL_ACCOUNT)
            .accountType(AccountTypeDTO.CACC);
    }
}
