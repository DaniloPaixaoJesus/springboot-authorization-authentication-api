package matera.spi.main.utils.verifier;

import matera.spi.main.domain.model.BalanceAccountPiEntity;
import matera.spi.main.utils.verifier.expected.dto.ExpectedIPAccountBalanceDTO;
import matera.spi.main.utils.verifier.expected.dto.ExpectedIPAccountBalanceDTO.ExpectedIPAccountBalanceDTOBuilder;

import java.math.BigDecimal;
import java.util.List;

import static matera.spi.main.domain.model.enums.EnumTransactionType.CREDIT;
import static matera.spi.main.domain.model.enums.EnumTransactionType.DEBIT;
import static matera.spi.main.utils.InstantPaymentCreationUtils.BIG_DEBIT_VALUE;
import static org.assertj.core.api.Assertions.assertThat;

public class IPAccountBalanceVerifier {

	private IPAccountBalanceVerifier() {/*utility class should not be instantiated*/}

	public static void verifyBalanceTransaction(BalanceAccountPiEntity actual, ExpectedIPAccountBalanceDTO expected) {
		assertThat(actual.getTransactionType()).isEqualTo(expected.getTransactionType());
		assertThat(actual.getBalance().doubleValue()).isEqualTo(expected.getBalanceAfterTransaction().doubleValue());
		assertThat(actual.getValue().doubleValue()).isEqualTo(expected.getTransactionValue().doubleValue());
	}

	public static void verifyAccountBalance(List<BalanceAccountPiEntity> allBalanceTransactions,
											int debits,
											int credits) {
		int total = debits + credits + 1;
		assertThat(allBalanceTransactions).hasSize(total);
		BalanceAccountPiEntity actualBalanceAccountPI = allBalanceTransactions.get(0);
		BigDecimal currentBalance = actualBalanceAccountPI.getBalance();

		for (int i = 1; i < total; i++) {
			actualBalanceAccountPI = allBalanceTransactions.get(i);
			ExpectedIPAccountBalanceDTOBuilder expectedBuilder = ExpectedIPAccountBalanceDTO.builder()
																			.transactionValue(BIG_DEBIT_VALUE);
			if (i <= debits) {
				currentBalance = currentBalance.subtract(BIG_DEBIT_VALUE);
				expectedBuilder.balanceAfterTransaction(currentBalance).transactionType(DEBIT);
			} else {
				currentBalance = currentBalance.add(BIG_DEBIT_VALUE);
				expectedBuilder.balanceAfterTransaction(currentBalance).transactionType(CREDIT);
			}
			verifyBalanceTransaction(actualBalanceAccountPI, expectedBuilder.build());

		}

	}

}
