package matera.spi.main.domain.service.scheduling;

import matera.spi.commons.IntegrationTest;
import matera.spi.indirect.domain.model.ParticipantMipIndirectEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectHistoryEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectStatusEntity;
import matera.spi.indirect.domain.service.IndirectParticipantHistoryService;
import matera.spi.indirect.domain.service.IndirectParticipantStatusService;
import matera.spi.indirect.domain.service.scheduling.IndirectParticipantUnregisterScheduling;
import matera.spi.indirect.persistence.ParticipantMipIndirectContactsRepository;
import matera.spi.indirect.persistence.ParticipantMipIndirectHistoryRepository;
import matera.spi.indirect.persistence.ParticipantMipIndirectRepository;
import matera.spi.indirect.util.ParticipantMipIndirectDataSetUtil;
import matera.spi.main.domain.model.ParticipantMipEntity;
import matera.spi.main.persistence.ParticipantMipRepository;

import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import static matera.spi.indirect.domain.model.enums.IndirectParticipantStatusEnum.ACTIVE;
import static matera.spi.indirect.domain.model.enums.IndirectParticipantStatusEnum.WAITING_TO_SEND_DEREGISTRATION_TO_CLEARING;

import static org.assertj.core.api.Assertions.assertThat;

@IntegrationTest
public class IndirectParticipantUnregisterSchedulingIT {

    private static final Integer ISPB = 12345434;
    private static final Integer ANOTHER_ISPB = 12345436;
    private static final Integer ISPB_NOT_EXPECTED = 12345439;
    private static final String FIRST_PARTICIPANT = "First Participant";
    private static final String SECOND_PARTICIPANT = "Second Participant";
    private static final String THIRD_PARTICIPANT = "Third Participant";

    @Autowired
    private IndirectParticipantStatusService indirectParticipantStatusService;

    @Autowired
    private IndirectParticipantHistoryService indirectParticipantHistoryService;

    @Autowired
    private ParticipantMipRepository participantMipRepository;

    @Autowired
    private ParticipantMipIndirectRepository participantMipIndirectRepository;

    @Autowired
    private ParticipantMipIndirectHistoryRepository participantMipIndirectHistoryRepository;

    @Autowired
    private ParticipantMipIndirectContactsRepository participantMipIndirectContactsRepository;

    @Autowired
    private IndirectParticipantUnregisterScheduling indirectParticipantUnregisterScheduling;

    @BeforeEach
    @AfterEach
    void cleanData() {
        ParticipantMipIndirectDataSetUtil.cleanIndirectParticipantTablesData(participantMipIndirectHistoryRepository,
            participantMipIndirectContactsRepository, participantMipIndirectRepository, participantMipRepository);
    }

    @Test
    void shouldUnregisterIndirectParticipantAndCreateHistoryBecauseItIsInStatusWaitingDeregistrationEvaluationForMoreThanTwentyFourHours() {
        ParticipantMipIndirectStatusEntity waitingDeregistrationEvaluation =
            indirectParticipantStatusService.findById(WAITING_TO_SEND_DEREGISTRATION_TO_CLEARING.getId()).orElseThrow();
        ParticipantMipIndirectStatusEntity active =
            indirectParticipantStatusService.findById(ACTIVE.getId()).orElseThrow();

        populateDatabaseWithBacenAlreadyApprovedDateTime(waitingDeregistrationEvaluation, ISPB, FIRST_PARTICIPANT);
        populateDatabaseWithBacenAlreadyApprovedDateTime(waitingDeregistrationEvaluation, ANOTHER_ISPB, SECOND_PARTICIPANT);
        ParticipantMipIndirectHistoryEntity thirdParticipantHistory =
            populateDatabaseWithBacenAlreadyApprovedDateTime(active, ISPB_NOT_EXPECTED, THIRD_PARTICIPANT);

        indirectParticipantUnregisterScheduling.unregister();

        ParticipantMipIndirectEntity firstParticipant =
            participantMipIndirectRepository.findByParticipantMipIspb(ISPB).orElseThrow();
        assertThat(firstParticipant.getStatus()).isNotEqualTo(waitingDeregistrationEvaluation);
        assertThat(participantMipIndirectHistoryRepository.findAllByParticipantMip(firstParticipant).size()).isEqualTo(2);
        ParticipantMipIndirectHistoryEntity topHistoryForFirstParticipant =
            indirectParticipantHistoryService
                .findTopByParticipantMipOrderByEventDateTimeDesc(firstParticipant);
        assertThat(topHistoryForFirstParticipant.getPreviousStatus()).isEqualTo(waitingDeregistrationEvaluation);
        assertThat(topHistoryForFirstParticipant.getType()).isEqualTo(ParticipantMipIndirectHistoryEntity.Type.CLEARING_RESCISSION_RESPONSE);
        assertThat(topHistoryForFirstParticipant.getParticipantMip().getName()).isEqualTo(FIRST_PARTICIPANT);

        ParticipantMipIndirectEntity secondParticipant =
            participantMipIndirectRepository.findByParticipantMipIspb(ANOTHER_ISPB).orElseThrow();
        assertThat(secondParticipant.getStatus()).isNotEqualTo(waitingDeregistrationEvaluation);
        assertThat(participantMipIndirectHistoryRepository.findAllByParticipantMip(secondParticipant).size()).isEqualTo(2);
        ParticipantMipIndirectHistoryEntity topHistoryForSecondParticipant =
            indirectParticipantHistoryService
                .findTopByParticipantMipOrderByEventDateTimeDesc(secondParticipant);
        assertThat(topHistoryForSecondParticipant.getPreviousStatus()).isEqualTo(waitingDeregistrationEvaluation);
        assertThat(topHistoryForSecondParticipant.getType()).isEqualTo(ParticipantMipIndirectHistoryEntity.Type.CLEARING_RESCISSION_RESPONSE);
        assertThat(topHistoryForSecondParticipant.getParticipantMip().getName()).isEqualTo(SECOND_PARTICIPANT);

        ParticipantMipIndirectEntity thirdParticipant =
            participantMipIndirectRepository.findByParticipantMipIspb(ISPB_NOT_EXPECTED).orElseThrow();
        assertThat(thirdParticipant.getStatus()).isEqualTo(active);
        List<ParticipantMipIndirectHistoryEntity> allHistoryForThirdParticipant =
            participantMipIndirectHistoryRepository.findAllByParticipantMip(thirdParticipant);
        assertThat(allHistoryForThirdParticipant.size()).isEqualTo(1);
        assertThat(thirdParticipantHistory).isEqualToIgnoringGivenFields(allHistoryForThirdParticipant.get(0), "participantMip");
    }

    @Test
    void shouldDoNothingToIndirectParticipantInStatusWaitingDeregistrationEvaluationBecauseItIsLessThantTwentyFourHours() {
        ParticipantMipIndirectStatusEntity waitingDeregistrationEvaluation =
            indirectParticipantStatusService.findById(WAITING_TO_SEND_DEREGISTRATION_TO_CLEARING.getId()).orElseThrow();

        ParticipantMipIndirectHistoryEntity historyForFirst =
            populateDatabaseWithBacenToBeApprovedDateTime(waitingDeregistrationEvaluation, ISPB, FIRST_PARTICIPANT);
        ParticipantMipIndirectHistoryEntity historyForSecond =
            populateDatabaseWithBacenToBeApprovedDateTime(waitingDeregistrationEvaluation, ANOTHER_ISPB,
                SECOND_PARTICIPANT);

        indirectParticipantUnregisterScheduling.unregister();

        ParticipantMipIndirectEntity firstParticipant =
            participantMipIndirectRepository.findByParticipantMipIspb(ISPB).orElseThrow();
        assertThat(firstParticipant.getStatus()).isEqualTo(waitingDeregistrationEvaluation);
        List<ParticipantMipIndirectHistoryEntity> allHistoryForFirstParticipant =
            participantMipIndirectHistoryRepository.findAllByParticipantMip(firstParticipant);
        assertThat(allHistoryForFirstParticipant.size()).isEqualTo(1);
        assertThat(historyForFirst).isEqualToIgnoringGivenFields(allHistoryForFirstParticipant.get(0), "participantMip");

        ParticipantMipIndirectEntity secondParticipant =
            participantMipIndirectRepository.findByParticipantMipIspb(ANOTHER_ISPB).orElseThrow();
        assertThat(secondParticipant.getStatus()).isEqualTo(waitingDeregistrationEvaluation);
        List<ParticipantMipIndirectHistoryEntity> allHistoryForSecondParticipant =
            participantMipIndirectHistoryRepository.findAllByParticipantMip(secondParticipant);
        assertThat(allHistoryForSecondParticipant.size()).isEqualTo(1);
        assertThat(historyForSecond).isEqualToIgnoringGivenFields(allHistoryForSecondParticipant.get(0), "participantMip");
    }

    private ParticipantMipIndirectHistoryEntity populateDatabaseWithBacenAlreadyApprovedDateTime(ParticipantMipIndirectStatusEntity status, Integer ispb, String participantName) {
        ParticipantMipEntity participantMip = createParticipantMip(ispb);
        LocalDateTime bacenDateTime = LocalDateTime.now().minusMinutes(50);
        ParticipantMipIndirectEntity participantIndirect = createParticipantMipIndirect(participantMip, status, participantName, bacenDateTime);
        return createParticipantMipIndirectHistoryEntity(participantIndirect);
    }

    private ParticipantMipIndirectHistoryEntity populateDatabaseWithBacenToBeApprovedDateTime(ParticipantMipIndirectStatusEntity status, Integer ispb, String participantName) {
        ParticipantMipEntity participantMip = createParticipantMip(ispb);
        LocalDateTime bacenDateTime = LocalDateTime.now().plusMinutes(50);
        ParticipantMipIndirectEntity participantIndirect = createParticipantMipIndirect(participantMip, status, participantName, bacenDateTime);
        return createParticipantMipIndirectHistoryEntity(participantIndirect);
    }

    @NotNull
    private ParticipantMipIndirectHistoryEntity createParticipantMipIndirectHistoryEntity(ParticipantMipIndirectEntity participantMipIndirect) {
        ParticipantMipIndirectHistoryEntity participantMipIndirectHistory = new ParticipantMipIndirectHistoryEntity();

        participantMipIndirectHistory.setType(ParticipantMipIndirectHistoryEntity.Type.LOCAL_UPDATE);
        participantMipIndirectHistory.setParticipantMip(participantMipIndirect);
        participantMipIndirectHistory.setPreviousStatus(indirectParticipantStatusService.findById(ACTIVE.getId()).get());
        participantMipIndirectHistory.setEventDateTime(LocalDateTime.now());

        return participantMipIndirectHistoryRepository.saveAndFlush(participantMipIndirectHistory);
    }

    private ParticipantMipEntity createParticipantMip(Integer ispb) {
        ParticipantMipEntity participantMip = new ParticipantMipEntity();
        participantMip.setIspb(ispb);
        participantMip.setBranch(123);
        participantMip.setAccountNumber(BigDecimal.valueOf(444555));
        participantMip.setDebTransactionType(12);
        participantMip.setCredTransactionType(344);
        participantMip.setDepositTransactionType(4789);
        participantMip.setWithdrawTransactionType(1147);
        participantMip.setDrawbackSentTransactType(11);
        participantMip.setDrawbackReceiveTransactType(77);
        participantMip.setBalanceValidationThreshold(true);
        participantMip.setBalanceLowerThreshold(BigDecimal.valueOf(1002430.57));
        participantMip.setBalanceLowerThresholdPerc(10);
        participantMip.setDirectParticipant(false);
        participantMip.setQrcodeCredTransactionType(9875);

        return participantMip;
    }

    private ParticipantMipIndirectEntity createParticipantMipIndirect(ParticipantMipEntity participantMip, ParticipantMipIndirectStatusEntity status, String name, LocalDateTime localDateTime) {
        ParticipantMipIndirectEntity participantMipIndirect = new ParticipantMipIndirectEntity();

        participantMipIndirect.setParticipantMip(participantMip);
        participantMipIndirect.setName(name);
        participantMipIndirect.setCorporateName("Indirect");
        participantMipIndirect.setTaxId(new BigDecimal("123"));
        participantMipIndirect.setStatus(status);
        participantMipIndirect.setContractInitDate(LocalDate.of(2020, 8, 13));
        participantMipIndirect.setContractEndDate(LocalDate.of(2020, 8, 20));
        participantMipIndirect.setCurrentStatusExpireTimestamp(localDateTime);

        return participantMipIndirectRepository.saveAndFlush(participantMipIndirect);
    }
}
