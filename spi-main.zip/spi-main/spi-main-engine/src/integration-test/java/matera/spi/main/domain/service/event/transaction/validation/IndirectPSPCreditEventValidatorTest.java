package matera.spi.main.domain.service.event.transaction.validation;

import matera.spi.commons.AbstractIntegrationTest;
import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.domain.model.account.PayerAccountEntity;
import matera.spi.main.domain.model.account.ReceiverAccountEntity;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.transaction.PaymentEventEntity;
import matera.spi.main.domain.model.event.transaction.ReceiptEventEntity;
import matera.spi.main.domain.model.event.transaction.ReturnReceivedEventEntity;
import matera.spi.main.domain.model.transaction.ReceiptEntity;
import matera.spi.main.domain.model.transaction.ReturnReceivedEntity;
import matera.spi.main.domain.model.transaction.TransactionEntity;
import matera.spi.main.domain.model.transaction.TransactionPriorityEntity;
import matera.spi.main.exception.CreditIndirectValidatorException;
import matera.spi.main.exception.EventValidatorException;
import matera.spi.main.utils.WireMockUtils;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import lombok.SneakyThrows;
import org.assertj.core.api.Assertions;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import static matera.spi.main.domain.model.event.EventType.PAYMENT;
import static matera.spi.main.domain.model.event.EventType.RETURN_RECEIVER;
import static matera.spi.main.utils.EntityCreationUtils.CORRELATION_ID;
import static matera.spi.main.utils.EntityCreationUtils.buildEventEntity;
import static matera.spi.main.utils.InstantPaymentCreationUtils.ADDITIONAL_INFORMATION;
import static matera.spi.main.utils.InstantPaymentCreationUtils.EXTERNAL_ACCOUNT;
import static matera.spi.main.utils.InstantPaymentCreationUtils.EXTERNAL_BRANCH;
import static matera.spi.main.utils.InstantPaymentCreationUtils.EXTERNAL_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.EXTERNAL_TAX_ID;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ACCOUNT;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_BRANCH;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_TAX_ID;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PAYER_NAME;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.exactly;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.resetAllRequests;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;

@ActiveProfiles("indirects")
class IndirectPSPCreditEventValidatorTest extends AbstractIntegrationTest {

    private static final String V_1_CREDITS = "/v1/credits";
    private static final String TRANSACTION_ID = "123456789";
    private static final int DELAY_TIME_MILLISECONDS = 2000;
    private static final String SERVICE_UNAVAILABLE_MSG = "503 - Service Unavailable";

    private static final WireMockServer wireMockServer = WireMockUtils.start();
    private static final String ORIGINAL_EVENT_CORRELATION_ID = "E0000000012345679876543212345";
    private static final BigDecimal ORIGINAL_EVENT_VALUE = BigDecimal.valueOf(100.12);
    private static final String RETURN_REASON_INFORMATION = "Return reason info";
    private static final String RETURN_REASON_INFORMATION_CODE = "AM09";
    private static final String RECONCILIATION_IDENTIFIER = "Reconciliation identifier";

    @Autowired
    private IndirectPSPCreditEventValidator indirectPSPCreditEventValidator;

    @AfterAll
    static void afterAll() {
        wireMockServer.stop();
    }

    @BeforeEach
    void beforeEach() {
        resetAllRequests();
    }

    @Test
    void shouldValidateCreditIndirectValidatorWithoutStub() throws CreditIndirectValidatorException, EventValidatorException {

        ReceiptEntity receiptEntity = createReceiptEntity();

        indirectPSPCreditEventValidator.validateCredit(receiptEntity);

        verify(exactly(1), postRequestedFor(urlEqualTo(V_1_CREDITS)));

    }

    @Test
    @SneakyThrows
    void shouldValidateCreditIndirectValidatorOk() {

        stubFor(post(V_1_CREDITS)
            .willReturn(aResponse()
                .withStatus(HttpStatus.ACCEPTED.value())
                .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .withBody("{ \"data\": {\"transactionId\":\"" + TRANSACTION_ID + "\"} }")
            ));

        ReceiptEntity receiptEntity = createReceiptEntity();
        indirectPSPCreditEventValidator.validateCredit(receiptEntity);

        EventEntity receiptEventEntity = receiptEntity.getEvent();
        String expectedJson =
            "{  " +
            "  'creditType': 'RECEIPT', " +
            "  'eventId': '" + receiptEventEntity.getId() + "', " +
            "  'endToEndId': '" + CORRELATION_ID + "', " +
            "  'value': 1, " +
            "  'debtor': { " +
            "    'taxId': '" + EXTERNAL_TAX_ID + "'," +
            "    'participantISPB': " + EXTERNAL_ISPB +"," +
            "    'account': {" +
            "      'branch': '" + EXTERNAL_BRANCH + "',"+
            "      'accountNumber': '" + EXTERNAL_ACCOUNT + "', " +
            "      'accountType': 'SLRY' " +
            "    }  " +
            "  }," +
            "  'credtor': {" +
            "    'taxId': '" + PARTICIPANT_TAX_ID + "'," +
            "    'participantISPB': " + PARTICIPANT_ISPB +"," +
            "    'account': {" +
            "      'branch': '" + PARTICIPANT_BRANCH + "'," +
            "      'accountNumber': '" + PARTICIPANT_ACCOUNT + "'," +
            "      'accountType': 'CACC'" +
            "    } " +
            "  }," +
            "  'additionalInformation': '" + ADDITIONAL_INFORMATION + "'" +
            "}";

        verify(exactly(1),
            postRequestedFor(urlEqualTo(V_1_CREDITS))
            .withRequestBody(WireMock.equalToJson(expectedJson))
        );
    }

    @Test
    @SneakyThrows
    void shouldValidateCreditIndirectValidatorOfAReturn() {

        stubFor(post(V_1_CREDITS)
            .willReturn(aResponse()
                .withStatus(HttpStatus.ACCEPTED.value())
                .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .withBody("{ \"data\": {\"transactionId\":\"" + TRANSACTION_ID + "\"} }")
            ));

        ReturnReceivedEntity returnReceivedEntity = createReturnReceivedEntity();
        indirectPSPCreditEventValidator.validateCredit(returnReceivedEntity);

        EventEntity returnEventEntity = returnReceivedEntity.getEvent();
        String expectedJson =
            "{  " +
            "  'creditType': 'RETURN', " +
            "  'eventId': '" + returnEventEntity.getId() + "', " +
            "  'endToEndId': '" + CORRELATION_ID + "', " +
            "  'receiverReconciliationIdentifier': '" + RECONCILIATION_IDENTIFIER + "'," +
            "  'value': 1, " +
            "  'debtor': { " +
            "    'taxId': '" + EXTERNAL_TAX_ID + "'," +
            "    'participantISPB': " + EXTERNAL_ISPB + "," +
            "    'account': {" +
            "      'branch': '" + EXTERNAL_BRANCH + "'," +
            "      'accountNumber': '" + EXTERNAL_ACCOUNT + "', " +
            "      'accountType': 'SLRY' " +
            "    }  " +
            "  }," +
            "  'credtor': {" +
            "    'taxId': '" + PARTICIPANT_TAX_ID + "'," +
            "    'participantISPB': " + PARTICIPANT_ISPB + "," +
            "    'account': {" +
            "      'branch': '" + PARTICIPANT_BRANCH + "'," +
            "      'accountNumber': '" + PARTICIPANT_ACCOUNT + "'," +
            "      'accountType': 'CACC'" +
            "    } " +
            "  }," +
            "  'additionalInformation': '" + ADDITIONAL_INFORMATION + "'," +
            "  'returnDetails': {" +
            "    'originalEndToEndId': '" + ORIGINAL_EVENT_CORRELATION_ID + "'," +
            "    'originalValue': " + ORIGINAL_EVENT_VALUE + "," +
            "    'returnReason': {" +
            "      'reasonCode': '" + RETURN_REASON_INFORMATION_CODE + "'," +
            "      'reasonDescription': 'Amount received is not the amount agreed or expected.'," +
            "      'additionalInformation': '" + RETURN_REASON_INFORMATION + "'" +
            "    }" +
            "  }" +
            "}";

        verify(exactly(1),
            postRequestedFor(urlEqualTo(V_1_CREDITS))
            .withRequestBody(WireMock.equalToJson(expectedJson))
        );
    }

    @Test
    void shouldValidateCreditIndirectDelayTimeout() throws CreditIndirectValidatorException, EventValidatorException {
        stubFor(post(V_1_CREDITS).willReturn(aResponse().withStatus(HttpStatus.ACCEPTED.value())
            .withFixedDelay(DELAY_TIME_MILLISECONDS)
            .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .withBody("{ \"data\": {\"transactionId\":\"" + TRANSACTION_ID + "\"} }")));

        ReceiptEntity receiptEntity = createReceiptEntity();

        indirectPSPCreditEventValidator.validateCredit(receiptEntity);

        verify(exactly(1), postRequestedFor(urlEqualTo(V_1_CREDITS)));
    }

    @Test
    void shouldValidateCreditIndirectInternalServerError(){

        stubFor(post(V_1_CREDITS)
            .willReturn(aResponse()
                .withStatus(HttpStatus.INTERNAL_SERVER_ERROR.value())));

        ReceiptEntity receiptEntity = createReceiptEntity();

        Assertions.assertThatThrownBy(()->{
            indirectPSPCreditEventValidator.validateCredit(receiptEntity);
        }).isInstanceOf(CreditIndirectValidatorException.class);

        verify(exactly(1), postRequestedFor(urlEqualTo(V_1_CREDITS)));
    }

    @Test
    void shouldValidateCreditIndirectRejectionInvalidRequestError(){
        stubFor(post(V_1_CREDITS)
            .willReturn(aResponse()
                .withHeader("Content-Type","application/json")
                .withBody("{" +
                          "  \"invalidRequestError\": {" +
                          "    \"message\": \"credtor.account cannot be null\"" +
                          "  }" +
                          "}")
                .withStatus(HttpStatus.BAD_REQUEST.value())));
        ReceiptEntity receiptEntity = createReceiptEntity();
        Assertions.assertThatThrownBy(()->{
            indirectPSPCreditEventValidator.validateCredit(receiptEntity);
        }).isInstanceOf(EventValidatorException.class);
        verify(exactly(1), postRequestedFor(urlEqualTo(V_1_CREDITS)));
    }

    @Test
    void shouldValidateCreditIndirectRejectionReasonAC07(){
        stubFor(post(V_1_CREDITS)
            .willReturn(aResponse()
                .withHeader("Content-Type","application/json")
                .withBody("{" +
                          "  \"rejectionReason\": {" +
                          "    \"rejectionReasonCode\": \"AC07\"" +
                          "  }" +
                          "}")
                .withStatus(HttpStatus.BAD_REQUEST.value())));
        ReceiptEntity receiptEntity = createReceiptEntity();
        Assertions.assertThatThrownBy(()->{
            indirectPSPCreditEventValidator.validateCredit(receiptEntity);
        }).isInstanceOf(EventValidatorException.class);

        verify(exactly(1), postRequestedFor(urlEqualTo(V_1_CREDITS)));
    }

    @Test
    void shouldValidateCreditIndirectBadRequestNoContentBody(){

        stubFor(post(V_1_CREDITS)
            .willReturn(aResponse()
                .withStatus(HttpStatus.BAD_REQUEST.value())));

        ReceiptEntity receiptEntity = createReceiptEntity();

        Assertions.assertThatThrownBy(()->{
            indirectPSPCreditEventValidator.validateCredit(receiptEntity);
        }).isInstanceOf(CreditIndirectValidatorException.class);

        verify(exactly(1), postRequestedFor(urlEqualTo(V_1_CREDITS)));
    }

    @Test
    void shouldValidateCreditIndirectServiceUnavailable(){

        stubFor(post(V_1_CREDITS)
            .willReturn(aResponse()
                .withStatus(HttpStatus.SERVICE_UNAVAILABLE.value())));

        ReceiptEntity receiptEntity = createReceiptEntity();

        Assertions.assertThatThrownBy(()->{
            indirectPSPCreditEventValidator.validateCredit(receiptEntity);
        }).isInstanceOf(CreditIndirectValidatorException.class)
            .hasMessageContaining(SERVICE_UNAVAILABLE_MSG);

        verify(exactly(1), postRequestedFor(urlEqualTo(V_1_CREDITS)));
    }

    @NotNull
    private ReceiptEntity createReceiptEntity() {
        ReceiptEntity receiptEntity = new ReceiptEntity();

        ReceiptEventEntity eventEntity = (ReceiptEventEntity) buildEventEntity(2);
        receiptEntity.setEvent(eventEntity);

        populateTransaction(receiptEntity);

        return receiptEntity;
    }

    private ReturnReceivedEntity createReturnReceivedEntity() {
        ReturnReceivedEntity returnReceivedEntity = new ReturnReceivedEntity();

        ReturnReceivedEventEntity returnReceivedEventEntity = (ReturnReceivedEventEntity) buildEventEntity(RETURN_RECEIVER.getCode());
        returnReceivedEntity.setEvent(returnReceivedEventEntity);
        returnReceivedEntity.setUnstructured(RETURN_REASON_INFORMATION);
        returnReceivedEntity.setReturnReasonInformationCode(RETURN_REASON_INFORMATION_CODE);
        returnReceivedEntity.setReceiverReconIdentifier(RECONCILIATION_IDENTIFIER);
        populateTransaction(returnReceivedEntity);

        PaymentEventEntity originalEvent = (PaymentEventEntity) buildEventEntity(PAYMENT.getCode());
        originalEvent.setCorrelationId(ORIGINAL_EVENT_CORRELATION_ID);
        originalEvent.setValue(ORIGINAL_EVENT_VALUE);
        returnReceivedEventEntity.setOriginalEvent(originalEvent);
        returnReceivedEventEntity.setOriginalCorrelationId(ORIGINAL_EVENT_CORRELATION_ID);

        return returnReceivedEntity;
    }

    private void populateTransaction(TransactionEntity transactionEntity) {
        ParticipantEntity payerParticipant = new ParticipantEntity();
        payerParticipant.setIspb(EXTERNAL_ISPB);
        transactionEntity.setPayerParticipant(payerParticipant);

        ParticipantEntity receiverParticipant = new ParticipantEntity();
        receiverParticipant.setIspb(PARTICIPANT_ISPB);
        transactionEntity.setReceiverParticipant(receiverParticipant);

        transactionEntity.setCustomerInitTimestampUtc(LocalDateTime.now());
        transactionEntity.setEndToEndId(CORRELATION_ID);
        TransactionPriorityEntity priority = new TransactionPriorityEntity();
        priority.setCode("HIGH");
        transactionEntity.setPriority(priority);

        transactionEntity.setPayerAccount(new PayerAccountEntity());
        transactionEntity.getPayerAccount().setAccount(EXTERNAL_ACCOUNT);
        transactionEntity.getPayerAccount().setAccountType("SLRY");
        transactionEntity.getPayerAccount().setBranch(EXTERNAL_BRANCH);
        transactionEntity.getPayerAccount().setTaxId(EXTERNAL_TAX_ID);
        transactionEntity.getPayerAccount().setName(PAYER_NAME);

        transactionEntity.setReceiverAccount(new ReceiverAccountEntity());
        transactionEntity.getReceiverAccount().setAccount(PARTICIPANT_ACCOUNT);
        transactionEntity.getReceiverAccount().setAccountType("CACC");
        transactionEntity.getReceiverAccount().setBranch(PARTICIPANT_BRANCH);
        transactionEntity.getReceiverAccount().setTaxId(PARTICIPANT_TAX_ID);
        transactionEntity.setAdditionalInformation(ADDITIONAL_INFORMATION);
    }

}
