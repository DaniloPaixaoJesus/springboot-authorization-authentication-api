package matera.spi.main.utils;

import org.assertj.core.api.SoftAssertions;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;

public class CustomAssertions {

    private static final int TOLERATED_DIFFERENCE_IN_SECONDS = 30;

    private CustomAssertions() {/*utility classes should not be instantiated*/}

	public static void assertThatIsCloseToNow(LocalDateTime time) {
		assertThat(time).isCloseToUtcNow(within(TOLERATED_DIFFERENCE_IN_SECONDS, ChronoUnit.SECONDS));
	}

	public static void assertThatIsCloseToNow(SoftAssertions softly, LocalDateTime time) {
        softly.assertThat(time).isCloseToUtcNow(within(TOLERATED_DIFFERENCE_IN_SECONDS, ChronoUnit.SECONDS));
	}
}
