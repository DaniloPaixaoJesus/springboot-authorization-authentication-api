package matera.spi.main.utils.verifier.expected.dto;

import matera.spi.dto.AccountTypeUIDTO;
import matera.spi.dto.InstantPaymentsUIDTO;
import matera.spi.dto.PayerUIDTO;
import matera.spi.dto.PaymentsUIDTO;
import matera.spi.dto.ReceiverUIDTO;
import matera.spi.dto.RemoteAccountUIDTO;
import matera.spi.dto.ReturnSettlementUIWapperDTO;
import matera.spi.main.domain.model.account.Account;
import matera.spi.main.domain.model.event.transaction.TransactionEventEntity;
import matera.spi.main.domain.model.transaction.TransactionType;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class ExpectedTransactionDTO {
	TransactionType type;
	LocalDateTime customerInitTimestamp;
	ReceiverUIDTO receiver;
	String chargeBearer;
	PayerUIDTO payer;
	Long initiatingInstitutionTaxId;
	String endToEndId;
	String receiverReconIdentifier;
	String additionalInformation;
	String priorityCode;
	String settlementMethod;
    String returnReasonInformationCode;
    String unstructured;

	public static ExpectedTransactionDTO paymentFromInstantPaymentsUIDTO(InstantPaymentsUIDTO instantPaymentsUIDTO) {
		return ExpectedTransactionDTO.fromInstantPaymentsUIDTO(instantPaymentsUIDTO, 0)
				.type(TransactionType.PAYMENT)
				.build();
	}

	public static ExpectedTransactionDTO receiptFromInstantPaymentsUIDTO(InstantPaymentsUIDTO instantPaymentsUIDTO, int paymentIndex) {
		return ExpectedTransactionDTO.fromInstantPaymentsUIDTO(instantPaymentsUIDTO, paymentIndex)
				.type(TransactionType.RECEIPT)
				.build();
	}

	public static ExpectedTransactionDTOBuilder fromInstantPaymentsUIDTO(InstantPaymentsUIDTO instantPaymentsUIDTO, int paymentIndex) {
		PaymentsUIDTO paymentUIDTO = instantPaymentsUIDTO.getPayments().get(paymentIndex);
		return builder()
				.customerInitTimestamp(paymentUIDTO.getAcceptanceDateTime())
				.receiver(paymentUIDTO.getReceiver())
				.chargeBearer(paymentUIDTO.getChargeBearer())
				.payer(paymentUIDTO.getPayer())
				.initiatingInstitutionTaxId(paymentUIDTO.getOrganisationIdentification())
				.endToEndId(paymentUIDTO.getEndToEndID())
				.receiverReconIdentifier(paymentUIDTO.getTransactionIdentification())
				.additionalInformation(paymentUIDTO.getUnstructured())
				.priorityCode(instantPaymentsUIDTO.getInstructionPriority())
				.settlementMethod(instantPaymentsUIDTO.getSettlementMethod());
	}

    private static ExpectedTransactionDTOBuilder fromReturnSentEventSpecificationDTO(ReturnSettlementUIWapperDTO returnSettlementUIWapperDTO, TransactionEventEntity originalEvent) {
	    return builder()
            .customerInitTimestamp(returnSettlementUIWapperDTO.getCreationDateTime())
            .receiver(getReceiverFromReturn(originalEvent)) //should be inverted
            .payer(getPayerFromReturn(originalEvent)) //should be inverted
            .chargeBearer(returnSettlementUIWapperDTO.getChargeBearer())
            .returnReasonInformationCode(returnSettlementUIWapperDTO.getReturnReasonInformation().name())
            .endToEndId(returnSettlementUIWapperDTO.getReturnEndToEndIdentification())
            .additionalInformation(returnSettlementUIWapperDTO.getAdditionalInformation())
            .unstructured(returnSettlementUIWapperDTO.getUnstructured())
            .settlementMethod(returnSettlementUIWapperDTO.getSettlementMethod())
            .priorityCode(returnSettlementUIWapperDTO.getSettlementPriority());
    }

    private static ReceiverUIDTO getReceiverFromReturn(TransactionEventEntity originalEvent) {
        //should be inverted
        Account payerAccount = originalEvent.getPayerAccount();
        return new ReceiverUIDTO()
            .account(new RemoteAccountUIDTO()
                .branch(payerAccount.getBranch())
                .accountNumber(payerAccount.getAccount())
                .accountType(AccountTypeUIDTO.fromValue(payerAccount.getAccountType()))
            )
            .taxId(payerAccount.getTaxId())
            .institutionISPB(originalEvent.getPayerIspb());
    }

    private static PayerUIDTO getPayerFromReturn(TransactionEventEntity originalEvent) {
        //should be inverted
        Account receiverAccount = originalEvent.getReceiverAccount();
        return new PayerUIDTO()
            .account(new RemoteAccountUIDTO()
                .branch(receiverAccount.getBranch())
                .accountNumber(receiverAccount.getAccount())
                .accountType(AccountTypeUIDTO.fromValue(receiverAccount.getAccountType()))
            )
            .taxId(receiverAccount.getTaxId())
            .institutionISPB(originalEvent.getReceiverIspb());
    }

    public static ExpectedTransactionDTO returnSentFromEventSpecificationDTO(ReturnSettlementUIWapperDTO returnSettlementUIWapperDTO, TransactionEventEntity originalEvent) {
        return fromReturnSentEventSpecificationDTO(returnSettlementUIWapperDTO, originalEvent)
            .type(TransactionType.RETURN_SENT)
            .build();
	}

    public static ExpectedTransactionDTO returnReceivedFromEventSpecificationDTO(ReturnSettlementUIWapperDTO returnSettlementUIWapperDTO, TransactionEventEntity originalEvent) {
        return fromReturnSentEventSpecificationDTO(returnSettlementUIWapperDTO, originalEvent)
            .type(TransactionType.RETURN_RECEIVED)
            .build();
    }
}
