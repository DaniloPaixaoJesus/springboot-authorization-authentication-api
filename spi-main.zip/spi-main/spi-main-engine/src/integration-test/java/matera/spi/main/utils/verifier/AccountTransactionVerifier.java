package matera.spi.main.utils.verifier;

import com.matera.spi.thirdparties.customers.transactions.model.LancamentoResponseV2DTO;

import matera.spi.main.domain.model.IpAccountConfigEntity;
import matera.spi.main.domain.model.ParticipantMipEntity;
import matera.spi.main.domain.model.transaction.TransactionType;
import matera.spi.main.domain.service.IpAccountConfigurationService;
import matera.spi.main.domain.service.ParticipantMipService;
import matera.spi.main.dto.AccountTransactionRequestDTO;
import matera.spi.main.dto.AccountTransactionResponseDTO;
import matera.spi.main.dto.QueryBalanceRequestDTO;
import matera.spi.main.dto.QueryBalanceResponseDTO;
import matera.spi.main.dto.event.transaction.AccountTransactionReverterDTO;
import matera.spi.main.transactions.port.AccountTransactionExecutorPort;
import matera.spi.main.transactions.port.AccountTransactionReverterPort;

import org.mockito.stubbing.Answer;
import org.opentest4j.AssertionFailedError;

import java.math.BigDecimal;
import java.util.Random;

import static com.matera.spi.thirdparties.customers.transactions.model.LancamentoResponseV2DTO.ClassificacaoCategoriaContaSPIEnum.CACC;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class AccountTransactionVerifier {

    private static final Random RANDOM = new Random();
    private ParticipantMipService participantMipService;
    private IpAccountConfigurationService ipAccountConfigurationService;
    private AccountTransactionExecutorPort accountTransactionExecutorPort;
    private AccountTransactionReverterPort accountTransactionReverterPort;

    public AccountTransactionVerifier(ParticipantMipService participantMipService,
                                      IpAccountConfigurationService ipAccountConfigurationService,
                                      AccountTransactionExecutorPort accountTransactionExecutorPort,
                                      AccountTransactionReverterPort accountTransactionReverterPort) {
        this.participantMipService = participantMipService;
        this.ipAccountConfigurationService = ipAccountConfigurationService;
        this.accountTransactionExecutorPort = accountTransactionExecutorPort;
        this.accountTransactionReverterPort = accountTransactionReverterPort;
    }

    public void verifyRevert(int expectedReversions) {
        verify(accountTransactionReverterPort, times(expectedReversions))
            .revertDebit(any(AccountTransactionReverterDTO.class));
    }

    public void verifyTransaction(int expectedTransactions, TransactionType transactionType) {

        Integer ipAccountTransactionId = getTransactionTypeIdForIpAccount(transactionType);
        verify(accountTransactionExecutorPort, times(expectedTransactions))
            .makeTransaction(argThat(argument -> argument.getTransactionType().equals(ipAccountTransactionId)));

        Integer participantTransactionId = getTransactionTypeIdForParticipant(transactionType);
        verify(accountTransactionExecutorPort, times(expectedTransactions))
            .makeTransaction(argThat(argument -> argument.getTransactionType().equals(participantTransactionId)));

    }

    public Integer getTransactionTypeIdForIpAccount(TransactionType transactionType) {
        IpAccountConfigEntity config = ipAccountConfigurationService.findConfig()
            .orElseThrow(() -> new AssertionFailedError("not found ip account config"));

        switch (transactionType) {
            case PAYMENT:
                return config.getDebitTransactionType();
            case RECEIPT:
                return config.getCreditTransactionType();
            case RETURN_SENT:
                return config.getDrawbackSentTransactType();
            case RETURN_RECEIVED:
                return config.getDrawbackReceiveTransactType();
            default:
                return null;
        }
    }

    public Integer getTransactionTypeIdForParticipant(TransactionType transactionType) {
        ParticipantMipEntity config = participantMipService.findAllParticipantsMip().get(0);

        switch (transactionType) {
            case PAYMENT:
                return config.getDebTransactionType();
            case RECEIPT:
                return config.getCredTransactionType();
            case RETURN_SENT:
                return config.getDrawbackSentTransactType();
            case RETURN_RECEIVED:
                return config.getDrawbackReceiveTransactType();
            default:
                return null;
        }
    }

    public void mockTransactionExecutor() {
        when(accountTransactionExecutorPort.queryBalance(any(QueryBalanceRequestDTO.class))).thenAnswer(
            (Answer<QueryBalanceResponseDTO>) invocation -> QueryBalanceResponseDTO.builder()
                .balanceAvailable(BigDecimal.valueOf(RANDOM.nextLong())).build());

        LancamentoResponseV2DTO lancamentoResponseV2DTO = new LancamentoResponseV2DTO();

        lancamentoResponseV2DTO.setClassificacaoCategoriaContaSPI(CACC);
        lancamentoResponseV2DTO.setCpfCnpjTitular(BigDecimal.valueOf(92082843521L));


        when(accountTransactionExecutorPort.makeTransaction(any(AccountTransactionRequestDTO.class))).thenAnswer(
            (Answer<AccountTransactionResponseDTO>) invocation -> AccountTransactionResponseDTO.builder()
                .transactionId(BigDecimal.valueOf(RANDOM.nextLong()))
                .lancamentoResponseV2DTO(lancamentoResponseV2DTO)
                .build());
    }

}
