package matera.spi.indirect.flow;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.matera.spi.messaging.model.MessageSpecificationDTO;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import matera.spi.indirect.domain.model.ParticipantMipIndirectContactsEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectHistoryEntity;
import matera.spi.indirect.persistence.ParticipantMipIndirectContactsRepository;
import matera.spi.indirect.persistence.ParticipantMipIndirectHistoryRepository;
import matera.spi.indirect.persistence.ParticipantMipIndirectRepository;
import matera.spi.main.config.MainEngineConfiguration;
import matera.spi.main.domain.service.MessageIdGenerator;
import matera.spi.main.domain.service.event.receiver.MessageReceiver;
import matera.spi.main.dto.MessageReceiverDTO;
import matera.spi.main.utils.FileUtils;
import matera.spi.main.utils.WireMockUtils;
import org.apache.http.HttpStatus;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.core.io.ResourceLoader;
import org.testcontainers.shaded.com.fasterxml.jackson.databind.ObjectMapper;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import static matera.spi.main.utils.WireMockUtils.V_1_MESSAGES;

@Slf4j
public abstract class IndirectBaseStateFlowIT {

    protected static final String URN_INDIRECT_REGISTER = "/ui/v1/indirect";
    protected static final String URN_INDIRECT_GET_BY_ISPB = "/ui/v1/indirect/{ispb}";
    protected static final String URN_INDIRECT_SEND_REGISTRY_TO_CLEARING = "/ui/v1/indirect/registration/{ispb}";
    protected static final String URN_INDIRECT_SEND_RESCISSION_TO_CLEARING = "/ui/v1/indirect/rescission/{ispb}";
    protected static final String PATH_PARAMETER_ISPB = "ispb";

    protected static final String FILE_REDA014 = "classpath:examples/indirect/xml/reda014.xml";
    protected static final String FILE_REDA016_QUEUED = "classpath:examples/indirect/xml/reda016-queued.xml";
    protected static final String FILE_REDA016_REJECTED = "classpath:examples/indirect/xml/reda016-rejected.xml";
    protected static final String FILE_REDA016_SUCCESS = "classpath:examples/indirect/xml/reda016-success.xml";
    protected static final String FILE_REDA017 = "classpath:examples/indirect/xml/reda017.xml";
    protected static final String FILE_REDA031 = "classpath:examples/indirect/xml/reda031.xml";

    protected static final String FILE_JSON_INDIRECT_ACTIVE = "classpath:examples/indirect/json/ui-get-expected-active.json";
    protected static final String FILE_JSON_INDIRECT_REGISTER = "classpath:examples/indirect/json/ui-register.json";
    protected static final String FILE_JSON_INDIRECT_REJECTED = "classpath:examples/indirect/json/ui-get-expected-rejected-register.json";
    protected static final String FILE_JSON_INDIRECT_DEREGISTERED = "classpath:examples/indirect/json/ui-get-expected-deregistered.json";
    protected static final String FILE_JSON_INDIRECT_WAITING_TO_SEND_RESCISSION = "classpath:examples/indirect/json/ui-get-expected-waiting-to-send-rescission.json";
    protected static final String FILE_JSON_INDIRECT_WAITING_TO_SEND_REGISTRY = "classpath:examples/indirect/json/ui-get-expected-waiting-registry.json";
    protected static final String FILE_JSON_INDIRECT_WAITING_CLEARING_REGISTRY_RESPONSE = "classpath:examples/indirect/json/ui-get-expected-waiting-registry-clearing-response.json";

    protected static final String REDA016_REASON_CODE_IND2 = "IND2";
    protected static final String REDA016_REASON_CODE_IND3 = "IND3";
    protected static final String REDA016_REASON_CODE_ANOTHER = "IND4";

    protected static final String DIRECT_ISPB = "13370835";
    protected static final String INDIRECT_ISPB = "00558456";
    protected static final String INDIRECT_CNPJ = "00558456000171";

    protected static final String RESCISSION_BODY_CLEARING_RESPONSE = "{\"reason\":\"CLEARING_RESPONSE\"}";

    protected static final String MSG_ID_TAG = "MsgId";
    protected static final String BODY_REDA014_TAG = "Pty";
    protected static final String BODY_REDA031_TAG = "SysPtyId";

    protected static final String PLACEHOLDER_ORIGINAL_MSG_ID = "${original.msgId}";
    protected static final String PLACEHOLDER_MSG_ID = "${msgId}";
    protected static final String PLACEHOLDER_PRTRY = "${reasonCode}";
    protected static final String PLACEHOLDER_VAL = "${limitDate}";

    protected static final String MSG_TYPE_REDA016 = "REDA.016";
    protected static final String MSG_TYPE_REDA017 = "REDA.017";

    @LocalServerPort
    private int port;

    @Autowired
    protected ResourceLoader resourceLoader;

    @Autowired
    protected ParticipantMipIndirectRepository participantMipIndirectRepository;

    @Autowired
    protected ParticipantMipIndirectHistoryRepository participantMipIndirectHistoryRepository;

    @Autowired
    protected ParticipantMipIndirectContactsRepository participantMipIndirectContactsRepository;

    @Autowired
    protected MessageReceiver messageReceiver;

    @Autowired
    private MainEngineConfiguration mainEngineConfiguration;

    protected final ObjectMapper objectMapper = new ObjectMapper();

    private boolean sendEmailConfiguration;

    @BeforeEach
    public void baseBeforeEach() {
        RestAssured.port = port;
        sendEmailConfiguration = mainEngineConfiguration.isSendEmailActivated();
        mainEngineConfiguration.setSendEmailActivated(false);
    }

    @AfterEach
    public void baseAfterEach() {
        removeIndirectFromDatabase(INDIRECT_ISPB);
        WireMock.resetAllRequests();
        mainEngineConfiguration.setSendEmailActivated(sendEmailConfiguration);
    }

    protected void registryIndirectWithSuccess() {
        String registryJson = getFileAsString(FILE_JSON_INDIRECT_REGISTER);
        Response registryResponse = RestAssured
            .given()
            .body(registryJson)
            .contentType(ContentType.JSON)
            .post(URN_INDIRECT_REGISTER);
        Assertions.assertEquals(HttpStatus.SC_CREATED, registryResponse.statusCode());

        String getResponseJson = getParticipantByIspb(INDIRECT_ISPB);
        String expectedWaitingToSend = getFileAsString(FILE_JSON_INDIRECT_WAITING_TO_SEND_REGISTRY);
        Assertions.assertEquals(expectedWaitingToSend, getResponseJson);

        Response sendToClearingResponse = RestAssured
            .given()
            .pathParam(PATH_PARAMETER_ISPB, INDIRECT_ISPB)
            .post(URN_INDIRECT_SEND_REGISTRY_TO_CLEARING);
        Assertions.assertEquals(HttpStatus.SC_ACCEPTED, sendToClearingResponse.statusCode());

        getResponseJson = getParticipantByIspb(INDIRECT_ISPB);
        String expectedWaitingClearingResponse = getFileAsString(FILE_JSON_INDIRECT_WAITING_CLEARING_REGISTRY_RESPONSE);
        Assertions.assertEquals(expectedWaitingClearingResponse, getResponseJson);

        String messageSent = WireMockUtils
            .getFirstBodyFrom(WireMock.postRequestedFor(WireMock.urlEqualTo(V_1_MESSAGES)), MessageSpecificationDTO.class)
            .getMessageContent()
            .trim();
        String expectedSentToClearing = getFileAsString(FILE_REDA014);
        Assertions.assertEquals(extractValueFromXml(expectedSentToClearing, BODY_REDA014_TAG), extractValueFromXml(messageSent, BODY_REDA014_TAG));

        String reda016Success = customizeReda016(getFileAsString(FILE_REDA016_SUCCESS), extractValueFromXml(messageSent, MSG_ID_TAG));
        sendRedaToMessageReceiver(MSG_TYPE_REDA016, reda016Success);
        getResponseJson = getParticipantByIspb(INDIRECT_ISPB);
        String expectedActiveResponse = getFileAsString(FILE_JSON_INDIRECT_ACTIVE);
        Assertions.assertEquals(expectedActiveResponse, getResponseJson);
    }

    private void removeIndirectFromDatabase(String ispb) {
        ParticipantMipIndirectEntity indirectEntity = participantMipIndirectRepository
            .findByParticipantMipIspb(Integer.valueOf(ispb))
            .orElseThrow();

        List<ParticipantMipIndirectContactsEntity> participantMipIndirectContactsEntityList = participantMipIndirectContactsRepository
            .findAllByParticipantMip(indirectEntity);
        participantMipIndirectContactsRepository.deleteAll(participantMipIndirectContactsEntityList);

        List<ParticipantMipIndirectHistoryEntity> participantMipIndirectHistoryEntityList = participantMipIndirectHistoryRepository
            .findAllByParticipantMip(indirectEntity);
        participantMipIndirectHistoryRepository.deleteAll(participantMipIndirectHistoryEntityList);

        participantMipIndirectRepository.delete(indirectEntity);
    }

    protected String getParticipantByIspb(String participant) {
        return RestAssured
            .given()
            .pathParam("ispb", participant)
            .get(URN_INDIRECT_GET_BY_ISPB)
            .asString()
            .trim();
    }

    protected String getFileAsString(String file) {
        return FileUtils.resourceAsString(resourceLoader.getResource(file)).trim();
    }

    protected String customizeReda016(String xml, String originalMsgId) {
        return xml.replace(PLACEHOLDER_ORIGINAL_MSG_ID, originalMsgId)
            .replace(PLACEHOLDER_MSG_ID, MessageIdGenerator.generate(DIRECT_ISPB));
    }

    protected String customizeReda016(String xml, String originalMsgId, String reasonCode) {
        return xml.replace(PLACEHOLDER_ORIGINAL_MSG_ID, originalMsgId)
            .replace(PLACEHOLDER_MSG_ID, MessageIdGenerator.generate(DIRECT_ISPB))
            .replace(PLACEHOLDER_PRTRY, reasonCode);
    }

    protected String customizeReda017(String xml, LocalDateTime limitDate) {
        return xml.replace(PLACEHOLDER_MSG_ID, MessageIdGenerator.generate(DIRECT_ISPB))
            .replace(PLACEHOLDER_VAL, DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").format(limitDate));
    }

    protected String extractValueFromXml(String xml, String tag) {
        String opTag = String.format("<%s>", tag);
        String clTag = String.format("</%s>", tag);
        return xml.substring(xml.indexOf(opTag) + opTag.length(), xml.indexOf(clTag));
    }

    @SneakyThrows
    protected void sendRedaToMessageReceiver(String msgType, String xmlContent) {
        MessageReceiverDTO dto = new MessageReceiverDTO();
        dto.setMessageType(msgType);
        dto.setXml(xmlContent);
        dto.setPiResourceId(String.valueOf(System.currentTimeMillis()));
        messageReceiver.readIncomingMessage(objectMapper.writeValueAsString(dto));
    }

}
