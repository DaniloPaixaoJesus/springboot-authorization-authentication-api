package matera.spi.main.utils;

import matera.spi.dto.InstantPaymentsUIDTO;
import matera.spi.dto.PayerUIDTO;
import matera.spi.dto.PaymentsUIDTO;
import matera.spi.dto.ReceiverUIDTO;
import matera.spi.dto.ReturnSettlementUIWapperDTO;
import matera.spi.main.dto.MessageReceiverDTO;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.SneakyThrows;
import org.jetbrains.annotations.NotNull;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.List;

import static matera.spi.main.utils.InstantPaymentCreationUtils.BACEN_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.CLEARING_RESPONSE_TIMESTAMP_STR;
import static matera.spi.main.utils.InstantPaymentCreationUtils.EXTERNAL_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.LEFT_PADDED_BACEN_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.LEFT_PADDED_PARTICIPANT_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.getRandomPiResourceId;

public class MessageCreationUtils {

    private MessageCreationUtils() {/*utility classes should not be instantiated*/}

    public static final String RECEIPT_SUCCESS_STATUS = "ACCC";

    public static final String INTRA_MIP_RECEIPT_SUCCESS_STATUS = "ACSP";

    public static final String PAYMENT_SUCCESS_STATUS = "ACSC";

    public static final String INTRA_MIP_PAYMENT_SUCCESS_STATUS = "ACSP";

    public static final String PAYMENT_REJECTED_STATUS = "RJCT";

    public static final String RETURN_REJECTED_STATUS = "RJCT";
    public static final String RECEIPT_REJECTED_STATUS = "RJCT";

    public static final String INTRA_MIP_RETURN_SENT_SUCCESS_STATUS = "ACSP";

    public static final String RETURN_SENT_SUCCESS_STATUS = "ACSC";

    public static String buildPacs002Response(String transactionInformationAndStatus) {
        return buildPacs002Response(getRandomPiResourceId(), transactionInformationAndStatus, "1.4");
    }

    public static String buildPacs002Response(int ispbFrom,
                                              int ispbTo,
                                              String expectedPiResourceId,
                                              String transactionInformationAndStatus,
                                              String messageVersion) {
        String envelopeNamespace = "1.2".equals(messageVersion) ? "pacs.002.spi.1.2.xsd" :
            "https://www.bcb.gov.br/pi/pacs.002/" + messageVersion;
        // @formatter:off
        return "{\"piResourceId\": \"" + expectedPiResourceId +
               "\",\"xml\": \"" +
               "<?xml version=\\\"1.0\\\" encoding=\\\"UTF-8\\\" standalone=\\\"no\\\" ?>" +
               "<Envelope xmlns=\\\"" + envelopeNamespace + "\\\">" +
               "<AppHdr>" +
               "<Fr><FIId><FinInstnId><Othr><Id>"+ispbFrom+"</Id></Othr></FinInstnId></FIId></Fr>" +
               "<To><FIId><FinInstnId><Othr><Id>"+ispbTo+"</Id></Othr></FinInstnId></FIId></To>" +
               "<BizMsgIdr>M00285763d3ab749d3cca431ba2fc95f</BizMsgIdr>" +
               "<MsgDefIdr>pacs.002.spi." + messageVersion + "</MsgDefIdr>" +
               "<CreDt>" + CLEARING_RESPONSE_TIMESTAMP_STR + "</CreDt>" +
               "<Sgntr></Sgntr>" +
               "</AppHdr>" +
               "<Document>" +
               "<FIToFIPmtStsRpt>" +
               "<GrpHdr><MsgId>M00285763d3ab749d3cca431ba2fc95f</MsgId><CreDtTm>2020-04-01T14:52:04.666Z</CreDtTm></GrpHdr>" +
               transactionInformationAndStatus +
               "</FIToFIPmtStsRpt></Document></Envelope>\"}";
        // @formatter:on

    }

    public static String buildPacs002Response(String expectedPiResourceId,
                                              String transactionInformationAndStatus,
                                              String messageVersion) {
        String envelopeNamespace = "1.2".equals(messageVersion) ? "pacs.002.spi.1.2.xsd" :
            "https://www.bcb.gov.br/pi/pacs.002/" + messageVersion;
        // @formatter:off
        return "{\"piResourceId\": \"" + expectedPiResourceId +
               "\",\"xml\": \"" +
               "<?xml version=\\\"1.0\\\" encoding=\\\"UTF-8\\\" standalone=\\\"no\\\" ?>" +
               "<Envelope xmlns=\\\"" + envelopeNamespace + "\\\">" +
               "<AppHdr>" +
               "<Fr><FIId><FinInstnId><Othr><Id>00038166</Id></Othr></FinInstnId></FIId></Fr>" +
               "<To><FIId><FinInstnId><Othr><Id>13370835</Id></Othr></FinInstnId></FIId></To>" +
               "<BizMsgIdr>M00285763d3ab749d3cca431ba2fc95f</BizMsgIdr>" +
               "<MsgDefIdr>pacs.002.spi." + messageVersion + "</MsgDefIdr>" +
               "<CreDt>" + CLEARING_RESPONSE_TIMESTAMP_STR + "</CreDt>" +
               "<Sgntr></Sgntr>" +
               "</AppHdr>" +
               "<Document>" +
               "<FIToFIPmtStsRpt>" +
               "<GrpHdr><MsgId>M00285763d3ab749d3cca431ba2fc95f</MsgId><CreDtTm>2020-04-01T14:52:04.666Z</CreDtTm></GrpHdr>" +
               transactionInformationAndStatus +
               "</FIToFIPmtStsRpt></Document></Envelope>\"}";
        // @formatter:on

    }

    public static String buildTxInfAndSts(String endToEndId, String status) {
        // @formatter:off
        return "<TxInfAndSts>" +
               "<OrgnlInstrId>" + endToEndId + "</OrgnlInstrId>" +
               "<OrgnlEndToEndId>" + endToEndId + "</OrgnlEndToEndId>" +
               "<TxSts>" + status + "</TxSts>" +
               "<FctvIntrBkSttlmDt><DtTm>" + CLEARING_RESPONSE_TIMESTAMP_STR + "</DtTm></FctvIntrBkSttlmDt>" +
               "<OrgnlTxRef><IntrBkSttlmDt>2020-04-01</IntrBkSttlmDt></OrgnlTxRef>" +
               "</TxInfAndSts>";
        // @formatter:on
    }

    public static String buildReceivedPacs008(String piResourceId, InstantPaymentsUIDTO dto) {
        return buildReceivedPacs008(piResourceId, dto, "1.4");
    }

    public static String buildReceivedPacs008(String piResourceId, InstantPaymentsUIDTO dto, String messageVersion) {
        String envelopeNamespace = "1.2".equals(messageVersion) ? "pacs.008.spi.1.2.xsd" :
            "https://www.bcb.gov.br/pi/pacs.008/" + messageVersion;
        // @formatter:off
        return "{\"piResourceId\": \"" +
               piResourceId +
               "\",\"xml\": \"" +
               "<?xml version=\\\"1.0\\\" encoding=\\\"UTF-8\\\" standalone=\\\"no\\\"?>" +
               "<Envelope xmlns=\\\"" + envelopeNamespace + "\\\">" +
               "<AppHdr>" +
               "<Fr><FIId><FinInstnId><Othr><Id>00038166</Id></Othr></FinInstnId></FIId></Fr>" +
               "<To><FIId><FinInstnId><Othr><Id>13370835</Id></Othr></FinInstnId></FIId></To>" +
               "<BizMsgIdr>M005737687cd679d901c941d0aad880a</BizMsgIdr>" +
               "<MsgDefIdr>pacs.008.spi." + messageVersion + "</MsgDefIdr>" +
               "<CreDt>" + getLocalDateTimeString(dto.getCreationDateTime()) + "</CreDt>" +
               "<Sgntr></Sgntr>" +
               "</AppHdr>" +
               "<Document>" +
               "<FIToFICstmrCdtTrf>" +
               "<GrpHdr>" +
               "<MsgId>M005737687cd679d901c941d0aad880a</MsgId>" +
               "<CreDtTm>" + getLocalDateTimeString(dto.getCreationDateTime()) + "</CreDtTm>" +
               "<NbOfTxs>" + dto.getPayments().size() + "</NbOfTxs>" +
               "<SttlmInf><SttlmMtd>" + dto.getSettlementMethod() + "</SttlmMtd></SttlmInf>" +
               "<PmtTpInf><InstrPrty>" + dto.getInstructionPriority() + "</InstrPrty></PmtTpInf>" +
               "</GrpHdr>" +
               dto.getPayments().stream().map(MessageCreationUtils::buildCdtTrfTxInf).reduce("", String::concat) +
               "</FIToFICstmrCdtTrf>" +
               "</Document>" +
               "</Envelope>\"}";
        // @formatter:on
    }

    public static String buildCdtTrfTxInf(PaymentsUIDTO creditDTO) {
        PayerUIDTO payer = creditDTO.getPayer();
        ReceiverUIDTO receiver = creditDTO.getReceiver();

        String unstructured = creditDTO.getUnstructured() != null ?
            "<RmtInf><Ustrd>" + creditDTO.getUnstructured() + "</Ustrd></RmtInf>" :
            "";

        String addressingKey = receiver.getAddressingKey() != null ?
            "<Prxy><Id>" + receiver.getAddressingKey() + "</Id></Prxy>"
            : "";

        String transactionIdentification = creditDTO.getTransactionIdentification() != null ?
            "<TxId>" + creditDTO.getTransactionIdentification() + "</TxId>"
            : "";

        // @formatter:off
        return "<CdtTrfTxInf>" +
               "<PmtId>" +
               "<EndToEndId>" + creditDTO.getEndToEndID() + "</EndToEndId>" +
               transactionIdentification +
               "</PmtId>" +
               "<IntrBkSttlmAmt Ccy=\\\"BRL\\\">" + creditDTO.getInterbankSettlementAmount() + "</IntrBkSttlmAmt>" +
               "<AccptncDtTm>" + getLocalDateTimeString(creditDTO.getAcceptanceDateTime()) + "</AccptncDtTm>" +
               "<ChrgBr>" + creditDTO.getChargeBearer() + "</ChrgBr>" +
               "<InitgPty><Id><OrgId><Othr><Id>" + creditDTO.getOrganisationIdentification() + "</Id></Othr></OrgId></Id></InitgPty>" +
               "<Dbtr>" +
               "<Nm>" + payer.getName() + "</Nm>" +
               "<Id><PrvtId><Othr><Id>" + payer.getTaxId() + "</Id></Othr></PrvtId></Id>" +
               "</Dbtr>" +
               "<DbtrAcct>" +
               "<Id><Othr>" +
               "<Id>" + payer.getAccount().getAccountNumber() + "</Id>" +
               "<Issr>" + payer.getAccount().getBranch() + "</Issr>" +
               "</Othr></Id>" +
               "<Tp><Cd>" + payer.getAccount().getAccountType().name() + "</Cd></Tp>" +
               "</DbtrAcct>" +
               "<DbtrAgt><FinInstnId><ClrSysMmbId><MmbId>" + payer.getInstitutionISPB() + "</MmbId></ClrSysMmbId></FinInstnId></DbtrAgt>" +
               "<CdtrAgt><FinInstnId><ClrSysMmbId><MmbId>" + receiver.getInstitutionISPB() + "</MmbId></ClrSysMmbId></FinInstnId></CdtrAgt>" +
               "<Cdtr><Id><PrvtId><Othr><Id>" + receiver.getTaxId() + "</Id></Othr></PrvtId></Id></Cdtr>" +
               "<CdtrAcct>" +
               "<Id><Othr>" +
               "<Id>" + receiver.getAccount().getAccountNumber() + "</Id>" +
               "<Issr>" + receiver.getAccount().getBranch() + "</Issr>" +
               "</Othr></Id>" +
               "<Tp><Cd>" + receiver.getAccount().getAccountType().name() + "</Cd></Tp>" +
               addressingKey +
               "</CdtrAcct>" +
               unstructured +
               "</CdtTrfTxInf>";
        // @formatter:on
    }

    public static String buildReceivedCamt014(String correlationId, String camt014RptXMLTag, String messageVersion,
                                              String envelopeNamespace, LocalDateTime creationDateTime) {
        return "{" +
               "\"messageType\":\"CAMT.014\"," +
               "\"piResourceId\":\""+correlationId+"\"," +
               "\"xml\":\"" +
               "<?xml version=\\\"1.0\\\" encoding=\\\"UTF-8\\\" standalone=\\\"no\\\"?>" +
               "<Envelope xmlns=\\\"" + envelopeNamespace + "\\\">" +
               "<AppHdr>" +
               "<Fr><FIId><FinInstnId><Othr><Id>" + BACEN_ISPB + "</Id></Othr></FinInstnId></FIId></Fr>" +
               "<To><FIId><FinInstnId><Othr><Id>" + PARTICIPANT_ISPB + "</Id></Othr></FinInstnId></FIId></To>" +
               "<BizMsgIdr>"+correlationId+"</BizMsgIdr>" +
               "<MsgDefIdr>camt.014.spi." + messageVersion + "</MsgDefIdr>" +
               "<CreDt>2020-01-01T08:30:12.000Z</CreDt>" +
               "<Sgntr></Sgntr>" +
               "</AppHdr>" +
               "<Document>" +
               "<RtrMmb><MsgHdr>" +
               "<MsgId>"+correlationId+"</MsgId>" +
               "<CreDtTm>" + getLocalDateTimeString(creationDateTime) + "</CreDtTm>" +
               "</MsgHdr>" +
               "<RptOrErr>" +
               camt014RptXMLTag +
               "</RptOrErr>" +
               "</RtrMmb>" +
               "</Document>" +
               "</Envelope>\"" +
               "}";
    }

    public static String buildCamt014RptTag(String clrSysMmbId, String name,
                                 String type, String status){
        return "<Rpt>" +
                "<MmbId><ClrSysMmbId><MmbId>"+clrSysMmbId+"</MmbId></ClrSysMmbId>" +
                "</MmbId>" +
                "<MmbOrErr><Mmb>" +
                "<Nm>"+name+"</Nm>" +
                "<Tp><Cd>"+type+"</Cd></Tp>" +
                "<Sts><Cd>"+status+"</Cd></Sts>" +
                "</Mmb></MmbOrErr>" +
               "</Rpt>";
    }

    public static String buildReceivedPacs004(List<ReturnSettlementUIWapperDTO> returnDTOs,
                                              String piResourceId,
                                              String messageVersion) {
        // @formatter:off
        return "{\"piResourceId\": \"" + piResourceId + "\",\"xml\": \"" +
               "<?xml version=\\\"1.0\\\" encoding=\\\"UTF-8\\\" standalone=\\\"no\\\"?>" +
               "<Envelope xmlns=\\\"https://www.bcb.gov.br/pi/pacs.004/" + messageVersion + "\\\">" +
               "<AppHdr>" +
               "<Fr><FIId><FinInstnId><Othr><Id>" + BACEN_ISPB + "</Id></Othr></FinInstnId></FIId></Fr>" +
               "<To><FIId><FinInstnId><Othr><Id>" + PARTICIPANT_ISPB + "</Id></Othr></FinInstnId></FIId></To>" +
               "<BizMsgIdr>M005737687cd679d901c941d0aad880a</BizMsgIdr>" +
               "<MsgDefIdr>pacs.004.spi." + messageVersion + "</MsgDefIdr>" +
               "<CreDt>" + getLocalDateTimeString(returnDTOs.get(0).getCreationDateTime()) + "</CreDt>" +
               "<Sgntr></Sgntr>" +
               "</AppHdr>" +
               "<Document>" +
               "<PmtRtr>" +
               "<GrpHdr>" +
               "<MsgId>M133708351591360455550dQssefMvWu</MsgId>" +
               "<CreDtTm>" + getLocalDateTimeString(returnDTOs.get(0).getCreationDateTime()) + "</CreDtTm>" +
               "<NbOfTxs>1</NbOfTxs>" +
               "<SttlmInf><SttlmMtd>" + returnDTOs.get(0).getSettlementMethod() + "</SttlmMtd></SttlmInf>" +
               "</GrpHdr>"
               + returnDTOs.stream().map(MessageCreationUtils::buildReturnTxInf).reduce("", String::concat)
               + "</PmtRtr>" +
               "</Document>" + "</Envelope>" + "\"}";
        // @formatter:on
    }

    public static String buildReceivedAdmi004(String evtCd, String evtDesc, String messageVersion, LocalDateTime creationDateTime) {
        return "{" +
               "\"messageType\":\"ADMI.004\"," +
               "\"piResourceId\":\"MGJhNTRhNGYyMmUyNDA2ZTg4YmU5OWM=\"," +
               "\"xml\":\"" +
               "<?xml version=\\\"1.0\\\" encoding=\\\"UTF-8\\\" standalone=\\\"no\\\"?>" +
               "<Envelope xmlns=\\\"https://www.bcb.gov.br/pi/admi.004/1.0\\\">" +
               "<AppHdr>" +
               "<Fr><FIId><FinInstnId><Othr><Id>" + BACEN_ISPB + "</Id></Othr></FinInstnId></FIId></Fr>" +
               "<To><FIId><FinInstnId><Othr><Id>" + PARTICIPANT_ISPB + "</Id></Othr></FinInstnId></FIId></To>" +
               "<BizMsgIdr>M005737687cd679d901c941d0aad880a</BizMsgIdr>" +
               "<MsgDefIdr>admi.004.spi." + messageVersion + "</MsgDefIdr>" +
               "<CreDt>" + getLocalDateTimeString(creationDateTime) + "</CreDt>" +
               "<Sgntr></Sgntr>" +
               "</AppHdr>" +
               "<Document>" +
                   "<SysEvtNtfctn>" +
                   "<EvtInf>" +
                   "<EvtCd>"+evtCd+"</EvtCd>" +
                   "<EvtDesc>"+evtDesc+"</EvtDesc>" +
                   "</EvtInf>" +
                   "</SysEvtNtfctn>" +
               "</Document>" +
               "</Envelope>\"" +
               "}";
    }

    @NotNull
    private static String buildReturnTxInf(ReturnSettlementUIWapperDTO returnSettlementUIWapperDTO) {
        // @formatter:off
        return "<TxInf>" +
               "<RtrId>" + returnSettlementUIWapperDTO.getReturnEndToEndIdentification() + "</RtrId>" +
               "<OrgnlEndToEndId>" + returnSettlementUIWapperDTO.getOriginalEndToEndIdentification() + "</OrgnlEndToEndId>" +
               "<RtrdIntrBkSttlmAmt Ccy=\\\"BRL\\\">" + returnSettlementUIWapperDTO.getReturnedInterbankSettlementAmount() + "</RtrdIntrBkSttlmAmt>" +
               "<SttlmPrty>" + returnSettlementUIWapperDTO.getSettlementPriority() + "</SttlmPrty>" +
               "<ChrgBr>" + returnSettlementUIWapperDTO.getChargeBearer() + "</ChrgBr>" +
               "<RtrRsnInf>" +
               "<Rsn><Cd>" + returnSettlementUIWapperDTO.getReturnReasonInformation().name() + "</Cd></Rsn>" +
               "<AddtlInf>" + returnSettlementUIWapperDTO.getAdditionalInformation() + "</AddtlInf>" +
               "</RtrRsnInf>" +
               "<OrgnlTxRef>" +
               "<RmtInf><Ustrd>" + returnSettlementUIWapperDTO.getUnstructured() + "</Ustrd></RmtInf>" +
               "<DbtrAgt><FinInstnId><ClrSysMmbId><MmbId>" + EXTERNAL_ISPB + "</MmbId></ClrSysMmbId></FinInstnId></DbtrAgt>" +
               "<CdtrAgt><FinInstnId><ClrSysMmbId><MmbId>" + PARTICIPANT_ISPB + "</MmbId></ClrSysMmbId></FinInstnId></CdtrAgt>" +
               "</OrgnlTxRef>" +
               "</TxInf>";
        // @formatter:on
    }

    public static String buildReceivedReda041(String correlationId, String reda041XMLTag, String messageVersion,
                                              String envelopeNamespace, LocalDateTime creationDateTime) {
        return "{" +
               "\"messageType\":\"REDA.041\"," +
               "\"piResourceId\":\""+correlationId+"\"," +
               "\"xml\":\"" +
               "<?xml version=\\\"1.0\\\" encoding=\\\"UTF-8\\\" standalone=\\\"no\\\"?>" +
               "<Envelope xmlns=\\\"" + envelopeNamespace + "\\\">" +
               "<AppHdr>" +
               "<Fr><FIId><FinInstnId><Othr><Id>" + BACEN_ISPB + "</Id></Othr></FinInstnId></FIId></Fr>" +
               "<To><FIId><FinInstnId><Othr><Id>" + PARTICIPANT_ISPB + "</Id></Othr></FinInstnId></FIId></To>" +
               "<BizMsgIdr>"+correlationId+"</BizMsgIdr>" +
               "<MsgDefIdr>reda.041.spi." + messageVersion + "</MsgDefIdr>" +
               "<CreDt>" + getLocalDateTimeString(creationDateTime) + "</CreDt>" +
               "<Sgntr></Sgntr>" +
               "</AppHdr>" +
               "<Document>" +
               "<PtyActvtyAdvc><MsgHdr>" +
               "<MsgId>"+correlationId+"</MsgId>" +
               "<CreDtTm>" + getLocalDateTimeString(creationDateTime) + "</CreDtTm>" +
               "</MsgHdr>" +
               reda041XMLTag +
               "</PtyActvtyAdvc>" +
               "</Document>" +
               "</Envelope>\"" +
               "}";
    }

    public static String buildReda041PtyActvtyTag(String ispb, String oldName,
                                            String newName){
        return "<PtyActvty>" +
               "<Chng><PtyId><Id><Id><PrtryId><Id>" + ispb + "</Id><Issr>BCB</Issr></PrtryId></Id></Id></PtyId></Chng>" +
               "<Rcrd><Nm><Od><Nm>" + oldName + "</Nm></Od><New><Nm>" + newName + "</Nm></New></Nm></Rcrd>" +
               "</PtyActvty>";
    }

    public static String addAppHeader(String xml, String messageDef, String from, String to) {
        String appHeader = "<AppHdr>" +
                           "<Fr><FIId><FinInstnId><Othr><Id>"+from+"</Id></Othr></FinInstnId></FIId></Fr>" +
                           "<To><FIId><FinInstnId><Othr><Id>"+to+"</Id></Othr></FinInstnId></FIId></To>" +
                           "<BizMsgIdr>M005737687cd679d901c941d0aad880a</BizMsgIdr>" +
                           "<MsgDefIdr>" + messageDef + "</MsgDefIdr>" +
                           "<CreDt>" + getLocalDateTimeString(LocalDateTime.now()) + "</CreDt>" +
                           "<Sgntr></Sgntr>" + "</AppHdr>";

        return xml.replace("<Document>", appHeader + "<Document>");

    }

    public static String addAppHeader(String xml, String messageDef) {
        return addAppHeader(xml, messageDef, LEFT_PADDED_BACEN_ISPB, LEFT_PADDED_PARTICIPANT_ISPB);
    }

    public static String buildMessageReceiverJson(String xml) {
        return buildMessageReceiverJson(getRandomPiResourceId(), xml);
    }

    @SneakyThrows
    public static String buildMessageReceiverJson(String piResourceId, String xml) {
        MessageReceiverDTO messageReceiverDTO = MessageReceiverDTO.builder()
            .xml(xml)
            .piResourceId(piResourceId)
            .build();
        return new ObjectMapper().writeValueAsString(messageReceiverDTO);
    }

    public static String getLocalDateTimeString(LocalDateTime localDateTime) {
        return localDateTime.atZone(ZoneOffset.UTC).format(DateTimeFormatter.ISO_DATE_TIME);
    }

}
