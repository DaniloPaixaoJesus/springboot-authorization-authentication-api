package matera.spi.main.flow;

import com.matera.client.exception.BadRequestException;
import com.matera.client.exception.InternalServerErrorException;
import com.matera.commons.rest.dto.MateraRestReturnDTO;
import com.matera.spi.messaging.api.MessagesApi;
import com.matera.spi.messaging.api.SPIMessagingApis;
import com.matera.spi.messaging.model.MessageSpecificationDTO;
import com.matera.spi.thirdparties.customers.transactions.model.LancamentoResponseV2DTO;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.InstantPaymentsUIDTO;
import matera.spi.dto.ReturnSettlementUIWapperDTO;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventStatusTransitionEntity;
import matera.spi.main.domain.model.event.transaction.TransactionEventEntity;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.domain.model.transaction.TransactionEntity;
import matera.spi.main.domain.service.CorrelationIdGenerator;
import matera.spi.main.domain.service.MessageSender;
import matera.spi.main.domain.service.transaction.AccountTransaction;
import matera.spi.main.domain.service.transaction.AccountTransactionReverter;
import matera.spi.main.dto.AccountTransactionRequestDTO;
import matera.spi.main.dto.AccountTransactionResponseDTO;
import matera.spi.main.dto.event.transaction.AccountTransactionReverterDTO;
import matera.spi.main.dto.event.transaction.TransactionReverterDTO;
import matera.spi.main.persistence.MessageRepository;
import matera.spi.main.transactions.port.AccountTransactionExecutorPort;
import matera.spi.main.transactions.port.AccountTransactionReverterPort;
import matera.spi.main.utils.InstantPaymentCreationUtils;
import matera.spi.main.utils.TransactionEntitiesService;

import io.restassured.RestAssured;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.RandomStringUtils;
import org.assertj.core.api.Condition;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.test.annotation.Commit;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static matera.spi.main.utils.InstantPaymentCreationUtils.ADDITIONAL_INFORMATION;
import static matera.spi.main.utils.InstantPaymentCreationUtils.CHARGE_BEARER_SLEV;
import static matera.spi.main.utils.InstantPaymentCreationUtils.INSTRUCTION_PRIORITY_HIGH;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.SETTLEMENT_METHOD_CLRG;
import static matera.spi.main.utils.InstantPaymentCreationUtils.createInstantPaymentsUIDTOMock;
import static matera.spi.main.utils.InstantPaymentCreationUtils.createMessageSentResponseDTO;
import static matera.spi.main.utils.InstantPaymentCreationUtils.getRandomPiResourceId;
import static matera.spi.main.utils.MessageCreationUtils.buildPacs002Response;
import static matera.spi.main.utils.MessageCreationUtils.buildReceivedPacs008;
import static matera.spi.main.utils.MessageCreationUtils.buildTxInfAndSts;

import static com.matera.spi.thirdparties.customers.transactions.model.LancamentoResponseV2DTO.ClassificacaoCategoriaContaSPIEnum.CACC;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

@Slf4j
@IntegrationTest
@Transactional
@Commit
@Disabled
class ReturnSentErrorFlowIT {

    private static final String RECEIPT_SUCCESS_STATUS = "ACCC";
    private static final String EXPECTED_ERROR_STATUS = "Error";
    private static final String CLEARING_ACCOUNT_DEBIT_ERROR = "Clearing Account Debit Error";
    private static final BigDecimal TRANSACTION_ID_MOCK = BigDecimal.valueOf(new Random().nextLong());
    private static final String RETURN_ENDPOINT = "/ui/v1/settlement/return";
    private static final String INCOMING_MESSAGE_ENDPOINT = "/test/incoming-message";
    private static final String CUSTOMER_DEBIT_INTERNAL_ERROR = "Customer Debit Internal Error";
    private static final String RETURN_REJECTED = "Return rejected";
    private static final String RETURN_INITIATED = "Return initiated";
    private static final String CUSTOMER_DEBIT_ERROR = "Customer Debit Error";

    @Autowired
    private MessageSender messageSender;
    @Autowired
    private SPIMessagingApis spiMessagingApisBean;
    @Mock
    private SPIMessagingApis mockedSpiMessagingApis;
    @Mock
    private MessagesApi mockedMessagesApi;

    @Autowired
    private AccountTransaction accountTransaction;
    @Autowired
    private AccountTransactionExecutorPort accountTransactionExecutorPort;
    @Mock
    private AccountTransactionExecutorPort mockedAccountTransactionExecutorPort;

    @Autowired
    private AccountTransactionReverter accountTransactionReverter;
    @Autowired
    private AccountTransactionReverterPort accountTransactionReverterPort;
    @Mock
    private AccountTransactionReverterPort mockedAccountTransactionReverterPort;
    @Autowired
    private TransactionEntitiesService transactionEntitiesService;
    @Autowired
    private MessageRepository messageRepository;
    @LocalServerPort
    private int port;

    private String originalEndToEndId;

    private static final Predicate<MessageEntity> CHECK_MESSAGE_IS_PACS_004_PREDICATE =
        (message) -> "pacs.004".equalsIgnoreCase(message.getMessageTypeEntity().getCode());
    private static final Condition<MessageEntity> IS_PACS004_CONDITION =
        new Condition<>(CHECK_MESSAGE_IS_PACS_004_PREDICATE, "Should not have any pacs.004 message");

    @BeforeEach
    void setUp() {
        RestAssured.port = port;
        log.info("Test");
        when(mockedAccountTransactionExecutorPort.makeTransaction(any(AccountTransactionRequestDTO.class)))
            .thenReturn(buildTransactionResponseMock())  // Customer for the receipt
            .thenReturn(buildTransactionResponseMock())  // Managerial for the receipt
            .thenReturn(buildTransactionResponseMock()); // Mirror for the receipt
        originalEndToEndId = receiveAReceipt();
        reset(mockedAccountTransactionExecutorPort);
        when(mockedSpiMessagingApis.messagesApi()).thenReturn(mockedMessagesApi);
        messageSender.setSpiMessagingApis(mockedSpiMessagingApis);
        accountTransaction.setAccountTransactionExecutorPort(mockedAccountTransactionExecutorPort);
        accountTransactionReverter.setAccountTransactionReverterAdapter(mockedAccountTransactionReverterPort);
    }

    @AfterEach
    void tearDown() {
        messageSender.setSpiMessagingApis(spiMessagingApisBean);
        accountTransaction.setAccountTransactionExecutorPort(accountTransactionExecutorPort);
        accountTransactionReverter.setAccountTransactionReverterAdapter(accountTransactionReverterPort);
    }

    @Test
    @DisplayName("when sending a return and the customer account debit throws internal server error exception should the event end with error status")
    void shouldGenerateAnEventWithErrorStatusWhenCustomerDebitThrowsInternalServerErrorException() {
        //given
        when(mockedAccountTransactionExecutorPort.makeTransaction(any(AccountTransactionRequestDTO.class)))
            .thenThrow(InternalServerErrorException.class);

        //when
        assertThatThrownBy(this::sendAReturn).isInstanceOf(HttpServerErrorException.InternalServerError.class);

        //then
        EventEntity event = verifyEventWithStatus(EXPECTED_ERROR_STATUS, CUSTOMER_DEBIT_INTERNAL_ERROR, null);
        TransactionEntity transactionEntity = ((TransactionEventEntity) event).getTransactionEntity();
        assertThat(transactionEntity.getCustomerTransactionResult().isInternalServerError()).isTrue();
        assertThat(transactionEntity.getCustomerTransactionResult().getErrorReturned()).isNotNull();
        assertThat(event.getTransactionResult()).isNull();
        assertThat(event.getIpAccountTransactionResult()).isNull();

        verify(mockedAccountTransactionExecutorPort, times(1)).makeTransaction(any());
        verifyNoMoreInteractions(mockedAccountTransactionReverterPort);

        assertThat(messageRepository.findAll()).doNotHave(IS_PACS004_CONDITION);
    }

    @Test
    @DisplayName("when sending a return and the customer account debit throws bad request exception should the event end with error status")
    void shouldGenerateAnEventWithErrorStatusWhenCustomerDebitThrowsBadRequestException() {
        //given
        when(mockedAccountTransactionExecutorPort.makeTransaction(any(AccountTransactionRequestDTO.class)))
            .thenThrow(BadRequestException.class);

        //when
        assertThatThrownBy(this::sendAReturn).isInstanceOf(HttpClientErrorException.BadRequest.class);

        //then
        EventEntity event = verifyEventWithStatus(RETURN_REJECTED, null, CUSTOMER_DEBIT_ERROR);
        TransactionEntity transactionEntity = ((TransactionEventEntity) event).getTransactionEntity();
        assertThat(transactionEntity.getCustomerTransactionResult().isInternalServerError()).isFalse();
        assertThat(transactionEntity.getCustomerTransactionResult().getErrorReturned()).isNotNull();
        assertThat(event.getTransactionResult()).isNull();
        assertThat(event.getIpAccountTransactionResult()).isNull();

        verify(mockedAccountTransactionExecutorPort, times(1)).makeTransaction(any());
        verifyNoInteractions(mockedAccountTransactionReverterPort);

        assertThat(messageRepository.findAll()).doNotHave(IS_PACS004_CONDITION);
    }

    @Test
    @DisplayName("when sending a return and the managerial ip account debit throws exception should the event end with error status")
    void shouldGenerateAnEventWithErrorStatusWhenManagerialDebitThrowsException() {
        //given
        when(mockedAccountTransactionExecutorPort.makeTransaction(any(AccountTransactionRequestDTO.class)))
            .thenReturn(buildTransactionResponseMock())
            .thenThrow(InternalServerErrorException.class);

        //when
        assertThatThrownBy(this::sendAReturn).isInstanceOf(HttpServerErrorException.InternalServerError.class);

        //then
        EventEntity event = verifyEventWithStatus(EXPECTED_ERROR_STATUS, CLEARING_ACCOUNT_DEBIT_ERROR, null);

        TransactionEntity transactionEntity = ((TransactionEventEntity) event).getTransactionEntity();
        assertThat(transactionEntity.getCustomerTransactionResult().getReverted()).isTrue();
        assertThat(event.getTransactionResult()).isNull();
        assertThat(event.getIpAccountTransactionResult()).isNull();

        verify(mockedAccountTransactionExecutorPort, times(2)).makeTransaction(any());
        verify(mockedAccountTransactionReverterPort).revertDebit(ExpectTransactionRevertDTO(1));

        assertThat(messageRepository.findAll()).doNotHave(IS_PACS004_CONDITION);
    }

    @Test
    @DisplayName("when sending a return and the mirror ip account debit throws exception should the event end with error status")
    void shouldGenerateAnEventWithErrorStatusWhenMirrorIPAccountDebitThrowsException() {
        //given
        when(mockedAccountTransactionExecutorPort.makeTransaction(any(AccountTransactionRequestDTO.class)))
            .thenReturn(buildTransactionResponseMock())
            .thenReturn(buildTransactionResponseMock())
            .thenThrow(InternalServerErrorException.class);
        //when
        assertThatThrownBy(this::sendAReturn).isInstanceOf(HttpServerErrorException.InternalServerError.class);

        //then
        EventEntity event = verifyEventWithStatus(EXPECTED_ERROR_STATUS, CLEARING_ACCOUNT_DEBIT_ERROR, null);

        TransactionEntity transactionEntity = ((TransactionEventEntity) event).getTransactionEntity();
        assertThat(transactionEntity.getCustomerTransactionResult().getReverted()).isTrue();
        assertThat(event.getTransactionResult().getReverted()).isTrue();
        assertThat(event.getIpAccountTransactionResult()).isNull();

        verify(mockedAccountTransactionExecutorPort, times(3)).makeTransaction(any());
        verify(mockedAccountTransactionReverterPort).revertDebit(ExpectTransactionRevertDTO(2));

        assertThat(messageRepository.findAll()).doNotHave(IS_PACS004_CONDITION);
    }

    @NotNull
    private EventEntity verifyEventWithStatus(String status, String errorReason, String rejectionReason) {
        List<EventEntity> allEvents = transactionEntitiesService.getAllEventsAndVerifySize(2);

        EventEntity event = allEvents.get(1);
        assertThat(event.getStatus().getDescription()).isEqualTo(status);

        if (errorReason != null) {
            assertThat(event.getErrorReason().getDescription()).isEqualTo(errorReason);
        } else {
            assertThat(event.getErrorReason()).isNull();
        }

        if (rejectionReason != null) {
            assertThat(event.getRejectionReasonCode().getDescription()).isEqualTo(rejectionReason);
        } else {
            assertThat(event.getRejectionReasonCode()).isNull();
        }

        // Verifying status transition
        List<EventStatusTransitionEntity> statusTransitions = getOrderedEventStatusTransitions(event);
        assertThat(statusTransitions).hasSize(2);
        assertThat(statusTransitions.get(0).getEventStatusCode().getDescription()).isEqualTo(RETURN_INITIATED);
        assertThat(statusTransitions.get(1).getEventStatusCode().getDescription()).isEqualTo(status);
        return event;
    }

    private AccountTransactionReverterDTO ExpectTransactionRevertDTO(int reversions) {
        return AccountTransactionReverterDTO.builder()
            .reversals(
                IntStream.range(0, reversions)
                    .mapToObj(
                        i -> TransactionReverterDTO.builder().entryId(TRANSACTION_ID_MOCK).build()
                    ).collect(Collectors.toList())
            ).build();
    }

    private AccountTransactionResponseDTO buildTransactionResponseMock() {

        LancamentoResponseV2DTO lancamentoResponseV2DTO = new LancamentoResponseV2DTO();

        lancamentoResponseV2DTO.setClassificacaoCategoriaContaSPI(CACC);
        lancamentoResponseV2DTO.setCpfCnpjTitular(BigDecimal.valueOf(92082843521L));

        return AccountTransactionResponseDTO.builder()
            .transactionId(TRANSACTION_ID_MOCK)
            .lancamentoResponseV2DTO(lancamentoResponseV2DTO)
            .build();
    }

    protected void mockMessageSender() {
        String expectedPiResourceId = RandomStringUtils.randomAlphabetic(12);
        when(mockedMessagesApi.sendsMessageV1(any(MessageSpecificationDTO.class)))
            .thenReturn(createMessageSentResponseDTO(expectedPiResourceId));
    }

    @NotNull
    private static List<EventStatusTransitionEntity> getOrderedEventStatusTransitions(EventEntity actual) {
        return actual.getEventStatusTransitionEntities().stream()
            .sorted(Comparator.comparing(EventStatusTransitionEntity::getTimestamp))
            .collect(Collectors.toList());
    }

    private void sendAReturn() {

        String returnEndToEndId =
            CorrelationIdGenerator.generateCorrelactionIdPacs004(String.valueOf(PARTICIPANT_ISPB));

        ReturnSettlementUIWapperDTO returnSettlementUIWapperDTO =
            new ReturnSettlementUIWapperDTO()
                .originalEndToEndIdentification(originalEndToEndId)
                .returnEndToEndIdentification(returnEndToEndId)
                .creationDateTime(LocalDateTime.parse("2020-06-03T21:11:46.120"))
                .settlementMethod(SETTLEMENT_METHOD_CLRG)
                .settlementPriority(INSTRUCTION_PRIORITY_HIGH)
                .chargeBearer(CHARGE_BEARER_SLEV)
                .additionalInformation(ADDITIONAL_INFORMATION)
                .unstructured(" MORE ADDITIONAL INFO ")
                .returnReasonInformation(ReturnSettlementUIWapperDTO.ReturnReasonInformationEnum.AM05)
                .returnedInterbankSettlementAmount(BigDecimal.ONE);

        mockMessageSender();
        invokeEndpoint(returnSettlementUIWapperDTO);
    }

    private void receiveAPacs008(String receiptEndToEndId) {

        mockMessageSender();
        InstantPaymentsUIDTO instantPaymentsUIDTO =
            createInstantPaymentsUIDTOMock(Collections.singletonList(receiptEndToEndId),
                InstantPaymentCreationUtils.OperationType.RECEIPT);

        invokeEndpointIncomingMessage(buildReceivedPacs008(getRandomPiResourceId(), instantPaymentsUIDTO, "1.4"));

    }

    private void receiveAPacs002(String endToEndId) {
        String receivedPacs002PiResourceId = getRandomPiResourceId();
        String receivedPacs002Message =
            buildPacs002Response(receivedPacs002PiResourceId, buildTxInfAndSts(endToEndId, RECEIPT_SUCCESS_STATUS), "1.2");
        invokeEndpointIncomingMessage(receivedPacs002Message);
    }

    private String receiveAReceipt() {

        String receiptEndToEndId = CorrelationIdGenerator.generateCorrelactionIdPacs008(String.valueOf(PARTICIPANT_ISPB));

        receiveAPacs008(receiptEndToEndId);
        receiveAPacs002(receiptEndToEndId);

        return receiptEndToEndId;
    }

    private void invokeEndpoint(ReturnSettlementUIWapperDTO returnSettlementUIWapperDTO) {
        RestTemplate restTemplate = new RestTemplate();
        HttpEntity<ReturnSettlementUIWapperDTO> request = new HttpEntity<>(returnSettlementUIWapperDTO);
        String url = "http://localhost:" + port + RETURN_ENDPOINT;
        restTemplate.postForObject(url, request, MateraRestReturnDTO.class);
    }

    private void invokeEndpointIncomingMessage(String message) {
        RestTemplate restTemplate = new RestTemplate();
        HttpEntity<String> request = new HttpEntity<>(message);
        String url = "http://localhost:" + port + INCOMING_MESSAGE_ENDPOINT;
        restTemplate.postForObject(url, request, Void.class);
    }
}
