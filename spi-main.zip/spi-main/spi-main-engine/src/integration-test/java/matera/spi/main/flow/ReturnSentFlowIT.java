package matera.spi.main.flow;

import com.matera.commons.utils.exception.BusinessException;
import com.matera.spi.messaging.api.MessagesApi;
import com.matera.spi.messaging.api.SPIMessagingApis;
import com.matera.spi.messaging.model.MessageSpecificationDTO;

import com.matera.spi.webhook.transaction.model.TransactionIdValidationResponseDTO;
import matera.spi.commons.IntegrationTest;
import matera.spi.dto.InstantPaymentsUIDTO;
import matera.spi.dto.ReturnSettlementUIWapperDTO;
import matera.spi.dto.ReturnSettlementUIWapperDTO.ReturnReasonInformationEnum;
import matera.spi.main.application.service.ReturnApplicationUIService;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.transaction.TransactionEventEntity;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.domain.model.transaction.TransactionEntity;
import matera.spi.main.domain.model.transaction.TransactionType;
import matera.spi.main.domain.service.CorrelationIdGenerator;
import matera.spi.main.domain.service.IpAccountConfigurationService;
import matera.spi.main.domain.service.MessageCatalogSpecificationService;
import matera.spi.main.domain.service.MessageSender;
import matera.spi.main.domain.service.ParticipantMipService;
import matera.spi.main.domain.service.ReceiptEventValidator;
import matera.spi.main.domain.service.WebhookTransactionValidationService;
import matera.spi.main.domain.service.event.receiver.AccountTransactionReceiver;
import matera.spi.main.domain.service.event.receiver.MessageReceiver;
import matera.spi.main.domain.service.transaction.AccountTransaction;
import matera.spi.main.domain.service.transaction.AccountTransactionReverter;
import matera.spi.main.transactions.port.AccountTransactionExecutorPort;
import matera.spi.main.transactions.port.AccountTransactionReverterPort;
import matera.spi.main.utils.InstantPaymentCreationUtils;
import matera.spi.main.utils.TransactionEntitiesService;
import matera.spi.main.utils.verifier.AccountTransactionVerifier;
import matera.spi.main.utils.verifier.EventVerifier;
import matera.spi.main.utils.verifier.ReturnSentVerifier;
import matera.spi.main.utils.verifier.ReturnSentVerifier.ReturnSentVerifierBuilder;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static matera.spi.main.utils.InstantPaymentCreationUtils.ADDITIONAL_INFORMATION;
import static matera.spi.main.utils.InstantPaymentCreationUtils.BIG_DEBIT_VALUE;
import static matera.spi.main.utils.InstantPaymentCreationUtils.CHARGE_BEARER_SLEV;
import static matera.spi.main.utils.InstantPaymentCreationUtils.INSTRUCTION_PRIORITY_HIGH;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.SETTLEMENT_METHOD_CLRG;
import static matera.spi.main.utils.InstantPaymentCreationUtils.createInstantPaymentsUIDTOMock;
import static matera.spi.main.utils.InstantPaymentCreationUtils.createMessageSentResponseDTO;
import static matera.spi.main.utils.InstantPaymentCreationUtils.getRandomPiResourceId;
import static matera.spi.main.utils.MessageCreationUtils.buildPacs002Response;
import static matera.spi.main.utils.MessageCreationUtils.buildReceivedPacs008;
import static matera.spi.main.utils.MessageCreationUtils.buildTxInfAndSts;
import static matera.spi.main.utils.verifier.MessageSenderVerifier.verifyMessagesApiWasCalledWithExternalOriginAndDestination;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@IntegrationTest
@Transactional
class ReturnSentFlowIT {

    private static final String RECEIPT_SUCCESS_STATUS = "ACCC";
    private static final String RETURN_SUCCESS_STATUS = "ACSC";
    private static final String RETURN_REJECT_STATUS = "RJCT";
    private static final int ZERO = 0;
    private static final int ONE = 1;

    @Autowired
    private MessageReceiver messageReceiver;
    @Autowired
    private ReturnApplicationUIService returnApplicationUIService;
    @Autowired
    private MessageCatalogSpecificationService messageCatalogSpecificationService;
    @Autowired
    private TransactionEntitiesService transactionEntitiesService;
    @Autowired
    private ParticipantMipService participantMipService;
    @Autowired
    private IpAccountConfigurationService ipAccountConfigurationService;

    @Autowired
    private MessageSender messageSender;

    @Autowired
    private SPIMessagingApis spiMessagingApisBean;
    @Mock
    private SPIMessagingApis mockedSpiMessagingApis;
    @Mock
    private MessagesApi mockedMessagesApi;

    @Autowired
    private AccountTransaction accountTransaction;
    @Autowired
    private AccountTransactionExecutorPort accountTransactionExecutorPort;
    @Mock
    private AccountTransactionExecutorPort mockedAccountTransactionExecutorPort;

    @Autowired
    private AccountTransactionReverter accountTransactionReverter;

    @Autowired
    private AccountTransactionReverterPort accountTransactionReverterPort;

    @Mock
    private AccountTransactionReverterPort mockedAccountTransactionReverterPort;

    @Autowired
    private AccountTransactionReceiver accountTransactionReceiver;

    @Autowired
    private ReceiptEventValidator receiptEventValidator;

    @Mock
    private WebhookTransactionValidationService mockWebhookTransactionValidationService;
    @Autowired
    private WebhookTransactionValidationService webhookTransactionValidationService;


    private AccountTransactionVerifier accountTransactionVerifier;

    private String pacs004CurrentVersion;
    private String pacs002CurrentVersion;

    @BeforeEach
    void setup() {
        pacs004CurrentVersion = messageCatalogSpecificationService.findMessageCatalogSpecificationByCode("pacs.004").getVersion();
        pacs002CurrentVersion = messageCatalogSpecificationService.findMessageCatalogSpecificationByCode("pacs.002").getVersion();

        when(mockedSpiMessagingApis.messagesApi()).thenReturn(mockedMessagesApi);
        messageSender.setSpiMessagingApis(mockedSpiMessagingApis);
        accountTransaction.setAccountTransactionExecutorPort(mockedAccountTransactionExecutorPort);
        accountTransactionReverter.setAccountTransactionReverterAdapter(mockedAccountTransactionReverterPort);

        accountTransactionVerifier = new AccountTransactionVerifier(participantMipService, ipAccountConfigurationService, mockedAccountTransactionExecutorPort, mockedAccountTransactionReverterPort);

        ReflectionTestUtils.setField(receiptEventValidator, "webhookTransactionValidationService", mockWebhookTransactionValidationService);

        when(mockWebhookTransactionValidationService.queryValidator(any(), any())).thenReturn(new TransactionIdValidationResponseDTO().shouldReceive(false).motive("Web hook rejection."));
    }

    @AfterEach
    void tearDown() {
        messageSender.setSpiMessagingApis(spiMessagingApisBean);
        accountTransaction.setAccountTransactionExecutorPort(accountTransactionExecutorPort);
        accountTransactionReverter.setAccountTransactionReverterAdapter(accountTransactionReverterPort);
        ReflectionTestUtils.setField(receiptEventValidator, "webhookTransactionValidationService", webhookTransactionValidationService);

    }

    @Test
    void shouldSendAReturnFromAReceipt() {
        //given
        String originalEndToEndId = receiveAReceipt(RECEIPT_SUCCESS_STATUS);
        reset(mockedMessagesApi);
        //when
        reset(mockedAccountTransactionExecutorPort);
        accountTransactionVerifier.mockTransactionExecutor();
        ReturnSentVerifierBuilder returnSentVerifierBuilder = ReturnSentVerifier.builder();
        sendAReturn(returnSentVerifierBuilder, originalEndToEndId);

        //then
        accountTransactionVerifier.verifyRevert(ZERO);
        accountTransactionVerifier.verifyTransaction(ONE, TransactionType.RETURN_SENT);

        transactionEntitiesService.refreshAllEntities();
        List<EventEntity> allEvents = transactionEntitiesService.getAllEventsAndVerifySize(2);
        List<TransactionEntity> allTransactions = transactionEntitiesService.getAllTransactionsAndVerifySize(2);
        List<MessageEntity> allMessages = transactionEntitiesService.getAllMessagesAndVerifySize(4);

        TransactionEventEntity originalEventEntity = (TransactionEventEntity) allEvents.get(0);
        returnSentVerifierBuilder
            .pacs004(allMessages.get(3))
            .expectedPacs004Version(pacs004CurrentVersion)
            .pacs002(null)
            .returnEventEntity(allEvents.get(1))
            .returnSentEntity(allTransactions.get(1))
            .originalEventEntity(originalEventEntity)
            .eventVerifier(EventVerifier::verifyReturnSentEventIsWaitingConfirm)
            .build().verify();

        verifyMessagesApiWasCalledWithExternalOriginAndDestination(mockedMessagesApi);
    }

    @Test
    void shouldConfirmAReturnFromAReceipt() {
        //given
        String originalEndToEndId = receiveAReceipt(RECEIPT_SUCCESS_STATUS);

        //when
        reset(mockedAccountTransactionExecutorPort);
        accountTransactionVerifier.mockTransactionExecutor();
        ReturnSentVerifierBuilder returnSentVerifierBuilder = ReturnSentVerifier.builder();
        String returnEndToEndId = sendAReturn(returnSentVerifierBuilder, originalEndToEndId);

        receiveAResponse(RETURN_SUCCESS_STATUS, returnEndToEndId, returnSentVerifierBuilder);
        //then
        accountTransactionVerifier.verifyRevert(ZERO);
        accountTransactionVerifier.verifyTransaction(ONE, TransactionType.RETURN_SENT);

        transactionEntitiesService.refreshAllEntities();
        List<EventEntity> allEvents = transactionEntitiesService.getAllEventsAndVerifySize(2);
        List<TransactionEntity> allTransactions = transactionEntitiesService.getAllTransactionsAndVerifySize(2);
        List<MessageEntity> allMessages = transactionEntitiesService.getAllMessagesAndVerifySize(5);

        TransactionEventEntity originalEventEntity = (TransactionEventEntity) allEvents.get(0);
        EventEntity returnEventEntity = allEvents.get(1);
        returnSentVerifierBuilder
            .pacs004(allMessages.get(3))
            .expectedPacs004Version(pacs004CurrentVersion)
            .pacs002(allMessages.get(4))
            .returnEventEntity(returnEventEntity)
            .returnSentEntity(allTransactions.get(1))
            .originalEventEntity(originalEventEntity)
            .eventVerifier(EventVerifier::verifyReturnSentEventIsSuccess)
            .build().verify();

        BigDecimal returnedAmount = originalEventEntity.getTransactionEntity().getReturnedAmount();
        assertThat(returnedAmount).isEqualTo(returnEventEntity.getValue());
    }

    @Test
    void shouldIncrementReturnedAmountOriginalEventTransaction() {
        //given
        String originalEndToEndId = receiveAReceipt(RECEIPT_SUCCESS_STATUS);

        //when
        for (int i = 0; i < 2; i++) {
            reset(mockedAccountTransactionExecutorPort);
            accountTransactionVerifier.mockTransactionExecutor();
            ReturnSentVerifierBuilder returnSentVerifierBuilder = ReturnSentVerifier.builder();
            String returnEndToEndId = sendAReturn(returnSentVerifierBuilder, originalEndToEndId);
            receiveAResponse(RETURN_SUCCESS_STATUS, returnEndToEndId, returnSentVerifierBuilder);
        }

        //then
        transactionEntitiesService.refreshAllEntities();
        List<EventEntity> allEvents = transactionEntitiesService.getAllEventsAndVerifySize(3);

        TransactionEventEntity originalEventEntity = (TransactionEventEntity) allEvents.get(0);
        EventEntity returnEventEntity1 = allEvents.get(1);
        EventEntity returnEventEntity2 = allEvents.get(2);
        BigDecimal returnEventValue = returnEventEntity1.getValue().add(returnEventEntity2.getValue());


        BigDecimal returnedAmount = originalEventEntity.getTransactionEntity().getReturnedAmount();

        assertThat(returnedAmount).isEqualTo(returnEventValue);
    }

    @Test
    void shouldConfirmRejectionAReturnFromAReceipt() {
        //given
        String originalEndToEndId = receiveAReceipt(RECEIPT_SUCCESS_STATUS);

        //when
        reset(mockedAccountTransactionExecutorPort);
        accountTransactionVerifier.mockTransactionExecutor();
        ReturnSentVerifierBuilder returnSentVerifierBuilder = ReturnSentVerifier.builder();
        String returnEndToEndId = sendAReturn(returnSentVerifierBuilder, originalEndToEndId);

        receiveAResponse(RETURN_REJECT_STATUS, returnEndToEndId, returnSentVerifierBuilder);
        //then
        accountTransactionVerifier.verifyRevert(ONE);
        accountTransactionVerifier.verifyTransaction(ONE, TransactionType.RETURN_SENT);

        transactionEntitiesService.refreshAllEntities();
        List<EventEntity> allEvents = transactionEntitiesService.getAllEventsAndVerifySize(2);
        List<TransactionEntity> allTransactions = transactionEntitiesService.getAllTransactionsAndVerifySize(2);
        List<MessageEntity> allMessages = transactionEntitiesService.getAllMessagesAndVerifySize(5);

        TransactionEventEntity originalEventEntity = (TransactionEventEntity) allEvents.get(0);
        returnSentVerifierBuilder
            .pacs004(allMessages.get(3))
            .expectedPacs004Version(pacs004CurrentVersion)
            .pacs002(allMessages.get(4))
            .returnEventEntity(allEvents.get(1))
            .returnSentEntity(allTransactions.get(1))
            .originalEventEntity(originalEventEntity)
            .eventVerifier(EventVerifier::verifyReturnSentEventIsReturnReject)
            .build().verify();

    }

    @Test
    void shouldSendAndConfirmMultipleReturns() {
        //given
        String originalEndToEndId = receiveAReceipt(RECEIPT_SUCCESS_STATUS);

        //when
        reset(mockedAccountTransactionExecutorPort);
        accountTransactionVerifier.mockTransactionExecutor();
        List<ReturnSentVerifierBuilder> verifierBuilders = new ArrayList<>();
        int returnsQuantity = 50;

        for (int returnIndex = 0; returnIndex < returnsQuantity; returnIndex++) {
            ReturnSentVerifierBuilder returnSentVerifierBuilder = ReturnSentVerifier.builder();
            verifierBuilders.add(returnSentVerifierBuilder);
            String returnEndToEndId = sendAReturn(returnSentVerifierBuilder, originalEndToEndId);
            receiveAResponse(isEven(returnIndex) ? RETURN_SUCCESS_STATUS : RETURN_REJECT_STATUS, returnEndToEndId, returnSentVerifierBuilder);
        }
        //then
        accountTransactionVerifier.verifyRevert(returnsQuantity / 2);
        accountTransactionVerifier.verifyTransaction(returnsQuantity, TransactionType.RETURN_SENT);

        transactionEntitiesService.refreshAllEntities();
        List<EventEntity> allEvents = transactionEntitiesService.getAllEventsAndVerifySize(returnsQuantity + 1);
        List<TransactionEntity> allTransactions = transactionEntitiesService.getAllTransactionsAndVerifySize(returnsQuantity + 1);
        List<MessageEntity> allMessages = transactionEntitiesService.getAllMessagesAndVerifySize((returnsQuantity * 2) + 3); // 3 messages for the receipt and 2 for each return


        TransactionEventEntity originalEventEntity = (TransactionEventEntity) allEvents.get(0);
        for (int returnIndex = 0; returnIndex < returnsQuantity; returnIndex++) {
            verifierBuilders.get(returnIndex)
                .pacs004(allMessages.get((returnIndex * 2) + 3))
                .expectedPacs004Version(pacs004CurrentVersion)
                .pacs002(allMessages.get((returnIndex * 2) + 4))
                .returnEventEntity(allEvents.get(returnIndex + 1))
                .returnSentEntity(allTransactions.get(returnIndex + 1))
                .originalEventEntity(originalEventEntity)
                .eventVerifier(
                    isEven(returnIndex)
                        ? EventVerifier::verifyReturnSentEventIsSuccess
                        : EventVerifier::verifyReturnSentEventIsReturnReject)
                .build().verify();
        }

    }

    @Test
    void shouldThrowErrorWhenTheValueItsBiggerThanOriginalEvent() {
        //given
        String originalEndToEndId = receiveAReceipt(RECEIPT_SUCCESS_STATUS);

        //when
        reset(mockedAccountTransactionExecutorPort);
        accountTransactionVerifier.mockTransactionExecutor();
        ReturnSentVerifierBuilder returnSentVerifierBuilder = ReturnSentVerifier.builder();
        assertThatThrownBy(() -> sendAReturn(returnSentVerifierBuilder, originalEndToEndId, BIG_DEBIT_VALUE.add(BigDecimal.ONE)))
        .isInstanceOf(BusinessException.class)
        .hasMessage("SPI-ME-007 - [returnedAmount]");
        //then
        accountTransactionVerifier.verifyRevert(ZERO);

        transactionEntitiesService.refreshAllEntities();
        transactionEntitiesService.getAllEventsAndVerifySize(1);
        transactionEntitiesService.getAllTransactionsAndVerifySize(1);
        transactionEntitiesService.getAllMessagesAndVerifySize(3);
    }

    private boolean isEven(int returnIndex) {
        return returnIndex % 2 == 0;
    }

    private String sendAReturn(ReturnSentVerifierBuilder returnSentVerifierBuilder, String originalEndToEndId) {
        return sendAReturn(returnSentVerifierBuilder, originalEndToEndId, BigDecimal.ONE);
    }
    private String sendAReturn(ReturnSentVerifierBuilder returnSentVerifierBuilder, String originalEndToEndId, BigDecimal value) {
        String returnEndToEndId =
            CorrelationIdGenerator.generateCorrelactionIdPacs004(String.valueOf(PARTICIPANT_ISPB));

        ReturnSettlementUIWapperDTO returnSettlementUIWapperDTO =
            new ReturnSettlementUIWapperDTO()
                .originalEndToEndIdentification(originalEndToEndId)
                .returnEndToEndIdentification(returnEndToEndId)
                .creationDateTime(LocalDateTime.parse("2020-06-03T21:11:46.120"))
                .settlementMethod(SETTLEMENT_METHOD_CLRG)
                .settlementPriority(INSTRUCTION_PRIORITY_HIGH)
                .chargeBearer(CHARGE_BEARER_SLEV)
                .additionalInformation(ADDITIONAL_INFORMATION)
                .unstructured(" MORE ADDITIONAL INFO ")
                .returnReasonInformation(ReturnReasonInformationEnum.AM05)
                .returnedInterbankSettlementAmount(value);

        returnSentVerifierBuilder.returnSettlementUIWapperDTO(returnSettlementUIWapperDTO);

        String messagePiResourceId = mockMessageSender();
        returnSentVerifierBuilder.expectedPacs004PiResourceId(messagePiResourceId);

        returnApplicationUIService.sentReturn(returnSettlementUIWapperDTO);
        return returnEndToEndId;
    }

    private String receiveAReceipt(String status) {
        accountTransactionVerifier.mockTransactionExecutor();

        String endToEndId = CorrelationIdGenerator.generateCorrelactionIdPacs008(String.valueOf(PARTICIPANT_ISPB));
        mockMessageSender();
        InstantPaymentsUIDTO instantPaymentsUIDTO =
            createInstantPaymentsUIDTOMock(Collections.singletonList(endToEndId),
                InstantPaymentCreationUtils.OperationType.RECEIPT);

        messageReceiver.readIncomingMessage(buildReceivedPacs008(getRandomPiResourceId(), instantPaymentsUIDTO, "1.4"));

        transactionEntitiesService.refreshAllEntities();

        receiveAResponse(status, endToEndId, null);

        transactionEntitiesService.refreshAllEntities();
        EventEntity eventEntity = transactionEntitiesService.getAllEventsAndVerifySize(1).get(0);

        accountTransactionReceiver.onMessage(new GenericMessage("{\"eventId\": \"" + eventEntity.getId() + "\"}"));

        return endToEndId;
    }

    private void receiveAResponse(String status, String endToEndId, ReturnSentVerifierBuilder returnSentVerifierBuilder) {
        String receivedPacs002PiResourceId = getRandomPiResourceId();
        String receivedPacs002Message =
            buildPacs002Response(receivedPacs002PiResourceId, buildTxInfAndSts(endToEndId, status), pacs002CurrentVersion);
        if (returnSentVerifierBuilder != null) {
            returnSentVerifierBuilder
                .expectedPacs002PiResourceId(receivedPacs002PiResourceId)
                .expectedPacs002Version(pacs002CurrentVersion);
        }
        messageReceiver.readIncomingMessage(receivedPacs002Message);
    }

    protected String mockMessageSender() {
        String randomPiResourceId = getRandomPiResourceId();
        when(mockedMessagesApi.sendsMessageV1(any(MessageSpecificationDTO.class)))
            .thenReturn(createMessageSentResponseDTO(randomPiResourceId));
        return randomPiResourceId;
    }

}
