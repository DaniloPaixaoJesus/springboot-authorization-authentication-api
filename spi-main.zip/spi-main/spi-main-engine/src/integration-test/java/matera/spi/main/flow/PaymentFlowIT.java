package matera.spi.main.flow;

import com.matera.commons.utils.exception.BusinessException;
import com.matera.spi.messaging.api.MessagesApi;
import com.matera.spi.messaging.api.SPIMessagingApis;
import com.matera.spi.messaging.model.MessageSpecificationDTO;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.InstantPaymentsUIDTO;
import matera.spi.main.application.service.PaymentsService;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.domain.model.transaction.TransactionEntity;
import matera.spi.main.domain.service.CorrelationIdGenerator;
import matera.spi.main.domain.service.MessageCatalogSpecificationService;
import matera.spi.main.domain.service.MessageSender;
import matera.spi.main.domain.service.event.receiver.MessageReceiver;
import matera.spi.main.persistence.BalanceAccountPiRepository;
import matera.spi.main.utils.InstantPaymentCreationUtils.OperationType;
import matera.spi.main.utils.TransactionEntitiesService;
import matera.spi.main.utils.verifier.EventVerifier;
import matera.spi.main.utils.verifier.PaymentVerifier;
import matera.spi.main.utils.verifier.PaymentVerifier.PaymentVerifierBuilder;

import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.createInstantPaymentsUIDTOMock;
import static matera.spi.main.utils.InstantPaymentCreationUtils.createMessageSentResponseDTO;
import static matera.spi.main.utils.InstantPaymentCreationUtils.getRandomPiResourceId;
import static matera.spi.main.utils.MessageCreationUtils.buildPacs002Response;
import static matera.spi.main.utils.MessageCreationUtils.buildTxInfAndSts;
import static matera.spi.main.utils.verifier.IPAccountBalanceVerifier.verifyAccountBalance;
import static matera.spi.main.utils.verifier.MessageSenderVerifier.verifyMessagesApiWasCalledWithExternalOriginAndDestination;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@IntegrationTest
@Transactional
class PaymentFlowIT {

    @Autowired
    private MessageSender messageSender;
    @Autowired
    private SPIMessagingApis spiMessagingApisBean;
    @Mock
    private SPIMessagingApis mockedSpiMessagingApis;
    @Mock
    private MessagesApi mockedMessagesApi;

	@Autowired
	private BalanceAccountPiRepository balanceAccountPiRepository;
	@Autowired
	private PaymentsService paymentsService;
	@Autowired
	private MessageReceiver messageReceiver;
    @Autowired
    private MessageCatalogSpecificationService messageCatalogSpecificationService;
    @Autowired
    private TransactionEntitiesService transactionEntitiesService;

    private String pacs008CurrentVersion;

    @BeforeEach
    void setUp() {
        pacs008CurrentVersion = messageCatalogSpecificationService.findMessageCatalogSpecificationByCode("pacs.008").getVersion();

        when(mockedSpiMessagingApis.messagesApi()).thenReturn(mockedMessagesApi);
        ReflectionTestUtils.setField(messageSender, "spiMessagingApis", mockedSpiMessagingApis);
    }

    @AfterEach
    void tearDown() {
        ReflectionTestUtils.setField(messageSender, "spiMessagingApis", spiMessagingApisBean);
    }

    @Test
	void shouldSendAPayment() {
		//when
		PaymentVerifierBuilder paymentVerifierBuilder = PaymentVerifier.builder();
		sendPayment(paymentVerifierBuilder);

		//then
        transactionEntitiesService.refreshAllEntities();
		verifyAccountBalance(balanceAccountPiRepository.findAll(), 1, 0);

		List<EventEntity> allEvents = transactionEntitiesService.getAllEventsAndVerifySize(1);
		List<TransactionEntity> allTransactions = transactionEntitiesService.getAllTransactionsAndVerifySize(1);
		List<MessageEntity> allMessages = transactionEntitiesService.getAllMessagesAndVerifySize(1);

		paymentVerifierBuilder
				.pacs008(allMessages.get(0))
                .expectedPacs008Version(pacs008CurrentVersion)
				.pacs002(null)
				.eventEntity(allEvents.get(0))
				.transactionEntity(allTransactions.get(0))
				.eventVerifier(EventVerifier::verifyPaymentEventIsWaitingConfirm)
				.build().verify();

        verifyMessagesApiWasCalledWithExternalOriginAndDestination(mockedMessagesApi);
    }

	@ParameterizedTest(name = "receive message from version: [{0}]")
	@ValueSource(strings = {"1.2", "1.3"})
	void shouldProcessAReceivedMessageConfirmingThePayment(String messageReceivedVersion) {
		//given
		PaymentVerifierBuilder paymentVerifierBuilder = PaymentVerifier.builder();
		String endToEndId = sendPayment(paymentVerifierBuilder);

		//when
		String pacs002PiResourceId = "ResourceId-325";
		paymentVerifierBuilder.expectedPacs002PiResourceId(pacs002PiResourceId);
		String message = buildPacs002Response(pacs002PiResourceId, buildTxInfAndSts(endToEndId, "ACSC"), messageReceivedVersion);
		messageReceiver.readIncomingMessage(message);

		//then
        transactionEntitiesService.refreshAllEntities();
		verifyAccountBalance(balanceAccountPiRepository.findAll(), 1, 0);

		List<EventEntity> allEvents = transactionEntitiesService.getAllEventsAndVerifySize(1);
		List<TransactionEntity> allTransactions = transactionEntitiesService.getAllTransactionsAndVerifySize(1);
		List<MessageEntity> allMessages = transactionEntitiesService.getAllMessagesAndVerifySize(2);

		paymentVerifierBuilder
				.pacs008(allMessages.get(0))
                .expectedPacs008Version(pacs008CurrentVersion)
				.pacs002(allMessages.get(1))
				.expectedPacs002Version(messageReceivedVersion)
				.eventEntity(allEvents.get(0))
				.transactionEntity(allTransactions.get(0))
				.eventVerifier(EventVerifier::verifyPaymentEventIsSuccess)
				.build().verify();
	}

	@ParameterizedTest(name = "receive message from version: [{0}]")
	@ValueSource(strings = {"1.2", "1.3"})
	void shouldProcessAReceivedMessageRejectingThePayment(String messageReceivedVersion) {
		//given
		PaymentVerifierBuilder paymentVerifierBuilder = PaymentVerifier.builder();
		String endToEndId = sendPayment(paymentVerifierBuilder);

		//when
		String pacs002PiResourceId = "ResourceId-325";
		paymentVerifierBuilder.expectedPacs002PiResourceId(pacs002PiResourceId);
		String message = buildPacs002Response(pacs002PiResourceId, buildTxInfAndSts(endToEndId, "RJCT"), messageReceivedVersion);
		messageReceiver.readIncomingMessage(message);

        transactionEntitiesService.refreshAllEntities();
		verifyAccountBalance(balanceAccountPiRepository.findAll(), 1, 1);

		List<EventEntity> allEvents = transactionEntitiesService.getAllEventsAndVerifySize(1);
		List<TransactionEntity> allTransactions = transactionEntitiesService.getAllTransactionsAndVerifySize(1);
		List<MessageEntity> allMessages = transactionEntitiesService.getAllMessagesAndVerifySize(2);

		paymentVerifierBuilder
				.pacs008(allMessages.get(0))
                .expectedPacs008Version(pacs008CurrentVersion)
				.pacs002(allMessages.get(1))
				.expectedPacs002Version(messageReceivedVersion)
				.eventEntity(allEvents.get(0))
				.transactionEntity(allTransactions.get(0))
				.eventVerifier(EventVerifier::verifyPaymentEventIsRejected)
				.build().verify();
	}

	@ParameterizedTest(name = "receive message from version: [{0}]")
	@ValueSource(strings = {"1.2", "1.3"})
	void shouldProcessAMessageWithFourPaymentResponses(String messageReceivedVersion) {
		//given
		List<PaymentVerifierBuilder> verifierBuilders = new ArrayList<>();
		StringBuilder txInfAndSts = new StringBuilder();
		for (int i = 0; i < 4; i++) {
			PaymentVerifierBuilder paymentVerifierBuilder = PaymentVerifier.builder();
			verifierBuilders.add(paymentVerifierBuilder);
			String endToEndId = sendPayment(paymentVerifierBuilder);
			txInfAndSts.append(buildTxInfAndSts(endToEndId, i % 2 == 0 ? "ACSC" : "RJCT"));
		}
		// when
		String pacs002PiResourceId = "ResourceId-325";
		verifierBuilders.forEach(builder -> builder.expectedPacs002PiResourceId(pacs002PiResourceId));
		String message = buildPacs002Response(pacs002PiResourceId, txInfAndSts.toString(), messageReceivedVersion);
        transactionEntitiesService.refreshAllEntities();
		messageReceiver.readIncomingMessage(message);
		// then
        transactionEntitiesService.refreshAllEntities();
		verifyAccountBalance(balanceAccountPiRepository.findAll(), 4, 2);

		List<EventEntity> allEvents = transactionEntitiesService.getAllEventsAndVerifySize(4);
		List<TransactionEntity> allTransactions = transactionEntitiesService.getAllTransactionsAndVerifySize(4);
		List<MessageEntity> allMessages = transactionEntitiesService.getAllMessagesAndVerifySize(5);

		MessageEntity pacs002 = allMessages.get(4);
		for (int i = 0; i < 4; i++) {
			PaymentVerifierBuilder paymentVerifierBuilder = verifierBuilders.get(i);
			paymentVerifierBuilder
					.pacs008(allMessages.get(i))
                    .expectedPacs008Version(pacs008CurrentVersion)
					.pacs002(pacs002)
					.expectedPacs002Version(messageReceivedVersion)
					.eventEntity(allEvents.get(i))
					.transactionEntity(allTransactions.get(i))
					.eventVerifier(i % 2 == 0 ? EventVerifier::verifyPaymentEventIsSuccess : EventVerifier::verifyPaymentEventIsRejected)
					.build().verify();
		}
	}

    @Test
    void shouldDuplicateCorrelationIdExceptionforDuplicateCorrelationId() {
        PaymentVerifierBuilder paymentVerifierBuilder = PaymentVerifier.builder();
        String endToEndId = "E133708352020052018307QIM07dpeD3";
        sendPaymentStaticEndToEndId(paymentVerifierBuilder, endToEndId);
        assertThatThrownBy(() -> sendPaymentStaticEndToEndId(paymentVerifierBuilder, endToEndId))
            .isInstanceOf(BusinessException.class)
            .hasMessage("SPI-ME-009 - [%s]", endToEndId);
    }

	@NotNull
	private String sendPayment(PaymentVerifierBuilder paymentVerifierBuilder) {
		String endToEndId = CorrelationIdGenerator.generateCorrelactionIdPacs008(String.valueOf(PARTICIPANT_ISPB));
		String expectedPiResourceId = mockMessageSender();
		InstantPaymentsUIDTO instantPaymentsUIDTO = createInstantPaymentsUIDTOMock(endToEndId, OperationType.PAYMENT);
		paymentVerifierBuilder.expectedPacs008PiResourceId(expectedPiResourceId);
		paymentVerifierBuilder.instantPaymentsUIDTO(instantPaymentsUIDTO);
		paymentsService.sendPayments(instantPaymentsUIDTO);
		return endToEndId;
	}

    private void sendPaymentStaticEndToEndId(PaymentVerifierBuilder paymentVerifierBuilder, String endToEndId) {
        String expectedPiResourceId = mockMessageSender();
        InstantPaymentsUIDTO instantPaymentsUIDTO = createInstantPaymentsUIDTOMock(endToEndId, OperationType.PAYMENT);
        paymentVerifierBuilder.expectedPacs008PiResourceId(expectedPiResourceId);
        paymentVerifierBuilder.instantPaymentsUIDTO(instantPaymentsUIDTO);
        paymentsService.sendPayments(instantPaymentsUIDTO);
    }

	protected String mockMessageSender() {
		String expectedPiResourceId = getRandomPiResourceId();
		when(mockedMessagesApi.sendsMessageV1(any(MessageSpecificationDTO.class))).thenReturn(createMessageSentResponseDTO(expectedPiResourceId));
		return expectedPiResourceId;
	}
}

