package matera.spi.main.utils.verifier;

import matera.spi.dto.ReturnSettlementUIWapperDTO;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.transaction.TransactionEventEntity;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.domain.model.transaction.TransactionEntity;
import matera.spi.main.utils.verifier.expected.dto.ExpectedTransactionDTO;

import lombok.Builder;
import lombok.Data;
import lombok.NonNull;
import org.apache.logging.log4j.util.TriConsumer;

@Data
@Builder
public class ReturnSentVerifier {

    @NonNull EventEntity returnEventEntity;
    @NonNull TransactionEntity returnSentEntity;
    @NonNull TransactionEventEntity originalEventEntity;

    @NonNull MessageEntity pacs004;
    @NonNull String expectedPacs004PiResourceId;
    @NonNull String expectedPacs004Version;

    @NonNull ReturnSettlementUIWapperDTO returnSettlementUIWapperDTO;
    @NonNull TriConsumer<EventEntity, ReturnSettlementUIWapperDTO, EventEntity> eventVerifier;

	MessageEntity pacs002;
	String expectedPacs002PiResourceId;
	String expectedPacs002Version;

    private void verifyEvent() {
        eventVerifier.accept(returnEventEntity, returnSettlementUIWapperDTO, originalEventEntity);
    }

    private void verifyTransaction() {
        TransactionVerifier.verifyTransaction(returnSentEntity, ExpectedTransactionDTO.returnSentFromEventSpecificationDTO(
            returnSettlementUIWapperDTO, originalEventEntity));
        TransactionVerifier.verifyTransactionAndEventRelation((TransactionEventEntity) returnEventEntity, returnSentEntity);
    }

    private void verifyPacs004Message() {
        MessageVerifier.verifySentMessageIsPacs004(pacs004, expectedPacs004PiResourceId, expectedPacs004Version);
        MessageVerifier.verifyMessageEventRelation(pacs004, returnEventEntity);
    }

	private void verifyPacs002Message() {
		if (pacs002 != null) {
			MessageVerifier.verifyReceivedMessageIsPacs002(pacs002, expectedPacs002PiResourceId, expectedPacs002Version);
			MessageVerifier.verifyMessageEventRelation(pacs002, returnEventEntity);
		}
	}

    public void verify() {
        verifyEvent();
        verifyTransaction();
        verifyPacs004Message();
        verifyPacs002Message();
    }
}
