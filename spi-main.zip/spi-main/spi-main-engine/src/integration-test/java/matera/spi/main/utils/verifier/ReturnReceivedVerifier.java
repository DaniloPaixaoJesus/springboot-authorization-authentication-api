package matera.spi.main.utils.verifier;

import matera.spi.dto.ReturnSettlementUIWapperDTO;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.transaction.TransactionEventEntity;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.domain.model.transaction.TransactionEntity;
import matera.spi.main.utils.verifier.expected.dto.ExpectedTransactionDTO;

import lombok.Builder;
import lombok.Data;
import lombok.NonNull;
import org.apache.logging.log4j.util.TriConsumer;

@Data
@Builder
public class ReturnReceivedVerifier {

	@NonNull EventEntity returnReceivedEventEntity;
    @NonNull TransactionEventEntity originalEventEntity;
	@NonNull TransactionEntity transactionEntity;

	@NonNull MessageEntity receivedPacs004;
	@NonNull String expectedReceivedPacs004PiResourceId;
	@NonNull String expectedReceivedPacs004Version;

	@NonNull ReturnSettlementUIWapperDTO returnSettlementUIWapperDTO;
    @NonNull TriConsumer<EventEntity, ReturnSettlementUIWapperDTO, EventEntity> eventVerifier;
	@NonNull MessageEntity sentPacs002;
	@NonNull String expectedSentPacs002PiResourceId;
    @NonNull String expectedSentPacs002Version;

	MessageEntity receivedPacs002;
	String expectedReceivedPacs002PiResourceId;
	String expectedReceivedPacs002Version;

	private void verifyEvent() {
		eventVerifier.accept(returnReceivedEventEntity, returnSettlementUIWapperDTO, originalEventEntity);
	}

	private void verifyTransaction() {
		TransactionVerifier.verifyTransaction(
            transactionEntity, ExpectedTransactionDTO.returnReceivedFromEventSpecificationDTO(returnSettlementUIWapperDTO, originalEventEntity));
		TransactionVerifier.verifyTransactionAndEventRelation((TransactionEventEntity) returnReceivedEventEntity, transactionEntity);
	}

	private void verifyReceivedPacs004Message() {
		MessageVerifier.verifyReceivedMessageIsPacs004(receivedPacs004, expectedReceivedPacs004PiResourceId, expectedReceivedPacs004Version);
		MessageVerifier.verifyMessageEventRelation(receivedPacs004, returnReceivedEventEntity);
	}

	private void verifySentPacs002Message() {
		MessageVerifier.verifySentMessageIsPacs002(sentPacs002, expectedSentPacs002PiResourceId, expectedSentPacs002Version);
		MessageVerifier.verifyMessageEventRelation(sentPacs002, returnReceivedEventEntity);
	}

	private void verifyReceivedPacs002Message() {
		if (receivedPacs002 != null) {
			MessageVerifier.verifyReceivedMessageIsPacs002(receivedPacs002, expectedReceivedPacs002PiResourceId, expectedReceivedPacs002Version);
			MessageVerifier.verifyMessageEventRelation(receivedPacs002, returnReceivedEventEntity);
		}
	}

	public void verify() {
		verifyEvent();
		verifyTransaction();
		verifyReceivedPacs004Message();
		verifySentPacs002Message();
		verifyReceivedPacs002Message();
	}
}
