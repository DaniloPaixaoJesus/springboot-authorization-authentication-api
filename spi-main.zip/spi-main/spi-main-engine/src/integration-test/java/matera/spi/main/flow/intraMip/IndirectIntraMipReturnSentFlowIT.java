package matera.spi.main.flow.intraMip;

import matera.spi.main.utils.WireMockUtils;

import com.github.tomakehurst.wiremock.client.CountMatchingStrategy;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.test.context.ActiveProfiles;

import static matera.spi.main.utils.WireMockUtils.never;

@ActiveProfiles("indirects")
class IndirectIntraMipReturnSentFlowIT extends IntraMipReturnSentFlowIT {

    @BeforeEach
    void setUpIndirect() {
        WireMockUtils.stubV1CreditsEntryValidation();
        WireMockUtils.stubV1IpAccount();

        WireMockUtils.stubV1IndirectsForIntraMip();
    }

    @Override
    protected CountMatchingStrategy customerTransactionCalls() {
        return never();
    }

}
