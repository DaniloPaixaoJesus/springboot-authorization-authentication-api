package matera.spi.main.flow;

import com.matera.spi.messaging.api.MessagesApi;
import com.matera.spi.messaging.api.SPIMessagingApis;
import com.matera.spi.messaging.model.MessageSentResponseDTO;
import com.matera.spi.messaging.model.MessageSpecificationDTO;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.InstantPaymentsUIDTO;
import matera.spi.dto.ReturnSettlementUIWapperDTO;
import matera.spi.dto.ReturnSettlementUIWapperDTO.ReturnReasonInformationEnum;
import matera.spi.main.application.service.PaymentsService;
import matera.spi.main.application.service.ReturnApplicationService;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.transaction.TransactionEventEntity;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.domain.model.transaction.TransactionEntity;
import matera.spi.main.domain.model.transaction.TransactionType;
import matera.spi.main.domain.service.CorrelationIdGenerator;
import matera.spi.main.domain.service.IpAccountConfigurationService;
import matera.spi.main.domain.service.MessageCatalogSpecificationService;
import matera.spi.main.domain.service.MessageSender;
import matera.spi.main.domain.service.ParticipantMipService;
import matera.spi.main.domain.service.event.receiver.MessageReceiver;
import matera.spi.main.domain.service.transaction.AccountTransaction;
import matera.spi.main.domain.service.transaction.AccountTransactionReverter;
import matera.spi.main.transactions.port.AccountTransactionExecutorPort;
import matera.spi.main.transactions.port.AccountTransactionReverterPort;
import matera.spi.main.utils.InstantPaymentCreationUtils;
import matera.spi.main.utils.TransactionEntitiesService;
import matera.spi.main.utils.verifier.AccountTransactionVerifier;
import matera.spi.main.utils.verifier.EventVerifier;
import matera.spi.main.utils.verifier.ReturnReceivedVerifier;
import matera.spi.main.utils.verifier.ReturnReceivedVerifier.ReturnReceivedVerifierBuilder;

import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static matera.spi.main.utils.InstantPaymentCreationUtils.ADDITIONAL_INFORMATION;
import static matera.spi.main.utils.InstantPaymentCreationUtils.BIG_DEBIT_VALUE;
import static matera.spi.main.utils.InstantPaymentCreationUtils.CHARGE_BEARER_SLEV;
import static matera.spi.main.utils.InstantPaymentCreationUtils.INSTRUCTION_PRIORITY_HIGH;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.SETTLEMENT_METHOD_CLRG;
import static matera.spi.main.utils.InstantPaymentCreationUtils.createInstantPaymentsUIDTOMock;
import static matera.spi.main.utils.InstantPaymentCreationUtils.createMessageSentResponseDTO;
import static matera.spi.main.utils.InstantPaymentCreationUtils.getRandomPiResourceId;
import static matera.spi.main.utils.MessageCreationUtils.buildPacs002Response;
import static matera.spi.main.utils.MessageCreationUtils.buildReceivedPacs004;
import static matera.spi.main.utils.MessageCreationUtils.buildTxInfAndSts;
import static matera.spi.main.utils.verifier.MessageSenderVerifier.verifyMessagesApiWasCalledWithExternalOriginAndDestination;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@IntegrationTest
@Transactional
class ReturnReceivedFlowIT {

    private static final String RETURN_SUCCESS_STATUS = "ACCC";
    private static final String RETURN_REJECT_STATUS = "RJCT";
    private static final String PAYMENT_CONFIRM_STATUS = "ACSC";
    private static final int ZERO = 0;
    private static final int ONE = 1;

    @Autowired
    private MessageReceiver messageReceiver;
    @Autowired
    private ReturnApplicationService returnApplicationService;
    @Autowired
    private MessageCatalogSpecificationService messageCatalogSpecificationService;
    @Autowired
    private TransactionEntitiesService transactionEntitiesService;
    @Autowired
    private ParticipantMipService participantMipService;
    @Autowired
    private IpAccountConfigurationService ipAccountConfigurationService;
    @Autowired
    private PaymentsService paymentsService;

    @Autowired
    private MessageSender messageSender;
    @Autowired
    private SPIMessagingApis spiMessagingApisBean;
    @Mock
    private SPIMessagingApis mockedSpiMessagingApis;
    @Mock
    private MessagesApi mockedMessagesApi;

    @Autowired
    private AccountTransaction accountTransaction;
    @Autowired
    private AccountTransactionExecutorPort accountTransactionExecutorPort;
    @Mock
    private AccountTransactionExecutorPort mockedAccountTransactionExecutorPort;

    @Autowired
    private AccountTransactionReverter accountTransactionReverter;
    @Autowired
    private AccountTransactionReverterPort accountTransactionReverterPort;
    @Mock
    private AccountTransactionReverterPort mockedAccountTransactionReverterPort;

    private AccountTransactionVerifier accountTransactionVerifier;

    private String pacs004CurrentVersion;
    private String pacs002CurrentVersion;

    @BeforeEach
    void setUp() {
        pacs004CurrentVersion =
            messageCatalogSpecificationService.findMessageCatalogSpecificationByCode("pacs.004").getVersion();
        pacs002CurrentVersion =
            messageCatalogSpecificationService.findMessageCatalogSpecificationByCode("pacs.002").getVersion();
        when(mockedSpiMessagingApis.messagesApi()).thenReturn(mockedMessagesApi);
        messageSender.setSpiMessagingApis(mockedSpiMessagingApis);
        accountTransaction.setAccountTransactionExecutorPort(mockedAccountTransactionExecutorPort);
        accountTransactionReverter.setAccountTransactionReverterAdapter(mockedAccountTransactionReverterPort);

        accountTransactionVerifier = new AccountTransactionVerifier(participantMipService, ipAccountConfigurationService, mockedAccountTransactionExecutorPort, mockedAccountTransactionReverterPort);
    }

    @AfterEach
    void tearDown() {
        messageSender.setSpiMessagingApis(spiMessagingApisBean);
        accountTransaction.setAccountTransactionExecutorPort(accountTransactionExecutorPort);
        accountTransactionReverter.setAccountTransactionReverterAdapter(accountTransactionReverterPort);
    }

    @Test
    void shouldSendAReturnFromAReceipt() {
        //given
        String originalEndToEndId = sendAPayment();
        reset(mockedMessagesApi);

        //when
        reset(mockedAccountTransactionExecutorPort);
        accountTransactionVerifier.mockTransactionExecutor();
        ReturnReceivedVerifierBuilder returnReceivedVerifierBuilder = ReturnReceivedVerifier.builder();
        receiveAReturn(returnReceivedVerifierBuilder, originalEndToEndId);
        //then
        accountTransactionVerifier.verifyTransaction(ZERO, TransactionType.RETURN_RECEIVED);

        transactionEntitiesService.refreshAllEntities();
        List<EventEntity> allEvents = transactionEntitiesService.getAllEventsAndVerifySize(2);
        List<TransactionEntity> allTransactions = transactionEntitiesService.getAllTransactionsAndVerifySize(2);
        List<MessageEntity> allMessages = transactionEntitiesService.getAllMessagesAndVerifySize(4);

        TransactionEventEntity originalEventEntity = (TransactionEventEntity) allEvents.get(0);
        // @formatter:off
        returnReceivedVerifierBuilder
            .receivedPacs004(allMessages.get(2))
            .expectedReceivedPacs004Version(pacs004CurrentVersion)
            .sentPacs002(allMessages.get(3))
            .expectedSentPacs002Version(pacs002CurrentVersion)
            .receivedPacs002(null)
            .returnReceivedEventEntity(allEvents.get(1))
            .transactionEntity(allTransactions.get(1))
            .originalEventEntity(originalEventEntity)
            .eventVerifier(EventVerifier::verifyReturnReceiverEventIsWaitingConfirm)
            .build().verify();
        // @formatter:off

        verifyMessagesApiWasCalledWithExternalOriginAndDestination(mockedMessagesApi);
    }

    @Test
    void shouldConfirmAReturnFromAReceipt() {
        //given
        String originalEndToEndId = sendAPayment();

        //when
        reset(mockedAccountTransactionExecutorPort);
        accountTransactionVerifier.mockTransactionExecutor();
        ReturnReceivedVerifierBuilder returnReceivedVerifierBuilder = ReturnReceivedVerifier.builder();
        String returnEndToEndId = receiveAReturn(returnReceivedVerifierBuilder, originalEndToEndId);

        transactionEntitiesService.refreshAllEntities();
        receiveAResponse(RETURN_SUCCESS_STATUS, returnEndToEndId, returnReceivedVerifierBuilder);

        //then
        accountTransactionVerifier.verifyRevert(ZERO);
        accountTransactionVerifier.verifyTransaction(ONE, TransactionType.RETURN_RECEIVED);

        transactionEntitiesService.refreshAllEntities();
        List<EventEntity> allEvents = transactionEntitiesService.getAllEventsAndVerifySize(2);
        List<TransactionEntity> allTransactions = transactionEntitiesService.getAllTransactionsAndVerifySize(2);
        List<MessageEntity> allMessages = transactionEntitiesService.getAllMessagesAndVerifySize(5);

        TransactionEventEntity originalEventEntity = (TransactionEventEntity) allEvents.get(0);
        EventEntity returnEventEntity = allEvents.get(1);
        // @formatter:off
        returnReceivedVerifierBuilder
            .receivedPacs004(allMessages.get(2))
            .expectedReceivedPacs004Version(pacs004CurrentVersion)
            .sentPacs002(allMessages.get(3))
            .expectedSentPacs002Version(pacs002CurrentVersion)
            .receivedPacs002(allMessages.get(4))
            .expectedReceivedPacs002Version(pacs002CurrentVersion)
            .returnReceivedEventEntity(returnEventEntity)
            .transactionEntity(allTransactions.get(1))
            .originalEventEntity(originalEventEntity)
            .eventVerifier(EventVerifier::verifyReturnReceiverEventIsPendingCreditAccountHolder)
            .build().verify();
        // @formatter:on

        BigDecimal returnedAmount = originalEventEntity.getTransactionEntity().getReturnedAmount();
        assertThat(returnedAmount).isEqualTo(returnEventEntity.getValue());
    }

    @Test
    void shouldIncrementReturnedAmountOriginalEventTransaction() {
        //given
        String originalEndToEndId = sendAPayment();

        //when
        for (int i = 0; i < 2; i++) {
            reset(mockedAccountTransactionExecutorPort);
            accountTransactionVerifier.mockTransactionExecutor();
            ReturnReceivedVerifierBuilder returnReceivedVerifierBuilder = ReturnReceivedVerifier.builder();
            String returnEndToEndId = receiveAReturn(returnReceivedVerifierBuilder, originalEndToEndId);

            transactionEntitiesService.refreshAllEntities();
            receiveAResponse(RETURN_SUCCESS_STATUS, returnEndToEndId, returnReceivedVerifierBuilder);
        }
        //then
        accountTransactionVerifier.verifyRevert(ZERO);
        accountTransactionVerifier.verifyTransaction(ONE, TransactionType.RETURN_RECEIVED);

        transactionEntitiesService.refreshAllEntities();
        List<EventEntity> allEvents = transactionEntitiesService.getAllEventsAndVerifySize(3);

        TransactionEventEntity originalEventEntity = (TransactionEventEntity) allEvents.get(0);
        EventEntity returnEventEntity1 = allEvents.get(1);
        EventEntity returnEventEntity2 = allEvents.get(2);
        BigDecimal returnEventValue = returnEventEntity1.getValue().add(returnEventEntity2.getValue());


        BigDecimal returnedAmount = originalEventEntity.getTransactionEntity().getReturnedAmount();

        assertThat(returnedAmount).isEqualTo(returnEventValue);
    }

    @Test
    void shouldConfirmRejectionReturnFromAReceipt() {
        //given
        String originalEndToEndId = sendAPayment();

        //when
        reset(mockedAccountTransactionExecutorPort);
        accountTransactionVerifier.mockTransactionExecutor();
        ReturnReceivedVerifierBuilder returnReceivedVerifierBuilder = ReturnReceivedVerifier.builder();
        String returnEndToEndId = receiveAReturn(returnReceivedVerifierBuilder, originalEndToEndId);
        receiveAResponse(RETURN_REJECT_STATUS, returnEndToEndId, returnReceivedVerifierBuilder);
        //then
        accountTransactionVerifier.verifyRevert(ZERO); // the credit operation only will be if the return is confirmed
        accountTransactionVerifier.verifyTransaction(ZERO, TransactionType.RETURN_RECEIVED);

        transactionEntitiesService.refreshAllEntities();
        List<EventEntity> allEvents = transactionEntitiesService.getAllEventsAndVerifySize(2);
        List<TransactionEntity> allTransactions = transactionEntitiesService.getAllTransactionsAndVerifySize(2);
        List<MessageEntity> allMessages = transactionEntitiesService.getAllMessagesAndVerifySize(5);

        TransactionEventEntity originalEventEntity = (TransactionEventEntity) allEvents.get(0);
        // @formatter:off
        returnReceivedVerifierBuilder
            .receivedPacs004(allMessages.get(2))
            .expectedReceivedPacs004Version(pacs004CurrentVersion)
            .sentPacs002(allMessages.get(3))
            .expectedSentPacs002Version(pacs002CurrentVersion)
            .receivedPacs002(allMessages.get(4))
            .expectedReceivedPacs002Version(pacs002CurrentVersion)
            .returnReceivedEventEntity(allEvents.get(1))
            .transactionEntity(allTransactions.get(1))
            .originalEventEntity(originalEventEntity)
            .eventVerifier(EventVerifier::verifyReturnReceiverEventIsRejectedByClearing)
            .build().verify();
        // @formatter:on
    }

    @Test
    void shouldReceiveMultipleReturns() {
        //given
        String originalEndToEndId = sendAPayment();

        //when
        reset(mockedAccountTransactionExecutorPort);
        accountTransactionVerifier.mockTransactionExecutor();
        List<ReturnReceivedVerifierBuilder> verifierBuilders = new ArrayList<>();
        int returnsQuantity = 20;

        for (int returnIndex = 0; returnIndex < returnsQuantity; returnIndex++) {
            ReturnReceivedVerifierBuilder returnReceivedVerifierBuilder = ReturnReceivedVerifier.builder();
            verifierBuilders.add(returnReceivedVerifierBuilder);
            String returnEndToEndId = receiveAReturn(returnReceivedVerifierBuilder, originalEndToEndId);
            receiveAResponse(isEven(returnIndex) ? RETURN_SUCCESS_STATUS : RETURN_REJECT_STATUS, returnEndToEndId,
                returnReceivedVerifierBuilder);
        }
        //then
        accountTransactionVerifier.verifyRevert(ZERO);
        accountTransactionVerifier.verifyTransaction(returnsQuantity / 2,
            TransactionType.RETURN_RECEIVED); //only success returns will make transactions

        transactionEntitiesService.refreshAllEntities();
        List<EventEntity> allEvents = transactionEntitiesService.getAllEventsAndVerifySize(returnsQuantity + 1);
        List<TransactionEntity> allTransactions =
            transactionEntitiesService.getAllTransactionsAndVerifySize(returnsQuantity + 1);
        List<MessageEntity> allMessages = transactionEntitiesService
            .getAllMessagesAndVerifySize((returnsQuantity * 3) + 2); // 3 messages for the receipt and 2 for each return

        TransactionEventEntity originalEventEntity = (TransactionEventEntity) allEvents.get(0);
        for (int returnIndex = 0; returnIndex < returnsQuantity; returnIndex++) {
            // @formatter:off
            verifierBuilders.get(returnIndex)
                .receivedPacs004(allMessages.get((returnIndex * 3) + 2))
                .expectedReceivedPacs004Version(pacs004CurrentVersion)
                .sentPacs002(allMessages.get((returnIndex * 3) + 3))
                .expectedSentPacs002Version(pacs002CurrentVersion)
                .receivedPacs002(allMessages.get((returnIndex * 3) + 4))
                .expectedReceivedPacs002Version(pacs002CurrentVersion)
                .returnReceivedEventEntity(allEvents.get(returnIndex + 1))
                .transactionEntity(allTransactions.get(returnIndex + 1))
                .originalEventEntity(originalEventEntity)
                .eventVerifier(
                    isEven(returnIndex)
                        ? EventVerifier::verifyReturnReceiverEventIsPendingCreditAccountHolder
                        : EventVerifier::verifyReturnReceiverEventIsRejectedByClearing
                )
                .build().verify();
            // @formatter:on
        }
    }

    @Test
    void shouldReceiveMultipleReturnsInASinglePacs004() {
        //given
        String originalEndToEndId = sendAPayment();

        //when
        reset(mockedAccountTransactionExecutorPort);
        accountTransactionVerifier.mockTransactionExecutor();

        int returnsQuantity = 16;

        List<ReturnReceivedVerifierBuilder> verifierBuilders = IntStream.range(0, returnsQuantity)
            .mapToObj(returnIndex -> ReturnReceivedVerifier.builder())
            .collect(Collectors.toList());

        List<String> returnEndToEndIdList = receiveAReturn(verifierBuilders, originalEndToEndId, BigDecimal.ONE);

        String allPacs002Responses = IntStream.range(0, returnsQuantity)
            .mapToObj(
                i -> buildTxInfAndSts(returnEndToEndIdList.get(i), isEven(i) ? RETURN_SUCCESS_STATUS : RETURN_REJECT_STATUS)
            ).reduce("", String::concat);

        String receivedPacs002PiResourceId = getRandomPiResourceId();
        String receivedPacs002Message = buildPacs002Response(receivedPacs002PiResourceId, allPacs002Responses, pacs002CurrentVersion);
        messageReceiver.readIncomingMessage(receivedPacs002Message);

        //then
        accountTransactionVerifier.verifyRevert(ZERO);
        accountTransactionVerifier.verifyTransaction(returnsQuantity / 2, TransactionType.RETURN_RECEIVED); //only success returns will make transactions

        transactionEntitiesService.refreshAllEntities();
        List<EventEntity> allEvents = transactionEntitiesService.getAllEventsAndVerifySize(returnsQuantity + 1);
        List<TransactionEntity> allTransactions =
            transactionEntitiesService.getAllTransactionsAndVerifySize(returnsQuantity + 1);
        List<MessageEntity> allMessages = transactionEntitiesService
            .getAllMessagesAndVerifySize(returnsQuantity + 4); // 3 messages for the receipt and 2 for each return

        TransactionEventEntity originalEventEntity = (TransactionEventEntity) allEvents.get(0);
        for (int returnIndex = 0; returnIndex < returnsQuantity; returnIndex++) {
            // @formatter:off
            verifierBuilders.get(returnIndex)
                .receivedPacs004(allMessages.get(2))
                .expectedReceivedPacs004Version(pacs004CurrentVersion)
                .sentPacs002(allMessages.get(returnIndex + 3))
                .expectedSentPacs002Version(pacs002CurrentVersion)
                .receivedPacs002(allMessages.get(allMessages.size() - 1))
                .expectedReceivedPacs002PiResourceId(receivedPacs002PiResourceId)
                .expectedReceivedPacs002Version(pacs002CurrentVersion)
                .returnReceivedEventEntity(allEvents.get(returnIndex + 1))
                .transactionEntity(allTransactions.get(returnIndex + 1))
                .originalEventEntity(originalEventEntity)
                .eventVerifier(
                    isEven(returnIndex)
                        ? EventVerifier::verifyReturnReceiverEventIsPendingCreditAccountHolder
                        : EventVerifier::verifyReturnReceiverEventIsRejectedByClearing
                )
                .build().verify();
            // @formatter:on
        }
    }

    @Test
    void shouldRejectAReturnThatExceedsTheValueFromThePaymentAndOthersReturns() {
        //given
        String originalEndToEndId = sendAPayment();

        //when
        reset(mockedAccountTransactionExecutorPort);
        accountTransactionVerifier.mockTransactionExecutor();
        ReturnReceivedVerifierBuilder returnReceivedVerifierBuilder = ReturnReceivedVerifier.builder();
        String returnEndToEndId =
            receiveAReturn(Collections.singletonList(returnReceivedVerifierBuilder), originalEndToEndId, BIG_DEBIT_VALUE.add(BigDecimal.ONE)).get(0);

        receiveAResponse(RETURN_REJECT_STATUS, returnEndToEndId, returnReceivedVerifierBuilder);
        //then
        accountTransactionVerifier.verifyRevert(ZERO);
        accountTransactionVerifier.verifyTransaction(ZERO, TransactionType.RETURN_RECEIVED);

        transactionEntitiesService.refreshAllEntities();

        List<EventEntity> allEvents = transactionEntitiesService.getAllEventsAndVerifySize(2);
        List<TransactionEntity> allTransactions = transactionEntitiesService.getAllTransactionsAndVerifySize(2);
        List<MessageEntity> allMessages = transactionEntitiesService.getAllMessagesAndVerifySize(5);

        TransactionEventEntity originalEventEntity = (TransactionEventEntity) allEvents.get(0);
        // @formatter:off
        returnReceivedVerifierBuilder
            .receivedPacs004(allMessages.get(2))
            .expectedReceivedPacs004Version(pacs004CurrentVersion)
            .sentPacs002(allMessages.get(3))
            .expectedSentPacs002Version(pacs002CurrentVersion)
            .receivedPacs002(allMessages.get(4))
            .expectedReceivedPacs002Version(pacs002CurrentVersion)
            .returnReceivedEventEntity(allEvents.get(1))
            .transactionEntity(allTransactions.get(1))
            .originalEventEntity(originalEventEntity)
            .eventVerifier(EventVerifier::verifyReturnReceiverEventIsReturnRejectionConfirmed)
            .build().verify();
        // @formatter:on
    }

    private boolean isEven(int returnIndex) {
        return returnIndex % 2 == 0;
    }

    private String receiveAReturn(ReturnReceivedVerifierBuilder returnSentVerifierBuilder, String originalEndToEndId) {
        return receiveAReturn(Collections.singletonList(returnSentVerifierBuilder), originalEndToEndId, BigDecimal.ONE).get(0);
    }

    private List<String> receiveAReturn(List<ReturnReceivedVerifierBuilder> returnReceivedVerifierBuilders,
                                        String originalEndToEndId,
                                        BigDecimal value) {

        int quantity = returnReceivedVerifierBuilders.size();

        List<String> returnsEndToEndIds = IntStream.range(0, quantity)
            .mapToObj(i -> CorrelationIdGenerator.generateCorrelactionIdPacs004(String.valueOf(PARTICIPANT_ISPB)))
            .collect(Collectors.toList());

        List<ReturnSettlementUIWapperDTO> returnsList = IntStream.range(0, quantity)
            .mapToObj(i -> buildReturnSettlementUIWapperDTO(returnsEndToEndIds.get(i), originalEndToEndId, value))
            .collect(Collectors.toList());
        String pacs004PiResourceId = getRandomPiResourceId();

        List<String> piResourcesIds = IntStream.range(0, quantity)
            .mapToObj(i -> getRandomPiResourceId())
            .collect(Collectors.toList());

        mockMessageSender(piResourcesIds);

        IntStream.range(0, quantity).forEach(
            i -> returnReceivedVerifierBuilders.get(i)
                .expectedReceivedPacs004PiResourceId(pacs004PiResourceId)
                .expectedSentPacs002PiResourceId(piResourcesIds.get(i))
                .returnSettlementUIWapperDTO(returnsList.get(i))
        );

        messageReceiver.readIncomingMessage(buildReceivedPacs004(returnsList, pacs004PiResourceId, pacs004CurrentVersion));
        transactionEntitiesService.refreshAllEntities();
        return returnsEndToEndIds;
    }

    private ReturnSettlementUIWapperDTO buildReturnSettlementUIWapperDTO(String returnEndToEndId,
                                                                         String originalEndToEndId,
                                                                         BigDecimal value) {
        // @formatter:off
        return new ReturnSettlementUIWapperDTO()
            .returnEndToEndIdentification(returnEndToEndId)
            .originalEndToEndIdentification(originalEndToEndId)
            .creationDateTime(LocalDateTime.parse("2020-06-03T21:11:46.120"))
            .settlementMethod(SETTLEMENT_METHOD_CLRG)
            .settlementPriority(INSTRUCTION_PRIORITY_HIGH)
            .chargeBearer(CHARGE_BEARER_SLEV)
            .additionalInformation(ADDITIONAL_INFORMATION)
            .unstructured(" MORE ADDITIONAL INFO ")
            .returnReasonInformation(ReturnReasonInformationEnum.AM05)
            .returnedInterbankSettlementAmount(value);
        // @formatter:on
    }

    @NotNull
    private String sendAPayment() {

        String originalEndToEndId =
            CorrelationIdGenerator.generateCorrelactionIdPacs008(String.valueOf(PARTICIPANT_ISPB));
        InstantPaymentsUIDTO instantPaymentsUIDTO =
            createInstantPaymentsUIDTOMock(originalEndToEndId, InstantPaymentCreationUtils.OperationType.PAYMENT);

        accountTransactionVerifier.mockTransactionExecutor();
        mockMessageSender();

        paymentsService.sendPayments(instantPaymentsUIDTO);

        receiveAResponse(PAYMENT_CONFIRM_STATUS, originalEndToEndId, null);

        return originalEndToEndId;
    }

    private void receiveAResponse(String status,
                                  String endToEndId,
                                  ReturnReceivedVerifierBuilder returnReceivedVerifierBuilder) {
        String receivedPacs002PiResourceId = getRandomPiResourceId();
        String receivedPacs002Message =
            buildPacs002Response(receivedPacs002PiResourceId, buildTxInfAndSts(endToEndId, status),
                pacs002CurrentVersion);
        if (returnReceivedVerifierBuilder != null) {
            returnReceivedVerifierBuilder
                .expectedReceivedPacs002PiResourceId(receivedPacs002PiResourceId)
                .expectedReceivedPacs002Version(pacs002CurrentVersion);
        }
        messageReceiver.readIncomingMessage(receivedPacs002Message);
    }

    private void mockMessageSender() {
        String piResourceId = getRandomPiResourceId();
        mockMessageSender(Collections.singletonList(piResourceId));
    }

    private void mockMessageSender(List<String> expectedPiResourceIds) {
        OngoingStubbing<MessageSentResponseDTO> sendMessageMock =
            when(mockedMessagesApi.sendsMessageV1(any(MessageSpecificationDTO.class)));
        for (String piResourceId : expectedPiResourceIds) {
            sendMessageMock = sendMessageMock.thenReturn(createMessageSentResponseDTO(piResourceId));
        }
    }

}
