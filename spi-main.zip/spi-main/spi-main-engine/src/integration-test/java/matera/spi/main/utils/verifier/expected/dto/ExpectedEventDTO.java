package matera.spi.main.utils.verifier.expected.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import matera.spi.dto.PaymentsUIDTO;
import matera.spi.dto.ReturnSettlementUIWapperDTO;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventType;

import java.time.LocalDateTime;

import static matera.spi.main.utils.InstantPaymentCreationUtils.BACEN_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ISPB;

@Data
@Builder
@AllArgsConstructor
public class ExpectedEventDTO {

	EventType type;
	String typeDescription;
	String statusDescription;
	Boolean isReverted;
	int initiatorISPB;
	String expectedEventStatus;
	String correlationId;
	LocalDateTime clearingTimestamp;
	boolean hasTransactionResult;
	double value;
	String originalCorrelationId;
	EventEntity originalEvent;

    public Boolean isExpectedBeReverted() {
		return isReverted;
	}

    public Boolean hasTransactionResult() {
		return hasTransactionResult;
	}
	public static ExpectedEventDTOBuilder paymentFromInstantPaymentsUIDTO(PaymentsUIDTO paymentsUIDTO) {
		return builder()
				.type(EventType.PAYMENT)
				.hasTransactionResult(true)
				.typeDescription("Payment")
				.correlationId(paymentsUIDTO.getEndToEndID())
				.value(paymentsUIDTO.getInterbankSettlementAmount().doubleValue())
				.initiatorISPB(PARTICIPANT_ISPB);
	}

	public static ExpectedEventDTOBuilder receiptFromInstantPaymentsUIDTO(PaymentsUIDTO paymentsUIDTO) {
		return builder()
				.type(EventType.RECEIPT)
				.typeDescription("Receipt")
				.correlationId(paymentsUIDTO.getEndToEndID())
				.value(paymentsUIDTO.getInterbankSettlementAmount().doubleValue())
				.initiatorISPB(BACEN_ISPB); //TODO: verify if this is correct?
	}

    public static ExpectedEventDTOBuilder returnSentFromReturnSettlementUIWapperDTO(ReturnSettlementUIWapperDTO returnSettlementUIWapperDTO, EventEntity originalEvent) {
        return builder()
            .type(EventType.RETURN_SENDER)
            .hasTransactionResult(true)
            .typeDescription("Return sender")
            .correlationId(returnSettlementUIWapperDTO.getReturnEndToEndIdentification())
            .value(returnSettlementUIWapperDTO.getReturnedInterbankSettlementAmount().doubleValue())
            .originalEvent(originalEvent)
            .originalCorrelationId(returnSettlementUIWapperDTO.getOriginalEndToEndIdentification())
            .initiatorISPB(PARTICIPANT_ISPB);
    }

    public static ExpectedEventDTOBuilder returnReceivedFromReturnSettlementUIWapperDTO(ReturnSettlementUIWapperDTO returnSettlementUIWapperDTO, EventEntity originalEvent) {
        return builder()
            .type(EventType.RETURN_RECEIVER)
            .typeDescription("Return receiver")
            .correlationId(returnSettlementUIWapperDTO.getReturnEndToEndIdentification())
            .value(returnSettlementUIWapperDTO.getReturnedInterbankSettlementAmount().doubleValue())
            .originalEvent(originalEvent)
            .originalCorrelationId(returnSettlementUIWapperDTO.getOriginalEndToEndIdentification())
            .initiatorISPB(BACEN_ISPB);
    }
}
