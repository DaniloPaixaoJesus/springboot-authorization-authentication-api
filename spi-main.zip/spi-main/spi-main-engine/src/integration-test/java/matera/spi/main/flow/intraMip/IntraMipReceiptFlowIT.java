package matera.spi.main.flow.intraMip;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.InstantPaymentsUIDTO;
import matera.spi.main.domain.model.ConfigEntity;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventType;
import matera.spi.main.domain.model.event.transaction.ReceiptEventEntity;
import matera.spi.main.domain.model.transaction.ReceiptEntity;
import matera.spi.main.domain.model.transaction.TransactionEntity;
import matera.spi.main.domain.service.ConfigurationService;
import matera.spi.main.domain.service.WebhookTransactionService;
import matera.spi.main.domain.service.WebhookWorkQueue;
import matera.spi.main.domain.service.event.receiver.AccountTransactionReceiver;
import matera.spi.main.domain.service.event.receiver.MessageReceiver;
import matera.spi.main.dto.WebhookTransactionDTO;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.ParticipantMipRepository;
import matera.spi.main.persistence.TransactionRepository;
import matera.spi.main.utils.AccountTransactionMocker;
import matera.spi.main.utils.WireMockUtils;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.CountMatchingStrategy;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.List;

import static matera.spi.main.domain.service.CorrelationIdGenerator.generateCorrelactionIdPacs008;
import static matera.spi.main.utils.InstantPaymentCreationUtils.EXTERNAL_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.LEFT_PADDED_EXTERNAL_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.LEFT_PADDED_PARTICIPANT_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.OperationType.RECEIPT;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ACCOUNT;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_BRANCH;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.createInstantPaymentsUIDTOMock;
import static matera.spi.main.utils.InstantPaymentCreationUtils.getRandomPiResourceId;
import static matera.spi.main.utils.MessageCreationUtils.RECEIPT_REJECTED_STATUS;
import static matera.spi.main.utils.MessageCreationUtils.RECEIPT_SUCCESS_STATUS;
import static matera.spi.main.utils.MessageCreationUtils.buildPacs002Response;
import static matera.spi.main.utils.MessageCreationUtils.buildReceivedPacs008;
import static matera.spi.main.utils.MessageCreationUtils.buildTxInfAndSts;
import static matera.spi.main.utils.WireMockUtils.V_1_MESSAGES;
import static matera.spi.main.utils.WireMockUtils.never;
import static matera.spi.main.utils.verifier.EventVerifier.RECEIPT_RECEIVED;
import static matera.spi.main.utils.verifier.EventVerifier.RECEIPT_REJECTED;
import static matera.spi.main.utils.verifier.EventVerifier.RECEIPT_REJECTION_CONFIRMED;
import static matera.spi.main.utils.verifier.EventVerifier.verifyAllStatusTransactions;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.exactly;
import static com.github.tomakehurst.wiremock.client.WireMock.matching;
import static com.github.tomakehurst.wiremock.client.WireMock.matchingJsonPath;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.resetAllRequests;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlMatching;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;
import static org.assertj.core.api.Assertions.assertThat;

@IntegrationTest
class IntraMipReceiptFlowIT {

    @Autowired
    private ParticipantMipRepository participantMipRepository;

    @Autowired
    private AccountTransactionReceiver accountTransactionReceiver;

    @Autowired
    private MessageReceiver messageReceiver;

    @Autowired
    private EventRepository eventRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private AccountTransactionMocker accountTransactionMocker;

    @Autowired
    private TransactionTemplate transactionTemplate;

    @Autowired
    private WebhookTransactionService webhookTransactionService;

    @Autowired
    private WebhookWorkQueue webhookWorkQueue;

    @Mock
    private WebhookWorkQueue mockWebhookWorkQueue;

    @Autowired
    private ConfigurationService configurationService;

    private static WireMockServer wireMockServer;

    @BeforeAll
    static void beforeAll() {
        wireMockServer = WireMockUtils.start();

        WireMockUtils.stubMessaging();

        WireMockUtils.stubStandin();

        WireMockUtils.stubWebhookValidation();

    }

    @AfterAll
    static void afterAll() {
        wireMockServer.stop();
    }

    @BeforeEach
    void setUp() {
        resetAllRequests();

        WireMockUtils.stubStandinEntryValidation();

        participantMipRepository
            .findByIspb(PARTICIPANT_ISPB)
            .ifPresent(participantMipEntity -> {
                participantMipEntity.setIspb(EXTERNAL_ISPB);
                participantMipEntity.setDirectParticipant(false);
                participantMipRepository.saveAndFlush(participantMipEntity);
            });

        accountTransactionMocker.spyExecutor();

        ReflectionTestUtils.setField(webhookTransactionService, "webhookWorkQueue", mockWebhookWorkQueue);
    }

    @AfterEach
    void tearDown() {
        participantMipRepository
            .findByIspb(EXTERNAL_ISPB)
            .ifPresent(participantMipRepository::delete);

        accountTransactionMocker.restoreAll();

        ReflectionTestUtils.setField(webhookTransactionService, "webhookWorkQueue", webhookWorkQueue);
    }

    @Test
    @DisplayName("receipt should call v1/messages passing destination with receiver isbp")
    void receiptShouldCallV1MessagesPassingDestinationWithReceiverIsbp() {
        //when
        receivePacs008();

        //then
        verify(exactly(1),
            postRequestedFor(urlMatching(V_1_MESSAGES))
                .withRequestBody(matchingJsonPath("$.origin", equalTo(LEFT_PADDED_PARTICIPANT_ISPB)))
                .withRequestBody(matchingJsonPath("$.destination", equalTo(LEFT_PADDED_EXTERNAL_ISPB)))
                .withRequestBody(matchingJsonPath("$.messageDefinitionIdentifier", matching("pacs.002.spi.*")))
                .withRequestBody(matchingJsonPath("$.messageContent", containing("<TxSts>ACSP</TxSts>")))
        );
    }

    @Test
    @DisplayName("receipt should generate a pacs002 with status reject when credit validation fails")
    void receiptShouldGeneratePacs002WithStatusRejectWhenCreditValidationFails() {
        //given
        stubBadRequestCreditValidation();

        //when
        receivePacs008();

        //then
        verify(exactly(1),
            postRequestedFor(urlMatching(V_1_MESSAGES))
                .withRequestBody(matchingJsonPath("$.origin", equalTo(LEFT_PADDED_PARTICIPANT_ISPB)))
                .withRequestBody(matchingJsonPath("$.destination", equalTo(LEFT_PADDED_EXTERNAL_ISPB)))
                .withRequestBody(matchingJsonPath("$.messageDefinitionIdentifier", matching("pacs.002.spi.*")))
                .withRequestBody(matchingJsonPath("$.messageContent", containing("<TxSts>RJCT</TxSts>")))
        );
    }

    @Test
    void receiptShouldProcessCreditValidationWithError() {
        //given
        stubInternalServerErrorCreditValidation();

        //when
        String endToEndId = receivePacs008();
        receiveAPacs002(endToEndId, RECEIPT_REJECTED_STATUS);

        //then
        transactionTemplate.execute(status -> {
            List<EventEntity> events = eventRepository.findAll(Sort.by(Sort.Direction.ASC, "initiationTimestampUTC"));
            assertThat(events).hasSize(1);

            EventEntity receiptEventEntity = events.get(0);

            assertThat(receiptEventEntity.getEventType()).isEqualTo(EventType.RECEIPT);

            List<String> receiptStatusTransitions = getReceiptCreditValidationErrorStatusTransitions();
            verifyAllStatusTransactions(receiptEventEntity, receiptStatusTransitions);

            return null;
        });

        ArgumentCaptor<WebhookTransactionDTO> argumentCaptor = ArgumentCaptor.forClass(WebhookTransactionDTO.class);
        Mockito.verify(mockWebhookWorkQueue).send(argumentCaptor.capture());

        WebhookTransactionDTO dto = argumentCaptor.getValue();
        assertThat(dto.getPaymentSettlementCallbackRequest().getPaymentConfirmed()).isFalse();
    }

    @NotNull
    protected List<String> getReceiptCreditValidationErrorStatusTransitions() {
        return List.of(RECEIPT_RECEIVED, RECEIPT_REJECTED, RECEIPT_REJECTION_CONFIRMED);
    }

    @Test
    @DisplayName("intra mip receipt should set transaction is local receipt as true")
    void intraMipReceiptShouldSetIsLocalTransferAsTrue() {
        //when
        receivePacs008();

        List<TransactionEntity> transactions = transactionRepository.findAll();
        assertThat(transactions).hasSize(1);

        ReceiptEntity receiptEntity = (ReceiptEntity) transactions.get(0);
        assertThat(receiptEntity.getIsLocalTransfer()).isTrue();
    }

    @Test
    void intraMipReceiptFirstLegShouldNotDoAnyTransaction() {
        receivePacs008();

        verify(never(),
            postRequestedFor(urlMatching("/api/v2/contas/[0-9]+/[0-9]+/lancamentos"))
        );

    }

    @Test
    @DisplayName("intra mip receipt should do customer transaction with QrcodeCredTransactionType")
    void intraMipReceiptShouldDoCustomerTransactionWithQrcodeCredTransactionType() {
        //given
        receiveAReceipt();

        //then
        ConfigEntity customerConfig = configurationService.findConfig();
        verify(customerTransactionCalls(),
            postRequestedFor(urlEqualTo("/api/v2/contas/" + PARTICIPANT_BRANCH + "/" + PARTICIPANT_ACCOUNT + "/lancamentos"))
                .withRequestBody(matchingJsonPath("$.lancamentos[?(@.historico == " + customerConfig.getQrcodeCredTransactionType() + " )]"))
        );

    }

    @Test
    @DisplayName("intra mip receipt should do customer transaction with QrcodeCredTransactionType")
    void intraMipReturnByAPIShouldDoCustomerTransactionWithIsDynamicQrCodeTrue() {
        //given
        var endToEndId = receiveAReceipt();

        transactionTemplate.executeWithoutResult((status) -> {
            final ReceiptEventEntity receiptEntity = (ReceiptEventEntity) eventRepository.findByCorrelationId(endToEndId);
            assertThat(receiptEntity.isDynamicQrCode()).isTrue();
        });
    }

    protected CountMatchingStrategy customerTransactionCalls() {
        return exactly(1);
    }

    private String receiveAReceipt() {
        String endToEndId = receivePacs008();

        receiveAPacs002(endToEndId, RECEIPT_SUCCESS_STATUS);

        processCreditWorkQueue();

        return endToEndId;
    }

    private void receiveAPacs002(String endToEndId, String status) {
        receiveAMessage(buildPacs002Response(buildTxInfAndSts(endToEndId, status)));
    }

    @NotNull
    private String receivePacs008() {
        String endToEndId = generateCorrelactionIdPacs008(String.valueOf(PARTICIPANT_ISPB));
        InstantPaymentsUIDTO instantPaymentsUIDTO = createInstantPaymentsUIDTOMock(endToEndId, RECEIPT);
        receiveAMessage(buildReceivedPacs008(getRandomPiResourceId(), instantPaymentsUIDTO));
        return endToEndId;
    }

    protected void stubBadRequestCreditValidation() {
        stubCreditValidation(HttpStatus.BAD_REQUEST.value());
    }

    protected void stubInternalServerErrorCreditValidation() {
        stubCreditValidation(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    private void stubCreditValidation(int status) {
        stubFor(post(urlMatching("/api/v1/accounts/[0-9]+/[0-9]+/entry/validation"))
            .willReturn(aResponse()
                .withStatus(status)
            )
        );
    }

    private void processCreditWorkQueue() {
        EventEntity receiptEventEntity = getReceiptEvent();
        accountTransactionReceiver.onMessage(new GenericMessage<>("{\"eventId\": \"" + receiptEventEntity.getId() + "\"}"));
    }

    private EventEntity getReceiptEvent() {
        List<EventEntity> events = eventRepository.findAll();

        assertThat(events).as("Should only exist the receipt event here").hasSize(1);

        return events.get(0);
    }

    private void receiveAMessage(String message) {
        messageReceiver.readIncomingMessage(message);
    }

}
