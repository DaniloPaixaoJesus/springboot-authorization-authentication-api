package matera.spi.main.flow.intraMip;

import com.matera.commons.rest.dto.MateraRestReturnDTO;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.AccountTypeDTO;
import matera.spi.dto.InstantPaymentSettlementRequestDTO;
import matera.spi.dto.InstantPaymentsUIDTO;
import matera.spi.dto.SettlementPayerDTO;
import matera.spi.main.domain.model.ConfigEntity;
import matera.spi.main.domain.model.IpAccountConfigEntity;
import matera.spi.main.domain.model.ParticipantMipEntity;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventType;
import matera.spi.main.domain.model.transaction.PaymentEntity;
import matera.spi.main.domain.model.transaction.TransactionEntity;
import matera.spi.main.domain.service.ConfigurationService;
import matera.spi.main.domain.service.CorrelationIdGenerator;
import matera.spi.main.domain.service.IpAccountConfigurationService;
import matera.spi.main.domain.service.event.receiver.MessageReceiver;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.ParticipantMipRepository;
import matera.spi.main.persistence.TransactionRepository;
import matera.spi.main.utils.AccountTransactionMocker;
import matera.spi.main.utils.InstantPaymentCreationUtils;
import matera.spi.main.utils.WireMockUtils;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.CountMatchingStrategy;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.client.RestTemplate;

import java.util.List;

import static matera.spi.main.utils.InstantPaymentCreationUtils.EXTERNAL_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.LEFT_PADDED_EXTERNAL_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.LEFT_PADDED_PARTICIPANT_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.OperationType.PAYMENT;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ACCOUNT;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_BRANCH;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_TAX_ID;
import static matera.spi.main.utils.InstantPaymentSettlementRequestCreationUtils.createSettlementRequestDTO;
import static matera.spi.main.utils.MessageCreationUtils.INTRA_MIP_PAYMENT_SUCCESS_STATUS;
import static matera.spi.main.utils.MessageCreationUtils.PAYMENT_REJECTED_STATUS;
import static matera.spi.main.utils.MessageCreationUtils.buildPacs002Response;
import static matera.spi.main.utils.MessageCreationUtils.buildTxInfAndSts;
import static matera.spi.main.utils.WireMockUtils.V_1_MESSAGES;
import static matera.spi.main.utils.WireMockUtils.never;
import static matera.spi.main.utils.verifier.EventVerifier.PAYMENT_INITIALIZED;
import static matera.spi.main.utils.verifier.EventVerifier.PAYMENT_REJECTED;
import static matera.spi.main.utils.verifier.EventVerifier.SUCCESS;
import static matera.spi.main.utils.verifier.EventVerifier.WAITING_CREDIT_VALIDATION;
import static matera.spi.main.utils.verifier.EventVerifier.verifyAllStatusTransactions;

import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.exactly;
import static com.github.tomakehurst.wiremock.client.WireMock.matching;
import static com.github.tomakehurst.wiremock.client.WireMock.matchingJsonPath;
import static com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.resetAllRequests;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlMatching;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.containsString;

@IntegrationTest
class IntraMipPaymentFlowIT {

    @LocalServerPort
    private int port;

    @Autowired
    private ParticipantMipRepository participantMipRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private EventRepository eventRepository;

    @Autowired
    private TransactionTemplate transactionTemplate;

    @Autowired
    private IpAccountConfigurationService ipAccountConfigurationService;

    @Autowired
    private ConfigurationService configurationService;

    @Autowired
    private MessageReceiver messageReceiver;

    @Autowired
    private AccountTransactionMocker accountTransactionMocker;

    private static WireMockServer wireMockServer;

    @BeforeAll
    static void beforeAll() {
        wireMockServer = WireMockUtils.start();

        WireMockUtils.stubMessaging();

        WireMockUtils.stubStandin();
    }

    @AfterAll
    static void afterAll() {
        wireMockServer.stop();
    }

    @BeforeEach
    void setUp() {

        RestAssured.port = port;

        resetAllRequests();

        participantMipRepository
            .findByIspb(PARTICIPANT_ISPB)
            .ifPresent(participantMipEntity -> {
                participantMipEntity.setIspb(EXTERNAL_ISPB);
                participantMipEntity.setDirectParticipant(false);
                participantMipRepository.saveAndFlush(participantMipEntity);
            });


        accountTransactionMocker.mockReverter();
        accountTransactionMocker.spyExecutor();

    }

    @AfterEach
    void tearDown() {
        participantMipRepository
            .findByIspb(EXTERNAL_ISPB)
            .ifPresent(participantMipRepository::delete);

        accountTransactionMocker.restoreAll();

    }
    @Test
    @DisplayName("payment should call v1/messages passing origin and destination be the receiver ispb")
    void paymentShouldCallV1MessagesPassingDestinationWithExternalIsbp() {

        //Given
        sendPaymentByAPI(port);

        verify(exactly(1),
            postRequestedFor(urlMatching(V_1_MESSAGES))
                .withRequestBody(matchingJsonPath("$.origin", equalTo(LEFT_PADDED_PARTICIPANT_ISPB)))
                .withRequestBody(matchingJsonPath("$.destination", equalTo(LEFT_PADDED_EXTERNAL_ISPB)))
                .withRequestBody(matchingJsonPath("$.messageDefinitionIdentifier", matching("pacs.008.spi.*")))
        );
    }

    @Test
    @DisplayName("intra mip payment should set transaction is local payment as true")
    void intraMipPaymentShouldSetIsLocalPaymentAsTrue() {

        //Given
        sendPaymentByAPI(port);

        List<TransactionEntity> transactions = transactionRepository.findAll();
        assertThat(transactions).hasSize(1);

        PaymentEntity paymentEntity = (PaymentEntity) transactions.get(0);
        assertThat(paymentEntity.getIsLocalPayment()).isTrue();
    }

    @Test
    @DisplayName("intra mip payment should set event status to waiting credit validation after sending")
    void intraMipPaymentShouldSetEventStatusToWaitingCreditValidationAfterSending() {

        //Given
        sendPaymentByAPI(port);

        transactionTemplate.execute(status -> {
            List<EventEntity> events = eventRepository.findAll();
            assertThat(events).hasSize(1);

            EventEntity eventEntity = events.get(0);
            verifyAllStatusTransactions(eventEntity, List.of(PAYMENT_INITIALIZED, WAITING_CREDIT_VALIDATION));

            return null;
        });

    }

    @Test
    @DisplayName("intra mip payment should do managerial transaction and not do mirror transaction")
    void intraMipPaymentShouldDoManagerialTransactionAndNotDoMirrorTransaction() {

        //Given
        sendPaymentByAPI(port);

        ParticipantMipEntity participantMip = participantMipRepository.findByIspb(PARTICIPANT_ISPB).orElse(null);

        verify(exactly(1),
            postRequestedFor(urlEqualTo("/api/v2/contas/" + participantMip.getBranch() + "/" + participantMip.getAccountNumber() + "/lancamentos"))
                .withRequestBody(matchingJsonPath("$.lancamentos[?(@.historico == " + participantMip.getDebTransactionType() + " )]"))
        );

        IpAccountConfigEntity mirrorAccountConfig = ipAccountConfigurationService.findConfig().orElse(null);

        verify(never(),
            postRequestedFor(urlEqualTo("/api/v2/contas/" + mirrorAccountConfig.getBranch() + "/" + mirrorAccountConfig.getAccountNumber() + "/lancamentos"))
        );
    }

    @Test
    @DisplayName("intra mip payment by API should do customer transaction when is direct")
    void intraMipPaymentByAPIShouldDoCustomerTransactionOnlyWhenIsDirect() {
        sendPaymentByAPI(port);

        ConfigEntity customerConfig = configurationService.findConfig();

        verify(customerTransactionCalls(),
            postRequestedFor(urlEqualTo("/api/v2/contas/" + PARTICIPANT_BRANCH + "/" + PARTICIPANT_ACCOUNT + "/lancamentos"))
                .withRequestBody(matchingJsonPath("$.lancamentos[?(@.historico == " + customerConfig.getCustomerDebTransactionType() + " )]"))
        );

    }

    protected CountMatchingStrategy customerTransactionCalls() {
        return exactly(1);
    }

    @Test
    @DisplayName("intra mip payment should generate and send pacs002 to receiver")
    void intraMipPaymentShouldGenerateAndSendPacs002ToReceiver() {

        //Given
        sendPaymentByAPI(port);

        resetAllRequests();

        //When
        receiveSuccessPacs002();

        //Then
        verify(exactly(1),
            postRequestedFor(urlMatching(V_1_MESSAGES))
                .withRequestBody(matchingJsonPath("$.origin", equalTo(LEFT_PADDED_PARTICIPANT_ISPB)))
                .withRequestBody(matchingJsonPath("$.destination", equalTo(LEFT_PADDED_EXTERNAL_ISPB)))
                .withRequestBody(matchingJsonPath("$.messageDefinitionIdentifier", matching("pacs.002.spi.*")))
                .withRequestBody(matchingJsonPath("$.messageContent", containing("<TxSts>ACSP</TxSts>")))

        );

    }

    @Test
    @DisplayName("intra mip payment should set event status to success")
    void intraMipPaymentShouldTransitToSuccess() {

        //Given
        sendPaymentByAPI(port);

        resetAllRequests();

        //When
        receiveSuccessPacs002();

        //Then
        transactionTemplate.execute(status -> {
            List<EventEntity> events = eventRepository.findAll(Sort.by(Sort.Direction.ASC, "initiationTimestampUTC"));
            assertThat(events).hasSize(1);

            EventEntity paymentEventEntity = events.get(0);

            assertThat(paymentEventEntity.getEventType()).isEqualTo(EventType.PAYMENT);
            verifyAllStatusTransactions(paymentEventEntity, List.of(PAYMENT_INITIALIZED, WAITING_CREDIT_VALIDATION, SUCCESS));

            return null;
        });

    }

    @Test
    void intraMipPaymentRejectedShouldGenerateAndSendPacs002WithStatusRejectedStatus() {

        //Given
        sendPaymentByAPI(port);

        resetAllRequests();

        //When
        receiveRejectedPacs002();

        //Then
        verify(exactly(1),
            postRequestedFor(urlMatching(V_1_MESSAGES))
                .withRequestBody(matchingJsonPath("$.origin", equalTo(LEFT_PADDED_PARTICIPANT_ISPB)))
                .withRequestBody(matchingJsonPath("$.destination", equalTo(LEFT_PADDED_EXTERNAL_ISPB)))
                .withRequestBody(matchingJsonPath("$.messageDefinitionIdentifier", matching("pacs.002.spi.*")))
                .withRequestBody(matchingJsonPath("$.messageContent", containing("<TxSts>RJCT</TxSts>")))
        );

    }

    @Test
    @DisplayName("intra mip payment should set event status to rejected when receive pacs002 with status rejected")
    void intraMipPaymentShouldTransitToRejected() {

        //Given
        sendPaymentByAPI(port);

        resetAllRequests();

        //When
        receiveRejectedPacs002();

        //Then
        transactionTemplate.execute(status -> {
            List<EventEntity> events = eventRepository.findAll(Sort.by(Sort.Direction.ASC, "initiationTimestampUTC"));
            assertThat(events).hasSize(1);

            EventEntity paymentEventEntity = events.get(0);

            assertThat(paymentEventEntity.getEventType()).isEqualTo(EventType.PAYMENT);
            verifyAllStatusTransactions(paymentEventEntity,
                List.of(PAYMENT_INITIALIZED, WAITING_CREDIT_VALIDATION, PAYMENT_REJECTED));

            return null;
        });

    }

    @Test
    void intraMipPaymentByUIShouldReturnBadRequest() {

        String endToEndId = CorrelationIdGenerator.generateCorrelactionIdPacs008(String.valueOf(PARTICIPANT_ISPB));
        InstantPaymentsUIDTO instantPaymentsUIDTOMock =
            InstantPaymentCreationUtils.createInstantPaymentsUIDTOMock(endToEndId, PAYMENT);

        RestAssured
            .given()
                .header("Authorization", "Bearer teste")
                .contentType(ContentType.JSON)
                .body(instantPaymentsUIDTOMock)
            .when()
                .post("/ui/v1/instant-payments")
            .then()
                .statusCode(HttpStatus.BAD_REQUEST.value())
                .body(containsString("It is not possible to transfer intra MIP or intra PSP through the frontend"));

        assertThat(eventRepository.findAll()).isEmpty();
    }

    private static void sendPaymentByAPI(Integer port) {
        InstantPaymentSettlementRequestDTO instantPaymentSettlementRequestDTO = getInstantPaymentSettlementRequestDTO();

        RestTemplate restTemplate = new RestTemplate();

        HttpHeaders headers = new HttpHeaders();
        headers.add("IdempotencyId", RandomStringUtils.randomAlphanumeric(10));
        headers.add("Authorization", "Bearer " + RandomStringUtils.randomAlphanumeric(10));

        HttpEntity<InstantPaymentSettlementRequestDTO> request = new HttpEntity<>(instantPaymentSettlementRequestDTO, headers);

        String url = "http://localhost:" + port + "/api/v1/settlements/instant-payments";

        restTemplate.postForObject(url, request, MateraRestReturnDTO.class);
    }

    private static InstantPaymentSettlementRequestDTO getInstantPaymentSettlementRequestDTO() {
        InstantPaymentSettlementRequestDTO instantPaymentSettlementRequestDTO = createSettlementRequestDTO();
        instantPaymentSettlementRequestDTO.getPayer().setTaxId(PARTICIPANT_TAX_ID);
        instantPaymentSettlementRequestDTO.getPayer().setPersonType(SettlementPayerDTO.PersonTypeEnum.PF);
        instantPaymentSettlementRequestDTO.getPayer().getAccount().setAccountType(AccountTypeDTO.CACC);
        return instantPaymentSettlementRequestDTO;
    }

    private void receiveSuccessPacs002() {
        receiveAPacs002(INTRA_MIP_PAYMENT_SUCCESS_STATUS);
    }

    private void receiveRejectedPacs002() {
        receiveAPacs002(PAYMENT_REJECTED_STATUS);
    }

    private void receiveAPacs002(String status) {
        List<EventEntity> events = eventRepository.findAll(Sort.by(Sort.Direction.ASC, "initiationTimestampUTC"));
        assertThat(events).hasSize(1);
        String endToEndId = events.get(0).getCorrelationId();
        receiveAMessage(buildPacs002Response(buildTxInfAndSts(endToEndId, status)));
    }

    private void receiveAMessage(String message) {
        messageReceiver.readIncomingMessage(message);
    }

}
