package matera.spi.lm.flow;

import com.matera.spi.messaging.api.MessagesApi;
import com.matera.spi.messaging.api.SPIMessagingApis;
import com.matera.spi.messaging.model.MessageSentResponseDTO;
import com.matera.spi.messaging.model.MessageSpecificationDTO;

import matera.spi.commons.IntegrationTest;
import matera.spi.lm.domain.model.event.IpAccountBalanceQueryDetailsEntity;
import matera.spi.lm.domain.model.event.IpAccountBalanceQueryEventEntity;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventStatus;
import matera.spi.main.domain.model.event.EventType;
import matera.spi.main.domain.service.MessageSender;
import matera.spi.main.domain.service.event.receiver.MessageReceiver;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.EventStatusTransitionRepository;
import matera.spi.main.persistence.MessageRepository;

import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.http.ContentType;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.messaging.support.GenericMessage;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.persistence.EntityManager;

import static matera.spi.main.utils.FileUtils.getStringFromFile;

import static io.restassured.config.JsonConfig.jsonConfig;
import static io.restassured.config.RestAssuredConfig.newConfig;
import static io.restassured.path.json.config.JsonPathConfig.NumberReturnType;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.comparesEqualTo;
import static org.hamcrest.Matchers.hasKey;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.nullValue;
import static org.hamcrest.core.Is.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;


@IntegrationTest
public class Camt053FlowIT {

    private static final String CAMT053_XML_PATH = "camt.053/camt.053_saldo_msg.xml";
    private static final String XML_IT_PATH = "src/integration-test/resources/examples";
    private static final String CAMT053_INCOMING_MESSAGE = getStringFromFile(XML_IT_PATH, CAMT053_XML_PATH);
    private static final String MESSAGE_ID = "M99999999dfg4frgh342434234324yyh";

    @LocalServerPort
    private int port;

    @Autowired
    private MessageReceiver messageReceiver;

    @Autowired
    private EventRepository eventRepository;

    @Autowired
    private MessageRepository messageRepository;

    @Autowired
    private EventStatusTransitionRepository eventStatusTransitionRepository;

    @Autowired
    private EntityManager entityManager;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private MessageSender messageSender;
    @Autowired
    private SPIMessagingApis spiMessagingApisBean;
    @Mock
    private SPIMessagingApis mockedSpiMessagingApis;
    @Mock
    private MessagesApi mockedMessagesApi;
    @Captor
    private ArgumentCaptor<MessageSpecificationDTO> messageSpecificationDTOArgumentCaptor;

    @BeforeEach
    void beforeEach() {
        RestAssured.port = port;

        when(mockedMessagesApi.sendsMessageV1(any())).thenReturn(getResponseSentDTO());
        when(mockedSpiMessagingApis.messagesApi()).thenReturn(mockedMessagesApi);
        messageSender.setSpiMessagingApis(mockedSpiMessagingApis);
    }

    @AfterEach
    void tearDown() {
        messageSender.setSpiMessagingApis(spiMessagingApisBean);
    }

    private MessageSentResponseDTO getResponseSentDTO() {
        MessageSentResponseDTO messageSentResponseDTO = new MessageSentResponseDTO();
        messageSentResponseDTO.setPiResourceID("SentPiResourceID");
        return messageSentResponseDTO;
    }

    private void createBalanceQuery() throws JSONException {
        JSONObject jsonObject = new JSONObject().put("referenceDate", LocalDate.now());

        RestAssured
            .given()
                .contentType(ContentType.JSON)
                .body(jsonObject.toString())
            .when()
                .post("/ui/v1/ip-account/balance/queries");
    }


    private void sendDetailsMessage() throws Exception {
        messageReceiver.onMessage(getIncomingMessage());

        Thread.sleep(5000L); // Wait for jms to be processed
    }

    @Test
    void shouldCreateBdaalanceQueryEventOnRestPOST() throws JSONException {
        createBalanceQuery();

        List<EventEntity> events = eventRepository.findAll();
        assertThat(events, hasSize(1));

        IpAccountBalanceQueryEventEntity firstEvent = (IpAccountBalanceQueryEventEntity) events.get(0);
        IpAccountBalanceQueryDetailsEntity eventDetails = getDetailsEntity();

        assertThat(firstEvent.getEventType().getCode(), is(EventType.IP_ACCOUNT_BALANCE_QUERY.getCode()));
        assertThat(firstEvent.getStatus().getCode(), is(EventStatus.QUERY_SENT.getCode()));
        assertThat(eventDetails.getBalanceAvailable(), is(nullValue()));
        assertThat(eventDetails.getBalanceBlocked(), is(nullValue()));
    }


    @Test
    void shouldReturnAnEventWithoutBalancesValuesOnRestGET() throws JSONException{
        createBalanceQuery();

        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");

        RestAssured
            .given()
                .queryParam("startTimestampUtc", LocalDateTime.now().minusDays(1).format(dateTimeFormatter))
                .queryParam("endTimestampUtc", LocalDateTime.now().plusDays(1).format(dateTimeFormatter ))
                .header("pageSize", 10)
                .header("pageNumber", 0)
            .when()
                .get("/ui/v1/ip-account/balance/queries")
            .then()
                .log().all().and()
                .assertThat()
                    .body("data.content", hasSize(1))
                    .body("data.content[0].balances.availableBalance", not(hasKey("value")))
                    .body("data.content[0].balances.blockedBalance", not(hasKey("value")));
    }

    @Test
    void shouldFillEventDetailsOnMessageReceiver() throws Exception {
        createBalanceQuery();
        sendDetailsMessage();

        IpAccountBalanceQueryDetailsEntity eventDetails = getDetailsEntity();

        assertThat(eventDetails.getBalanceAvailable(), comparesEqualTo(BigDecimal.valueOf(1200000L)));
        assertThat(eventDetails.getBalanceBlocked(), comparesEqualTo(BigDecimal.valueOf(800000L)));
    }

    @Test
    public void shouldReturnBalancesValuesOnRestGET() throws Exception {
        createBalanceQuery();
        sendDetailsMessage();

        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
        RestAssuredConfig config = newConfig().jsonConfig(jsonConfig().numberReturnType(NumberReturnType.BIG_DECIMAL));

        RestAssured
            .given()
                .config(config)
                .queryParam("startTimestampUtc", LocalDateTime.now().minusDays(1).format(dateTimeFormatter))
                .queryParam("endTimestampUtc", LocalDateTime.now().format(dateTimeFormatter ))
                .header("pageSize", 10)
                .header("pageNumber", 0)
            .when()
                .get("/ui/v1/ip-account/balance/queries")
            .then()
              .log().all().and()
            .assertThat()
                .body("data.content", hasSize(1))
                .body("data.content[0].balances.availableBalance", hasKey("value"))
                .body("data.content[0].balances.blockedBalance", hasKey("value"));
    }

    private IpAccountBalanceQueryDetailsEntity getDetailsEntity() {
        String query = "SELECT event " +
                       "  FROM IpAccountBalanceQueryEventEntity event " +
                       " JOIN FETCH event.ipAccountBalanceQueryDetailsEntity";

        return entityManager
            .createQuery(query, IpAccountBalanceQueryEventEntity.class)
            .getResultList()
            .get(0)
            .getIpAccountBalanceQueryDetailsEntity();
    }

    private void clearDatabase() {
        eventStatusTransitionRepository.deleteAll();
        messageRepository.deleteAll();
        eventRepository.deleteAll();
    }

    private GenericMessage<String> getIncomingMessage() throws JSONException {
        verify(mockedMessagesApi, atLeastOnce()).sendsMessageV1(messageSpecificationDTOArgumentCaptor.capture());
        MessageSpecificationDTO messageSpecificationDTO = messageSpecificationDTOArgumentCaptor.getValue();

        JSONObject jsonObject = new JSONObject()
            .put("piResourceId", "ReceivePiResourceID")
            .put("xml", CAMT053_INCOMING_MESSAGE.replace(MESSAGE_ID, messageSpecificationDTO.getMessageId()))
            .put("messageType", "camt.053");

        return new GenericMessage<>(jsonObject.toString());
    }

}
