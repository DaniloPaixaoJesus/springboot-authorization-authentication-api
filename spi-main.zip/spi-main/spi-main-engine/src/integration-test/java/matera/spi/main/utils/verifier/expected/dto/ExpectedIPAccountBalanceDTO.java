package matera.spi.main.utils.verifier.expected.dto;

import lombok.Builder;
import lombok.Data;
import matera.spi.main.domain.model.enums.EnumTransactionType;

import java.math.BigDecimal;

@Data
@Builder
public class ExpectedIPAccountBalanceDTO {
	EnumTransactionType transactionType;
	BigDecimal balanceAfterTransaction;
	BigDecimal transactionValue;
}
