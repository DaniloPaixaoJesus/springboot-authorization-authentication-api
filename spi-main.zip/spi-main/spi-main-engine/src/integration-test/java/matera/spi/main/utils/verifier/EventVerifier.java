package matera.spi.main.utils.verifier;

import matera.spi.dto.PaymentsUIDTO;
import matera.spi.dto.ReturnSettlementUIWapperDTO;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventStatusTransitionEntity;
import matera.spi.main.domain.service.PrincipalAuthenticationService;
import matera.spi.main.utils.verifier.expected.dto.ExpectedEventDTO;

import org.assertj.core.api.SoftAssertions;
import org.jetbrains.annotations.NotNull;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static matera.spi.main.utils.CustomAssertions.assertThatIsCloseToNow;
import static matera.spi.main.utils.InstantPaymentCreationUtils.CLEARING_RESPONSE_DATE_TIME;

import static org.assertj.core.api.Assertions.assertThat;

public class EventVerifier {

    public static final String PAYMENT_INITIALIZED = "Payment initialized";
	public static final String WAITING_PAYMENT_CONFIRM = "Waiting payment confirm";
	public static final String PAYMENT_REJECTED = "Payment rejected";
	public static final String RECEIPT_RECEIVED = "Receipt received";
	public static final String ERROR = "Error";
	public static final String WAITING_RECEIPT_CONFIRM = "Waiting receipt confirm";
	public static final String RECEIPT_REJECTED = "Receipt rejected";
	public static final String RECEIPT_REJECTED_BY_CLEARING = "Receipt Rejected by Clearing";
	public static final String RECEIPT_REJECTION_CONFIRMED = "Receipt Rejection confirmed";
    public static final String PENDING_CREDIT_ACCOUNT_HOLDER = "Pending credit account holder";
	public static final String SUCCESS = "Success";
    public static final String RETURN_INITIATED = "Return initiated";
    public static final String WAITING_RETURN_CONFIRM = "Waiting return confirm";
    public static final String RETURN_REJECTED = "Return rejected";
    public static final String RETURN_RECEIVED = "Return received";
    public static final String RETURN_REJECTED_BY_CLEARING = "Return rejected by Clearing";
    public static final String RETURN_REJECTION_CONFIRMED = "Return rejection confirmed";
    public static final String WAITING_CREDIT_VALIDATION = "Waiting credit validation";

    private EventVerifier() {/*utility classes should not be instantiated*/}

	private static void verifyEvent(EventEntity actual, ExpectedEventDTO expected) {
		assertThat(actual.getEventType()).isEqualTo(expected.getType());
		assertThat(actual.getEventTypeEntity().getDescription()).isEqualTo(expected.getTypeDescription());
		assertThatIsCloseToNow(actual.getInitiationTimestampUTC());
		assertThat(actual.getInitiatorIspb()).isEqualTo(expected.getInitiatorISPB());
		assertThat(actual.getStatus().getDescription()).isEqualTo(expected.getStatusDescription());

		if (expected.hasTransactionResult()) {
			assertThat(actual.getIpAccountTransactionResult().getReverted()).isEqualTo(expected.isExpectedBeReverted());
			assertThat(actual.getIpAccountTransactionResult().getTransactionIdInDdaSystem()).isNotNull();
            assertThat(actual.getTransactionResult().getReverted()).isEqualTo(expected.isExpectedBeReverted());
            assertThat(actual.getTransactionResult()).isNotNull();
		} else {
			assertThat(actual.getIpAccountTransactionResult()).isNull();
            assertThat(actual.getTransactionResult()).isNull();
		}

		assertThat(actual.getCorrelationId()).isEqualTo(expected.getCorrelationId());
		assertThat(actual.getClearingTimestampUTC()).isEqualTo(expected.getClearingTimestamp());
		assertThat(actual.getValue().doubleValue()).isEqualTo(expected.getValue());
		assertThat(actual.getOriginalCorrelationId()).isEqualTo(expected.getOriginalCorrelationId());
        assertThat(actual.getOriginalEvent()).isEqualTo(expected.getOriginalEvent());

	}

	public static void verifyPaymentEventIsWaitingConfirm(EventEntity actual, PaymentsUIDTO paymentsUIDTO) {
		ExpectedEventDTO expectedEvent = ExpectedEventDTO.paymentFromInstantPaymentsUIDTO(paymentsUIDTO)
				.statusDescription(WAITING_PAYMENT_CONFIRM)
				.build();
		verifyEvent(actual, expectedEvent);
		verifyAllStatusTransactions(actual, List.of(PAYMENT_INITIALIZED, WAITING_PAYMENT_CONFIRM));
	}

	public static void verifyPaymentEventIsSuccess(EventEntity actual, PaymentsUIDTO paymentsUIDTO) {
		ExpectedEventDTO expectedEvent = ExpectedEventDTO.paymentFromInstantPaymentsUIDTO(paymentsUIDTO)
				.statusDescription(SUCCESS)
				.clearingTimestamp(CLEARING_RESPONSE_DATE_TIME)
				.build();
		verifyEvent(actual, expectedEvent);
        verifyAllStatusTransactions(actual, List.of(PAYMENT_INITIALIZED, WAITING_PAYMENT_CONFIRM, SUCCESS));
	}

	public static void verifyPaymentEventIsRejected(EventEntity actual, PaymentsUIDTO paymentsUIDTO) {
		ExpectedEventDTO expectedEvent = ExpectedEventDTO.paymentFromInstantPaymentsUIDTO(paymentsUIDTO)
				.statusDescription(PAYMENT_REJECTED)
				.clearingTimestamp(CLEARING_RESPONSE_DATE_TIME)
				.isReverted(true)
				.build();
		verifyEvent(actual, expectedEvent);
        verifyAllStatusTransactions(actual, List.of(PAYMENT_INITIALIZED, WAITING_PAYMENT_CONFIRM, PAYMENT_REJECTED));
	}

	public static void verifyReceiptEventIsWaitingConfirm(EventEntity actual, PaymentsUIDTO paymentsUIDTO) {
		ExpectedEventDTO expectedEvent = ExpectedEventDTO.receiptFromInstantPaymentsUIDTO(paymentsUIDTO)
				.statusDescription(WAITING_RECEIPT_CONFIRM)
				.build();
		verifyEvent(actual, expectedEvent);
        verifyAllStatusTransactions(actual, List.of(RECEIPT_RECEIVED, WAITING_RECEIPT_CONFIRM));
	}

	public static void verifyReceiptEventIsPendingCreditAccountHolder(EventEntity actual, PaymentsUIDTO paymentsUIDTO) {
		ExpectedEventDTO expectedEvent = ExpectedEventDTO.receiptFromInstantPaymentsUIDTO(paymentsUIDTO)
				.statusDescription(PENDING_CREDIT_ACCOUNT_HOLDER)
				.clearingTimestamp(CLEARING_RESPONSE_DATE_TIME)
				.hasTransactionResult(true)
				.build();
		verifyEvent(actual, expectedEvent);
        verifyAllStatusTransactions(actual, List.of(RECEIPT_RECEIVED, WAITING_RECEIPT_CONFIRM, PENDING_CREDIT_ACCOUNT_HOLDER));
	}

	public static void verifyReceiptEventIsRejectedByTheClearing(EventEntity actual, PaymentsUIDTO paymentsUIDTO) {
		ExpectedEventDTO expectedEvent = ExpectedEventDTO.receiptFromInstantPaymentsUIDTO(paymentsUIDTO)
				.statusDescription(RECEIPT_REJECTED_BY_CLEARING)
				.clearingTimestamp(CLEARING_RESPONSE_DATE_TIME)
				.build();
		verifyEvent(actual, expectedEvent);
        verifyAllStatusTransactions(actual, List.of(RECEIPT_RECEIVED, WAITING_RECEIPT_CONFIRM, RECEIPT_REJECTED_BY_CLEARING));
	}

	public static void verifyReceiptEventIsRejected(EventEntity actual, PaymentsUIDTO paymentsUIDTO) {
		ExpectedEventDTO expectedEvent = ExpectedEventDTO.receiptFromInstantPaymentsUIDTO(paymentsUIDTO)
				.statusDescription(RECEIPT_REJECTED)
				.build();
		verifyEvent(actual, expectedEvent);
        verifyAllStatusTransactions(actual, List.of(RECEIPT_RECEIVED, RECEIPT_REJECTED));
	}

	public static void verifyReceiptEventIsRejectionConfirmed(EventEntity actual, PaymentsUIDTO paymentsUIDTO) {
		ExpectedEventDTO expectedEvent = ExpectedEventDTO.receiptFromInstantPaymentsUIDTO(paymentsUIDTO)
				.statusDescription(RECEIPT_REJECTION_CONFIRMED)
				.clearingTimestamp(CLEARING_RESPONSE_DATE_TIME)
				.build();
		verifyEvent(actual, expectedEvent);
        verifyAllStatusTransactions(actual, List.of(RECEIPT_RECEIVED, RECEIPT_REJECTED, RECEIPT_REJECTION_CONFIRMED));
	}

    public static void verifyReturnSentEventIsWaitingConfirm(EventEntity actual,
                                                             ReturnSettlementUIWapperDTO returnSettlementUIWapperDTO,
                                                             EventEntity originalEventEntity) {
        ExpectedEventDTO expectedEvent = ExpectedEventDTO.returnSentFromReturnSettlementUIWapperDTO(returnSettlementUIWapperDTO, originalEventEntity)
            .statusDescription(WAITING_RETURN_CONFIRM)
            .build();
        verifyEvent(actual, expectedEvent);
        verifyAllStatusTransactions(actual, List.of(RETURN_INITIATED, WAITING_RETURN_CONFIRM));
    }

    public static void verifyReturnSentEventIsSuccess(EventEntity actual,
                                                             ReturnSettlementUIWapperDTO returnSettlementUIWapperDTO,
                                                             EventEntity originalEventEntity) {
        ExpectedEventDTO expectedEvent = ExpectedEventDTO.returnSentFromReturnSettlementUIWapperDTO(returnSettlementUIWapperDTO, originalEventEntity)
            .statusDescription(SUCCESS)
            .clearingTimestamp(CLEARING_RESPONSE_DATE_TIME)
            .build();
        verifyEvent(actual, expectedEvent);
        verifyAllStatusTransactions(actual, List.of(RETURN_INITIATED, WAITING_RETURN_CONFIRM, SUCCESS));
    }

    public static void verifyReturnSentEventIsReturnReject(EventEntity actual,
                                                      ReturnSettlementUIWapperDTO returnSettlementUIWapperDTO,
                                                      EventEntity originalEventEntity) {
        ExpectedEventDTO expectedEvent = ExpectedEventDTO.returnSentFromReturnSettlementUIWapperDTO(returnSettlementUIWapperDTO, originalEventEntity)
            .statusDescription(RETURN_REJECTED)
            .clearingTimestamp(CLEARING_RESPONSE_DATE_TIME)
            .isReverted(true)
            .build();
        verifyEvent(actual, expectedEvent);
        verifyAllStatusTransactions(actual, List.of(RETURN_INITIATED, WAITING_RETURN_CONFIRM, RETURN_REJECTED));
    }

    public static void verifyReturnReceiverEventIsWaitingConfirm(EventEntity actual,
                                                             ReturnSettlementUIWapperDTO returnSettlementUIWapperDTO,
                                                             EventEntity originalEventEntity) {
        ExpectedEventDTO expectedEvent = ExpectedEventDTO.returnReceivedFromReturnSettlementUIWapperDTO(returnSettlementUIWapperDTO, originalEventEntity)
            .statusDescription(WAITING_RETURN_CONFIRM)
            .build();
        verifyEvent(actual, expectedEvent);
        verifyAllStatusTransactions(actual, List.of(RETURN_RECEIVED, WAITING_RETURN_CONFIRM));
    }

    public static void verifyReturnReceiverEventIsPendingCreditAccountHolder(EventEntity actual,
                                                                             ReturnSettlementUIWapperDTO returnSettlementUIWapperDTO,
                                                                             EventEntity originalEventEntity) {
        ExpectedEventDTO expectedEvent = ExpectedEventDTO.returnReceivedFromReturnSettlementUIWapperDTO(returnSettlementUIWapperDTO, originalEventEntity)
            .statusDescription(PENDING_CREDIT_ACCOUNT_HOLDER)
            .clearingTimestamp(CLEARING_RESPONSE_DATE_TIME)
            .hasTransactionResult(true)
            .build();
        verifyEvent(actual, expectedEvent);
        verifyAllStatusTransactions(actual, List.of(RETURN_RECEIVED, WAITING_RETURN_CONFIRM, PENDING_CREDIT_ACCOUNT_HOLDER));
    }

    public static void verifyReturnReceiverEventIsRejectedByClearing(EventEntity actual,
                                                          ReturnSettlementUIWapperDTO returnSettlementUIWapperDTO,
                                                          EventEntity originalEventEntity) {
        ExpectedEventDTO expectedEvent = ExpectedEventDTO.returnReceivedFromReturnSettlementUIWapperDTO(returnSettlementUIWapperDTO, originalEventEntity)
            .statusDescription(RETURN_REJECTED_BY_CLEARING)
            .clearingTimestamp(CLEARING_RESPONSE_DATE_TIME)
            .build();
        verifyEvent(actual, expectedEvent);
        verifyAllStatusTransactions(actual, List.of(RETURN_RECEIVED, WAITING_RETURN_CONFIRM, RETURN_REJECTED_BY_CLEARING));
    }

    public static void verifyReturnReceiverEventIsReturnRejectionConfirmed(EventEntity actual,
                                                                     ReturnSettlementUIWapperDTO returnSettlementUIWapperDTO,
                                                                     EventEntity originalEventEntity) {
        ExpectedEventDTO expectedEvent = ExpectedEventDTO.returnReceivedFromReturnSettlementUIWapperDTO(returnSettlementUIWapperDTO, originalEventEntity)
            .statusDescription(RETURN_REJECTION_CONFIRMED)
            .clearingTimestamp(CLEARING_RESPONSE_DATE_TIME)
            .build();
        verifyEvent(actual, expectedEvent);
        verifyAllStatusTransactions(actual, List.of(RETURN_RECEIVED, RETURN_REJECTED, RETURN_REJECTION_CONFIRMED));
    }

    public static void verifyAllStatusTransactions(EventEntity actual, List<String> expectedStatuses) {
        assertThat(actual.getEventStatusTransitionEntities()).hasSize(expectedStatuses.size());

        SoftAssertions softly = new SoftAssertions();
        String lastStatus = expectedStatuses.get(expectedStatuses.size() - 1);
        softly.assertThat(actual.getStatus().getDescription()).isEqualTo(lastStatus);
        List<EventStatusTransitionEntity> eventStatusTransitionEntityList = getEventStatusTransitionEntities(actual);
        IntStream.range(0, expectedStatuses.size()).forEach(i -> verifyStatusTransition(softly, eventStatusTransitionEntityList.get(i), actual, expectedStatuses.get(i)));
        softly.assertAll();
    }

    @NotNull
	private static List<EventStatusTransitionEntity> getEventStatusTransitionEntities(EventEntity actual) {
		return actual.getEventStatusTransitionEntities().stream()
					.sorted(Comparator.comparing(EventStatusTransitionEntity::getTimestamp))
					.collect(Collectors.toList());
	}

	private static void verifyStatusTransition(SoftAssertions softly, EventStatusTransitionEntity actualStatusTransition, EventEntity relatedEvent, String expectedStatus) {
        softly.assertThat(actualStatusTransition.getEvent().getId()).isEqualTo(relatedEvent.getId());
        softly.assertThat(actualStatusTransition.getEventStatusCode().getDescription()).isEqualTo(expectedStatus);
        softly.assertThat(actualStatusTransition.getResponsible()).isEqualTo(PrincipalAuthenticationService.RESPONSIBLE_FOR_NEW_EVENTS_FROM_RECEIVED_MESSAGES);
		assertThatIsCloseToNow(softly, actualStatusTransition.getTimestamp());
	}

}
