package matera.spi.main.utils;

import com.matera.spi.messaging.api.MessagesApi;
import com.matera.spi.messaging.api.impl.SPIMessagingApisImpl;

import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.test.util.ReflectionTestUtils;

@Component
public class MockMessagingHelper {

    @Autowired
    private SPIMessagingApisImpl spiMessagingApis;
    private MessagesApi originalMessagesApi;

    public MessagesApi mock() {
        originalMessagesApi = spiMessagingApis.messagesApi();
        MessagesApi mockedMessageApi = Mockito.mock(originalMessagesApi.getClass());
        ReflectionTestUtils.setField(spiMessagingApis, "messagesApiImpl",  mockedMessageApi);
        return mockedMessageApi;
    }

    public void restore() {
        ReflectionTestUtils.setField(spiMessagingApis, "messagesApiImpl",  originalMessagesApi);
    }

}
