package matera.spi.indirect.flow;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.matera.spi.messaging.model.MessageSpecificationDTO;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import matera.spi.commons.IntegrationTest;
import matera.spi.main.utils.WireMockUtils;
import org.apache.http.HttpStatus;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static matera.spi.main.utils.WireMockUtils.V_1_MESSAGES;

@Slf4j
@IntegrationTest
public class IndirectActiveStateFlowIT extends IndirectBaseStateFlowIT {

    private static final WireMockServer wireMockServer = WireMockUtils.start();

    @BeforeAll
    public static void baseBeforeAll() {
        WireMockUtils.stubMessaging();
    }

    @AfterAll
    public static void baseAfterAll() {
        wireMockServer.stop();
    }

    @Test
    public void shouldCreateAndSendIndirectToClearing() {
        registryIndirectWithSuccess();
    }

    @Test
    public void shouldCreateAndSendIndirectToClearingReceivingReda016RejtInd2AndActiveIndirect() {

        String registryJson = getFileAsString(FILE_JSON_INDIRECT_REGISTER);
        Response registryResponse = RestAssured
            .given()
            .body(registryJson)
            .contentType(ContentType.JSON)
            .post(URN_INDIRECT_REGISTER);
        Assertions.assertEquals(HttpStatus.SC_CREATED, registryResponse.statusCode());

        String getResponseJson = getParticipantByIspb(INDIRECT_ISPB);
        String expectedWaitingToSend = getFileAsString(FILE_JSON_INDIRECT_WAITING_TO_SEND_REGISTRY);
        Assertions.assertEquals(expectedWaitingToSend, getResponseJson);

        Response sendToClearingResponse = RestAssured
            .given()
            .pathParam(PATH_PARAMETER_ISPB, INDIRECT_ISPB)
            .post(URN_INDIRECT_SEND_REGISTRY_TO_CLEARING);
        Assertions.assertEquals(HttpStatus.SC_ACCEPTED, sendToClearingResponse.statusCode());

        getResponseJson = getParticipantByIspb(INDIRECT_ISPB);
        String expectedWaitingClearingResponse = getFileAsString(FILE_JSON_INDIRECT_WAITING_CLEARING_REGISTRY_RESPONSE);
        Assertions.assertEquals(expectedWaitingClearingResponse, getResponseJson);

        String messageSent = WireMockUtils
            .getFirstBodyFrom(WireMock.postRequestedFor(WireMock.urlEqualTo(V_1_MESSAGES)), MessageSpecificationDTO.class)
            .getMessageContent()
            .trim();
        String expectedSentToClearing = getFileAsString(FILE_REDA014);
        Assertions.assertEquals(extractValueFromXml(expectedSentToClearing, BODY_REDA014_TAG), extractValueFromXml(messageSent, BODY_REDA014_TAG));

        String reda016Rejected = customizeReda016(getFileAsString(FILE_REDA016_REJECTED), extractValueFromXml(messageSent, MSG_ID_TAG), REDA016_REASON_CODE_IND2);
        sendRedaToMessageReceiver(MSG_TYPE_REDA016, reda016Rejected);
        getResponseJson = getParticipantByIspb(INDIRECT_ISPB);
        String expectedActiveResponse = getFileAsString(FILE_JSON_INDIRECT_ACTIVE);
        Assertions.assertEquals(expectedActiveResponse, getResponseJson);

    }

    @Test
    public void shouldCreateAndSendIndirectToClearingReceivingReda016RejtNotInd2AndRedirectStateToEditIndirect() {

        String registryJson = getFileAsString(FILE_JSON_INDIRECT_REGISTER);
        Response registryResponse = RestAssured
            .given()
            .body(registryJson)
            .contentType(ContentType.JSON)
            .post(URN_INDIRECT_REGISTER);
        Assertions.assertEquals(HttpStatus.SC_CREATED, registryResponse.statusCode());

        String getResponseJson = getParticipantByIspb(INDIRECT_ISPB);
        String expectedWaitingToSend = getFileAsString(FILE_JSON_INDIRECT_WAITING_TO_SEND_REGISTRY);
        Assertions.assertEquals(expectedWaitingToSend, getResponseJson);

        Response sendToClearingResponse = RestAssured
            .given()
            .pathParam(PATH_PARAMETER_ISPB, INDIRECT_ISPB)
            .post(URN_INDIRECT_SEND_REGISTRY_TO_CLEARING);
        Assertions.assertEquals(HttpStatus.SC_ACCEPTED, sendToClearingResponse.statusCode());

        getResponseJson = getParticipantByIspb(INDIRECT_ISPB);
        String expectedWaitingClearingResponse = getFileAsString(FILE_JSON_INDIRECT_WAITING_CLEARING_REGISTRY_RESPONSE);
        Assertions.assertEquals(expectedWaitingClearingResponse, getResponseJson);

        String messageSent = WireMockUtils
            .getFirstBodyFrom(WireMock.postRequestedFor(WireMock.urlEqualTo(V_1_MESSAGES)), MessageSpecificationDTO.class)
            .getMessageContent()
            .trim();
        String expectedSentToClearing = getFileAsString(FILE_REDA014);
        Assertions.assertEquals(extractValueFromXml(expectedSentToClearing, BODY_REDA014_TAG), extractValueFromXml(messageSent, BODY_REDA014_TAG));


        String reda016Rejected = customizeReda016(getFileAsString(FILE_REDA016_REJECTED), extractValueFromXml(messageSent, MSG_ID_TAG), REDA016_REASON_CODE_ANOTHER);
        sendRedaToMessageReceiver(MSG_TYPE_REDA016, reda016Rejected);
        getResponseJson = getParticipantByIspb(INDIRECT_ISPB);
        String expectedActiveResponse = getFileAsString(FILE_JSON_INDIRECT_REJECTED);
        Assertions.assertEquals(expectedActiveResponse, getResponseJson);
    }

}
