package matera.spi.main.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.CountMatchingStrategy;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import com.github.tomakehurst.wiremock.matching.RequestPatternBuilder;
import com.github.tomakehurst.wiremock.verification.LoggedRequest;
import lombok.SneakyThrows;
import org.apache.http.entity.ContentType;
import org.jetbrains.annotations.NotNull;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

import java.util.List;
import java.util.stream.Collectors;

import static matera.spi.main.utils.DynamicPiResourceIdStubResponseTransformer.DYNAMIC_PI_RESOURCE_ID_RESPONSE_TRANSFORMER;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.configureFor;
import static com.github.tomakehurst.wiremock.client.WireMock.exactly;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlMatching;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
public class WireMockUtils {

    public static final String V1_CREDITS = "/v1/credits";
    public static final String WEBHOOK_V1_TRANSACTION_CALLBACK = "/webhook/v1/transaction/callback/.*";

    private WireMockUtils() {/* utility class should not be instantiated*/}
    public static final String V_1_MESSAGES = "/v1/messages/";
    public static final String WIREMOCK_RESPONSE_DIR = "wiremock/json/responses/";
    public static final int WIREMOCK_PORT = 8088;

    public static final DynamicPiResourceIdStubResponseTransformer DYNAMIC_PI_RESOURCE_ID_STUB_RESPONSE_TRANSFORMER =
        new DynamicPiResourceIdStubResponseTransformer();

    private static final WireMockConfiguration WIREMOCK_CONFIG = wireMockConfig()
        .port(WIREMOCK_PORT)
        .extensions(DYNAMIC_PI_RESOURCE_ID_STUB_RESPONSE_TRANSFORMER);

    /**
     * *Don't forget to call wiremock.stop with the result of this method*
     */
    public static WireMockServer start() {
        DYNAMIC_PI_RESOURCE_ID_STUB_RESPONSE_TRANSFORMER.clearLastPiResourceId();
        WireMockServer wireMockServer = new WireMockServer(WIREMOCK_CONFIG);
        wireMockServer.start();
        configureFor(WIREMOCK_PORT);
        return wireMockServer;
    }

    public static String getLastPiResourceId(){
        return DYNAMIC_PI_RESOURCE_ID_STUB_RESPONSE_TRANSFORMER.getLastPiResourceId();
    }

    public static void stubMessaging() {
        stubFor(post(V_1_MESSAGES)
            .willReturn(aResponse()
                .withStatus(HttpStatus.OK.value())
                .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .withTransformers(DYNAMIC_PI_RESOURCE_ID_RESPONSE_TRANSFORMER)
            )
        );
    }

    public static void stubStandin() {
        stubFor(post(urlMatching("/api/v2/contas/[0-9]+/[0-9]+/lancamentos"))
            .willReturn(aResponse()
                .withStatus(HttpStatus.OK.value())
                .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .withBodyFile(WIREMOCK_RESPONSE_DIR + "v2_contas_lancamentos_response.json")
            )
        );
    }

    public static void stubStandinEntryValidation() {
        stubFor(post(urlMatching("/api/v1/accounts/[0-9]+/[0-9]+/entry/validation"))
            .willReturn(aResponse()
                .withStatus(HttpStatus.NO_CONTENT.value())
            )
        );
    }

    public static void stubV1CreditsEntryValidation() {
        stubFor(post(urlMatching(V1_CREDITS))
            .willReturn(aResponse()
                .withStatus(HttpStatus.OK.value())
                .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .withBody("{ \"data\": { \"transactionId\": \"bdcd0123-10a7-4d13-826d-f8474b9e7b0f\" } }")
            )
        );
    }

    public static void stubWebhookValidation() {
        stubFor(post(urlMatching("/webhook/v1/transaction/validation/.*"))
            .willReturn(aResponse()
                .withStatus(HttpStatus.OK.value())
                .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .withBody("{\"data\": {\"shouldReceive\": true, \"callback\": true, \"isDynamicQRCode\": true } }")
            )
        );
    }

    public static void stubV1IpAccount() {
        stubFor(get(urlMatching("/api/v1/ip-account"))
            .willReturn(aResponse()
                .withStatus(HttpStatus.OK.value())
                .withHeader(HttpHeaders.CONTENT_TYPE, ContentType.APPLICATION_JSON.toString())
                .withBodyFile(WIREMOCK_RESPONSE_DIR + "v1_ip_account_response.json")
            )
        );
    }

    public static void stubV1IndirectsForIntraMip() {
        stubFor(get(urlMatching("/api/v1/indirects\\?onlyActiveIndirects=true&showCanceledIndirects=false"))
            .willReturn(aResponse()
                .withStatus(HttpStatus.OK.value())
                .withHeader(HttpHeaders.CONTENT_TYPE, ContentType.APPLICATION_JSON.toString())
                .withBodyFile(WIREMOCK_RESPONSE_DIR + "intra_mip_v1_indirects_response.json")
            )
        );
    }

    public static <T> List<T> getBodiesFrom(RequestPatternBuilder requestPatternBuilder, Class<T> bodyClass) {
        ObjectMapper om = getObjectMapper();
        return WireMock.findAll(requestPatternBuilder)
            .stream()
            .map(request -> bodyStringToObject(bodyClass, om, request.getBodyAsString()))
            .collect(Collectors.toList());
    }
    public static <T> T getFirstBodyFrom(RequestPatternBuilder requestPatternBuilder, Class<T> bodyClass) {
        List<LoggedRequest> requests = WireMock.findAll(requestPatternBuilder);
        assert !requests.isEmpty();
        return bodyStringToObject(bodyClass, getObjectMapper(), requests.get(0).getBodyAsString());
    }
    @NotNull
    private static ObjectMapper getObjectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        return objectMapper;
    }
    @SneakyThrows
    private static <T> T bodyStringToObject(Class<T> bodyClass,
                                            ObjectMapper om,
                                            String bodyString) {
        return om.readValue(bodyString, bodyClass);
    }
    @NotNull
    public static CountMatchingStrategy never() {
        return exactly(0);
    }
}
