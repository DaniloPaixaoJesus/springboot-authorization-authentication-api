package matera.spi.main.flow;

import com.matera.client.rest.exception.RestBadRequestException;
import com.matera.commons.rest.dto.MateraRestErrorDTO;
import com.matera.spi.messaging.api.MessagesApi;
import com.matera.spi.messaging.api.SPIMessagingApis;
import com.matera.spi.messaging.model.MessageSentResponseDTO;
import com.matera.spi.messaging.model.MessageSpecificationDTO;
import com.matera.spi.webhook.transaction.model.TransactionIdValidationResponseDTO;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.InstantPaymentsUIDTO;
import matera.spi.dto.ReceiverUIDTO;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.transaction.ReceiptEventEntity;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.domain.model.transaction.TransactionEntity;
import matera.spi.main.domain.service.CorrelationIdGenerator;
import matera.spi.main.domain.service.MessageCatalogSpecificationService;
import matera.spi.main.domain.service.MessageSender;
import matera.spi.main.domain.service.ReceiptEventValidator;
import matera.spi.main.domain.service.TransactionRejectReasonStandinService;
import matera.spi.main.domain.service.WebhookTransactionValidationService;
import matera.spi.main.domain.service.event.receiver.MessageReceiver;
import matera.spi.main.domain.service.event.transaction.validation.DirectPSPCreditEventValidator;
import matera.spi.main.domain.service.transaction.CustomerAccount;
import matera.spi.main.exception.EventValidatorException;
import matera.spi.main.persistence.BalanceAccountPiRepository;
import matera.spi.main.utils.InstantPaymentCreationUtils.OperationType;
import matera.spi.main.utils.TransactionEntitiesService;
import matera.spi.main.utils.verifier.EventVerifier;
import matera.spi.main.utils.verifier.ReceiptVerifier;
import matera.spi.main.utils.verifier.ReceiptVerifier.ReceiptVerifierBuilder;

import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.persistence.EntityManager;

import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.createInstantPaymentsUIDTOMock;
import static matera.spi.main.utils.InstantPaymentCreationUtils.createMessageSentResponseDTO;
import static matera.spi.main.utils.InstantPaymentCreationUtils.getRandomPiResourceId;
import static matera.spi.main.utils.MessageCreationUtils.buildPacs002Response;
import static matera.spi.main.utils.MessageCreationUtils.buildReceivedPacs008;
import static matera.spi.main.utils.MessageCreationUtils.buildTxInfAndSts;
import static matera.spi.main.utils.verifier.IPAccountBalanceVerifier.verifyAccountBalance;
import static matera.spi.main.utils.verifier.MessageSenderVerifier.verifyMessagesApiWasCalledWithExternalOriginAndDestination;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

@IntegrationTest
@Transactional
class ReceiptFlowIT {

    @Autowired
    private MessageSender messageSender;
    @Autowired
    private SPIMessagingApis spiMessagingApisBean;
    @Mock
    private SPIMessagingApis mockedSpiMessagingApis;
    @Mock
    private MessagesApi mockedMessagesApi;
    @Autowired
    private DirectPSPCreditEventValidator directPSPCreditEventValidator;
    @Autowired
    private ReceiptEventValidator receiptEventValidator;
    @Autowired
    private TransactionRejectReasonStandinService transactionRejectReasonStandinService;
    @Autowired
    private CustomerAccount customerAccount;
    @Mock
    private CustomerAccount mockedCustomerAccount;
	@Autowired
	private BalanceAccountPiRepository balanceAccountPiRepository;
	@Autowired
	private EntityManager entityManager;
	@Autowired
	private MessageReceiver messageReceiver;
    @Autowired
    private MessageCatalogSpecificationService messageCatalogSpecificationService;
    @Autowired
    private TransactionEntitiesService transactionEntitiesService;
    @Mock
    private WebhookTransactionValidationService mockWebhookTransactionValidationService;
    @Autowired
    private WebhookTransactionValidationService webhookTransactionValidationService;

    private String pacs002CurrentVersion;

    private static final String CREDIT_ON_ACCOUNT_NOT_VALIDATED_CODE = "ED05";
    private static final String CREDIT_ON_ACCOUNT_NOT_VALIDATED_DESCRIPTION = "Settlement of the transaction has failed";

    @BeforeEach
    void setUp() {
        pacs002CurrentVersion = messageCatalogSpecificationService.findMessageCatalogSpecificationByCode("pacs.002").getVersion();
        when(mockedSpiMessagingApis.messagesApi()).thenReturn(mockedMessagesApi);
        messageSender.setSpiMessagingApis(mockedSpiMessagingApis);

        ReflectionTestUtils.setField(directPSPCreditEventValidator, "customerAccount", mockedCustomerAccount);
        ReflectionTestUtils.setField(receiptEventValidator, "webhookTransactionValidationService", mockWebhookTransactionValidationService);

        when(mockWebhookTransactionValidationService.queryValidator(any(), any())).thenReturn(new TransactionIdValidationResponseDTO().shouldReceive(true).motive("Web hook rejection."));
    }

    @AfterEach
    void tearDown() {
        messageSender.setSpiMessagingApis(spiMessagingApisBean);

        ReflectionTestUtils.setField(directPSPCreditEventValidator, "customerAccount", customerAccount);
        ReflectionTestUtils.setField(receiptEventValidator, "webhookTransactionValidationService", webhookTransactionValidationService);
    }

    @ParameterizedTest(name = "receive message from version: [{0}]")
    @ValueSource(strings = {"1.2", "1.3"})
    void shouldRejectTheReceiptWhenDS0G(String messageReceivedVersion) throws EventValidatorException {

        //when
        MateraRestErrorDTO[] errors = {new MateraRestErrorDTO("DS0G", "", "", "")};
        doThrow(new RestBadRequestException(404, "", "", errors))
            .when(mockedCustomerAccount)
            .validateCredit((ReceiptEventEntity) any());

        ReceiptVerifierBuilder receiptVerifierBuilder = ReceiptVerifier.builder();
        receivePaymentWithInvalidReceiverAccount(receiptVerifierBuilder, messageReceivedVersion);

        //then
        transactionEntitiesService.refreshAllEntities();
        verifyAccountBalance(balanceAccountPiRepository.findAll(), 0, 0);

        List<EventEntity> allEvents = transactionEntitiesService.getAllEventsAndVerifySize(1);
        List<TransactionEntity> allTransactions = transactionEntitiesService.getAllTransactionsAndVerifySize(1);
        List<MessageEntity> allMessages = transactionEntitiesService.getAllMessagesAndVerifySize(2);

        receiptVerifierBuilder
            .receivedPacs008(allMessages.get(0))
            .expectedReceivedPacs008Version(messageReceivedVersion)
            .sentPacs002(allMessages.get(1))
            .expectedSentPacs002Version(pacs002CurrentVersion)
            .eventEntity(allEvents.get(0))
            .transactionEntity(allTransactions.get(0))
            .paymentIndex(0)
            .eventVerifier(EventVerifier::verifyReceiptEventIsRejected)
            .build().verify();
    }

    @ParameterizedTest(name = "receive message from version: [{0}]")
    @ValueSource(strings = {"1.2", "1.3"})
    void shouldRejectTheReceiptWhenStdTr001(String messageReceivedVersion) throws EventValidatorException {

        //when
        MateraRestErrorDTO[] errors = {new MateraRestErrorDTO("STD-TR-001", "", "", "")};
        doThrow(new RestBadRequestException(404, "", "", errors))
                        .when(mockedCustomerAccount)
                        .validateCredit((ReceiptEventEntity) any());

        ReceiptVerifierBuilder receiptVerifierBuilder = ReceiptVerifier.builder();
        receivePaymentWithInvalidReceiverAccount(receiptVerifierBuilder, messageReceivedVersion);

        //then
        transactionEntitiesService.refreshAllEntities();
        verifyAccountBalance(balanceAccountPiRepository.findAll(), 0, 0);

        List<EventEntity> allEvents = transactionEntitiesService.getAllEventsAndVerifySize(1);
        List<TransactionEntity> allTransactions = transactionEntitiesService.getAllTransactionsAndVerifySize(1);
        List<MessageEntity> allMessages = transactionEntitiesService.getAllMessagesAndVerifySize(2);

        receiptVerifierBuilder
            .receivedPacs008(allMessages.get(0))
            .expectedReceivedPacs008Version(messageReceivedVersion)
            .sentPacs002(allMessages.get(1))
            .expectedSentPacs002Version(pacs002CurrentVersion)
            .eventEntity(allEvents.get(0))
            .transactionEntity(allTransactions.get(0))
            .paymentIndex(0)
            .eventVerifier(EventVerifier::verifyReceiptEventIsRejected)
            .build().verify();
    }

	@ParameterizedTest(name = "receive message from version: [{0}]")
	@ValueSource(strings = {"1.2", "1.3"})
	@DisplayName("When receive a pacs.008 with a single payment should respond with a pacs.002 accepting the payment and create the corresponding entities")
	void shouldReceiveAReceipt(String messageReceivedVersion) {
		//when
		ReceiptVerifierBuilder receiptVerifierBuilder = ReceiptVerifier.builder();
		receivePayment(receiptVerifierBuilder, messageReceivedVersion);

		//then
		transactionEntitiesService.refreshAllEntities();
		//Credit will only done after confirmation
		verifyAccountBalance(balanceAccountPiRepository.findAll(), 0, 0);

		List<EventEntity> allEvents = transactionEntitiesService.getAllEventsAndVerifySize(1);
		List<TransactionEntity> allTransactions = transactionEntitiesService.getAllTransactionsAndVerifySize(1);
		List<MessageEntity> allMessages = transactionEntitiesService.getAllMessagesAndVerifySize(2);

		receiptVerifierBuilder
				.receivedPacs008(allMessages.get(0))
				.expectedReceivedPacs008Version(messageReceivedVersion)
				.sentPacs002(allMessages.get(1))
                .expectedSentPacs002Version(pacs002CurrentVersion)
				.eventEntity(allEvents.get(0))
				.transactionEntity(allTransactions.get(0))
				.paymentIndex(0)
				.eventVerifier(EventVerifier::verifyReceiptEventIsWaitingConfirm)
				.build().verify();

        verifyMessagesApiWasCalledWithExternalOriginAndDestination(mockedMessagesApi);
    }

	@ParameterizedTest(name = "receive message from version: [{0}]")
	@ValueSource(strings = {"1.2", "1.3"})
	@DisplayName("When receive a pacs.008 with an unexpected receiver account should respond with a pacs.002 rejecting the payment")
	void shouldRejectTheReceiptWhenAnInvalidReceiverAccountItsGiven(String messageReceivedVersion) throws EventValidatorException {
		//when
        doThrow(RestBadRequestException.class).when(mockedCustomerAccount).validateCredit((ReceiptEventEntity) any());
		ReceiptVerifierBuilder receiptVerifierBuilder = ReceiptVerifier.builder();
		receivePaymentWithInvalidReceiverAccount(receiptVerifierBuilder, messageReceivedVersion);

		//then
		transactionEntitiesService.refreshAllEntities();
		verifyAccountBalance(balanceAccountPiRepository.findAll(), 0, 0);

		List<EventEntity> allEvents = transactionEntitiesService.getAllEventsAndVerifySize(1);
		List<TransactionEntity> allTransactions = transactionEntitiesService.getAllTransactionsAndVerifySize(1);
		List<MessageEntity> allMessages = transactionEntitiesService.getAllMessagesAndVerifySize(2);

		receiptVerifierBuilder
				.receivedPacs008(allMessages.get(0))
				.expectedReceivedPacs008Version(messageReceivedVersion)
				.sentPacs002(allMessages.get(1))
                .expectedSentPacs002Version(pacs002CurrentVersion)
				.eventEntity(allEvents.get(0))
				.transactionEntity(allTransactions.get(0))
				.paymentIndex(0)
				.eventVerifier(EventVerifier::verifyReceiptEventIsRejected)
				.build().verify();
	}

	@ParameterizedTest(name = "receive message from version: [{0}]")
	@ValueSource(strings = {"1.2", "1.3"})
	@DisplayName("When receive a pacs.008 with a single payment and then receive a pacs.002 confirming it should process the credit correctly")
	void shouldProcessAReceivedMessageConfirmingTheReceipt(String messageReceivedVersion) {
		//given
		ReceiptVerifierBuilder receiptVerifierBuilder = ReceiptVerifier.builder();
		String pacs008EndToEndId = receivePayment(receiptVerifierBuilder, messageReceivedVersion);
		transactionEntitiesService.refreshAllEntities();

		//when
		String receivedPacs002PiResourceId = getRandomPiResourceId();
		receiptVerifierBuilder.expectedReceivedPacs002PiResourceId(receivedPacs002PiResourceId);
		String receivedPacs002Message = buildPacs002Response(
				receivedPacs002PiResourceId,
				buildTxInfAndSts(pacs008EndToEndId, "ACCC"),
				messageReceivedVersion);
		messageReceiver.readIncomingMessage(receivedPacs002Message);

		//then
		transactionEntitiesService.refreshAllEntities();

		verifyAccountBalance(balanceAccountPiRepository.findAll(), 0, 1);

		List<EventEntity> allEvents = transactionEntitiesService.getAllEventsAndVerifySize(1);
		List<TransactionEntity> allTransactions = transactionEntitiesService.getAllTransactionsAndVerifySize(1);
		List<MessageEntity> allMessages = transactionEntitiesService.getAllMessagesAndVerifySize(3);

		receiptVerifierBuilder
				.receivedPacs008(allMessages.get(0))
				.expectedReceivedPacs008Version(messageReceivedVersion)
				.sentPacs002(allMessages.get(1))
                .expectedSentPacs002Version(pacs002CurrentVersion)
				.receivedPacs002(allMessages.get(2))
				.expectedReceivedPacs002Version(messageReceivedVersion)
				.eventEntity(allEvents.get(0))
				.transactionEntity(allTransactions.get(0))
				.paymentIndex(0)
				.eventVerifier(EventVerifier::verifyReceiptEventIsPendingCreditAccountHolder)
				.build().verify();
	}

	@ParameterizedTest(name = "receive message from version: [{0}]")
	@ValueSource(strings = {"1.2", "1.3"})
	@DisplayName("When receive a pacs.008 with a single payment and then receive a pacs.002 rejecting it should process the credit rejection")
	void shouldProcessAReceivedMessageRejectingTheReceipt(String messageReceivedVersion) {
		//given
		ReceiptVerifierBuilder receiptVerifierBuilder = ReceiptVerifier.builder();
		String pacs008EndToEndId = receivePayment(receiptVerifierBuilder, messageReceivedVersion);
		transactionEntitiesService.refreshAllEntities();

		//when
		String receivedPacs002PiResourceId = getRandomPiResourceId();
		receiptVerifierBuilder.expectedReceivedPacs002PiResourceId(receivedPacs002PiResourceId);
		String receivedPacs002Message = buildPacs002Response(
				receivedPacs002PiResourceId,
				buildTxInfAndSts(pacs008EndToEndId, "RJCT"),
				messageReceivedVersion);
		messageReceiver.readIncomingMessage(receivedPacs002Message);

		//then
		transactionEntitiesService.refreshAllEntities();
		verifyAccountBalance(balanceAccountPiRepository.findAll(), 0, 0);

		List<EventEntity> allEvents = transactionEntitiesService.getAllEventsAndVerifySize(1);
		List<TransactionEntity> allTransactions = transactionEntitiesService.getAllTransactionsAndVerifySize(1);
		List<MessageEntity> allMessages = transactionEntitiesService.getAllMessagesAndVerifySize(3);

		receiptVerifierBuilder
				.receivedPacs008(allMessages.get(0))
				.expectedReceivedPacs008Version(messageReceivedVersion)
				.sentPacs002(allMessages.get(1))
                .expectedSentPacs002Version(pacs002CurrentVersion)
				.receivedPacs002(allMessages.get(2))
				.expectedReceivedPacs002Version(messageReceivedVersion)
				.eventEntity(allEvents.get(0))
				.transactionEntity(allTransactions.get(0))
				.paymentIndex(0)
				.eventVerifier(EventVerifier::verifyReceiptEventIsRejectedByTheClearing)
				.build().verify();
	}

	@ParameterizedTest(name = "receive message from version: [{0}]")
	@ValueSource(strings = {"1.2", "1.3"})
	@DisplayName("When receive a pacs.008 with an unexpected receiver account and then receive a pacs.002 confirming the rejection should complete the credit rejection process")
	void shouldProcessAReceivedMessageConfirmingTheRejectionOfTheReceipt(String messageReceivedVersion)  throws EventValidatorException {

        doThrow(RestBadRequestException.class).when(mockedCustomerAccount).validateCredit((ReceiptEventEntity) any());

        // given
		ReceiptVerifierBuilder receiptVerifierBuilder = ReceiptVerifier.builder();
		String pacs008EndToEndId = receivePaymentWithInvalidReceiverAccount(receiptVerifierBuilder, messageReceivedVersion);
		transactionEntitiesService.refreshAllEntities();

		// when
		String receivedPacs002PiResourceId = getRandomPiResourceId();
		receiptVerifierBuilder.expectedReceivedPacs002PiResourceId(receivedPacs002PiResourceId);
		String receivedPacs002Message = buildPacs002Response(
				receivedPacs002PiResourceId,
				buildTxInfAndSts(pacs008EndToEndId, "RJCT"),
				messageReceivedVersion);
		messageReceiver.readIncomingMessage(receivedPacs002Message);

		//then
		transactionEntitiesService.refreshAllEntities();
		verifyAccountBalance(balanceAccountPiRepository.findAll(), 0, 0);

		List<EventEntity> allEvents = transactionEntitiesService.getAllEventsAndVerifySize(1);
		List<TransactionEntity> allTransactions = transactionEntitiesService.getAllTransactionsAndVerifySize(1);
		List<MessageEntity> allMessages = transactionEntitiesService.getAllMessagesAndVerifySize(3);

		receiptVerifierBuilder
				.receivedPacs008(allMessages.get(0))
				.expectedReceivedPacs008Version(messageReceivedVersion)
				.sentPacs002(allMessages.get(1))
                .expectedSentPacs002Version(pacs002CurrentVersion)
				.receivedPacs002(allMessages.get(2))
				.expectedReceivedPacs002Version(messageReceivedVersion)
				.eventEntity(allEvents.get(0))
				.transactionEntity(allTransactions.get(0))
				.paymentIndex(0)
				.eventVerifier(EventVerifier::verifyReceiptEventIsRejectionConfirmed)
				.build().verify();
	}

	@ParameterizedTest(name = "receive message from version: [{0}]")
	@ValueSource(strings = {"1.2", "1.3"})
	@DisplayName("When receive multiple pacs.008 each one with a single payment and then receive one pacs.002 confirming or rejecting the payments should process all the events correctly")
	void shouldProcessAMessageWithFiveReceiptResponsesWhenFiveReceiptsWereReceivedSeparately(String messageReceivedVersion) {
		// given several pacs.008 each one with a single payment
		List<ReceiptVerifierBuilder> verifierBuilders = new ArrayList<>();
		StringBuilder txInfAndSts = new StringBuilder();
		for (int i = 0; i < 5; i++) {
			ReceiptVerifierBuilder paymentVerifierBuilder = ReceiptVerifier.builder();
			verifierBuilders.add(paymentVerifierBuilder);
			// receiving each one fo the pacs.008 and responding with a pacs.002
			String endToEndId = receivePayment(paymentVerifierBuilder, messageReceivedVersion);

			txInfAndSts.append(buildTxInfAndSts(endToEndId, i % 2 == 0 ? "ACCC" : "RJCT"));
		}

		// when we receive a single pacs.002 confirming and rejecting multiple payments
		String pacs002PiResourceId = getRandomPiResourceId();
		verifierBuilders.forEach(builder -> builder.expectedReceivedPacs002PiResourceId(pacs002PiResourceId));
		String message = buildPacs002Response(pacs002PiResourceId, txInfAndSts.toString(), messageReceivedVersion);
		transactionEntitiesService.refreshAllEntities();
		messageReceiver.readIncomingMessage(message);

		// then
		transactionEntitiesService.refreshAllEntities();
		verifyAccountBalance(balanceAccountPiRepository.findAll(), 0, 3);

		List<EventEntity> allEvents = transactionEntitiesService.getAllEventsAndVerifySize(5);
		List<TransactionEntity> allTransactions = transactionEntitiesService.getAllTransactionsAndVerifySize(5);
		List<MessageEntity> allMessages = transactionEntitiesService.getAllMessagesAndVerifySize(11);

		MessageEntity receivedPacs002 = allMessages.get(10);
		for (int i = 0; i < 5; i++) {
			ReceiptVerifierBuilder paymentVerifierBuilder = verifierBuilders.get(i);
			paymentVerifierBuilder
					//here we have the pacs.008 and sent pacs.002 in pairs
					.receivedPacs008(allMessages.get(2*i))
					.expectedReceivedPacs008Version(messageReceivedVersion)
					.sentPacs002(allMessages.get((2*i) + 1))
                    .expectedSentPacs002Version(pacs002CurrentVersion)
					// always paymentIndex zero, because each pacs.008 has only one payment
					.paymentIndex(0)
					.receivedPacs002(receivedPacs002)
					.expectedReceivedPacs002Version(messageReceivedVersion)
					.eventEntity(allEvents.get(i))
					.transactionEntity(allTransactions.get(i))
					.eventVerifier(i % 2 == 0 ? EventVerifier::verifyReceiptEventIsPendingCreditAccountHolder : EventVerifier::verifyReceiptEventIsRejectedByTheClearing)
					.build().verify();
		}
	}

	@ParameterizedTest(name = "receive message from version: [{0}]")
	@ValueSource(strings = {"1.2", "1.3"})
	@DisplayName("When receive one pacs.008 with multiple payments and then receive one pacs.002 confirming or rejecting the payments should process all the events correctly")
	void shouldProcessAMessageWithTenReceiptResponsesWhenReceivedOnePacs008WithTenPayments(String messageReceivedVersion) {
		// given a pacs.008 with multiple payments
		List<ReceiptVerifierBuilder> receiptVerifierBuilderList = new ArrayList<>();
		StringBuilder txInfAndSts = new StringBuilder();
		for (int i = 0; i < 10; i++) {
			ReceiptVerifierBuilder receiptVerifierBuilder = ReceiptVerifier.builder();
			receiptVerifierBuilderList.add(receiptVerifierBuilder);
		}
		// receiving the pacs.008 with multiple payments and sending multiple pacs.002 to respond this pacs.008
		List<String> endToEndIdList = receivePayment(receiptVerifierBuilderList, messageReceivedVersion);

		// when we receive a single pacs.002 confirming and rejecting multiple payments
		for (int i = 0; i < 10; i++) {
			//building pacs.002 response contents
			txInfAndSts.append(buildTxInfAndSts(endToEndIdList.get(i), i % 2 == 0 ? "ACCC" : "RJCT"));
		}
		String pacs002PiResourceId = getRandomPiResourceId();
		receiptVerifierBuilderList.forEach(builder -> builder.expectedReceivedPacs002PiResourceId(pacs002PiResourceId));
		String message = buildPacs002Response(pacs002PiResourceId, txInfAndSts.toString(), messageReceivedVersion);
		transactionEntitiesService.refreshAllEntities();
		messageReceiver.readIncomingMessage(message);

		// then
		transactionEntitiesService.refreshAllEntities();
		verifyAccountBalance(balanceAccountPiRepository.findAll(), 0, 5);

		List<EventEntity> allEvents = transactionEntitiesService.getAllEventsAndVerifySize(10);
		List<TransactionEntity> allTransactions = transactionEntitiesService.getAllTransactionsAndVerifySize(10);
		List<MessageEntity> allMessages = transactionEntitiesService.getAllMessagesAndVerifySize(12);

		MessageEntity receivedPacs002 = allMessages.get(11);
		for (int i = 0; i < 10; i++) {
			ReceiptVerifierBuilder paymentVerifierBuilder = receiptVerifierBuilderList.get(i);
			paymentVerifierBuilder
					//for each pacs.008 received we send a pacs.002
					.receivedPacs008(allMessages.get(0))
					.expectedReceivedPacs008Version(messageReceivedVersion)
					.sentPacs002(allMessages.get(i + 1))
                    .expectedSentPacs002Version(pacs002CurrentVersion)
					// we all the payments at a single instantPaymentsUIDTO
					.paymentIndex(i)
					.receivedPacs002(receivedPacs002)
					.expectedReceivedPacs002Version(messageReceivedVersion)
					.eventEntity(allEvents.get(i))
					.transactionEntity(allTransactions.get(i))
					.eventVerifier(i % 2 == 0 ? EventVerifier::verifyReceiptEventIsPendingCreditAccountHolder : EventVerifier::verifyReceiptEventIsRejectedByTheClearing)
					.build().verify();
		}
	}

	@ParameterizedTest(name = "receive message from version: [{0}]")
	@ValueSource(strings = {"1.2", "1.3"})
	@DisplayName("When receive one pacs.008 with multiple payments and then receive multiple pacs.002 each one confirming or rejecting one payments should process all the events correctly")
	void shouldProcessMultipleReceivedPacs002MessagesResponsesWhenReceivedOnePacs008With4Payments(String messageReceivedVersion) {
		// given a pacs.008 with multiple payments
		List<ReceiptVerifierBuilder> receiptVerifierBuilderList = new ArrayList<>();
		for (int i = 0; i < 4; i++) {
			ReceiptVerifierBuilder receiptVerifierBuilder = ReceiptVerifier.builder();
			receiptVerifierBuilderList.add(receiptVerifierBuilder);
		}
		// receiving a pacs.008 with multiple payments and sending multiple pacs.002 to respond this pacs.008
		List<String> endToEndIdList = receivePayment(receiptVerifierBuilderList, messageReceivedVersion);

		// when we receive multiple pacs.002 confirming and rejecting the payments
		for (int i = 0; i < 4; i++) {
			String pacs002PiResourceId = getRandomPiResourceId();
			receiptVerifierBuilderList.get(i).expectedReceivedPacs002PiResourceId(pacs002PiResourceId);
			String message = buildPacs002Response(pacs002PiResourceId, buildTxInfAndSts(endToEndIdList.get(i), i % 2 == 0 ? "ACCC" : "RJCT"), messageReceivedVersion);
			transactionEntitiesService.refreshAllEntities();
			messageReceiver.readIncomingMessage(message);
		}

		// then
		transactionEntitiesService.refreshAllEntities();
		verifyAccountBalance(balanceAccountPiRepository.findAll(), 0, 2);

		List<EventEntity> allEvents = transactionEntitiesService.getAllEventsAndVerifySize(4);
		List<TransactionEntity> allTransactions = transactionEntitiesService.getAllTransactionsAndVerifySize(4);
		List<MessageEntity> allMessages = transactionEntitiesService.getAllMessagesAndVerifySize(9);

		for (int i = 0; i < 4; i++) {
			ReceiptVerifierBuilder paymentVerifierBuilder = receiptVerifierBuilderList.get(i);
			paymentVerifierBuilder
					//for each pacs.008 received we send a pacs.002
					.receivedPacs008(allMessages.get(0))
					.expectedReceivedPacs008Version(messageReceivedVersion)
					.paymentIndex(i)
					//first all sentPacs002
					.sentPacs002(allMessages.get(i + 1))
                    .expectedSentPacs002Version(pacs002CurrentVersion)
					//then all receivedPacs002
					.receivedPacs002(allMessages.get(i + 5))
					.expectedReceivedPacs002Version(messageReceivedVersion)
					.eventEntity(allEvents.get(i))
					.transactionEntity(allTransactions.get(i))
					.eventVerifier(i % 2 == 0 ? EventVerifier::verifyReceiptEventIsPendingCreditAccountHolder : EventVerifier::verifyReceiptEventIsRejectedByTheClearing)
					.build().verify();
		}
	}

	@NotNull
	private List<String> receivePayment(List<ReceiptVerifierBuilder> receiptVerifierBuilders, boolean withInvalidReceiverAccount, String messageReceivedVersion) {

		List<String> expectedSentPiPacs002SentPiResourceId = new ArrayList<>();
		List<String> expectedEndToEndIds = new ArrayList<>();
		String receivedPacs008PiResourceId = getRandomPiResourceId();
		receiptVerifierBuilders
				.forEach(receiptVerifierBuilder -> {
					String randomPiResourceId = getRandomPiResourceId();
					receiptVerifierBuilder.expectedSentPacs002PiResourceId(randomPiResourceId);
					expectedSentPiPacs002SentPiResourceId.add(randomPiResourceId);
					//setting same pacs.008 for all given piResourceIds
					receiptVerifierBuilder.expectedReceivedPacs008PiResourceId(receivedPacs008PiResourceId);

					String endToEndId = CorrelationIdGenerator.generateCorrelactionIdPacs008(String.valueOf(PARTICIPANT_ISPB));
					expectedEndToEndIds.add(endToEndId);
				});
		mockMessageSender(expectedSentPiPacs002SentPiResourceId);
		InstantPaymentsUIDTO instantPaymentsUIDTO = createInstantPaymentsUIDTOMock(expectedEndToEndIds, OperationType.RECEIPT);
		if (withInvalidReceiverAccount) {
			ReceiverUIDTO receiverUIDTO = instantPaymentsUIDTO.getPayments().get(0).getReceiver();
			receiverUIDTO.getAccount().setAccountNumber("12345679");
		}
		messageReceiver.readIncomingMessage(buildReceivedPacs008(receivedPacs008PiResourceId, instantPaymentsUIDTO, messageReceivedVersion));

		receiptVerifierBuilders
				.forEach(receiptVerifierBuilder -> receiptVerifierBuilder.instantPaymentsUIDTO(instantPaymentsUIDTO));
		return expectedEndToEndIds;
	}

	@NotNull
	private List<String> receivePayment(List<ReceiptVerifierBuilder> receiptVerifierBuilders, String messageReceivedVersion) {
		return receivePayment(receiptVerifierBuilders, false, messageReceivedVersion);
	}

	@NotNull
	private String receivePayment(ReceiptVerifierBuilder paymentVerifierBuilder, String messageReceivedVersion) {
		return receivePayment(Collections.singletonList(paymentVerifierBuilder), false, messageReceivedVersion).get(0);
	}

	@NotNull
	private String receivePaymentWithInvalidReceiverAccount(ReceiptVerifierBuilder paymentVerifierBuilder, String messageReceivedVersion) {
		return receivePayment(Collections.singletonList(paymentVerifierBuilder), true, messageReceivedVersion).get(0);
	}

	protected void mockMessageSender(List<String> expectedPiResourceIds) {
		OngoingStubbing<MessageSentResponseDTO> sendMessageMock = when(mockedMessagesApi.sendsMessageV1(any(MessageSpecificationDTO.class)));
		for (String piResourceId: expectedPiResourceIds) {
			sendMessageMock = sendMessageMock.thenReturn(createMessageSentResponseDTO(piResourceId));
		}
	}
}
