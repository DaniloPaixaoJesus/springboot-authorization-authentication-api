package matera.spi.main.application.service;

import com.matera.spi.messaging.api.MessagesApi;
import com.matera.spi.messaging.model.MessageSpecificationDTO;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.IpAccountOwnerDTO;
import matera.spi.dto.IpAccountOwnerRequestDTO;
import matera.spi.main.domain.model.IpAccountOwnerEntity;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventStatus;
import matera.spi.main.domain.model.event.IpAccountOwnerStatus;
import matera.spi.main.domain.model.event.IpAccountOwnerUpdateEventEntity;
import matera.spi.main.domain.service.CpfCnpjFormatter;
import matera.spi.main.domain.service.IpAccountOwnerService;
import matera.spi.main.domain.service.config.MessagingCircuitBreakerConfig;
import matera.spi.main.exception.MessagingUnavailableException;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.EventStatusRepository;
import matera.spi.main.persistence.EventTypeRepository;
import matera.spi.main.persistence.IpAccountOwnerRepository;
import matera.spi.main.utils.EntityCreationUtils;
import matera.spi.main.utils.MockMessagingHelper;
import matera.spi.utils.LocalDateTimeUtils;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.http.Header;
import io.restassured.path.json.JsonPath;
import org.assertj.core.api.SoftAssertions;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.support.TransactionTemplate;

import static matera.spi.main.application.service.mapper.IpAccountOwnerUIMapper.mapIpAccountOwnerRequestToEntity;
import static matera.spi.main.domain.model.event.IpAccountOwnerStatus.ACTIVE;
import static matera.spi.main.domain.model.event.IpAccountOwnerStatus.ERROR;
import static matera.spi.main.domain.model.event.IpAccountOwnerStatus.INACTIVE;
import static matera.spi.main.domain.model.event.IpAccountOwnerStatus.REJECTED;
import static matera.spi.main.domain.model.event.IpAccountOwnerStatus.WAITING_CONFIRMATION;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.createMessageSentResponseDTO;
import static matera.spi.main.utils.XmlValidator.validateWithXSD;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@IntegrationTest
class IpAccountOwnerApplicationUIServiceIT {

    @LocalServerPort
    private int port;
    @Autowired
    private MockMessagingHelper mockMessagingHelper;
    @Autowired
    private IpAccountOwnerService ipAccountOwnerService;
    @Autowired
    private IpAccountOwnerRepository ipAccountOwnerRepository;
    @Autowired
    private EventRepository eventRepository;
    @Autowired
    private EventTypeRepository eventTypeRepository;
    @Autowired
    private EventStatusRepository eventStatusRepository;
    @Autowired
    private TransactionTemplate transactionTemplate;
    @Autowired
    private MessagingCircuitBreakerConfig messagingCircuitBreakerConfig;

    @Captor
    private ArgumentCaptor<MessageSpecificationDTO> messageSpecificationDTOArgumentCaptor;
    @Value("classpath:xsd/version/*/reda.022.*.xsd")
    Resource[] reda022XSDResources;

    private SoftAssertions softly;
    private MessagesApi messagesApiMock;

    @BeforeEach
    void setUp() {
        RestAssured.port = port;
        messagesApiMock = mockMessagingHelper.mock();
        when(messagesApiMock.sendsMessageV1(any())).thenReturn(createMessageSentResponseDTO());
        softly = new SoftAssertions();
    }

    @AfterEach
    void tearDown() {
        mockMessagingHelper.restore();
        messagingCircuitBreakerConfig.getCircuitBreaker().transitionToClosedState();
    }

    @Test
    @DisplayName("should be able to create a new ip-account owner when posting at /ui/v1/ip-account/owners with only required fields")
    void shouldCreateANewIpAccountOwnerWithOnlyRequiredFields() {
        JsonPath response = RestAssured
            .given()
                .contentType(ContentType.JSON)
                .body(EntityCreationUtils.buildIpAccountOwnerRequestDTO())
            .when()
                .post("/ui/v1/ip-account/owners")
            .then()
            .assertThat()
                .statusCode(HttpStatus.ACCEPTED.value())
                .extract().response().jsonPath();

        IpAccountOwnerDTO responseDTO = response.getObject("data", IpAccountOwnerDTO.class);
        assertThat(responseDTO).isEqualTo(EntityCreationUtils.buildIpAccountOwnerDTO(WAITING_CONFIRMATION));

        String reda022Sent = getXmlSent();
        validateWithXSD(reda022Sent, reda022XSDResources[0]);
    }

    @Test
    @DisplayName("should be able to create a new ip-account owner when posting at /ui/v1/ip-account/owners with only ALL fields")
    void shouldCreateANewIpAccountOwnerWithAllRequiredFields() {
        JsonPath response = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(EntityCreationUtils.buildIpAccountOwnerRequestDTOWithAllFields())
            .when()
            .post("/ui/v1/ip-account/owners")
            .then()
            .assertThat()
            .statusCode(HttpStatus.ACCEPTED.value())
            .extract().response().jsonPath();

        IpAccountOwnerDTO responseDTO = response.getObject("data", IpAccountOwnerDTO.class);
        assertThat(responseDTO).isEqualTo(EntityCreationUtils.buildIpAccountOwnerDTOWithAllFields(WAITING_CONFIRMATION));

        String reda022Sent = getXmlSent();
        validateWithXSD(reda022Sent, reda022XSDResources[0]);
    }

    @Test
    @DisplayName("when trying to update the ipAccount owner with same values of the current active owner should return bad request")
    void shouldGetBadRequestWhenTryingToUpdateTheIpAccountOwnerWithTheSameValuesOfTheCurrentActive() {
        IpAccountOwnerRequestDTO requestUpdateWithAllFields = EntityCreationUtils.buildIpAccountOwnerRequestDTOWithAllFields();
        createIpAccountOwner(ACTIVE, requestUpdateWithAllFields);

        String response = RestAssured
            .given()
                .contentType(ContentType.JSON)
                .body(requestUpdateWithAllFields)
            .when()
                .post("/ui/v1/ip-account/owners")
            .then()
                .assertThat()
                .statusCode(HttpStatus.BAD_REQUEST.value())
            .extract().asString();

        assertThat(response).contains("SPI-ME-018", "Active owner already has these values. Nothing to update");
    }

    @Test
    @DisplayName("when messaging responds with error should set the status of ipAccountOwnerUpdate as ERROR")
    void shouldCreateIpAccountOwnerWithStatusErrorWhenMessagingRespondsWithError() {
        IpAccountOwnerRequestDTO requestUpdateWithAllFields = EntityCreationUtils.buildIpAccountOwnerRequestDTOWithAllFields();
        when(messagesApiMock.sendsMessageV1(any())).thenThrow(MessagingUnavailableException.class);

        RestAssured
            .given()
                .contentType(ContentType.JSON)
                .body(requestUpdateWithAllFields)
            .when()
                .post("/ui/v1/ip-account/owners")
            .then()
            .assertThat()
                .statusCode(HttpStatus.SERVICE_UNAVAILABLE.value());

        transactionTemplate.execute((status) -> {
            EventEntity eventEntity = eventRepository.findAll().get(0);
            assertThat(eventEntity.getStatus().getDescription()).isEqualTo("Error");

            IpAccountOwnerEntity ipAccountOwnerEntity = ipAccountOwnerRepository.findAll().get(0);
            assertThat(ipAccountOwnerEntity.getStatus()).isEqualTo(ERROR);
            return null;
        });
    }

    @ParameterizedTest(name = "{0} with value {1}")
    @DisplayName("should throw BadRequest when trying to update the ipAccount with field ")
    @CsvSource({
        "directorName,",
        "directorName, ''",
        "directorName, random chars with characters more than 140 random chars with characters more than 140 random chars with characters more than 140 random chars ",
        "directorTaxId, ''",
        "directorTaxId,",
        "directorTaxId, 012345678912",
        "directorPhone, ''",
        "directorPhone,",
        "directorPhone, ''",
        "directorPhone, +55-121391239081203981209381011",
        "directorMobile, +55-121391239081203981209381011",
        "directorEmail,",
        "directorEmail, ''",
        "directorEmail, random chars with characters@more than 77 random chars with characters more th",
        "passPhrase,",
        "passPhrase, ''",
        "passPhrase, 123456789",
        "employeePhone,",
        "employeePhone, ''",
        "employeePhone, +55-121391239081203981209381011",
        "employeeMobile, +55-121391239081203981209381011",
        "employeeFax, +55-121391239081203981209381011",
        "employeeEmail,",
        "employeeEmail, ''",
        "employeeEmail, random chars with characters more@than 77 random chars with characters more th"
    })
    void shouldGetBadRequestWhenTryingToUpdateWithoutTheRequiredFields(String fieldName, String invalidData) {
        IpAccountOwnerRequestDTO requestUpdateWithRequiredFields = EntityCreationUtils.buildIpAccountOwnerRequestDTO();

        ReflectionTestUtils.setField(requestUpdateWithRequiredFields, fieldName, invalidData);

        String response = RestAssured
            .given()
                .contentType(ContentType.JSON)
                .body(requestUpdateWithRequiredFields)
            .when()
                .post("/ui/v1/ip-account/owners")
            .then()
            .assertThat()
                .statusCode(HttpStatus.BAD_REQUEST.value())
                .extract().asString();

        assertThat(response).contains("SPI-ME-016", "Validation failed:", fieldName);
    }

    @ParameterizedTest(name = "{0} with value {1}")
    @DisplayName("should get ok when receiving the limit of character of some field")
    @CsvSource({
        "directorName, random chars with characters 140 random chars with characters 140 random chars with characters more than 140 random chars with characters rr",
        "directorPhone, +55-12139123908120398120938101",
        "directorMobile,",
        "directorMobile, ''",
        "directorMobile, +55-12139123908120398120938101",
        "directorEmail, random chars with@ characters 77 random chars with characters 77 random 1234",
        "passPhrase, 12345678",
        "employeePhone, +55-12139123908120398120938101",
        "employeeMobile,",
        "employeeMobile, ''",
        "employeeMobile, +55-12139123908120398120938101",
        "employeeFax,",
        "employeeFax, ''",
        "employeeFax, +55-12139123908120398120938101",
        "employeeEmail, random chars with@ characters 77 random chars with characters 77 random 1234"
    })
    void shouldGetOkWhenTryingToUpdateIpAccountOwnerWithField(String fieldName, String validData) {
        IpAccountOwnerRequestDTO requestUpdateWithRequiredFields = EntityCreationUtils.buildIpAccountOwnerRequestDTO();

        ReflectionTestUtils.setField(requestUpdateWithRequiredFields, fieldName, validData);

        RestAssured
            .given()
                .contentType(ContentType.JSON)
                .body(requestUpdateWithRequiredFields)
            .when()
                .post("/ui/v1/ip-account/owners")
            .then()
            .assertThat()
                .statusCode(HttpStatus.ACCEPTED.value());

        String reda022Sent = getXmlSent();
        validateWithXSD(reda022Sent, reda022XSDResources[0]);
    }

    @Test
    @DisplayName("when have a waiting confirmation owner should get a BAD REQUEST response on new attempts to create an ip account owner update")
    void shouldGetBadRequestWhenAlreadyHaveAWaitingConfirmationOwner() {
        createIpAccountOwner(WAITING_CONFIRMATION);

        String response = RestAssured
            .given()
                .contentType(ContentType.JSON)
                .body(EntityCreationUtils.buildIpAccountOwnerRequestDTO())
            .when()
                .post("/ui/v1/ip-account/owners")
            .then()
                .assertThat()
                .statusCode(HttpStatus.BAD_REQUEST.value())
                .extract().asString();

        assertThat(response).contains("SPI-ME-017", "Cannot update ip account owner while there is an update waiting for confirmation");
    }

    @Test
    @DisplayName("when have none active owner should return NO_CONTENT on ip-account/owners/active")
    void shouldReturnNoContentWhenDoesNotHaveActiveOwner() {
        RestAssured
            .when()
                .get("/ui/v1/ip-account/owners/active")
            .then()
                .assertThat()
                .statusCode(HttpStatus.NO_CONTENT.value());
    }

    @Test
    @DisplayName("when have an active owner should return it on ip-account/owners/active")
    void shouldReturnTheActiveOwner() {
        createIpAccountOwner(ACTIVE);

        JsonPath response = RestAssured
            .when()
                .get("/ui/v1/ip-account/owners/active")
            .then()
                .assertThat()
                .statusCode(HttpStatus.OK.value())
                .extract().response().jsonPath();

        IpAccountOwnerDTO responseDTO = response.getObject("data", IpAccountOwnerDTO.class);
        assertThat(responseDTO).isEqualTo(EntityCreationUtils.buildIpAccountOwnerDTO(ACTIVE));
    }

    @Test
    @DisplayName("should be able to return the list of ip account owners updates")
    void shouldBeAbleToListTheHistoryOfIpAccountOwners() {
        //given
        createIpAccountOwner(INACTIVE);
        createIpAccountOwner(REJECTED);
        createIpAccountOwner(ERROR);
        createIpAccountOwner(ACTIVE);
        createIpAccountOwner(WAITING_CONFIRMATION);

        //when
        JsonPath jsonPath = RestAssured
            .given()
                .contentType(ContentType.JSON)
                .header(new Header("pageSize", "10"))
                .header(new Header("pageNumber", "0"))
                .body("{}")
            .when()
                .post("/ui/v1/ip-account/owners/filter").then()
            .assertThat()
                .statusCode(HttpStatus.OK.value())
                .extract().jsonPath();

        //then
        assertJsonContentAtIndexHasStatus(jsonPath, 0, WAITING_CONFIRMATION);
        assertJsonContentAtIndexHasStatus(jsonPath, 1, ACTIVE);
        assertJsonContentAtIndexHasStatus(jsonPath, 2, ERROR);
        assertJsonContentAtIndexHasStatus(jsonPath, 3, REJECTED);
        assertJsonContentAtIndexHasStatus(jsonPath, 4, INACTIVE);

        softly.assertAll();
    }

    private void assertJsonContentAtIndexHasStatus(JsonPath jsonPath, int index, IpAccountOwnerStatus expectedStatus) {
        IpAccountOwnerDTO expected = EntityCreationUtils.buildIpAccountOwnerDTO(expectedStatus);
        IpAccountOwnerDTO actual = getIpAccountOwnerFromIndex(jsonPath, index);
        softly.assertThat(expected).isEqualTo(actual);
        softly.assertThat(jsonPath.getString("data.content[" + index + "].eventId")).isNotBlank();
    }

    private IpAccountOwnerDTO getIpAccountOwnerFromIndex(JsonPath jsonPath, int index) {
        return jsonPath.getObject("data.content["+index+"].ipAccountOwner", IpAccountOwnerDTO.class);
    }

    private void createIpAccountOwner(IpAccountOwnerStatus status) {
        createIpAccountOwner(status, EntityCreationUtils.buildIpAccountOwnerRequestDTO());
    }

    private void createIpAccountOwner(IpAccountOwnerStatus status, IpAccountOwnerRequestDTO requestDTO) {
        IpAccountOwnerEntity owner = mapIpAccountOwnerRequestToEntity(requestDTO);
        String sanitizedTaxId = CpfCnpjFormatter.padCpf(owner.getDirectorTaxId());
        owner.setDirectorTaxId(sanitizedTaxId);
        owner.setStatus(status);
        owner.setInitiationTimestamp(LocalDateTimeUtils.getUtcLocalDateTime());
        ipAccountOwnerService.save(owner);

        createEventFor(owner);
    }

    private void createEventFor(IpAccountOwnerEntity owner) {
        IpAccountOwnerUpdateEventEntity eventEntity = new IpAccountOwnerUpdateEventEntity();
        eventTypeRepository.findById(7).ifPresent(eventEntity::setEventTypeEntity);
        eventEntity.setResponsible("some responsible");
        eventEntity.setInitiationTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
        eventEntity.setInitiatorIspb(PARTICIPANT_ISPB);
        eventStatusRepository.findById(EventStatus.UPDATE_SENT.getCode()).ifPresent(eventEntity::setStatus);

        eventEntity.setIpAccountOwnerEntity(owner);
        eventRepository.saveAndFlush(eventEntity);
    }

    private String getXmlSent() {

        verify(messagesApiMock, atLeastOnce()).sendsMessageV1(messageSpecificationDTOArgumentCaptor.capture());
        MessageSpecificationDTO messageSpecificationDTO = messageSpecificationDTOArgumentCaptor.getValue();

        return messageSpecificationDTO.getMessageContent();
    }

}


