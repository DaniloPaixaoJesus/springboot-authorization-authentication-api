package matera.spi.main.utils;

import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.domain.model.transaction.TransactionEntity;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.MessageRepository;
import matera.spi.main.persistence.TransactionRepository;

import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;

import static org.assertj.core.api.Assertions.assertThat;

@Service
public class TransactionEntitiesService {

    @Autowired
    private EventRepository eventRepository;
    @Autowired
    private MessageRepository messageRepository;
    @Autowired
    private TransactionRepository transactionRepository;
    @Autowired
    private EntityManager entityManager;

    public @NotNull List<EventEntity> getAllEventsAndVerifySize(int expectedSize) {
        List<EventEntity> allEvents = eventRepository.findAllWithTransactionEntity(Sort.by(Sort.Direction.ASC, "initiationTimestampUTC"));
        assertThat(allEvents).hasSize(expectedSize);
        return allEvents;
    }

    public @NotNull List<MessageEntity> getAllMessagesAndVerifySize(int expectedSize) {
        List<MessageEntity> allMessages = messageRepository.findAll(Sort.by(Sort.Direction.ASC, "timestampUtc"));
        assertThat(allMessages).hasSize(expectedSize);
        return allMessages;
    }

    public @NotNull List<TransactionEntity> getAllTransactionsAndVerifySize(int expectedSize) {
        List<TransactionEntity> allTransactions = transactionRepository.findAll();
        List<TransactionEntity> sortedTransactions = allTransactions.stream()
            .sorted(Comparator.comparing(s -> s.getEvent().getInitiationTimestampUTC()))
            .collect(Collectors.toList());
        assertThat(sortedTransactions).hasSize(expectedSize);
        return sortedTransactions;
    }

    /**
     * we need to refresh the entities because we are executing the test at one transaction,
     * to get the relation right between event ant message we need this refreshes.
     */
    public void refreshAllEntities() {
        transactionRepository.findAll().forEach(entityManager::refresh);
        messageRepository.findAll().forEach(entityManager::refresh);
        eventRepository.findAll().forEach(entityManager::refresh);
    }

}
