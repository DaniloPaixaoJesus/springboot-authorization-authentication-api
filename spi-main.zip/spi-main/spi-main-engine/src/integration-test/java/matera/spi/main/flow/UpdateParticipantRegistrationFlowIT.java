package matera.spi.main.flow;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.message.MessageTypeEntity;
import matera.spi.main.domain.service.event.receiver.MessageReceiver;
import matera.spi.main.exception.EventErrorException;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.MessageTypeRepository;
import matera.spi.main.persistence.ParticipantRepository;
import matera.spi.utils.LocalDateTimeUtils;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.opentest4j.AssertionFailedError;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

import static matera.spi.main.utils.MessageCreationUtils.buildReceivedReda041;
import static matera.spi.main.utils.MessageCreationUtils.buildReda041PtyActvtyTag;

@IntegrationTest
public class UpdateParticipantRegistrationFlowIT {

    public static final Integer ISPB = 60701190;
    public static final String PARTICIPANT_NAME = "PIX S/A";

    public static final String ENVELOPE_NAMESPACE = "https://www.bcb.gov.br/pi/reda.041/1.2";
    public static final String CORRELATION_ID = "M005737687cd679d901c941d0aad880b";
    public static final Integer EVT_TYPE_CODE_UPDATE_PARTICIPANT = 16;
    public static final Integer EVT_STATUS_CODE_SUCCESS = 3;
    public static final String UPDATED_DATE = "2020-08-26T18:54:40.009Z";

    @Autowired
    private MessageReceiver messageReceiver;

    @Autowired
    private EventRepository eventRepository;

    @Autowired
    private MessageTypeRepository messageTypeRepository;

    @Autowired
    private ParticipantRepository participantRepository;

    @Test
    public void shouldProcessUpdateParticipantRegistrationReda041() {
        ParticipantEntity participantEntity = participantRepository.findByIspb(ISPB).get();
        final String oldName = participantEntity.getName();
        final LocalDateTime oldUpdateTimestampUtc = participantEntity.getUpdateTimestampUtc();

        Assertions.assertNotEquals(PARTICIPANT_NAME, participantEntity.getName());

        String reda041PtyActvtyTag = buildReda041PtyActvtyTag(ISPB.toString(), "ITAÚ UNIBANCO S.A.", PARTICIPANT_NAME);

        LocalDateTime updatedDate = LocalDateTimeUtils.parseLocalDateTimeUTC(UPDATED_DATE);

        String reda041Message = buildReceivedReda041(CORRELATION_ID, reda041PtyActvtyTag,"1.2", ENVELOPE_NAMESPACE,
        updatedDate);

        messageReceiver.readIncomingMessage(reda041Message);

        EventEntity eventEntity = eventRepository
            .findFirstByCorrelationIdAndMessageType(CORRELATION_ID, getmessageType())
            .orElse(null);

        Assertions.assertNotNull(eventEntity);
        Assertions.assertEquals(CORRELATION_ID, eventEntity.getCorrelationId());
        Assertions.assertEquals(EVT_STATUS_CODE_SUCCESS, eventEntity.getStatus().getCode());
        Assertions.assertEquals(EVT_TYPE_CODE_UPDATE_PARTICIPANT, eventEntity.getEventType().getCode());

        participantEntity = participantRepository.findByIspb(ISPB).get();
        Assertions.assertEquals(PARTICIPANT_NAME, participantEntity.getName());
        Assertions.assertEquals(updatedDate, participantEntity.getUpdateTimestampUtc());

        participantEntity.setName(oldName);
        participantEntity.setUpdateTimestampUtc(oldUpdateTimestampUtc);
        participantRepository.saveAndFlush(participantEntity);
    }

    @Test()
    public void shouldThrowErrorOnUpdateParticipantRegistrationReda041WithWrongISPB() {
        String reda041PtyActvtyTag = buildReda041PtyActvtyTag("44444444", "ITAÚ UNIBANCO S.A.", PARTICIPANT_NAME);
        LocalDateTime updatedDate = LocalDateTimeUtils.getUtcLocalDateTime().truncatedTo(ChronoUnit.MILLIS);

        String reda041Message = buildReceivedReda041(CORRELATION_ID, reda041PtyActvtyTag,"1.2", ENVELOPE_NAMESPACE,
            updatedDate);

        Assertions.assertThrows(EventErrorException.class, () -> {
            messageReceiver.readIncomingMessage(reda041Message);
        });
    }

    private MessageTypeEntity getmessageType(){
        return messageTypeRepository.findById("reda.041")
            .orElseThrow(() -> new AssertionFailedError("Not found message type reda.041"));
    }
}
