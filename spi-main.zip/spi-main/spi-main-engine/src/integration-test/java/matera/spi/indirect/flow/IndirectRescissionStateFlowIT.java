package matera.spi.indirect.flow;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.matera.spi.messaging.model.MessageSpecificationDTO;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import matera.spi.commons.IntegrationTest;
import matera.spi.indirect.domain.model.ParticipantMipIndirectEntity;
import matera.spi.indirect.domain.service.scheduling.IndirectParticipantUnregisterScheduling;
import matera.spi.indirect.persistence.ParticipantMipIndirectRepository;
import matera.spi.main.utils.WireMockUtils;
import org.apache.http.HttpStatus;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;

import static matera.spi.main.utils.WireMockUtils.V_1_MESSAGES;

@IntegrationTest
public class IndirectRescissionStateFlowIT extends IndirectBaseStateFlowIT {

    private static final WireMockServer wireMockServer = WireMockUtils.start();

    @BeforeAll
    public static void baseBeforeAll() {
        WireMockUtils.stubMessaging();
    }

    @AfterAll
    public static void baseAfterAll() {
        wireMockServer.stop();
    }

    @Autowired
    private IndirectParticipantUnregisterScheduling indirectParticipantUnregisterScheduling;

    @Autowired
    private ParticipantMipIndirectRepository participantMipIndirectRepository;

    @Test
    public void shouldReceiveReda017AndSendReda031ToClearingReceiveReda016WithSuccess() {

        registryIndirectWithSuccess();

        String reda017 = customizeReda017(getFileAsString(FILE_REDA017), LocalDateTime.now().plusDays(1));
        sendRedaToMessageReceiver(MSG_TYPE_REDA017, reda017);
        String getResponseJson = getParticipantByIspb(INDIRECT_ISPB);
        String expectedActiveResponse = getFileAsString(FILE_JSON_INDIRECT_WAITING_TO_SEND_RESCISSION);
        Assertions.assertEquals(expectedActiveResponse, getResponseJson);

        WireMock.resetAllRequests();
        Response response = RestAssured
            .given()
            .body(RESCISSION_BODY_CLEARING_RESPONSE)
            .contentType(ContentType.JSON)
            .pathParam(PATH_PARAMETER_ISPB, INDIRECT_ISPB)
            .post(URN_INDIRECT_SEND_RESCISSION_TO_CLEARING);
        Assertions.assertEquals(HttpStatus.SC_ACCEPTED, response.statusCode());

        String messageSent = WireMockUtils
            .getFirstBodyFrom(WireMock.postRequestedFor(WireMock.urlEqualTo(V_1_MESSAGES)), MessageSpecificationDTO.class)
            .getMessageContent()
            .trim();
        String expectedSentToClearing = getFileAsString(FILE_REDA031);
        Assertions.assertEquals(extractValueFromXml(expectedSentToClearing, BODY_REDA031_TAG), extractValueFromXml(messageSent, BODY_REDA031_TAG));

        String reda016Success = customizeReda016(getFileAsString(FILE_REDA016_SUCCESS), extractValueFromXml(messageSent, MSG_ID_TAG));
        sendRedaToMessageReceiver(MSG_TYPE_REDA016, reda016Success);
        getResponseJson = getParticipantByIspb(INDIRECT_ISPB);
        String expectedDeregisteredResponse = getFileAsString(FILE_JSON_INDIRECT_DEREGISTERED);
        Assertions.assertEquals(expectedDeregisteredResponse, getResponseJson);
    }

    @Test
    public void shouldSendReda031ToClearingReceiveReda016WithSuccess() {

        registryIndirectWithSuccess();

        WireMock.resetAllRequests();
        Response response = RestAssured
            .given()
            .body(RESCISSION_BODY_CLEARING_RESPONSE)
            .contentType(ContentType.JSON)
            .pathParam(PATH_PARAMETER_ISPB, INDIRECT_ISPB)
            .post(URN_INDIRECT_SEND_RESCISSION_TO_CLEARING);
        Assertions.assertEquals(HttpStatus.SC_ACCEPTED, response.statusCode());

        String messageSent = WireMockUtils
            .getFirstBodyFrom(WireMock.postRequestedFor(WireMock.urlEqualTo(V_1_MESSAGES)), MessageSpecificationDTO.class)
            .getMessageContent()
            .trim();
        String expectedSentToClearing = getFileAsString(FILE_REDA031);
        Assertions.assertEquals(extractValueFromXml(expectedSentToClearing, BODY_REDA031_TAG), extractValueFromXml(messageSent, BODY_REDA031_TAG));

        String reda016Success = customizeReda016(getFileAsString(FILE_REDA016_SUCCESS), extractValueFromXml(messageSent, MSG_ID_TAG));
        sendRedaToMessageReceiver(MSG_TYPE_REDA016, reda016Success);
        String getResponseJson = getParticipantByIspb(INDIRECT_ISPB);
        String expectedDeregisteredResponse = getFileAsString(FILE_JSON_INDIRECT_DEREGISTERED);
        Assertions.assertEquals(expectedDeregisteredResponse, getResponseJson);
    }

    @Test
    public void shouldReceiveReda017AndSendReda031ToClearingReceiveReda016WithRejtRollbackIndirectToActiveStatus() {

        registryIndirectWithSuccess();

        String reda017 = customizeReda017(getFileAsString(FILE_REDA017), LocalDateTime.now().plusDays(1));
        sendRedaToMessageReceiver(MSG_TYPE_REDA017, reda017);
        String getResponseJson = getParticipantByIspb(INDIRECT_ISPB);
        String expectedWaitingToSendRescissionResponse = getFileAsString(FILE_JSON_INDIRECT_WAITING_TO_SEND_RESCISSION);
        Assertions.assertEquals(expectedWaitingToSendRescissionResponse, getResponseJson);

        WireMock.resetAllRequests();
        Response response = RestAssured
            .given()
            .body(RESCISSION_BODY_CLEARING_RESPONSE)
            .contentType(ContentType.JSON)
            .pathParam(PATH_PARAMETER_ISPB, INDIRECT_ISPB)
            .post(URN_INDIRECT_SEND_RESCISSION_TO_CLEARING);
        Assertions.assertEquals(HttpStatus.SC_ACCEPTED, response.statusCode());

        String messageSent = WireMockUtils
            .getFirstBodyFrom(WireMock.postRequestedFor(WireMock.urlEqualTo(V_1_MESSAGES)), MessageSpecificationDTO.class)
            .getMessageContent()
            .trim();
        String expectedSentToClearing = getFileAsString(FILE_REDA031);
        Assertions.assertEquals(extractValueFromXml(expectedSentToClearing, BODY_REDA031_TAG), extractValueFromXml(messageSent, BODY_REDA031_TAG));

        String reda016Error = customizeReda016(getFileAsString(FILE_REDA016_REJECTED), extractValueFromXml(messageSent, MSG_ID_TAG), REDA016_REASON_CODE_ANOTHER);
        sendRedaToMessageReceiver(MSG_TYPE_REDA016, reda016Error);
        getResponseJson = getParticipantByIspb(INDIRECT_ISPB);
        String expectedActiveResponse = getFileAsString(FILE_JSON_INDIRECT_ACTIVE);
        Assertions.assertEquals(expectedActiveResponse, getResponseJson);

    }

    @Test
    public void shouldSendReda031ToClearingReceiveReda016WithRejtRollbackIndirectToActiveStatus() {

        registryIndirectWithSuccess();

        WireMock.resetAllRequests();
        Response response = RestAssured
            .given()
            .body(RESCISSION_BODY_CLEARING_RESPONSE)
            .contentType(ContentType.JSON)
            .pathParam(PATH_PARAMETER_ISPB, INDIRECT_ISPB)
            .post(URN_INDIRECT_SEND_RESCISSION_TO_CLEARING);
        Assertions.assertEquals(HttpStatus.SC_ACCEPTED, response.statusCode());

        String messageSent = WireMockUtils
            .getFirstBodyFrom(WireMock.postRequestedFor(WireMock.urlEqualTo(V_1_MESSAGES)), MessageSpecificationDTO.class)
            .getMessageContent()
            .trim();
        String expectedSentToClearing = getFileAsString(FILE_REDA031);
        Assertions.assertEquals(extractValueFromXml(expectedSentToClearing, BODY_REDA031_TAG), extractValueFromXml(messageSent, BODY_REDA031_TAG));

        String reda016Error = customizeReda016(getFileAsString(FILE_REDA016_REJECTED), extractValueFromXml(messageSent, MSG_ID_TAG), REDA016_REASON_CODE_ANOTHER);
        sendRedaToMessageReceiver(MSG_TYPE_REDA016, reda016Error);
        String getResponseJson = getParticipantByIspb(INDIRECT_ISPB);
        String expectedActiveResponse = getFileAsString(FILE_JSON_INDIRECT_ACTIVE);
        Assertions.assertEquals(expectedActiveResponse, getResponseJson);

    }

    @Test
    public void shouldReceiveReda017AndSendReda031ToClearingReceiveReda016WithRejtReasonCodeInd3RollbackIndirectToActiveStatus() {

        registryIndirectWithSuccess();

        String reda017 = customizeReda017(getFileAsString(FILE_REDA017), LocalDateTime.now().plusDays(1));
        sendRedaToMessageReceiver(MSG_TYPE_REDA017, reda017);
        String getResponseJson = getParticipantByIspb(INDIRECT_ISPB);
        String expectedWaitingToSendRescissionResponse = getFileAsString(FILE_JSON_INDIRECT_WAITING_TO_SEND_RESCISSION);
        Assertions.assertEquals(expectedWaitingToSendRescissionResponse, getResponseJson);

        WireMock.resetAllRequests();
        Response response = RestAssured
            .given()
            .body(RESCISSION_BODY_CLEARING_RESPONSE)
            .contentType(ContentType.JSON)
            .pathParam(PATH_PARAMETER_ISPB, INDIRECT_ISPB)
            .post(URN_INDIRECT_SEND_RESCISSION_TO_CLEARING);
        Assertions.assertEquals(HttpStatus.SC_ACCEPTED, response.statusCode());

        String messageSent = WireMockUtils
            .getFirstBodyFrom(WireMock.postRequestedFor(WireMock.urlEqualTo(V_1_MESSAGES)), MessageSpecificationDTO.class)
            .getMessageContent()
            .trim();
        String expectedSentToClearing = getFileAsString(FILE_REDA031);
        Assertions.assertEquals(extractValueFromXml(expectedSentToClearing, BODY_REDA031_TAG), extractValueFromXml(messageSent, BODY_REDA031_TAG));

        String reda016Error = customizeReda016(getFileAsString(FILE_REDA016_REJECTED), extractValueFromXml(messageSent, MSG_ID_TAG), REDA016_REASON_CODE_IND3);
        sendRedaToMessageReceiver(MSG_TYPE_REDA016, reda016Error);
        getResponseJson = getParticipantByIspb(INDIRECT_ISPB);
        String expectedActiveResponse = getFileAsString(FILE_JSON_INDIRECT_ACTIVE);
        Assertions.assertEquals(expectedActiveResponse, getResponseJson);

    }

    @Test
    public void shouldSendReda031ToClearingReceiveReda016WithRejtReasonCodeInd3RollbackIndirectToActiveStatus() {

        registryIndirectWithSuccess();

        WireMock.resetAllRequests();
        Response response = RestAssured
            .given()
            .body(RESCISSION_BODY_CLEARING_RESPONSE)
            .contentType(ContentType.JSON)
            .pathParam(PATH_PARAMETER_ISPB, INDIRECT_ISPB)
            .post(URN_INDIRECT_SEND_RESCISSION_TO_CLEARING);
        Assertions.assertEquals(HttpStatus.SC_ACCEPTED, response.statusCode());

        String messageSent = WireMockUtils
            .getFirstBodyFrom(WireMock.postRequestedFor(WireMock.urlEqualTo(V_1_MESSAGES)), MessageSpecificationDTO.class)
            .getMessageContent()
            .trim();
        String expectedSentToClearing = getFileAsString(FILE_REDA031);
        Assertions.assertEquals(extractValueFromXml(expectedSentToClearing, BODY_REDA031_TAG), extractValueFromXml(messageSent, BODY_REDA031_TAG));

        String reda016Error = customizeReda016(getFileAsString(FILE_REDA016_REJECTED), extractValueFromXml(messageSent, MSG_ID_TAG), REDA016_REASON_CODE_IND3);
        sendRedaToMessageReceiver(MSG_TYPE_REDA016, reda016Error);
        String getResponseJson = getParticipantByIspb(INDIRECT_ISPB);
        String expectedActiveResponse = getFileAsString(FILE_JSON_INDIRECT_ACTIVE);
        Assertions.assertEquals(expectedActiveResponse, getResponseJson);

    }

    @Test
    public void shouldReceiveReda017AndChangeStatusToActiveByJob() {
        registryIndirectWithSuccess();

        String reda017 = customizeReda017(getFileAsString(FILE_REDA017), LocalDateTime.now().plusDays(1));
        sendRedaToMessageReceiver(MSG_TYPE_REDA017, reda017);
        String getResponseJson = getParticipantByIspb(INDIRECT_ISPB);
        String expectedWaitingToSendRescissionResponse = getFileAsString(FILE_JSON_INDIRECT_WAITING_TO_SEND_RESCISSION);
        Assertions.assertEquals(expectedWaitingToSendRescissionResponse, getResponseJson);

        ParticipantMipIndirectEntity indirectEntity = participantMipIndirectRepository
            .findByParticipantMipIspb(Integer.valueOf(INDIRECT_ISPB))
            .orElseThrow();
        indirectParticipantUnregisterScheduling.unregister();
        Assertions.assertTrue(indirectEntity.getCurrentStatusExpireTimestamp().isAfter(LocalDateTime.now()));
        getResponseJson = getParticipantByIspb(INDIRECT_ISPB);
        Assertions.assertEquals(expectedWaitingToSendRescissionResponse, getResponseJson);

        indirectEntity.setCurrentStatusExpireTimestamp(LocalDateTime.now().minusSeconds(1));
        participantMipIndirectRepository.save(indirectEntity);
        indirectParticipantUnregisterScheduling.unregister();
        Assertions.assertTrue(indirectEntity.getCurrentStatusExpireTimestamp().isBefore(LocalDateTime.now()));

        getResponseJson = getParticipantByIspb(INDIRECT_ISPB);
        String expectedActiveResponse = getFileAsString(FILE_JSON_INDIRECT_ACTIVE);
        Assertions.assertEquals(expectedActiveResponse, getResponseJson);
    }

}
