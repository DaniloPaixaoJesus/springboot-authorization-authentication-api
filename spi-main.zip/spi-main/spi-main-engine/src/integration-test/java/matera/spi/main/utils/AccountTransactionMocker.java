package matera.spi.main.utils;

import com.matera.spi.thirdparties.customers.transactions.api.SPICustomersTransactionContractApis;

import matera.spi.main.domain.service.transaction.AccountTransaction;
import matera.spi.main.domain.service.transaction.AccountTransactionReverter;
import matera.spi.main.transactions.adapter.account.AccountTransactionExecutorAdapter;
import matera.spi.main.transactions.port.AccountTransactionExecutorPort;
import matera.spi.main.transactions.port.AccountTransactionReverterPort;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.springframework.test.util.ReflectionTestUtils.setField;

@Service
public class AccountTransactionMocker {

    @Autowired
    private AccountTransactionReverter accountTransactionReverter;

    @Autowired
    private AccountTransactionReverterPort accountTransactionReverterPort;

    @Autowired
    private AccountTransactionExecutorPort accountTransactionExecutorPort;

    @Autowired
    private SPICustomersTransactionContractApis spiCustomersTransactionContractApis;

    @Autowired
    private AccountTransaction accountTransaction;

    public AccountTransactionReverterPort mockReverter() {
        AccountTransactionReverterPort mock = mock(AccountTransactionReverterPort.class);

        setField(accountTransactionReverter, "accountTransactionReverterAdapter", mock);

        return mock;
    }

    public AccountTransactionExecutorAdapter spyExecutor() {
        AccountTransactionExecutorAdapter spy = spy(new AccountTransactionExecutorAdapter(spiCustomersTransactionContractApis));

        setField(accountTransaction, "accountTransactionExecutorPort", spy);

        return spy;
    }

    public void restoreReverter() {
        setField(accountTransactionReverter, "accountTransactionReverterAdapter",
            accountTransactionReverterPort);
    }

    public void restoreExecutor() {
        setField(accountTransaction, "accountTransactionExecutorPort", accountTransactionExecutorPort);
    }

    public void restoreAll() {
        restoreReverter();
        restoreExecutor();
    }

}
