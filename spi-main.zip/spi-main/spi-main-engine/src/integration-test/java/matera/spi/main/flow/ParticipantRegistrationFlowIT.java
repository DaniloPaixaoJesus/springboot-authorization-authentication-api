package matera.spi.main.flow;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.message.MessageTypeEntity;
import matera.spi.main.domain.service.event.receiver.MessageReceiver;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.MessageTypeRepository;
import matera.spi.main.persistence.ParticipantRepository;
import matera.spi.utils.LocalDateTimeUtils;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.opentest4j.AssertionFailedError;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

import static matera.spi.main.utils.InstantPaymentCreationUtils.CREATION_DATE_TIME;
import static matera.spi.main.utils.MessageCreationUtils.buildCamt014RptTag;
import static matera.spi.main.utils.MessageCreationUtils.buildReceivedCamt014;

import static org.assertj.core.api.Assertions.assertThat;

@IntegrationTest
class ParticipantRegistrationFlowIT {

    public static final String ENVELOPE_NAMESPACE = "https://www.bcb.gov.br/pi/camt.014/1.0";

    public static final String CORRELATION_ID = "";
    public static final Integer EVT_TYPE_CODE_PARTICIPANT = 15;
    public static final Integer EVT_STATUS_CODE_SUCCESS = 3;
    public static final LocalDateTime UPDATED_DATE = CREATION_DATE_TIME;

    public static final Integer ISPB_1 = 67676767;
    public static final Integer ISPB_2 = 96969696;

    public static final String PARTICIPANT_NAME_1 = "PIX S/A";
    public static final String TYPE_INDIRECT = "IDRT";
    public static final String STATUS_ENABLE = "ENBL";

    public static final String PARTICIPANT_NAME_2 = "INSTANT PAYMENT";
    public static final String TYPE_DIRECT = "DRCT";
    public static final String STATUS_DISABLE = "DLTD";
    public static final int ONE = 1;
    public static final int TWO = 2;

    @Autowired
    private MessageReceiver messageReceiver;

    @Autowired
    private EventRepository eventRepository;

    @Autowired
    private MessageTypeRepository messageTypeRepository;

    @Autowired
    private ParticipantRepository participantRepository;

    @BeforeEach
    void beforeEach() {
        participantRepository.deleteParticipants(PARTICIPANT_NAME_1);
        participantRepository.deleteParticipants(PARTICIPANT_NAME_2);
    }

    @AfterEach
    void afterEach() {
        participantRepository.deleteParticipants(PARTICIPANT_NAME_1);
        participantRepository.deleteParticipants(PARTICIPANT_NAME_2);
    }

    @Test
    void shouldProcessCamt014CreateParticipant() {

        String camt014RptTag = buildCamt014RptTag(ISPB_1.toString(), PARTICIPANT_NAME_1, TYPE_INDIRECT, STATUS_ENABLE);
        String camt014Message = buildReceivedCamt014(CORRELATION_ID, camt014RptTag,"1.0", ENVELOPE_NAMESPACE,
            UPDATED_DATE);

        messageReceiver.readIncomingMessage(camt014Message);

        List<EventEntity> eventsEntity = eventRepository.findAll();

        assertThat(eventsEntity).hasSize(ONE);
        assertThat(eventsEntity.get(0).getStatus().getCode()).isEqualTo(EVT_STATUS_CODE_SUCCESS);
        assertThat(eventsEntity.get(0).getEventType().getCode()).isEqualTo(EVT_TYPE_CODE_PARTICIPANT);

        ParticipantEntity participantEntity = participantRepository.findByIspb(ISPB_1).get();
        assertThat(participantEntity.getName()).isEqualTo(PARTICIPANT_NAME_1);
        assertThat(participantEntity.getActive()).isTrue();
        assertThat(participantEntity.getDirectParticipant()).isFalse();
        assertThat(participantEntity.getUpdateTimestampUtc()).isEqualTo(UPDATED_DATE);
    }

    @Test
    void shouldProcessCamt014CreateTwoParticipants() {

        String camt014RptTag1 = buildCamt014RptTag(ISPB_1.toString(), PARTICIPANT_NAME_1, TYPE_INDIRECT, STATUS_ENABLE);
        String camt014RptTag2 = buildCamt014RptTag(ISPB_2.toString(), PARTICIPANT_NAME_2, TYPE_DIRECT, STATUS_DISABLE);

        String camt014Message = buildReceivedCamt014(CORRELATION_ID, camt014RptTag1 + camt014RptTag2,"1.0", ENVELOPE_NAMESPACE,
            UPDATED_DATE);

        messageReceiver.readIncomingMessage(camt014Message);

        List<EventEntity> eventsEntity = eventRepository.findAll();

        assertThat(eventsEntity).hasSize(TWO);

        EventEntity firstEvent = eventsEntity.get(0);
        assertThat(firstEvent.getStatus().getCode()).isEqualTo(EVT_STATUS_CODE_SUCCESS);
        assertThat(firstEvent.getEventType().getCode()).isEqualTo(EVT_TYPE_CODE_PARTICIPANT);

        EventEntity secondEvent = eventsEntity.get(1);
        assertThat(secondEvent.getStatus().getCode()).isEqualTo(EVT_STATUS_CODE_SUCCESS);
        assertThat(secondEvent.getEventType().getCode()).isEqualTo(EVT_TYPE_CODE_PARTICIPANT);

        ParticipantEntity participantEntity1 = participantRepository.findByIspb(ISPB_1).get();
        assertThat(participantEntity1.getName()).isEqualTo(PARTICIPANT_NAME_1);
        assertThat(participantEntity1.getActive()).isTrue();
        assertThat(participantEntity1.getDirectParticipant()).isFalse();
        assertThat(participantEntity1.getUpdateTimestampUtc()).isEqualTo(UPDATED_DATE);

        ParticipantEntity participantEntity2 = participantRepository.findByIspb(ISPB_2).get();
        assertThat(participantEntity2.getName()).isEqualTo(PARTICIPANT_NAME_2);
        assertThat(participantEntity2.getActive()).isFalse();
        assertThat(participantEntity2.getDirectParticipant()).isTrue();
        assertThat(participantEntity2.getUpdateTimestampUtc()).isEqualTo(UPDATED_DATE);
    }

    @Test
    void shouldProcessCamt014UpdateEnableParticipation() {

        createNewParticipant(ISPB_1, PARTICIPANT_NAME_1, false, false);

        String camt014RptTag = buildCamt014RptTag(ISPB_1.toString(), PARTICIPANT_NAME_1, TYPE_INDIRECT, STATUS_ENABLE);
        String camt014Message = buildReceivedCamt014(CORRELATION_ID, camt014RptTag,"1.0", ENVELOPE_NAMESPACE,
            UPDATED_DATE);

        messageReceiver.readIncomingMessage(camt014Message);

        List<EventEntity> eventsEntity = eventRepository.findAll();

        assertThat(eventsEntity).hasSize(ONE);
        assertThat(eventsEntity.get(0).getStatus().getCode()).isEqualTo(EVT_STATUS_CODE_SUCCESS);
        assertThat(eventsEntity.get(0).getEventType().getCode()).isEqualTo(EVT_TYPE_CODE_PARTICIPANT);

        ParticipantEntity participantEntity = participantRepository.findByIspb(ISPB_1).get();
        assertThat(participantEntity.getName()).isEqualTo(PARTICIPANT_NAME_1);
        assertThat(participantEntity.getActive()).isTrue();
        assertThat(participantEntity.getDirectParticipant()).isFalse();
        assertThat(participantEntity.getUpdateTimestampUtc()).isEqualTo(UPDATED_DATE);
    }

    @Test
    void shouldProcessCamt014UpdateDisableParticipation() {
        createNewParticipant(ISPB_1, PARTICIPANT_NAME_1, false, true);


        String camt014RptTag = buildCamt014RptTag(ISPB_1.toString(), PARTICIPANT_NAME_1, TYPE_INDIRECT, STATUS_DISABLE);
        String camt014Message = buildReceivedCamt014(CORRELATION_ID, camt014RptTag,"1.0", ENVELOPE_NAMESPACE,
            UPDATED_DATE);

        messageReceiver.readIncomingMessage(camt014Message);

        List<EventEntity> eventsEntity = eventRepository.findAll();

        assertThat(eventsEntity).hasSize(ONE);
        EventEntity eventEntity = eventsEntity.get(0);
        assertThat(eventEntity.getStatus().getCode()).isEqualTo(EVT_STATUS_CODE_SUCCESS);
        assertThat(eventEntity.getEventType().getCode()).isEqualTo(EVT_TYPE_CODE_PARTICIPANT);

        ParticipantEntity participantEntity = participantRepository.findByIspb(ISPB_1).get();
        assertThat(participantEntity.getName()).isEqualTo(PARTICIPANT_NAME_1);
        assertThat(participantEntity.getActive()).isFalse();
        assertThat(participantEntity.getDirectParticipant()).isFalse();
        assertThat(participantEntity.getUpdateTimestampUtc()).isEqualTo(UPDATED_DATE);
    }

    @Test
    void shouldProcessCamt014UpdateDisable_CreateParticipation() {
        createNewParticipant(ISPB_1, PARTICIPANT_NAME_1, false, true);


        String camt014RptTagUpdate = buildCamt014RptTag(ISPB_1.toString(), PARTICIPANT_NAME_1, TYPE_INDIRECT, STATUS_DISABLE);
        String camt014RptTagCreate = buildCamt014RptTag(ISPB_2.toString(), PARTICIPANT_NAME_2, TYPE_DIRECT, STATUS_ENABLE);

        String camt014Message = buildReceivedCamt014(CORRELATION_ID, camt014RptTagUpdate+camt014RptTagCreate,
                        "1.0", ENVELOPE_NAMESPACE, UPDATED_DATE);

        messageReceiver.readIncomingMessage(camt014Message);

        List<EventEntity> eventsEntity = eventRepository.findAll();

        assertThat(eventsEntity).hasSize(TWO);

        EventEntity firstEvent = eventsEntity.get(0);
        assertThat(firstEvent.getStatus().getCode()).isEqualTo(EVT_STATUS_CODE_SUCCESS);
        assertThat(firstEvent.getEventType().getCode()).isEqualTo(EVT_TYPE_CODE_PARTICIPANT);

        EventEntity secondEvent = eventsEntity.get(1);
        assertThat(secondEvent.getStatus().getCode()).isEqualTo(EVT_STATUS_CODE_SUCCESS);
        assertThat(secondEvent.getEventType().getCode()).isEqualTo(EVT_TYPE_CODE_PARTICIPANT);

        ParticipantEntity participantEntity1 = participantRepository.findByIspb(ISPB_1).get();
        assertThat(participantEntity1.getName()).isEqualTo(PARTICIPANT_NAME_1);
        assertThat(participantEntity1.getActive()).isFalse();
        assertThat(participantEntity1.getDirectParticipant()).isFalse();
        assertThat(participantEntity1.getUpdateTimestampUtc()).isEqualTo(UPDATED_DATE);

        ParticipantEntity participantEntity2 = participantRepository.findByIspb(ISPB_2).get();
        assertThat(participantEntity2.getName()).isEqualTo(PARTICIPANT_NAME_2);
        assertThat(participantEntity2.getActive()).isTrue();
        assertThat(participantEntity2.getDirectParticipant()).isTrue();
        assertThat(participantEntity2.getUpdateTimestampUtc()).isEqualTo(UPDATED_DATE);
    }

    private void createNewParticipant(Integer ispb, String name, boolean isDirect, boolean isActive) {
        ParticipantEntity participant = new ParticipantEntity();
        participant.setIspb(ispb);
        participant.setName(name);
        participant.setDirectParticipant(isDirect);
        participant.setActive(isActive);
        participant.setUpdateTimestampUtc(UPDATED_DATE);
        participantRepository.save(participant);
    }

    private MessageTypeEntity getmessageType(){
        return messageTypeRepository.findById("camt.014")
            .orElseThrow(() -> new AssertionFailedError("Not found message type camt.014"));
    }

}
