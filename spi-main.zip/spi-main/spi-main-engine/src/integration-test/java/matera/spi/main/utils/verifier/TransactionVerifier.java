package matera.spi.main.utils.verifier;

import matera.spi.dto.RemoteAccountUIDTO;
import matera.spi.main.domain.model.event.transaction.TransactionEventEntity;
import matera.spi.main.domain.model.transaction.ReturnReceivedEntity;
import matera.spi.main.domain.model.transaction.ReturnSentEntity;
import matera.spi.main.domain.model.transaction.TransactionEntity;
import matera.spi.main.utils.verifier.expected.dto.ExpectedTransactionDTO;

import java.time.format.DateTimeFormatter;

import static org.assertj.core.api.Assertions.assertThat;

public class TransactionVerifier {

	private TransactionVerifier() {/*utility classes should not be instantiated*/}

	public static void verifyTransaction(TransactionEntity actual, ExpectedTransactionDTO expected) {
		assertThat(actual.getTransactionType()).isEqualTo(expected.getType());
        assertThat(actual.getCustomerInitTimestampUtc()).isEqualTo(expected.getCustomerInitTimestamp());
		//verify receiver
        assertThat(actual.getReceiverParticipant().getIspb()).isEqualTo(expected.getReceiver().getInstitutionISPB());
        if (expected.getReceiver().getAccount() != null) {
            assertThat(actual.getReceiverAccount().getTaxId()).isEqualTo(expected.getReceiver().getTaxId());
            RemoteAccountUIDTO receiverAccount = expected.getReceiver().getAccount();
            assertThat(actual.getReceiverAccount().getBranch()).isEqualTo(receiverAccount.getBranch());
            assertThat(actual.getReceiverAccount().getAccount()).isEqualTo(receiverAccount.getAccountNumber());
            assertThat(actual.getReceiverAccount().getAddressingKey().orElse(null)).isEqualTo(expected.getReceiver().getAddressingKey());
            assertThat(actual.getReceiverAccount().getAccountType()).isEqualTo(receiverAccount.getAccountType().toString());
        } else {
            assertThat(actual.getReceiverAccount()).isNull();
        }
		assertThat(actual.getChargeBearer()).isEqualTo(expected.getChargeBearer());

		//verify payer
        assertThat(actual.getPayerParticipant().getIspb()).isEqualTo(expected.getPayer().getInstitutionISPB());
        if (expected.getPayer().getAccount() != null) {
            assertThat(actual.getPayerAccount().getName()).isEqualTo(expected.getPayer().getName());
            assertThat(actual.getPayerAccount().getTaxId()).isEqualTo(expected.getPayer().getTaxId());
            RemoteAccountUIDTO payerAccount = expected.getPayer().getAccount();
            assertThat(actual.getPayerAccount().getAccount()).isEqualTo(payerAccount.getAccountNumber());
            assertThat(actual.getPayerAccount().getBranch()).isEqualTo(payerAccount.getBranch());
            assertThat(actual.getPayerAccount().getAccountType()).isEqualTo(payerAccount.getAccountType().toString());
        } else {
            assertThat(actual.getPayerAccount()).isNull();
        }

		assertThat(actual.getInitiatingInstitutionTaxId()).isEqualTo(expected.getInitiatingInstitutionTaxId());
		assertThat(actual.getEndToEndId()).isEqualTo(expected.getEndToEndId());
		assertThat(actual.getReceiverReconIdentifier()).isEqualTo(expected.getReceiverReconIdentifier());
		assertThat(actual.getAdditionalInformation()).isEqualTo(expected.getAdditionalInformation());
		if (actual instanceof ReturnSentEntity) {
            assertThat(((ReturnSentEntity) actual).getUnstructured()).isEqualTo(expected.getUnstructured());
        } else if (actual instanceof ReturnReceivedEntity) {
            assertThat(((ReturnReceivedEntity) actual).getUnstructured()).isEqualTo(expected.getUnstructured());
        }
		assertThat(actual.getPriority().getCode()).isEqualTo(expected.getPriorityCode());
		assertThat(actual.getSettlementMethod()).isEqualTo(expected.getSettlementMethod());

		assertThat(actual.getReturnReasonInformationCode()).isEqualTo(expected.getReturnReasonInformationCode());
	}

	public static void verifyTransactionAndEventRelation(TransactionEventEntity eventEntity, TransactionEntity transactionEntity) {
		assertThat(eventEntity.getTransactionEntity())
				.as("Event related to Transaction").isEqualTo(transactionEntity);
		assertThat(transactionEntity.getEvent())
				.as("Transaction related to Event").isEqualTo(eventEntity);
	}

}
