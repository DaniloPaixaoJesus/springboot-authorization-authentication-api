package matera.spi.main.flow;

import com.matera.commons.utils.asserts.Asserts;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.EmailNotificationDTO;
import matera.spi.main.domain.model.EmailNotificationEntity;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.MessageNotificationEntity;
import matera.spi.main.domain.model.event.MessageNotificationEventEntity;
import matera.spi.main.domain.model.message.MessageTypeEntity;
import matera.spi.main.domain.service.EmailNotificationService;
import matera.spi.main.domain.service.event.receiver.MessageReceiver;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.MessageNotificationEventRepository;
import matera.spi.main.persistence.MessageNotificationRepository;
import matera.spi.main.persistence.MessageTypeRepository;
import matera.spi.utils.LocalDateTimeUtils;

import com.dumbster.smtp.SimpleSmtpServer;
import com.dumbster.smtp.SmtpMessage;
import org.assertj.core.api.Assertions;
import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.Test;
import org.opentest4j.AssertionFailedError;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static matera.spi.main.utils.MessageCreationUtils.buildReceivedAdmi004;

import static org.hamcrest.Matchers.hasSize;
import static org.junit.jupiter.api.Assertions.assertEquals;

@IntegrationTest
@Transactional
class NotificationFlowIT {

    private static final String EVT_CD = "SPI";
    private static final String EVT_DESC = "mudança da data contábil";

    private static final String CORRELATION_ID = "M005737687cd679d901c941d0aad880a";
    private static final Integer EVT_TYPE_CODE_NOTIFICATION = 3;
    private static final Integer EVT_STATUS_CODE_SUCCESS = 3;

    @Value("${spring.mail.port}")
    private Integer smptPort;

    private static final String SUBJECT = "Subject";
    private static final String TO = "To";
    private static final String SUBJECT_MSG = "=?UTF-8?Q?Aviso_sobre_a_opera=C3=A7=C3=A3o_do_SPI?=";
    public static final String TEXT = "mudan=C3=A7a da data cont=C3=A1bil";
    public static final String ANY_EMAIL = "mail@anymail.com";
    public static final String ANY_EMAIL_IDENTIFICATION = "99999010";
    public static final String TEST_EMAIL = "mail@testmail.com";
    public static final String TEST_EMAIL_IDENTIFICATION = "00038166";

    @Autowired
	private MessageReceiver messageReceiver;

    @Autowired
	private EventRepository eventRepository;

    @Autowired
    private MessageTypeRepository messageTypeRepository;

    @Autowired
    private MessageNotificationRepository messageNotificationRepository;

    @Autowired
    private MessageNotificationEventRepository notificationEventRepository;

    @Autowired
    private EmailNotificationService emailNotificationService;

	@Test
	void shouldProcessNotificationAdmi004() throws IOException {
		String admi004Message = buildReceivedAdmi004(EVT_CD, EVT_DESC,"1.0", LocalDateTimeUtils.getUtcLocalDateTime());

        //smtp server
        try (SimpleSmtpServer mailServer = SimpleSmtpServer.start(smptPort)) {
            messageReceiver.readIncomingMessage(admi004Message);
        }

        EventEntity eventEntity = eventRepository
                                    .findFirstByCorrelationIdAndMessageType(CORRELATION_ID, getmessageType())
                                    .orElse(null);

        Asserts.assertNotNull(eventEntity);
        Asserts.assertEquals(CORRELATION_ID, eventEntity.getCorrelationId());
        Asserts.assertEquals(EVT_STATUS_CODE_SUCCESS, eventEntity.getStatus().getCode());
        Asserts.assertEquals(EVT_TYPE_CODE_NOTIFICATION, eventEntity.getEventType().getCode());

        MessageNotificationEventEntity notificationEventEntity = notificationEventRepository.findById(eventEntity.getId()).orElse(null);
        Asserts.assertNotNull(notificationEventEntity);

        UUID messageNotificationUUID = notificationEventEntity.getMessageNotificationEntity().getId();
        Asserts.assertNotNull(messageNotificationUUID);

        MessageNotificationEntity messageNotificationEntity = messageNotificationRepository.findById(messageNotificationUUID).orElse(null);
        Asserts.assertNotNull(messageNotificationEntity);
        Asserts.assertEquals(EVT_CD, messageNotificationEntity.getCodeMessage());
        Asserts.assertEquals(EVT_DESC, messageNotificationEntity.getDescription());
	}

    @Test
    void shouldProcessNotificationAdmi004SendNotification() throws IOException {
        /*  STEPS
        1- if the configuration is active (spi.mainengine.send-email) send the email
        2 - The body of the email must be the content of the notification received
        3- The subject of the email must be "Aviso sobre a operação do SPI".
        4- at the end of sending update the table ME_MESSAGE_NOTIFICATION in field NOTIFICATION_SENT
        */

	    //build admi004Message
	    String admi004Message = buildReceivedAdmi004(EVT_CD, EVT_DESC,"1.0", LocalDateTimeUtils.getUtcLocalDateTime());

	    //save 2 EmailNotificationDTO's
        List<EmailNotificationDTO> notificationDTOList = createEmailsNotificationDTOs();
        notificationDTOList.forEach((e) -> {
            emailNotificationService.save(getEmailNotificationEntity(e));
        });

        //smtp server
        try (SimpleSmtpServer mailServer = SimpleSmtpServer.start(smptPort)) {
            //STEP - 1
            //Notification Flow Start
            messageReceiver.readIncomingMessage(admi004Message);
            //Emails sent in the stream
            List<SmtpMessage> emails = mailServer.getReceivedEmails();
            MatcherAssert.assertThat(emails, hasSize(1));

            String emailTo =  emails.get(0).getHeaderValue(TO);
            Assertions.assertThat(emailSplit(emailTo))
                .hasSize(2)
                .containsExactlyInAnyOrder(ANY_EMAIL, TEST_EMAIL);
            //STEP - 2
            assertEquals(TEXT, emails.get(0).getBody());
            //STEP - 3
            assertEquals(SUBJECT_MSG, emails.get(0).getHeaderValue(SUBJECT));
        }

        //STEP - 4
        List<MessageNotificationEntity> messageNotifications = messageNotificationRepository.findAll();
        MatcherAssert.assertThat(messageNotifications, hasSize(1));
        String notificationSent = messageNotifications.get(0).getNotificationSent();
        //Check padding notificationSent
        Assertions.assertThat(emailSplit(notificationSent))
            .hasSize(2)
            .containsExactlyInAnyOrder(ANY_EMAIL, TEST_EMAIL);
    }

    private String[] emailSplit(String email) {
        String[] emailSplit = email.split(", ");
        return emailSplit;
    }

    private MessageTypeEntity getmessageType(){
        return messageTypeRepository.findById("admi.004")
            .orElseThrow(() -> new AssertionFailedError("Not found message type admi.004"));
    }

    private List<EmailNotificationDTO> createEmailsNotificationDTOs(){
        List<EmailNotificationDTO> notificationDTOList = new ArrayList<>();

        EmailNotificationDTO emailNotificationDTO1 = new EmailNotificationDTO();
        emailNotificationDTO1.email(ANY_EMAIL);
        emailNotificationDTO1.dateTimeRegister(LocalDateTime.now());
        emailNotificationDTO1.id(UUID.randomUUID());
        emailNotificationDTO1.identification(ANY_EMAIL_IDENTIFICATION);
        notificationDTOList.add(emailNotificationDTO1);

        EmailNotificationDTO emailNotificationDTO2 = new EmailNotificationDTO();
        emailNotificationDTO2.email(TEST_EMAIL);
        emailNotificationDTO2.dateTimeRegister(LocalDateTime.now());
        emailNotificationDTO2.id(UUID.randomUUID());
        emailNotificationDTO2.identification(TEST_EMAIL_IDENTIFICATION);
        notificationDTOList.add(emailNotificationDTO2);

        return notificationDTOList;
    }

    private EmailNotificationEntity getEmailNotificationEntity(EmailNotificationDTO emailNotificationDTO){
        EmailNotificationEntity emailNotificationEntity = new EmailNotificationEntity();
        emailNotificationEntity.setUuid(emailNotificationDTO.getId());
        emailNotificationEntity.setIdentification(emailNotificationDTO.getIdentification());
        emailNotificationEntity.setEmail(emailNotificationDTO.getEmail());
        emailNotificationEntity.setDateTimeRegister(LocalDateTimeUtils.getUtcLocalDateTime());
        return emailNotificationEntity;
    }

}
