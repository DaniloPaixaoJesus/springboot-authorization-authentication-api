package matera.spi.lm.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.lm.domain.model.spb.SpbEventEntity;
import matera.spi.lm.domain.model.spb.SpbMessageEntity;
import matera.spi.lm.domain.model.spb.deposit.IpAccountDepositDetailsEntity;
import matera.spi.lm.domain.model.spb.deposit.IpAccountDepositEventEntity;
import matera.spi.main.domain.model.event.EventTypeEntity;
import matera.spi.main.persistence.EventTypeRepository;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.mockito.internal.util.collections.Sets;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.core.Is.is;


@IntegrationTest
class SpbEventRepositoryTest {

    @Autowired
    private SpbEventRepository spbEventRepository;

    @Autowired
    private SpbMessageRepository spbMessageRepository;

    @Autowired
    private EventTypeRepository eventTypeRepository;

    @AfterEach
    void afterEach() {
        spbMessageRepository.deleteAll();
        spbEventRepository.deleteAll();
    }

    @Test
    @Transactional(propagation = Propagation.NEVER)
    void findBySpbEventId() {
        IpAccountDepositEventEntity spbDepositEventEntity = createSpbDepositEventEntity();
        spbMessageRepository.saveAndFlush(getSpbMessageEntity(spbDepositEventEntity));

        Optional<SpbEventEntity> spbEventEntity = spbEventRepository.findDetailsById(spbDepositEventEntity.getId());

        assertThat(spbEventEntity.isPresent(), is(true));
        assertThat(spbEventEntity.get().getSpbMessageEntity(), hasSize(1));;

        spbEventEntity.get().getSpbMessageEntity().forEach(item -> System.out.println(item.getTimestamp()));
        List<SpbMessageEntity> collect = new ArrayList<>(spbEventEntity.get().getSpbMessageEntity());
        assertThat(collect.get(0).getTimestamp(), is(LocalDateTime.of(2020, 1, 2, 1, 3, 5)));
    }

    @Test
    void testGetAnSpbEventEntityById() {
        createSpbDepositEventEntity();
        Optional<SpbEventEntity> spbEventId = spbEventRepository.findBySpbEventId(1L);
        assertThat(spbEventId.isPresent(), is(true));
    }

    private void setBasicEventInfo(SpbEventEntity spbEventEntity) {
        EventTypeEntity eventTypeEntity = eventTypeRepository.findById(10).orElseThrow(() -> new RuntimeException("EventType not found"));
        spbEventEntity.setSpbEventId(1L);
        spbEventEntity.setControlNumber("1a2b3c");
        spbEventEntity.setMovementDate(LocalDate.of(2020, 5, 11));
        spbEventEntity.setSpbMessageEntity(Sets.newSet());
        spbEventEntity.setValue(BigDecimal.TEN);
        spbEventEntity.setResponsible("Responsible");
        spbEventEntity.setInitiationTimestampUTC(LocalDateTime.now());
        spbEventEntity.setInitiatorIspb(1);
        spbEventEntity.setResponsible("ResponsibleOfEvent");
        spbEventEntity.setInitiatorIspb(12345678);
        spbEventEntity.setStatus(eventTypeEntity.getInitialStatus());
    }

    private SpbMessageEntity getSpbMessageEntity(IpAccountDepositEventEntity spbDepositEventEntity) {
        SpbMessageEntity spbMessageEntity = new SpbMessageEntity();
        spbMessageEntity.setMessageCode("MCODE");
        spbMessageEntity.setMessageContents("CONTENT");
        spbMessageEntity.setEvent(spbDepositEventEntity);
        spbMessageEntity.setTimestamp(LocalDateTime.of(2020, 1, 2, 1, 3, 5));
        return spbMessageEntity;
    }

    private IpAccountDepositDetailsEntity createSpbDepositEventDetailsEntity() {
        IpAccountDepositDetailsEntity detailsEntity = new IpAccountDepositDetailsEntity();
        detailsEntity.setIspbif(100L);
        detailsEntity.setIspbpspi(999L);
        return detailsEntity;
    }

    private IpAccountDepositEventEntity createSpbDepositEventEntity() {
        final IpAccountDepositEventEntity depositEntity = new IpAccountDepositEventEntity();
        depositEntity.setIpAccountDepositDetails(createSpbDepositEventDetailsEntity());
        setBasicEventInfo(depositEntity);
        spbEventRepository.saveAndFlush(depositEntity);
        return depositEntity;
    }

}
