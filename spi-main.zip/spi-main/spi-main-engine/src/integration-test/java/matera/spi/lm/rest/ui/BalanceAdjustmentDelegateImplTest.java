package matera.spi.lm.rest.ui;

import matera.spi.commons.IntegrationTest;

import io.restassured.RestAssured;
import io.restassured.response.ExtractableResponse;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.web.server.LocalServerPort;

import java.util.List;

import static matera.spi.mainengine.utils.Asserts.assertThat;

import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.is;

@IntegrationTest
class BalanceAdjustmentDelegateImplTest {

    @LocalServerPort
    private int port;

    @BeforeEach
    void beforeEach() {
        RestAssured.port = port;
    }

    @Test
    void getCreditAdjustmentsTypesV1() {
        List<String> response = RestAssured
            .when()
                .get("/ui/v1/balance/adjustment-types/CREDIT")
            .thenReturn()
                .path("data");

        assertThat(response, hasItem("LPI0001"));
        assertThat(response, hasItem("LPI0002"));
        assertThat(response, hasItem("SEL1009"));
        assertThat(response, hasItem("PACS.004"));
        assertThat(response, hasItem("PACS.008"));
        assertThat(response, hasItem("LPI0006"));
    }

    @Test
    void getDebitAdjustmentsTypesV1() {
        List<String> response = RestAssured
            .when()
                .get("/ui/v1/balance/adjustment-types/DEBIT")
            .thenReturn()
                .path("data");

        assertThat(response, hasItem("LPI0003"));
        assertThat(response, hasItem("LPI0004"));
        assertThat(response, hasItem("SEL1016"));
        assertThat(response, hasItem("PACS.004"));
        assertThat(response, hasItem("PACS.008"));
    }

    @Test
    void shouldReturnWithDebitLowerCase() {
        List<String> response = RestAssured
            .when()
                .get("/ui/v1/balance/adjustment-types/debit")
            .thenReturn()
                .path("data");

        assertThat(response, hasItem("LPI0003"));
        assertThat(response, hasItem("LPI0004"));
        assertThat(response, hasItem("SEL1016"));
        assertThat(response, hasItem("PACS.004"));
        assertThat(response, hasItem("PACS.008"));
    }
    @Test
    void shouldThrownWrongType() {
        ExtractableResponse<Response> response = RestAssured
            .when()
                .get("/ui/v1/balance/adjustment-types/not-exist-type")
            .then()
                .extract();

        assertThat(response.path("error[0].code"), is("SPI-LM-018"));
        assertThat(response.path("error[0].message"), is("The transaction type not-exist-type is not valid"));

    }

}
