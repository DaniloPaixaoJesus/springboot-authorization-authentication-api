package matera.spi.main.utils;

import com.matera.spi.messaging.model.MessageSentResponseDTO;
import matera.spi.dto.*;

import org.apache.commons.lang.RandomStringUtils;
import org.jetbrains.annotations.NotNull;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static matera.spi.utils.IspbUtils.leftPadIspb;

public final class InstantPaymentCreationUtils {

	public static final int PARTICIPANT_ISPB = 13370835;
    public static final String LEFT_PADDED_PARTICIPANT_ISPB = leftPadIspb(PARTICIPANT_ISPB);
	public static final int EXTERNAL_ISPB = 250699;
    public static final String LEFT_PADDED_EXTERNAL_ISPB = leftPadIspb(EXTERNAL_ISPB);
	public static final int BACEN_ISPB = 38166;
    public static final String LEFT_PADDED_BACEN_ISPB = leftPadIspb(BACEN_ISPB);
	public static final String PARTICIPANT_ACCOUNT = "35";
	public static final String PARTICIPANT_BRANCH = "1";
	public static final String PARTICIPANT_TAX_ID = "31953073832";
	public static final String EXTERNAL_ACCOUNT = "123456789-5";
	public static final String EXTERNAL_BRANCH = "5573";
	public static final String EXTERNAL_TAX_ID = "77928135094";
    public static final String PAYER_NAME = "João da Silva";
	public static final String SETTLEMENT_METHOD_CLRG = "CLRG";
	public static final String CHARGE_BEARER_SLEV = "SLEV";
	public static final String INSTRUCTION_PRIORITY_HIGH = "HIGH";
	public static final double DEBIT_VALUE = 100.37;
	public static final BigDecimal BIG_DEBIT_VALUE = BigDecimal.valueOf(DEBIT_VALUE);
	public static final LocalDateTime ACCEPTANCE_DATE_TIME = LocalDateTime.parse("2020-04-10T10:01:05.601Z", DateTimeFormatter.ISO_DATE_TIME);
	public static final String TRANSACTION_IDENTIFICATION = "TRANSACTION Identification";
	public static final long ORGANISATION_IDENTIFICATION = 47450396000132L;
	public static final String ADDITIONAL_INFORMATION = "Campo Livre";
	public static final LocalDateTime CREATION_DATE_TIME = LocalDateTime.parse("2020-04-10T10:01:07.777Z", DateTimeFormatter.ISO_DATE_TIME);
	public static final String CLEARING_RESPONSE_TIMESTAMP_STR = "2020-04-01T14:52:04.666Z";
	public static final LocalDateTime CLEARING_RESPONSE_DATE_TIME = LocalDateTime.parse(CLEARING_RESPONSE_TIMESTAMP_STR, DateTimeFormatter.ISO_DATE_TIME);

	public static final String ADDRESSING_KEY = "ADDRESSING_KEY";
	public static final String CACC = "CACC";

    private InstantPaymentCreationUtils() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public enum OperationType {
        PAYMENT, RECEIPT
    }

    public static String getRandomPiResourceId() {
        return RandomStringUtils.randomAlphabetic(12);
    }

    @NotNull
    public static MessageSentResponseDTO createMessageSentResponseDTO(String piResourceId) {
        MessageSentResponseDTO responseDTO = new MessageSentResponseDTO();
        responseDTO.setPiResourceID(piResourceId);
        return responseDTO;
    }

    @NotNull
    public static MessageSentResponseDTO createMessageSentResponseDTO() {
        return createMessageSentResponseDTO(getRandomPiResourceId());
    }

    public static InstantPaymentsUIDTO createInstantPaymentsUIDTOMock(String endToEndId, OperationType operationType) {
        return createInstantPaymentsUIDTOMock(Collections.singletonList(endToEndId), operationType);
    }

    public static InstantPaymentsUIDTO createInstantPaymentsUIDTOMock(List<String> endToEndIds, OperationType operationType) {
        InstantPaymentsUIDTO instantPaymentsUIDTO = new InstantPaymentsUIDTO();
        instantPaymentsUIDTO.setCreationDateTime(CREATION_DATE_TIME);
        instantPaymentsUIDTO.setInstructionPriority(INSTRUCTION_PRIORITY_HIGH);
        instantPaymentsUIDTO.setPayments(createListOfPaymentsUiDTOMock(endToEndIds, operationType));
        instantPaymentsUIDTO.setSettlementMethod(SETTLEMENT_METHOD_CLRG);
        return instantPaymentsUIDTO;
    }

    private static List<PaymentsUIDTO> createListOfPaymentsUiDTOMock(List<String> endToEndIds, OperationType operationType) {
        return endToEndIds.stream()
                .map(endToEndId -> InstantPaymentCreationUtils.createPaymentsUiDTOMock(endToEndId, operationType))
                .collect(Collectors.toList());
    }

    private static PaymentsUIDTO createPaymentsUiDTOMock(String endToEndId, OperationType operationType) {
        PaymentsUIDTO paymentsUIDTO = new PaymentsUIDTO();
        paymentsUIDTO.setAcceptanceDateTime(ACCEPTANCE_DATE_TIME);
        paymentsUIDTO.setChargeBearer(CHARGE_BEARER_SLEV);
        paymentsUIDTO.setEndToEndID(endToEndId);
        paymentsUIDTO.setInterbankSettlementAmount(BigDecimal.valueOf(DEBIT_VALUE));
        paymentsUIDTO.setOrganisationIdentification(ORGANISATION_IDENTIFICATION);
        paymentsUIDTO.setTransactionIdentification(TRANSACTION_IDENTIFICATION);
        paymentsUIDTO.setUnstructured(ADDITIONAL_INFORMATION);
        paymentsUIDTO.setPayer(createPayerUIDTOMock(isPayment(operationType)));
        paymentsUIDTO.setReceiver(createReceiverUIDTOMock(isReceipt(operationType)));

        return paymentsUIDTO;
    }

    private static PayerUIDTO createPayerUIDTOMock(boolean isPayment) {
        PayerUIDTO payerUIDTO = new PayerUIDTO();
        payerUIDTO.setInstitutionISPB(getIspb(isPayment));
        payerUIDTO.setName(PAYER_NAME);
        payerUIDTO.setTaxId(getTaxId(isPayment));
        payerUIDTO.setAccount(createRemoteAccountUIDTOMock(getAccount(isPayment), getBranch(isPayment)));

        return payerUIDTO;
    }

    private static PayerUIDTO createPayerUIDTOMock(boolean isPayment, int ispb) {
        PayerUIDTO payerUIDTO = new PayerUIDTO();
        payerUIDTO.setInstitutionISPB(ispb);
        payerUIDTO.setName(PAYER_NAME);
        payerUIDTO.setTaxId(getTaxId(isPayment));
        payerUIDTO.setAccount(createRemoteAccountUIDTOMock(getAccount(isPayment), getBranch(isPayment)));

        return payerUIDTO;
    }

    private static ReceiverUIDTO createReceiverUIDTOMock(boolean isReceipt) {
        ReceiverUIDTO receiverUIDTO = new ReceiverUIDTO();
        receiverUIDTO.setAddressingKey(ADDRESSING_KEY);
        receiverUIDTO.setInstitutionISPB(getIspb(isReceipt));
        receiverUIDTO.setTaxId(getTaxId(isReceipt));
        receiverUIDTO.setAccount(createRemoteAccountUIDTOMock(getAccount(isReceipt), getBranch(isReceipt)));

        return receiverUIDTO;
    }

    private static ReceiverUIDTO createReceiverUIDTOMock(boolean isReceipt, int ispb) {
        ReceiverUIDTO receiverUIDTO = new ReceiverUIDTO();
        receiverUIDTO.setAddressingKey(ADDRESSING_KEY);
        receiverUIDTO.setInstitutionISPB(ispb);
        receiverUIDTO.setTaxId(getTaxId(isReceipt));
        receiverUIDTO.setAccount(createRemoteAccountUIDTOMock(getAccount(isReceipt), getBranch(isReceipt)));

        return receiverUIDTO;
    }

    private static String getTaxId(boolean isParticipant) {
        return isParticipant ? PARTICIPANT_TAX_ID : EXTERNAL_TAX_ID ;
    }

    private static int getIspb(boolean isParticipant) {
        return isParticipant ? PARTICIPANT_ISPB : EXTERNAL_ISPB ;
    }

    @NotNull
    private static String getAccount(boolean isParticipant) {
        return isParticipant ? PARTICIPANT_ACCOUNT : EXTERNAL_ACCOUNT;
    }

    @NotNull
    private static String getBranch(boolean isParticipant) {
        return isParticipant ? PARTICIPANT_BRANCH : EXTERNAL_BRANCH;
    }

    private static boolean isPayment(OperationType operationType) {
        return OperationType.PAYMENT == operationType;
    }

    private static boolean isReceipt(OperationType operationType) {
        return OperationType.RECEIPT == operationType;
    }

    private static RemoteAccountUIDTO createRemoteAccountUIDTOMock(String account, String branch) {
        RemoteAccountUIDTO remoteAccountUIDTO = new RemoteAccountUIDTO();
        remoteAccountUIDTO.setAccountNumber(account);
        remoteAccountUIDTO.setBranch(branch);
        remoteAccountUIDTO.setAccountType(AccountTypeUIDTO.CACC);

        return remoteAccountUIDTO;
    }

}
