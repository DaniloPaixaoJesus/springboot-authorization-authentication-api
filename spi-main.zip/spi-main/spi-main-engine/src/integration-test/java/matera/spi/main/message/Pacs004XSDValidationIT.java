package matera.spi.main.message;

import com.matera.spi.messaging.api.MessagesApi;
import com.matera.spi.messaging.api.SPIMessagingApis;
import com.matera.spi.messaging.model.MessageSpecificationDTO;
import com.matera.spi.thirdparties.customers.transactions.model.LancamentoResponseV2DTO;
import com.matera.spi.webhook.transaction.model.TransactionIdValidationResponseDTO;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.InstantPaymentsUIDTO;
import matera.spi.dto.ReturnSettlementUIWapperDTO;
import matera.spi.dto.ReturnSettlementUIWapperDTO.ReturnReasonInformationEnum;
import matera.spi.main.application.service.ReturnApplicationService;
import matera.spi.main.application.service.ReturnApplicationUIService;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.service.CorrelationIdGenerator;
import matera.spi.main.domain.service.MessageSender;
import matera.spi.main.domain.service.ReceiptEventValidator;
import matera.spi.main.domain.service.WebhookTransactionValidationService;
import matera.spi.main.domain.service.event.receiver.AccountTransactionReceiver;
import matera.spi.main.domain.service.event.receiver.MessageReceiver;
import matera.spi.main.domain.service.transaction.AccountTransaction;
import matera.spi.main.dto.AccountTransactionRequestDTO;
import matera.spi.main.dto.AccountTransactionResponseDTO;
import matera.spi.main.dto.AccountTransactionValidationRequestDTO;
import matera.spi.main.dto.QueryBalanceRequestDTO;
import matera.spi.main.dto.QueryBalanceResponseDTO;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.MessageRepository;
import matera.spi.main.persistence.ReceiptRepository;
import matera.spi.main.transactions.port.AccountTransactionExecutorPort;
import matera.spi.main.utils.InstantPaymentCreationUtils;

import org.apache.commons.lang.RandomStringUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collections;

import javax.persistence.EntityManager;

import static matera.spi.main.utils.InstantPaymentCreationUtils.ADDITIONAL_INFORMATION;
import static matera.spi.main.utils.InstantPaymentCreationUtils.CHARGE_BEARER_SLEV;
import static matera.spi.main.utils.InstantPaymentCreationUtils.INSTRUCTION_PRIORITY_HIGH;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.SETTLEMENT_METHOD_CLRG;
import static matera.spi.main.utils.InstantPaymentCreationUtils.createInstantPaymentsUIDTOMock;
import static matera.spi.main.utils.InstantPaymentCreationUtils.createMessageSentResponseDTO;
import static matera.spi.main.utils.MessageCreationUtils.buildPacs002Response;
import static matera.spi.main.utils.MessageCreationUtils.buildReceivedPacs008;
import static matera.spi.main.utils.MessageCreationUtils.buildTxInfAndSts;
import static matera.spi.main.utils.XmlValidator.validateWithXSD;

import static com.matera.spi.thirdparties.customers.transactions.model.LancamentoResponseV2DTO.ClassificacaoCategoriaContaSPIEnum.CACC;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@IntegrationTest
@Transactional
class Pacs004XSDValidationIT {

    @Autowired
    private AccountTransaction accountTransaction;
    @Autowired
    private AccountTransactionExecutorPort accountTransactionExecutorPort;
    @Mock
    private AccountTransactionExecutorPort mockedAccountTransactionExecutorPort;

    @Autowired
    private MessageSender messageSender;
    @Autowired
    private SPIMessagingApis spiMessagingApisBean;
    @Mock
    private SPIMessagingApis mockedSpiMessagingApis;
    @Mock
    private MessagesApi mockedMessagesApi;

    @Autowired
    private MessageReceiver messageReceiver;
    @Autowired
    private ReceiptRepository receiptRepository;
    @Autowired
    private MessageRepository messageRepository;
    @Autowired
    private EventRepository eventRepository;
    @Autowired
    private EntityManager entityManager;
    @Autowired
    private ReturnApplicationUIService returnApplicationUIService;
    @Autowired
    private ReturnApplicationService returnApplicationService;
    @Autowired
    private AccountTransactionReceiver accountTransactionReceiver;
    @Autowired
    private ReceiptEventValidator receiptEventValidator;
    @Mock
    private WebhookTransactionValidationService mockWebhookTransactionValidationService;
    @Autowired
    private WebhookTransactionValidationService webhookTransactionValidationService;


    @Captor
    private ArgumentCaptor<MessageSpecificationDTO> messageSpecificationDTOArgumentCaptor;
    @Value("classpath:xsd/version/*/pacs.004.*.xsd")
    Resource[] pacs004XSDResources;

    @BeforeEach
    public void setup() {

        LancamentoResponseV2DTO lancamentoResponseV2DTO = new LancamentoResponseV2DTO();

        lancamentoResponseV2DTO.setClassificacaoCategoriaContaSPI(CACC);
        lancamentoResponseV2DTO.setCpfCnpjTitular(BigDecimal.valueOf(92082843521L));

        when(mockedAccountTransactionExecutorPort.makeTransaction(any(AccountTransactionRequestDTO.class))).thenAnswer(
            (Answer<AccountTransactionResponseDTO>) invocation -> AccountTransactionResponseDTO.builder()
                .transactionId(BigDecimal.valueOf(1L))
                .lancamentoResponseV2DTO(lancamentoResponseV2DTO)
                .build());

        when(mockedAccountTransactionExecutorPort.validateCredit(any(AccountTransactionValidationRequestDTO.class)))
            .thenReturn(false);

        when(mockedAccountTransactionExecutorPort.queryBalance(any(QueryBalanceRequestDTO.class))).thenAnswer(
            (Answer<QueryBalanceResponseDTO>) invocation -> QueryBalanceResponseDTO.builder()
                .balanceAvailable(BigDecimal.valueOf(1234546789L))
                .accountingBalance(BigDecimal.valueOf(1234546L))
                .blockedBalance(BigDecimal.valueOf(123454L))
                .accountingBalance(BigDecimal.valueOf(12345L))
                .creditLimitAvailable(BigDecimal.valueOf(1234546789L))
                .date(LocalDate.now())
                .build());

        when(mockedSpiMessagingApis.messagesApi()).thenReturn(mockedMessagesApi);
        messageSender.setSpiMessagingApis(mockedSpiMessagingApis);
        accountTransaction.setAccountTransactionExecutorPort(mockedAccountTransactionExecutorPort);

        ReflectionTestUtils.setField(receiptEventValidator, "webhookTransactionValidationService", mockWebhookTransactionValidationService);

        when(mockWebhookTransactionValidationService.queryValidator(any(), any())).thenReturn(new TransactionIdValidationResponseDTO().shouldReceive(false).motive("Web hook rejection."));
    }

    @AfterEach
    void tearDown() {
        accountTransaction.setAccountTransactionExecutorPort(accountTransactionExecutorPort);
        messageSender.setSpiMessagingApis(spiMessagingApisBean);
        ReflectionTestUtils.setField(receiptEventValidator, "webhookTransactionValidationService", webhookTransactionValidationService);

    }

    private static String getRandomPiResourceId() {
        return RandomStringUtils.randomAlphabetic(12);
    }

    @Test
    void validatePacs004SentWithAllFields() {
        String originalEndToEndId = receiveAReceipt();

        BigDecimal returnValue = BigDecimal.ONE;

        String returnEndToEndId =
            CorrelationIdGenerator.generateCorrelactionIdPacs004(String.valueOf(PARTICIPANT_ISPB));

        ReturnSettlementUIWapperDTO returnSettlementUIWapperDTO =
            new ReturnSettlementUIWapperDTO()
                .originalEndToEndIdentification(originalEndToEndId)
                .returnEndToEndIdentification(returnEndToEndId)
                .creationDateTime(LocalDateTime.now(ZoneOffset.UTC))
                .settlementMethod(SETTLEMENT_METHOD_CLRG)
                .settlementPriority(INSTRUCTION_PRIORITY_HIGH)
                .chargeBearer(CHARGE_BEARER_SLEV)
                .additionalInformation(ADDITIONAL_INFORMATION)
                .unstructured(" MORE ADDITIONAL INFO ")
                .returnReasonInformation(ReturnReasonInformationEnum.AM05)
                .debtorAgent((long) PARTICIPANT_ISPB) // not used
                .creditorAgent((long) PARTICIPANT_ISPB) // not used
                .returnedInterbankSettlementAmount(returnValue);

        returnApplicationUIService.sentReturn(returnSettlementUIWapperDTO);
        String xmlSent = getXmlMessage();

        validateWithXSD(xmlSent, pacs004XSDResources[0]);
    }

    @ParameterizedTest
    @NullAndEmptySource
    void validatePacs004SentWithOnlyRequiredFields(String nullAndEmpty) {
        String originalEndToEndId = receiveAReceipt();

        BigDecimal returnValue = BigDecimal.ONE;

        String returnEndToEndId =
            CorrelationIdGenerator.generateCorrelactionIdPacs004(String.valueOf(PARTICIPANT_ISPB));

        ReturnSettlementUIWapperDTO returnSettlementUIWapperDTO =
            new ReturnSettlementUIWapperDTO()
                .originalEndToEndIdentification(originalEndToEndId)
                .returnEndToEndIdentification(returnEndToEndId)
                .creationDateTime(LocalDateTime.now(ZoneOffset.UTC))
                .settlementMethod(SETTLEMENT_METHOD_CLRG)
                .settlementPriority(INSTRUCTION_PRIORITY_HIGH)
                .chargeBearer(CHARGE_BEARER_SLEV)
                .additionalInformation(nullAndEmpty)
                .unstructured(nullAndEmpty)
                .returnReasonInformation(ReturnReasonInformationEnum.AM09)
                .returnedInterbankSettlementAmount(returnValue)
            ;

        returnApplicationUIService.sentReturn(returnSettlementUIWapperDTO);
        String xmlSent = getXmlMessage();

        validateWithXSD(xmlSent, pacs004XSDResources[0]);
    }

    void refreshAllEntities() {
        receiptRepository.findAll().forEach(entityManager::refresh);
        messageRepository.findAll().forEach(entityManager::refresh);
        eventRepository.findAll().forEach(entityManager::refresh);
    }

    private String receiveAReceipt() {
        String endToEndId = CorrelationIdGenerator.generateCorrelactionIdPacs008(String.valueOf(PARTICIPANT_ISPB));
        mockMessageSender();
        InstantPaymentsUIDTO instantPaymentsUIDTO =
            createInstantPaymentsUIDTOMock(Collections.singletonList(endToEndId),
                InstantPaymentCreationUtils.OperationType.RECEIPT);

        messageReceiver.readIncomingMessage(buildReceivedPacs008(getRandomPiResourceId(), instantPaymentsUIDTO, "1.4"));

        refreshAllEntities();

        String receivedPacs002PiResourceId = getRandomPiResourceId();
        String receivedPacs002Message =
            buildPacs002Response(receivedPacs002PiResourceId, buildTxInfAndSts(endToEndId, "ACCC"), "1.3");
        messageReceiver.readIncomingMessage(receivedPacs002Message);

        EventEntity eventEntity = eventRepository.findAll().get(0);

        accountTransactionReceiver.onMessage(new GenericMessage<>("{\"eventId\": \"" + eventEntity.getId() + "\"}"));

        return endToEndId;
    }

    protected void mockMessageSender() {
        when(mockedMessagesApi.sendsMessageV1(any(MessageSpecificationDTO.class)))
            .thenAnswer((invocation) -> createMessageSentResponseDTO());
    }

    private String getXmlMessage() {

        verify(mockedMessagesApi, atLeastOnce()).sendsMessageV1(messageSpecificationDTOArgumentCaptor.capture());
        MessageSpecificationDTO messageSpecificationDTO = messageSpecificationDTOArgumentCaptor.getValue();

        return messageSpecificationDTO.getMessageContent();
    }

}
