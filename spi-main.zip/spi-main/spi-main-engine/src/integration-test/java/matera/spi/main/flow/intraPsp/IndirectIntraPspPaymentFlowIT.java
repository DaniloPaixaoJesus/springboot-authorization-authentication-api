package matera.spi.main.flow.intraPsp;

import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventType;
import matera.spi.main.utils.WireMockUtils;

import com.github.tomakehurst.wiremock.client.CountMatchingStrategy;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;

import java.util.List;

import static matera.spi.main.utils.WireMockUtils.V1_CREDITS;
import static matera.spi.main.utils.WireMockUtils.never;
import static matera.spi.main.utils.verifier.EventVerifier.ERROR;
import static matera.spi.main.utils.verifier.EventVerifier.PAYMENT_INITIALIZED;
import static matera.spi.main.utils.verifier.EventVerifier.PAYMENT_REJECTED;
import static matera.spi.main.utils.verifier.EventVerifier.RECEIPT_RECEIVED;
import static matera.spi.main.utils.verifier.EventVerifier.WAITING_CREDIT_VALIDATION;
import static matera.spi.main.utils.verifier.EventVerifier.verifyAllStatusTransactions;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.resetAllRequests;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static org.assertj.core.api.Assertions.assertThat;

@ActiveProfiles("indirects")
class IndirectIntraPspPaymentFlowIT extends IntraPspPaymentFlowIT {

    @BeforeEach
    void setUpIndirect() {
        WireMockUtils.stubV1CreditsEntryValidation();
        WireMockUtils.stubV1IpAccount();

        WireMockUtils.stubV1IndirectsForIntraMip();
    }

    @Override
    protected CountMatchingStrategy customerTransactionCalls() {
        return never();
    }

    @Override
    @Test
    void intraPspPaymentShouldHandleCreditValidationReturnInternalServerError() {
        //Given
        stubInternalServerErrorCreditValidation();

        sendPaymentByAPI(port);
        String pacs008 = getPacs008FromPayment();

        resetAllRequests();
        receiveAMessage(pacs008);

        //When
        String pacs002 = getPacs002FromReceipt();
        resetAllRequests();
        receiveAMessage(pacs002);

        //Then
        transactionTemplate.execute(status -> {
            List<EventEntity> events = eventRepository.findAll(Sort.by(Sort.Direction.ASC, "initiationTimestampUTC"));
            assertThat(events).hasSize(2);

            EventEntity paymentEventEntity = events.get(0);
            EventEntity receiptEventEntity = events.get(1);

            assertThat(paymentEventEntity.getEventType()).isEqualTo(EventType.PAYMENT);
            assertThat(receiptEventEntity.getEventType()).isEqualTo(EventType.RECEIPT);
            assertThat(paymentEventEntity.getCorrelationId()).isEqualTo(receiptEventEntity.getCorrelationId());

            verifyAllStatusTransactions(paymentEventEntity,
                List.of(PAYMENT_INITIALIZED, WAITING_CREDIT_VALIDATION, PAYMENT_REJECTED));

            verifyAllStatusTransactions(receiptEventEntity,
                List.of(RECEIPT_RECEIVED, ERROR));

            return null;
        });

    }

    @Override
    protected void stubBadRequestCreditValidation() {
        stubFor(post(V1_CREDITS)
            .willReturn(aResponse()
                .withStatus(HttpStatus.BAD_REQUEST.value())
                .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .withBody("{\"rejectionReason\": {\"rejectionReasonCode\": \"AC07\" } }")
            )
        );
    }

    @Override
    protected void stubInternalServerErrorCreditValidation() {
        stubFor(post(V1_CREDITS)
            .willReturn(aResponse()
                .withStatus(HttpStatus.INTERNAL_SERVER_ERROR.value())
            )
        );
    }

}
