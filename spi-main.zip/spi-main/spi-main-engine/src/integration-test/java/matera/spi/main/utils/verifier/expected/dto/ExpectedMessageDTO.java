package matera.spi.main.utils.verifier.expected.dto;

import lombok.Builder;
import lombok.Data;
import lombok.NonNull;

import java.time.LocalDateTime;

@Data
@Builder
public class ExpectedMessageDTO {
	@NonNull String typeCode;
	@NonNull String version;
	@NonNull String piResourceId;
	int senderISPB;
	int receiverISPB;
	LocalDateTime clearingTimestamp;
	boolean clearingTimestampCloseToUTC;
}