package matera.spi.lm.domain.service.event;

import matera.spi.lm.domain.model.TransactionQueryEntity;
import matera.spi.lm.domain.model.event.TransactionQueryEventEntity;
import matera.spi.lm.dto.event.TransactionQueryEventSpecificationDTO;
import matera.spi.main.domain.service.event.Event;
import matera.spi.main.dto.event.EventSpecificationFromReceivedMessageDTO;
import matera.spi.main.persistence.MessageRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.support.TransactionTemplate;
import org.w3c.dom.Document;

import java.math.BigDecimal;

import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static matera.spi.utils.DocumentUtils.stringToXmlDocument;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;

@ActiveProfiles("indirects")
public class IndirectTransactionQueryEventIntegrationTest extends AbstractTransactionQueryEventIntegrationTest {

    private static final String CAMT_054_CONSULTA_LANCAMENTO_PATH_DEPTOR_DIFFERENT = "camt.054/camt.054_consulta_lancamento_debitor_diferente_do_partipante.xml";
    private static final Document CAMT_054_DOCUMENT_DEBTOR_DIFFERENT = stringToXmlDocument(getStringFromXmlFile(CAMT_054_CONSULTA_LANCAMENTO_PATH_DEPTOR_DIFFERENT));

    @Test
    void shouldReplyMsgWithDebtorEqualsParticipant() {
        doReturn(buildMessageSentResponseDTO()).when(messagesApi).sendsMessageV1(any());
        final TransactionQueryEventSpecificationDTO specificationDTO = buildEventSpecificationDTO();

        Event event = eventFactory.createNewEvent(specificationDTO);
        assertThat(event).isNotNull();

        IndirectTransactionQueryEvent actual = (IndirectTransactionQueryEvent) event;
        TransactionQueryEventEntity eventEntity = assertEventEntity(actual);

        TransactionQueryEntity transactionQueryEntity = eventEntity.getTransactionQueryEntity();
        assertThat(transactionQueryEntity).isNotNull();
        assertThat(transactionQueryEntity.getEndToEndID()).isEqualTo(END_TO_END_ID);

        final EventSpecificationFromReceivedMessageDTO eventSpecificationDTO = buildMessageReceivedDTO(CAMT_054_DOCUMENT);
        actual.actionsForReplyMessage(eventSpecificationDTO);

        assertDetailsAfterReply(transactionQueryEntity);
        assertThat(eventSpecificationDTO.getMessageEntity().getHasPermission()).isTrue();
    }

    @Test
    void shouldReplyMsgWithDeptorOrCreditorNotEqualsParticipant() {
        doReturn(buildMessageSentResponseDTO()).when(messagesApi).sendsMessageV1(any());
        final TransactionQueryEventSpecificationDTO specificationDTO = buildEventSpecificationDTO();

        Event event = eventFactory.createNewEvent(specificationDTO);
        assertThat(event).isNotNull();

        IndirectTransactionQueryEvent actual = (IndirectTransactionQueryEvent) event;
        TransactionQueryEventEntity eventEntity = assertEventEntity(actual);

        TransactionQueryEntity transactionQueryEntity = eventEntity.getTransactionQueryEntity();
        assertThat(transactionQueryEntity).isNotNull();
        assertThat(transactionQueryEntity.getEndToEndID()).isEqualTo(END_TO_END_ID);

        final EventSpecificationFromReceivedMessageDTO eventSpecificationDTO = buildMessageReceivedDTO(CAMT_054_DOCUMENT_DEBTOR_DIFFERENT);
        actual.actionsForReplyMessage(eventSpecificationDTO);

        assertThat(transactionQueryEntity.getEffectiveTimestamp()).isNull();
        assertThat(transactionQueryEntity.getValue()).isNull();
        assertThat(transactionQueryEntity.getType()).isNull();
        assertThat(transactionQueryEntity.getIspbDebtor()).isNull();
        assertThat(transactionQueryEntity.getIspbCreditor()).isNull();

        assertThat(eventSpecificationDTO.getMessageEntity().getHasPermission()).isFalse();
    }

    private TransactionQueryEventEntity assertEventEntity(IndirectTransactionQueryEvent actual) {
        TransactionQueryEventEntity eventEntity = actual.getEventEntity();
        assertThat(eventEntity).isNotNull();
        assertThat(eventEntity.getInitiationTimestampUTC()).isNotNull();
        assertThat(eventEntity.getResponsible()).isEqualTo(RESPONSIBLE);
        assertThat(eventEntity.getInitiatorIspb()).isEqualTo(INITIATOR_ISPB);
        assertThat(eventEntity.getStatus().getCode()).isEqualTo(EVENT_STATUS_CODE);
        assertThat(eventEntity.getEventTypeEntity().getCode()).isEqualTo(EVENT_TYPE_ENTITY_CODE);
        assertThat(eventEntity.getCorrelationId()).isNotNull();
        assertThat(eventEntity.getOriginSystem()).isEqualTo("System");
        assertThat(eventEntity.getOrigSystemTransactionId()).isEqualTo("SystemTransaction");
        assertThat(eventEntity.getValue()).isEqualTo(new BigDecimal("1000"));
        return eventEntity;
    }
}
