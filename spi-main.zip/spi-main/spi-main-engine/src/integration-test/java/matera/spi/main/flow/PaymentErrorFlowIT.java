package matera.spi.main.flow;

import com.matera.client.exception.BadRequestException;
import com.matera.client.exception.InternalServerErrorException;
import com.matera.commons.rest.dto.MateraRestReturnDTO;
import com.matera.spi.messaging.api.MessagesApi;
import com.matera.spi.messaging.api.SPIMessagingApis;
import com.matera.spi.messaging.model.MessageSpecificationDTO;
import com.matera.spi.thirdparties.customers.transactions.model.LancamentoResponseV2DTO;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.InstantPaymentsUIDTO;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventStatusTransitionEntity;
import matera.spi.main.domain.model.event.transaction.TransactionEventEntity;
import matera.spi.main.domain.model.transaction.TransactionEntity;
import matera.spi.main.domain.service.CorrelationIdGenerator;
import matera.spi.main.domain.service.MessageSender;
import matera.spi.main.domain.service.transaction.AccountTransaction;
import matera.spi.main.domain.service.transaction.AccountTransactionReverter;
import matera.spi.main.dto.AccountTransactionRequestDTO;
import matera.spi.main.dto.AccountTransactionResponseDTO;
import matera.spi.main.dto.event.transaction.AccountTransactionReverterDTO;
import matera.spi.main.dto.event.transaction.TransactionReverterDTO;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.MessageRepository;
import matera.spi.main.transactions.port.AccountTransactionExecutorPort;
import matera.spi.main.transactions.port.AccountTransactionReverterPort;
import matera.spi.main.utils.InstantPaymentCreationUtils.OperationType;

import io.restassured.RestAssured;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.RandomStringUtils;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.test.annotation.Commit;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.createInstantPaymentsUIDTOMock;
import static matera.spi.main.utils.InstantPaymentCreationUtils.createMessageSentResponseDTO;

import static com.matera.spi.thirdparties.customers.transactions.model.LancamentoResponseV2DTO.ClassificacaoCategoriaContaSPIEnum.CACC;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

@Slf4j
@IntegrationTest
@Transactional
@Commit
@Disabled
class PaymentErrorFlowIT {

    private static final String EXPECTED_ERROR_STATUS = "Error";
    private static final String CLEARING_ACCOUNT_DEBIT_ERROR = "Clearing Account Debit Error";
    private static final BigDecimal TRANSACTION_ID_MOCK = BigDecimal.valueOf(new Random().nextLong());
    private static final String BASE_URI_INSTANT_PAYMENTS = "/ui/v1/instant-payments";
    private static final String CUSTOMER_DEBIT_INTERNAL_ERROR = "Customer Debit Internal Error";
    private static final String PAYMENT_REJECTED = "Payment rejected";
    private static final String PAYMENT_INITIALIZED = "Payment initialized";
    private static final String CUSTOMER_DEBIT_ERROR = "Customer Debit Error";

    @Autowired
    private MessageSender messageSender;
    @Autowired
    private SPIMessagingApis spiMessagingApisBean;
    @Mock
    private SPIMessagingApis mockedSpiMessagingApis;
    @Mock
    private MessagesApi mockedMessagesApi;

    @Autowired
    private AccountTransaction accountTransaction;
    @Autowired
    private AccountTransactionExecutorPort accountTransactionExecutorPort;
    @Mock
    private AccountTransactionExecutorPort mockedAccountTransactionExecutorPort;

    @Autowired
    private AccountTransactionReverter accountTransactionReverter;
    @Autowired
    private AccountTransactionReverterPort accountTransactionReverterPort;
    @Mock
    private AccountTransactionReverterPort mockedAccountTransactionReverterPort;

    @Autowired
    private EventRepository eventRepository;
    @Autowired
    private MessageRepository messageRepository;
    @LocalServerPort
    private int port;

    @BeforeEach
    void setUp() {
        RestAssured.port = port;

        when(mockedSpiMessagingApis.messagesApi()).thenReturn(mockedMessagesApi);
        messageSender.setSpiMessagingApis(mockedSpiMessagingApis);
        accountTransaction.setAccountTransactionExecutorPort(mockedAccountTransactionExecutorPort);
        accountTransactionReverter.setAccountTransactionReverterAdapter(mockedAccountTransactionReverterPort);
    }

    @AfterEach
    void tearDown() {
        messageSender.setSpiMessagingApis(spiMessagingApisBean);
        accountTransaction.setAccountTransactionExecutorPort(accountTransactionExecutorPort);
        accountTransactionReverter.setAccountTransactionReverterAdapter(accountTransactionReverterPort);
    }

    @Test
    @DisplayName("when sending payment and the customer account debit throws internal server error exception should the event end with error status")
    void shouldGenerateAnEventWithErrorStatusWhenCustomerDebitThrowsInternalServerErrorException() {
        //given
        when(mockedAccountTransactionExecutorPort.makeTransaction(any(AccountTransactionRequestDTO.class)))
            .thenThrow(InternalServerErrorException.class);

        //when
        assertThatThrownBy(this::sendPayment).isInstanceOf(HttpServerErrorException.InternalServerError.class);

        //then
        EventEntity event = verifyEventWithStatus(EXPECTED_ERROR_STATUS, CUSTOMER_DEBIT_INTERNAL_ERROR, null);
        TransactionEntity transactionEntity = ((TransactionEventEntity) event).getTransactionEntity();
        assertThat(transactionEntity.getCustomerTransactionResult().isInternalServerError()).isTrue();
        assertThat(transactionEntity.getCustomerTransactionResult().getErrorReturned()).isNotNull();
        assertThat(event.getTransactionResult()).isNull();
        assertThat(event.getIpAccountTransactionResult()).isNull();

        verify(mockedAccountTransactionExecutorPort, times(1)).makeTransaction(any());
        verifyNoMoreInteractions(mockedAccountTransactionReverterPort);

        assertThat(messageRepository.findAll()).as("Messages should not be created").isEmpty();
    }

    @Test
    @DisplayName("when sending payment and the customer account debit throws bad request exception should the event end with error status")
    void shouldGenerateAnEventWithErrorStatusWhenCustomerDebitThrowsBadRequestException() {
        //given
        when(mockedAccountTransactionExecutorPort.makeTransaction(any(AccountTransactionRequestDTO.class)))
            .thenThrow(BadRequestException.class);

        //when
        assertThatThrownBy(this::sendPayment).isInstanceOf(HttpClientErrorException.BadRequest.class);

        //then
        EventEntity event = verifyEventWithStatus(PAYMENT_REJECTED, null, CUSTOMER_DEBIT_ERROR);
        TransactionEntity transactionEntity = ((TransactionEventEntity) event).getTransactionEntity();
        assertThat(transactionEntity.getCustomerTransactionResult().isInternalServerError()).isFalse();
        assertThat(transactionEntity.getCustomerTransactionResult().getErrorReturned()).isNotNull();
        assertThat(event.getTransactionResult()).isNull();
        assertThat(event.getIpAccountTransactionResult()).isNull();

        verify(mockedAccountTransactionExecutorPort, times(1)).makeTransaction(any());
        verifyNoInteractions(mockedAccountTransactionReverterPort);

        assertThat(messageRepository.findAll()).as("Messages should not be created").isEmpty();
    }

    @Test
    @DisplayName("when sending payment and the managerial ip account debit throws exception should the event end with error status")
    void shouldGenerateAnEventWithErrorStatusWhenManagerialDebitThrowsException() {
        //given
        when(mockedAccountTransactionExecutorPort.makeTransaction(any(AccountTransactionRequestDTO.class)))
            .thenReturn(buildTransactionResponseMock())
            .thenThrow(InternalServerErrorException.class);

        //when
        assertThatThrownBy(this::sendPayment).isInstanceOf(HttpServerErrorException.InternalServerError.class);

        //then
        EventEntity event = verifyEventWithStatus(EXPECTED_ERROR_STATUS, CLEARING_ACCOUNT_DEBIT_ERROR, null);

        TransactionEntity transactionEntity = ((TransactionEventEntity) event).getTransactionEntity();
        assertThat(transactionEntity.getCustomerTransactionResult().getReverted()).isTrue();
        assertThat(event.getTransactionResult()).isNull();
        assertThat(event.getIpAccountTransactionResult()).isNull();

        verify(mockedAccountTransactionExecutorPort, times(2)).makeTransaction(any());
        verify(mockedAccountTransactionReverterPort).revertDebit(ExpectTransactionRevertDTO(1));

        assertThat(messageRepository.findAll()).as("Messages should not be created").isEmpty();
    }

    @Test
    @DisplayName("when sending payment and the mirror ip account debit throws exception should the event end with error status")
    void shouldGenerateAnEventWithErrorStatusWhenMirrorIPAccountDebitThrowsException() {
        //given
        when(mockedAccountTransactionExecutorPort.makeTransaction(any(AccountTransactionRequestDTO.class)))
            .thenReturn(buildTransactionResponseMock())
            .thenReturn(buildTransactionResponseMock())
            .thenThrow(InternalServerErrorException.class);
        //when
        assertThatThrownBy(this::sendPayment).isInstanceOf(HttpServerErrorException.InternalServerError.class);

        //then
        EventEntity event = verifyEventWithStatus(EXPECTED_ERROR_STATUS, CLEARING_ACCOUNT_DEBIT_ERROR, null);

        TransactionEntity transactionEntity = ((TransactionEventEntity) event).getTransactionEntity();
        assertThat(transactionEntity.getCustomerTransactionResult().getReverted()).isTrue();
        assertThat(event.getTransactionResult().getReverted()).isTrue();
        assertThat(event.getIpAccountTransactionResult()).isNull();

        verify(mockedAccountTransactionExecutorPort, times(3)).makeTransaction(any());
        verify(mockedAccountTransactionReverterPort).revertDebit(ExpectTransactionRevertDTO(2));

        assertThat(messageRepository.findAll()).as("Messages should not be created").isEmpty();
    }

    @NotNull
    private EventEntity verifyEventWithStatus(String status, String errorReason, String rejectionReason) {
        //then
        List<EventEntity> allEvents = eventRepository.findAllWithTransactionEntity();
        assertThat(allEvents).hasSize(1);

        EventEntity event = allEvents.get(0);
        assertThat(event.getStatus().getDescription()).isEqualTo(status);

        if (errorReason != null) {
            assertThat(event.getErrorReason().getDescription()).isEqualTo(errorReason);
        } else {
            assertThat(event.getErrorReason()).isNull();
        }

        if (rejectionReason != null) {
            assertThat(event.getRejectionReasonCode().getDescription()).isEqualTo(rejectionReason);
        } else {
            assertThat(event.getRejectionReasonCode()).isNull();
        }


        // Verifying status transition
        List<EventStatusTransitionEntity> statusTransitions = getOrderedEventStatusTransitions(event);
        assertThat(statusTransitions).hasSize(2);
        assertThat(statusTransitions.get(0).getEventStatusCode().getDescription()).isEqualTo(PAYMENT_INITIALIZED);
        assertThat(statusTransitions.get(1).getEventStatusCode().getDescription()).isEqualTo(status);
        return event;
    }

    private AccountTransactionReverterDTO ExpectTransactionRevertDTO(int reversions) {
        return AccountTransactionReverterDTO.builder()
            .reversals(
                IntStream.range(0, reversions)
                    .mapToObj(
                        i -> TransactionReverterDTO.builder().entryId(TRANSACTION_ID_MOCK).build()
                    ).collect(Collectors.toList())
            ).build();
    }

    private AccountTransactionResponseDTO buildTransactionResponseMock() {

        LancamentoResponseV2DTO lancamentoResponseV2DTO = new LancamentoResponseV2DTO();

        lancamentoResponseV2DTO.setClassificacaoCategoriaContaSPI(CACC);
        lancamentoResponseV2DTO.setCpfCnpjTitular(BigDecimal.valueOf(92082843521L));

        return AccountTransactionResponseDTO.builder()
            .transactionId(TRANSACTION_ID_MOCK)
            .lancamentoResponseV2DTO(lancamentoResponseV2DTO)
            .build();
    }

    private void sendPayment() {
        String endToEndId = CorrelationIdGenerator.generateCorrelactionIdPacs008(String.valueOf(PARTICIPANT_ISPB));
        mockMessageSender();
        InstantPaymentsUIDTO instantPaymentsUIDTO = createInstantPaymentsUIDTOMock(endToEndId, OperationType.PAYMENT);
        invokeEndpoint(instantPaymentsUIDTO);
    }

    protected void mockMessageSender() {
        String expectedPiResourceId = RandomStringUtils.randomAlphabetic(12);
        when(mockedMessagesApi.sendsMessageV1(any(MessageSpecificationDTO.class)))
            .thenReturn(createMessageSentResponseDTO(expectedPiResourceId));
    }

    @NotNull
    private static List<EventStatusTransitionEntity> getOrderedEventStatusTransitions(EventEntity actual) {
        return actual.getEventStatusTransitionEntities().stream()
            .sorted(Comparator.comparing(EventStatusTransitionEntity::getTimestamp))
            .collect(Collectors.toList());
    }

    private void invokeEndpoint(InstantPaymentsUIDTO instantPaymentsUIDTO) {
        RestTemplate restTemplate = new RestTemplate();
        HttpEntity<InstantPaymentsUIDTO> request = new HttpEntity<>(instantPaymentsUIDTO);
        String url = "http://localhost:" + port + BASE_URI_INSTANT_PAYMENTS;
        restTemplate.postForObject(url, request, MateraRestReturnDTO.class);
    }
}
