package matera.spi.lm.domain.service.event;

import com.matera.spi.messaging.api.MessagesApi;
import com.matera.spi.messaging.api.SPIMessagingApis;
import com.matera.spi.messaging.model.MessageSentResponseDTO;
import matera.spi.commons.IntegrationTest;
import matera.spi.lm.domain.model.TransactionQueryEntity;
import matera.spi.lm.domain.model.event.TransactionQueryEventEntity;
import matera.spi.lm.dto.event.TransactionQueryEventSpecificationDTO;
import matera.spi.main.domain.model.event.EventTypeEntity;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.domain.model.message.MessageTypeEntity;
import matera.spi.main.domain.service.MessageSender;
import matera.spi.main.domain.service.ParticipantService;
import matera.spi.main.domain.service.event.Event;
import matera.spi.main.domain.service.event.EventFactory;
import matera.spi.main.dto.event.EventSpecificationFromReceivedMessageDTO;
import matera.spi.main.persistence.MessageRepository;
import matera.spi.main.persistence.MessageTypeRepository;
import matera.spi.utils.DocumentUtils;
import matera.spi.utils.LocalDateTimeUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneOffset;

import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static matera.spi.utils.DocumentUtils.stringToXmlDocument;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@IntegrationTest
abstract class AbstractTransactionQueryEventIntegrationTest {

    protected static final String PI_RESOURCE_ID = "PI-RESOURCE-ID-TEST-STATEMENT";

    protected static final LocalDateTime EFFECTIVE_TIMESTAMP = LocalDateTimeUtils.parseLocalDateTimeUTC("2020-01-01T08:30:12.000Z");
    protected static final LocalDateTime ENDTIMESTAMP = LocalDateTimeUtils.getUtcLocalDateTime().plusHours(5);
    protected static final String RESPONSIBLE = "ResponsibleTest";
    protected static final Integer INITIATOR_ISPB = 12345678;
    protected static final int EVENT_STATUS_CODE = 14;
    protected static final int EVENT_TYPE_ENTITY_CODE = 6;
    protected static final String END_TO_END_ID = "EndToEndId";
    protected static final String CAMT_054_CONSULTA_LANCAMENTO_PATH = "camt.054/camt.054_consulta_lancamento.xml";
    protected static final Document CAMT_054_DOCUMENT = stringToXmlDocument(getStringFromXmlFile(CAMT_054_CONSULTA_LANCAMENTO_PATH));

    protected static Event event;

    @Autowired
    protected EventFactory eventFactory;

    @Autowired
    protected MessageSender messageSender;
    @Autowired
    protected SPIMessagingApis spiMessagingApisBean;

    @Autowired
    private MessageTypeRepository messageTypeRepository;

    @Mock
    protected SPIMessagingApis mockedSpiMessagingApis;
    @Mock
    protected MessagesApi messagesApi;

    @Autowired
    private ParticipantService participantService;

    @Autowired
    private MessageRepository messageRepository;

    @BeforeEach
    void setup() {
        when(mockedSpiMessagingApis.messagesApi()).thenReturn(messagesApi);
        messageSender.setSpiMessagingApis(mockedSpiMessagingApis);
    }

    @AfterEach
    void tearDown() {
        messageSender.setSpiMessagingApis(spiMessagingApisBean);
        messageRepository.deleteAll();
    }

    protected TransactionQueryEventSpecificationDTO buildEventSpecificationDTO() {
        final TransactionQueryEventSpecificationDTO eventSpecificationDTO = new TransactionQueryEventSpecificationDTO();
        eventSpecificationDTO.setResponsible(RESPONSIBLE);
        eventSpecificationDTO.setInitiatorIspb(INITIATOR_ISPB);
        eventSpecificationDTO.setEndToEndId(END_TO_END_ID);
        eventSpecificationDTO.setCorrelationId("CorrelationId");

        eventSpecificationDTO.setOriginalSystemTransactionIdentifier("SystemTransaction");
        eventSpecificationDTO.setOriginSystem("System");
        eventSpecificationDTO.setValue(BigDecimal.valueOf(1000));
        return eventSpecificationDTO;
    }

    protected MessageSentResponseDTO buildMessageSentResponseDTO() {
        final MessageSentResponseDTO messageSentResponseDTO = new MessageSentResponseDTO();
        messageSentResponseDTO.setPiResourceID(PI_RESOURCE_ID);
        return messageSentResponseDTO;
    }

    protected EventSpecificationFromReceivedMessageDTO buildMessageReceivedDTO(Document document) {
        final NodeList nodeList = DocumentUtils
            .getElementsByExpression(document, "Envelope/Document/BkToCstmrDbtCdtNtfctn");
        final Node currentNode = nodeList.item(0);

        MessageTypeEntity messageTypeEntity = messageTypeRepository.findById("camt.054").orElseThrow();
        EventTypeEntity eventTypeEntity = new EventTypeEntity();
        eventTypeEntity.setCode(6);
        messageTypeEntity.setNewEventType(eventTypeEntity);

        MessageEntity messageEntity = new MessageEntity();
        messageEntity.setMessageTypeEntity(messageTypeEntity);
        messageEntity.setHasPermission(true);
        messageEntity.setPiResourceId("PiResourceId");
        messageEntity.setClearingTimestampUtc(LocalDateTime.now(ZoneOffset.UTC));
        messageEntity.setTimestampUtc(LocalDateTime.now(ZoneOffset.UTC));
        messageEntity.setVersion("1");
        messageEntity.setSenderParticipant(participantService.findByIspb(38166).orElseThrow());
        messageEntity.setReceiverParticipant(participantService.findByIspb(13370835).orElseThrow());

        return EventSpecificationFromReceivedMessageDTO
            .builder()
            .messageEntity(messageEntity)
            .document(document)
            .specificElement(currentNode)
            .build();
    }

    protected TransactionQueryEventEntity assertEventEntity(TransactionQueryEvent actual) {
        TransactionQueryEventEntity eventEntity = actual.getEventEntity();
        assertThat(eventEntity).isNotNull();
        assertThat(eventEntity.getInitiationTimestampUTC()).isNotNull();
        assertThat(eventEntity.getResponsible()).isEqualTo(RESPONSIBLE);
        assertThat(eventEntity.getInitiatorIspb()).isEqualTo(INITIATOR_ISPB);
        assertThat(eventEntity.getStatus().getCode()).isEqualTo(EVENT_STATUS_CODE);
        assertThat(eventEntity.getEventTypeEntity().getCode()).isEqualTo(EVENT_TYPE_ENTITY_CODE);
        assertThat(eventEntity.getCorrelationId()).isNotNull();
        assertThat(eventEntity.getOriginSystem()).isEqualTo("System");
        assertThat(eventEntity.getOrigSystemTransactionId()).isEqualTo("SystemTransaction");
        assertThat(eventEntity.getValue()).isEqualTo(new BigDecimal("1000"));
        return eventEntity;
    }

    protected void assertDetailsAfterReply(TransactionQueryEntity transactionQueryEntity) {
        assertThat(transactionQueryEntity.getEffectiveTimestamp()).isEqualTo(EFFECTIVE_TIMESTAMP);
        assertThat(transactionQueryEntity.getValue()).isEqualTo(new BigDecimal("1000.00"));
        assertThat(transactionQueryEntity.getType()).isEqualTo("D");
        assertThat(transactionQueryEntity.getIspbDebtor()).isEqualTo("13370835");
        assertThat(transactionQueryEntity.getIspbCreditor()).isEqualTo("00255564");
    }
}
