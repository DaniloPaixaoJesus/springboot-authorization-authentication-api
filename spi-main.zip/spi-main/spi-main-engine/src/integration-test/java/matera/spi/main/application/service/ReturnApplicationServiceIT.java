package matera.spi.main.application.service;

import com.matera.commons.rest.dto.MateraRestReturnDTO;
import com.matera.spi.messaging.model.MessageSpecificationDTO;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.InstantPaymentsUIDTO;
import matera.spi.dto.InstructionPriorityDTO;
import matera.spi.dto.ReturnResponseDTO;
import matera.spi.dto.ReturnSettlementWrapperDTO;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventType;
import matera.spi.main.domain.model.event.transaction.TransactionEventEntity;
import matera.spi.main.domain.service.event.receiver.AccountTransactionReceiver;
import matera.spi.main.domain.service.event.receiver.MessageReceiver;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.utils.WireMockUtils;

import com.github.tomakehurst.wiremock.WireMockServer;
import io.restassured.RestAssured;
import io.restassured.common.mapper.TypeRef;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.data.domain.Sort;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.transaction.support.TransactionTemplate;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Stream;

import static matera.spi.main.domain.service.CorrelationIdGenerator.generateCorrelactionIdPacs008;
import static matera.spi.main.utils.InstantPaymentCreationUtils.ADDITIONAL_INFORMATION;
import static matera.spi.main.utils.InstantPaymentCreationUtils.OperationType.RECEIPT;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.createInstantPaymentsUIDTOMock;
import static matera.spi.main.utils.InstantPaymentCreationUtils.getRandomPiResourceId;
import static matera.spi.main.utils.MessageCreationUtils.RECEIPT_SUCCESS_STATUS;
import static matera.spi.main.utils.MessageCreationUtils.buildPacs002Response;
import static matera.spi.main.utils.MessageCreationUtils.buildReceivedPacs008;
import static matera.spi.main.utils.MessageCreationUtils.buildTxInfAndSts;
import static matera.spi.main.utils.WireMockUtils.V_1_MESSAGES;

import static com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.resetAllRequests;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static org.assertj.core.api.Assertions.assertThat;

@IntegrationTest
class ReturnApplicationServiceIT {

    private static final String AUTHORIZATION_HEADER_NAME = "Authorization";
    private static final String BEARER_RANDOM_HEADER_VALUE = "Bearer random";
    private static final String IDEMPOTENCY_ID_HEADER_NAME = "IdempotencyId";

    @LocalServerPort
    private int port;

    @Autowired
    private TransactionTemplate transactionTemplate;

    @Autowired
    private MessageReceiver messageReceiver;

    @Autowired
    private EventRepository eventRepository;

    @Autowired
    private AccountTransactionReceiver accountTransactionReceiver;

    private static final WireMockServer wireMockServer = WireMockUtils.start();

    @BeforeAll
    static void beforeAll() {
        WireMockUtils.stubMessaging();
    }

    @AfterAll
    static void afterAll() {
        wireMockServer.stop();
    }

    private static Stream<Arguments> instructionPriorityArgSource() {
        return Stream.of(
            Arguments.of(null, "HIGH"),
            Arguments.of(InstructionPriorityDTO.HIGH, "HIGH"),
            Arguments.of(InstructionPriorityDTO.NORM, "NORM")
        );
    }

    @BeforeEach
    void setUp() {
        RestAssured.port = port;
        resetAllRequests();
    }

    @ParameterizedTest
    @MethodSource("instructionPriorityArgSource")
    void instantPaymentApiShouldSetInstructionPriority(InstructionPriorityDTO endpointInstructionPriority, String expectedInstruction) {
        receiveAReceipt();

        ReturnSettlementWrapperDTO returnSettlementWrapperDTO =
            createReturnSettlementWrapperDTO(endpointInstructionPriority, BigDecimal.TEN);

        String receiptId = getReceiptEvent().getId().toString();
        String idempotency = "RANDOMIDEMPOTENCYID"+ LocalDateTime.now();
        RestAssured
            .given()
            .contentType(ContentType.JSON)
                .body(returnSettlementWrapperDTO)
                .header(AUTHORIZATION_HEADER_NAME, BEARER_RANDOM_HEADER_VALUE)
                .header(IDEMPOTENCY_ID_HEADER_NAME, idempotency)
            .when()
                .post("/api/v1/settlements/instant-payments/" + receiptId + "/returns")
            .then()
                .statusCode(202);

        transactionTemplate.execute((status) -> {
            List<EventEntity> events = eventRepository.findAll(Sort.by(Sort.Direction.ASC, "initiationTimestampUTC"));

            TransactionEventEntity returnSentEntity = (TransactionEventEntity) events.get(1);
            assertThat(returnSentEntity.getEventType()).isEqualTo(EventType.RETURN_SENDER);

            assertThat(returnSentEntity.getTransactionEntity().getPriority().getCode()).isEqualTo(expectedInstruction);

            MessageSpecificationDTO messagingBody =
                WireMockUtils.getFirstBodyFrom(postRequestedFor(urlEqualTo(V_1_MESSAGES)), MessageSpecificationDTO.class);

            assertThat(messagingBody.getMessageDefinitionIdentifier()).contains("pacs.004");
            assertThat(messagingBody.getMessageContent()).contains("<SttlmPrty>" + expectedInstruction + "</SttlmPrty>");

            return null;
        });
    }

    @Test
    void instantPaymentApiShouldReturnResponseDTO() {
        receiveAReceipt();

        ReturnSettlementWrapperDTO returnSettlementWrapperDTO =
            createReturnSettlementWrapperDTO(InstructionPriorityDTO.NORM, BigDecimal.TEN);

        String receiptId = getReceiptEvent().getId().toString();
        String idempotency = "RANDOMIDEMPOTENCYID"+ LocalDateTime.now();
        MateraRestReturnDTO<ReturnResponseDTO> response = RestAssured.
                given()
                    .contentType(ContentType.JSON)
                .body(returnSettlementWrapperDTO)
                    .header(AUTHORIZATION_HEADER_NAME, BEARER_RANDOM_HEADER_VALUE)
                    .header(IDEMPOTENCY_ID_HEADER_NAME, idempotency)
                .when()
                    .post("/api/v1/settlements/instant-payments/" + receiptId + "/returns")
                .then()
                    .statusCode(202)
                    .extract()
                    .body()
                    .as(new TypeRef<>() {});

        assertThat(response.getData().getEndToEndId()).isNotNull();
        assertThat(response.getData().getReturnId()).isNotNull();
        assertThat(response.getData().getCreationDateTime()).isNotNull();
        assertThat(response.getData().getOriginalInstantPaymentId()).isNotNull();
        assertThat(response.getData().getReturnedAmount()).isNotNull();
    }

    @Test
    void instantPaymentApiShouldReturnBadRequestWithInvalidValueScale() {
        receiveAReceipt();

        ReturnSettlementWrapperDTO returnSettlementWrapperDTO =
            createReturnSettlementWrapperDTO(InstructionPriorityDTO.NORM, new BigDecimal("0.123456789123"));

        String receiptId = getReceiptEvent().getId().toString();
        String idempotency = "RANDOMIDEMPOTENCYID"+ LocalDateTime.now();
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(returnSettlementWrapperDTO)
            .header(AUTHORIZATION_HEADER_NAME, BEARER_RANDOM_HEADER_VALUE)
            .header(IDEMPOTENCY_ID_HEADER_NAME, idempotency)
            .when()
            .post("/api/v1/settlements/instant-payments/" + receiptId + "/returns")
            .then()
            .statusCode(400);
    }

    @Test
    void instantPaymentApiShouldReturnBadRequestWithTooBigIdempotencyId() {
        receiveAReceipt();

        ReturnSettlementWrapperDTO returnSettlementWrapperDTO =
            createReturnSettlementWrapperDTO(InstructionPriorityDTO.NORM, new BigDecimal("0.123456789123"));

        String receiptId = getReceiptEvent().getId().toString();
        String idempotency = "RANDOMIDEMPOTENCYID_RANDOMIDEMPOTENCYID_RANDOMIDEMPOTENCYID_RANDOMIDEMPOTENCYID_RANDOMIDEMPOTENCYID_RANDOMIDEMPOTENCYID_RANDOMIDEMPOTENCYID_RANDOMIDEMPOTENCYID_RANDOMIDEMPOTENCYID_RANDOMIDEMPOTENCYID_RANDOMIDEMPOTENCYID_RANDOMIDEMPOTENCYID_RANDOMIDEMPOTENCYID_RANDOMIDEMPOTENCYID_RANDOMIDEMPOTENCYID_R";
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(returnSettlementWrapperDTO)
            .header(AUTHORIZATION_HEADER_NAME, BEARER_RANDOM_HEADER_VALUE)
            .header(IDEMPOTENCY_ID_HEADER_NAME, idempotency)
            .when()
            .post("/api/v1/settlements/instant-payments/" + receiptId + "/returns")
            .then()
            .statusCode(400);
    }

    private ReturnSettlementWrapperDTO createReturnSettlementWrapperDTO(InstructionPriorityDTO instructionPriorityDTO, BigDecimal amount) {
        return new ReturnSettlementWrapperDTO().originSystem("matera").returnedAmount(amount)
            .additionalInformation(ADDITIONAL_INFORMATION).returnReasonCode("AM05")
            .returnReasonInformation("Return reason information").instructionPriority(instructionPriorityDTO)
            .demandsImmediateReturn(true);

    }

    private void receiveAReceipt() {
        String endToEndId = generateCorrelactionIdPacs008(String.valueOf(PARTICIPANT_ISPB));
        InstantPaymentsUIDTO instantPaymentsUIDTO = createInstantPaymentsUIDTOMock(endToEndId, RECEIPT);

        receiveAMessage(buildReceivedPacs008(getRandomPiResourceId(), instantPaymentsUIDTO));

        receiveAMessage(buildPacs002Response(buildTxInfAndSts(endToEndId, RECEIPT_SUCCESS_STATUS)));

        processCreditWorkQueue();

        resetAllRequests();
    }

    private void processCreditWorkQueue() {
        EventEntity receiptEventEntity = getReceiptEvent();
        accountTransactionReceiver.onMessage(new GenericMessage<>("{\"eventId\": \"" + receiptEventEntity.getId() + "\"}"));
    }

    private EventEntity getReceiptEvent() {
        List<EventEntity> events = eventRepository.findAll();

        assertThat(events).as("Should only exist the receipt event here").hasSize(1);

        return events.get(0);
    }

    private void receiveAMessage(String message) {
        messageReceiver.readIncomingMessage(message);
    }

}
