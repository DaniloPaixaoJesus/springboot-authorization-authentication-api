package matera.spi.main.domain.service.idempotency;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.idempotence.IdempotencyControlEntity;
import matera.spi.main.persistence.IdempotencyControlRepository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;
import java.time.ZoneId;

import static org.assertj.core.api.Assertions.assertThat;

@IntegrationTest
class IdempotencyServiceIT {

    @Autowired
    private IdempotencyControlRepository repo;

    @Autowired
    private IdempotencyService idempotencyService;

    @Test
    void shouldDeleteIdempotencyControlEntityOlderThanTheThreshold() {
        final long countBeforeAdd = repo.count();

        IdempotencyControlEntity entity = new IdempotencyControlEntity();
        entity.setIdempotencyId("123");
        entity.setOriginSystem("originSystem");
        entity.setService("service");
        entity.setTimestampUTC(LocalDateTime.now(ZoneId.of("UTC")).minusDays(100));

        repo.saveAndFlush(entity);

        assertThat(countBeforeAdd).isLessThan(repo.count());

        idempotencyService.clearIdempotencyControlTable();

        assertThat(countBeforeAdd).isEqualTo(repo.count());
    }

}
