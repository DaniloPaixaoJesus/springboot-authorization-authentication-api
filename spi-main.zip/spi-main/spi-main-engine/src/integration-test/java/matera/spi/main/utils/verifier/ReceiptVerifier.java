package matera.spi.main.utils.verifier;

import matera.spi.dto.InstantPaymentsUIDTO;
import matera.spi.dto.PaymentsUIDTO;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.transaction.TransactionEventEntity;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.domain.model.transaction.TransactionEntity;
import matera.spi.main.utils.verifier.expected.dto.ExpectedTransactionDTO;

import lombok.Builder;
import lombok.Data;
import lombok.NonNull;

import java.util.function.BiConsumer;

@Data
@Builder
public class ReceiptVerifier {

	@NonNull EventEntity eventEntity;
	@NonNull TransactionEntity transactionEntity;

	@NonNull MessageEntity receivedPacs008;
	@NonNull String expectedReceivedPacs008PiResourceId;
	@NonNull String expectedReceivedPacs008Version;

	@NonNull InstantPaymentsUIDTO instantPaymentsUIDTO;
	@NonNull Integer paymentIndex;
	@NonNull BiConsumer<EventEntity, PaymentsUIDTO> eventVerifier;
	@NonNull MessageEntity sentPacs002;
	@NonNull String expectedSentPacs002PiResourceId;
    @NonNull String expectedSentPacs002Version;

	MessageEntity receivedPacs002;
	String expectedReceivedPacs002PiResourceId;
	String expectedReceivedPacs002Version;

	private void verifyEvent() {
		eventVerifier.accept(eventEntity, instantPaymentsUIDTO.getPayments().get(paymentIndex));
	}

	private void verifyTransaction() {
		TransactionVerifier.verifyTransaction(
            transactionEntity, ExpectedTransactionDTO.receiptFromInstantPaymentsUIDTO(instantPaymentsUIDTO, paymentIndex));
		TransactionVerifier.verifyTransactionAndEventRelation((TransactionEventEntity) eventEntity, transactionEntity);
	}

	private void verifyReceivedPacs008Message() {
		MessageVerifier.verifyReceivedMessageIsPacs008(receivedPacs008, expectedReceivedPacs008PiResourceId, expectedReceivedPacs008Version);
		MessageVerifier.verifyMessageEventRelation(receivedPacs008, eventEntity);
	}

	private void verifySentPacs002Message() {
		MessageVerifier.verifySentMessageIsPacs002(sentPacs002, expectedSentPacs002PiResourceId, expectedSentPacs002Version);
		MessageVerifier.verifyMessageEventRelation(sentPacs002, eventEntity);
	}

	private void verifyReceivedPacs002Message() {
		if (receivedPacs002 != null) {
			MessageVerifier.verifyReceivedMessageIsPacs002(receivedPacs002, expectedReceivedPacs002PiResourceId, expectedReceivedPacs002Version);
			MessageVerifier.verifyMessageEventRelation(receivedPacs002, eventEntity);
		}
	}

	public void verify() {
		verifyEvent();
		verifyTransaction();
		verifyReceivedPacs008Message();
		verifySentPacs002Message();
		verifyReceivedPacs002Message();
	}
}
