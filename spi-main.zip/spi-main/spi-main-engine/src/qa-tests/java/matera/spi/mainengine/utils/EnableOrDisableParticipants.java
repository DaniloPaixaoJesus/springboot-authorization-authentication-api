package matera.spi.mainengine.utils;

import matera.spi.mainengine.commons.Paths;
import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.requests.mainengine.participants.AddOrRemoveParticipant;

import org.apache.http.HttpStatus;

public class EnableOrDisableParticipants extends BaseAction {

    AddOrRemoveParticipant addOrRemoveParticipant = new AddOrRemoveParticipant();

    public void enableParticipants(String payerIspb, String receiverIspb){
        String camt014BodyPayer = addOrRemoveParticipant.validAddOrRemoveParticipant("ENBL", payerIspb);
        stubRequestPostWithBody(Paths.PATH_POST_STUB_INCOMING_MESSAGES, camt014BodyPayer, HttpStatus.SC_OK);
        String camt014BodyReceiver = addOrRemoveParticipant.validAddOrRemoveParticipant("ENBL", receiverIspb);
        stubRequestPostWithBody(Paths.PATH_POST_STUB_INCOMING_MESSAGES, camt014BodyReceiver, HttpStatus.SC_OK);
    }

    public void disablePayerParticipant(String payerIspb){
        String camt014BodyPayer = addOrRemoveParticipant.validAddOrRemoveParticipant("DLTD", payerIspb);
        stubRequestPostWithBody(Paths.PATH_POST_STUB_INCOMING_MESSAGES, camt014BodyPayer, HttpStatus.SC_OK);
    }

    public void disableReceiverParticipant(String receiverIspb){
        String camt014BodyReceiver = addOrRemoveParticipant.validAddOrRemoveParticipant("DLTD", receiverIspb);
        stubRequestPostWithBody(Paths.PATH_POST_STUB_INCOMING_MESSAGES, camt014BodyReceiver, HttpStatus.SC_OK);
    }
}
