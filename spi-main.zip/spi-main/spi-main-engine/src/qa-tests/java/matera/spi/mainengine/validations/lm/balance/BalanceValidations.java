package matera.spi.mainengine.validations.lm.balance;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.utils.Asserts;

import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;

public class BalanceValidations extends BaseAction {

    public void validateBalanceResponse() throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, getStatusCode());
        Asserts.assertThat(getJsonValue("data.ipAccountMirror"), Matchers.notNullValue());
      //  Asserts.assertThat(getJsonValue("data.InstantPayments.eventID"), Matchers.notNullValue());
    }
    public void validateBalanceResponseAfterDeposit() throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, getStatusCode());
        Asserts.assertThat(getJsonValue("data.ipAccountMirror"), Matchers.notNullValue());
    }
    public void validateBalanceResponseAfterWithdraw() throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, getStatusCode());
        Asserts.assertThat(getJsonValue("data.ipAccountMirror"), Matchers.notNullValue());
        //  Asserts.assertThat(getJsonValue("data.InstantPayments.eventID"), Matchers.notNullValue());

    }
    public void validateBalanceResponseAfterPayment() throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, getStatusCode());
        Asserts.assertThat(getJsonValue("data.ipAccountMirror"), Matchers.notNullValue());
        //  Asserts.assertThat(getJsonValue("data.InstantPayments.eventID"), Matchers.notNullValue());
    }
    public void validateBalanceResponseAfterReceiver() throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, getStatusCode());
        Asserts.assertThat(getJsonValue("data.ipAccountMirror"), Matchers.notNullValue());
        //  Asserts.assertThat(getJsonValue("data.InstantPayments.eventID"), Matchers.notNullValue());
    }
}
