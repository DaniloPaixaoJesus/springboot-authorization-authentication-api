package matera.spi.mainengine.core;

import matera.spi.mainengine.commons.Paths;
import matera.spi.mainengine.dao.QueryResult;
import matera.spi.mainengine.model.mainengine.receivers.ui.ReceivePaymentModel;
import matera.spi.mainengine.properties.Settings;
import matera.spi.mainengine.utils.Asserts;
import matera.spi.mainengine.utils.ClearingStubSendTLSMessage;
import matera.spi.mainengine.utils.ConfigReader;
import matera.spi.mainengine.utils.GenerateAccessToken;
import matera.spi.mainengine.utils.FakerUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;

/**
 * Base class of generic requests for use in the test classes of the system's features
 *
 * @author jefferson.bessa
 * @author felipe.silva
 *
 */
@Slf4j
public class BaseAction {

    protected static ThreadLocal<BaseResponse> RESPONSE_THREAD_LOCAL = new ThreadLocal<>();
    protected static Map<String, BaseResponse> RESPONSE_MAP_THREAD_LOCAL = new HashMap<>();
    protected static ThreadLocal<QueryResult> QUERY_RESULT_THREAD_LOCAL = new ThreadLocal<>();
    protected Map<String, Object> paramsMap = new HashMap<String, Object>();
    protected Map<String, Object> bodyJsonMap = new HashMap<String, Object>();
    protected static ThreadLocal<String> bodyJson = new ThreadLocal<>();
    protected static String IDEMPOTENCYID_KEY = "IdempotencyId";
    protected static String AUTHORIZATION_KEY = "Authorization";
    protected static String AUTHORIZATION_VALUE = "Bearer ";
    private static final String PAGE_SIZE_KEY = "pageSize";
    private static final String PAGE_SIZE_VALUE = "10";
    private static final String PAGE_NUMBER_KEY = "pageNumber";
    private static final String PAGE_NUMBER_VALUE = "0";
    protected static final String ISPB = "13370835";
    protected static final String PARTICIPANT_NAME = "STN";
    protected static final String PARTICIPANT_PARAM = "participantName";

    protected GenerateAccessToken generateAccessToken = new GenerateAccessToken();

    public int getIdempotencyId() {
        int faker = FakerUtils.fakerNumber();
        return faker;
    }

    public String getAuthorizationToken() {
        String accessToken = generateAccessToken.getAccessToken();
        return accessToken;
    }

//    public String getMainEngineURL() {
//        RestAssured.baseURI = Settings.MAIN_ENGINE_URL;
//        return RestAssured.baseURI;
//    }

    @SneakyThrows
    public String getMainEngineURL() {
        RestAssured.baseURI = ConfigReader.getPropertiesFile("main.engine.url");
        return RestAssured.baseURI;
    }

    @SneakyThrows
    public String getStubURL() {
        RestAssured.baseURI = ConfigReader.getPropertiesFile("stub.url");
        return RestAssured.baseURI;
    }

    //----------------------------------------------------- GET REQUESTS -----------------------------------------------------------

    /**
     * @param path       recurso desejado
     * @param statusCode codigo esperado na resposta da requisicao
     * @return
     */
    public BaseResponse requestGetWithParams(String path, Map<String, String> param, int statusCode) {
        Response response =
             RestAssured
                 .given().header(AUTHORIZATION_KEY, AUTHORIZATION_VALUE + getAuthorizationToken()).header(PAGE_SIZE_KEY, PAGE_SIZE_VALUE).header(PAGE_NUMBER_KEY, PAGE_NUMBER_VALUE).queryParams(param)
                 .when().contentType(ContentType.JSON).get(getMainEngineURL().concat(path))
                 .then().statusCode(statusCode).extract().response();
        return new RestAssuredResponse(response);
    }

    /**
     * @param path       recurso desejado
     * @param statusCode codigo esperado na resposta da requisicao
     * @return
     */
    public BaseResponse requestTransactionInquiryWithParams(String path, Map<String, String> param, int statusCode) {
        Response response =
            RestAssured
                .given().header(AUTHORIZATION_KEY, AUTHORIZATION_VALUE + getAuthorizationToken()).queryParams(param)
                .when().contentType(ContentType.JSON).get(getMainEngineURL().concat(path))
                .then().statusCode(statusCode).extract().response();
        return new RestAssuredResponse(response);
    }

    public BaseResponse sendXmlDirectToClearingStub(String xml) {
            RestAssured.given()
                .header(AUTHORIZATION_KEY,AUTHORIZATION_VALUE + getAuthorizationToken())
                .when()
                .contentType(ContentType.XML).body(xml)
                .post(getStubURL().concat(Paths.PATH_POST_STUB_INCOMING_MESSAGES))
                .then().statusCode(HttpStatus.SC_OK);
        return null;
    }

    /**
     * @param path       recurso desejado
     * @param statusCode codigo esperado na resposta da requisicao
     * @return
     */
    public BaseResponse requestGetWithoutParams(String path, int statusCode) {
        Response response =
            RestAssured
                .given().header(AUTHORIZATION_KEY, AUTHORIZATION_VALUE + getAuthorizationToken()).header(PAGE_SIZE_KEY, PAGE_SIZE_VALUE).header(PAGE_NUMBER_KEY, PAGE_NUMBER_VALUE)
                .when().contentType(ContentType.JSON).get(getMainEngineURL().concat(path))
                .then().statusCode(statusCode).extract().response();
        return new RestAssuredResponse(response);
    }

    /**
     * @param path       recurso desejado
     * @param statusCode codigo esperado na resposta da requisicao
     * @return
     */
    public BaseResponse requestGetWithoutParamsLM(String path, int statusCode) {
        Response response =
         RestAssured.given().header(AUTHORIZATION_KEY, AUTHORIZATION_VALUE + getAuthorizationToken())
            .header(PAGE_SIZE_KEY, PAGE_SIZE_VALUE).header(PAGE_NUMBER_KEY, PAGE_NUMBER_VALUE).when()
            .contentType(ContentType.JSON).get(getMainEngineURL().concat(path)).then().statusCode(statusCode).extract()
            .response();
        return new RestAssuredResponse(response);
    }

    public BaseResponse requestGetWithPathParams(String path, String paramKey, String paramValue, int statusCode) {
        Response response =
            RestAssured
                .given().header(AUTHORIZATION_KEY, AUTHORIZATION_VALUE + getAuthorizationToken()).header(PAGE_SIZE_KEY, PAGE_SIZE_VALUE).header(PAGE_NUMBER_KEY, PAGE_NUMBER_VALUE)
                .pathParam(paramKey, paramValue)
                .when().contentType(ContentType.JSON).get(getMainEngineURL().concat(path))
                .then().statusCode(statusCode).extract().response();
        return new RestAssuredResponse(response);
    }

    /**
     * @param path       recurso desejado
     * @param id         id de recurso desejado
     * @param statusCode codigo esperado na resposta da requisicao
     * @return
     */
    public Response requestGetWithId(String path, String id, int statusCode) {

        return
            RestAssured.given()
                .pathParam("id", id)
                .when()
                .contentType(ContentType.JSON)
                .get(getMainEngineURL().concat(path))
                .then().statusCode(statusCode)
                .extract()
                .response();
    }

    /**
     * @param path        recurso desejado
     * @param params      query parameters da requisicao
     * @param id          id de recurso desejado
     * @param idParamName complemento de recurso com id para a requisicao
     * @param idParam     id de integração como complemento ao caminho  com id para a requisicao
     * @param statusCode  codigo esperado da resposta da requisicao
     * @return
     */
    public Response requestGetWithIdAndIdRequirementAndParam(String path, Map<String, Object> params, String id, String idParamName, String idParam, int statusCode) {
        return
            RestAssured.given()
                .pathParam("id", id)
                .pathParam(idParamName, idParam)
                .formParams(params)
                .when()
                .contentType(ContentType.JSON)
                .get(getMainEngineURL().concat(path))
                .then().statusCode(statusCode)
                .extract()
                .response();
    }
    public BaseResponse requestGetWithPathParam(String path, int statusCode) {

        Response response = RestAssured.given().header(AUTHORIZATION_KEY, AUTHORIZATION_VALUE + getAuthorizationToken())
            .when().contentType(ContentType.JSON).get(getMainEngineURL().concat(path)).then()
            .statusCode(statusCode).extract().response();
        return new RestAssuredResponse(response);
    }

    public BaseResponse requestGetWithPathParamLm(String path, String param, int statusCode) {

        Response response =
            RestAssured.given().header(AUTHORIZATION_KEY, AUTHORIZATION_VALUE + getAuthorizationToken())
                .pathParam("eventUuid", param).when().contentType(ContentType.JSON).get(getMainEngineURL().concat(path))
                .then().statusCode(statusCode).extract().response();
        return new RestAssuredResponse(response);
    }

    public BaseResponse requestGet(String path, int statusCode) {

        Response response =
            RestAssured.given().header(AUTHORIZATION_KEY, AUTHORIZATION_VALUE + getAuthorizationToken()).when()
                .contentType(ContentType.JSON).get(getMainEngineURL().concat(path)).then().statusCode(statusCode)
                .extract().response();
        return new RestAssuredResponse(response);
    }

    public void requestGetList(String path, String param, int statusCode) {
        List<String> response =
            (List<String>) RestAssured.given().header(AUTHORIZATION_KEY, AUTHORIZATION_VALUE + getAuthorizationToken())
                .pathParam("data", param).when().contentType(ContentType.JSON).get(getMainEngineURL().concat(path))
                .then().statusCode(statusCode).extract().response();
    }
    //----------------------------------------------------- POST REQUESTS ----------------------------------------------------------

    /**
     * @param path       recurso desejado
     * @param param      query parameters da requisicao
     * @param statusCode codigo esperado na resposta da requisicao
     * @return
     */
    public Response requestPost(String path, Map<String, Object> param, int statusCode) {

        return
            RestAssured.given()
                .queryParams(param)
                .when()
                .contentType(ContentType.JSON)
                .post(getMainEngineURL().concat(path))
                .then().statusCode(statusCode)
                .extract()
                .response();
    }

    /**
     * @param path       recurso desejado
     * @param id         id de recurso desejado
     * @param param      query parameters da requisicao
     * @param statusCode codigo esperado na resposta da requisicao
     * @return
     */
    public Response requestPostWithId(String path, String id, Map<String, Object> param, int statusCode) {

        return
            RestAssured.given()
                .pathParam("id", id)
                .queryParams(param)
                .when()
                .contentType(ContentType.JSON)
                .post(getMainEngineURL().concat(path))
                .then().statusCode(statusCode)
                .extract()
                .response();
    }

    /**
     * @param path       recurso desejado
     * @param id         id de recurso desejado
     * @param body       corpo da requisicao
     * @param statusCode codigo esperado na resposta da requisicao
     * @return
     */
    public Response requestPostWithIdAndBody(String path, String id, Map<String, Object> body, int statusCode) {

        return
            RestAssured.given()
                .pathParam("id", id)
                .body(body)
                .when()
                .contentType(ContentType.JSON)
                .post(getMainEngineURL().concat(path))
                .then().statusCode(statusCode)
                .extract()
                .response();
    }

    /**
     * @param path       recurso desejado
     * @param body       corpo da requisicao
     * @param statusCode codigo esperado na resposta da requisicao
     * @return
     */
    public Response requestPostWithBody(String path, String body, int statusCode) {
        return
            RestAssured.given()
                .body(body)
                .contentType(ContentType.JSON)
                .post(getMainEngineURL().concat(path))
                .then().statusCode(statusCode)
                .extract()
                .response();
    }

    /**
     * @param path       recurso desejado
     * @param body       corpo da requisicao
     * @param statusCode codigo esperado na resposta da requisicao
     * @return
     */
    public Response requestPostWithBody(String path, Map<String, Object> body, int statusCode) {
        return
            RestAssured.given()
                .body(body)
                .contentType(ContentType.JSON)
                .post(getMainEngineURL().concat(path))
                .then().statusCode(statusCode)
                .extract()
                .response();
    }

    /**
     * @param path       recurso desejado
     * @param body       corpo da requisicao
     * @param statusCode codigo esperado na resposta da requisicao
     * @return
     */
    public BaseResponse requestPostWithBody(String path, Object body, int statusCode) {
        Response response =
            RestAssured
                .given().header(AUTHORIZATION_KEY, AUTHORIZATION_VALUE + getAuthorizationToken()).body(body).contentType(ContentType.JSON)
                .post(getMainEngineURL().concat(path))
                .then().statusCode(statusCode)
                .extract().response();
        return new RestAssuredResponse(response);
    }

    public BaseResponse requestGetWithBody(String path, Object body, int statusCode) {
        Response response =
            RestAssured
                .given().header(AUTHORIZATION_KEY, AUTHORIZATION_VALUE + getAuthorizationToken()).body(body)
                .contentType(ContentType.JSON)
                .get(getMainEngineURL().concat(path))
                .then().statusCode(statusCode)
                .extract().response();
        return new RestAssuredResponse(response);
    }

    public BaseResponse requestGetParticipantsWithBodyAndParam(String path, Object body, int statusCode) {
        Response response =
            RestAssured
                .given().header(AUTHORIZATION_KEY, AUTHORIZATION_VALUE + getAuthorizationToken()).body(body)
                .queryParam(PARTICIPANT_PARAM, PARTICIPANT_NAME)
                .contentType(ContentType.JSON)
                .get(getMainEngineURL().concat(path))
                .then().statusCode(statusCode)
                .extract().response();
        return new RestAssuredResponse(response);
    }

    public BaseResponse requestPostWithBody(String path, Object body) {
        Response response =
            RestAssured.given().header(AUTHORIZATION_KEY, AUTHORIZATION_VALUE + getAuthorizationToken()).body(body)
                .contentType(ContentType.JSON).post(getMainEngineURL().concat(path)).then().extract().response();
        return new RestAssuredResponse(response);
    }

    /**
     * @param path       recurso desejado
     * @param body       corpo da requisicao
     * @return
     */
    public BaseResponse requestPostWithBodyMEAPI(String path, Object body, String instantPaymentId) {
        Response response = RestAssured.given()
            .header(IDEMPOTENCYID_KEY, getIdempotencyId())
            .header(AUTHORIZATION_KEY, AUTHORIZATION_VALUE + getAuthorizationToken()).body(body)
            .pathParam("instantPaymentId", instantPaymentId)
            .contentType(ContentType.JSON).post(getMainEngineURL().concat(path)).then().extract()
            .response();
        return new RestAssuredResponse(response);
    }

    /**
     * @param path       recurso desejado
     * @param body       corpo da requisicao
     * @param statusCode codigo esperado na resposta da requisicao
     * @return
     */
    public BaseResponse requestPostWithBodyMEAPI(String path, Object body, int statusCode) {
        Response response = RestAssured.given()
            .header(IDEMPOTENCYID_KEY, getIdempotencyId())
            .header(AUTHORIZATION_KEY, AUTHORIZATION_VALUE + getAuthorizationToken()).body(body)
            .contentType(ContentType.JSON).post(getMainEngineURL().concat(path))
            .then().statusCode(statusCode).extract()
            .response();
        return new RestAssuredResponse(response);
    }

    public BaseResponse requestIPAccountOwnerFilter(String path, Object body, int statusCode) {
        Response response =
            RestAssured
                .given()
                .header(PAGE_SIZE_KEY, PAGE_SIZE_VALUE).header(PAGE_NUMBER_KEY, PAGE_NUMBER_VALUE)
                .header(AUTHORIZATION_KEY, AUTHORIZATION_VALUE + getAuthorizationToken()).body(body).contentType(ContentType.JSON)
                .post(getMainEngineURL().concat(path))
                .then().statusCode(statusCode)
                .extract().response();
        return new RestAssuredResponse(response);
    }

    public BaseResponse requestIPAccountOwnerFilterWithOutPageNumber(String path, Object body, int statusCode) {
        Response response =
            RestAssured
                .given()
                .header(PAGE_SIZE_KEY, PAGE_SIZE_VALUE)
                .header(AUTHORIZATION_KEY, AUTHORIZATION_VALUE + getAuthorizationToken()).body(body).contentType(ContentType.JSON)
                .post(getMainEngineURL().concat(path))
                .then().statusCode(statusCode)
                .extract().response();
        return new RestAssuredResponse(response);
    }

    public BaseResponse requestIPAccountOwnerFilterWithOutPageSize(String path, Object body, int statusCode) {
        Response response =
            RestAssured
                .given()
                .header(PAGE_NUMBER_KEY, PAGE_NUMBER_VALUE)
                .header(AUTHORIZATION_KEY, AUTHORIZATION_VALUE + getAuthorizationToken()).body(body).contentType(ContentType.JSON)
                .post(getMainEngineURL().concat(path))
                .then().statusCode(statusCode)
                .extract().response();
        return new RestAssuredResponse(response);
    }

    /**
     * @param path       recurso desejado
     * @param body       corpo da requisicao
     * @param statusCode codigo esperado na resposta da requisicao
     * @return
     */
    public BaseResponse requestPostWithoutAuthenticationToken(String path, Object body, int statusCode) {
        Response response =
            RestAssured.given().body(body).contentType(ContentType.JSON).post(getMainEngineURL().concat(path)).then()
                .statusCode(statusCode).extract().response();
        return new RestAssuredResponse(response);
    }

    /**
     * @param path       recurso desejado
     * @param body       corpo da requisicao
     * @return
     */
    public BaseResponse requestPostWithoutAuthenticationTokenMEAPI(String path, Object body, String instantPaymentId) {
        Response response = RestAssured.given()
            .header(IDEMPOTENCYID_KEY, getIdempotencyId())
            .body(body)
            .pathParam("instantPaymentId", instantPaymentId)
            .contentType(ContentType.JSON).post(getMainEngineURL().concat(path)).then().extract()
            .response();
        return new RestAssuredResponse(response);
    }

    /**
     * @param path       recurso desejado
     * @param body       corpo da requisicao
     * @param statusCode codigo esperado na resposta da requisicao
     * @return
     */
    @SneakyThrows
    public BaseResponse stubRequestPostWithBody(String path, ReceivePaymentModel body, int statusCode) {

        ResponseEntity<String> resp = ClearingStubSendTLSMessage.getInstance().sendTLSMessage(body);
        return new RestTemplateResponse(resp);
    }

    public BaseResponse stubRequestPostWithParamAndBody(String path, Object body, int statusCode) {
        Response response =
            RestAssured.given().header(AUTHORIZATION_KEY, AUTHORIZATION_VALUE + getAuthorizationToken()).body(body)
                .contentType(ContentType.JSON).post(getStubURL().concat(path)).then().statusCode(statusCode).extract()
                .response();
        return new RestAssuredResponse(response);
    }

    /**
     * @param path       recurso desejado
     * @param body       corpo da requisicao
     * @param statusCode codigo esperado na resposta da requisicao
     * @return
     */
    @SneakyThrows
    public BaseResponse stubRequestPostWithBody(String path, String body, int statusCode) {

        ResponseEntity<String> resp = ClearingStubSendTLSMessage.getInstance().sendTLSMessage(body);
        return new RestTemplateResponse(resp);
    }

    /**
     * @param path        recurso desejado
     * @param paramKey    chave de parametro de url para requisicao
     * @param paramValue  valor de parametro de url para requisicao
     * @param statusCode  codigo esperado da resposta da requisicao
     * @return
     */
    public BaseResponse requestPostWithParamsAndBody(String path, String paramKey, String paramValue, Object body, int statusCode) {
        Response response =
            RestAssured
                .given()
                .header(AUTHORIZATION_KEY, AUTHORIZATION_VALUE + getAuthorizationToken())
                .pathParam(paramKey, paramValue)
                .body(body)
                .when().contentType(ContentType.JSON).post(getMainEngineURL().concat(path))
                .then().statusCode(statusCode).extract().response();
        return new RestAssuredResponse(response);
    }

    //----------------------------------------------------- PUT REQUESTS-----------------------------------------------------------

    /**
     * @param path       caminho para a requisicao
     * @param params     parametros query da requisicao
     * @param statusCode codigo esperado da resposta da requisicao
     * @return
     */
    protected Response requestPut(String path, Map<String, Object> params, int statusCode) {
        return
            RestAssured.given()
                .contentType("application/json")
                .contentType(ContentType.JSON)
                .put(getMainEngineURL().concat(path))
                .then().statusCode(statusCode)
                .extract()
                .response();
    }

    /**
     * @param path       caminho para a requisicao
     * @param id         id de integracao ao caminho para a requisicao
     * @param params     parametros de integração para a requisicao
     * @param statusCode codigo esperado da resposta da requisicao
     * @return
     */
    protected Response requestPutWithId(String path, String id, Map<String, Object> params, int statusCode) {
        return
            RestAssured.given()
                .pathParam("id", id)
                .contentType(ContentType.JSON)
                .queryParams(params)
                .put(getMainEngineURL().concat(path))
                .then().statusCode(statusCode)
                .extract()
                .response();
    }

    /**
     * @param path       caminho para a requisicao
     * @param body       corpo para requisicao
     * @param id         id de integracao ao caminho para a requisicao
     * @param statusCode codigo esperado da resposta da requisicao
     * @return
     */
    protected Response requestPutWithIdAndBody(String path, String id, Map<String, Object> body, int statusCode) {
        return
            RestAssured.given()
                .pathParam("id", id)
                .body(body)
                .contentType(ContentType.JSON)
                .put(getMainEngineURL().concat(path))
                .then().statusCode(statusCode)
                .extract()
                .response();
    }

    /**
     * @param path       caminho para a requisicao
     * @param body       corpo para requisicao
     * @param id         de integracao ao caminho para a requisicao
     * @param statusCode codigo esperado da resposta da requisicao
     * @return
     */
    protected Response requestPutWithIdAndBody(String path, String id, String body, int statusCode) {
        return
            RestAssured.given()
                .pathParam("id", id)
                .body(body)
                .contentType(ContentType.JSON)
                .put(getMainEngineURL().concat(path))
                .then().statusCode(statusCode)
                .extract()
                .response();
    }

    //----------------------------------------------------- PATCH REQUESTS -----------------------------------------------------------

    public Response requestPatchWithIdAndIdRequirementAndBody(String path, String id, String idParamName, String idParam, Map<String, Object> body, int statusCode) {
        return
            RestAssured.given()
                .pathParam("id", id)
                .pathParam(idParamName, idParam)
                .body(body)
                .when()
                .contentType(ContentType.JSON)
                .patch(getMainEngineURL().concat(path))
                .then().statusCode(statusCode)
                .extract()
                .response();
    }

    public Response requestPatchWithIdAndIdRequirementAndBody(String path, String id, String idParamName, String idParam, String body, int statusCode) {
        return
            RestAssured.given()
                .pathParam("id", id)
                .pathParam(idParamName, idParam)
                .body(body)
                .when()
                .contentType(ContentType.JSON)
                .patch(getMainEngineURL().concat(path))
                .then().statusCode(statusCode)
                .extract()
                .response();
    }

    public Response requestPatchWithIdAndBody(String path, String id, String body, int statusCode) {
        return
            RestAssured.given()
                .pathParam("id", id)
                .body(body)
                .when()
                .contentType(ContentType.JSON)
                .patch(getMainEngineURL().concat(path))
                .then().statusCode(statusCode)
                .extract()
                .response();
    }


    //----------------------------------------------------- DELETE REQUESTS-----------------------------------------------------------
    /**
     * @param path       caminho para a requisicao
     * @param id         id de integracao ao caminho para a requisicao
     * @param statusCode codigo esperado da resposta da requisicao
     * @return
     */
    protected Response requestDeleteWithId(String path, String id, int statusCode) {
        return
            RestAssured.given()
                .pathParam("id", id)
                .contentType(ContentType.JSON)
                .delete(getMainEngineURL().concat(path))
                .then().statusCode(statusCode)
                .extract()
                .response();
    }

    /**
     * @param path       recurso desejado
     * @param statusCode codigo esperado na resposta da requisicao
     * @return
     */
    public BaseResponse requestDeleteWithPathParams(String path, String paramKey, String paramValue, int statusCode) {
        Response response =
            RestAssured
                .given().header(AUTHORIZATION_KEY, AUTHORIZATION_VALUE + getAuthorizationToken())
                .pathParam(paramKey, paramValue)
                .when().contentType(ContentType.JSON).delete(getMainEngineURL().concat(path))
                .then().statusCode(statusCode).extract().response();
        return new RestAssuredResponse(response);
    }


    //----------------------------------------------------------------------------------------------------------------------
    protected int getStatusCode() {
        return RESPONSE_THREAD_LOCAL.get().statusCode();
    }

    protected String getJsonValue(String value) {
        if (RESPONSE_THREAD_LOCAL.get().getJsonValue(value) == null) {
            return "";
        } else {
            return RESPONSE_THREAD_LOCAL.get().getJsonValue(value);
        }
    }

    protected String getJsonContentValue(int index, String value) {
        ArrayList<Map<String, ?>> jsonContent = RESPONSE_THREAD_LOCAL.get().path("content");

        if (jsonContent.get(index).get(value) == null) {
            return "";
        } else {
            return jsonContent.get(index).get(value).toString();
        }
    }

    protected static String getJsonContentValue(int index, String content, String value) {
        ArrayList<Map<String, ?>> json = RESPONSE_THREAD_LOCAL.get().path(content);

        if (json.get(index).get(value) == null) {
            return "";
        } else {
            return json.get(index).get(value).toString();
        }
    }

    protected String getErrosJsonValue(int index, String value) {
        ArrayList<Map<String, ?>> jsonContent = RESPONSE_THREAD_LOCAL.get().path("erros");

        if (jsonContent.get(index).get(value) == null) {
            return "";
        } else {
            return jsonContent.get(index).get(value).toString();
        }
    }

    protected static String getJsonArrayCountValue(String content) {
        ArrayList<Map<String, ?>> json = RESPONSE_THREAD_LOCAL.get().path(content);
        return Integer.toString(json.size());
    }

    protected void setMap(String key, String value) {
        paramsMap.put(key, value);
    }

    protected String getQueryValue(String value) {
        return QUERY_RESULT_THREAD_LOCAL.get().returnRecord(value);
    }

    protected void waitEndOfReceiptByMainEngine(long l) throws InterruptedException {
        Thread.sleep(l);
    }

    protected void waitEndOfTransactionFromStub(long l) throws InterruptedException {
        Thread.sleep(l);
    }

    protected void logSendedRequest(Object value) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        String print = mapper.writeValueAsString(value);
        System.out.println(print);
    }

    protected void logResponsePretyPrint() {
        RESPONSE_THREAD_LOCAL.get().prettyPrint();
    }

    protected void logResponsePretyPrintMap(String value, BaseResponse response) {
        RESPONSE_MAP_THREAD_LOCAL.put(value, response);
        RESPONSE_MAP_THREAD_LOCAL.get(value).prettyPrint();
    }

    protected void validateJsonSchema(String jsonSchemaPath) {
        String apiResponse = RESPONSE_THREAD_LOCAL.get().responseAsString();
        Asserts.assertThat(apiResponse, matchesJsonSchemaInClasspath(jsonSchemaPath));
        log.info("--------------- API contract validated successfully!!! ---------------");
    }

    protected void validateJsonSchema(String value, String jsonSchemaPath) {
        String apiResponse = RESPONSE_MAP_THREAD_LOCAL.get(value).responseAsString();
        Asserts.assertThat(apiResponse, matchesJsonSchemaInClasspath(jsonSchemaPath));
        log.info("--------------- API contract validated successfully!!! ---------------");
    }

}
