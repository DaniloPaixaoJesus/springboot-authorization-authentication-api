package matera.spi.mainengine.utils;

import matera.spi.mainengine.commons.Paths;
import matera.spi.mainengine.model.mainengine.receivers.ui.ReceivePaymentModel;
import matera.spi.mainengine.properties.Settings;

import lombok.SneakyThrows;
import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClients;
import org.jetbrains.annotations.NotNull;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;

public class ClearingStubSendTLSMessage {

    private static final char[] KEYSTORE_PASSWORD = "materaspi".toCharArray();
    private static final String KEYSTORE_PATH = "keystores/client-qa-keystore-tls.jks";
    private static final String TRUSTSTORE_PATH = "keystores/client-qa-truststore-tls.jks";
    private static final ClearingStubSendTLSMessage INSTANCE = new ClearingStubSendTLSMessage();
    private RestTemplate restTemplate = getRestTemplate();
    public static final String ISPB = "13370835";

    public static ClearingStubSendTLSMessage getInstance() {
        return INSTANCE;
    }

    private ClearingStubSendTLSMessage() {
    }

    @SneakyThrows
    public ResponseEntity<String> sendTLSMessage(ReceivePaymentModel receivePaymentModel) {
        String url = ConfigReader.getPropertiesFile("stub.url") + Paths.PATH_POST_STUB_INCOMING_MESSAGES;
        URI uri = URI.create(url);

        HttpEntity<ReceivePaymentModel> receivePaymentModelHttpEntity = new HttpEntity<>(receivePaymentModel);

        ResponseEntity<String> response = restTemplate.postForEntity(uri, receivePaymentModelHttpEntity, String.class);

        return response;
    }

    @SneakyThrows
    public ResponseEntity<String> sendTLSMessage(String incomingMessageDetail) {
        String url = ConfigReader.getPropertiesFile("stub.url").concat(Paths.PATH_POST_STUB_INCOMING_MESSAGES).concat("/").concat(ISPB);
        URI uri = URI.create(url);

        HttpEntity<String> incomingMessageDetailHttpEntity = new HttpEntity<>(incomingMessageDetail);

        ResponseEntity<String> response = restTemplate.postForEntity(uri, incomingMessageDetailHttpEntity, String.class);

        return response;
    }

    @NotNull
    @SneakyThrows
    private RestTemplate getRestTemplate() {
        SSLContext sslContext = SSLContext.getInstance("TLSv1.2", "SunJSSE");

        KeyManager[] keyManagers = getKeyManagers();
        TrustManager[] trustManagers = getTrustManagers();

        sslContext.init(keyManagers, trustManagers, null);

        HttpClient client = HttpClients.custom().setSSLContext(sslContext).build();

        ClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(client);

        RestTemplate restTemplate = new RestTemplate();
        restTemplate.setRequestFactory(requestFactory);
        return restTemplate;
    }

    private KeyStore getKeyStore(String s)
        throws KeyStoreException, IOException, NoSuchAlgorithmException, CertificateException {
        KeyStore keyStore = KeyStore.getInstance("JKS");
        InputStream is = getClass().getClassLoader().getResourceAsStream(s);
        keyStore.load(is, KEYSTORE_PASSWORD);
        return keyStore;
    }

    private KeyManager[] getKeyManagers() throws NoSuchAlgorithmException, UnrecoverableKeyException, KeyStoreException, IOException, CertificateException {
        KeyStore keyStore = getKeyStore(KEYSTORE_PATH);
        KeyManagerFactory kmfactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        kmfactory.init(keyStore, KEYSTORE_PASSWORD);
        return kmfactory.getKeyManagers();
    }

    private TrustManager[] getTrustManagers() throws NoSuchAlgorithmException, KeyStoreException, IOException, CertificateException {
        KeyStore trustStore = getKeyStore(TRUSTSTORE_PATH);
        TrustManagerFactory tmfactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        tmfactory.init(trustStore);
        return tmfactory.getTrustManagers();
    }
}
