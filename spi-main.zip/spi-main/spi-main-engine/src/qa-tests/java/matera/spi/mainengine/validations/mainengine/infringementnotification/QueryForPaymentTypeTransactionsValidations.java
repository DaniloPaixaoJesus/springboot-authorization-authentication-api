package matera.spi.mainengine.validations.mainengine.infringementnotification;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.utils.Asserts;
import matera.spi.mainengine.requests.mainengine.payments.api.PACS008BodyPostSendedAPI;
import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;
import org.junit.Assert;

public class QueryForPaymentTypeTransactionsValidations extends BaseAction {

    public void validSuccessfullPaymentQueriedTransactionResponse(int statusCodeReceived,
                                                        String payerBranch,
                                                        String payerAccountNumber,
                                                        String receiverBranch,
                                                        String receiverAccountNumber,
                                                        String correlationId,
                                                        String endToEndId,
                                                        String originalAmount,
                                                        String maximumAmountReturn,
                                                        String effectiveSettlementDate,
                                                        String eventType,
                                                        String eventStatus) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodeReceived);
        Asserts.assertThat(payerBranch, Matchers.is(PACS008BodyPostSendedAPI.VALID_PAYER_BRANCH));
        Asserts.assertThat(payerAccountNumber, Matchers.is(PACS008BodyPostSendedAPI.VALID_PAYER_ACCOUNT_NUMBER));
        Asserts.assertThat(receiverBranch, Matchers.is(PACS008BodyPostSendedAPI.VALID_RECEIVER_BRANCH));
        Asserts.assertThat(receiverAccountNumber, Matchers.is(PACS008BodyPostSendedAPI.VALID_RECEIVER_ACCOUNT_NUMBER));
        Asserts.assertThat(endToEndId, Matchers.is(correlationId));
        Asserts.assertThat(originalAmount, Matchers.is(PACS008BodyPostSendedAPI.VALID_VALUE));
        Asserts.assertThat(maximumAmountReturn, Matchers.is(PACS008BodyPostSendedAPI.VALID_VALUE));
        Asserts.assertThat(effectiveSettlementDate, Matchers.notNullValue());
        Asserts.assertThat(eventType, Matchers.is("PAYMENT"));
        Asserts.assertThat(eventStatus, Matchers.is("SUCCESS"));
    }

    public void validRejectedPaymentQueriedTransactionResponse(int statusCodeReceived,
                                                                String correlationId,
                                                                String endToEndId,
                                                                String originalAmount,
                                                                String maximumAmountReturn,
                                                                String effectiveSettlementDate,
                                                                String eventType,
                                                                String eventStatus) throws Exception {
            Asserts.assertEquals(HttpStatus.SC_OK, statusCodeReceived);
            Asserts.assertThat(endToEndId, Matchers.is(correlationId));
            Asserts.assertThat(originalAmount, Matchers.is(PACS008BodyPostSendedAPI.VALID_VALUE));
            Asserts.assertThat(maximumAmountReturn, Matchers.is(PACS008BodyPostSendedAPI.VALID_VALUE));
            Asserts.assertThat(effectiveSettlementDate, Matchers.notNullValue());
            Asserts.assertThat(eventType, Matchers.is("PAYMENT"));
            Asserts.assertThat(eventStatus, Matchers.is("PAYMENT_REJECTED"));
    }

    public void validAdmi002ErrorPaymentQueriedTransactionResponse(int statusCodeReceived,
                                                                    String correlationId,
                                                                    String endToEndId,
                                                                    String originalAmount,
                                                                    String maximumAmountReturn,
                                                                    String effectiveSettlementDate,
                                                                    String eventType,
                                                                    String eventStatus) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodeReceived);
        Asserts.assertThat(endToEndId, Matchers.is(correlationId));
        Asserts.assertThat(originalAmount, Matchers.is(PACS008BodyPostSendedAPI.VALID_VALUE));
        Asserts.assertThat(maximumAmountReturn, Matchers.is(PACS008BodyPostSendedAPI.VALID_VALUE));
        Asserts.assertThat(effectiveSettlementDate, Matchers.notNullValue());
        Asserts.assertThat(eventType, Matchers.is("PAYMENT"));
        Asserts.assertThat(eventStatus, Matchers.is("ERROR"));
    }

    public void validAllPaymentTypeTransactionsQueriedTransactionResponse(int statusCodeReceived,
                                                                           String paymentTypeTransactionsList,
                                                                           String correlationId,
                                                                           String endToEndId
                                                                          ) throws Exception {

        Asserts.assertEquals(HttpStatus.SC_OK, statusCodeReceived);
        Asserts.assertThat(endToEndId, Matchers.is(correlationId));
        Asserts.assertNotNull("Validating returned data list", paymentTypeTransactionsList);
        Assert.assertTrue(paymentTypeTransactionsList.length() > 0);
    }
}
