package matera.spi.mainengine.model.mainengine.participants;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ValidGetParticipants {

    private String ispb;
    private String name;

    public ValidGetParticipants changeIspb(String newIspb){
        setIspb(newIspb);
        return this;
    }

    public ValidGetParticipants changeName(String newName){
        setName(newName);
        return this;
    }

}
