package matera.spi.mainengine.validations.mainengine.payments.ui;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.utils.Asserts;

import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;

import static matera.spi.mainengine.utils.Util.assertEquals;

public class PaymentValidationsUI extends BaseAction {

    public void validPACS008Response() throws Exception {
        Asserts.assertEquals(HttpStatus.SC_CREATED, getStatusCode());
        Asserts.assertThat(getJsonValue("data.InstantPayments.endToEndId"), Matchers.notNullValue());
        Asserts.assertThat(getJsonValue("data.InstantPayments.eventID"), Matchers.notNullValue());
    }

    public void validPACS002Response(String endToEndId, String eventId) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, getStatusCode());
        Asserts.assertThat(getJsonValue("data.content[0].eventId"), Matchers.is(eventId));
        Asserts.assertThat(getJsonValue("data.content[0].status.code"), Matchers.is("3"));
        Asserts.assertThat(getJsonValue("data.content[0].status.description"), Matchers.is("Success"));
        Asserts.assertThat(getJsonValue("data.content[0].endToEndId"), Matchers.is(endToEndId));
    }

    public void invalidPACS008Response(String errorCode, String message) throws Exception {
        switch (getStatusCode()) {
            case 400:
                Asserts.assertEquals(HttpStatus.SC_BAD_REQUEST, getStatusCode());
                Asserts.assertThat(getJsonValue("error[0].code"), Matchers.equalTo(errorCode));
                Asserts.assertThat(getJsonValue("error[0].message"), Matchers.equalTo(message));
                break;
            case 500:
                assertEquals(HttpStatus.SC_INTERNAL_SERVER_ERROR, getStatusCode());
                Asserts.assertThat(getJsonValue("error[0].code"), Matchers.equalTo(errorCode));
                Asserts.assertThat(getJsonValue("error[0].message"), Matchers.equalTo(message));
                break;
            default:
                break;
        }
    }

    public void duplicatedEventResponse(String endToEndId) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_BAD_REQUEST, getStatusCode());
        Asserts.assertThat(getJsonValue("error[0].code"), Matchers.equalTo("SPI-ME-009"));
        Asserts.assertThat(getJsonValue("error[0].message"), Matchers.equalTo("Event with EndToEndId " + endToEndId + " was already created"));
    }

    public void invalidEndToEndIdResponse(String invalidEndToEndId) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_BAD_REQUEST, getStatusCode());
        Asserts.assertThat(getJsonValue("error[0].code"), Matchers.equalTo("Pattern"));
        Asserts.assertThat(getJsonValue("error[0].message"), Matchers.equalTo("Field payments[0].endToEndID: must match \"[E|D][0-9]{8}[0-9]{4}[0-1][0-9][0-3][0-9][0-2][0-9][0-5][0-9][a-zA-Z0-9]{11}\". Informed value: " + "["+invalidEndToEndId+"]"));
    }

    public void nullEndToEndIdResponse() throws Exception {
        Asserts.assertEquals(HttpStatus.SC_BAD_REQUEST, getStatusCode());
        Asserts.assertThat(getJsonValue("error[0].code"), Matchers.equalTo("NotNull"));
        Asserts.assertThat(getJsonValue("error[0].message"), Matchers.equalTo("Field payments[0].endToEndID: must not be null"));
    }

    public void validPaymentIntraPSPByUI() throws Exception {
        Asserts.assertEquals(HttpStatus.SC_BAD_REQUEST, getStatusCode());
        Asserts.assertThat(getJsonValue("error[0].code"), Matchers.equalTo("SPI-ME-026"));
        Asserts.assertThat(getJsonValue("error[0].message"), Matchers.equalTo("It is not possible to transfer intra MIP or intra PSP through the frontend"));
    }
}
