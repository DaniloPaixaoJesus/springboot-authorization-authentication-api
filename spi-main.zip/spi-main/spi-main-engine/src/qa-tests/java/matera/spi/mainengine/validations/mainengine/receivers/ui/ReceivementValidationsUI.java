package matera.spi.mainengine.validations.mainengine.receivers.ui;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.utils.Asserts;

import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;

public class ReceivementValidationsUI extends BaseAction {

    public void validPACS002Response(String endToEndId) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, getStatusCode());
        Asserts.assertThat(getJsonValue("data.content[0].status.code"), Matchers.is("3"));
        Asserts.assertThat(getJsonValue("data.content[0].status.description"), Matchers.is("Success"));
        Asserts.assertThat(getJsonValue("data.content[0].endToEndId"), Matchers.is(endToEndId));
    }

    public void rejectedPACS002Response(String endToEndId) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, getStatusCode());
        Asserts.assertThat(getJsonValue("data.content[0].status.code"), Matchers.is("20"));
        Asserts.assertThat(getJsonValue("data.content[0].status.description"), Matchers.is("Receipt Rejected by Clearing"));
        Asserts.assertThat(getJsonValue("data.content[0].endToEndId"), Matchers.is(endToEndId));
    }

    public void validateAdmi002ErrorPACS002Response(String endToEndId) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, getStatusCode());
        Asserts.assertThat(getJsonValue("data.content[0].status.code"), Matchers.is("5"));
        Asserts.assertThat(getJsonValue("data.content[0].status.description"), Matchers.is("Error"));
        Asserts.assertThat(getJsonValue("data.content[0].endToEndId"), Matchers.is(endToEndId));
    }
}
