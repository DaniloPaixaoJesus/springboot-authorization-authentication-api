package matera.spi.mainengine.core;

import io.restassured.path.json.config.JsonPathConfig;

import java.util.ArrayList;
import java.util.Map;

public interface BaseResponse {

    void prettyPrint();

    String responseAsString();

    ArrayList<Map<String, ?>> path(String content);

    int statusCode();

    String getJsonValue(String value);

    String getJsonValue(String value, JsonPathConfig jsonPathConfig);

}
