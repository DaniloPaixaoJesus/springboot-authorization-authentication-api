package matera.spi.mainengine.validations.mainengine.indirects;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.utils.Asserts;

import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;

public class IndirectsMIPParticipantsValidationsUI extends BaseAction {

    public void validQueriedIndirectsMIPParticipantsResponse(String indirectMIPParticipantsList) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, getStatusCode());
        Asserts.assertThat(indirectMIPParticipantsList, Matchers.notNullValue());
        Asserts.assertThat(indirectMIPParticipantsList, Matchers.containsString("name"));
        Asserts.assertThat(indirectMIPParticipantsList, Matchers.containsString("corporateName"));
        Asserts.assertThat(indirectMIPParticipantsList, Matchers.containsString("taxId"));
        Asserts.assertThat(indirectMIPParticipantsList, Matchers.containsString("ispb"));
        Asserts.assertThat(indirectMIPParticipantsList, Matchers.containsString("status"));
        Asserts.assertThat(indirectMIPParticipantsList, Matchers.containsString("contractInitDate"));
        Asserts.assertThat(indirectMIPParticipantsList, Matchers.containsString("contractEndDate"));
    }

    public void validCreatedsIndirectsMIPParticipantsResponse(int statusCodeReceived, String newRegister) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_CREATED, statusCodeReceived);
        Asserts.assertThat(newRegister, Matchers.equalTo("WAITING_TO_SEND_REGISTRATION_TO_CLEARING"));
    }

    public void validQueriedIndirectsMIPParticipantByIdResponse(int statusCodeReceived,
                                                                String indirectMIPParticipantData,
                                                                String ispb,
                                                                String indirectIspbReturned,
                                                                String name,
                                                                String indirectNameReturned,
                                                                String corporateName,
                                                                String indirectCorporateNameReturned,
                                                                String status,
                                                                String indirectStatusReturned,
                                                                String contractInitDate,
                                                                String indirectContractInitDate,
                                                                String contractEndDate,
                                                                String indirectContractEndDate,
                                                                String managerialAccountEnabled,
                                                                String indirectManagerialAccountEnabled) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodeReceived);
        Asserts.assertThat(indirectMIPParticipantData,  Matchers.notNullValue());
        Asserts.assertThat(ispb, Matchers.is(indirectIspbReturned));
        Asserts.assertThat(name, Matchers.is(indirectNameReturned));
        Asserts.assertThat(corporateName, Matchers.is(indirectCorporateNameReturned));
        Asserts.assertThat(status, Matchers.is(indirectStatusReturned));
        Asserts.assertThat(contractInitDate, Matchers.is(indirectContractInitDate));
        Asserts.assertThat(contractEndDate, Matchers.is(indirectContractEndDate));
        Asserts.assertThat(managerialAccountEnabled, Matchers.is(indirectManagerialAccountEnabled));
    }

}
