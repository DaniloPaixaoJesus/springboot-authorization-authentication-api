package matera.spi.mainengine.validations.mainengine.infringementnotification;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.requests.mainengine.payments.ui.PACS008BodyPostSendedUI;
import matera.spi.mainengine.utils.Asserts;

import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;
import org.junit.Assert;

public class QueryForReceiveADevolutionTypeTransactionsValidations extends BaseAction {

    public static final String PAYER_BRANCH = "2637";
    public static final String PAYER_ACCOUNT_NUMBER = "123456-7";
    public static final String RECEIVER_BRANCH = "9911";
    public static final String RECEIVER_ACCOUNT_NUMBER = "00290785";
    public static final String ORIGINAL_AMOUNT = "20.0";

    public void validSuccessfullDevolutionReceiptQueriedTransactionResponse(int statusCodeReceived,
                                                                      String payerBranch,
                                                                      String payerAccountNumber,
                                                                      String receiverBranch,
                                                                      String receiverAccountNumber,
                                                                      String originalAmount,
                                                                      String effectiveSettlementDate,
                                                                      String eventType,
                                                                      String eventStatus) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodeReceived);
        Asserts.assertThat(payerBranch, Matchers.is(PAYER_BRANCH));
        Asserts.assertThat(payerAccountNumber, Matchers.is(PAYER_ACCOUNT_NUMBER));
        Asserts.assertThat(receiverBranch, Matchers.is(RECEIVER_BRANCH));
        Asserts.assertThat(receiverAccountNumber, Matchers.is(RECEIVER_ACCOUNT_NUMBER));
        if(originalAmount.endsWith(".0")){
            Asserts.assertThat(originalAmount.concat("0"), Matchers.is(PACS008BodyPostSendedUI.VALID_INTERBANK_SETTLEMENT_AMOUNT));
        }
        Asserts.assertThat(effectiveSettlementDate, Matchers.notNullValue());
        Asserts.assertThat(eventType, Matchers.is("RETURN_RECEIVED"));
        Asserts.assertThat(eventStatus, Matchers.is("SUCCESS"));
    }

    public void validUpdatedOriginalPaymentAmountQueriedTransactionResponse(int statusCodeReceived,
                                                                             String correlationId,
                                                                             String endToEndId,
                                                                             String originalAmount,
                                                                             String maximumAmountReturn,
                                                                             String effectiveSettlementDate,
                                                                             String eventType,
                                                                             String eventStatus) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodeReceived);
        Asserts.assertThat(endToEndId, Matchers.is(correlationId));
        if(originalAmount.endsWith(".0")){
            Asserts.assertThat(originalAmount.concat("0"), Matchers.is(PACS008BodyPostSendedUI.VALID_INTERBANK_SETTLEMENT_AMOUNT));
        }
        if(maximumAmountReturn.endsWith(".0")){
            Asserts.assertNotEquals(maximumAmountReturn.concat("0"), PACS008BodyPostSendedUI.VALID_INTERBANK_SETTLEMENT_AMOUNT);
        }
        Asserts.assertThat(effectiveSettlementDate, Matchers.notNullValue());
        Asserts.assertThat(eventType, Matchers.is("PAYMENT"));
        Asserts.assertThat(eventStatus, Matchers.is("SUCCESS"));
    }

    public void validRejectedDevolutionReceiptQueriedTransactionResponse(int statusCodeReceived,
                                                                         String originalAmount,
                                                                         String effectiveSettlementDate,
                                                                         String eventType,
                                                                         String eventStatus) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodeReceived);
        if(originalAmount.endsWith(".0")){
            Asserts.assertThat(originalAmount.concat("0"), Matchers.is(PACS008BodyPostSendedUI.VALID_INTERBANK_SETTLEMENT_AMOUNT));
        }
        Asserts.assertThat(effectiveSettlementDate, Matchers.notNullValue());
        Asserts.assertThat(eventType, Matchers.is("RETURN_RECEIVED"));
        Asserts.assertThat(eventStatus, Matchers.is("RETURN_REJECTED_BY_CLEARING"));
    }


    public void validADMI002ErrorDevolutionReceiptQueriedTransactionResponse(int statusCodeReceived,
                                                                              String originalAmount,
                                                                              String effectiveSettlementDate,
                                                                              String eventType,
                                                                              String eventStatus) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodeReceived);
        if(originalAmount.endsWith(".0")){
            Asserts.assertThat(originalAmount.concat("0"), Matchers.is(PACS008BodyPostSendedUI.VALID_INTERBANK_SETTLEMENT_AMOUNT));
        }
        Asserts.assertThat(effectiveSettlementDate, Matchers.notNullValue());
        Asserts.assertThat(eventType, Matchers.is("RETURN_RECEIVED"));
        Asserts.assertThat(eventStatus, Matchers.is("ERROR"));

    }

    public void validNotUpdatedOriginalPaymentAmountQueriedTransactionResponse(int statusCodeReceived,
                                                                               String correlationId,
                                                                               String endToEndId,
                                                                               String originalAmount,
                                                                               String maximumAmountReturn,
                                                                               String effectiveSettlementDate,
                                                                               String eventType,
                                                                               String eventStatus) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodeReceived);
        Asserts.assertThat(endToEndId, Matchers.is(correlationId));
        if(originalAmount.endsWith(".0")){
            Asserts.assertThat(originalAmount.concat("0"), Matchers.is(PACS008BodyPostSendedUI.VALID_INTERBANK_SETTLEMENT_AMOUNT));
        }
        if(maximumAmountReturn.endsWith(".0")){
            Asserts.assertEquals(maximumAmountReturn.concat("0"), PACS008BodyPostSendedUI.VALID_INTERBANK_SETTLEMENT_AMOUNT);
        }
        Asserts.assertThat(effectiveSettlementDate, Matchers.notNullValue());
        Asserts.assertThat(eventType, Matchers.is("PAYMENT"));
        Asserts.assertThat(eventStatus, Matchers.is("SUCCESS"));
    }

    public void validAllReceiveADevolutionTypeTransactionsQueriedTransactionResponse(int statusCodeReceived,
                                                                                     String ReceiveADevolutionTypeTransactionsList) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodeReceived);
        Asserts.assertNotNull("Validating returned data list", ReceiveADevolutionTypeTransactionsList);
        Assert.assertTrue(ReceiveADevolutionTypeTransactionsList.length() > 0);
    }

}
