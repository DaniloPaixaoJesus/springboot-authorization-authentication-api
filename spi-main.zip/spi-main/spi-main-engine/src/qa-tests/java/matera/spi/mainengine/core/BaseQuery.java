package matera.spi.mainengine.core;

import matera.spi.mainengine.dao.DBUtils;
import matera.spi.mainengine.dao.QueryResult;
import java.util.List;

/**
 * Base class of queries for use in the database query classes of the system's features
 *
 * @author jefferson.bessa
 * @author felipe.silva
 *
 */
public class BaseQuery {

    private static ThreadLocal<DBUtils> dbUtils = new ThreadLocal<>();
    private static ThreadLocal<QueryResult> queryResult = new ThreadLocal<>();

    /**
     * Method for bringing the result of a query
     *
     * @param query query parameter to be executed
     * @return returns the result of the query
     */
    public static QueryResult getQuery(String query) {
        dbUtils.set(new DBUtils());
        return dbUtils.get().getQuery(query);
    }

    /**
     * Method for bringing the result of a query with parameters
     *
     * @param query parameter query is the query to be executed
     * @param parameters parameter parameters are the parameters that the query has
     * @return returns the result of the query
     */
    public static QueryResult getQueryWithParameters(String query, List<String> parameters) {
        dbUtils.set(new DBUtils());
        for (String parameter : parameters) {
            dbUtils.get().addParameter(parameter);
        }
        return dbUtils.get().getQuery(query);
    }

    /**
     * Method for bringing the value of a column of the query result
     *
     * @param query parameter query is the query to be executed
     * @param column parameter column is the column to be captured the value
     * @return returns the column value
     */
    public static String getQueryValue(String query, String column) {
        dbUtils.set(new DBUtils());
        queryResult.set(dbUtils.get().getQuery(query));
        return queryResult.get().returnRecord(column);
    }

    /**
     * Method for bringing the value of a column of the result of a query with
     * parameters
     *
     * @param query parameter query is the query to be executed
     * @param column column parameter column is the column to be captured the value
     * @param parameters parameter parameters are the parameters that the query has
     * @return returns the column value
     */
    public static String getQueryValueWithParameters(String query, String column, List<String> parameters) {
        dbUtils.set(new DBUtils());
        for (String parameter : parameters) {
            dbUtils.get().addParameter(parameter);
        }
        queryResult.set(dbUtils.get().getQuery(query));
        return queryResult.get().returnRecord(column);
    }

    /**
     * Method to perform an update
     *
     * @param query parameter query is the query to be executed
     * @param parameters parameter parameters are the parameters that the query has
     */
    public static void updateQuery(String query, List<String> parameters) {
        dbUtils.set(new DBUtils());
        for (String parameter : parameters) {
            dbUtils.get().addParameter(parameter);
        }
        dbUtils.get().update(query);
    }
}
