package matera.spi.mainengine.validations.mainengine.ipaccount;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.utils.Asserts;
import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;

public class GetIpAccountConfigDataValidations extends BaseAction {

    public void validQueriedIpAccountConfigDataValidationsResponse(String ipMirrorAccountDataList) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, getStatusCode());
        Asserts.assertThat(ipMirrorAccountDataList, Matchers.notNullValue());
        Asserts.assertThat(ipMirrorAccountDataList, Matchers.containsString("debitTransactionType"));
        Asserts.assertThat(ipMirrorAccountDataList, Matchers.containsString("branch"));
        Asserts.assertThat(ipMirrorAccountDataList, Matchers.containsString("accountNumber"));
        Asserts.assertThat(ipMirrorAccountDataList, Matchers.containsString("creditTransactionType"));
        Asserts.assertThat(ipMirrorAccountDataList, Matchers.containsString("balanceValidationThreshold"));
        Asserts.assertThat(ipMirrorAccountDataList, Matchers.containsString("drawbackReceiveTransactType"));
        Asserts.assertThat(ipMirrorAccountDataList, Matchers.containsString("drawbackSentTransactType"));
        Asserts.assertThat(ipMirrorAccountDataList, Matchers.containsString("balanceLowerThreshold"));
        Asserts.assertThat(ipMirrorAccountDataList, Matchers.containsString("balanceLowerThresholdPercent"));
        Asserts.assertThat(ipMirrorAccountDataList, Matchers.containsString("balanceUpperThreshold"));
        Asserts.assertThat(ipMirrorAccountDataList, Matchers.containsString("balanceUpperThresholdPercent"));
        Asserts.assertThat(ipMirrorAccountDataList, Matchers.containsString("depositTransactionType"));
        Asserts.assertThat(ipMirrorAccountDataList, Matchers.containsString("withdrawTransactionType"));
        Asserts.assertThat(ipMirrorAccountDataList, Matchers.containsString("qrcodeCredTransactionType"));
    }
}
