package matera.spi.mainengine.dao;

import java.sql.Connection;

public class Database {

	private static Connection conn = null;

	public Connection getConn() {
	    return conn;
	}

	public void setConn(Connection conn) {
	   Database.conn = conn;
	}

}
