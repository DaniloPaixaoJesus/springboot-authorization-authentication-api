package matera.spi.mainengine.requests.mainengine.participants;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.model.mainengine.receivers.ui.IncomingMessageDetail;
import matera.spi.mainengine.utils.DocumentConverterUtil;

public class AddOrRemoveParticipant extends BaseAction {
    public static final String CAMT_014 = "src/qa-tests/resources/xml/mainengine/camt-014-example.xml";
    public static final String STATUS_PLACEHOLDER = "###status###";
    public static final String PARTICIPANT_ISPB_PLACEHOLDER = "###participantIspb###";
    IncomingMessageDetail incomingMessageDetail = new IncomingMessageDetail();

    public String validAddOrRemoveParticipant(String status, String participantIspb) {
        String camt014 = parseFileToXMLStringFormat();
        camt014 = camt014.replace(STATUS_PLACEHOLDER, status);
        camt014 = camt014.replace(PARTICIPANT_ISPB_PLACEHOLDER, participantIspb);
        incomingMessageDetail.setXml(camt014);
        return camt014;
    }

    public String parseFileToXMLStringFormat() {
        String xml = DocumentConverterUtil.convertFileToString(CAMT_014);
        return xml;
    }
}
