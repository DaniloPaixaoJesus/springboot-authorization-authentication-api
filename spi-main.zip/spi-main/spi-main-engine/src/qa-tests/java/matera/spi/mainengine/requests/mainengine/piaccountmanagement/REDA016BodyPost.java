package matera.spi.mainengine.requests.mainengine.piaccountmanagement;

import matera.spi.mainengine.model.mainengine.receivers.ui.IncomingMessageDetail;
import matera.spi.mainengine.utils.DocumentConverterUtil;

public class REDA016BodyPost {

    public static final String REDA_016 ="src/qa-tests/resources/xml/mainengine/reda-016-example.xml";
    public static final String MESSAGEID_PLACEHOLDER = "###MessageId###";
    public static final String STATUS_PLACEHOLDER = "###Status###";
    IncomingMessageDetail incomingMessageDetail = new IncomingMessageDetail();

    public String parseFileToXMLStringFormat() {
        String xml = DocumentConverterUtil.convertFileToString(REDA_016);
        return xml;
    }

    public String receiveValidREDA016(String messageId, String status){
        String reda016 = parseFileToXMLStringFormat();
        reda016 = reda016.replace(MESSAGEID_PLACEHOLDER, messageId);
        reda016 = reda016.replace(STATUS_PLACEHOLDER, status);
        incomingMessageDetail.setXml(reda016);
        return reda016;
    }

}
