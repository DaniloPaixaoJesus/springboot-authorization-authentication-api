package matera.spi.mainengine.core;

import io.restassured.path.json.config.JsonPathConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.Map;

@Slf4j
public class RestTemplateResponse implements BaseResponse {

    private ResponseEntity<String> responseEntity;

    public RestTemplateResponse(ResponseEntity<String> restAssuredResponse) {
        this.responseEntity = restAssuredResponse;
    }

    @Override
    public void prettyPrint() {
        log.info(responseEntity.getBody());
    }

    @Override
    public String responseAsString() {
        String result = responseEntity.getBody().toString();
        return result;
    }

    @Override
    public ArrayList<Map<String, ?>> path(String content) {
        throw new UnsupportedOperationException("STUB messages should not be validated!");
    }

    @Override
    public int statusCode() {
        return responseEntity.getStatusCodeValue();
    }

    @Override
    public String getJsonValue(String value) {
        throw new UnsupportedOperationException("STUB messages should not be validated!");
    }

    @Override
    public String getJsonValue(String value, JsonPathConfig jsonPathConfig) {
        throw new UnsupportedOperationException("STUB messages should not be validated!");
    }

}
