package matera.spi.mainengine.requests.mainengine.piaccountmanagement;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.model.mainengine.piaccountmanagement.PIAccountManagementModel;

import com.github.javafaker.Faker;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import static matera.spi.mainengine.utils.FakerUtils.fakerName;

public class REDA022BodyPost extends BaseAction {

    public static String VALID_DIRECTOR_NAME = fakerName();
    public static final String VALID_DIRECTOR_EMAIL = "director@mail.com";
    public static final String VALID_DIRECTOR_PHONE = "+55-6144444444";
    public static final String VALID_DIRECTOR_MOBILE = "+55-613333333";
    public static final String VALID_PASS_PHRASE = "12345678";
    public static final String VALID_DIRECTOR_TAX_ID = "57533154029";
    public static final String VALID_EMPLOYEE_EMAIL = "employee@mail.com";
    public static final String VALID_EMPLOYEE_PHONE = "+55-14911223344";
    public static final String VALID_EMPLOYEE_MOBILE = "+55-14900000000";
    public static final String VALID_EMPLOYEE_FAX = "+55-14911111111";

    public PIAccountManagementModel validREDA022() {

        PIAccountManagementModel PIAccountManagementModel = new PIAccountManagementModel();
        PIAccountManagementModel.setDirectorName(VALID_DIRECTOR_NAME);
        PIAccountManagementModel.setDirectorEmail(VALID_DIRECTOR_EMAIL);
        PIAccountManagementModel.setDirectorPhone(VALID_DIRECTOR_PHONE);
        PIAccountManagementModel.setDirectorMobile(VALID_DIRECTOR_MOBILE);
        PIAccountManagementModel.setPassPhrase(VALID_PASS_PHRASE);
        PIAccountManagementModel.setDirectorTaxId(VALID_DIRECTOR_TAX_ID);
        PIAccountManagementModel.setEmployeeEmail(VALID_EMPLOYEE_EMAIL);
        PIAccountManagementModel.setEmployeePhone(VALID_EMPLOYEE_PHONE);
        PIAccountManagementModel.setEmployeeMobile(VALID_EMPLOYEE_MOBILE);
        PIAccountManagementModel.setEmployeeFax(VALID_EMPLOYEE_FAX);

        return PIAccountManagementModel;
    }

    public Map<String, String> setParamsEventStatus() {

        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");

        Map<String, String> eventParam = new HashMap<>();
        eventParam.put("startTimestampUtc", LocalDateTime.now().minusDays(1).format(dateTimeFormatter));
        eventParam.put("endTimestampUtc", LocalDateTime.now().plusDays(1).format(dateTimeFormatter));
        eventParam.put("eventStatusCode", "35");
        return eventParam;
    }

}
