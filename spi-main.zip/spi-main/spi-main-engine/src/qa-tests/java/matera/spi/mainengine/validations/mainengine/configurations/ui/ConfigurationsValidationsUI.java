package matera.spi.mainengine.validations.mainengine.configurations.ui;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.utils.Asserts;

import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;

public class ConfigurationsValidationsUI extends BaseAction {

    public void validatePSPConfigurations() throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, getStatusCode());
        Asserts.assertThat(getJsonValue("data.id"), Matchers.notNullValue());
        Asserts.assertThat(getJsonValue("data.ispb"), Matchers.notNullValue());
        Asserts.assertThat(getJsonValue("data.balanceValidationThreshold"), Matchers.notNullValue());
        Asserts.assertThat(getJsonValue("data.pmtConfirmRetryAmount"), Matchers.notNullValue());
        Asserts.assertThat(getJsonValue("data.pmtConfirmRetryInterval"), Matchers.notNullValue());
        Asserts.assertThat(getJsonValue("data.receiveConfirmRetryInterval"), Matchers.notNullValue());
        Asserts.assertThat(getJsonValue("data.pmtConfirmRetryAmount"), Matchers.notNullValue());
        Asserts.assertThat(getJsonValue("data.customerDebTransactionType"), Matchers.notNullValue());

    }
}
