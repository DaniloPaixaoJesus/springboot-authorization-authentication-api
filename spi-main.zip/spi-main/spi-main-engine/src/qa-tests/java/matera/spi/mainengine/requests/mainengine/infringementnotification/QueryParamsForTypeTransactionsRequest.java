package matera.spi.mainengine.requests.mainengine.infringementnotification;

import matera.spi.mainengine.core.BaseAction;

import java.util.HashMap;
import java.util.Map;

public class QueryParamsForTypeTransactionsRequest extends BaseAction {

    public Map<String, String> setParamsEvent(String eventType, String pageSize, String pageNumber, String eventStatus) {

        Map<String, String> eventParam = new HashMap<>();
        eventParam.put("eventType", eventType);
        eventParam.put("pageSize", pageSize);
        eventParam.put("pageNumber", pageNumber);
        eventParam.put("eventStatus", eventStatus);
        return eventParam;
    }

    public Map<String, String> setParamsEventFilterForBranch(String branch, String eventType, String pageSize, String pageNumber, String eventStatus) {

        Map<String, String> eventParam = new HashMap<>();
        eventParam.put("branch", branch);
        eventParam.put("eventType", eventType);
        eventParam.put("pageSize", pageSize);
        eventParam.put("pageNumber", pageNumber);
        eventParam.put("eventStatus", eventStatus);
        return eventParam;
    }

    public Map<String, String> setParamsEventFilterForAccountNumber(String accountNumber, String eventType, String pageSize, String pageNumber, String eventStatus) {

        Map<String, String> eventParam = new HashMap<>();
        eventParam.put("accountNumber", accountNumber);
        eventParam.put("eventType", eventType);
        eventParam.put("pageSize", pageSize);
        eventParam.put("pageNumber", pageNumber);
        eventParam.put("eventStatus", eventStatus);
        return eventParam;
    }

    public Map<String, String> setParamsEventFilterForBranchAndAccountNumber(String branch, String accountNumber, String eventType, String pageSize, String pageNumber, String eventStatus) {

        Map<String, String> eventParam = new HashMap<>();
        eventParam.put("branch", branch);
        eventParam.put("accountNumber", accountNumber);
        eventParam.put("eventType", eventType);
        eventParam.put("pageSize", pageSize);
        eventParam.put("pageNumber", pageNumber);
        eventParam.put("eventStatus", eventStatus);
        return eventParam;
    }

}
