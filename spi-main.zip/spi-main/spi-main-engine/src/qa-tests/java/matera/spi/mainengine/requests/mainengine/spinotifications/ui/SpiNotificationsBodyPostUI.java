package matera.spi.mainengine.requests.mainengine.spinotifications.ui;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.model.mainengine.receivers.ui.IncomingMessageDetail;
import matera.spi.mainengine.model.mainengine.spinotifications.ui.SpiNotificationsModelUI;
import matera.spi.mainengine.utils.DocumentConverterUtil;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import static matera.spi.mainengine.utils.FakerUtils.fakerEmail;
import static matera.spi.mainengine.utils.FakerUtils.fakerIdentification;

public class SpiNotificationsBodyPostUI extends BaseAction {

    public static final String VALID_IDENTIFICATION = fakerIdentification();
    public static final String VALID_EMAIL = fakerEmail();
    public static final String INVALID_EMAIL = "teste-email-invalido.com.br";
    public static final String IDENTIFICATION_TO_SEND_NOTIFICATION = "QA Homologação";
    public static final String EMAIL_ADDRESS_TO_SEND_NOTIFICATION = "qa-mip@matera.com";
    public static final String ISPB = "13370835";
    public static final String NOTIFICATION_MSG_ID = "M005737687cd679d901c941d0aad8j8w";
    public static final String ADMI004 = "src/qa-tests/resources/xml/mainengine/admi-004-example.xml";

    IncomingMessageDetail incomingMessageDetail = new IncomingMessageDetail();

    public SpiNotificationsModelUI validSpiAddEmailRegisterBody(){
        SpiNotificationsModelUI spiNotificationsModelUI = new SpiNotificationsModelUI();
        spiNotificationsModelUI.setIdentification(VALID_IDENTIFICATION);
        spiNotificationsModelUI.setEmail(VALID_EMAIL);
        return spiNotificationsModelUI;
    }

    public SpiNotificationsModelUI validSpiEmailNotificationsBody(){
        SpiNotificationsModelUI spiNotificationsModelUI = new SpiNotificationsModelUI();
        spiNotificationsModelUI.setIdentification(IDENTIFICATION_TO_SEND_NOTIFICATION);
        spiNotificationsModelUI.setEmail(EMAIL_ADDRESS_TO_SEND_NOTIFICATION);
        return spiNotificationsModelUI;
    }

    public String receiveValidADMI004(){
        String admi004 = parseFileToXMLStringFormat();
        incomingMessageDetail.setXml(admi004);
        return admi004;
    }

    public String parseFileToXMLStringFormat(){
        String xmlADMI004 = DocumentConverterUtil.convertFileToString(ADMI004);
        return xmlADMI004;
    }


    public Map<String, String> setParamsEventStatus(String correlationID) {

        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");

        Map<String, String> eventParam = new HashMap<>();
        eventParam.put("startTimestampUtc", LocalDateTime.now().minusDays(1).format(dateTimeFormatter));
        eventParam.put("endTimestampUtc", LocalDateTime.now().plusDays(1).format(dateTimeFormatter));
        eventParam.put("correlationId", correlationID);
        return eventParam;
    }
}
