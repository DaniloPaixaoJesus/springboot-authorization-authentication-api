package matera.spi.mainengine.validations.mainengine.participants;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.utils.Asserts;

import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;

public class UpdateParticipantsValidations extends BaseAction {

    public void validParticipantsResponse(String participantIdentification,
                                          String participantName,
                                          int statusCodeCAMT014) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodeCAMT014);
        Asserts.assertThat(participantIdentification, Matchers.is("394460"));
        Asserts.assertThat(participantName, Matchers.is("STN"));
    }

    public void NullParticipantsResponse(String participantIdentification,
                                         String participantName,
                                         int statusCodeCAMT014) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodeCAMT014);
        Asserts.assertThat(participantIdentification, Matchers.nullValue());
        Asserts.assertThat(participantName, Matchers.nullValue());
    }
}



