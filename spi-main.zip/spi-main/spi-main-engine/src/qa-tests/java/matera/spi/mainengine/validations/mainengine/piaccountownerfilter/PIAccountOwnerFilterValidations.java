package matera.spi.mainengine.validations.mainengine.piaccountownerfilter;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.utils.Asserts;

import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;

public class PIAccountOwnerFilterValidations extends BaseAction {

    public void InvalidPIAccountOwnerFilterResponse(String errorCode, String message) throws Exception {
        switch (getStatusCode()) {
            case 400:
                Asserts.assertEquals(HttpStatus.SC_BAD_REQUEST, getStatusCode());
                Asserts.assertThat(getJsonValue("error[0].code"), Matchers.equalTo(errorCode));
                Asserts.assertThat(getJsonValue("error[0].message"), Matchers.equalTo(message));
                break;
            case 500:
                Asserts.assertEquals(HttpStatus.SC_INTERNAL_SERVER_ERROR, getStatusCode());
                Asserts.assertThat(getJsonValue("error[0].code"), Matchers.equalTo(errorCode));
                Asserts.assertThat(getJsonValue("error[0].message"), Matchers.equalTo(message));
                break;
            default:
                break;
        }
    }

}
