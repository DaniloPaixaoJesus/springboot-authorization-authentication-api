package matera.spi.mainengine.requests.mainengine.participants;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.model.mainengine.participants.ValidGetParticipants;

public class GetParticipants extends BaseAction {

    public static final String VALID_ISPB = "13370835";
    public static final String VALID_NAME = "BPP IP S.A.";

    public ValidGetParticipants validGetParticipants() {
        ValidGetParticipants validGetParticipants = new ValidGetParticipants();
        validGetParticipants.setIspb(VALID_ISPB);
        validGetParticipants.setName(VALID_NAME);

        return validGetParticipants;
    }

}
