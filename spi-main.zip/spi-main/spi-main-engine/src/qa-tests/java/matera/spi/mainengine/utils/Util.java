package matera.spi.mainengine.utils;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

public class Util {

    private static final SimpleDateFormat aFormat = new SimpleDateFormat("yyyy-MM-dd");
    private static final SimpleDateFormat hFormat = new SimpleDateFormat("HHmmss");


    /**
     * Método para renomear os arquivos de relatório gerado pelo plugin do json.
     */
    public static void renomearJsonReport() {
        String fileDate = hFormat.format(Calendar.getInstance().getTime());
        File jsonReport = new File("target/jsonReport/CucumberTestReport.json");
        File jsonReportRenamed = new File("target/jsonReport/CucumberTestReport_".concat(fileDate).concat(".json"));

        if (jsonReport.exists() && jsonReport.length() != 0) {
            try {
                FileUtils.copyFile(jsonReport, jsonReportRenamed);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Método para criar a estrutura de pastas das evidências, movendo o conteudo da pasta cucumber_reports.
     */
    public static void gerarEvidencia() {
        String folderDate = aFormat.format(Calendar.getInstance().getTime());
        String fileDate = hFormat.format(Calendar.getInstance().getTime());
        String diretorio;

        diretorio = System.getProperty("user.home").concat("/") + "Evidencias".concat("/") + fileDate.concat("/");
        File dir = new File(diretorio);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        File cucumberReportsDir = new File("cucumber-html-reports");
        File[] files = cucumberReportsDir.listFiles();
        for (File file : files) {
            try {
                if (file.isDirectory()) {
                    FileUtils.moveDirectoryToDirectory(file, dir, false);
                } else {
                    FileUtils.moveFileToDirectory(file, dir, false);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Método para validar se um valor é igual ao outro.
     *
     * @param esperado parâmetro esperado é o valor a ser comparado com o retornado
     * @param atual    parâmetro atual é o valor a ser comparado com o esperado
     */
    public static void assertEquals(String esperado, String atual) {
        try {
            Assert.assertEquals(esperado.trim(), atual.trim());
        } catch (Exception e) {
            assertFail("Esperado [" + esperado + "], mas retornou [" + atual + "]");
        }
    }

    /**
     * Método para validar se um valor é igual ao outro.
     *
     * @param esperado parâmetro esperado é o valor a ser comparado com o retornado
     * @param atual    parâmetro atual é o valor a ser comparado com o esperado
     */
    public static void assertEqualsComMenssagem(String atual, String esperado, String valorColuna) {
        try {
            Assert.assertEquals(esperado.trim(), atual.trim());
        } catch (Exception e) {
            assertFail("Na Coluna [" + valorColuna + "] era Esperado [" + esperado + "], mas retornou [" + atual + "]");
        }
    }

    /**
     * Método para validar se um valor é igual ao outro.
     *
     * @param esperado parâmetro esperado é o valor a ser comparado com o retornado
     * @param atual    parâmetro atual é o valor a ser comparado com o esperado
     */
    public static void assertEquals(int esperado, int atual) {
        try {
            Assert.assertEquals(esperado, atual);
        } catch (Exception e) {
            assertFail("Esperado [" + esperado + "], mas retornou [" + atual + "]");
        }
    }

    /**
     * Método para validar se um valor é igual ao outro.
     *
     * @param coluna   coluna a ser validada
     * @param esperado parâmetro esperado é o valor a ser comparado com o retornado
     * @param atual    parâmetro atual é o valor a ser comparado com o esperado
     */
    public static void assertEquals(String coluna, String esperado, String atual) {
        try {
            Assert.assertEquals(esperado.trim(), atual.trim());
        } catch (Exception e) {
            assertFail("Coluna : [" + coluna + "] Esperado [" + esperado + "], mas retornou [" + atual + "]");
        }
    }

    /**
     * Método para validar se um valor é diferente ao outro.
     *
     * @param coluna   coluna a ser validada
     * @param esperado parâmetro esperado é o valor a ser comparado com o retornado
     * @param atual    parâmetro atual é o valor a ser comparado com o esperado
     */
    public static void assertEqualsFail(String coluna, String esperado, String atual) {
        try {
            Assert.assertFalse("", esperado.trim().contains(atual.trim()));
        } catch (Exception e) {
            assertFail("Coluna : [" + coluna + "] Esperado [" + esperado + "], mas retornou [" + atual + "]");
        }
    }

    public static void assertFail(String message) {
        Assert.fail(message);
    }

    /**
     * Método para formatar uma data no formato YYYY-MM-DD HH-MM-SS para YYYY-MM-DDTHH-MM-SSZ
     *
     * @param data data a ser formatada
     * @return retorna a data formatada
     */
    public static String formatarData(String data) {
        if (data.equals("")) {
            return "";
        } else {
            return data.substring(0, 10) + "T" + data.substring(11, data.length()) + "00Z";
        }
    }

    public static String formatarDataTimeZone(String data) {
        if (data.equals("")) {
            return "";
        } else {
            return data.substring(0, 10) + "T" + data.substring(11, data.length()) + "Z";
        }
    }

    public static String formatarDataEHora(String data) {
        if (data.equals("")) {
            return "";
        } else {
            return data.substring(0, 10) + "T" + data.substring(11, 19);
        }
    }

    /**
     * Método para capturar a data atual e transformar no formato - yyyy-MM-dd HH:mm:ss.
     *
     * @return retorna a data atual
     */
    public static String getDataAtual() {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date(System.currentTimeMillis());
        return formatter.format(date);
    }

    /**
     * Método para capturar a data atual e transformar no formato - yyyy-MM-ddTHH:mm:ssZ.
     *
     * @return retorna a data atual
     */
    public static String getDataAtualFormatoTZ() {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date(System.currentTimeMillis());
        String data = formatter.format(date);
        return data.substring(0, 10) + "T" + data.substring(11, Math.round(data.length()));
    }

    public static LocalDateTime getUtcLocalDateTime(){
        return LocalDateTime.now(ZoneOffset.UTC);
    }

    public static LocalDate getTodayUTC() {
        return LocalDate.now(ZoneId.of("UTC"));
    }

    public static String conversorMonetario(String valor) {
        try {
            if (!valor.equals("")) {
                if (valor.contains(",")) {
                    valor = valor.replaceAll(",", ".");
                }
                String valorAntesPonto = valor.substring(0, valor.indexOf("."));
                String valorDepoisPonto = valor.substring(valor.indexOf("."), valor.length());
                String valorDuasCasasDepoisPonto = valor.substring(valor.indexOf("."), valor.indexOf(".") + 3);

                if (valor.endsWith("00")) {
                    valor = valorAntesPonto + valorDuasCasasDepoisPonto;
                } else {
                    valor = valorAntesPonto + valorDepoisPonto;
                }
                if (valor.endsWith("0")) {
                    valor = valorAntesPonto + valorDuasCasasDepoisPonto.substring(0, 2);
                }
            }
        } catch (Exception e) {
            assertFail("Erro na conversão do valor [" + valor + "]" + "\n" + "Exception: " + e);
        }
        return valor;
    }

    /**
     * Método para arredondar um valor para no maximo duas casas decimais.
     *
     * @param valor valor a ser arredondado
     * @return retorna o valor arredondado
     */
    public static String arredondarValor(double valor) {
        DecimalFormat df = new DecimalFormat("#0.00");
        return df.format(valor).replaceAll(",", ".");
    }

    public static String conversorCasaDouble(String valor) {
        if (valor != null) {
            DecimalFormat df = new DecimalFormat("#0.0");
            return df.format(Double.parseDouble(valor)).replaceAll(",", ".");
        } else return "";
    }

    public static String gerarFormatoGMT() {
        LocalDateTime agora = LocalDateTime.now();
        return agora.toString();
    }

	public static String gerarStringRandomica(int tamanho, String letras) {
		Random random = new Random();
		StringBuilder saida = new StringBuilder();
		for (int i = 0; i < tamanho; i++) {
			saida.append(letras.charAt(random.nextInt(letras.length())));
		}
		return saida.toString();
	}

    public static String gerarValorUnico(String valor) {
        double valorDouble = Double.parseDouble(valor);
        DecimalFormat df = new DecimalFormat("##.#");
        String newValor = df.format(valorDouble);
        return newValor.replaceAll(",", ".");
    }

    public static String dateFormat(String date) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-mm-dd");
        String data = null;
        try {
            format.format(format.parse(date));
            data = format.format(format.parse(date));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return data;
    }
    public static String getValorDoubleRandom(double min, double max) {
        return arredondarValor((Math.random() * ((max - min) + 1)) + min);
    }

    public static String formatarHora(String hora) {
        return hora.substring(0, 8);
    }

//    public static String formataDados(String dado){
//        dado = dado.replaceAll("\n.","");
//        dado = dado.replaceAll("\r", "");
//        return dado;
//    }
}




