package matera.spi.mainengine.validations.mainengine.spinotifications.ui;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.requests.mainengine.spinotifications.ui.SpiNotificationsBodyPostUI;
import matera.spi.mainengine.utils.Asserts;

import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;

import static matera.spi.mainengine.utils.Util.assertEquals;

public class SpiNotificationsValidationsUI extends BaseAction {

    public void eventNotificationSendedResponse(int statusCodeNotificationSended,
                                                String endToEndId,
                                                String notificationEndToEndId,
                                                String notificationTypeDescription,
                                                String notificationStatusCode,
                                                String notificationStatusDescription) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodeNotificationSended);
        Asserts.assertThat(endToEndId, Matchers.is(notificationEndToEndId));
        Asserts.assertThat(notificationTypeDescription, Matchers.is("Notification"));
        Asserts.assertThat(notificationStatusCode, Matchers.is("3"));
        Asserts.assertThat(notificationStatusDescription, Matchers.is("Success"));
    }

    public void validQueriedSpiNotificationsResponse(int statusCodeReceived,
                                                     String emailsList) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodeReceived);
        Asserts.assertThat(emailsList, Matchers.notNullValue());
        Asserts.assertThat(emailsList, Matchers.containsString("id"));
        Asserts.assertThat(emailsList, Matchers.containsString("identification"));
        Asserts.assertThat(emailsList, Matchers.containsString("email"));
        Asserts.assertThat(emailsList, Matchers.containsString("dateTimeRegister"));
    }

    public void validCreatedSpiNotificationsResponse(int statusCodeReceived, String createdEmailIdentification, String createdEmailAddress) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_CREATED, statusCodeReceived);
        Asserts.assertEquals(createdEmailIdentification, SpiNotificationsBodyPostUI.VALID_IDENTIFICATION);
        Asserts.assertEquals(createdEmailAddress, SpiNotificationsBodyPostUI.VALID_EMAIL);
    }

    public void validUpdatedSpiNotificationsResponse(int statusCodeReceived, String updatedEmailIdentification, String updatedEmailAddress) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodeReceived);
        Asserts.assertNotEquals(updatedEmailIdentification, SpiNotificationsBodyPostUI.VALID_IDENTIFICATION);
        Asserts.assertNotEquals(updatedEmailAddress, SpiNotificationsBodyPostUI.VALID_EMAIL);
    }

    public void validDeletedSpiNotificationsByIdResponse(int statusCodeReceived) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_NO_CONTENT, statusCodeReceived);
    }

    public void validQueriedSpiNotificationsByIdResponse(int statusCodeReceived,
                                                         String id,
                                                         String identification,
                                                         String identificationName,
                                                         String email,
                                                         String emailAddress,
                                                         String dateTimeRegister,
                                                         String dateTimeRegisterCreation) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodeReceived);
        Asserts.assertNotNull("Validating email notification id:", id);
        Asserts.assertEquals(identification, identificationName);
        Asserts.assertEquals(email, emailAddress);
        Asserts.assertEquals(dateTimeRegister, dateTimeRegisterCreation);
    }

    public void invalidPACS004Response(String errorCode, String message) throws Exception {
        switch (getStatusCode()) {
            case 400:
                Asserts.assertEquals(HttpStatus.SC_BAD_REQUEST, getStatusCode());
                Asserts.assertThat(getJsonValue("error[0].code"), Matchers.equalTo(errorCode));
                Asserts.assertThat(getJsonValue("error[0].message"), Matchers.equalTo(message));
                break;
            case 500:
                assertEquals(HttpStatus.SC_INTERNAL_SERVER_ERROR, getStatusCode());
                Asserts.assertThat(getJsonValue("error[0].code"), Matchers.equalTo(errorCode));
                Asserts.assertThat(getJsonValue("error[0].message"), Matchers.equalTo(message));
                break;
            default:
                break;
        }
    }

    public void validateDuplicatedRegister(int statusCodeReceived, String errorCode, String errorCodeResponse, String errorMessage, String errorMessageResponse) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_BAD_REQUEST, statusCodeReceived);
        Asserts.assertEquals(errorCode, errorCodeResponse );
        Asserts.assertEquals(errorMessage, errorMessageResponse);
    }
}
