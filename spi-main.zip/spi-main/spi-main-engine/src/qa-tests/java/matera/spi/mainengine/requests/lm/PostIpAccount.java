package matera.spi.mainengine.requests.lm;

import matera.spi.mainengine.core.BaseAction;

import java.util.ArrayList;
import java.util.Map;

public class PostIpAccount extends BaseAction {
    public Map<String, Object> postJsonIpAccount()

    {
        bodyJsonMap.put("value", "1000000.58");
        bodyJsonMap.put("ignoreThresholdViolation", "true");

        ArrayList<Map<String, String>> jsonIpAccount = new ArrayList<>();
        //jsonIpAccount.add("value", "1000000.58");

        return bodyJsonMap;
    }


}
