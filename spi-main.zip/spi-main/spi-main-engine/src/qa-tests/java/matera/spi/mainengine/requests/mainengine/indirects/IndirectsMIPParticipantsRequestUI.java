package matera.spi.mainengine.requests.mainengine.indirects;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.model.mainengine.indirects.Contact;
import matera.spi.mainengine.model.mainengine.indirects.Financial;
import matera.spi.mainengine.model.mainengine.indirects.IndirectsMIPParticipantsModelUI;
import matera.spi.mainengine.utils.FakerUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class IndirectsMIPParticipantsRequestUI extends BaseAction {

    public static final String VALID_INDIRECT_NAME =  FakerUtils.fakerCompanyName();
    public static final String VALID_INDIRECT_CORPORATE_NAME = "Indirect PSP LTDA";
    public static final String VALID_INDIRECT_TAX_ID = "79567666000186";
    public static final int VALID_INDIRECT_ISPB = FakerUtils.fakerNumber();
    public static final String VALID_INDIRECT_STATUS = "ACTIVE";
    public static final String VALID_INDIRECT_CONTRACT_INIT_DATE = "2020-12-31";
    public static final String VALID_INDIRECT_CONTRACT_END_DATE = "2022-01-01";
    public static final String VALID_INDIRECT_BRANCH = "1";
    public static final String VALID_INDIRECT_ACCOUNT_NUMBER = "1231313";
    public static final Boolean VALID_BALANCE_VALIDATION_THRESHOLD = true;
    public static final String VALID_BALANCE_LOWER_THRESHOLD = "10000";
    public static final String VALID_DEBIT_TRANSACTION_TYPE = "10";
    public static final String VALID_CRED_TRANSACTION_TYPE = "11";
    public static final String VALID_QRCODE_CRED_TRANSACTION_TYPE = "20";
    public static final String VALID_DRAWBACK_RECEIVE_TRANSACT_TYPE = "30";
    public static final String VALID_DRAWBACK_SENT_TRANSAC_TYPE = "31";
    public static final String VALID_CONTACT_NAME = "John";
    public static final String VALID_CONTACT_DEPARTMENT = "Financial";
    public static final String VALID_CONTACT_EMAIL = "john@psp.com";
    public static final String VALID_CONTACT_PHONE = "+551132331111";

    public IndirectsMIPParticipantsModelUI validAddIndirectsMIPParticipantsBody() {

        Contact contact = new Contact();
        contact.setName(VALID_CONTACT_NAME);
        contact.setDepartment(VALID_CONTACT_DEPARTMENT);
        contact.setEmail(VALID_CONTACT_EMAIL);
        contact.setPhone(VALID_CONTACT_PHONE);

        Financial financial = new Financial();
        financial.setBalanceValidationThreshold(VALID_BALANCE_VALIDATION_THRESHOLD);
        financial.setBalanceLowerThreshold(VALID_BALANCE_LOWER_THRESHOLD);
        financial.setCredTransactionType(VALID_CRED_TRANSACTION_TYPE);
        financial.setDebitTransactionType(VALID_DEBIT_TRANSACTION_TYPE);
        financial.setQrcodeCredTransactionType(VALID_QRCODE_CRED_TRANSACTION_TYPE);
        financial.setDrawbackReceiveTransactType(VALID_DRAWBACK_RECEIVE_TRANSACT_TYPE);
        financial.setDrawbackSentTransactType(VALID_DRAWBACK_SENT_TRANSAC_TYPE);

        IndirectsMIPParticipantsModelUI indirectsMIPParticipantsModelUI = new IndirectsMIPParticipantsModelUI();
        indirectsMIPParticipantsModelUI.setName(VALID_INDIRECT_NAME);
        indirectsMIPParticipantsModelUI.setCorporateName(VALID_INDIRECT_CORPORATE_NAME);
        indirectsMIPParticipantsModelUI.setTaxId(VALID_INDIRECT_TAX_ID);
        indirectsMIPParticipantsModelUI.setIspb(VALID_INDIRECT_ISPB);
        indirectsMIPParticipantsModelUI.setStatus(VALID_INDIRECT_STATUS);
        indirectsMIPParticipantsModelUI.setContractInitDate(VALID_INDIRECT_CONTRACT_INIT_DATE);
        indirectsMIPParticipantsModelUI.setContractEndDate(VALID_INDIRECT_CONTRACT_END_DATE);
        indirectsMIPParticipantsModelUI.setBranch(VALID_INDIRECT_BRANCH);
        indirectsMIPParticipantsModelUI.setAccountNumber(VALID_INDIRECT_ACCOUNT_NUMBER);
        indirectsMIPParticipantsModelUI.setFinancial(financial);

        List<Contact> contactList = new ArrayList<>();
        contactList.add(contact);
        indirectsMIPParticipantsModelUI.setContacts(contactList);

        return indirectsMIPParticipantsModelUI;
    }

    public Map<String, String> setParamsEvent(String pageSize, String pageNumber) {

        Map<String, String> eventParam = new HashMap<>();
        eventParam.put("pageSize", pageSize);
        eventParam.put("pageNumber", pageNumber);
        return eventParam;
    }
}
