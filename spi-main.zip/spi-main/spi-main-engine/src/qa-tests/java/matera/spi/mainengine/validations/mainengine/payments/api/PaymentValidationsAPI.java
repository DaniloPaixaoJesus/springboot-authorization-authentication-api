package matera.spi.mainengine.validations.mainengine.payments.api;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.requests.mainengine.payments.api.PACS008BodyPostSendedAPI;
import matera.spi.mainengine.utils.Asserts;
import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;

public class PaymentValidationsAPI extends BaseAction {

    public void validSuccessPACS008Response() throws Exception {
        Asserts.assertEquals(HttpStatus.SC_ACCEPTED, getStatusCode());
        Asserts.assertEquals("Validating receiverInstitutionISPB:", getJsonValue("data.receiver.receiverInstitutionISPB"), PACS008BodyPostSendedAPI.VALID_RECEIVER_INSTITUTION_ISPB);
        Asserts.assertEquals("Validating receiverTaxId:", getJsonValue("data.receiver.receiverTaxId"), PACS008BodyPostSendedAPI.VALID_RECEIVER_TAX_ID);
        Asserts.assertThat(getJsonValue("data.InstantPayments.endToEndIdQuery"), Matchers.notNullValue());
        Asserts.assertEquals("Validating account branch receiver:", getJsonValue("data.receiver.account.branch"), PACS008BodyPostSendedAPI.VALID_RECEIVER_BRANCH);
        Asserts.assertEquals("Validating account number receiver:", getJsonValue("data.receiver.account.accountNumber"), PACS008BodyPostSendedAPI.VALID_RECEIVER_ACCOUNT_NUMBER);
        Asserts.assertEquals("Validating account type receiver:", getJsonValue("data.receiver.account.accountType"), PACS008BodyPostSendedAPI.VALID_RECEIVER_ACCOUNT_TYPE);
        Asserts.assertEquals("Validating payment value:", getJsonValue("data.value"), PACS008BodyPostSendedAPI.VALID_VALUE);
        Asserts.assertEquals("Validating payment additional information:", getJsonValue("data.additionalInformation"), PACS008BodyPostSendedAPI.VALID_SUCCESS_ADDITIONAL_INFORMATION);
        Asserts.assertEquals("Validating payment demands immediate return:", getJsonValue("data.demandsImmediateReturn"), PACS008BodyPostSendedAPI.VALID_DEMANDS_IMMEDIATE_RETURN.toString());
        Asserts.assertEquals("Validating payment historic complement:", getJsonValue("data.historicComplement"), PACS008BodyPostSendedAPI.VALID_HISTORIC_COMPLEMENT);
        Asserts.assertEquals("Validating account branch payer:", getJsonValue("data.payer.account.branch"), PACS008BodyPostSendedAPI.VALID_PAYER_BRANCH);
        Asserts.assertEquals("Validating account number payer:", getJsonValue("data.payer.account.accountNumber"), PACS008BodyPostSendedAPI.VALID_PAYER_ACCOUNT_NUMBER);
        Asserts.assertEquals("Validating check customer account balance:", getJsonValue("data.payer.checkCustomerAccountBalance"), PACS008BodyPostSendedAPI.VALID_CHECK_CUSTOMER_ACCOUNT_BALANCE.toString());
        Asserts.assertEquals("Validating name of payer:", getJsonValue("data.payer.name"), PACS008BodyPostSendedAPI.VALID_PAYER_NAME);
        Asserts.assertThat(getJsonValue("data.instantPaymentId"), Matchers.notNullValue());
        Asserts.assertThat(getJsonValue("data.eventStatus.code"), Matchers.notNullValue());
        Asserts.assertThat(getJsonValue("data.eventStatus.description"), Matchers.notNullValue());
        Asserts.assertThat(getJsonValue("data.endToEndId"), Matchers.notNullValue());
    }

    public void validRejectPACS008Response() throws Exception {
        Asserts.assertEquals(HttpStatus.SC_ACCEPTED, getStatusCode());
        Asserts.assertEquals("Validating receiverInstitutionISPB:", getJsonValue("data.receiver.receiverInstitutionISPB"), PACS008BodyPostSendedAPI.VALID_RECEIVER_INSTITUTION_ISPB);
        Asserts.assertEquals("Validating receiverTaxId:", getJsonValue("data.receiver.receiverTaxId"), PACS008BodyPostSendedAPI.VALID_RECEIVER_TAX_ID);
        Asserts.assertThat(getJsonValue("data.InstantPayments.endToEndIdQuery"), Matchers.notNullValue());
        Asserts.assertEquals("Validating account branch receiver:", getJsonValue("data.receiver.account.branch"), PACS008BodyPostSendedAPI.VALID_RECEIVER_BRANCH);
        Asserts.assertEquals("Validating account number receiver:", getJsonValue("data.receiver.account.accountNumber"), PACS008BodyPostSendedAPI.VALID_RECEIVER_ACCOUNT_NUMBER);
        Asserts.assertEquals("Validating account type receiver:", getJsonValue("data.receiver.account.accountType"), PACS008BodyPostSendedAPI.VALID_RECEIVER_ACCOUNT_TYPE);
        Asserts.assertEquals("Validating payment value:", getJsonValue("data.value"), PACS008BodyPostSendedAPI.VALID_VALUE);
        Asserts.assertEquals("Validating payment additional information:", getJsonValue("data.additionalInformation"), PACS008BodyPostSendedAPI.VALID_REJECT_ADDITIONAL_INFORMATION);
        Asserts.assertEquals("Validating payment demands immediate return:", getJsonValue("data.demandsImmediateReturn"), PACS008BodyPostSendedAPI.VALID_DEMANDS_IMMEDIATE_RETURN.toString());
        Asserts.assertEquals("Validating payment historic complement:", getJsonValue("data.historicComplement"), PACS008BodyPostSendedAPI.VALID_HISTORIC_COMPLEMENT);
        Asserts.assertEquals("Validating account branch payer:", getJsonValue("data.payer.account.branch"), PACS008BodyPostSendedAPI.VALID_PAYER_BRANCH);
        Asserts.assertEquals("Validating account number payer:", getJsonValue("data.payer.account.accountNumber"), PACS008BodyPostSendedAPI.VALID_PAYER_ACCOUNT_NUMBER);
        Asserts.assertEquals("Validating check customer account balance:", getJsonValue("data.payer.checkCustomerAccountBalance"), PACS008BodyPostSendedAPI.VALID_CHECK_CUSTOMER_ACCOUNT_BALANCE.toString());
        Asserts.assertEquals("Validating name of payer:", getJsonValue("data.payer.name"), PACS008BodyPostSendedAPI.VALID_PAYER_NAME);
        Asserts.assertThat(getJsonValue("data.instantPaymentId"), Matchers.notNullValue());
        Asserts.assertThat(getJsonValue("data.eventStatus.code"), Matchers.notNullValue());
        Asserts.assertThat(getJsonValue("data.eventStatus.description"), Matchers.notNullValue());
        Asserts.assertThat(getJsonValue("data.endToEndId"), Matchers.notNullValue());
    }

    public void validErrorPACS008Response() throws Exception {
        Asserts.assertEquals(HttpStatus.SC_ACCEPTED, getStatusCode());
        Asserts.assertEquals("Validating receiverInstitutionISPB:", getJsonValue("data.receiver.receiverInstitutionISPB"), PACS008BodyPostSendedAPI.VALID_RECEIVER_INSTITUTION_ISPB);
        Asserts.assertEquals("Validating receiverTaxId:", getJsonValue("data.receiver.receiverTaxId"), PACS008BodyPostSendedAPI.VALID_RECEIVER_TAX_ID);
        Asserts.assertThat(getJsonValue("data.InstantPayments.endToEndIdQuery"), Matchers.notNullValue());
        Asserts.assertEquals("Validating account branch receiver:", getJsonValue("data.receiver.account.branch"), PACS008BodyPostSendedAPI.VALID_RECEIVER_BRANCH);
        Asserts.assertEquals("Validating account number receiver:", getJsonValue("data.receiver.account.accountNumber"), PACS008BodyPostSendedAPI.VALID_RECEIVER_ACCOUNT_NUMBER);
        Asserts.assertEquals("Validating account type receiver:", getJsonValue("data.receiver.account.accountType"), PACS008BodyPostSendedAPI.VALID_RECEIVER_ACCOUNT_TYPE);
        Asserts.assertEquals("Validating payment value:", getJsonValue("data.value"), PACS008BodyPostSendedAPI.VALID_VALUE);
        Asserts.assertEquals("Validating payment additional information:", getJsonValue("data.additionalInformation"), PACS008BodyPostSendedAPI.VALID_ERROR_ADDITIONAL_INFORMATION);
        Asserts.assertEquals("Validating payment demands immediate return:", getJsonValue("data.demandsImmediateReturn"), PACS008BodyPostSendedAPI.VALID_DEMANDS_IMMEDIATE_RETURN.toString());
        Asserts.assertEquals("Validating payment historic complement:", getJsonValue("data.historicComplement"), PACS008BodyPostSendedAPI.VALID_HISTORIC_COMPLEMENT);
        Asserts.assertEquals("Validating account branch payer:", getJsonValue("data.payer.account.branch"), PACS008BodyPostSendedAPI.VALID_PAYER_BRANCH);
        Asserts.assertEquals("Validating account number payer:", getJsonValue("data.payer.account.accountNumber"), PACS008BodyPostSendedAPI.VALID_PAYER_ACCOUNT_NUMBER);
        Asserts.assertEquals("Validating check customer account balance:", getJsonValue("data.payer.checkCustomerAccountBalance"), PACS008BodyPostSendedAPI.VALID_CHECK_CUSTOMER_ACCOUNT_BALANCE.toString());
        Asserts.assertEquals("Validating name of payer:", getJsonValue("data.payer.name"), PACS008BodyPostSendedAPI.VALID_PAYER_NAME);
        Asserts.assertThat(getJsonValue("data.instantPaymentId"), Matchers.notNullValue());
        Asserts.assertThat(getJsonValue("data.eventStatus.code"), Matchers.notNullValue());
        Asserts.assertThat(getJsonValue("data.eventStatus.description"), Matchers.notNullValue());
        Asserts.assertThat(getJsonValue("data.endToEndId"), Matchers.notNullValue());
    }

    public void invalidPACS008Response(String errorCode, String message) throws Exception {
        switch (getStatusCode()) {
            case 400:
                Asserts.assertEquals(HttpStatus.SC_BAD_REQUEST, getStatusCode());
                Asserts.assertThat(getJsonValue("error[0].code"), Matchers.equalTo(errorCode));
                Asserts.assertThat(getJsonValue("error[0].message"), Matchers.equalTo(message));
                break;
            case 500:
                Asserts.assertEquals(HttpStatus.SC_INTERNAL_SERVER_ERROR, getStatusCode());
                Asserts.assertThat(getJsonValue("error[0].code"), Matchers.equalTo(errorCode));
                Asserts.assertThat(getJsonValue("error[0].message"), Matchers.equalTo(message));
                break;
            default:
                break;
        }
    }

    public void invalidAuthenticationResponse(String errorDescription, String message) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_UNAUTHORIZED, getStatusCode());
        Asserts.assertThat(getJsonValue("error"), Matchers.equalTo(errorDescription));
        Asserts.assertThat(getJsonValue("error_description"), Matchers.equalTo(message));
    }

    public void validPACS002Response(String correlationId) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, getStatusCode());
        Asserts.assertThat(getJsonValue("data.content[0].status.code"), Matchers.is("3"));
        Asserts.assertThat(getJsonValue("data.content[0].status.description"), Matchers.is("Success"));
        Asserts.assertThat(getJsonValue("data.content[0].endToEndId"), Matchers.is(correlationId));
    }

    public void rejectPACS002Response(String correlationId) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, getStatusCode());
        Asserts.assertThat(getJsonValue("data.content[0].status.code"), Matchers.is("22"));
        Asserts.assertThat(getJsonValue("data.content[0].status.description"), Matchers.is("Payment rejected"));
        Asserts.assertThat(getJsonValue("data.content[0].endToEndId"), Matchers.is(correlationId));
    }

    public void validateAdmi002ErrorPACS002Response(String correlationId) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, getStatusCode());
        Asserts.assertThat(getJsonValue("data.content[0].status.code"), Matchers.is("5"));
        Asserts.assertThat(getJsonValue("data.content[0].status.description"), Matchers.is("Error"));
        Asserts.assertThat(getJsonValue("data.content[0].endToEndId"), Matchers.is(correlationId));
    }

    public void validSameBranchAndAccountNumberPayerAndReceiver() throws Exception {
        Asserts.assertEquals(HttpStatus.SC_BAD_REQUEST, getStatusCode());
        Asserts.assertThat(getJsonValue("error[0].code"), Matchers.equalTo("SPI-ME-024"));
        Asserts.assertThat(getJsonValue("error[0].message"), Matchers.equalTo("The account number and branch from payer and receiver cannot be the same on an internal payment"));
    }
}



