package matera.spi.mainengine.validations.lm.events;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.utils.Asserts;

import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;

import static matera.spi.mainengine.stepdefinitions.lm.balanceajustments.BalanceAdjustmentFlow.balanceAfterAdjustment;
import static matera.spi.mainengine.stepdefinitions.lm.balanceajustments.BalanceAdjustmentFlow.balanceBeforeAdjustment;

public class EventsValidations extends BaseAction {

    public void validateEvents() throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, getStatusCode());
    }

    public void validateEventBalanceAdjustmentDetails(String eventId) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, getStatusCode());
        Asserts.assertThat(Matchers.comparesEqualTo(balanceBeforeAdjustment), Matchers.notNullValue());
        Asserts.assertThat(Matchers.comparesEqualTo(balanceAfterAdjustment), Matchers.notNullValue());
        Asserts.assertThat(getJsonValue("data.content[0].eventId"), Matchers.notNullValue());
        Asserts.assertThat(getJsonValue("data.content[0].eventId"), Matchers.is(eventId));
        Asserts.assertThat(getJsonValue("data.content[0].type.code"), Matchers.is("14"));
        Asserts.assertThat(getJsonValue("data.content[0].type.description"), Matchers.is("Ip Account Balance Adjustment"));
        Asserts.assertThat(getJsonValue("data.content[0].status.code"), Matchers.is("3"));
        Asserts.assertThat(getJsonValue("data.content[0].status.description"), Matchers.is("Success"));
        Asserts.assertThat(Matchers.comparesEqualTo(balanceBeforeAdjustment), Matchers.is(Matchers.not(balanceAfterAdjustment)));
    }

}
