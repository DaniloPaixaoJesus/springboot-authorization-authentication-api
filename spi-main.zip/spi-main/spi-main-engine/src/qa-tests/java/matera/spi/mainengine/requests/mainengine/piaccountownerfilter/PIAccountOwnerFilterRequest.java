package matera.spi.mainengine.requests.mainengine.piaccountownerfilter;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.model.mainengine.piaccountownerfilter.PIAccountOwnerFilterModel;
import matera.spi.mainengine.requests.mainengine.piaccountmanagement.REDA022BodyPost;

public class PIAccountOwnerFilterRequest extends BaseAction{

    public static final String VALID_DIRECTOR_NAME = REDA022BodyPost.VALID_DIRECTOR_NAME;
    public static final String VALID_PASS_PHRASE = "12345678";

    public PIAccountOwnerFilterModel validPIAccountOwnerFilter() {

        PIAccountOwnerFilterModel PIAccountOwnerFilterModel = new PIAccountOwnerFilterModel();
        PIAccountOwnerFilterModel.setDirectorName(VALID_DIRECTOR_NAME);
        PIAccountOwnerFilterModel.setPassPhrase(VALID_PASS_PHRASE);

        return PIAccountOwnerFilterModel;
    }

}
