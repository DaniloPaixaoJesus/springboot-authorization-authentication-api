package matera.spi.mainengine.utils;

import com.github.javafaker.Faker;
import com.github.javafaker.service.FakeValuesService;
import com.github.javafaker.service.RandomService;

import java.util.Locale;
import java.util.Random;

public class FakerUtils {

    public static int fakerNumber() {
        Faker faker = new Faker();
        int fakerNumber = faker.number().numberBetween(1,99999);
        return fakerNumber;
    }

    public static String fakerName() {
        Faker faker = new Faker();
        String name = faker.name().fullName();
        return name;
    }

    public static String fakerCompanyName() {
        Faker faker = new Faker();
        String company = faker.company().name();
        return company;
    }

    public static String fakerIdentification(){
        Faker register = new Faker();
        new Locale("pt_BR");
        String name = register.name().fullName();
        return name;
    }

    public static String fakerEmail(){
        FakeValuesService fakeValuesService = new FakeValuesService( new Locale("pt_BR"), new RandomService());
        String email = fakeValuesService.bothify("????##@gmail.com");
        return email;
    }

    public static String generateFakerCPF() {
        String partial = "";
        String cpf = "";
        Integer number;

        for (int i = 0; i < 9; i++) {
            number = new Integer((int) (Math.random() * 10));
        }

        Random random = new Random();
        long elevenDigits = (random.nextInt(1000000000) + (random.nextInt(90) + 10) * 1000000000L);
        cpf = String.valueOf(elevenDigits);

        return cpf;
    }
}
