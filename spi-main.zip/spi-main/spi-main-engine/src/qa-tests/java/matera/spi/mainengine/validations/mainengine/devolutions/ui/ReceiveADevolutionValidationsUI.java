package matera.spi.mainengine.validations.mainengine.devolutions.ui;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.utils.Asserts;
import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;

public class ReceiveADevolutionValidationsUI extends BaseAction {

    public void validatePACS004Response(String endToEndId,  String piResourceId, String xmlContent,  String messageType, String ispb, String correlationId, String compressed) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_CREATED, getStatusCode());
        Asserts.assertThat(piResourceId, Matchers.notNullValue());
        Asserts.assertThat(xmlContent, Matchers.notNullValue());
        Asserts.assertThat(piResourceId, Matchers.notNullValue());
        Asserts.assertThat(messageType, Matchers.is("PACS004"));
        Asserts.assertThat(xmlContent, Matchers.notNullValue());
        Asserts.assertThat(correlationId, Matchers.equalTo(endToEndId));
        Asserts.assertThat(ispb, Matchers.notNullValue());
        Asserts.assertThat(compressed, Matchers.notNullValue());
    }

    public void validateSuccessPACS002Response(String returnId) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, getStatusCode());
        Asserts.assertThat(getJsonValue("data.content[0].status.code"), Matchers.is("3"));
        Asserts.assertThat(getJsonValue("data.content[0].status.description"), Matchers.is("Success"));
        Asserts.assertThat(getJsonValue("data.content[0].endToEndId"), Matchers.is(returnId));
    }

    public void validateRejectPACS002Response(String returnId) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, getStatusCode());
        if(getJsonValue("data.content[0].status.code") == "28"){
            Asserts.assertThat(getJsonValue("data.content[0].status.description"), Matchers.is("Return rejected by Clearing"));
        }
        if(getJsonValue("data.content[0].status.code") == "31"){
            Asserts.assertThat(getJsonValue("data.content[0].status.description"), Matchers.is("Return rejection confirmed"));
        }
        Asserts.assertThat(getJsonValue("data.content[0].endToEndId"), Matchers.is(returnId));
    }

    public void validateAdmi002ErrorPACS002Response(String returnId) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, getStatusCode());
        Asserts.assertThat(getJsonValue("data.content[0].status.code"), Matchers.is("5"));
        Asserts.assertThat(getJsonValue("data.content[0].status.description"), Matchers.is("Error"));
        Asserts.assertThat(getJsonValue("data.content[0].endToEndId"), Matchers.is(returnId));
    }
}
