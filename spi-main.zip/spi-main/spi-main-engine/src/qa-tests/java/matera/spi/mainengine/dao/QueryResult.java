package matera.spi.mainengine.dao;

import java.util.HashMap;

public class QueryResult {

	 private HashMap<String,String> records;
	 private QueryResult next;

	 public QueryResult(){
		 this.records = new HashMap<String,String>();
		 this.next = null;
	 }

	 public String returnRecord(String record){
		 if(records.containsKey(record)) {
			 if(records.get(record) != null) {
				 return records.get(record);
			 }else {
				 return "";
			 }
		 } else {
			 return null;
		 }
	 }

	 public void insertRecords(String key, String value){
		 records.put(key, value);
	 }

	 public static QueryResult getNext(QueryResult queryResult){
		 return queryResult.next;
	 }

	public static boolean hasNext(QueryResult queryResult){
		return queryResult.next != null;
	}

	 public void setNext(QueryResult queryResult){
		 queryResult.next = queryResult;
	 }

	 public HashMap<String,String> returnRecordsMap(QueryResult queryResult){
		 return queryResult.records;
	 }

	 public void insertNext(QueryResult queryResult, QueryResult initial) {
			if (initial == null) {
				initial = queryResult;
			}else {
				QueryResult aux = initial.next;
				while (aux != null) {
					initial = aux;
					aux = aux.next;
				}
				initial.next = queryResult;
			}
		}

	 public static int getSize(QueryResult queryResult){
		 int a = 0;
		  while(queryResult != null){
			 if(queryResult.records.size() != 0) a++;
			 queryResult = queryResult.getNext(queryResult);
		 }
		 return a;
	 }
}
