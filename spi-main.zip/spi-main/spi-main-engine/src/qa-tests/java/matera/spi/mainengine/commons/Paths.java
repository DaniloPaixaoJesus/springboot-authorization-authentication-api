package matera.spi.mainengine.commons;

public class Paths {

    //KEYCLOAK
    public static final String PATH_TOKEN_PASSWORD = "/auth/realms/Matera/protocol/openid-connect/token";

    //MAIN ENGINE
    public static final String PATH_GENERATE_END_TO_END_ID_UI = "/ui/v1/instant-payments/end-to-end-id";
    public static final String PATH_POST_PAYMENTS_UI = "/ui/v1/instant-payments";
    public static final String PATH_POST_PAYMENTS_API = "/api/v1/settlements/instant-payments";
    public static final String PATH_PSP_CONFIGURATIONS_UI = "/ui/v1/configs";
    public static final String PATH_POST_SEND_DEVOLUTION_UI = "/ui/v1/settlement/return";
    public static final String PATH_POST_SEND_DEVOLUTION_API = "/api/v1/settlements/instant-payments/{instantPaymentId}/returns";
    public static final String PATH_SPI_NOTIFICATIONS = "/ui/v1/email/notification";
    public static final String PATH_SPI_NOTIFICATIONS_BY_ID = "/ui/v1/email/notification/{id}";
    public static final String PATH_POST_IP_ACCOUNT_OWNER = "/ui/v1/ip-account/owners";
    public static final String PATH_POST_IP_ACCOUNT_OWNER_FILTER = "/ui/v1/ip-account/owners/filter";
    public static final String PATH_GET_PARTICIPANT = "/api/v1/payment-service-providers";
    public static final String PATH_TRANSACTION_INQUIRY = "/api/v1/settlements";
    public static final String PATH_GET_IP_ACCOUNT = "/api/v1/ip-account";
    public static final String PATH_GET_INDIRECTS_LIST = "/ui/v1/indirect/";
    public static final String PATH_GET_INDIRECTS_BY_ID = "/ui/v1/indirect/{ispb}";
    public static final String PATH_POST_INDIRECTS = "/ui/v1/indirect";

    //LIQUIDITY MANAGER
    public static final String PATH_BALANCE_IP_ACCOUNT_UI = "/ui/v1/psp/balance/ip-account/mirror";
    public static final String PATH_IP_ACCOUNT_WITHDRAW_UI = "/ui/v1/ip-account/withdraw";
    public static final String PATH_IP_ACCOUNT_DEPOSIT_UI = "/ui/v1/ip-account/deposit";
    public static final String PATH_EVENTS_STATUSES_UI = "/ui/v1/events/statuses";
    public static final String PATH_EVENTS = "/ui/v1/events";
    public static final String PATH_BALANCE_QUERIES_UI = "/ui/v1/ip-account/balance/queries";
    public static final String PATH_EVENTS_UUID_XML_CONTENT_UI = "/ui/v1/events/{eventUuid}/xml-content";
    public static final String PATH_QUERIES_UI = "/ui/v1/ip-account/balance/queries";
    public static final String PATH_STATEMENTS_QUERIES = "/ui/v1/statement/details/queries";
    public static final String PATH_STATEMENTS_QUERIES_TRANSACTIONS = "/ui/v1/statement/details/queries/transactions";
    public static final String PATH_TRANSACTION_DETAILS_QUERIES = "/ui/v1/transaction/details/queries/";
    public static final String PATH_BALANCE_ADJUSTMENTS = "/ui/v1/balance/adjustment";
    public static final String PATH_OUTSTANDING_DEPOSIT ="/ui/v1/balance/outstanding/DEPOSIT";
    public static final String PATH_OUTSTANDING_WITHDRAW ="/ui/v1/balance/outstanding/WITHDRAW";



    //STUB
    public static final String PATH_POST_STUB_INCOMING_MESSAGES = "/v1/incoming-messages";
    public static final String PATH_POST_RECEIVE_PAYMENTS = "/v1/incoming-messages";
    public static final String PATH_POST_RECEIVE_DEVOLUTION = "/v1/incoming-messages";
    public static final String PATH_POST_RECEIVE_BALANCE = "/v1/incoming-messages/";

}
