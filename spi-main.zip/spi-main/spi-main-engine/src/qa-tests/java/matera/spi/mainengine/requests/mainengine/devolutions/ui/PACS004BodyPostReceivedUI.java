package matera.spi.mainengine.requests.mainengine.devolutions.ui;

import matera.spi.main.domain.service.CorrelationIdGenerator;
import matera.spi.mainengine.model.mainengine.receivers.ui.IncomingMessageDetail;
import matera.spi.mainengine.model.mainengine.receivers.ui.ReceivePaymentModel;
import matera.spi.mainengine.utils.DocumentConverterUtil;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PACS004BodyPostReceivedUI {

    public static final String PACS_004 = "src/qa-tests/resources/xml/mainengine/pacs-004-example.xml";
    public static final String ORIGINAL_END_TO_END_ID_PLACEHOLDER = "###originalEndToEndId###";
    public static final String ISPB = "13370835";
    public static final String RTR_ID = "###rtrID###";
    public static final String DESIRED_RESULT = "###desiredResult###";
    IncomingMessageDetail IncomingMessageDetail = new IncomingMessageDetail();
    String rtrId = CorrelationIdGenerator.generateCorrelactionIdPacs004(ISPB);

    public String getRtrId() {
        return rtrId;
    }

    public ReceivePaymentModel receiveValidPACS004(String endToEndID) {
        ReceivePaymentModel ReceivePaymentModel = new ReceivePaymentModel();
        ReceivePaymentModel.setIspb(ISPB);
        List<IncomingMessageDetail> messageContent = new ArrayList<>();
        ReceivePaymentModel.setIncomingMessage(messageContent);
        String pacs004 = parseFileToXMLStringFormat();
        pacs004 = pacs004.replace(ORIGINAL_END_TO_END_ID_PLACEHOLDER, endToEndID);
        pacs004 = pacs004.replace(RTR_ID, rtrId);
        pacs004 = pacs004.replace(DESIRED_RESULT, "SUCCESS");
        IncomingMessageDetail.setXml(pacs004);
        messageContent.add(IncomingMessageDetail);
        return ReceivePaymentModel;
    }

    public ReceivePaymentModel receiveRejectPACS004(String endToEndID) {
        ReceivePaymentModel ReceivePaymentModel = new ReceivePaymentModel();
        ReceivePaymentModel.setIspb(ISPB);
        List<IncomingMessageDetail> messageContent = new ArrayList<>();
        ReceivePaymentModel.setIncomingMessage(messageContent);
        String pacs004 = parseFileToXMLStringFormat();
        pacs004 = pacs004.replace(ORIGINAL_END_TO_END_ID_PLACEHOLDER, endToEndID);
        pacs004 = pacs004.replace(RTR_ID, rtrId);
        pacs004 = pacs004.replace(DESIRED_RESULT, "REJECT");
        IncomingMessageDetail.setXml(pacs004);
        messageContent.add(IncomingMessageDetail);
        return ReceivePaymentModel;
    }

    public ReceivePaymentModel receiveAPACS004WithADMI002Error(String endToEndID) {
        ReceivePaymentModel ReceivePaymentModel = new ReceivePaymentModel();
        ReceivePaymentModel.setIspb(ISPB);
        List<IncomingMessageDetail> messageContent = new ArrayList<>();
        ReceivePaymentModel.setIncomingMessage(messageContent);
        String pacs004 = parseFileToXMLStringFormat();
        pacs004 = pacs004.replace(ORIGINAL_END_TO_END_ID_PLACEHOLDER, endToEndID);
        pacs004 = pacs004.replace(RTR_ID, rtrId);
        pacs004 = pacs004.replace(DESIRED_RESULT, "ADMI002");
        IncomingMessageDetail.setXml(pacs004);
        messageContent.add(IncomingMessageDetail);
        return ReceivePaymentModel;
    }

    public String parseFileToXMLStringFormat(){
        String xmlPACS004 = DocumentConverterUtil.convertFileToString(PACS_004);
        return xmlPACS004;
    }

    public Map<String, String> setParamsEventStatus(String returnId) {

        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");

        Map<String, String> eventParam = new HashMap<>();
        eventParam.put("startTimestampUtc", LocalDateTime.now().minusDays(1).format(dateTimeFormatter));
        eventParam.put("endTimestampUtc", LocalDateTime.now().plusDays(1).format(dateTimeFormatter));
        eventParam.put("correlationId", returnId);
        return eventParam;
    }

}
