package matera.spi.mainengine.validations.mainengine.devolutions.ui;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.utils.Asserts;
import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;

import static matera.spi.mainengine.utils.Util.assertEquals;

public class SendADevolutionValidationsUI extends BaseAction {

    public void invalidPACS004Response(String errorCode, String message) throws Exception {
        switch (getStatusCode()) {
            case 400:
                Asserts.assertEquals(HttpStatus.SC_BAD_REQUEST, getStatusCode());
                Asserts.assertThat(getJsonValue("error[0].code"), Matchers.equalTo(errorCode));
                Asserts.assertThat(getJsonValue("error[0].message"), Matchers.equalTo(message));
                break;
            case 500:
                assertEquals(HttpStatus.SC_INTERNAL_SERVER_ERROR, getStatusCode());
                Asserts.assertThat(getJsonValue("error[0].code"), Matchers.equalTo(errorCode));
                Asserts.assertThat(getJsonValue("error[0].message"), Matchers.equalTo(message));
                break;
            default:
                break;
        }
    }

    public void unauthorizedPACS004Response() throws Exception {
        Asserts.assertEquals(HttpStatus.SC_UNAUTHORIZED, getStatusCode());
        Asserts.assertThat(getJsonValue("error"), Matchers.equalTo("unauthorized"));
        Asserts.assertThat(getJsonValue("error_description"), Matchers.equalTo("Full authentication is required to access this resource"));
    }

    public void rejectedPACS002Response(int statusCodePACS002, String returnEndToEndIdentification, String devolutionStatusCode, String devolutionstatusDescription, String devolutionEndToEndId) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodePACS002);
        Asserts.assertThat(devolutionStatusCode, Matchers.is("26"));
        Asserts.assertThat(devolutionstatusDescription, Matchers.is("Return rejected"));
        Asserts.assertThat(devolutionEndToEndId, Matchers.is(returnEndToEndIdentification));
    }

    public void duplicatedReturnEndToEndIdentification() throws Exception {
        Asserts.assertEquals(HttpStatus.SC_INTERNAL_SERVER_ERROR, getStatusCode());
        Asserts.assertThat(getJsonValue("error[0].code"), Matchers.equalTo("MTR-003"));
        Asserts.assertThat(getJsonValue("error[0].message"), Matchers.equalTo("Internal error processing the request."));
    }

    public void validPACS002Response(int statusCodePACS002,
                                     String returnEndToEndIdentification,
                                     String devolutionStatusCode,
                                     String devolutionstatusDescription,
                                     String devolutionEndToEndId) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodePACS002);
        Asserts.assertThat(devolutionStatusCode, Matchers.is("3"));
        Asserts.assertThat(devolutionstatusDescription, Matchers.is("Success"));
        Asserts.assertThat(devolutionEndToEndId, Matchers.is(returnEndToEndIdentification));
    }

    public void invalidOriginalEndToEndIdentification(String invalidOriginalEndToEndIdentification) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_BAD_REQUEST, getStatusCode());
        Asserts.assertThat(getJsonValue("error[0].code"), Matchers.equalTo("Pattern"));
        Asserts.assertThat(getJsonValue("error[0].message"), Matchers.equalTo("Field originalEndToEndIdentification: must match \"[E|D][0-9]{8}[0-9]{4}[0-1][0-9][0-3][0-9][0-2][0-9][0-5][0-9][a-zA-Z0-9]{11}\". Informed value: ["+invalidOriginalEndToEndIdentification+"]"));
    }

    public void nullOriginalEndToEndIdentification() throws Exception {
        Asserts.assertEquals(HttpStatus.SC_BAD_REQUEST, getStatusCode());
        Asserts.assertThat(getJsonValue("error[0].code"), Matchers.equalTo("NotNull"));
        Asserts.assertThat(getJsonValue("error[0].message"), Matchers.equalTo("Field originalEndToEndIdentification: must not be null"));
    }
    public void validateAdmi002ErrorPACS002Response(int statusCodePACS002,
                                            String returnEndToEndIdentification,
                                            String devolutionStatusCode,
                                            String devolutionstatusDescription,
                                            String devolutionEndToEndId) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodePACS002);
        Asserts.assertThat(devolutionStatusCode, Matchers.is("5"));
        Asserts.assertThat(devolutionstatusDescription, Matchers.is("Error"));
        Asserts.assertThat(devolutionEndToEndId, Matchers.is(returnEndToEndIdentification));
    }

    public void validateReturnNotAllowedUI(int statusCodePACS004, String endToEndId, String devolutionStatusCodeUI, String devolutionstatusDescriptionUI) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_BAD_REQUEST, statusCodePACS004);
        Asserts.assertThat(devolutionStatusCodeUI, Matchers.is("SPI-ME-006"));
        Asserts.assertThat(devolutionstatusDescriptionUI, Matchers.is("Field OriginalEndToEndIdentification: Orign Event to Return not found with EndToEndId: " + endToEndId));
    }
}
