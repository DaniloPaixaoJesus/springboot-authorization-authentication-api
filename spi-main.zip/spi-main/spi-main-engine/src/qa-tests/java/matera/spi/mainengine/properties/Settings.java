package matera.spi.mainengine.properties;

import matera.spi.mainengine.utils.ConfigReader;

import java.io.IOException;

public class Settings {

    String mainEngineUrl = ConfigReader.getPropertiesFile("main.engine.url");
    String stubUrl = ConfigReader.getPropertiesFile("stub.url");
    String databaseUrl = ConfigReader.getPropertiesFile("database.url");
    String databaseDriver = ConfigReader.getPropertiesFile("database.driver");
    String databaseUser = ConfigReader.getPropertiesFile("database.user");
    String databasePassword = ConfigReader.getPropertiesFile("database.password");
    String keycloakUrl = ConfigReader.getPropertiesFile("keycloak.url");

    public Settings() throws IOException {
    }

}
