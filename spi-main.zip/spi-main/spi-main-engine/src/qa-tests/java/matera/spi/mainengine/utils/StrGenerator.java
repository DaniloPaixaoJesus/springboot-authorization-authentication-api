package matera.spi.mainengine.utils;

import org.apache.commons.lang3.RandomStringUtils;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class StrGenerator {

    private static final Integer LENGTH_MAX_TO_RANDOM_ALPHA_NUMERIC = 9;
    private static final String PREFIX_STR = "STR";
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyyMMdd");

    public static String generate() {
        return PREFIX_STR + getTodayUTC() + generateRandomAlphaNumericValue();
    }

    public static String getTodayUTC() {
        return LocalDate.now(ZoneId.of("UTC")).format(DATE_FORMAT);
    }

    private static String generateRandomAlphaNumericValue() {
        return RandomStringUtils.randomAlphanumeric(LENGTH_MAX_TO_RANDOM_ALPHA_NUMERIC);
    }

}


