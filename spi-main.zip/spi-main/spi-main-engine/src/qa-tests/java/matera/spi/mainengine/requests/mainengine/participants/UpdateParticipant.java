package matera.spi.mainengine.requests.mainengine.participants;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.utils.DocumentConverterUtil;

public class UpdateParticipant extends BaseAction {
    public static final String REDA_041 = "src/qa-tests/resources/xml/mainengine/reda-041-example.xml";

    public String validUpdateParticipant() {
        String reda041 = parseFileToXMLStringFormat();
        return reda041;
    }

    public String parseFileToXMLStringFormat() {
        String xml = DocumentConverterUtil.convertFileToString(REDA_041);
        return xml;
    }
}
