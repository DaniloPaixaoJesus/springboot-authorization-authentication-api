package matera.spi.mainengine.utils;

import matera.spi.mainengine.commons.Paths;
import matera.spi.mainengine.core.BaseAction;
import io.restassured.http.ContentType;
import org.apache.http.HttpStatus;

import static io.restassured.RestAssured.given;

public class GenerateEndToEndID extends BaseAction {

    public static String GENERATE_ENDTOENDID_BODY = "{\"ispb\":\"13370835\"}";

    public String EndToEndID() {
        String Id =
            given()
                .header(AUTHORIZATION_KEY,AUTHORIZATION_VALUE + getAuthorizationToken())
                .contentType(ContentType.JSON)
                .body(GENERATE_ENDTOENDID_BODY)
                .when()
                .post(getMainEngineURL().concat(Paths.PATH_GENERATE_END_TO_END_ID_UI))
                .then()
                .statusCode(HttpStatus.SC_OK)
                .extract().path("data.endToEndID");
        return Id;
    }
}
