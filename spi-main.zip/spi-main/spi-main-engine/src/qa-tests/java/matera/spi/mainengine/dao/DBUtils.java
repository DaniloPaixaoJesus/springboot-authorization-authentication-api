package matera.spi.mainengine.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.LinkedList;

public class DBUtils {
	private PreparedStatement ps;
	private LinkedList<String> parametersList;
	private ResultSet rs;
	private QueryResult queryResult;
	private boolean stopQuery;

	public DBUtils() {
		this.ps = null;
		this.parametersList = new LinkedList<String>();
		this.rs = null;
		this.queryResult = null;
		this.stopQuery = true;
	}

	public DBUtils(LinkedList<String> listOfParameters) {
		this.ps = null;
		this.parametersList = listOfParameters;
		this.rs = null;
		this.queryResult = null;
		this.stopQuery = true;
	}

	public void isStopQuery(boolean stopQuery) {
	    this.stopQuery = stopQuery;
	}

	private void configPreparedStatement(String query) {
		try {
			Database db = new Database();
			db.setConn(DatabaseSettings.createDatabaseConnection());
            System.out.println("Performing SQL statements...");
			this.ps = db.getConn().prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
		} catch (Exception e) {
			this.closeConnection();
            System.out.println(e);
            System.out.println("Error when trying to configure the connection to the database!");
		}
	}

	public void configParametersList(LinkedList<String> listOfParameters) {
		this.parametersList = listOfParameters;
	}

	private QueryResult executeQuery(String query) {
		try {
			rs = ps.executeQuery();
			ResultSetMetaData rsm = rs.getMetaData();
            System.out.println("Query ended, returning results...");
			while (rs.next()) {
				QueryResult newRecord = new QueryResult();
				for (int a = 1; a <= rsm.getColumnCount(); a++) {
                    newRecord.insertRecords(rsm.getColumnName(a).toUpperCase(), rs.getString(a));
                    System.out.println(("Data: " + rsm.getColumnName(a) + " of value: " + rs.getString(a) + " obtained successfully! "));
				}
				if (this.queryResult == null) {
					this.queryResult = newRecord;
				} else {
					this.queryResult.insertNext(newRecord, this.queryResult);
				}
			}
			if ((queryResult == null && stopQuery) || (stopQuery && queryResult.getSize(this.queryResult) == 0)) {
				this.closeConnection();
                System.out.println("Query did not return any valid records!");
			} else if (queryResult == null || queryResult.getSize(this.queryResult) == 0) {
                System.out.println("Query did not return any records");
			}
		} catch (SQLException e) {
			this.closeConnection();
            System.out.println(e);
		}
		return this.queryResult;
	}

	private int executeUpdate(String update) {
		try {
            System.out.println("Success when updating, insert or delete!");
			return ps.executeUpdate();
		} catch (SQLException e) {
			this.closeConnection();
            System.out.println(e);
            System.out.println("Error when updating, insert or delete!");
		}
		return -1;
	}

	private void configureParametersPreparedStatement() {
		try {
			if (this.parametersList.size() > 0 && ps != null) {
				Iterator<String> i = parametersList.iterator();
				int counter = 1;
				while (i.hasNext()) {
					ps.setString(counter, i.next());
                    counter++;
				}
			} else if (ps == null) {
                System.out.println("Error when trying to configure the parameters. Check PreparedStatement and its configuration!");
			}
		} catch (SQLException e) {
			this.closeConnection();
            System.out.println(e);
            System.out.println("Error when trying to query the database!");
		}
	}

	private void closeConnection() {
		try {
			if (rs != null) {
				rs.close();
			}
			if (ps != null) {
				ps.close();
			}
		} catch (Exception e2) {
            System.out.println("Error when trying to close connection to the database!");
		}
	}

	public QueryResult getQuery(String query) {
		this.queryResult = null;
		this.configPreparedStatement(query);
		this.configureParametersPreparedStatement();
		this.executeQuery(query);
		this.closeConnection();
		this.parametersList = new LinkedList<String>();
		return this.queryResult;
	}

	public void update(String update) {
		this.queryResult = null;
		this.configPreparedStatement(update);
		this.configParametersList(this.parametersList);
		this.configureParametersPreparedStatement();
		this.executeUpdate(update);
		this.closeConnection();
		this.parametersList = new LinkedList<String>();
        System.out.println("Update, insert or delete performed successfully!");
	}

	public void addParameter(String parameter) {
		this.parametersList.add(parameter);
	}
}
