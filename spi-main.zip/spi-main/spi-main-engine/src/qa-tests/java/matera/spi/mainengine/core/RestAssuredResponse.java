package matera.spi.mainengine.core;

import io.restassured.path.json.config.JsonPathConfig;
import io.restassured.response.Response;

import java.util.ArrayList;
import java.util.Map;

public class RestAssuredResponse implements BaseResponse {

    private Response restAssuredResponse;

    public RestAssuredResponse(Response restAssuredResponse) {
        this.restAssuredResponse = restAssuredResponse;
    }

    @Override
    public void prettyPrint() {
        restAssuredResponse.prettyPrint();
    }

    @Override
    public String responseAsString() {
        return restAssuredResponse.getBody().asString();
    }

    @Override
    public ArrayList<Map<String, ?>> path(String content) {
        return restAssuredResponse.path(content);
    }

    @Override
    public int statusCode() {
        return restAssuredResponse.getStatusCode();
    }

    @Override
    public String getJsonValue(String value) {
        return restAssuredResponse.jsonPath().getString(value);
    }

    @Override
    public String getJsonValue(String value, JsonPathConfig jsonPathConfig) {
        return restAssuredResponse.jsonPath(jsonPathConfig).getString(value);
    }

}
