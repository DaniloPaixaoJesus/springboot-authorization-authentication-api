package matera.spi.mainengine.requests.mainengine.payments.ui;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.model.mainengine.payments.ui.Account;
import matera.spi.mainengine.model.mainengine.payments.ui.Payer;
import matera.spi.mainengine.model.mainengine.payments.ui.Payment;
import matera.spi.mainengine.model.mainengine.payments.ui.PostPaymentModelUI;
import matera.spi.mainengine.model.mainengine.payments.ui.PostPaymentModelUIWithoutCreationDateTime;
import matera.spi.mainengine.model.mainengine.payments.ui.Receiver;
import matera.spi.mainengine.utils.GenerateEndToEndID;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PACS008BodyPostSendedUI extends BaseAction {

    GenerateEndToEndID generateEndToEndID = new GenerateEndToEndID();
    String EndToEndID = generateEndToEndID.EndToEndID();
    public static final String VALID_BRANCH_RECEIVER = "2637";
    public static final String VALID_ACCOUNT_NUMBER_RECEIVER = "123456-7";
    public static final String VALID_ACCOUNT_TYPE_RECEIVER = "CACC";
    public static final String VALID_ACCEPTANCE_DATETIME = "2020-05-06T14:37:14.960Z";
    public static final String VALID_ISPB_RECEIVER = "250699";
    public static final String VALID_TAX_ID_RECEIVER = "100.200.300-88";
    public static final String VALID_BRANCH_PAYER = "9911";
    public static final String VALID_ACCOUNT_NUMBER_PAYER = "00290785";
    public static final String VALID_ACCOUNT_TYPE_PAYER = "CACC";
    public static final String VALID_ISPB_PAYER = "13370835";
    public static final String VALID_TAX_ID_PAYER = "783.066.215-06";
    public static final String VALID_NAME_PAYER = "Payer Teste";
    public static final String VALID_UNSTRUCTURED = "Pagamento para a caixa";
    public static final String VALID_CHARGER_BEARER = "SLEV";
    public static final String VALID_INTERBANK_SETTLEMENT_AMOUNT = "50.00";
    public static final String VALID_CREATION_DATETIME = "2020-04-24T20:17:42.399Z";
    public static final String VALID_SETTLEMENT_METHOD = "CLRG";
    public static final String VALID_INSTRUCTION_PRIORITY = "HIGH";

    public PostPaymentModelUI validPACS008() {

        Account accountReceiver = new Account();
        accountReceiver.setBranch(VALID_BRANCH_RECEIVER);
        accountReceiver.setAccountNumber(VALID_ACCOUNT_NUMBER_RECEIVER);
        accountReceiver.setAccountType(VALID_ACCOUNT_TYPE_RECEIVER);

        Receiver receiver = new Receiver();
        receiver.setInstitutionISPB(VALID_ISPB_RECEIVER);
        receiver.setTaxId(VALID_TAX_ID_RECEIVER);
        receiver.setAddressingKey("");
        receiver.setAccount(accountReceiver);

        Account accountPayer = new Account();
        accountPayer.setAccountNumber(VALID_ACCOUNT_NUMBER_PAYER);
        accountPayer.setBranch(VALID_BRANCH_PAYER);
        accountPayer.setAccountType(VALID_ACCOUNT_TYPE_PAYER);

        Payer payer = new Payer();
        payer.setInstitutionISPB(VALID_ISPB_PAYER);
        payer.setTaxId(VALID_TAX_ID_PAYER);
        payer.setName(VALID_NAME_PAYER);
        payer.setAccount(accountPayer);

        Payment payment = new Payment();
        payment.setAcceptanceDateTime(VALID_ACCEPTANCE_DATETIME);
        payment.setEndToEndID(EndToEndID);
        payment.setUnstructured(VALID_UNSTRUCTURED);
        payment.setChargeBearer(VALID_CHARGER_BEARER);
        payment.setInterbankSettlementAmount(VALID_INTERBANK_SETTLEMENT_AMOUNT);
        payment.setPayer(payer);
        payment.setReceiver(receiver);

        List<Payment> payments = new ArrayList<>();
        payments.add(payment);

        PostPaymentModelUI postPaymentModelUI = new PostPaymentModelUI();
        postPaymentModelUI.setCreationDateTime(VALID_CREATION_DATETIME);
        postPaymentModelUI.setSettlementMethod(VALID_SETTLEMENT_METHOD);
        postPaymentModelUI.setInstructionPriority(VALID_INSTRUCTION_PRIORITY);
        postPaymentModelUI.setPayments(payments);

        return postPaymentModelUI;
    }

    public PostPaymentModelUIWithoutCreationDateTime validPACS008WithoutCreationDateTime() {

        Account accountReceiver = new Account();
        accountReceiver.setBranch(VALID_BRANCH_RECEIVER);
        accountReceiver.setAccountNumber(VALID_ACCOUNT_NUMBER_RECEIVER);
        accountReceiver.setAccountType(VALID_ACCOUNT_TYPE_RECEIVER);

        Receiver receiver = new Receiver();
        receiver.setInstitutionISPB(VALID_ISPB_RECEIVER);
        receiver.setTaxId(VALID_TAX_ID_RECEIVER);
        receiver.setAddressingKey("");
        receiver.setAccount(accountReceiver);

        Account accountPayer = new Account();
        accountPayer.setAccountNumber(VALID_ACCOUNT_NUMBER_PAYER);
        accountPayer.setBranch(VALID_BRANCH_PAYER);
        accountPayer.setAccountType(VALID_ACCOUNT_TYPE_PAYER);

        Payer payer = new Payer();
        payer.setInstitutionISPB(VALID_ISPB_PAYER);
        payer.setTaxId(VALID_TAX_ID_PAYER);
        payer.setName(VALID_NAME_PAYER);
        payer.setAccount(accountPayer);

        Payment payment = new Payment();
        payment.setEndToEndID(EndToEndID);
        payment.setUnstructured(VALID_UNSTRUCTURED);
        payment.setChargeBearer(VALID_CHARGER_BEARER);
        payment.setInterbankSettlementAmount(VALID_INTERBANK_SETTLEMENT_AMOUNT);
        payment.setPayer(payer);
        payment.setReceiver(receiver);

        List<Payment> payments = new ArrayList<>();
        payments.add(payment);

        PostPaymentModelUIWithoutCreationDateTime postPaymentModelUIWithoutCreationDateTime = new PostPaymentModelUIWithoutCreationDateTime();
        postPaymentModelUIWithoutCreationDateTime.setSettlementMethod(VALID_SETTLEMENT_METHOD);
        postPaymentModelUIWithoutCreationDateTime.setInstructionPriority(VALID_INSTRUCTION_PRIORITY);
        postPaymentModelUIWithoutCreationDateTime.setPayments(payments);

        return postPaymentModelUIWithoutCreationDateTime;
    }


    public String getEndToEndID() {
        return EndToEndID;
    }

    public Map<String, String> setParamsEventStatus(String eventId) {

        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");

        Map<String, String> eventParam = new HashMap<>();
        eventParam.put("startTimestampUtc", LocalDateTime.now().minusDays(1).format(dateTimeFormatter));
        eventParam.put("endTimestampUtc", LocalDateTime.now().plusDays(1).format(dateTimeFormatter));
        eventParam.put("eventId", eventId);
        return eventParam;
    }

}
