package matera.spi.mainengine.validations.lm.transactions;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.utils.Asserts;

import org.apache.http.HttpStatus;

public class TransactionsValidations extends BaseAction {

    public void validateWithdraw() throws Exception {
        Asserts.assertEquals(HttpStatus.SC_CREATED, getStatusCode());
    }

    public void validateDeposit() throws Exception {
        Asserts.assertEquals(HttpStatus.SC_CREATED, getStatusCode());
    }

}
