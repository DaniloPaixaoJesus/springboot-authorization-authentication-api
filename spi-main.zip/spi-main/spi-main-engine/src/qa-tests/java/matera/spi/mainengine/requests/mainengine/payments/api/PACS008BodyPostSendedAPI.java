package matera.spi.mainengine.requests.mainengine.payments.api;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.model.mainengine.payments.api.Account;
import matera.spi.mainengine.model.mainengine.payments.api.Payer;
import matera.spi.mainengine.model.mainengine.payments.api.PostPaymentModelAPI;
import matera.spi.mainengine.model.mainengine.payments.api.Receiver;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

public class PACS008BodyPostSendedAPI extends BaseAction {

    public static final String VALID_RECEIVER_INSTITUTION_ISPB = "250699";
    public static final String VALID_RECEIVER_TAX_ID = "03259787941";
    public static final String VALID_RECEIVER_BRANCH = "2";
    public static final String VALID_RECEIVER_ACCOUNT_NUMBER = "12345635";
    public static final String VALID_RECEIVER_ACCOUNT_TYPE = "CACC";
    public static final String VALID_INFORMATION_ACCOUNT_HOLDER = "Informações accountHoulder";
    public static final Boolean VALID_CHECK_CUSTOMER_ACCOUNT_BALANCE = true;
    public static final Boolean VALID_DEMANDS_IMMEDIATE_RETURN = true;
    public static final String VALID_HISTORIC_COMPLEMENT = "Historico Complemento";
    public static final String DESIRED_RESULT_KEY = "desiredResult";
    public static final String DESIRED_RESULT_VALUE_SUCCESS = "SUCCESS";
    public static final String DESIRED_RESULT_VALUE_REJECT = "REJECT";
    public static final String DESIRED_RESULT_VALUE_ERROR = "ADMI002";
    public static final String VALID_SUCCESS_ADDITIONAL_INFORMATION = "{\""+DESIRED_RESULT_KEY+"\":\""+DESIRED_RESULT_VALUE_SUCCESS+"\"}";
    public static final String VALID_REJECT_ADDITIONAL_INFORMATION = "{\""+DESIRED_RESULT_KEY+"\":\""+DESIRED_RESULT_VALUE_REJECT+"\"}";
    public static final String VALID_ERROR_ADDITIONAL_INFORMATION = "{\""+DESIRED_RESULT_KEY+"\":\""+DESIRED_RESULT_VALUE_ERROR+"\"}";
    public static final String VALID_VALUE = "15.15";
    public static final String VALID_ORIGIN_SYSTEM = "matera";
    public static final String VALID_PAYER_NAME = "joao ferreira";
    public static final String VALID_PAYER_BRANCH = "1";
    public static final String VALID_PAYER_ACCOUNT_NUMBER = "35";

    public PostPaymentModelAPI validPACS008API() {

        matera.spi.mainengine.model.mainengine.payments.ui.Account accountReceiver = new matera.spi.mainengine.model.mainengine.payments.ui.Account();
        accountReceiver.setBranch(VALID_RECEIVER_BRANCH);
        accountReceiver.setAccountNumber(VALID_RECEIVER_ACCOUNT_NUMBER);
        accountReceiver.setAccountType(VALID_RECEIVER_ACCOUNT_TYPE);

        Receiver receiver = new Receiver();
        receiver.setReceiverInstitutionISPB(VALID_RECEIVER_INSTITUTION_ISPB);
        receiver.setReceiverTaxId(VALID_RECEIVER_TAX_ID);
        receiver.setAccount(accountReceiver);

        Account account = new Account();
        account.setAccountNumber(VALID_PAYER_ACCOUNT_NUMBER);
        account.setBranch(VALID_PAYER_BRANCH);

        Payer payer = new Payer();
        payer.setCheckCustomerAccountBalance(VALID_CHECK_CUSTOMER_ACCOUNT_BALANCE);
        payer.setName(VALID_PAYER_NAME);
        payer.setAccount(account);

        PostPaymentModelAPI postPaymentModelAPI = new PostPaymentModelAPI();
        postPaymentModelAPI.setInformationAccountHolder(VALID_INFORMATION_ACCOUNT_HOLDER);
        postPaymentModelAPI.setAdditionalInformation(VALID_SUCCESS_ADDITIONAL_INFORMATION);
        postPaymentModelAPI.setOriginSystem(VALID_ORIGIN_SYSTEM);
        postPaymentModelAPI.setValue(VALID_VALUE);
        postPaymentModelAPI.setDemandsImmediateReturn(VALID_DEMANDS_IMMEDIATE_RETURN);
        postPaymentModelAPI.setHistoricComplement(VALID_HISTORIC_COMPLEMENT);
        postPaymentModelAPI.setPayer(payer);
        postPaymentModelAPI.setReceiver(receiver);

        return postPaymentModelAPI;
    }

    public Map<String, String> setParamsEventStatus(String correlationId) {

        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");

        Map<String, String> eventParam = new HashMap<>();
        eventParam.put("startTimestampUtc", LocalDateTime.now().minusDays(1).format(dateTimeFormatter));
        eventParam.put("endTimestampUtc", LocalDateTime.now().plusDays(1).format(dateTimeFormatter));
        eventParam.put("correlationId", correlationId);
        return eventParam;
    }

}
