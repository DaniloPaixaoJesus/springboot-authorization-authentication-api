package matera.spi.mainengine.requests.mainengine.devolutions.ui;

import matera.spi.main.domain.service.CorrelationIdGenerator;
import matera.spi.mainengine.model.mainengine.devolutions.ui.SendedDevolutionModelUI;
import matera.spi.mainengine.utils.GenerateEndToEndID;

public class PACS004BodyPostSendedUI {

    public static final String VALID_CREATION_DATE_TIME = "2020-05-18T18:54:31.650Z";
    public static final String VALID_SETTLEMENT_METHOD = "CLRG";
    public static final String VALID_RETURNED_INTERBANK_SETTLEMENT_AMOUNT = "20.00";
    public static final String VALID_SETTLEMENT_PRIORITY = "HIGH";
    public static final String VALID_CHARGE_BEARER = "SLEV";
    public static final String VALID_RETURN_REASON_INFORMATION = "UPAY";
    public static final String VALID_DEBTOR_AGENT = "13370835";
    public static final String VALID_CREDITOR_AGENT = "000000000";
    public static final String DESIRED_RESULT_KEY = "desiredResult";
    public static final String DESIRED_RESULT_VALUE_SUCCESS = "SUCCESS";
    public static final String DESIRED_RESULT_VALUE_REJECT = "REJECT";
    public static final String DESIRED_RESULT_VALUE_ADMI002_ERROR = "ADMI002";
    public static final String VALID_ADDITIONAL_INFORMATION = "{\""+DESIRED_RESULT_KEY+"\":\""+DESIRED_RESULT_VALUE_SUCCESS+"\"}";
    public static final String REJECT_ADDITIONAL_INFORMATION = "{\""+DESIRED_RESULT_KEY+"\":\""+DESIRED_RESULT_VALUE_REJECT+"\"}";
    public static final String ERROR_ADDITIONAL_INFORMATION = "{\""+DESIRED_RESULT_KEY+"\":\""+DESIRED_RESULT_VALUE_ADMI002_ERROR+"\"}";
    public static final String VALID_UNSTRUCTURED = "";
    GenerateEndToEndID generateEndToEndID = new GenerateEndToEndID();
    String EndToEndID = generateEndToEndID.EndToEndID();
    String returnEndToEndIdentification = CorrelationIdGenerator.generateCorrelactionIdPacs004(VALID_DEBTOR_AGENT);

    public SendedDevolutionModelUI validPACS004(String endToEndID){
        SendedDevolutionModelUI sendedDevolutionModelUI = new SendedDevolutionModelUI();
        sendedDevolutionModelUI.setOriginalEndToEndIdentification(endToEndID);
        sendedDevolutionModelUI.setReturnEndToEndIdentification(returnEndToEndIdentification);
        sendedDevolutionModelUI.setCreationDateTime(VALID_CREATION_DATE_TIME);
        sendedDevolutionModelUI.setSettlementMethod(VALID_SETTLEMENT_METHOD);
        sendedDevolutionModelUI.setReturnedInterbankSettlementAmount(VALID_RETURNED_INTERBANK_SETTLEMENT_AMOUNT);
        sendedDevolutionModelUI.setSettlementPriority(VALID_SETTLEMENT_PRIORITY);
        sendedDevolutionModelUI.setChargeBearer(VALID_CHARGE_BEARER);
        sendedDevolutionModelUI.setReturnReasonInformation(VALID_RETURN_REASON_INFORMATION);
        sendedDevolutionModelUI.setDebtorAgent(VALID_DEBTOR_AGENT);
        sendedDevolutionModelUI.setCreditorAgent(VALID_CREDITOR_AGENT);
        sendedDevolutionModelUI.setAdditionalInformation(VALID_ADDITIONAL_INFORMATION);
        sendedDevolutionModelUI.setUnstructured(VALID_UNSTRUCTURED);
        return sendedDevolutionModelUI;
    }

    public String getEndToEndID() {
        return EndToEndID;
    }
    public String getReturnEndToEndIdentification() { return returnEndToEndIdentification; }

    public String setReturnEndToEndIdentification() {
        return CorrelationIdGenerator.generateCorrelactionIdPacs004(VALID_DEBTOR_AGENT);
    }

}
