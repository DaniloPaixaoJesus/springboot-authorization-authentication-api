package matera.spi.mainengine.validations.mainengine.devolutions.api;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.utils.Asserts;
import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;
import org.junit.Assert;
import static matera.spi.mainengine.utils.Util.assertEquals;

public class SendADevolutionValidationsAPI extends BaseAction {

    public void validPACS002Response(int statusCodePACS002, String eventId, String devolutionEventIdAPI, String devolutionStatusCodeAPI, String devolutionstatusDescriptionAPI) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodePACS002);
        Asserts.assertThat(devolutionEventIdAPI, Matchers.is(eventId));
        Asserts.assertThat(devolutionStatusCodeAPI, Matchers.is("3"));
        Asserts.assertThat(devolutionstatusDescriptionAPI, Matchers.is("Success"));
    }

    public void rejectedPACS002Response(int statusCodePACS002, String eventId, String devolutionEventIdAPI, String devolutionStatusCodeAPI, String devolutionstatusDescriptionAPI) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodePACS002);
        Asserts.assertThat(devolutionEventIdAPI, Matchers.is(eventId));
        Asserts.assertThat(devolutionStatusCodeAPI, Matchers.is("26"));
        Asserts.assertThat(devolutionstatusDescriptionAPI, Matchers.is("Return rejected"));
    }

    public void unauthorizedPACS004Response() throws Exception {
        Asserts.assertEquals(HttpStatus.SC_UNAUTHORIZED, getStatusCode());
        Asserts.assertThat(getJsonValue("error"), Matchers.equalTo("unauthorized"));
        Asserts.assertThat(getJsonValue("error_description"), Matchers.equalTo("Full authentication is required to access this resource"));
    }

    public void invalidPACS004Response(String errorCode, String errorMessage) throws Exception {
        switch (getStatusCode()) {
            case 400:
                Asserts.assertEquals(HttpStatus.SC_BAD_REQUEST, getStatusCode());
                Asserts.assertThat(getJsonValue("error[0].code"), Matchers.equalTo(errorCode));
                Asserts.assertThat(getJsonValue("error[0].message"), Matchers.equalTo(errorMessage));
                break;
            case 500:
                assertEquals(HttpStatus.SC_INTERNAL_SERVER_ERROR, getStatusCode());
                Asserts.assertThat(getJsonValue("error[0].code"), Matchers.equalTo(errorCode));
                Asserts.assertThat(getJsonValue("error[0].message"), Matchers.equalTo(errorMessage));
                break;
            default:
                break;
        }
    }

    public void validateRequiredFieldsPACS004Response(int statusCodePACS004, String errorCode, String errorMessage) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_BAD_REQUEST, statusCodePACS004);
        Assert.assertTrue(errorCode.equals("NotNull"));
        Assert.assertTrue(errorMessage.contains("must not be null"));
    }

    public void validateReturnNotAllowedAPI(int statusCodePACS004, String devolutionStatusCodeAPI, String devolutionstatusDescriptionAPI, String errorCode, String errorMessage) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_BAD_REQUEST, statusCodePACS004);
        Asserts.assertThat(devolutionStatusCodeAPI, Matchers.is(errorCode));
        Asserts.assertThat(devolutionstatusDescriptionAPI, Matchers.is(errorMessage));
    }

}
