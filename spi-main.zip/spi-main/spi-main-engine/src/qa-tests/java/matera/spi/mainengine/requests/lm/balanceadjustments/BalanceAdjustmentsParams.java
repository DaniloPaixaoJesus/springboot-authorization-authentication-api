package matera.spi.mainengine.requests.lm.balanceadjustments;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.utils.GenerateEndToEndID;
import matera.spi.mainengine.utils.StrGenerator;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

public class BalanceAdjustmentsParams extends BaseAction {

    GenerateEndToEndID generateEndToEndID = new GenerateEndToEndID();
    StrGenerator strGenerator = new StrGenerator();
    String EndToEndID = generateEndToEndID.EndToEndID();
    DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");

    public String getEndToEndID() {
        return EndToEndID;
    }

    public Map<String, String> setParamsBalanceAdjustmentQuery(String eventId) {
        Map<String, String> balanceAdjustmentQuery = new HashMap<>();
        balanceAdjustmentQuery.put("eventId", eventId);
        return balanceAdjustmentQuery;
    }

    public Map<String, String> setParamsBalanceAdjustmentLPI0001() {
        Map<String, String> balanceAdjustmentParamLPI0001 = new HashMap<>();
        balanceAdjustmentParamLPI0001.put("messageType", "LPI0001");
        balanceAdjustmentParamLPI0001.put("piAccountDatetime", LocalDateTime.now().format(dateTimeFormatter));
        balanceAdjustmentParamLPI0001.put("transactionType", "CREDIT");
        balanceAdjustmentParamLPI0001.put("transactionId", StrGenerator.generate());
        balanceAdjustmentParamLPI0001.put("value", "2.00");
        return balanceAdjustmentParamLPI0001;
    }

    public Map<String, String> setParamsBalanceAdjustmentLPI0002() {
        Map<String, String> balanceAdjustmentParamLPI0002 = new HashMap<>();
        balanceAdjustmentParamLPI0002.put("messageType", "LPI0002");
        balanceAdjustmentParamLPI0002.put("piAccountDatetime", LocalDateTime.now().format(dateTimeFormatter));
        balanceAdjustmentParamLPI0002.put("transactionType", "CREDIT");
        balanceAdjustmentParamLPI0002.put("transactionId", EndToEndID);
        balanceAdjustmentParamLPI0002.put("value", "1.00");
        return balanceAdjustmentParamLPI0002;
    }

    public Map<String, String> setParamsBalanceAdjustmentLPI0003() {
        Map<String, String> balanceAdjustmentParamLPI0003 = new HashMap<>();
        balanceAdjustmentParamLPI0003.put("messageType", "LPI0003");
        balanceAdjustmentParamLPI0003.put("piAccountDatetime", LocalDateTime.now().format(dateTimeFormatter));
        balanceAdjustmentParamLPI0003.put("transactionType", "DEBIT");
        balanceAdjustmentParamLPI0003.put("transactionId", EndToEndID);
        balanceAdjustmentParamLPI0003.put("value", "5.00");
        return balanceAdjustmentParamLPI0003;
    }

    public Map<String, String> setParamsBalanceAdjustmentLPI0004() {
        Map<String, String> balanceAdjustmentParamLPI0004 = new HashMap<>();
        balanceAdjustmentParamLPI0004.put("messageType", "LPI0004");
        balanceAdjustmentParamLPI0004.put("piAccountDatetime", LocalDateTime.now().format(dateTimeFormatter));
        balanceAdjustmentParamLPI0004.put("transactionType", "DEBIT");
        balanceAdjustmentParamLPI0004.put("transactionId", EndToEndID);
        balanceAdjustmentParamLPI0004.put("value", "3.00");
        return balanceAdjustmentParamLPI0004;
    }

    public Map<String, String> setParamsBalanceAdjustmentPACS004() {
        Map<String, String> balanceAdjustmentParamPACS004 = new HashMap<>();
        balanceAdjustmentParamPACS004.put("messageType", "PACS.004");
        balanceAdjustmentParamPACS004.put("piAccountDatetime", LocalDateTime.now().format(dateTimeFormatter));
        balanceAdjustmentParamPACS004.put("transactionType", "DEBIT");
        balanceAdjustmentParamPACS004.put("transactionId", EndToEndID);
        balanceAdjustmentParamPACS004.put("value", "10.50");
        return balanceAdjustmentParamPACS004;
    }

    public Map<String, String> setParamsBalanceAdjustmentLPI0006() {
        Map<String, String> balanceAdjustmentParamLPI0006 = new HashMap<>();
        balanceAdjustmentParamLPI0006.put("messageType", "LPI0002");
        balanceAdjustmentParamLPI0006.put("piAccountDatetime", LocalDateTime.now().format(dateTimeFormatter));
        balanceAdjustmentParamLPI0006.put("transactionType", "CREDIT");
        balanceAdjustmentParamLPI0006.put("transactionId", null);
        balanceAdjustmentParamLPI0006.put("value", "6.00");
        return balanceAdjustmentParamLPI0006;
    }

    public Map<String, String> setParamsBalanceAdjustmentPACS008() {
        Map<String, String> balanceAdjustmentParamPACS008 = new HashMap<>();
        balanceAdjustmentParamPACS008.put("messageType", "PACS.008");
        balanceAdjustmentParamPACS008.put("piAccountDatetime", LocalDateTime.now().format(dateTimeFormatter));
        balanceAdjustmentParamPACS008.put("transactionType", "CREDIT");
        balanceAdjustmentParamPACS008.put("transactionId", EndToEndID);
        balanceAdjustmentParamPACS008.put("value", "0.26");
        return balanceAdjustmentParamPACS008;
    }

    public Map<String, String> setParamsBalanceAdjustmentSEL1009() {
        Map<String, String> balanceAdjustmentParamPACS008 = new HashMap<>();
        balanceAdjustmentParamPACS008.put("messageType", "SEL1009");
        balanceAdjustmentParamPACS008.put("piAccountDatetime", LocalDateTime.now().format(dateTimeFormatter));
        balanceAdjustmentParamPACS008.put("transactionType", "CREDIT");
        balanceAdjustmentParamPACS008.put("transactionId", EndToEndID);
        balanceAdjustmentParamPACS008.put("value", "0.98");
        return balanceAdjustmentParamPACS008;
    }

    public Map<String, String> setParamsBalanceAdjustmentSEL1016() {
        Map<String, String> balanceAdjustmentParamPACS004 = new HashMap<>();
        balanceAdjustmentParamPACS004.put("messageType", "SEL1016");
        balanceAdjustmentParamPACS004.put("piAccountDatetime", LocalDateTime.now().format(dateTimeFormatter));
        balanceAdjustmentParamPACS004.put("transactionType", "DEBIT");
        balanceAdjustmentParamPACS004.put("transactionId", null);
        balanceAdjustmentParamPACS004.put("value", "0.52");
        return balanceAdjustmentParamPACS004;
    }

}
