package matera.spi.mainengine.dao;

import matera.spi.mainengine.properties.Settings;
import matera.spi.mainengine.utils.ConfigReader;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseSettings {

    public static Connection createDatabaseConnection() throws Exception {
        String driver = ConfigReader.getPropertiesFile("database.driver");
        String url = ConfigReader.getPropertiesFile("database.url");
        String user = ConfigReader.getPropertiesFile("database.user");
        String password = ConfigReader.getPropertiesFile("database.password");

        Connection conn = null;
        try {
            Class.forName(driver).getDeclaredConstructor().newInstance();
            conn = DriverManager.getConnection(url, user, password);
            conn.setAutoCommit(true);
            System.out.println("Successfully connected to the database!");
        } catch (Exception e) {
            throw new Exception("Could not connect to the database!)", e);
        }
        return conn;
    }
}
