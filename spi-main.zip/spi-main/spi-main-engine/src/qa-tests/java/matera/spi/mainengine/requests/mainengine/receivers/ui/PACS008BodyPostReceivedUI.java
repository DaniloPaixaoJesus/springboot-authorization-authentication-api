package matera.spi.mainengine.requests.mainengine.receivers.ui;

import matera.spi.mainengine.model.mainengine.receivers.ui.IncomingMessageDetail;
import matera.spi.mainengine.model.mainengine.receivers.ui.ReceivePaymentModel;
import matera.spi.mainengine.utils.DocumentConverterUtil;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PACS008BodyPostReceivedUI {

    public static final String PACS_008 = "src/qa-tests/resources/xml/mainengine/pacs-008-example.xml";
    public static final String ORIGINAL_END_TO_END_ID_PLACEHOLDER = "###originalEndToEndId###";
    public static final String DESIRED_RESULT_PLACEHOLDER = "###desiredResult###";
    public static final String ISPB = "13370835";
    public static final String TXID = "###txid###";
    IncomingMessageDetail incomingMessageDetail = new IncomingMessageDetail();

    public ReceivePaymentModel receiveValidPACS008(String endToEndID){
        ReceivePaymentModel receivePaymentModel = new ReceivePaymentModel();
        receivePaymentModel.setIspb(ISPB);
        List<IncomingMessageDetail> messageContent = new ArrayList<>();
        receivePaymentModel.setIncomingMessage(messageContent);
        String pacs008 = parseFileToXMLStringFormat();
        pacs008 = pacs008.replace(ORIGINAL_END_TO_END_ID_PLACEHOLDER, endToEndID);
        pacs008 = pacs008.replace(DESIRED_RESULT_PLACEHOLDER, "SUCCESS");
        pacs008 = pacs008.replace(TXID, "QRS1-NIMWPGBSKEBFNIXIZLF5");
        incomingMessageDetail.setXml(pacs008);
        messageContent.add(incomingMessageDetail);
        return receivePaymentModel;
    }

    public ReceivePaymentModel receiveRejectedPACS008(String endToEndID){
        ReceivePaymentModel receiveRejectedPACS008 = new ReceivePaymentModel();
        receiveRejectedPACS008.setIspb(ISPB);
        List<IncomingMessageDetail> messageContent = new ArrayList<>();
        receiveRejectedPACS008.setIncomingMessage(messageContent);
        String pacs008 = parseFileToXMLStringFormat();
        pacs008 = pacs008.replace(ORIGINAL_END_TO_END_ID_PLACEHOLDER, endToEndID);
        pacs008 = pacs008.replace(DESIRED_RESULT_PLACEHOLDER, "REJECT");
        pacs008 = pacs008.replace(TXID, "QRS1-NIMWPGBSKEBFNIXIZLF5");
        incomingMessageDetail.setXml(pacs008);
        messageContent.add(incomingMessageDetail);
        return receiveRejectedPACS008;
    }

    public ReceivePaymentModel receiveAPACS008WithADMI002Error(String endToEndID){
        ReceivePaymentModel receiveRejectedPACS008 = new ReceivePaymentModel();
        receiveRejectedPACS008.setIspb(ISPB);
        List<IncomingMessageDetail> messageContent = new ArrayList<>();
        receiveRejectedPACS008.setIncomingMessage(messageContent);
        String pacs008 = parseFileToXMLStringFormat();
        pacs008 = pacs008.replace(ORIGINAL_END_TO_END_ID_PLACEHOLDER, endToEndID);
        pacs008 = pacs008.replace(DESIRED_RESULT_PLACEHOLDER, "ADMI002");
        pacs008 = pacs008.replace(TXID, "QRS1-NIMWPGBSKEBFNIXIZLF5");
        incomingMessageDetail.setXml(pacs008);
        messageContent.add(incomingMessageDetail);
        return receiveRejectedPACS008;
    }

    public String parseFileToXMLStringFormat(){
        String xmlPACS008 = DocumentConverterUtil.convertFileToString(PACS_008);
        return xmlPACS008;
    }

    public Map<String, String> setParamsEventStatus(String endToEndID) {

        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");

        Map<String, String> eventParam = new HashMap<>();
        eventParam.put("startTimestampUtc", LocalDateTime.now().minusDays(1).format(dateTimeFormatter));
        eventParam.put("endTimestampUtc", LocalDateTime.now().plusDays(1).format(dateTimeFormatter));
        eventParam.put("correlationId", endToEndID);
        return eventParam;
    }
}
