package matera.spi.mainengine.validations.mainengine.piaccountmanagement;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.utils.Asserts;

import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;

public class PIAccountManagementValidations extends BaseAction {

    public void ValidREDA022response() throws Exception {
        Asserts.assertEquals(HttpStatus.SC_ACCEPTED, getStatusCode());
        Asserts.assertThat(getJsonValue("data.directorName"), Matchers.notNullValue());
        Asserts.assertThat(getJsonValue("data.directorEmail"), Matchers.is("director@mail.com"));
        Asserts.assertThat(getJsonValue("data.directorPhone"), Matchers.is("+55-6144444444"));
        Asserts.assertThat(getJsonValue("data.directorMobile"), Matchers.is("+55-613333333"));
        Asserts.assertThat(getJsonValue("data.passPhrase"), Matchers.is("12345678"));
        Asserts.assertThat(getJsonValue("data.directorTaxId"), Matchers.is("57533154029"));
        Asserts.assertThat(getJsonValue("data.employeeEmail"), Matchers.is("employee@mail.com"));
        Asserts.assertThat(getJsonValue("data.employeePhone"), Matchers.is("+55-14911223344"));
        Asserts.assertThat(getJsonValue("data.employeeMobile"), Matchers.is("+55-14900000000"));
        Asserts.assertThat(getJsonValue("data.employeeFax"), Matchers.is("+55-14911111111"));
        Asserts.assertThat(getJsonValue("data.status"), Matchers.is("WAITING_CONFIRMATION"));
    }

    public void ValidREDA016Response(int statusCode,
                                     String directorName,
                                     String validDirectorName,
                                     String passPhrase,
                                     String status) throws Exception {
        Asserts.assertEquals(statusCode, HttpStatus.SC_OK);
        Asserts.assertThat(directorName, Matchers.is(validDirectorName));
        Asserts.assertThat(passPhrase, Matchers.is("12345678"));
        Asserts.assertThat(status, Matchers.is("ACTIVE"));
    }

    public void InvalidREDA022response(String errorCode, String message) throws Exception {
        switch (getStatusCode()) {
            case 400:
                Asserts.assertEquals(HttpStatus.SC_BAD_REQUEST, getStatusCode());
                Asserts.assertThat(getJsonValue("error[0].code"), Matchers.equalTo(errorCode));
                Asserts.assertThat(getJsonValue("error[0].message"), Matchers.equalTo(message));
                break;
            case 500:
                Asserts.assertEquals(HttpStatus.SC_INTERNAL_SERVER_ERROR, getStatusCode());
                Asserts.assertThat(getJsonValue("error[0].code"), Matchers.equalTo(errorCode));
                Asserts.assertThat(getJsonValue("error[0].message"), Matchers.equalTo(message));
                break;
            default:
                break;
        }
    }

}
