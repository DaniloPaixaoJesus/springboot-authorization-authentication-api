package matera.spi.mainengine.validations.mainengine.infringementnotification;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.utils.Asserts;

import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;
import org.junit.Assert;

public class QueryForReceivementTypeTransactionsValidations extends BaseAction {

    public static final String PAYER_BRANCH = "6097";
    public static final String PAYER_ACCOUNT_NUMBER = "6722035";
    public static final String RECEIVER_BRANCH = "1";
    public static final String RECEIVER_ACCOUNT_NUMBER = "35";
    public static final String ORIGINAL_AMOUNT = "50.0";
    public static final String MAXIMUM_AMOUNT_RETURN = "50.0";

    public void validSuccessfullReceivementQueriedTransactionResponse(int statusCodeReceived,
                                                                      String payerBranch,
                                                                      String payerAccountNumber,
                                                                      String receiverBranch,
                                                                      String receiverAccountNumber,
                                                                      String originalAmount,
                                                                      String maximumAmountReturn,
                                                                      String effectiveSettlementDate,
                                                                      String eventType,
                                                                      String eventStatus) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodeReceived);
        Asserts.assertThat(payerBranch, Matchers.is(PAYER_BRANCH));
        Asserts.assertThat(payerAccountNumber, Matchers.is(PAYER_ACCOUNT_NUMBER));
        Asserts.assertThat(receiverBranch, Matchers.is(RECEIVER_BRANCH));
        Asserts.assertThat(receiverAccountNumber, Matchers.is(RECEIVER_ACCOUNT_NUMBER));
        Asserts.assertThat(originalAmount, Matchers.is(ORIGINAL_AMOUNT));
        Asserts.assertThat(maximumAmountReturn, Matchers.is(MAXIMUM_AMOUNT_RETURN));
        Asserts.assertThat(effectiveSettlementDate, Matchers.notNullValue());
        Asserts.assertThat(eventType, Matchers.is("RECEIPT"));
        Asserts.assertThat(eventStatus, Matchers.is("SUCCESS"));
    }

    public void validRejectedReceivementQueriedTransactionResponse(int statusCodeReceived,
                                                                   String originalAmount,
                                                                   String maximumAmountReturn,
                                                                   String effectiveSettlementDate,
                                                                   String eventType,
                                                                   String eventStatus) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodeReceived);
        Asserts.assertThat(originalAmount, Matchers.is(ORIGINAL_AMOUNT));
        Asserts.assertThat(maximumAmountReturn, Matchers.is(MAXIMUM_AMOUNT_RETURN));
        Asserts.assertThat(effectiveSettlementDate, Matchers.notNullValue());
        Asserts.assertThat(eventType, Matchers.is("RECEIPT"));
        Asserts.assertThat(eventStatus, Matchers.is("RECEIPT_REJECTED_BY_CLEARING"));
    }

    public void validAdmi002ErrorReceivementQueriedTransactionResponse(int statusCodeReceived,
                                                                        String originalAmount,
                                                                        String maximumAmountReturn,
                                                                        String effectiveSettlementDate,
                                                                        String eventType,
                                                                        String eventStatus) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodeReceived);
        Asserts.assertThat(originalAmount, Matchers.is(ORIGINAL_AMOUNT));
        Asserts.assertThat(maximumAmountReturn, Matchers.is(MAXIMUM_AMOUNT_RETURN));
        Asserts.assertThat(effectiveSettlementDate, Matchers.notNullValue());
        Asserts.assertThat(eventType, Matchers.is("RECEIPT"));
        Asserts.assertThat(eventStatus, Matchers.is("ERROR"));
    }

    public void validAllReceivementTypeTransactionsQueriedTransactionResponse(int statusCodeReceived,
                                                                              String receivementTypeTransactionsList) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodeReceived);
        Asserts.assertNotNull("Validating returned data list", receivementTypeTransactionsList);
        Assert.assertTrue(receivementTypeTransactionsList.length() > 0);
    }
}
