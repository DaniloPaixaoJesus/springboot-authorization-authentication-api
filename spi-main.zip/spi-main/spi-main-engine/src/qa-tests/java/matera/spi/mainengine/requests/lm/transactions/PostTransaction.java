package matera.spi.mainengine.requests.lm.transactions;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.model.lm.TransactionModel;

import com.fasterxml.jackson.core.JsonProcessingException;

public class PostTransaction extends BaseAction {

    public TransactionModel validDeposit() throws JsonProcessingException {
        TransactionModel deposit = new TransactionModel();
        deposit.setValue(100.00);
        deposit.setIgnoreThresholdViolation(true);
        return deposit;
    }

    public TransactionModel validWithdraw() throws JsonProcessingException {
        TransactionModel withdraw = new TransactionModel();
        withdraw.setValue(1.00);
        withdraw.setIgnoreThresholdViolation(true);
        return withdraw;
    }

}
