package matera.spi.mainengine.utils;

import matera.spi.mainengine.commons.Paths;
import matera.spi.mainengine.properties.Settings;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import lombok.SneakyThrows;
import org.apache.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.given;

public class GenerateAccessToken {

    @SneakyThrows
    public String getKeycloakURL() {
        RestAssured.baseURI = ConfigReader.getPropertiesFile("keycloak.url");
        return RestAssured.baseURI;
    }

    public String getAccessToken() {

        Map<String, String> bearerTokenBody = requestBodyTest();

        String access_token =
            given().contentType(ContentType.URLENC)
                .formParams(bearerTokenBody)
                .when()
                .post(getKeycloakURL().concat(Paths.PATH_TOKEN_PASSWORD))
                .then()
                .statusCode(HttpStatus.SC_OK)
                .extract()
                .path("access_token");
        return access_token;
    }

    public Map<String, String> requestBodyTest() {

        Map<String, String> tokenPasswordBody = new HashMap<>();
        tokenPasswordBody.put("grant_type", "password");
        tokenPasswordBody.put("client_id", "MIP-Login");
        tokenPasswordBody.put("username", "matera");
        tokenPasswordBody.put("password", "matera");
        return tokenPasswordBody;
    }
}
