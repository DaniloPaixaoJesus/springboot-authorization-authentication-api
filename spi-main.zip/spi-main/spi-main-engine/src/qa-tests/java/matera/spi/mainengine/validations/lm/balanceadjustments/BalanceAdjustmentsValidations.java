package matera.spi.mainengine.validations.lm.balanceadjustments;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.utils.Asserts;

import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;

import static matera.spi.mainengine.stepdefinitions.lm.balanceajustments.BalanceAdjustmentFlow.balanceAfterAdjustment;
import static matera.spi.mainengine.stepdefinitions.lm.balanceajustments.BalanceAdjustmentFlow.balanceBeforeAdjustment;
import static matera.spi.mainengine.utils.Asserts.assertEquals;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

public class BalanceAdjustmentsValidations extends BaseAction {

    public void validateBalanceAdjustmentsResponse(int statusCodeBalance) throws Exception {
        assertEquals(HttpStatus.SC_OK, statusCodeBalance);
        Asserts.assertThat(Matchers.comparesEqualTo(balanceBeforeAdjustment), Matchers.notNullValue());
        Asserts.assertThat(Matchers.comparesEqualTo(balanceAfterAdjustment), Matchers.notNullValue());
        Asserts.assertThat(Matchers.comparesEqualTo(balanceBeforeAdjustment), is(Matchers.not(balanceAfterAdjustment)));
    }

    public void validateBalanceAdjustmentGetCredit(String eventId) throws Exception {
        assertEquals(HttpStatus.SC_OK, getStatusCode());
        Asserts.assertThat(getJsonValue("data.content[0].eventId"), Matchers.notNullValue());
        Asserts.assertThat(getJsonValue("data.content[0].eventId"), is(eventId));
        Asserts.assertThat(getJsonValue("data.content[0].transactionType"), is("CREDIT"));
        Asserts.assertThat(getJsonValue("data.content[0].status.code"), is("3"));
        Asserts.assertThat(getJsonValue("data.content[0].status.description"), is("Success"));
        Asserts.assertThat(Matchers.comparesEqualTo(balanceBeforeAdjustment), notNullValue());
        Asserts.assertThat(Matchers.comparesEqualTo(balanceAfterAdjustment), notNullValue());
        Asserts.assertThat(Matchers.comparesEqualTo(eventId), notNullValue());
        Asserts.assertThat(Matchers.comparesEqualTo(balanceBeforeAdjustment),
            Matchers.is(Matchers.not(balanceAfterAdjustment)));
    }

    public void validateBalanceAdjustmentGetDebit(String eventId) throws Exception {
        assertEquals(HttpStatus.SC_OK, getStatusCode());
        Asserts.assertThat(getJsonValue("data.content[0].eventId"), Matchers.notNullValue());
        Asserts.assertThat(getJsonValue("data.content[0].eventId"), is(eventId));
        Asserts.assertThat(getJsonValue("data.content[0].transactionType"), is("DEBIT"));
        Asserts.assertThat(getJsonValue("data.content[0].status.code"), is("3"));
        Asserts.assertThat(getJsonValue("data.content[0].status.description"), is("Success"));
        Asserts.assertThat(Matchers.comparesEqualTo(balanceBeforeAdjustment), notNullValue());
        Asserts.assertThat(Matchers.comparesEqualTo(balanceAfterAdjustment), notNullValue());
        Asserts.assertThat(Matchers.comparesEqualTo(eventId), notNullValue());
        Asserts.assertThat(Matchers.comparesEqualTo(balanceBeforeAdjustment),
            Matchers.is(Matchers.not(balanceAfterAdjustment)));
    }

    public void validateBalanceAdjustmentPost(String eventId) throws Exception {
        assertEquals(HttpStatus.SC_CREATED, getStatusCode());
        Asserts.assertThat(getJsonValue("data.eventUuid"), is(eventId));
    }

    public void validateBalanceAdjustmentGetList(String eventId) throws Exception {
        assertEquals(HttpStatus.SC_OK, getStatusCode());
        Asserts.assertThat(getJsonValue("data.content[0].eventId"), Matchers.notNullValue());
        Asserts.assertThat(getJsonValue("data.content[0].transactionId"), Matchers.notNullValue());
        Asserts.assertThat(getJsonValue("data.content[0].piAccountDatetime"), Matchers.notNullValue());
        Asserts.assertThat(getJsonValue("data.content[0].creationDatetime"), Matchers.notNullValue());
        Asserts.assertThat(getJsonValue("data.content[0].status.code"), is("3"));
        Asserts.assertThat(getJsonValue("data.content[0].status.description"), is("Success"));
    }
}
