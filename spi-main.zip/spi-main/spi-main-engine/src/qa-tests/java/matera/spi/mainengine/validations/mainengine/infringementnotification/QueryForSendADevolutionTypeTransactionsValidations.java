package matera.spi.mainengine.validations.mainengine.infringementnotification;

import matera.spi.mainengine.core.BaseAction;
import matera.spi.mainengine.requests.mainengine.payments.api.PACS008BodyPostSendedAPI;
import matera.spi.mainengine.utils.Asserts;
import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;
import org.junit.Assert;

public class QueryForSendADevolutionTypeTransactionsValidations extends BaseAction {

    public static final String RECEIVER_BRANCH = "6097";
    public static final String RECEIVER_ACCOUNT_NUMBER = "6722035";
    public static final String ORIGINAL_AMOUNT = "20.0";

    public void validSuccessfullDevolutionSentQueriedTransactionResponse(int statusCodeReceived,
                                                                            String payerBranch,
                                                                            String payerAccountNumber,
                                                                            String receiverBranch,
                                                                            String receiverAccountNumber,
                                                                            String originalAmount,
                                                                            String effectiveSettlementDate,
                                                                            String eventType,
                                                                            String eventStatus) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodeReceived);
        Asserts.assertThat(payerBranch, Matchers.is(PACS008BodyPostSendedAPI.VALID_PAYER_BRANCH));
        Asserts.assertThat(payerAccountNumber, Matchers.is(PACS008BodyPostSendedAPI.VALID_PAYER_ACCOUNT_NUMBER));
        Asserts.assertThat(receiverBranch, Matchers.is(RECEIVER_BRANCH));
        Asserts.assertThat(receiverAccountNumber, Matchers.is(RECEIVER_ACCOUNT_NUMBER));
        if(originalAmount.endsWith(".0")){
            Asserts.assertThat(originalAmount.concat("0"), Matchers.is("20.00"));
        }
        Asserts.assertThat(effectiveSettlementDate, Matchers.notNullValue());
        Asserts.assertThat(eventType, Matchers.is("RETURN_SENT"));
        Asserts.assertThat(eventStatus, Matchers.is("SUCCESS"));
    }

    public void validUpdatedOriginalPaymentAmountQueriedTransactionResponse(int statusCodeReceived,
                                                                            String correlationId,
                                                                            String endToEndId,
                                                                            String originalAmount,
                                                                            String maximumAmountReturn,
                                                                            String effectiveSettlementDate,
                                                                            String eventType,
                                                                            String eventStatus) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodeReceived);
        Asserts.assertThat(endToEndId, Matchers.is(correlationId));
        if(originalAmount.endsWith(".0")){
            Asserts.assertThat(originalAmount.concat("0"), Matchers.is("50.00"));
        }
        if(maximumAmountReturn.endsWith(".0")){
            Asserts.assertNotEquals(maximumAmountReturn.concat("0"), "50.00");
        }
        Asserts.assertThat(effectiveSettlementDate, Matchers.notNullValue());
        Asserts.assertThat(eventType, Matchers.is("RECEIPT"));
        Asserts.assertThat(eventStatus, Matchers.is("SUCCESS"));
    }

    public void validRejectedDevolutionSentQueriedTransactionResponse(int statusCodeReceived,
                                                                         String originalAmount,
                                                                         String effectiveSettlementDate,
                                                                         String eventType,
                                                                         String eventStatus) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodeReceived);
        if(originalAmount.endsWith(".0")){
            Asserts.assertThat(originalAmount.concat("0"), Matchers.is("20.00"));
        }
        Asserts.assertThat(effectiveSettlementDate, Matchers.notNullValue());
        Asserts.assertThat(eventType, Matchers.is("RETURN_SENT"));
        Asserts.assertThat(eventStatus, Matchers.is("RETURN_REJECTED"));
    }


    public void validADMI002ErrorDevolutionReceiptQueriedTransactionResponse(int statusCodeReceived,
                                                                             String originalAmount,
                                                                             String effectiveSettlementDate,
                                                                             String eventType,
                                                                             String eventStatus) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodeReceived);
        if(originalAmount.endsWith(".0")){
            Asserts.assertThat(originalAmount.concat("0"), Matchers.is("20.00"));
        }
        Asserts.assertThat(effectiveSettlementDate, Matchers.notNullValue());
        Asserts.assertThat(eventType, Matchers.is("RETURN_SENT"));
        Asserts.assertThat(eventStatus, Matchers.is("ERROR"));

    }

    public void validNotUpdatedOriginalPaymentAmountQueriedTransactionResponse(int statusCodeReceived,
                                                                               String correlationId,
                                                                               String endToEndId,
                                                                               String originalAmount,
                                                                               String maximumAmountReturn,
                                                                               String effectiveSettlementDate,
                                                                               String eventType,
                                                                               String eventStatus) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodeReceived);
        Asserts.assertThat(endToEndId, Matchers.is(correlationId));
        if(originalAmount.endsWith(".0")){
            Asserts.assertThat(originalAmount.concat("0"), Matchers.is("50.00"));
        }
        if(maximumAmountReturn.endsWith(".0")){
            Asserts.assertEquals(maximumAmountReturn.concat("0"), "50.00");
        }
        Asserts.assertThat(effectiveSettlementDate, Matchers.notNullValue());
        Asserts.assertThat(eventType, Matchers.is("RECEIPT"));
        Asserts.assertThat(eventStatus, Matchers.is("SUCCESS"));
    }

    public void validAllSendADevolutionTypeTransactionsQueriedTransactionResponse(int statusCodeReceived,
                                                                                  String ReceiveADevolutionTypeTransactionsList) throws Exception {
        Asserts.assertEquals(HttpStatus.SC_OK, statusCodeReceived);
        Asserts.assertNotNull("Validating returned data list", ReceiveADevolutionTypeTransactionsList);
        Assert.assertTrue(ReceiveADevolutionTypeTransactionsList.length() > 0);
    }
}
