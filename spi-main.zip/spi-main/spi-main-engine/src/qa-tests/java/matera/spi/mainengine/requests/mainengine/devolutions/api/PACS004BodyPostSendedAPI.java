package matera.spi.mainengine.requests.mainengine.devolutions.api;

import matera.spi.mainengine.model.mainengine.devolutions.api.SendedDevolutionModelAPI;
import matera.spi.mainengine.utils.GenerateEndToEndID;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

public class PACS004BodyPostSendedAPI {

    public static final String VALID_ORIGIN_SYSTEM = "matera";
    public static final String VALID_RETURNED_AMOUNT = "20.00";
    public static final String VALID_ADDITIONAL_INFORMATION = "Return sent bank 000000000";
    public static final String VALID_RETURN_REASON_CODE = "AM05";
    public static final String DESIRED_RESULT_KEY = "desiredResult";
    public static final String DESIRED_RESULT_VALUE_SUCCESS = "SUCCESS";
    public static final String DESIRED_RESULT_VALUE_REJECT = "REJECT";
    public static final String VALID_RETURN_REASON_INFORMATION = "{\""+DESIRED_RESULT_KEY+"\":\""+DESIRED_RESULT_VALUE_SUCCESS+"\"}";
    public static final String REJECT_RETURN_REASON_INFORMATION = "{\""+DESIRED_RESULT_KEY+"\":\""+DESIRED_RESULT_VALUE_REJECT+"\"}";
    public static final String VALID_INFORMATION_ACCOUNT_HOLDER = "adding informationAccountHolder field test";

    GenerateEndToEndID generateEndToEndID = new GenerateEndToEndID();
    String EndToEndID = generateEndToEndID.EndToEndID();

    public SendedDevolutionModelAPI validPACS004API(){
        SendedDevolutionModelAPI sendedDevolutionModelAPI = new SendedDevolutionModelAPI();
        sendedDevolutionModelAPI.setOriginSystem(VALID_ORIGIN_SYSTEM);
        sendedDevolutionModelAPI.setReturnedAmount(VALID_RETURNED_AMOUNT);
        sendedDevolutionModelAPI.setAdditionalInformation(VALID_ADDITIONAL_INFORMATION);
        sendedDevolutionModelAPI.setReturnReasonCode(VALID_RETURN_REASON_CODE);
        sendedDevolutionModelAPI.setReturnReasonInformation(VALID_RETURN_REASON_INFORMATION);
        sendedDevolutionModelAPI.setInformationAccountHolder(VALID_INFORMATION_ACCOUNT_HOLDER);
        return sendedDevolutionModelAPI;
    }

    public String getEndToEndID() {
        return EndToEndID;
    }

    public Map<String, String> setParamsEventStatus(String eventId) {

        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");

        Map<String, String> eventParam = new HashMap<>();
        eventParam.put("startTimestampUtc", LocalDateTime.now().minusDays(1).format(dateTimeFormatter));
        eventParam.put("endTimestampUtc", LocalDateTime.now().plusDays(1).format(dateTimeFormatter));
        eventParam.put("eventId", eventId);
        return eventParam;
    }
}
