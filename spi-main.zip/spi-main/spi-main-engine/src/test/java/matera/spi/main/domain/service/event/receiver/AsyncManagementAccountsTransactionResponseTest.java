package matera.spi.main.domain.service.event.receiver;

import matera.spi.dto.EntryReply;
import matera.spi.dto.StandinReplyContract;
import matera.spi.main.domain.service.AsyncManagementAccountsService;
import matera.spi.utils.JsonService;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.messaging.support.GenericMessage;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class AsyncManagementAccountsTransactionResponseTest {

    @Spy
    private final JsonService jsonService = new JsonService(new ObjectMapper());

    @Mock
    private AsyncManagementAccountsService asyncManagementAccountsService;

    @Spy
    private ObjectMapper objectMapper = new ObjectMapper();

    @InjectMocks
    private AsyncManagementAccountsTransactionResponse asyncManagementAccountsTransactionResponse;

    @Test
    void shouldReceivedTheMessageAndCallTheProcessItemMethodWhenMessageIsNotEmpty() throws JsonProcessingException {
        StandinReplyContract standinReplyContract = new StandinReplyContract();
        List<EntryReply> entries = List.of(new EntryReply(), new EntryReply());
        standinReplyContract.setEntries(entries);
        String message = createMessage(standinReplyContract);
        asyncManagementAccountsTransactionResponse.onMessage(new GenericMessage<>(message));

        verify(asyncManagementAccountsService, times(2)).processItem(eq(entries.get(0)));
    }

    @Test
    void shouldReceivedTheMessageAndNotCallTheProcessItemMethodWhenMessageIsEmpty() throws JsonProcessingException {
        StandinReplyContract standinReplyContract = new StandinReplyContract();
        standinReplyContract.setEntries(List.of());
        String message = createMessage(standinReplyContract);
        asyncManagementAccountsTransactionResponse.onMessage(new GenericMessage<>(message));

        verify(asyncManagementAccountsService, never()).processItem(any(EntryReply.class));
    }

    private String createMessage(StandinReplyContract standinReplyContract) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.writeValueAsString(standinReplyContract);
    }

}

