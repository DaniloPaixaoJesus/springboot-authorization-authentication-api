package matera.spi.main.rest.ui;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.EmailNotificationEntity;
import matera.spi.main.persistence.EmailNotificationRepository;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;

import java.time.LocalDateTime;

@IntegrationTest
public class EmailNotificationApiDelegateImplTest {

    public static final String IDENTIFICATION_001 = "identification001";
    public static final String EMAIL_001 = "email001@email.com.br";
    public static final String NO_CONTENT_UUID = "11111111-1111-1111-1111-111111111111";
    @Autowired
    private EmailNotificationRepository emailNotificationRepository;
    private static final String BASE_URI = "/ui/v1/email/notification";

    @LocalServerPort
    private int port;

    @BeforeEach
    void beforeEach() {
        RestAssured.port = port;
        emailNotificationRepository.deleteAll();
    }

    @AfterEach
    void afterEach() {
        emailNotificationRepository.deleteAll();
    }

    @Test
    void shouldCreateEmailNotification() {
        String identification = IDENTIFICATION_001;
        String email = EMAIL_001;
        RestAssured.given()
            .contentType(ContentType.JSON)
            .body(generateEmailNotificationJson(null, identification, email))
            .when().post(BASE_URI)
            .then()
            .log().all()
            .assertThat()
            .statusCode(HttpStatus.SC_CREATED)
            .body("data.identification", Matchers.equalTo(identification))
            .body("data.email", Matchers.equalTo(email));
    }

    @Test
    void shouldReturnAllEmailNotification() {
        EmailNotificationEntity emailNotification  = createEmailNotification();

        RestAssured.given()
                .header("pageSize", "1")
                .header("pageNumber", "0")
                .when().get(BASE_URI)
                .then()
                .log().all()
                .assertThat()
                .statusCode(HttpStatus.SC_OK)
                .body("data.content[0].identification", Matchers.equalTo(emailNotification.getIdentification()))
                .body("data.content[0].email", Matchers.equalTo(emailNotification.getEmail()));

    }

    @Test
    void shouldUpdateEmailNotification() {
        EmailNotificationEntity emailNotification  = createEmailNotification();

        String identification = IDENTIFICATION_001;
        String email = EMAIL_001;

        RestAssured.given()
            .contentType(ContentType.JSON)
            .body(generateEmailNotificationJson(emailNotification.getUuid().toString(), identification, email))
            .when().post(BASE_URI+"/"+emailNotification.getUuid().toString())
            .then()
            .log().all()
            .assertThat()
            .statusCode(HttpStatus.SC_OK)
            .body("data.identification", Matchers.equalTo(identification))
            .body("data.email", Matchers.equalTo(email));

    }

    @Test
    void shouldReturnEmailNotification() {
        EmailNotificationEntity emailNotification  = createEmailNotification();

        RestAssured.given()
            .when().get(BASE_URI+"/"+emailNotification.getUuid().toString())
            .then()
            .log().all()
            .assertThat()
            .statusCode(HttpStatus.SC_OK)
            .body("data.identification", Matchers.equalTo(emailNotification.getIdentification()))
            .body("data.email", Matchers.equalTo(emailNotification.getEmail()));

    }

    @Test
    void shouldReturnNoContentIfEmailNotificationNotFound() {
        RestAssured.given()
            .when().get(BASE_URI + "/" + NO_CONTENT_UUID)
            .then()
            .log().all()
            .assertThat()
            .statusCode(HttpStatus.SC_NO_CONTENT);
    }

    private EmailNotificationEntity createEmailNotification() {
        EmailNotificationEntity emailNotificationEntity = new EmailNotificationEntity();
        emailNotificationEntity.setEmail("email@email.com");
        emailNotificationEntity.setIdentification("name identification");
        emailNotificationEntity.setDateTimeRegister(LocalDateTime.now());
        emailNotificationRepository.saveAndFlush(emailNotificationEntity);
        return emailNotificationEntity;
    }

    private String generateEmailNotificationJson(String id, String identification, String email) {
        String idStr = "\"id\": \""+id+"\",";
        if (id == null) {
            idStr = "";
        }
        return "{" +
                    idStr +
                    "\"identification\": \""+identification+"\"," +
                   "\"email\": \""+email+"\"" +
               "}";
    }

}
