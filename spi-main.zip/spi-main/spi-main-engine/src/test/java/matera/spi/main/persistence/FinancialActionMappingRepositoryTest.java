package matera.spi.main.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.message.FinancialActionMappingEntity;
import matera.spi.main.domain.model.message.FinancialActionMappingPK;
import matera.spi.main.domain.model.message.MessageTypeEntity;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

@IntegrationTest
class FinancialActionMappingRepositoryTest  {

    @Autowired
    private FinancialActionMappingRepository repository;

    @Autowired
    private MessageTypeRepository messageTypeRepository;

    @Test
    void shouldBeFindEntityWhenInserted() {
        FinancialActionMappingEntity expected = new FinancialActionMappingEntity();
        expected.setId(buildPK());
        expected.setFinancialAction("Financ Action Test");
    }

    private FinancialActionMappingPK buildPK() {
        FinancialActionMappingPK pk = new FinancialActionMappingPK();
        pk.setMessageTypeEntity(buildMessageTypeEntity());
        pk.setReportedStatus("Reported STS Test");
        return pk;
    }
    private MessageTypeEntity buildMessageTypeEntity() {
        MessageTypeEntity entity = new MessageTypeEntity();
        entity.setCode("MessageCodeTest");
        entity.setIsFinancial(false);

        messageTypeRepository.saveAndFlush(entity);

        return  entity;
    }
}
