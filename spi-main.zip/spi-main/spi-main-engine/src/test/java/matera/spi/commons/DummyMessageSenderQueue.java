package matera.spi.commons;

import matera.spi.main.domain.service.MessageSenderQueue;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@ConditionalOnProperty(prefix = "matera.messaging", name = "enabled", havingValue = "false")
public class DummyMessageSenderQueue<T> implements MessageSenderQueue<T> {

    @Override
    public void send(String queue, T messageDto ) {
        log.warn("Message sender queue disabled");
    }

}
