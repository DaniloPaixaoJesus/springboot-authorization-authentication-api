package matera.spi.lm.rest.ispbApiController;

import matera.spi.dto.IspbQueryDTO;
import matera.spi.dto.IspbQueryListResponseDTO;

import org.apache.commons.lang.math.NumberUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import java.util.Arrays;
import java.util.List;

import static java.lang.Boolean.TRUE;

@ActiveProfiles("indirects")
public class IndirectIspbApiControllerTest extends AbstractIspbApiControllerTest {

    private static final String EXPECTED_DIRECT_ISPB_NAME = "BPP IP S.A.";
    private static final String EXPECTED_DIRECT_ISPB = "13370835";
    private static final Boolean EXPECTED_DIRECT_IS_LOCAL_ISPB = TRUE;

    @Test
    void givenIndirectParticipantThenShouldReturnListThatContainOnlyNameAndIspbFromSearchedBank() {
        final List<IspbQueryDTO> expectedIspbQueryDTOList = buildExpectedIspbQueryDTOList();
        final IspbQueryListResponseDTO ispbListResponse = executeRequest();

        Assertions.assertNotNull(ispbListResponse);
        final List<IspbQueryDTO> ispbList = ispbListResponse.getData();
        Assertions.assertEquals(NumberUtils.INTEGER_ONE, ispbList.size());
        Assertions.assertArrayEquals(expectedIspbQueryDTOList.toArray(), ispbList.toArray());
    }

    private List<IspbQueryDTO> buildExpectedIspbQueryDTOList() {
        final IspbQueryDTO indirectIspbQueryDTO = buildIspbQueryDTO(EXPECTED_DIRECT_ISPB_NAME, EXPECTED_DIRECT_ISPB, EXPECTED_DIRECT_IS_LOCAL_ISPB);

        return Arrays.asList(indirectIspbQueryDTO);
    }
}
