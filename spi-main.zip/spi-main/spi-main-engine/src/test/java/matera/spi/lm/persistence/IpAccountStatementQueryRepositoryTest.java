package matera.spi.lm.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.lm.domain.model.event.IpAccountStatementQueryDetailsEntity;
import matera.spi.lm.domain.model.event.IpAccountStatementQueryEventEntity;
import matera.spi.main.domain.model.event.EventStatusEntity;
import matera.spi.main.domain.model.event.EventTypeEntity;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.EventStatusRepository;
import matera.spi.main.persistence.EventTypeRepository;
import matera.spi.utils.LocalDateTimeUtils;

import com.mysql.cj.exceptions.AssertionFailedException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.test.annotation.Commit;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.core.Is.is;

@IntegrationTest
@Transactional
@Commit
class IpAccountStatementQueryRepositoryTest  {

    private static final String CORRELATION1 = "E123";
    private static final String CORRELATION2 = "E456";
    private static final String CORRELATION3 = "E789";

    @Autowired
    private EventRepository eventRepository;

    @Autowired
    private EventStatusRepository eventStatusRepository;

    @Autowired
    private EventTypeRepository eventTypeRepository;

    @Autowired
    private IpAccountStatementQueryDetailsRepository ipAccountStatementQueryDetailsRepository;

    @BeforeEach
    void beforeEach() {
        createStatements();
    }

    @AfterEach
    void afterEach() {
        eventRepository.deleteAll();
    }

    @Test
    void shouldReturnTwoRows() {
        LocalDateTime startDateTime = LocalDateTime.of(2020, 6, 10, 9, 0, 0);
        LocalDateTime endDateTime = LocalDateTime.of(2020, 6, 10, 11, 0, 0);

        Page<IpAccountStatementQueryDetailsEntity> detailsPaged =
            ipAccountStatementQueryDetailsRepository.findByParams(getPageable(), startDateTime, endDateTime);

        List<IpAccountStatementQueryDetailsEntity> content = detailsPaged.getContent(); // Without order by, we cannot garantee it comes in a determinstic fashion
        content = content.stream()
                         .sorted(Comparator.comparing(x -> x.getIpAccountStatementQueryEventEntity().getCorrelationId()))
                         .collect(Collectors.toList());

        assertThat(content, hasSize(2));
        assertThat(content.get(0).getIpAccountStatementQueryEventEntity().getCorrelationId(), is(CORRELATION1));
        assertThat(content.get(1).getIpAccountStatementQueryEventEntity().getCorrelationId(), is(CORRELATION2));
    }

    @Test
    void shouldReturnAllRows() {
        LocalDateTime startDateTime = LocalDateTime.of(2020, 6, 10, 9, 0, 0);
        LocalDateTime endDateTime = LocalDateTime.of(2020, 6, 10, 14, 0, 0);

        Page<IpAccountStatementQueryDetailsEntity> detailsPaged =
            ipAccountStatementQueryDetailsRepository.findByParams(getPageable(), startDateTime, endDateTime);

        assertThat(detailsPaged.getContent(), hasSize(3));
    }

    @Test
    void shouldReturnOneRowFilterBetweenStatement() {
        LocalDateTime startDateTime = LocalDateTime.of(2020, 6, 10, 14, 0, 0);
        LocalDateTime endDateTime = LocalDateTime.of(2020, 6, 10, 18, 0, 0);

        Page<IpAccountStatementQueryDetailsEntity> detailsPaged =
            ipAccountStatementQueryDetailsRepository.findByParams(getPageable(), startDateTime, endDateTime);

        List<IpAccountStatementQueryDetailsEntity> content = detailsPaged.getContent();

        assertThat(content, hasSize(1));
        assertThat(content.get(0).getIpAccountStatementQueryEventEntity().getCorrelationId(), is(CORRELATION3));
    }

    @Test
    void shouldReturnNoneRowsBecauseDateIsUpper() {
        LocalDateTime startDateTime = LocalDateTime.of(2020, 6, 20, 9, 0, 0);
        LocalDateTime endDateTime = LocalDateTime.of(2020, 6, 20, 11, 0, 0);

        Page<IpAccountStatementQueryDetailsEntity> detailsPaged =
            ipAccountStatementQueryDetailsRepository.findByParams(getPageable(), startDateTime, endDateTime);

        List<IpAccountStatementQueryDetailsEntity> content = detailsPaged.getContent();

        assertThat(content, hasSize(0));
    }

    private PageRequest getPageable() {
        return PageRequest.of(0, 10, Sort.by("creationDateTime"));
    }

    private void createStatements() {
        EventStatusEntity eventStatus =
            eventStatusRepository.findById(1).orElseThrow(() -> new AssertionFailedException("Not found EventStatus"));

        EventTypeEntity eventType =
            eventTypeRepository.findById(1).orElseThrow(() -> new AssertionFailedException("Not found EventType"));

        LocalDateTime start1 = LocalDateTime.of(2020, 6, 9, 22, 5, 2);
        LocalDateTime end1 = LocalDateTime.of(2020, 6, 10, 9, 35, 2);

        LocalDateTime start2 = LocalDateTime.of(2020, 6, 10, 8, 0, 0);
        LocalDateTime end2 = LocalDateTime.of(2020, 6, 10, 11, 0, 0);

        LocalDateTime start3 = LocalDateTime.of(2020, 6, 10, 12, 0, 0);
        LocalDateTime end3 = LocalDateTime.of(2020, 6, 11, 1, 0, 0);

        createEvent(eventStatus, eventType, start1, end1, CORRELATION1);
        createEvent(eventStatus, eventType, start2, end2, CORRELATION2);
        createEvent(eventStatus, eventType, start3, end3, CORRELATION3);
    }

    private void createEvent(EventStatusEntity eventStatus,
                             EventTypeEntity eventType,
                             LocalDateTime startDatetime,
                             LocalDateTime endDatetime,
                             String correlationId) {
        IpAccountStatementQueryEventEntity eventEntity = new IpAccountStatementQueryEventEntity();
        eventEntity.setCorrelationId(correlationId);
        eventEntity.setClearingTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
        eventEntity.setInitiationTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
        eventEntity.setResponsible(UUID.randomUUID().toString());
        eventEntity.setInitiatorIspb(12345);
        eventEntity.setValue(BigDecimal.ONE);
        eventEntity.setEventTypeEntity(eventType);
        eventEntity.setStatus(eventStatus);

        IpAccountStatementQueryDetailsEntity detailsEntity = new IpAccountStatementQueryDetailsEntity();
        detailsEntity.setAdditionalReportInformation("Additional Rpt Information");
        detailsEntity.setCreationDateTime(LocalDateTimeUtils.getUtcLocalDateTime());
        detailsEntity.setFileUri("FileURI");
        detailsEntity.setNumberOfEntries(250);
        detailsEntity.setStartTimestampUtc(startDatetime);
        detailsEntity.setEndTimestampUtc(endDatetime);
        detailsEntity.setIpAccountStatementQueryEventEntity(eventEntity);

        ipAccountStatementQueryDetailsRepository.save(detailsEntity);
    }

}
