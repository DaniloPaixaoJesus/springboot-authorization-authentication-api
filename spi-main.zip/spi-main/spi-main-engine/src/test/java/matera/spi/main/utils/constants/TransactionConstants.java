package matera.spi.main.utils.constants;

public class TransactionConstants {

    private TransactionConstants() {/* Constatnt class should not be instantiated*/}

    /* Receipt */
    public static final String RECEIVER_TAX_ID = "3210";
    public static final String RECEIVER_BRANCH = "4321";
    public static final String RECEIVER_ACCOUNT = "55566677";
    public static final String RECEIVER_ADDRESSING_KEY = "teste@teste.com";
    public static final String RECEIVER_ADDITIONAL_INFORMATION = "Additional Information test for Receiver";
    public static final String RECEIVER_RECON_IDENTIFIER = "Receiver Recon Teste";
    public static final Long RECEIPT_INITIATING_INSTITUTION_TAX_ID = 50171215000143L;

    /* Receipt- TransactionPriorityEntity - */
    public static final String TRANSACTION_PRIORITY_ENTITY_CODE_FOR_RECEIPT = "1000";
    public static final String TRANSACTION_PRIORITY_ENTITY_DESCRIPTION_FOR_RECEIPT = "Priority Test for Receipt";

    /* Receipt - Participants */
    public static final Integer PAYER_PARTICIPANT_ENTITY_ISPB_FOR_RECEIPT = 78945;
    public static final String RECEIVER_PARTICIPANT_ENTITY_NAME_FOR_RECEIPT = "Receiver Participant for Receipt";
    public static final Integer RECEIVER_PARTICIPANT_ENTITY_ISPB_FOR_RECEIPT = 13370835;
    public static final String PAYER_PARTICIPANT_ENTITY_NAME_FOR_RECEIPT = "Payer Participant for Receipt";

    /* Payments */
    public static final String PAYER_TAX_ID = "1230";
    public static final String PAYER_NAME = "PAYER NAME";
    public static final String PAYER_BRANCH = "1234";
    public static final String PAYER_ACCOUNT = "22233344";
    public static final String PAYER_RECON_IDENTIFIER = "Payer Recon Teste";
    public static final String PAYMENT_ADDITIONAL_INFORMATION = "Additional Information test for Payment";
    public static final Long PAYER_INITIATING_INSTITUTION_TAX_ID = 47450396000132L;

    /* Payment- TransactionPriorityEntity */
    public static final String TRANSACTION_PRIORITY_ENTITY_CODE_FOR_PAYMENT = "1001";
    public static final String TRANSACTION_PRIORITY_ENTITY_DESCRIPTION_FOR_PAYMENT = "Priority Test for Payment";

    /* Payments - Participants */
    public static final Integer PAYER_PARTICIPANT_ENTITY_ISPB_FOR_PAYMENT = 75395;
    public static final String PAYER_PARTICIPANT_ENTITY_NAME_FOR_PAYMENT = "Payer Participant for Payment";
    public static final Integer RECEIVER_PARTICIPANT_ENTITY_ISPB_FOR_PAYMENT = 74185;
    public static final String RECEIVER_PARTICIPANT_ENTITY_NAME_FOR_PAYMENT = "Receiver Participant for Payment";

    /* AccountTypeEntity */
    public static final String ACCOUNT_TYPE_CODE = "ABCD";
    public static final String ACCOUNT_TYPE_DESCRIPTION = "Account Type";
}
