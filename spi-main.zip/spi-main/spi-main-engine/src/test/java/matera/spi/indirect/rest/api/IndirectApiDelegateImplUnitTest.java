package matera.spi.indirect.rest.api;

import matera.spi.dto.IndirectParticipantDTO;
import matera.spi.dto.IndirectParticipantInformationResponseDTO;
import matera.spi.indirect.application.service.IndirectParticipantAPIImpl;
import matera.spi.indirect.domain.model.ParticipantMipIndirectEntity;
import matera.spi.indirect.application.service.mapper.ParticipantMipIndirectMapper;
import matera.spi.indirect.persistence.ParticipantMipIndirectStatusRepository;
import matera.spi.indirect.util.ParticipantMipIndirectDataSetUtil;

import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class IndirectApiDelegateImplUnitTest {

    private static final int OK_HTTP_STATUS_CODE = 200;
    private static final int NO_CONTENT_HTTP_STATUS_CODE = 204;

    @Mock
    private IndirectParticipantAPIImpl indirectApiApplicationService;

    @InjectMocks
    private IndirectApiDelegateImpl indirectApiDelegate;

    @Mock
    private ParticipantMipIndirectStatusRepository participantMipIndirectStatusRepository;

    @Mock
    private HttpServletRequest httpServletRequest;

    @Mock
    private HttpServletResponse httpServletResponse;

    @ParameterizedTest
    @MethodSource("truthTable")
    void shouldFindIndirectCompleteInfo(boolean statusArgument, boolean showCanceledIndirects) {
        final IndirectParticipantDTO indirectParticipantDTO = prepareTest(statusArgument);

        final List<IndirectParticipantDTO> listToMock = Arrays.asList(indirectParticipantDTO);

        doReturn(listToMock).when(indirectApiApplicationService)
            .findIndirectCompleteInfo(eq(ParticipantMipIndirectDataSetUtil.ISPB), eq(statusArgument), eq(showCanceledIndirects));

        final IndirectParticipantInformationResponseDTO indirectCompleteInfo =
            indirectApiDelegate
                .findIndirectCompleteInfo(ParticipantMipIndirectDataSetUtil.ISPB, statusArgument, showCanceledIndirects, httpServletRequest,
                    httpServletResponse);

        verify(indirectApiApplicationService)
            .findIndirectCompleteInfo(eq(ParticipantMipIndirectDataSetUtil.ISPB), eq(statusArgument), eq(showCanceledIndirects));

        assertNotNull(indirectCompleteInfo);

        assertEquals(listToMock, indirectCompleteInfo.getIndirectParticipants());

    }

    @ParameterizedTest
    @MethodSource("truthTable")
    void shouldReturnNoContent(boolean statusArgument, boolean showCanceledIndirects) {
        final IndirectParticipantInformationResponseDTO indirectCompleteInfo =
            indirectApiDelegate
                .findIndirectCompleteInfo(ParticipantMipIndirectDataSetUtil.ISPB, statusArgument, showCanceledIndirects, httpServletRequest,
                    httpServletResponse);

        verify(indirectApiApplicationService)
            .findIndirectCompleteInfo(eq(ParticipantMipIndirectDataSetUtil.ISPB), eq(statusArgument), eq(showCanceledIndirects));
        assertNotNull(indirectCompleteInfo);

        assertThat(indirectApiApplicationService
            .findIndirectCompleteInfo(ParticipantMipIndirectDataSetUtil.ISPB, statusArgument, showCanceledIndirects)).hasSize(0);

    }

    private IndirectParticipantDTO prepareTest(boolean statusArgument) {
        doReturn(Optional.of(ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectStatusEntity()))
            .when(participantMipIndirectStatusRepository).findById(Mockito.any());

        final ParticipantMipIndirectEntity participantMipIndirectEntity = ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                ParticipantMipIndirectDataSetUtil.createParticipantMip());

        return ParticipantMipIndirectMapper.mapEntityToIndirectParticipantDTO(participantMipIndirectEntity);
    }

    private static Stream<Arguments> truthTable() {
        return Stream.of(
            Arguments.of(true, true),
            Arguments.of(true, false),
            Arguments.of(false, true),
            Arguments.of(false, false)
        );
    }

}
