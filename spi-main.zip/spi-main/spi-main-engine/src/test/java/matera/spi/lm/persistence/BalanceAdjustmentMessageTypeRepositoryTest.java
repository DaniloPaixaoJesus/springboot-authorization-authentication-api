package matera.spi.lm.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.lm.domain.model.BalanceAdjustmentMessageTypeEntity;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Commit;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static matera.spi.dto.BalanceAdjustmentDTO.TransactionTypeEnum.CREDIT;
import static matera.spi.dto.BalanceAdjustmentDTO.TransactionTypeEnum.DEBIT;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasSize;

@Commit
@Transactional
@IntegrationTest
class BalanceAdjustmentMessageTypeRepositoryTest {

    @Autowired
    private BalanceAdjustmentMessageTypeRepository repository;

    @Test
    void testGetListCredit() {
        List<BalanceAdjustmentMessageTypeEntity> byTransactionType = repository.findByTransactionType(CREDIT.toString());

        assertThat(byTransactionType, hasSize(6));
    }

    @Test
    void testGetListDebit() {
        List<BalanceAdjustmentMessageTypeEntity> byTransactionType = repository.findByTransactionType(DEBIT.toString());

        assertThat(byTransactionType, hasSize(5));
    }

}
