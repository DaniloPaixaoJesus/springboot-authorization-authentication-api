package matera.spi.lm.domain.service.event;

import matera.spi.dto.DominioSistemaDTO;
import matera.spi.dto.SpbCallbackDTO;
import matera.spi.lm.application.service.LMEmailSenderService;
import matera.spi.lm.application.service.email.EmailBodyBuilder;
import matera.spi.lm.application.service.email.lpi0006.Lpi0006ErrorEmailBodyBuilder;
import matera.spi.lm.application.service.email.lpi0006.Lpi0006SuccessEmailBodyBuilder;
import matera.spi.lm.domain.model.IpAccountAutoDepositDetailsEntity;
import matera.spi.lm.domain.model.IpAccountAutoDepositEventEntity;
import matera.spi.lm.dto.IpAccountAutoDepositSpecificationDTO;
import matera.spi.lm.exception.SpbCallbackException;
import matera.spi.main.config.MainEngineConfiguration;
import matera.spi.main.domain.model.event.EventStatus;
import matera.spi.main.domain.model.transaction.TransactionResultEntity;
import matera.spi.main.domain.service.transaction.MirrorIPAccount;
import matera.spi.main.email.dto.EmailDTO;
import matera.spi.main.persistence.TransactionResultRepository;
import matera.spi.utils.LocalDateTimeUtils;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.util.collections.Sets;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Collections;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class IpAccountAutoDepositEventTest {

    @Mock
    private LMEmailSenderService lmEmailSenderService;

    @Mock
    private MirrorIPAccount mirrorIPAccount;

    @Mock
    private TransactionResultRepository transactionResultRepository;

    @Mock
    private MainEngineConfiguration mainEngineConfiguration;

    @Captor
    private ArgumentCaptor<EventStatus> eventStatusArgumentCaptor;

    @Captor
    private ArgumentCaptor<EmailBodyBuilder> emailBodyBuilderArgumentCaptor;

    @InjectMocks
    private IpAccountAutoDepositEvent ipAccountAutoDepositEvent;

    @Test
    void shouldSetDetailsInEventEntity() {
        IpAccountAutoDepositEvent subject = new IpAccountAutoDepositEvent(buildEventEntity());

        IpAccountAutoDepositSpecificationDTO specification = buildIpAccountAutoDepositSpecificationDTO();
        subject.fillSpecializedEventEntityAttributesFromEventSpecification(specification);

        assertThat(subject.getEventEntity())
            .isNotNull()
            .satisfies(entity -> {
                assertThat(entity.getMovementDate()).isEqualTo(specification.getMovementDate());
                assertThat(entity.getControlNumber()).isEqualTo(specification.getNumCtrl());
                assertThat(entity.getIpAccountAutoDepositDetailsEntity())
                    .isNotNull()
                    .satisfies(details -> {
                        assertThat(details.getSituation()).isEqualTo(specification.getSituation());
                        assertThat(details.getTransactionTimestampUtc()).isEqualTo(specification.getTransactionTimestampUtc());
                    });
            });
    }

    @Test
    void shouldSaveEventStatusAndEmailsOnError() {
        IpAccountAutoDepositEvent spyEvent = initAutoEventMocks();

        doReturn(true).when(mainEngineConfiguration).isSendEmailActivated();

        IpAccountAutoDepositDetailsEntity detailsEntity =
            spyEvent.getEventEntity().getIpAccountAutoDepositDetailsEntity();
        assertThrows(SpbCallbackException.class, () -> spyEvent.actionsOnSpbReturn(createSpbCallbackDTO(5)));

        verify(lmEmailSenderService, times(1)).sendEmail(any(), emailBodyBuilderArgumentCaptor.capture());

        assertThat(emailBodyBuilderArgumentCaptor.getValue()).isInstanceOf(Lpi0006ErrorEmailBodyBuilder.class);
        assertThat(detailsEntity.getReceivers()).isEqualTo("email@domain.com");
    }

    @Test
    void shouldSaveEmailsOnSuccess() {
        IpAccountAutoDepositEvent spyEvent = initAutoEventMocks();

        doReturn(true).when(mainEngineConfiguration).isSendEmailActivated();

        spyEvent.actionsOnSpbReturn(createSpbCallbackDTO(7));
        IpAccountAutoDepositDetailsEntity detailsEntity =
            spyEvent.getEventEntity().getIpAccountAutoDepositDetailsEntity();

        verify(lmEmailSenderService, times(1)).sendEmail(any(), emailBodyBuilderArgumentCaptor.capture());

        assertThat(detailsEntity.getReceivers()).isEqualTo("email@domain.com");
        assertThat(emailBodyBuilderArgumentCaptor.getValue()).isInstanceOf(Lpi0006SuccessEmailBodyBuilder.class);
    }

    private IpAccountAutoDepositEvent initAutoEventMocks() {
        TransactionResultEntity transactionResultEntity = buildTransactionResultEntity();
        this.ipAccountAutoDepositEvent = spy(new IpAccountAutoDepositEvent(buildEventEntity()));

        MockitoAnnotations.initMocks(this);

        lenient().doReturn(transactionResultEntity).when(mirrorIPAccount).makeCredit(any(), any());
        lenient().doReturn(transactionResultEntity).when(transactionResultRepository).save(any());
        doNothing().when(ipAccountAutoDepositEvent).fireStatusTransition(any(EventStatus.class));
        doNothing().when(ipAccountAutoDepositEvent).save();
        when(lmEmailSenderService.sendEmail(any(), any())).thenReturn(createEmailDTO());

        return ipAccountAutoDepositEvent;
    }

    private TransactionResultEntity buildTransactionResultEntity() {
        final TransactionResultEntity transactionResultEntity = new TransactionResultEntity();
        transactionResultEntity.setId(UUID.randomUUID());
        transactionResultEntity.setTransactionIdInDdaSystem(BigDecimal.valueOf(200D));
        return transactionResultEntity;
    }

    private SpbCallbackDTO createSpbCallbackDTO(Integer situacaoNm) {
        return new SpbCallbackDTO()
            .tipoEvento("TP")
            .sistemaOrigem("SistemaOrigem")
            .dataHoraResposta(LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME))
            .numEmpresa(1234)
            .numEmpresaContraparte(12.5F)
            .operacaoOrigemId1("Or1")
            .operacaoOrigemId2("Or2")
            .tipoTransacaoOrigem("TpTransaction")
            .situacaoNm(situacaoNm)
            .situacaoLancamento("SituacaoLancamento")
            .dominioSistema(DominioSistemaDTO.MES01)
            .messages(Collections.singletonList("Message1"));
    }

    @NotNull
    private IpAccountAutoDepositEventEntity buildEventEntity() {
        IpAccountAutoDepositEventEntity eventEntity = new IpAccountAutoDepositEventEntity();
        eventEntity.setSpbEventId(1L);
        eventEntity.setSpbMessageEntity(Sets.newSet());
        eventEntity.setValue(BigDecimal.TEN);
        eventEntity.setInitiatorIspb(1);
        eventEntity.setCorrelationId("123456");
        eventEntity.setIpAccountAutoDepositDetailsEntity(buildDetails());

        return eventEntity;
    }

    private IpAccountAutoDepositDetailsEntity buildDetails() {
        return new IpAccountAutoDepositDetailsEntity();
    }

    private IpAccountAutoDepositSpecificationDTO buildIpAccountAutoDepositSpecificationDTO() {
        IpAccountAutoDepositSpecificationDTO specificationDTO = new IpAccountAutoDepositSpecificationDTO();
        specificationDTO.setNumCtrl("123456");
        specificationDTO.setSituation("Situation");
        specificationDTO.setTransactionTimestampUtc(LocalDateTimeUtils.getUtcLocalDateTime());
        specificationDTO.setMovementDate(LocalDateTimeUtils.getTodayUTC());

        return specificationDTO;
    }

    private EmailDTO createEmailDTO() {
        return EmailDTO.builder()
            .emails(Collections.singletonList("email@domain.com"))
            .subject("Subject")
            .text("TextBody")
            .build();
    }

}
