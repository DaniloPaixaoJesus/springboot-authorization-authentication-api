package matera.spi.main.commons.persistence.repository;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.RejectionReasonEntity;
import matera.spi.main.persistence.RejectionReasonRepository;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@IntegrationTest
public class RejectionReasonRepositoryTest  {

    private static final Integer CODE = 123;
    private static final String DESCRIPTION = "description rejection reason";

    @Autowired
    private RejectionReasonRepository repository;

    @Test
    public void saveAndFlush() {
        RejectionReasonEntity rejectionReasonEntity = createObject();
        repository.saveAndFlush(rejectionReasonEntity);
        Optional<RejectionReasonEntity> optionalRejectionReasonEntity = repository.findByDescription(DESCRIPTION);
        if(optionalRejectionReasonEntity.isPresent()) {
            assertNotNull(optionalRejectionReasonEntity.get().getCode());
            assertNotNull(optionalRejectionReasonEntity.get().getDescription());
            assertEquals(CODE, optionalRejectionReasonEntity.get().getCode());
            assertEquals(DESCRIPTION, optionalRejectionReasonEntity.get().getDescription());
        }
    }

    @Test
    public void findByDescription() {
        Optional<RejectionReasonEntity> optional =  repository.findByDescription(DESCRIPTION);
        if(optional.isPresent())
            assertEquals(DESCRIPTION, optional.get().getDescription());
    }

    @Test
    @DisplayName("Verifying if the default values are added correctly")
    public void shouldRejectionReasonDefaultValuesBeAdded() {
        RejectionReasonEntity rejectionReason = repository.findById(1).get();
        assertEquals("Book Transfer Error", rejectionReason.getDescription());

        rejectionReason = repository.findById(2).get();
        assertEquals("Customer Debit Error", rejectionReason.getDescription());

        rejectionReason = repository.findById(3).get();
        assertEquals("Approval required", rejectionReason.getDescription());

        rejectionReason = repository.findById(4).get();
        assertEquals("Restricted Credit", rejectionReason.getDescription());

        rejectionReason = repository.findById(5).get();
        assertEquals("Credit Rejected", rejectionReason.getDescription());
    }

    private RejectionReasonEntity createObject() {
        RejectionReasonEntity rejectionReasonEntity = new RejectionReasonEntity();
        rejectionReasonEntity.setCode(CODE);
        rejectionReasonEntity.setDescription(DESCRIPTION);
        return rejectionReasonEntity;
    }
}
