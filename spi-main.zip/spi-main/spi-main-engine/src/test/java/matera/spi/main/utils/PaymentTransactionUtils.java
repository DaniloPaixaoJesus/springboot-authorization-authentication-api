package matera.spi.main.utils;

import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.domain.model.account.AccountTypeEntity;
import matera.spi.main.domain.model.account.PayerAccountEntity;
import matera.spi.main.domain.model.account.ReceiverAccountEntity;
import matera.spi.main.domain.model.event.transaction.PaymentEventEntity;
import matera.spi.main.domain.model.transaction.PaymentEntity;
import matera.spi.main.domain.model.transaction.TransactionPriorityEntity;
import matera.spi.main.domain.service.ConfigurationService;
import matera.spi.main.messages.schema.generated.pacs008.ChargeBearerType1Code;
import matera.spi.main.messages.schema.generated.pacs008.SettlementMethod1Code;
import matera.spi.main.persistence.AccountTypeRepository;
import matera.spi.main.persistence.ParticipantRepository;
import matera.spi.main.persistence.PaymentRepository;
import matera.spi.main.persistence.TransactionPriorityRepository;
import matera.spi.main.utils.constants.TransactionConstants;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;

import static matera.spi.main.utils.constants.TransactionConstants.PAYER_PARTICIPANT_ENTITY_NAME_FOR_PAYMENT;
import static matera.spi.main.utils.constants.TransactionConstants.RECEIVER_PARTICIPANT_ENTITY_NAME_FOR_PAYMENT;

@Component
public class PaymentTransactionUtils {

    @Autowired
    private ParticipantRepository participantRepository;

    @Autowired
    private AccountTypeRepository accountTypeRepository;

    @Autowired
    private TransactionPriorityRepository transactionPriorityRepository;

    @Autowired
    private EventEntityUtils eventEntityUtils;

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private ConfigurationService configurationService;

    public PaymentEntity newPaymentEntity(BigDecimal value, Integer eventStatus) {
        final PaymentEventEntity eventEntity = eventEntityUtils.buildPaymentEventEntity(value, eventStatus);
        final PaymentEntity newPayment = buildNewPayment();

        eventEntityUtils.setPaymentEntityInEvent(eventEntity, newPayment);
        eventEntityUtils.saveEventEntity(eventEntity);
        eventEntityUtils.buildPaymentEventStatusTransitionEntity(eventEntity);
        return newPayment;
    }

    public void deleteAllInsertedValues() {
        final List<PaymentEntity> paymentList = paymentRepository.findAll();
        final List<ParticipantEntity> participantPayerList = participantRepository.findByNameContainingIgnoreCase(PAYER_PARTICIPANT_ENTITY_NAME_FOR_PAYMENT);
        final List<ParticipantEntity> participantReceiverList = participantRepository.findByNameContainingIgnoreCase(RECEIVER_PARTICIPANT_ENTITY_NAME_FOR_PAYMENT);
        eventEntityUtils.deleteAllInsertValuesFromEventEntity();
        paymentRepository.deleteAll(paymentList);
        participantRepository.deleteAll(participantPayerList);
        participantRepository.deleteAll(participantReceiverList);
    }


    public PaymentEntity buildNewPayment() {
        final String endToEndId = UUID.randomUUID().toString().replaceAll("-", "");
        PaymentEntity newPayment = new PaymentEntity();
        newPayment.setIsLocalPayment(true);
        newPayment.setClearingAccountBalanceChecked(false);
        newPayment.setAdditionalInformation(TransactionConstants.PAYMENT_ADDITIONAL_INFORMATION);
        newPayment.setCustomerInitTimestampUtc(LocalDateTime.now(ZoneOffset.UTC));
        newPayment.setEndToEndId(endToEndId);
        newPayment.setInitiatingInstitutionTaxId(TransactionConstants.PAYER_INITIATING_INSTITUTION_TAX_ID);
        newPayment.setPayerParticipant(getPayerParticipant());
        newPayment.setReceiverParticipant(getReceiverParticipant());
        newPayment.setPayerAccount(buildPayerAccountEntity());
        newPayment.setReceiverAccount(buildReceiverAccountEntity());
        newPayment.setPriority(getTransactionPriorityEntity());
        newPayment.setReceiverReconIdentifier(TransactionConstants.PAYER_RECON_IDENTIFIER);
        newPayment.setChargeBearer(ChargeBearerType1Code.SLEV.value());
        newPayment.setSettlementMethod(SettlementMethod1Code.CLRG.value());
        newPayment.setIsLocalPayment(false);

        return newPayment;
    }

    private TransactionPriorityEntity getTransactionPriorityEntity() {
        final Optional<TransactionPriorityEntity> optional = transactionPriorityRepository.findById(TransactionConstants.TRANSACTION_PRIORITY_ENTITY_CODE_FOR_PAYMENT);
        return optional.orElseGet(this::buildTransactionPriorityEntity);
    }

    private TransactionPriorityEntity buildTransactionPriorityEntity() {
         return transactionPriorityRepository.getOne("HIGH");
    }

    private ParticipantEntity getPayerParticipant() {
        final Integer ispbNumber = configurationService.findConfig().getIspb();
        final Optional<ParticipantEntity> optional = participantRepository.findByIspb(ispbNumber);
        return optional.orElseGet(() -> buildPayerParticipant(ispbNumber));
    }

    private ParticipantEntity buildPayerParticipant(Integer ispbNumber) {
        final ParticipantEntity entity = new ParticipantEntity();
        entity.setIspb(ispbNumber);
        entity.setName(TransactionConstants.PAYER_PARTICIPANT_ENTITY_NAME_FOR_PAYMENT);

        participantRepository.saveAndFlush(entity);
        return entity;
    }

    private ParticipantEntity getReceiverParticipant() {
        final Integer randomIspbNumber = getRandomISPBNumber();
        final Optional<ParticipantEntity> optional = participantRepository.findByIspb(randomIspbNumber);
        return optional.orElseGet(() -> buildReceiverParticipant(randomIspbNumber));
    }

    private ParticipantEntity buildReceiverParticipant(Integer ispbNumber) {
        final ParticipantEntity entity = new ParticipantEntity();
        entity.setIspb(TransactionConstants.RECEIVER_PARTICIPANT_ENTITY_ISPB_FOR_PAYMENT);
        entity.setName(TransactionConstants.RECEIVER_PARTICIPANT_ENTITY_NAME_FOR_PAYMENT);

        participantRepository.saveAndFlush(entity);
        return entity;
    }

    private PayerAccountEntity buildPayerAccountEntity() {
        final PayerAccountEntity entity = new PayerAccountEntity();
        entity.setTaxId(TransactionConstants.PAYER_TAX_ID);
        entity.setName(TransactionConstants.PAYER_NAME);
        entity.setBranch(TransactionConstants.PAYER_BRANCH);
        entity.setAccount(TransactionConstants.PAYER_ACCOUNT);
        entity.setAccountType(getAccountTypeEntity().getCode());

        return entity;
    }

    private ReceiverAccountEntity buildReceiverAccountEntity() {
        final ReceiverAccountEntity entity = new ReceiverAccountEntity();
        entity.setTaxId(TransactionConstants.RECEIVER_TAX_ID);
        entity.setBranch(TransactionConstants.RECEIVER_BRANCH);
        entity.setAccount(TransactionConstants.RECEIVER_ACCOUNT);
        entity.setAddressingKey(TransactionConstants.RECEIVER_ADDRESSING_KEY);
        entity.setAccountType(getAccountTypeEntity().getCode());

        return entity;
    }

    private AccountTypeEntity getAccountTypeEntity() {
        final Optional<AccountTypeEntity> optinal = accountTypeRepository.findById(TransactionConstants.ACCOUNT_TYPE_CODE);
        return optinal.orElseGet(this::buildAccountTypeEntity);
    }

    private AccountTypeEntity buildAccountTypeEntity() {
        final AccountTypeEntity entity = new AccountTypeEntity();
        entity.setCode(TransactionConstants.ACCOUNT_TYPE_CODE);
        entity.setDescription(TransactionConstants.ACCOUNT_TYPE_DESCRIPTION);

        accountTypeRepository.saveAndFlush(entity);
        return entity;
    }

    private Integer getRandomISPBNumber() {
        return new Random().nextInt(999999);
    }
}
