package matera.spi.lm.domain.service.extractor.message;

import matera.spi.lm.dto.CamtReplyMessageDTO;
import matera.spi.utils.DocumentUtils;

import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import static matera.spi.lm.domain.service.extractor.message.ExtractorFactory.camt053ReplyMessageExtractor;
import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static matera.spi.utils.DocumentUtils.stringToXmlDocument;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

class Camt053ReplyMessageExtractorTest {

    private static final String CAMT_053_MSG = "camt.053/camt.053_SALDO_MOMENTO_msg.xml";
    private static final Document CAMT_053_DOCUMENT = stringToXmlDocument(getStringFromXmlFile(CAMT_053_MSG));

    @Test
    void extractValues() {

        String bkToCstmrStmt = "/Envelope/Document/BkToCstmrStmt";
        NodeList nodeList = DocumentUtils.getElementsByExpression(CAMT_053_DOCUMENT, bkToCstmrStmt);

        CamtReplyMessageDTO extractedValues = camt053ReplyMessageExtractor().extractValues(nodeList.item(0));

        LocalDateTime availableUtc = LocalDateTime.of(2020, 4, 7, 13, 17, 4, 768000000);
        LocalDateTime blockedUtc = LocalDateTime.of(2020, 4, 7, 13, 17, 4, 768000000);

        assertThat(extractedValues.getBalanceAvailable(), is(BigDecimal.valueOf(52478.44)));
        assertThat(extractedValues.getBalanceAvailableTimeUTC(), is(availableUtc));

        assertThat(extractedValues.getBalanceBlocked(), is(BigDecimal.valueOf(27885.31)));
        assertThat(extractedValues.getBalanceBlockedTimeUTC(), is(blockedUtc));
    }

}
