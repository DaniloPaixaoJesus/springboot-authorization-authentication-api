package matera.spi.lm.application.services.validation;

import matera.spi.lm.application.service.validation.BalanceIPAccountServiceValidator;
import matera.spi.lm.exception.IpAccountPendingDepositException;
import matera.spi.main.apisInterface.EventApiService;
import matera.spi.main.apisInterface.EventStatusApiService;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventStatusEntity;
import matera.spi.main.domain.model.event.EventType;

import org.apache.commons.compress.utils.Lists;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;

import static matera.spi.main.domain.model.event.EventStatus.WAITING_CLEARING_RETURN;

import static org.mockito.Mockito.when;

import static java.lang.Boolean.FALSE;

@ExtendWith(MockitoExtension.class)
public class BalanceIPAccountServiceValidatorTest {

    @InjectMocks
    private BalanceIPAccountServiceValidator balanceValidator;

    @Mock
    private EventApiService eventApiService;

    @Mock
    private EventStatusApiService eventStatusApiService;

    @Test
    void shouldReturnIpAccountPendingDepositExceptionWhenHaveMoreThanOneEventWaitingForClearingResponse() {
        when(eventStatusApiService.findById(Mockito.anyInt())).thenReturn(buildEventStatusEntity());
        when(eventApiService.findEventByEventStatus(Mockito.any(EventStatusEntity.class))).thenReturn(buildEventEntityList());
        Assertions.assertThrows(IpAccountPendingDepositException.class, () -> {
            balanceValidator.validateDeposit(BigDecimal.TEN, FALSE);
        });
    }

    private EventStatusEntity buildEventStatusEntity() {
        final EventStatusEntity eventStatusEntity = new EventStatusEntity();
        eventStatusEntity.setCode(WAITING_CLEARING_RETURN.getCode());
        eventStatusEntity.setDescription("Waiting clearing return");
        eventStatusEntity.setFinalStatus(FALSE);
        return eventStatusEntity;
    }

    private List<EventEntity> buildEventEntityList() {
        final List<EventEntity> eventEntities = Lists.newArrayList();
        eventEntities.add(new EventEntity() {
            @Override
            public EventType getEventType() {
                return EventType.IP_ACCOUNT_DEPOSIT;
            }
        });
        return eventEntities;
    }

}
