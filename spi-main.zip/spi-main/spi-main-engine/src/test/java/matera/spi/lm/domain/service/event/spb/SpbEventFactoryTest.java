package matera.spi.lm.domain.service.event.spb;

import matera.spi.commons.IntegrationTest;
import matera.spi.lm.domain.model.spb.SpbEventEntity;
import matera.spi.lm.domain.model.spb.deposit.IpAccountDepositDetailsEntity;
import matera.spi.lm.domain.model.spb.deposit.IpAccountDepositEventEntity;
import matera.spi.lm.domain.model.spb.withdraw.IpAccountWithdrawDetailsEntity;
import matera.spi.lm.domain.model.spb.withdraw.IpAccountWithdrawEventEntity;
import matera.spi.lm.domain.service.event.IpAccountDepositEvent;
import matera.spi.lm.domain.service.event.IpAccountWithdrawEvent;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.internal.util.collections.Sets;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@IntegrationTest
public class SpbEventFactoryTest {

    @Autowired
    private SpbEventFactory factory;

    @Test
    void shouldCreateDepositSpbEventFromIpAccountDepositEventEntity() {
        final IpAccountDepositEventEntity spbDepositEventEntity = createSpbDepositEventEntity();
        final SpbEvent spbEvent = factory.findByEventEntity(spbDepositEventEntity);

        Assertions.assertNotNull(spbEvent);
        Assertions.assertTrue(spbEvent instanceof IpAccountDepositEvent);
        Assertions.assertEquals(spbDepositEventEntity, spbEvent.getEventEntity());
    }

    @Test
    void shouldCreateWithdrawSpbEventFromIpAccountWithdrawEventEntity() {
        final IpAccountWithdrawEventEntity spbDepositEventEntity = createSpbWithdrawEventEntity();
        final SpbEvent spbEvent = factory.findByEventEntity(spbDepositEventEntity);

        Assertions.assertNotNull(spbEvent);
        Assertions.assertTrue(spbEvent instanceof IpAccountWithdrawEvent);
        Assertions.assertEquals(spbDepositEventEntity, spbEvent.getEventEntity());
    }

    private IpAccountWithdrawEventEntity createSpbWithdrawEventEntity() {
        IpAccountWithdrawEventEntity withdrawEvent = new IpAccountWithdrawEventEntity();
        withdrawEvent.setIpAccountWithdrawDetails(createSpbWithdrawEventDetailsEntity());
        setBasicEventInfo(withdrawEvent);
        return withdrawEvent;
    }

    private void setBasicEventInfo(SpbEventEntity spbEventENtity) {
        spbEventENtity.setSpbEventId(1L);
        spbEventENtity.setControlNumber("1a2b3c");
        spbEventENtity.setMovementDate(LocalDate.of(2020,5,11));
        spbEventENtity.setSpbMessageEntity(Sets.newSet());
        spbEventENtity.setValue(BigDecimal.TEN);
        spbEventENtity.setInitiationTimestampUTC(LocalDateTime.now());
        spbEventENtity.setInitiatorIspb(1);
    }

    private IpAccountWithdrawDetailsEntity createSpbWithdrawEventDetailsEntity() {
        IpAccountWithdrawDetailsEntity withdrawDetailsEntity = new IpAccountWithdrawDetailsEntity();
        withdrawDetailsEntity.setFinlddLPI(1L);
        withdrawDetailsEntity.setIspbIfCredtd(123L);
        withdrawDetailsEntity.setIspbpspi(456L);
        return withdrawDetailsEntity;
    }

    private IpAccountDepositEventEntity createSpbDepositEventEntity() {
        final IpAccountDepositEventEntity depositEntity = new IpAccountDepositEventEntity();
        depositEntity.setIpAccountDepositDetails(createSpbDepositEventDetailsEntity());
        setBasicEventInfo(depositEntity);
        return depositEntity;
    }

    private IpAccountDepositDetailsEntity createSpbDepositEventDetailsEntity() {
        IpAccountDepositDetailsEntity detailsEntity = new IpAccountDepositDetailsEntity();
        detailsEntity.setIspbif(100L);
        detailsEntity.setIspbpspi(999L);
        return detailsEntity;
    }
}
