package matera.spi.main.rest.ui;

import matera.spi.dto.AccountTypeUIDTO;
import matera.spi.dto.InstantPaymentsUIDTO;
import matera.spi.dto.PayerUIDTO;
import matera.spi.dto.PaymentsUIDTO;
import matera.spi.dto.ReceiverUIDTO;
import matera.spi.dto.RemoteAccountUIDTO;
import matera.spi.main.domain.service.CorrelationIdGenerator;
import matera.spi.main.utils.constants.TransactionConstants;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PaymentsTestHelper {

    private static final int PAYER_INSTITUTION_ISPB = 13370835;
    private static final String PAYER_NAME = "João da Silva";

    private PaymentsTestHelper() {}

    public static InstantPaymentsUIDTO createInvalidInstantPaymentsUIDTO() {

        return createInstantPaymentsUIDTO(createPayerInvalidUIDTOMock(), createReceiverInvalidUIDTOMock());
    }

    public static Map<String, String> createJsonXmlMapping(boolean hasAddressingKey) {

        Map<String, String> jsonXmlMapping = new HashMap<String, String>();

        jsonXmlMapping.put("$.payments[0].acceptanceDateTime", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/AccptncDtTm");
        jsonXmlMapping.put("$.payments[0].receiver.taxId", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Cdtr/Id/PrvtId/Othr/Id");
        jsonXmlMapping.put("$.payments[0].receiver.account.accountNumber", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAcct/Id/Othr/Id");
        jsonXmlMapping.put("$.payments[0].receiver.account.branch", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAcct/Id/Othr/Issr");

        if (hasAddressingKey) {
            jsonXmlMapping.put("$.payments[0].receiver.addressingKey", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAcct/Prxy/Id");
        }

        jsonXmlMapping.put("$.payments[0].receiver.account.accountType", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAcct/Tp/Cd");
        jsonXmlMapping.put("$.payments[0].receiver.institutionISPB", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAgt/FinInstnId/ClrSysMmbId/MmbId");
        jsonXmlMapping.put("$.payments[0].chargeBearer", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/ChrgBr");
        jsonXmlMapping.put("$.payments[0].payer.name", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Dbtr/Nm");
        jsonXmlMapping.put("$.payments[0].payer.taxId", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Dbtr/Id/PrvtId/Othr/Id");
        jsonXmlMapping.put("$.payments[0].payer.account.accountNumber", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/DbtrAcct/Id/Othr/Id");
        jsonXmlMapping.put("$.payments[0].payer.account.branch", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/DbtrAcct/Id/Othr/Issr");
        jsonXmlMapping.put("$.payments[0].payer.account.accountType", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/DbtrAcct/Tp/Cd");
        jsonXmlMapping.put("$.payments[0].payer.institutionISPB", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/DbtrAgt/FinInstnId/ClrSysMmbId/MmbId");
        jsonXmlMapping.put("$.payments[0].organisationIdentification", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/InitgPty/Id/OrgId/Othr/Id");
        jsonXmlMapping.put("$.payments[0].interbankSettlementAmount", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/IntrBkSttlmAmt");
        jsonXmlMapping.put("$.payments[0].endToEndID", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/PmtId/EndToEndId");
        jsonXmlMapping.put("$.payments[0].transactionIdentification", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/PmtId/TxId");
        jsonXmlMapping.put("$.payments[0].unstructured", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/RmtInf/Ustrd");

        //TODO verificar porque não é persistido, uma vez que não há coluna para ele
        //Deveria ser, pois o valor que vem no payload, se perde atualmente.
        //O valor que vai no xml é um now().
        //jsonXmlMapping.put("$.creationDateTime", "/Envelope/Document/FIToFICstmrCdtTrf/GrpHdr/CreDtTm");

        jsonXmlMapping.put("$.payments.length()", "/Envelope/Document/FIToFICstmrCdtTrf/GrpHdr/NbOfTxs");
        jsonXmlMapping.put("$.instructionPriority", "/Envelope/Document/FIToFICstmrCdtTrf/GrpHdr/PmtTpInf/InstrPrty");
        jsonXmlMapping.put("$.settlementMethod", "/Envelope/Document/FIToFICstmrCdtTrf/GrpHdr/SttlmInf/SttlmMtd");

        return jsonXmlMapping;
    }

    public static InstantPaymentsUIDTO createValidInstantPaymentsUIDTO(String addressingKey) {

        return createInstantPaymentsUIDTO(createPayerUIDTOMock(), createReceiverUIDTOMock(addressingKey));
    }

    private static InstantPaymentsUIDTO createInstantPaymentsUIDTO(PayerUIDTO payerUIDTO, ReceiverUIDTO receiverUIDTO) {

        InstantPaymentsUIDTO instantPaymentsUIDTO = new InstantPaymentsUIDTO();
        instantPaymentsUIDTO.setCreationDateTime(LocalDateTime.parse("2020-04-14T20:55:28.678", DateTimeFormatter.ISO_DATE_TIME));
        instantPaymentsUIDTO.setInstructionPriority("HIGH");
        instantPaymentsUIDTO.setPayments(createListOfPaymentsUiDTOMock(payerUIDTO, receiverUIDTO));
        instantPaymentsUIDTO.setSettlementMethod("CLRG");

        return instantPaymentsUIDTO;
    }

    private static List<PaymentsUIDTO> createListOfPaymentsUiDTOMock(PayerUIDTO payerUIDTO, ReceiverUIDTO receiverUIDTO) {

        PaymentsUIDTO paymentsUIDTO = createPaymentsUiDTOMock(payerUIDTO, receiverUIDTO);

        return List.of(
            paymentsUIDTO
        );
    }

    private static PayerUIDTO createPayerInvalidUIDTOMock() {

        PayerUIDTO payerUIDTO = new PayerUIDTO();
        payerUIDTO.setInstitutionISPB(208);
        payerUIDTO.setTaxId("012345678901");
        payerUIDTO.setAccount(createRemoteAccountUIDTOMock());

        return payerUIDTO;
    }

    private static PayerUIDTO createPayerUIDTOMock() {
        return createPayerUIDTOMock(PAYER_NAME);
    }

    private static PayerUIDTO createPayerUIDTOMock(String payerName) {

        PayerUIDTO payerUIDTO = new PayerUIDTO();
        payerUIDTO.setInstitutionISPB(PAYER_INSTITUTION_ISPB);
        payerUIDTO.setName(payerName);
        payerUIDTO.setTaxId("83744943011");
        payerUIDTO.setAccount(createRemoteAccountUIDTOMock());

        return payerUIDTO;
    }

    private static PaymentsUIDTO createPaymentsUiDTOMock(PayerUIDTO payerUIDTO, ReceiverUIDTO receiverUIDTO) {

        PaymentsUIDTO paymentsUIDTO = new PaymentsUIDTO();

        paymentsUIDTO.setAcceptanceDateTime(LocalDateTime.parse("2020-04-14T21:55:28.678", DateTimeFormatter.ISO_DATE_TIME));
        paymentsUIDTO.setChargeBearer("SLEV");
        paymentsUIDTO.setEndToEndID(CorrelationIdGenerator.generateCorrelactionIdPacs008(String.valueOf(PAYER_INSTITUTION_ISPB)));
        paymentsUIDTO.setInterbankSettlementAmount(BigDecimal.valueOf(100));
        paymentsUIDTO.setOrganisationIdentification(TransactionConstants.PAYER_INITIATING_INSTITUTION_TAX_ID);
        paymentsUIDTO.setTransactionIdentification("TRANSACTION_ID");
        paymentsUIDTO.setUnstructured("UNSTRUCTURED");
        paymentsUIDTO.setPayer(payerUIDTO);
        paymentsUIDTO.setReceiver(receiverUIDTO);

        return paymentsUIDTO;
    }

    private static ReceiverUIDTO createReceiverInvalidUIDTOMock() {

        ReceiverUIDTO receiverUIDTO = new ReceiverUIDTO();
        receiverUIDTO.setAddressingKey("ADDRESSING_KEY");
        receiverUIDTO.setInstitutionISPB(38121);
        receiverUIDTO.setTaxId("109876543210");
        receiverUIDTO.setAccount(createRemoteAccountUIDTOMock());

        return receiverUIDTO;
    }

    private static ReceiverUIDTO createReceiverUIDTOMock(String addressingKey) {

        ReceiverUIDTO receiverUIDTO = new ReceiverUIDTO();
        receiverUIDTO.setAddressingKey(addressingKey);
        receiverUIDTO.setInstitutionISPB(38121);
        receiverUIDTO.setTaxId("28837107080");
        receiverUIDTO.setAccount(createRemoteAccountUIDTOMock());

        return receiverUIDTO;
    }

    private static RemoteAccountUIDTO createRemoteAccountUIDTOMock() {

        RemoteAccountUIDTO remoteAccountUIDTO = new RemoteAccountUIDTO();
        remoteAccountUIDTO.setAccountNumber("123456");
        remoteAccountUIDTO.setBranch("777");
        remoteAccountUIDTO.setAccountType(AccountTypeUIDTO.CACC);

        return remoteAccountUIDTO;
    }
}
