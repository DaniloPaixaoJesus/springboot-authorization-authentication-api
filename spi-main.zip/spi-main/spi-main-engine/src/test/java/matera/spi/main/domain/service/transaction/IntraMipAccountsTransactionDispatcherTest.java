package matera.spi.main.domain.service.transaction;

import matera.spi.main.config.MainEngineConfiguration;
import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.domain.model.ParticipantMipEntity;
import matera.spi.main.domain.model.event.transaction.PaymentEventEntity;
import matera.spi.main.domain.model.event.transaction.ReceiptEventEntity;
import matera.spi.main.domain.model.event.transaction.ReturnReceivedEventEntity;
import matera.spi.main.domain.model.event.transaction.ReturnSentEventEntity;
import matera.spi.main.domain.model.transaction.PaymentEntity;
import matera.spi.main.domain.model.transaction.ReceiptEntity;
import matera.spi.main.domain.model.transaction.ReturnReceivedEntity;
import matera.spi.main.domain.model.transaction.ReturnSentEntity;
import matera.spi.main.domain.service.AccountAsyncTransaction;
import matera.spi.main.domain.service.ConfigurationService;
import matera.spi.main.domain.service.CustomerCreditTransactionWorkQueue;
import matera.spi.main.domain.service.ParticipantMipService;
import matera.spi.main.domain.service.participants.IntraMipVerifier;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class IntraMipAccountsTransactionDispatcherTest {

    private static final int OTHER_PARTICIPANT_MIP_ISPB = 123;
    private static final int CURRENT_PARTICIPANT_ISPB = 789;

    @Mock
    private ManagerialIPAccount managerialIPAccount;
    @Mock
    private MirrorIPAccount mirrorIPAccount;
    @Mock
    private IntraMipVerifier intraMipVerifier;

    @Mock
    private MainEngineConfiguration mainEngineConfiguration;

    @Mock
    private AccountAsyncTransaction accountAsyncTransaction;

    @Mock
    private ParticipantMipService participantMipService;

    @Mock
    private ConfigurationService configurationService;

    @InjectMocks
    private AccountsTransactionDispatcher accountsTransactionDispatcher;

    private ParticipantEntity otherParticipantMip;
    private ParticipantEntity currentParticipant;

    private ParticipantMipEntity participantMipEntity;

    @BeforeEach
    void setUp() {

        when(intraMipVerifier.isIntraMip(OTHER_PARTICIPANT_MIP_ISPB)).thenReturn(true);

        lenient().when(configurationService.findByIspb()).thenReturn(Integer.toString(CURRENT_PARTICIPANT_ISPB));

        otherParticipantMip = new ParticipantEntity();
        otherParticipantMip.setIspb(OTHER_PARTICIPANT_MIP_ISPB);

        currentParticipant = new ParticipantEntity();
        currentParticipant.setIspb(CURRENT_PARTICIPANT_ISPB);

        participantMipEntity = new ParticipantMipEntity();
        participantMipEntity.setIspb(CURRENT_PARTICIPANT_ISPB);
        participantMipEntity.setAccountNumber(new BigDecimal(2222));
        participantMipEntity.setBranch(1111);
        participantMipEntity.setManagerialAccountEnabled(true);

        lenient().when(participantMipService.findByIspb(CURRENT_PARTICIPANT_ISPB))
            .thenReturn(Optional.of(participantMipEntity));
    }

    @Test
    void shouldOnlyMakeManagerialCreditWhenIsAIntraMipTransaction() {
        //given
        ReceiptEntity receiptEntity = new ReceiptEntity();
        receiptEntity.setPayerParticipant(otherParticipantMip);
        receiptEntity.setReceiverParticipant(currentParticipant);
        ReceiptEventEntity eventMock = new ReceiptEventEntity();
        eventMock.setReceiptEntity(receiptEntity);

        //when
        accountsTransactionDispatcher.makeCredit(eventMock);

        //then
        assertThat(otherParticipantMip).isNotEqualTo(currentParticipant);
        verify(managerialIPAccount).makeCredit(eventMock);
        verifyNoInteractions(mirrorIPAccount);
    }

    @Test
    void shouldOnlyMakeManagerialDebitWhenIsAIntraMipTransaction() {
        //given
        PaymentEntity paymentEntity = new PaymentEntity();
        paymentEntity.setPayerParticipant(currentParticipant);
        paymentEntity.setReceiverParticipant(otherParticipantMip);
        PaymentEventEntity eventMock = new PaymentEventEntity();
        eventMock.setPaymentEntity(paymentEntity);

        //when
        accountsTransactionDispatcher.makeDebit(eventMock);

        //then
        assertThat(otherParticipantMip).isNotEqualTo(currentParticipant);
        verify(managerialIPAccount).makeDebit(eventMock);
        verifyNoInteractions(mirrorIPAccount);
    }

    @Test
    void shouldOnlyMakeManagerialReturnSentWhenIsAIntraMipTransaction() {
        ReturnSentEntity returnSentEntity = new ReturnSentEntity();
        returnSentEntity.setPayerParticipant(currentParticipant);
        returnSentEntity.setReceiverParticipant(otherParticipantMip);
        ReturnSentEventEntity eventMock = new ReturnSentEventEntity();
        eventMock.setReturnSentEntity(returnSentEntity);
        //when
        accountsTransactionDispatcher.returnSent(eventMock);

        //then
        assertThat(otherParticipantMip).isNotEqualTo(currentParticipant);
        verify(managerialIPAccount).returnSent(eventMock);
        verifyNoInteractions(mirrorIPAccount);
    }

    @Test
    void shouldOnlyMakeManagerialReturnReceivedWhenIsAIntraMipTransaction() {
        //given
        ReturnReceivedEntity returnReceivedEntity = new ReturnReceivedEntity();
        returnReceivedEntity.setPayerParticipant(otherParticipantMip);
        returnReceivedEntity.setReceiverParticipant(currentParticipant);
        ReturnReceivedEventEntity eventMock = new ReturnReceivedEventEntity();
        eventMock.setReturnReceivedEntity(returnReceivedEntity);

        //when
        accountsTransactionDispatcher.returnReceived(eventMock);

        //then
        assertThat(otherParticipantMip).isNotEqualTo(currentParticipant);
        verify(managerialIPAccount).returnReceived(eventMock);
        verifyNoInteractions(mirrorIPAccount);
    }
}
