package matera.spi.lm.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.lm.domain.model.IpAccountStatementReportDetails;
import matera.spi.lm.domain.model.enums.EnumStatusCode;
import matera.spi.main.domain.model.enums.EnumTransactionType;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Stream;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.comparesEqualTo;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.core.Is.is;

@IntegrationTest
class IpAccountStatementReportDetailsRepositoryTest {

    @Autowired
    private IpAccountStatementReportDetailsRepository repository;

    @AfterEach
    void afterEach() {
        repository.deleteAll();
    }

    @Test
    void shouldInsertAnEntity() {
        createEntity(EnumTransactionType.CREDIT, EnumStatusCode.BOOK);

        assertThat(repository.count(), is(1L));
    }

    @ParameterizedTest
    @MethodSource("getStatusCodes")
    void shouldReturnAllVaryingStatusCode(List<EnumStatusCode> statusCodes) {
        createEntity(EnumTransactionType.CREDIT, EnumStatusCode.BOOK);

        PageRequest pageable = PageRequest.of(0, 1);
        LocalDateTime startTimestamp = LocalDateTime.now().minusDays(1);
        LocalDateTime endTimestamp = LocalDateTime.now().plusDays(1);

        Page<IpAccountStatementReportDetails> result = repository.findByParams(pageable, startTimestamp, endTimestamp, statusCodes);

        assertThat(result.getContent(), hasSize(1));
    }

    @Test
    void shouldReturnAllBetweenDates() {
        createEntity(EnumTransactionType.CREDIT, EnumStatusCode.BOOK);

        PageRequest pageable = PageRequest.of(0, 1);
        LocalDateTime startTimestamp = LocalDateTime.now().minusDays(1);
        LocalDateTime endTimestamp = LocalDateTime.now().plusDays(1);

        Page<IpAccountStatementReportDetails> result = repository.findByParams(pageable, startTimestamp, endTimestamp, List.of(EnumStatusCode.BOOK));

        assertThat(result.getContent(), hasSize(1));
    }

    @Test
    void shouldReturnEmptyList() {
        createEntity(EnumTransactionType.CREDIT, EnumStatusCode.BOOK);

        PageRequest pageable = PageRequest.of(0, 1);
        LocalDateTime startTimestamp = LocalDateTime.now().minusDays(2);
        LocalDateTime endTimestamp = LocalDateTime.now().minusDays(1);

        Page<IpAccountStatementReportDetails> result = repository.findByParams(pageable, startTimestamp, endTimestamp, List.of(EnumStatusCode.BOOK));

        assertThat(result.getContent(), hasSize(0));
    }

    @Test
    void shouldReturnDebitAndCreditSum() {
        createEntity(EnumTransactionType.DEBIT, EnumStatusCode.BOOK);
        createEntity(EnumTransactionType.DEBIT, EnumStatusCode.INFO);
        createEntity(EnumTransactionType.CREDIT, EnumStatusCode.BOOK);
        createEntity(EnumTransactionType.CREDIT, EnumStatusCode.BOOK);
        createEntity(EnumTransactionType.CREDIT, EnumStatusCode.INFO);

        LocalDateTime startTimestamp = LocalDateTime.now().minusDays(1);
        LocalDateTime endTimestamp = LocalDateTime.now().plusDays(1);

        BigDecimal creditResult = repository.getTotalCredit(startTimestamp, endTimestamp, List.of(EnumStatusCode.BOOK, EnumStatusCode.INFO));
        BigDecimal debitResult = repository.getTotalDebit(startTimestamp, endTimestamp, List.of(EnumStatusCode.BOOK));

        assertThat(creditResult, comparesEqualTo(BigDecimal.valueOf(30)));
        assertThat(debitResult, comparesEqualTo(BigDecimal.valueOf(10)));
    }

    private void createEntity(EnumTransactionType creditDebitIndicator, EnumStatusCode statusCode) {
        IpAccountStatementReportDetails entity = new IpAccountStatementReportDetails();
        entity.setAccountIdentification(12345);
        entity.setAmount(BigDecimal.TEN);
        entity.setCreditDebitIndicator(creditDebitIndicator);
        entity.setStatusCode(statusCode);
        entity.setBookingDate(LocalDateTime.now());
        entity.setValueDate(LocalDateTime.now());
        entity.setInstructionIdentification("Instruction ID");
        entity.setEndToEndIdentification("E2E ID");
        entity.setClearingSystemReference("Reference");
        entity.setInitiatingParty(5555L);
        entity.setDebtorAgent(4444);
        entity.setCreditorAgent(3333);

        repository.saveAndFlush(entity);
    }


    private static Stream<Arguments> getStatusCodes() {
        return Stream.of(
            Arguments.of(List.of(EnumStatusCode.BOOK)),
            Arguments.of(List.of(EnumStatusCode.BOOK, EnumStatusCode.INFO)));
    }

}
