package matera.spi.main.domain.service.event.receiver;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.dto.MessageReceiverDTO;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.testcontainers.shaded.com.fasterxml.jackson.core.JsonProcessingException;
import org.testcontainers.shaded.com.fasterxml.jackson.databind.ObjectMapper;

import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;

@IntegrationTest
class MessageReceiverAdmi002Test {

    @Autowired
    private MessageReceiver messageReceiver;

    private static final String ADMI_002_SPI_1_2_SPI_M_MSG = "admi.002/admi.002.spi.1.2_SPI_M_msg.xml";

    @Test
    void shouldNotBeProcessAdmi002WhenPiResourceIdOrMessageIdNotFound() {

        Assertions.assertDoesNotThrow(() -> messageReceiver
            .readIncomingMessage(createMessageMock("ResourceId 01", "txn 01", ADMI_002_SPI_1_2_SPI_M_MSG)));
    }

    private String createMessageMock(String piResourceId, String txnId, String xmlFileName)
        throws JsonProcessingException {
        String xml = getStringFromXmlFile(xmlFileName);
        MessageReceiverDTO messageReceiverDTO =
            MessageReceiverDTO.builder().piResourceId(piResourceId).xml(xml).build();
        return new ObjectMapper().writeValueAsString(messageReceiverDTO);
    }

}
