package matera.spi.lm.application.services.validation;

import matera.spi.lm.application.service.validation.BigDecimalValidation.BigDecimalValidator;
import matera.spi.lm.application.service.validation.LocalDateTimeValidation.LocalDateTimeValidator;
import matera.spi.lm.application.service.validation.PageableValidation.PageableValidator;
import matera.spi.lm.application.service.validation.TransactionApiValidator;
import matera.spi.lm.exception.TransactionsApiValidationException;
import matera.spi.main.domain.service.MacroEventStatusService;
import matera.spi.utils.LocalDateTimeUtils;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.mockito.ArgumentMatchers.anyInt;

@ExtendWith(MockitoExtension.class)
public class TransactionApiValidatorTest {

    private final Integer INTEGER_ZERO = 0;
    private final Integer INTEGER_MINUS_ONE = -1;

    private static Integer PAGE_SIZE = 1;
    private static Integer PAGE_NUMBER = 0;
    private static Integer ISPB = 0;
    private static LocalDateTime START_TIMESTAMP = LocalDateTimeUtils.getMinLocalDateTime(LocalDate.now());
    private static LocalDateTime END_TIMESTAMP = LocalDateTimeUtils.getMaxLocalDateTime(LocalDate.now());
    private static BigDecimal MIN_VALUE = new BigDecimal("0");
    private static BigDecimal MAX_VALUE = new BigDecimal("999999999");
    private static Integer STATUS = 1;

    @Spy
    @InjectMocks
    private TransactionApiValidator transactionApiValidator;

    @Mock
    private MacroEventStatusService macroEventStatusService;

    @Mock
    private PageableValidator pageableValidator;

    @Mock
    private LocalDateTimeValidator localDateTimeValidator;

    @Mock
    private BigDecimalValidator bigDecimalValidator;

    @Test
    void shouldThrowTransactionsApiValidationExceptionWhenPageSizeIsNull() {
        Assertions.assertThrows(
                TransactionsApiValidationException.class,
                () -> transactionApiValidator.validateGetTransactionsPageableWithFilters(null, PAGE_NUMBER, START_TIMESTAMP, END_TIMESTAMP, STATUS,
                    MIN_VALUE, MAX_VALUE),
                "Page Size must be not null"
        );
    }

    @Test
    void shouldThrowTransactionsApiValidationExceptionWhenPageSizeLessThanZero() {
        Assertions.assertThrows(
                TransactionsApiValidationException.class,
                () -> transactionApiValidator.validateGetTransactionsPageableWithFilters(null, PAGE_NUMBER, START_TIMESTAMP, END_TIMESTAMP, STATUS,
                    MIN_VALUE, MAX_VALUE),
                "The value of Page Size must be greater than ZERO"
        );
    }

    @Test
    void shouldThrowTransactionsApiValidationExceptionWhenPageNumberIsNull() {
        Assertions.assertThrows(
                TransactionsApiValidationException.class,
                () -> transactionApiValidator.validateGetTransactionsPageableWithFilters(PAGE_SIZE, null, START_TIMESTAMP, END_TIMESTAMP, STATUS,
                    MIN_VALUE, MAX_VALUE),
                "Page Number must be not null"
        );
    }

    @Test
    void shouldThrowTransactionsApiValidationExceptionWhenPageNumberLessThanZero() {
        Assertions.assertThrows(
                TransactionsApiValidationException.class,
                () -> transactionApiValidator.validateGetTransactionsPageableWithFilters(PAGE_SIZE, INTEGER_MINUS_ONE, START_TIMESTAMP, END_TIMESTAMP, STATUS,
                    MIN_VALUE, MAX_VALUE),
                "The value of Page Number must be greater or equal to ZERO"
        );
    }

    @Test
    void shouldThrowTransactionsApiValidationExceptionWhenMovimentDateIsNull() {
        Assertions.assertThrows(
                TransactionsApiValidationException.class,
                () -> transactionApiValidator.validateGetTransactionsPageableWithFilters(PAGE_SIZE, PAGE_NUMBER, null, null, STATUS,
                    MIN_VALUE, MAX_VALUE),
                "Moviment Date must be not null"
        );
    }

    @Test
    void shouldThrowTransactionsApiValidationExceptionWhenMacroStatusCodeIsNotStoredInDB() {
        Mockito.when(macroEventStatusService.isMacroStatusCodePresentInDB(anyInt())).thenReturn(false);
        Assertions.assertThrows(
                TransactionsApiValidationException.class,
                () -> transactionApiValidator.validateGetTransactionsPageableWithFilters(PAGE_SIZE, PAGE_NUMBER, START_TIMESTAMP, END_TIMESTAMP, 9,
                    MIN_VALUE, MAX_VALUE),
                "Status not Found"
        );
    }
}
