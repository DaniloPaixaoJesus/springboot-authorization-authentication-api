package matera.spi.main.domain.service;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.idempotence.IdempotenceStandinEntity;
import matera.spi.main.dto.IdempotenceStandinDTO;
import matera.spi.main.dto.PayerIdempotenceStandinDTO;
import matera.spi.main.dto.ReceiverIdempotenceStandinDTO;
import matera.spi.main.persistence.IdempotenceStandinRepository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

import static matera.spi.main.domain.service.util.HashGenerator.generateHash;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@IntegrationTest
@Transactional
public class IdempotenceStandinServiceTest  {

    @Autowired
    private IdempotenceStandinRepository idempotenceStandinRepository;

    @Autowired
    private IdempotenceStandinService idempotenceStandinService;

    @Test
    public void shouldCreateNewIdempotence() {

        IdempotenceStandinDTO idempotenceStandinDTO = getIdempotenceStandinDTO();

        String expectedHash = generateIdempotenceHash(idempotenceStandinDTO);
        UUID expectedUuid = idempotenceStandinService.saveIdempotence(idempotenceStandinDTO);

        IdempotenceStandinEntity idempotenceStandinEntity = idempotenceStandinRepository.findByIdempotence(expectedHash).get();

        assertEquals(expectedHash, idempotenceStandinEntity.getIdempotence());
        assertEquals(expectedUuid, idempotenceStandinEntity.getUuid());
    }

    @Test
    public void whenThereIsTheHashInDatabaseShouldNotCreateNewIdempotence() {

        IdempotenceStandinDTO idempotenceStandinDTO = getIdempotenceStandinDTO();

        UUID expectedUuid = idempotenceStandinService.saveIdempotence(idempotenceStandinDTO);
        UUID secondUuid = idempotenceStandinService.saveIdempotence(idempotenceStandinDTO);

        assertEquals(expectedUuid, secondUuid);
    }

    @Test
    public void shouldRemoveExpiredIdempotence() throws Exception {

        IdempotenceStandinDTO idempotenceStandinDTO = getIdempotenceStandinDTO();

        idempotenceStandinService.saveIdempotence(idempotenceStandinDTO);

        long secondsToWait = 2000;
        Thread.sleep(secondsToWait);

        idempotenceStandinService.purgeOldIdempotenceIds();

        List<IdempotenceStandinEntity> idempotenceStandinEntities = idempotenceStandinRepository.findAll();

        assertTrue(idempotenceStandinEntities.isEmpty());
    }

    private IdempotenceStandinDTO getIdempotenceStandinDTO() {
        return IdempotenceStandinDTO.builder()
                    .amount("999.99")
                    .payer(
                            PayerIdempotenceStandinDTO.builder()
                                    .account("333333")
                                    .branch("2222")
                                    .ispb("11111111")
                                    .build()
                    ).receiver(
                            ReceiverIdempotenceStandinDTO.builder()
                                    .account("66666")
                                    .accountType("SLRY")
                                    .addressingKey("alias@alias.com")
                                    .branch("5555")
                                    .ispb("44444444")
                                    .taxId("68563235737")
                                    .build()
                    ).build();
    }

    private String generateIdempotenceHash(IdempotenceStandinDTO idempotenceStandinDTO) {

        return generateHash(idempotenceStandinDTO);
    }
}
