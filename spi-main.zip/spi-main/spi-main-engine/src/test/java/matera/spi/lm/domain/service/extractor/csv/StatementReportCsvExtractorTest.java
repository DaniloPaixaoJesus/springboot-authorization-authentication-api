package matera.spi.lm.domain.service.extractor.csv;

import matera.spi.lm.dto.csv.StatementReportCsvDTO;
import matera.spi.lm.exception.LiquidityManagementException;

import com.fasterxml.jackson.databind.MappingIterator;
import com.google.common.collect.Lists;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class StatementReportCsvExtractorTest {

    private static final String BASE_DIR = "src/test/resources/examples";
    private static final String CSV_FILEPATH_1 = BASE_DIR + "/csv/csv_camt052_example1.csv";

    private final StatementReportCsvExtractor extractor = new StatementReportCsvExtractor();

//    @Test
//    void shouldExtractValuesFromCSV() {
//        final List<StatementReportCsvDTO> expectedStatementReportDTO = buildExpectedListCSV1();
//        final List<StatementReportCsvDTO> actualStatementReportCsvDTO = extractContentFromCsv(CSV_FILEPATH_1);
//
//        Assertions.assertArrayEquals(expectedStatementReportDTO.toArray(), actualStatementReportCsvDTO.toArray());
//    }

//    @SneakyThrows
//    private List<StatementReportCsvDTO> extractContentFromCsv(String pathToFile) {
//        final MappingIterator<StatementReportCsvDTO> statementReportCsvDTOMappingIterator =
//            extractor.extractContent(getZipInputStream(pathToFile), StatementReportCsvDTO.class);
//        return statementReportCsvDTOMappingIterator.readAll();
//    }

    private List<StatementReportCsvDTO> buildExpectedListCSV1() {
        List<StatementReportCsvDTO> expectedList = Lists.newArrayList();

        expectedList.add(buildExpectedRegistry(13370835, "BRL10.50", "CRDT", "BOOK", "2020-06-10T09:14:43.912Z",
            "2020-06-10T09:14:43.912Z", "", "E0057376820200217082881978247550", "", 1472540000130L, 13370835, 12345678));
        expectedList.add(buildExpectedRegistry(13370835, "BRL15.21", "DBIT", "BOOK", "2020-06-09T09:14:55.012Z",
            "2020-06-09T09:14:55.012Z", "", "E0057376820200217082881978247551", "", 1472540000130L, 13370835, 12345678));
        expectedList.add(buildExpectedRegistry(null, "BRL101.17", "DBIT", "INFO", "2020-06-10T09:15:27.523Z",
            "2020-06-10T09:15:27.523Z", "", "E0057376820200217082881978247552", "", 1472540000130L, 12345678, 13370835));
        expectedList.add(buildExpectedRegistry(13370835, "BRL9.00", "CRDT", "BOOK", "2020-06-10T10:01:21.912Z",
            "2020-06-10T10:01:21.912Z", "", "E0057376820200217082881978247553", "", null, 0, 13370835));
        expectedList.add(buildExpectedRegistry(13370835, "BRL53.99", "DBIT", "BOOK", "2020-06-11T09:16:13.731Z",
            "2020-06-11T09:16:13.731Z", "", "E0057376820200217082881978247554", "", 1472540000130L, 13370835, 0));

        return expectedList;
    }

    private StatementReportCsvDTO buildExpectedRegistry(Integer accountIdentification,
                                                        String amount,
                                                        String creditDebitIndicator,
                                                        String statusCode,
                                                        String bookingDate,
                                                        String valueDate,
                                                        String instructionIdentification,
                                                        String endToEndIdentification,
                                                        String clearingSystemReference,
                                                        Long initiatingParty,
                                                        Integer debtorAgent,
                                                        Integer creditorAgent) {
        return StatementReportCsvDTO.builder()
            .accountIdentification(accountIdentification)
            .amount(amount)
            .creditDebitIndicator(creditDebitIndicator)
            .statusCode(statusCode)
            .bookingDate(bookingDate)
            .valueDate(valueDate)
            .instructionIdentification(instructionIdentification)
            .endToEndIdentification(endToEndIdentification)
            .clearingSystemReference(clearingSystemReference)
            .initiatingParty(initiatingParty)
            .debtorAgent(debtorAgent)
            .creditorAgent(creditorAgent)
            .build();
    }

    private InputStream getZipInputStream(String pathToFile) {
        try {
            return new FileInputStream(new File(pathToFile));
        } catch (IOException e) {
            throw new LiquidityManagementException("SPI-LM-012");
        }
    }
}
