package matera.spi.commons;

import org.springframework.test.context.TestContext;
import org.springframework.test.context.TestExecutionListener;

import java.util.Locale;

public class LocaleTestExecutionListener implements TestExecutionListener {
    private Locale originalLocale;

    @Override
    public void beforeTestExecution(TestContext testContext) throws Exception {
        this.originalLocale = Locale.getDefault();
        Locale.setDefault(Locale.ENGLISH);
    }

    @Override
    public void afterTestExecution(TestContext testContext) throws Exception {
        Locale.setDefault(this.originalLocale);
    }
}
