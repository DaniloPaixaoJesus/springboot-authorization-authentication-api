package matera.spi.main.domain.service;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.EmailNotificationEntity;
import matera.spi.main.persistence.EmailNotificationRepository;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;
import java.util.UUID;

@IntegrationTest
class EmailNotificationServiceTest {

    private static final String NEW_NAME_IDENTIFICATION = "new name identification";
    private static final String NEW_EMAIL_ADDRESS = "newemail@email.com";

    private static final String EMAIL_ADDRESS = "email@email.com";
    private static final String NAME_IDENTIFICATION = "name identification";

    @Autowired
    private EmailNotificationService emailNotificationService;

    @Autowired
    private EmailNotificationRepository emailNotificationRepository;

    @BeforeEach
    void beforeEach() {
        emailNotificationRepository.deleteAll();
    }

    @AfterEach
    void afterEach() {
        emailNotificationRepository.deleteAll();
    }
    @Test
    void shouldBeUpdateEntityAfterInserted() {
        EmailNotificationEntity expected = new EmailNotificationEntity();
        expected.setEmail(EMAIL_ADDRESS);
        expected.setIdentification(NAME_IDENTIFICATION);
        expected.setDateTimeRegister(LocalDateTime.now());
        emailNotificationService.save(expected);


        EmailNotificationEntity updated = emailNotificationService
            .findById(expected.getUuid())
            .orElse(null);

        updated.setEmail(NEW_EMAIL_ADDRESS);
        updated.setIdentification(NEW_NAME_IDENTIFICATION);
        emailNotificationService.save(updated);

        EmailNotificationEntity actual = emailNotificationService
            .findById(expected.getUuid())
            .orElse(null);

        Assertions.assertNotEquals(expected, actual);
        Assertions.assertEquals(expected.getUuid(), actual.getUuid());
        Assertions.assertEquals(NEW_NAME_IDENTIFICATION, actual.getIdentification());
        Assertions.assertEquals(NEW_EMAIL_ADDRESS, actual.getEmail());

    }

    @Test
    void shouldBeFindEntityWhenInserted() {
        EmailNotificationEntity expected = new EmailNotificationEntity();
        expected.setEmail(EMAIL_ADDRESS);
        expected.setIdentification(NAME_IDENTIFICATION);
        expected.setDateTimeRegister(LocalDateTime.now());
        emailNotificationService.save(expected);

        EmailNotificationEntity actual = emailNotificationService
            .findById(expected.getUuid())
            .orElse(null);
        Assertions.assertEquals(expected, actual);
    }

    @Test
    void shouldBeDeletedEntityAfterInserted() {
        EmailNotificationEntity expected = new EmailNotificationEntity();
        expected.setEmail(EMAIL_ADDRESS);
        expected.setIdentification(NAME_IDENTIFICATION);
        expected.setDateTimeRegister(LocalDateTime.now());
        emailNotificationService.save(expected);

        UUID uuid = expected.getUuid();
        emailNotificationService.deleteById(uuid);

        EmailNotificationEntity found = emailNotificationService
            .findById(expected.getUuid())
            .orElse(null);


        Assertions.assertEquals(null, found);
    }

}

