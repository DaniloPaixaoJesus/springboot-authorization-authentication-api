package matera.spi.main.domain.service.event.receiver;

import com.matera.client.exception.SecurityErrorException;
import com.matera.spi.callback.model.CallbackIntantsPaymentsWrapperDTO;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.ClientSystemEntity;
import matera.spi.main.domain.service.CallbackService;
import matera.spi.main.dto.event.transaction.SendCallbackDTO;
import matera.spi.main.exception.CallbackException;
import matera.spi.utils.JsonService;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.assertj.core.api.Assertions.assertThatThrownBy;

@Slf4j
@IntegrationTest
class CallbackReceiverTest {

    private static final String CLIENT_ID = "123456789";
    private static final String NAME_SYSTEM = "123456789";
    private static final String SECRET = "123456789";
    private static final String URL_CALLBACK = "http://localhost";
    private static final String URL_O_AUTH = "http://localhost";
    public static final String CODE_SYSTEM_1 = "System1";

    @Autowired
    private CallbackReceiver callbackReceiver;

    @Autowired
    JsonService jsonUtils;

    @Autowired
    private CallbackService callbackService;

    private ObjectMapper objectMapper = new ObjectMapper();

    @SneakyThrows
    @Test
    public void testSendMessageSuccess(){
        createCallbackEntity(CODE_SYSTEM_1, true);
        String message = getJsonMessage(CODE_SYSTEM_1);

        assertThatThrownBy(() -> callbackReceiver.readIncomingMessage(message))
            .isInstanceOf(CallbackException.class);
    }

    @SneakyThrows
    @Test
    public void testSendMessageCodeSystemNotFound(){
        String message = getJsonMessage("CODE_SYSTEM");
        assertThatThrownBy(() -> callbackReceiver.readIncomingMessage(message))
            .isInstanceOf(IllegalArgumentException.class);
    }

    private ClientSystemEntity createCallbackEntity(String codeSystem, boolean active) {
        ClientSystemEntity clientSystemEntity = new ClientSystemEntity();
        clientSystemEntity.setClientId(CLIENT_ID);
        clientSystemEntity.setCodeSystem(codeSystem);
        clientSystemEntity.setNameSystem(NAME_SYSTEM);
        clientSystemEntity.setSecret(SECRET);
        clientSystemEntity.setUrlCallback(URL_CALLBACK);
        clientSystemEntity.setUrlOAuth(URL_O_AUTH);
        clientSystemEntity.setActive(active);
        return callbackService.createCallbackEntity(clientSystemEntity);
    }

    private String getJsonMessage(String systemCode) throws JsonProcessingException {
        CallbackIntantsPaymentsWrapperDTO callbackIntantPayment = new CallbackIntantsPaymentsWrapperDTO();
        callbackIntantPayment.setEndToEndId("EndToEndId");
        callbackIntantPayment.setEventId("EventId");
        callbackIntantPayment.setOriginalSystemTransactionIdentifier("OriginalSystemTransactionIdentifier");

        SendCallbackDTO sendCallbackDTO = SendCallbackDTO
                                                .builder()
                                                .callbackIntantsPaymentsWrapperDTO(callbackIntantPayment)
                                                .systemCode(systemCode)
                                                .build();

        return objectMapper.writeValueAsString(sendCallbackDTO);
    }


}
