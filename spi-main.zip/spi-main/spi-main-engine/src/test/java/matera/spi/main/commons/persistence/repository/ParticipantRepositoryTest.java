package matera.spi.main.commons.persistence.repository;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.persistence.ParticipantRepository;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@IntegrationTest
public class ParticipantRepositoryTest  {

    private static final Integer PARTICIPANT_01_ISPB = 12345;
    private static final String PARTICIPANT_01_NAME = "name";

    private static final Integer PARTICIPANT_02_ISPB = 123456;
    private static final String PARTICIPANT_02_NAME = "name 02";

    @Autowired
    private ParticipantRepository repository;

    @BeforeEach
    public void createParticipants() {

        ParticipantEntity meParticipantEntity01 = createParticipant01();
        repository.saveAndFlush(meParticipantEntity01);

        ParticipantEntity meParticipantEntity02 = createParticipant02();
        repository.saveAndFlush(meParticipantEntity02);
    }

    @AfterEach
    public void deleteParticipants() {

        repository.deleteById(PARTICIPANT_01_ISPB);
        repository.deleteById(PARTICIPANT_02_ISPB);
    }

    @Test
    @Order(2)
    public void findByIspb() {

        Optional<ParticipantEntity> optional =  repository.findByIspb(PARTICIPANT_01_ISPB);

        if(optional.isPresent()) {
            assertEquals(PARTICIPANT_01_ISPB, optional.get().getIspb());
        }
    }

    @Test
    public void findByNameContainingIgnoreCase() {

        List<ParticipantEntity> result =  repository.findByNameContainingIgnoreCase("NAME");

        assertEquals(2, result.size());

        result.forEach(participantEntity -> assertTrue(participantEntity.getName().contains("name")));
    }

    @Test
    public void shouldListOnlyActiveParticipants() {

        Optional<ParticipantEntity> optionalParticipantEntity = repository.findByIspb(PARTICIPANT_01_ISPB);

        ParticipantEntity participantEntity = optionalParticipantEntity.get();
        participantEntity.setActive(false);
        repository.saveAndFlush(participantEntity);

        List<ParticipantEntity> result =  repository.findByNameContainingIgnoreCaseAndActiveIsTrue("NAME");

        assertEquals(1, result.size());
        assertEquals(PARTICIPANT_02_ISPB, result.get(0).getIspb());
    }

    private ParticipantEntity createParticipant01() {

        ParticipantEntity meParticipantEntity = new ParticipantEntity();

        meParticipantEntity.setIspb(PARTICIPANT_01_ISPB);
        meParticipantEntity.setName(PARTICIPANT_01_NAME);
        meParticipantEntity.setActive(true);


        return meParticipantEntity;
    }

    private ParticipantEntity createParticipant02() {

        ParticipantEntity meParticipantEntity = new ParticipantEntity();

        meParticipantEntity.setIspb(PARTICIPANT_02_ISPB);
        meParticipantEntity.setName(PARTICIPANT_02_NAME);
        meParticipantEntity.setActive(true);

        return meParticipantEntity;
    }
}
