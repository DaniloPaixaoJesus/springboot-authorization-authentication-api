package matera.spi.lm.rest;

import com.matera.spi.thirdparties.customers.transactions.api.SPICustomersTransactionContractApis;
import com.matera.spi.thirdparties.customers.transactions.model.LancamentoDataResponseV2DTO;
import com.matera.spi.thirdparties.customers.transactions.model.LancamentoResponseV2DTO;
import com.matera.spi.thirdparties.customers.transactions.model.LancamentoV2DTO;
import com.matera.spi.thirdparties.customers.transactions.model.SaldoDTO;
import com.matera.spi.thirdparties.customers.transactions.model.SaldoResponseDTO;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.ManagerialBalanceResponseDTO;
import matera.spi.dto.PostBalanceAdjustmentRequestDTO;
import matera.spi.dto.PostBalanceAdjustmentRequestDTO.MessageTypeEnum;
import matera.spi.dto.PostBalanceAdjustmentRequestDTO.TransactionTypeEnum;
import matera.spi.dto.PostBalanceAdjustmentResponseDTO;
import matera.spi.lm.domain.model.enums.EnumMessageType;
import matera.spi.lm.domain.model.event.IpAccountBalanceAdjustmentDetailsEntity;
import matera.spi.lm.domain.model.event.IpAccountBalanceAdjustmentEventEntity;
import matera.spi.lm.domain.model.event.MessageType;
import matera.spi.lm.persistence.IpAccountBalanceAdjustmentDetailsRepository;
import matera.spi.main.apisInterface.IpAccountApiService;
import matera.spi.main.domain.model.enums.EnumTransactionType;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventStatusEntity;
import matera.spi.main.domain.model.event.EventTypeEntity;
import matera.spi.main.domain.service.transaction.AccountTransaction;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.EventStatusRepository;
import matera.spi.main.persistence.EventTypeRepository;
import matera.spi.main.transactions.adapter.account.AccountTransactionExecutorAdapter;
import matera.spi.main.transactions.port.AccountTransactionExecutorPort;
import matera.spi.main.utils.FileUtils;
import matera.spi.utils.BigDecimalUtils;
import matera.spi.utils.LocalDateTimeUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.github.tomakehurst.wiremock.WireMockServer;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import net.javacrumbs.jsonunit.JsonAssert;
import org.eclipse.jetty.http.HttpStatus;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import static matera.spi.utils.BigDecimalUtils.compareIf;

import static com.matera.spi.thirdparties.customers.transactions.model.LancamentoResponseV2DTO.ClassificacaoCategoriaContaSPIEnum.CACC;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathMatching;
import static com.github.tomakehurst.wiremock.stubbing.Scenario.STARTED;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.Is.isA;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.http.HttpStatus.OK;

@IntegrationTest
public class BalanceAdjustmentControllerTest {

    private static final String MANAGERIAL_IP_ACCOUNT_BALANCE_BASE_URI = "/ui/v1/psp/balance/ip-account/managerial";
    private static final String BALANCE_ADJUSTMENT_BASE_URI = "/ui/v1/balance/adjustment";
    private static final String STANDIN_API_OAUTH_TOKEN_URL = "/api/oauth/token";
    private static final String STANDIN_API_SALDOS = "/api/v2/contas/.*/.*/saldos";
    private static final String STANDIN_API_LANCAMENTOS = "/api/v2/contas/.*/.*/lancamentos";

    private static final String TRANSACTION_ID = "E008921002020021708289943624de78";

    private final String RESPONSE_BALANCE_ADJUSTMENT_DETAILS_LIST = FileUtils.getStringFromJsonFile(
        "balance-adjustment/response_find_all_balance_adjustments.json");

    private static WireMockServer wireMockServer = new WireMockServer(8088);

    private final static LancamentoDataResponseV2DTO mockedLancamentoResponse = getDefaultLancamentoResponseV2DTO();
    private static SaldoResponseDTO mockedSaldoResponse = getDefaultSaldoResponseDTO();
    private final static SaldoResponseDTO mockedUpdatedSaldoResponse = updateBalance();

    @LocalServerPort
    private int port;

    @Autowired
    private EventStatusRepository eventStatusRepository;

    @Autowired
    private EventTypeRepository eventTypeRepository;

    @Autowired
    private EventRepository eventRepository;

    @Autowired
    private IpAccountApiService mirrorIpAccountService;

    @Autowired
    private IpAccountBalanceAdjustmentDetailsRepository balanceAdjustmentDetailsRepository;

    @Autowired
    private AccountTransaction accountTransaction;

    @Autowired
    SPICustomersTransactionContractApis customersTransactionContractApis;

    private AccountTransactionExecutorPort accountTransactionExecutorPortBackupBean;

    @BeforeAll
    public static void beforeAll() {
        wireMockServer.stubFor(post(urlEqualTo(STANDIN_API_OAUTH_TOKEN_URL))
            .willReturn(aResponse()
                .withStatus(OK.value())
                .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE)
                .withBody(TokenResponseMock.JSON)));

        wireMockServer.stubFor(post(urlPathMatching(STANDIN_API_LANCAMENTOS))
            .willReturn(aResponse()
                .withStatus(OK.value())
                .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE)
                .withBody(TokenResponseMock.getJson(mockedLancamentoResponse))));

        createWireMockStub(STANDIN_API_SALDOS, STARTED, "AfterOperationState", TokenResponseMock.getJson(mockedSaldoResponse));
        createWireMockStub(STANDIN_API_SALDOS, "AfterOperationState", STARTED, TokenResponseMock.getJson(mockedUpdatedSaldoResponse));
        wireMockServer.start();
    }

    @BeforeEach
    void beforeEach() {
        RestAssured.port = port;
        accountTransactionExecutorPortBackupBean = (AccountTransactionExecutorPort) ReflectionTestUtils
            .getField(accountTransaction, "accountTransactionExecutorPort");
        ReflectionTestUtils.setField(accountTransaction, "accountTransactionExecutorPort", new AccountTransactionExecutorAdapter(customersTransactionContractApis));
    }

    @AfterEach
    void afterEach() {
        mockedSaldoResponse = getDefaultSaldoResponseDTO();
        ReflectionTestUtils.setField(accountTransaction, "accountTransactionExecutorPort", accountTransactionExecutorPortBackupBean);
        wireMockServer.resetScenarios();
    }

    @AfterAll
    static void afterAll() {
        wireMockServer.stop();
    }

    @Test
    void testStateWiremock() {
        assertEquals(BigDecimal.valueOf(10000D), mirrorIpAccountService.updateAndGetBalance());
        assertEquals(BigDecimal.valueOf(10010D), mirrorIpAccountService.updateAndGetBalance());
    }

    @Test
    void shouldReturnEventUUIDWhenSendPostRequestToStatementQueryDetails() {
        PostBalanceAdjustmentResponseDTO balanceAdjustmentResponseDTO = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(buildBalanceAdjustmentDTO())
            .when()
            .post(BALANCE_ADJUSTMENT_BASE_URI)
            .then()
            .statusCode(HttpStatus.CREATED_201)
            .extract()
            .as(PostBalanceAdjustmentResponseDTO.class);

        assertNotNull(balanceAdjustmentResponseDTO);
        UUID eventUuid = balanceAdjustmentResponseDTO.getData().getEventUuid();
        Optional<EventEntity> optionalEventEntity = eventRepository.findById(eventUuid);

        assertThat(optionalEventEntity.isPresent(), is(true));
        final IpAccountBalanceAdjustmentEventEntity balanceAdjustmentEventEntity =
            (IpAccountBalanceAdjustmentEventEntity) optionalEventEntity.get();
        assertThat(balanceAdjustmentEventEntity, isA(IpAccountBalanceAdjustmentEventEntity.class));

        final Optional<IpAccountBalanceAdjustmentDetailsEntity> detailsEntityOptional = balanceAdjustmentDetailsRepository
            .findById(balanceAdjustmentEventEntity.getIpAccountBalanceAdjustmentDetailsEntity().getUuid());
        assertThat(detailsEntityOptional.isPresent(), is(true));

        final IpAccountBalanceAdjustmentDetailsEntity balanceAdjustmentDetailsEntity =
            detailsEntityOptional.get();
        Assertions.assertEquals(BigDecimal.valueOf(10000D).stripTrailingZeros(), balanceAdjustmentDetailsEntity.getBalanceBeforeRequest().stripTrailingZeros());
        Assertions.assertEquals(BigDecimal.valueOf(10010D).stripTrailingZeros(), balanceAdjustmentDetailsEntity.getBalanceAfterRequest().stripTrailingZeros());
        Assertions.assertEquals(BigDecimal.TEN.stripTrailingZeros(), balanceAdjustmentDetailsEntity.getValue().stripTrailingZeros());
        assertEquals(TRANSACTION_ID, balanceAdjustmentDetailsEntity.getControlNumberSTR());
    }

    @Test
    void shouldReturnEventUUIDWhenSendPostRequestToMessageTypeLPI0006() {

        String transactionId = "E008921002020021708289943624de79";

        PostBalanceAdjustmentRequestDTO postBalanceAdjustmentRequestDTO = buildBalanceAdjustmentDTO(
            MessageTypeEnum.LPI0006,
            transactionId,
            TransactionTypeEnum.CREDIT,
            BigDecimal.TEN
        );

        PostBalanceAdjustmentResponseDTO balanceAdjustmentResponseDTO = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(postBalanceAdjustmentRequestDTO)
            .when()
            .post(BALANCE_ADJUSTMENT_BASE_URI)
            .then()
            .statusCode(HttpStatus.CREATED_201)
            .extract()
            .as(PostBalanceAdjustmentResponseDTO.class);

        assertNotNull(balanceAdjustmentResponseDTO);
        UUID eventUuid = balanceAdjustmentResponseDTO.getData().getEventUuid();
        Optional<EventEntity> optionalEventEntity = eventRepository.findById(eventUuid);

        assertThat(optionalEventEntity.isPresent(), is(true));
        final IpAccountBalanceAdjustmentEventEntity balanceAdjustmentEventEntity =
            (IpAccountBalanceAdjustmentEventEntity) optionalEventEntity.get();
        assertThat(balanceAdjustmentEventEntity, isA(IpAccountBalanceAdjustmentEventEntity.class));

        final Optional<IpAccountBalanceAdjustmentDetailsEntity> detailsEntityOptional = balanceAdjustmentDetailsRepository
            .findById(balanceAdjustmentEventEntity.getIpAccountBalanceAdjustmentDetailsEntity().getUuid());
        assertThat(detailsEntityOptional.isPresent(), is(true));

        final IpAccountBalanceAdjustmentDetailsEntity balanceAdjustmentDetailsEntity =
            detailsEntityOptional.get();
        Assertions.assertEquals(BigDecimal.valueOf(10000D).stripTrailingZeros(), balanceAdjustmentDetailsEntity.getBalanceBeforeRequest().stripTrailingZeros());
        Assertions.assertEquals(BigDecimal.valueOf(10010D).stripTrailingZeros(), balanceAdjustmentDetailsEntity.getBalanceAfterRequest().stripTrailingZeros());
        Assertions.assertEquals(BigDecimal.TEN.stripTrailingZeros(), balanceAdjustmentDetailsEntity.getValue().stripTrailingZeros());
        assertEquals(transactionId, balanceAdjustmentDetailsEntity.getControlNumberSTR());
    }

    @Test
    void shouldReturnControlNumberSTRNullWhenSendPostRequestToStatementQueryDetailsWithTransactionIdNull() {
        final PostBalanceAdjustmentRequestDTO postBalanceAdjustmentRequestDTO = buildBalanceAdjustmentDTO();
        postBalanceAdjustmentRequestDTO.setTransactionId(null);
        PostBalanceAdjustmentResponseDTO balanceAdjustmentResponseDTO = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(postBalanceAdjustmentRequestDTO)
            .when()
            .post(BALANCE_ADJUSTMENT_BASE_URI)
            .then()
            .statusCode(HttpStatus.CREATED_201)
            .extract()
            .as(PostBalanceAdjustmentResponseDTO.class);

        assertNotNull(balanceAdjustmentResponseDTO);
        UUID eventUuid = balanceAdjustmentResponseDTO.getData().getEventUuid();
        Optional<EventEntity> optionalEventEntity = eventRepository.findById(eventUuid);

        assertThat(optionalEventEntity.isPresent(), is(true));
        final IpAccountBalanceAdjustmentEventEntity balanceAdjustmentEventEntity =
            (IpAccountBalanceAdjustmentEventEntity) optionalEventEntity.get();
        assertThat(balanceAdjustmentEventEntity, isA(IpAccountBalanceAdjustmentEventEntity.class));

        final Optional<IpAccountBalanceAdjustmentDetailsEntity> detailsEntityOptional = balanceAdjustmentDetailsRepository
            .findById(balanceAdjustmentEventEntity.getIpAccountBalanceAdjustmentDetailsEntity().getUuid());
        assertThat(detailsEntityOptional.isPresent(), is(true));

        final IpAccountBalanceAdjustmentDetailsEntity balanceAdjustmentDetailsEntity =
            detailsEntityOptional.get();
        assertTrue(compareIf(balanceAdjustmentDetailsEntity.getBalanceBeforeRequest()).isEqualTo(BigDecimal.valueOf(10000D)));
        assertTrue(compareIf(balanceAdjustmentDetailsEntity.getBalanceAfterRequest()).isEqualTo(BigDecimal.valueOf(10010D)));
        assertTrue(compareIf(balanceAdjustmentDetailsEntity.getValue()).isEqualTo(BigDecimal.TEN));
        assertNull(balanceAdjustmentDetailsEntity.getControlNumberSTR());
    }

    @Test
    void shouldReturnBalanceAdjustmentsWithoutParameters() {
        createBalanceAdjustmentDetails();

        String responseBody = RestAssured.given()
            .header("pageSize", 10)
            .header("pageNumber", 0)
            .when()
            .get(BALANCE_ADJUSTMENT_BASE_URI)
            .thenReturn()
            .body()
            .asString();

        JsonAssert.assertJsonEquals(RESPONSE_BALANCE_ADJUSTMENT_DETAILS_LIST, responseBody);
    }

    @Test
    void shouldReturnBalanceAdjustmentsWithAllParameters() {
        IpAccountBalanceAdjustmentDetailsEntity balanceAdjustmentDetails = createBalanceAdjustmentDetails();

        String responseBody = RestAssured.given()
            .header("pageSize", 10)
            .header("pageNumber", 0)
            .queryParam("startTimestampUtc", LocalDateTimeUtils.getUtcLocalDateTime().minusDays(1).withNano(0).toString())
            .queryParam("endTimestampUtc", LocalDateTimeUtils.getUtcLocalDateTime().plusDays(1).withNano(0).toString())
            .queryParam("messageType", "PACS.004")
            .queryParam("transactionType", "CREDIT")
            .queryParam("eventId", balanceAdjustmentDetails.getEvent().getId())
            .queryParam("endToEndId", "MIP202006061423547")
            .queryParam("minValue", BigDecimal.ONE)
            .queryParam("maxValue", BigDecimal.valueOf(11))
            .when()
            .get(BALANCE_ADJUSTMENT_BASE_URI)
            .thenReturn()
            .body()
            .asString();

        JsonAssert.assertJsonEquals(RESPONSE_BALANCE_ADJUSTMENT_DETAILS_LIST, responseBody);
    }

    @Test
    public void shouldReturnManagerialBalance() {
        final ManagerialBalanceResponseDTO balanceResponseDTO =
            RestAssured.given()
                .log().all()
                .when()
                .get(MANAGERIAL_IP_ACCOUNT_BALANCE_BASE_URI)
                .then().extract()
                .as(ManagerialBalanceResponseDTO.class);

        Assertions.assertNotNull(balanceResponseDTO);
        final BigDecimal managerialBalance = balanceResponseDTO.getData().getValue();
        Assertions.assertTrue(BigDecimalUtils.compareIf(managerialBalance).isEqualTo(new BigDecimal("10000")));
    }

    private static SaldoResponseDTO updateBalance() {
        @Valid final List<LancamentoV2DTO> lancamentos = mockedLancamentoResponse.getData().getLancamentos();
        @NotNull @Valid final BigDecimal lancamentoValue = lancamentos.get(0).getValor();

        final BigDecimal resultBalance = mockedSaldoResponse.getSaldoDisponivel().add(lancamentoValue);
        final SaldoResponseDTO saldoResponseDTO = new SaldoResponseDTO();
        saldoResponseDTO.setData(LocalDateTimeUtils.getTodayUTC());
        saldoResponseDTO.setSaldoBloqueado(BigDecimal.ZERO);
        saldoResponseDTO.setLimiteCreditoDisponivel(BigDecimal.valueOf(10000D));
        saldoResponseDTO.setSaldoDisponivel(resultBalance);
        saldoResponseDTO.setSaldoVinculado(BigDecimal.ZERO);
        saldoResponseDTO.setSaldoContabil(BigDecimal.ZERO);
        return saldoResponseDTO;
    }

    private PostBalanceAdjustmentRequestDTO buildBalanceAdjustmentDTO() {
        final PostBalanceAdjustmentRequestDTO dto = new PostBalanceAdjustmentRequestDTO();

        dto.setMessageType(MessageTypeEnum.PACS_004);
        dto.setPiAccountDatetime(LocalDateTimeUtils.getUtcLocalDateTime());
        dto.setTransactionId(TRANSACTION_ID);
        dto.setTransactionType(TransactionTypeEnum.DEBIT);
        dto.setValue(BigDecimal.TEN);

        return dto;
    }

    private PostBalanceAdjustmentRequestDTO buildBalanceAdjustmentDTO(MessageTypeEnum messageType, String transactionId, TransactionTypeEnum transactionType, BigDecimal value) {
        final PostBalanceAdjustmentRequestDTO dto = new PostBalanceAdjustmentRequestDTO();

        dto.setMessageType(messageType);
        dto.setPiAccountDatetime(LocalDateTimeUtils.getUtcLocalDateTime());
        dto.setTransactionId(transactionId);
        dto.setTransactionType(transactionType);
        dto.setValue(value);

        return dto;
    }

    private IpAccountBalanceAdjustmentDetailsEntity createBalanceAdjustmentDetails() {
        IpAccountBalanceAdjustmentEventEntity ipAccountBalanceAdjustmentEventEntity = new IpAccountBalanceAdjustmentEventEntity();

        ipAccountBalanceAdjustmentEventEntity.setCorrelationId("E00539039202002170828063aec68f6e");
        ipAccountBalanceAdjustmentEventEntity.setClearingTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
        ipAccountBalanceAdjustmentEventEntity.setInitiationTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
        ipAccountBalanceAdjustmentEventEntity.setResponsible(UUID.randomUUID().toString());
        ipAccountBalanceAdjustmentEventEntity.setInitiatorIspb(12345);
        ipAccountBalanceAdjustmentEventEntity.setValue(BigDecimal.TEN);

        EventStatusEntity eventStatusEntity = eventStatusRepository.findByDescription("Success").orElseThrow();
        ipAccountBalanceAdjustmentEventEntity.setStatus(eventStatusEntity);

        EventTypeEntity eventTypeEntity = eventTypeRepository.findByDescription("Ip Account Balance Adjustment").orElseThrow();
        ipAccountBalanceAdjustmentEventEntity.setEventTypeEntity(eventTypeEntity);

        final IpAccountBalanceAdjustmentDetailsEntity entity = new IpAccountBalanceAdjustmentDetailsEntity();
        entity.setControlNumberSTR("MIP202006061423547");
        entity.setValue(BigDecimal.TEN);
        entity.setMessageType(buildMessageType());
        entity.setTransactionTimestamp(LocalDateTime.of(2020,6,6,15,30,30));
        entity.setEvent(ipAccountBalanceAdjustmentEventEntity);

        ipAccountBalanceAdjustmentEventEntity.setIpAccountBalanceAdjustmentDetailsEntity(entity);
        eventRepository.saveAndFlush(ipAccountBalanceAdjustmentEventEntity);

        return entity;
    }

    private MessageType buildMessageType() {
        return new MessageType(EnumTransactionType.CREDIT, EnumMessageType.PACS_004 );
    }

    private static SaldoResponseDTO getDefaultSaldoResponseDTO() {
        final SaldoResponseDTO saldoResponseDTO = new SaldoResponseDTO();
        saldoResponseDTO.setData(LocalDateTimeUtils.getTodayUTC());
        saldoResponseDTO.setSaldoBloqueado(BigDecimal.ZERO);
        saldoResponseDTO.setLimiteCreditoDisponivel(BigDecimal.valueOf(10000D));
        saldoResponseDTO.setSaldoDisponivel(BigDecimal.valueOf(10000D));
        saldoResponseDTO.setSaldoVinculado(BigDecimal.ZERO);
        saldoResponseDTO.setSaldoContabil(BigDecimal.ZERO);
        return saldoResponseDTO;
    }

    private static LancamentoDataResponseV2DTO getDefaultLancamentoResponseV2DTO() {
        final LancamentoResponseV2DTO lancamentoResponseV2DTO = new LancamentoResponseV2DTO();
        lancamentoResponseV2DTO.setSubSistema("STANDIN");
        lancamentoResponseV2DTO.setNomeUsuario("SDBANCO");
        lancamentoResponseV2DTO.setLoteEntrada(BigDecimal.valueOf(3691275723396573863894549962393805119D));
        lancamentoResponseV2DTO.setClassificacaoCategoriaContaSPI(CACC);
        lancamentoResponseV2DTO.setCpfCnpjTitular(BigDecimal.valueOf(24276273137L));
        lancamentoResponseV2DTO.setLancamentos(buildLancamentoV2DTO());
        lancamentoResponseV2DTO.setSaldo(buildSaldoDTO());

        final LancamentoDataResponseV2DTO lancamentoDataResponseV2DTO = new LancamentoDataResponseV2DTO();
        lancamentoDataResponseV2DTO.setData(lancamentoResponseV2DTO);
        return lancamentoDataResponseV2DTO;
    }

    private static SaldoDTO buildSaldoDTO() {
        final SaldoDTO saldoDTO = new SaldoDTO();
        saldoDTO.setData(LocalDateTimeUtils.getTodayUTC());
        saldoDTO.setSaldoBloqueado(BigDecimal.ZERO);
        saldoDTO.setLimiteCreditoDisponivel(BigDecimal.valueOf(10000D));
        saldoDTO.setSaldoDisponivel(BigDecimal.valueOf(10010D));
        saldoDTO.setSaldoVinculado(BigDecimal.ZERO);
        saldoDTO.setSaldoContabil(BigDecimal.ZERO);
        saldoDTO.setSaldoInvestimento(BigDecimal.ZERO);
        return saldoDTO;
    }

    private static List<LancamentoV2DTO> buildLancamentoV2DTO() {
        final LancamentoV2DTO lancamentoV2DTO = new LancamentoV2DTO();
        lancamentoV2DTO.setIdLancamento(BigDecimal.valueOf(222609220701524678307358757463152262719D));
        lancamentoV2DTO.setDataLancamento(LocalDateTimeUtils.getTodayUTC());
        lancamentoV2DTO.setHistorico(120);
        lancamentoV2DTO.setDocumento(123L);
        lancamentoV2DTO.setValor(BigDecimal.TEN);
        lancamentoV2DTO.setComplementoHistorico("TesteSTDIN");
        lancamentoV2DTO.setAgenciaGeradora(1);
        lancamentoV2DTO.setTipoLimite(LancamentoV2DTO.TipoLimiteEnum.SALDO_MAIS_LIMITE);
        lancamentoV2DTO.setReferenciaMovimento("teste1495");
        lancamentoV2DTO.setExibeLancamentoAgrupado(false);
        lancamentoV2DTO.setEnviaNotificacao(true);
        lancamentoV2DTO.setValidaSaldo(LancamentoV2DTO.ValidaSaldoEnum.VALIDA_SE_SISTEMA_CONFIGURADO);
        lancamentoV2DTO.setAtualizaValorLote(true);
        lancamentoV2DTO.setDetalhes("teste1495");

        return List.of(lancamentoV2DTO);
    }

    private static void createWireMockStub(String url, String currentState, String nextState, String responseBody) {
        wireMockServer.stubFor(get(urlPathMatching(url))
            .inScenario("StandinResponseTest")
            .whenScenarioStateIs(currentState)
            .willSetStateTo(nextState)
            .willReturn(aResponse()
                .withStatus(OK.value())
                .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE)
                .withBody(responseBody)));
    }

    private static class TokenResponseMock {
        static final String JSON = getJson(new TokenResponseMock());
        public String access_token = "ab12345c-6789-012d-3ee4-f56789g01hij"; // random token
        public String token_type = "bearer";
        public int expires_in = 86399;
        public String scope = "app";

        private static String getJson(Object object) {
            try {
                ObjectMapper mapper = new ObjectMapper();
                mapper.registerModule(new JavaTimeModule());
                mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
                return mapper.writeValueAsString(object);
            } catch (JsonProcessingException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
