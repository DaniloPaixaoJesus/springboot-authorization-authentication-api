package matera.spi.main.application.service;

import com.matera.commons.utils.exception.BusinessException;
import matera.spi.dto.ReturnEventUUIDDTO;
import matera.spi.dto.ReturnSettlementUIWapperDTO;
import matera.spi.main.config.MainEngineConfiguration;
import matera.spi.main.domain.model.account.PayerAccountEntity;
import matera.spi.main.domain.model.account.ReceiverAccountEntity;
import matera.spi.main.domain.model.event.EventStatus;
import matera.spi.main.domain.model.event.EventStatusEntity;
import matera.spi.main.domain.model.event.transaction.ReceiptEventEntity;
import matera.spi.main.domain.model.event.transaction.ReturnSentEventEntity;
import matera.spi.main.domain.model.transaction.ReceiptEntity;
import matera.spi.main.domain.model.transaction.ReturnSentEntity;
import matera.spi.main.domain.model.transaction.TransactionPriorityEntity;
import matera.spi.main.domain.service.ClientSystemService;
import matera.spi.main.domain.service.ReturnSentService;
import matera.spi.main.domain.service.ReturnSentValidator;
import matera.spi.main.domain.service.event.transaction.ReturnSentEvent;
import matera.spi.main.domain.service.messaging.MessagingAvailabilityChecker;
import matera.spi.main.domain.service.participants.IntraMipVerifier;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.ReceiptEventRepository;
import matera.spi.main.utils.EntityCreationUtils;
import matera.spi.utils.LocalDateTimeUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.UUID;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ReturnApplicationUIServiceTest {

    public static final String SPI_ME_006 = "SPI-ME-006";
    public static final String SPI_ME_011 = "SPI-ME-011";
    private static final String ID = "fe7962e7-12a5-46de-bf21-22868af37385";

    @Mock
    private ReturnSentService returnSentService;

    @Mock
    private ReturnSentValidator returnSentValidator;

    @Mock
    private MessagingAvailabilityChecker messagingAvailabilityChecker;

    @Mock
    private ReceiptEventRepository receiptEventRepository;

    @Mock
    private EventRepository eventRepository;

    @Mock
    private MainEngineConfiguration mainEngineConfiguration;

    @Mock
    private IntraMipVerifier intraMipVerifier;

    @InjectMocks
    private ReturnApplicationUIService returnApplicationUIService;

    private ReturnSettlementUIWapperDTO returnSettlementUIWapper = createReturnSettlementUIWapperDTO();

    @Test
    void shouldSentReturnSuccess() throws JsonProcessingException {

        BigDecimal originalEventValue = new BigDecimal(7905);
        Integer daysReturnExpiration = -89;
        EventStatus eventStatus = EventStatus.SUCCESS;

        ReceiptEventEntity receiptEventEntity = createReceiptEventEntity(originalEventValue, daysReturnExpiration, eventStatus);
        when(receiptEventRepository.findByCorrelationId(anyString())).thenReturn(receiptEventEntity);

        TransactionPriorityEntity transactionPriorityEntity = createpriorityByCode(returnSettlementUIWapper.getSettlementPriority());
        when(returnSentService.priorityByCode(any())).thenReturn(transactionPriorityEntity);

        ReturnSentEvent returnSentEvent = createReturnSentEvent();
        ReturnSentEntity returnSentEntity = returnApplicationUIService.getReturnSentEntity(returnSettlementUIWapper,receiptEventEntity);
        when(returnSentService.createReturn(returnSentEntity, receiptEventEntity, returnSettlementUIWapper.getReturnedInterbankSettlementAmount(), "", null)).thenReturn(createReturnSentEvent());

        ReturnEventUUIDDTO returnResponseUI = returnApplicationUIService.sentReturn(returnSettlementUIWapper);

        assertEquals(returnSentEvent.getId(), returnResponseUI.getEventUuid());
    }


    @Test
    void shouldValidateEventNofFound() {
        BusinessException thrown = Assertions.assertThrows(BusinessException.class, () -> returnApplicationUIService.sentReturn(returnSettlementUIWapper));
        assertTrue(thrown.getCode().contains(SPI_ME_006));

        verifyNoMoreInteractions(eventRepository);

        verify(returnSentService, times(0)).createReturn((ReturnSentEntity) any(), any(), any(), any(), any());
    }

    @Test
    @Disabled("Receiver validation was removed this rule will be ignored by now")
    void shouldValidateReceiverParticipant() {
        BigDecimal originalEventValue = new BigDecimal("131.00");
        Integer daysReturnExpiration = -93;
        Integer differentIspb = 87654321;
        EventStatus eventStatus = EventStatus.SUCCESS;

        ReceiptEventEntity originalReceiptEventEntity = createReceiptEventEntity(originalEventValue, daysReturnExpiration, eventStatus);
        originalReceiptEventEntity.getReceiptEntity().getReceiverParticipant().setIspb(differentIspb);
        ReturnSentEntity returnSentEntity = returnApplicationUIService.getReturnSentEntity(returnSettlementUIWapper,originalReceiptEventEntity);

        when(receiptEventRepository.findByCorrelationId(any())).thenReturn(originalReceiptEventEntity);

        BusinessException thrown = Assertions.assertThrows(BusinessException.class, () -> returnApplicationUIService.sentReturn(returnSettlementUIWapper));
        assertTrue(thrown.getCode().contains(SPI_ME_011));

        verifyNoMoreInteractions(eventRepository);

        verify(returnSentService, times(0)).createReturn((ReturnSentEntity) any(), any(), any(), any(), any());
    }

    @Test
    void shouldValidateRejectEventFound() {
        BigDecimal originalEventValue = new BigDecimal(7905);
        Integer daysReturnExpiration = -89;
        EventStatus eventStatus = EventStatus.RECEIPT_REJECTED;

        ReceiptEventEntity receiptEventEntity = createReceiptEventEntity(originalEventValue, daysReturnExpiration, eventStatus);
        when(receiptEventRepository.findByCorrelationId(anyString())).thenReturn(receiptEventEntity);

        BusinessException thrown = Assertions.assertThrows(BusinessException.class, () -> returnApplicationUIService.sentReturn(returnSettlementUIWapper));
        assertTrue(thrown.getCode().contains(SPI_ME_006));
    }

    private static ReturnSettlementUIWapperDTO createReturnSettlementUIWapperDTO() {
        ObjectMapper objectMapper = new ObjectMapper();

        String jsonReturn = "{\n" + "  \"originalEndToEndIdentification\": \"E1234567820200217082881978999530\",\n" +
            "  \"returnEndToEndIdentification\": \"D12345678202005180219TUYFXjgyK6n\",\n" +
            "  \"settlementMethod\": \"CLRG\",\n" +
            "  \"returnedInterbankSettlementAmount\":\t7905,\n" +
            "  \"settlementPriority\": \"HIGH\",\n" + "  \"chargeBearer\": \"SLEV\",\n" +
            "  \"returnReasonInformation\": \"UPAY\",\n" + "  \"debtorAgent\": \"13370835\",\n" +
            "  \"creditorAgent\": \"000000000\",\n" +
            "  \"additionalInformation\": \"Return sent bank 000000000 \"\n" + "}";

        ReturnSettlementUIWapperDTO returnSettlementUIWapperDTO = null;
        try {
            returnSettlementUIWapperDTO = objectMapper.readValue(jsonReturn, ReturnSettlementUIWapperDTO.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }

        return returnSettlementUIWapperDTO;

    }

    private ReceiptEventEntity createReceiptEventEntity(BigDecimal eventValue, Integer daysReturnExpiration,
                                                        EventStatus eventStatus){
        ReceiptEventEntity receiptEventEntity = new ReceiptEventEntity();
        receiptEventEntity.setValue(eventValue);
        receiptEventEntity.setInitiationTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime().plusDays(daysReturnExpiration));
        receiptEventEntity.setStatus(new EventStatusEntity());
        receiptEventEntity.setReceiptEntity(new ReceiptEntity());
        receiptEventEntity.getReceiptEntity().setReceiverParticipant(EntityCreationUtils.buildReceiverParticipant());
        receiptEventEntity.getReceiptEntity().setPayerParticipant(EntityCreationUtils.buildSenderParticipant());
        receiptEventEntity.getStatus().setCode(eventStatus.getCode());

        PayerAccountEntity payerAccountEntity = new PayerAccountEntity();
        payerAccountEntity.setTaxId("1234567");
        payerAccountEntity.setAccountType("AccounType");
        payerAccountEntity.setBranch("1234567");
        payerAccountEntity.setAccount("1234567");
        payerAccountEntity.setName("payerAccountEntity");

        receiptEventEntity.getTransactionEntity().setPayerAccount(payerAccountEntity);

        ReceiverAccountEntity receiverAccountEntity = new ReceiverAccountEntity();
        receiverAccountEntity.setTaxId("1234567");
        receiverAccountEntity.setAccountType("AccounType");
        receiverAccountEntity.setBranch("1234567");
        receiverAccountEntity.setAccount("1234567");

        receiptEventEntity.getTransactionEntity().setReceiverAccount(receiverAccountEntity);

        return receiptEventEntity;
    }

    private ReturnSentEvent createReturnSentEvent() {
        ReturnSentEventEntity eventEntity = new ReturnSentEventEntity();
        eventEntity.setId(UUID.fromString(ID));
        ReturnSentEvent returnSentEvent = new ReturnSentEvent(eventEntity);
        return returnSentEvent;
    }

    private TransactionPriorityEntity createpriorityByCode(String settlementPriority) {
        TransactionPriorityEntity expected = new TransactionPriorityEntity();
        expected.setCode("1000");
        expected.setDescription(settlementPriority);
        return expected;
    }

}


