package matera.spi.main.domain.service.pacs.pacs002;

import com.matera.spi.messaging.model.MessageSentResponseDTO;
import com.matera.spi.messaging.model.MessageSpecificationDTO;

import matera.spi.main.domain.service.CorrelationIdGenerator;
import matera.spi.main.domain.service.MessageIdGenerator;
import matera.spi.main.domain.service.MessageSender;
import matera.spi.main.domain.service.messages.factory.pacs002.Pacs002DTO;
import matera.spi.main.domain.service.messages.factory.pacs002.Pacs002Factory;
import matera.spi.main.domain.service.pacs.pacs002.dto.ContentPacs002;
import matera.spi.main.exception.MessagingInternalErrorException;
import matera.spi.main.exception.MessagingUnavailableException;
import matera.spi.utils.exceptions.XmlMarshalException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;

@ExtendWith(MockitoExtension.class)
class MessageSendPacs002Test {

    private static final String PI_RESOURCE_ID = "PiResourceId";
    private static final ZonedDateTime ZONED_DATE_TIME = ZonedDateTime.now(ZoneOffset.UTC);
    private static final String ISPB = "12345678";
    private static final String MESSAGE_CONTENT = "<xml></xml>";
    private static final String MESSAGE_ID = MessageIdGenerator.generate(ISPB);
    private static final String END_TO_END_ID = CorrelationIdGenerator.generateCorrelactionIdPacs008(ISPB);
    private static final MessageSentResponseDTO MESSAGE_SENT_RESPONSE_DTO = messageSentResponseDTOMock();
    private static final ContentPacs002 CONTENT_PACS_002 = contentPacs002Mock();

    @Mock
    private Pacs002Factory pacs002Factory;

    @Mock
    private MessageSender messageSender;

    @InjectMocks
    private MessageSendPacs002 messageSendPacs002;

    @Test
    void shouldSendPacs002() {
        Mockito.when(pacs002Factory.createXml(Mockito.any(Pacs002DTO.class))).thenReturn(MESSAGE_CONTENT);
        Mockito.when(messageSender.sendMessage(Mockito.any(MessageSpecificationDTO.class))).thenReturn(MESSAGE_SENT_RESPONSE_DTO);

        MessageSentResponseDTO actual = messageSendPacs002.send(CONTENT_PACS_002);

        Assertions.assertEquals(MESSAGE_SENT_RESPONSE_DTO, actual);
    }

    @Test
    void shouldThrowNullPointerException() {
        Assertions.assertThrows(NullPointerException.class, () -> messageSendPacs002.send(ContentPacs002.builder().build()));
    }

    @Test
    void shouldThrowXmlMarshalException() {
        Mockito.when(pacs002Factory.createXml(Mockito.any(Pacs002DTO.class))).thenThrow(XmlMarshalException.class);

        Assertions.assertThrows(XmlMarshalException.class, () -> messageSendPacs002.send(CONTENT_PACS_002));
    }

    @Test
    void shouldThrowMessagingUnavailableException() {
        Mockito.when(messageSender.sendMessage(Mockito.any(MessageSpecificationDTO.class))).thenThrow(MessagingUnavailableException.class);

        Assertions.assertThrows(MessagingUnavailableException.class, () -> messageSendPacs002.send(CONTENT_PACS_002));
    }

    @Test
    void shouldThrowMessagingInternalErrorException() {
        Mockito.when(messageSender.sendMessage(Mockito.any(MessageSpecificationDTO.class))).thenThrow(MessagingInternalErrorException.class);

        Assertions.assertThrows(MessagingInternalErrorException.class, () -> messageSendPacs002.send(CONTENT_PACS_002));
    }

    private static ContentPacs002 contentPacs002Mock() {
        return ContentPacs002.builder()
                            .creationDate(ZONED_DATE_TIME)
                            .messageId(MESSAGE_ID)
                            .endToEndId(END_TO_END_ID)
                            .messageIdentifier("pacs.002.spi.1.4")
                            .build();
    }

    private static MessageSentResponseDTO messageSentResponseDTOMock() {
        MessageSentResponseDTO messageSentResponseDTO = new MessageSentResponseDTO();
        messageSentResponseDTO.setPiResourceID(PI_RESOURCE_ID);
        return messageSentResponseDTO;
    }

}
