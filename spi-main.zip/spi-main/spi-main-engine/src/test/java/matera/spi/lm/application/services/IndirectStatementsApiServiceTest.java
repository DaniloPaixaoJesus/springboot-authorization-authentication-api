package matera.spi.lm.application.services;

import matera.spi.lm.application.service.statements.IndirectStatementsApiService;
import matera.spi.lm.exception.IndirectParticipantOperationInvalidException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;

@ExtendWith(MockitoExtension.class)
public class IndirectStatementsApiServiceTest {

    @Spy
    private IndirectStatementsApiService indirectStatementsApiService;

    @Test
    void shouldThrowExceptionWhenRequestNewStatementDetail() {
        Assertions.assertThrows(IndirectParticipantOperationInvalidException.class,
            () -> indirectStatementsApiService.requestNewStatementDetail(any()));
    }

    @Test
    void shouldThrowExceptionWhenRequestDownloadCsvFile() {
        Assertions.assertThrows(IndirectParticipantOperationInvalidException.class,
            () -> indirectStatementsApiService.downloadCsvFileFromEventUuid(any()));
    }

    @Test
    void shouldThrowExceptionWhenGetXmlContent() {
        Assertions.assertThrows(IndirectParticipantOperationInvalidException.class,
            () -> indirectStatementsApiService.getXmlContent(any()));
    }

    @Test
    void shouldThrowExceptionWhenGetStatements() {
        Assertions.assertThrows(IndirectParticipantOperationInvalidException.class,
            () -> indirectStatementsApiService.getStatements(any(), any(), anyInt(), anyInt()));
    }

    @Test
    void shouldThrowExceptionWhenGetStatementTransaction() {
        Assertions.assertThrows(IndirectParticipantOperationInvalidException.class,
            () -> indirectStatementsApiService.getStatementTransactions(anyInt(), anyInt(), any(), any(), any()));
    }

}
