package matera.spi.lm.domain.service.event;

import com.matera.spi.thirdparties.spb.model.EventoItemResponseDTO;
import com.matera.spi.thirdparties.spb.model.EventoResponseDTO;
import com.matera.spi.thirdparties.spb.model.LoteEventoRequestDTO;
import com.matera.spi.thirdparties.spb.model.LoteEventoResponseDataDTO;
import matera.spi.dto.SpbCallbackDTO;
import matera.spi.lm.domain.model.spb.SpbEventEntity;
import matera.spi.lm.domain.model.spb.withdraw.IpAccountWithdrawDetailsEntity;
import matera.spi.lm.domain.model.spb.withdraw.IpAccountWithdrawEventEntity;
import matera.spi.lm.domain.service.event.spb.LoteEventoRequestFactory;
import matera.spi.lm.domain.service.lpis.lpi0003.Lpi0003Factory;
import matera.spi.lm.domain.service.lpis.lpi0004.Lpi0004Factory;
import matera.spi.lm.dto.event.IpAccountWithdrawEventSpecificationDTO;
import matera.spi.lm.persistence.SpbMessageRepository;
import matera.spi.lm.transactions.adapter.spb.SpbOutgoingPortImpl;
import matera.spi.main.config.MainEngineConfiguration;
import matera.spi.main.domain.model.ConfigEntity;
import matera.spi.main.domain.model.event.transaction.TransactionEventEntity;
import matera.spi.main.domain.model.transaction.TransactionResultEntity;
import matera.spi.main.domain.service.ConfigurationService;
import matera.spi.main.domain.service.PrincipalAuthenticationService;
import matera.spi.main.domain.service.transaction.AccountTransactionReverter;
import matera.spi.main.domain.service.transaction.MirrorIPAccount;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.TransactionResultRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.internal.util.collections.Sets;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.lenient;

public class IpAccountWithdrawEventTest {

    public static final String END_TO_END_ID = "E0057376820200217082881978247550";

    @InjectMocks
    private WithdrawEventTest withdrawEvent;

    @Mock
    private MirrorIPAccount mirrorIPAccount;

    @Mock
    private TransactionResultRepository transactionResultRepository;

    @Mock
    private SpbMessageRepository spbMessageRepository;

    @Mock
    private EventRepository eventRepository;

    @Mock
    private SpbOutgoingPortImpl spbOutgoingPort;

    @Mock
    private AccountTransactionReverter accountTransactionReverter;

    @Mock
    private ConfigurationService configurationService;

    @Mock
    private PrincipalAuthenticationService principalAuthenticationService;

    @Mock
    private MainEngineConfiguration mainEngineConfiguration;

    @Spy
    private Lpi0003Factory lpi0003Factory;

    @Spy
    private Lpi0004Factory lpi0004Factory;

    @Spy
    private LoteEventoRequestFactory loteEventoRequestFactory;

    @Spy
    private LpiDTOFactory lpiDTOFactory;

    private IpAccountWithdrawEventEntity withdrawEventEntity;

    private TransactionResultEntity transactionResultEntity;

    @BeforeEach
    void init() {
        withdrawEventEntity = createIpAccountWithdrawEventEntity();
        withdrawEvent = new WithdrawEventTest(withdrawEventEntity);
        transactionResultEntity = buildTransactionResultEntity();
        MockitoAnnotations.initMocks(this);

        ConfigEntity configEntity = Mockito.mock(ConfigEntity.class);
        doReturn(123).when(configEntity).getIspb();
        doReturn(configEntity).when(configurationService).findConfig();
        doReturn("Operador de Teste").when(principalAuthenticationService).getPrincipalAuthentication();
        doReturn("00000456").when(mainEngineConfiguration).getClearingIspb();
        doReturn(new LoteEventoRequestDTO()).when(loteEventoRequestFactory).build(any(), any(), any(), any(), any(), any());
        lenient().doReturn(transactionResultEntity).when(mirrorIPAccount).makeDebit(any(), any());
        lenient().doReturn(transactionResultEntity).when(transactionResultRepository).save(any());
        doReturn(buildSpbResponseDataDTO()).when(spbOutgoingPort).sendMessage(any());
    }

    @Test
    void shouldSetTransactionResultInEventEntity() {
        Assertions.assertNull(withdrawEvent.getEventEntity().getTransactionResult());
        withdrawEvent.sendMessage();

        final TransactionResultEntity actual = withdrawEvent.getEventEntity().getTransactionResult();
        Assertions.assertNotNull(actual);
        Assertions.assertEquals(transactionResultEntity.getId(), actual.getId());
        Assertions.assertEquals(transactionResultEntity.getTransactionIdInDdaSystem(), actual.getTransactionIdInDdaSystem());
    }

    private LoteEventoResponseDataDTO buildSpbResponseDataDTO() {
        final LoteEventoResponseDataDTO loteEventoResponseDataDTO = new LoteEventoResponseDataDTO();
        final EventoItemResponseDTO eventoItemResponseDTO = new EventoItemResponseDTO();

        eventoItemResponseDTO.setData(buildEventoResponseDTO());
        loteEventoResponseDataDTO.setItems(List.of(eventoItemResponseDTO));
        return loteEventoResponseDataDTO;
    }

    private EventoResponseDTO buildEventoResponseDTO() {
        final EventoResponseDTO eventoResponseDTO = new EventoResponseDTO();
        eventoResponseDTO.setItemId(withdrawEvent.getEventEntity().getId().toString());
        eventoResponseDTO.setId(1);
        eventoResponseDTO.setSistemaOrigem("MIP");
        eventoResponseDTO.setTipoEvento("LPI0003");
        eventoResponseDTO.setNumEmpresa(1d);
        eventoResponseDTO.setOperador("Operador de Teste");
        eventoResponseDTO.setDataHoraAgendamento(null);
        eventoResponseDTO.setTipoTransacaoOrigem("LPI0003");
        eventoResponseDTO.setOperacaoOrigemId1(withdrawEvent.getEventEntity().getId().toString());
        eventoResponseDTO.setOperacaoOrigemId2(null);
        eventoResponseDTO.setIspbRemetente("00000123");
        eventoResponseDTO.setIspbDestinatario("00000456");
        eventoResponseDTO.setDescricao("Teste");
        eventoResponseDTO.setValor(BigDecimal.TEN.floatValue());
        eventoResponseDTO.setDominioSistema(EventoResponseDTO.DominioSistemaEnum.SPB01);
        eventoResponseDTO.setMessage("<LPI0003>Content</LPI0003>");
        eventoResponseDTO.setUrl("/v1/eventos-retorno");
        return eventoResponseDTO;
    }

    private IpAccountWithdrawEventEntity createIpAccountWithdrawEventEntity() {
        final IpAccountWithdrawEventEntity withdrawEventEntity = new IpAccountWithdrawEventEntity();
        withdrawEventEntity.setIpAccountWithdrawDetails(createSpbDepositEventDetailsEntity());
        setBasicEventInfo(withdrawEventEntity);
        return Mockito.spy(withdrawEventEntity);
    }

    private IpAccountWithdrawDetailsEntity createSpbDepositEventDetailsEntity() {
        final IpAccountWithdrawDetailsEntity detailsEntity = new IpAccountWithdrawDetailsEntity();
        detailsEntity.setIspbIfCredtd(100L);
        detailsEntity.setIspbpspi(999L);
        detailsEntity.setFinlddLPI(450L);
        return detailsEntity;
    }

    private void setBasicEventInfo(SpbEventEntity spbEventEntity) {
        spbEventEntity.setId(UUID.randomUUID());
        spbEventEntity.setSpbEventId(1L);
        spbEventEntity.setControlNumber("1a2b3c");
        spbEventEntity.setMovementDate(LocalDate.of(2020, 5, 11));
        spbEventEntity.setSpbMessageEntity(Sets.newSet());
        spbEventEntity.setValue(BigDecimal.TEN);
        spbEventEntity.setInitiationTimestampUTC(LocalDateTime.now());
        spbEventEntity.setInitiatorIspb(1);
        spbEventEntity.setCorrelationId(END_TO_END_ID);
    }

    private TransactionResultEntity buildTransactionResultEntity() {
        final TransactionResultEntity transactionResultEntity = new TransactionResultEntity();
        transactionResultEntity.setId(UUID.randomUUID());
        transactionResultEntity.setTransactionIdInDdaSystem(BigDecimal.valueOf(200D));
        return transactionResultEntity;
    }

    public static class WithdrawEventTest extends IpAccountWithdrawEvent {

        public WithdrawEventTest(TransactionEventEntity eventEntity) {
            super(eventEntity);
        }

        public WithdrawEventTest(IpAccountWithdrawEventSpecificationDTO eventSpecificationDto) {
            super(eventSpecificationDto);
        }

        public void actionsOnSpbReturn(SpbCallbackDTO spbCallbackDTO) {
            super.actionsOnSpbReturn(spbCallbackDTO);
        }
    }

}
