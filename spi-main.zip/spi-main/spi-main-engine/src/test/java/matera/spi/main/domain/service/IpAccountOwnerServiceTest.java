package matera.spi.main.domain.service;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.IpAccountOwnerEntity;
import matera.spi.main.domain.model.event.IpAccountOwnerStatus;
import matera.spi.main.utils.EntityCreationUtils;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.opentest4j.AssertionFailedError;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

@IntegrationTest
class IpAccountOwnerServiceTest {

    @Autowired
    private IpAccountOwnerService ipAccountOwnerService;

    @Test
    void shouldCreateIpAccountOwnerOnlyWithRequiredFields() {

        IpAccountOwnerEntity newIpAccountOwnerEntity = EntityCreationUtils.buildIpAccountOwnerEntityWithRequiredFields();
        ipAccountOwnerService.save(newIpAccountOwnerEntity);

        IpAccountOwnerEntity searchedIpAccountOwnerEntity = ipAccountOwnerService.findById(newIpAccountOwnerEntity.getId())
            .orElseThrow(AssertionFailedError::new);

        assertEquals(newIpAccountOwnerEntity, searchedIpAccountOwnerEntity);
    }

    @Test
    void shouldCreateIpAccountOwnerOnlyWithAllFields() {

        IpAccountOwnerEntity newIpAccountOwnerEntity = EntityCreationUtils.buildIpAccountOwnerEntityWithRequiredFields();

        newIpAccountOwnerEntity.setDirectorMobile("+55-44999112233");
        newIpAccountOwnerEntity.setEmployeeMobile("+55-44988776655");
        newIpAccountOwnerEntity.setEmployeeFax("+55-44988336622");
        newIpAccountOwnerEntity.setClearingTimestamp(LocalDateTime.parse("2020-07-24T18:13:30.892"));
        newIpAccountOwnerEntity.setStatus(IpAccountOwnerStatus.ACTIVE);

        ipAccountOwnerService.save(newIpAccountOwnerEntity);

        IpAccountOwnerEntity searchedIpAccountOwnerEntity =  ipAccountOwnerService.findById(newIpAccountOwnerEntity.getId())
            .orElseThrow(AssertionFailedError::new);

        assertEquals(newIpAccountOwnerEntity, searchedIpAccountOwnerEntity);
    }

    @Test
    void shouldReturnTheFirstActiveIpAccountOwnerEntity() {

        IpAccountOwnerEntity expectedActiveOwner = EntityCreationUtils.buildIpAccountOwnerEntityWithRequiredFields();
        expectedActiveOwner.setStatus(IpAccountOwnerStatus.ACTIVE);
        ipAccountOwnerService.save(expectedActiveOwner);

        IpAccountOwnerEntity inactiveOwner = EntityCreationUtils.buildIpAccountOwnerEntityWithRequiredFields();
        inactiveOwner.setStatus(IpAccountOwnerStatus.INACTIVE);
        ipAccountOwnerService.save(inactiveOwner);

        Optional<IpAccountOwnerEntity> activeOwner = ipAccountOwnerService.getActive();
        assertThat(activeOwner).hasValue(expectedActiveOwner);
    }

    @Test
    void shouldReturnOptionalEmptyIfNotFoundAnyActiveOwner() {

        IpAccountOwnerEntity expectedActiveOwner = EntityCreationUtils.buildIpAccountOwnerEntityWithRequiredFields();
        expectedActiveOwner.setStatus(IpAccountOwnerStatus.INACTIVE);
        ipAccountOwnerService.save(expectedActiveOwner);

        IpAccountOwnerEntity inactiveOwner = EntityCreationUtils.buildIpAccountOwnerEntityWithRequiredFields();
        inactiveOwner.setStatus(IpAccountOwnerStatus.REJECTED);
        ipAccountOwnerService.save(inactiveOwner);

        Optional<IpAccountOwnerEntity> activeOwner = ipAccountOwnerService.getActive();
        assertThat(activeOwner).isNotPresent();
    }

    @Test
    @DisplayName("hasOwnerWaitingConfirmation should return false when does not have any owner with waiting confirmation status")
    void shouldReturnFalseWhenDoesNotHaveOwnerWaitingConfirmation() {

        IpAccountOwnerEntity expectedActiveOwner = EntityCreationUtils.buildIpAccountOwnerEntityWithRequiredFields();
        expectedActiveOwner.setStatus(IpAccountOwnerStatus.INACTIVE);
        ipAccountOwnerService.save(expectedActiveOwner);

        IpAccountOwnerEntity inactiveOwner = EntityCreationUtils.buildIpAccountOwnerEntityWithRequiredFields();
        inactiveOwner.setStatus(IpAccountOwnerStatus.REJECTED);
        ipAccountOwnerService.save(inactiveOwner);

        boolean hasOwnerWaitingConfirmation = ipAccountOwnerService.hasOwnerWaitingConfirmation();
        assertThat(hasOwnerWaitingConfirmation).isFalse();
    }

    @Test
    @DisplayName("hasOwnerWaitingConfirmation should return true when there is an owner with waiting confirmation status")
    void shouldReturnTrueWhenHaveOwnerWaitingConfirmation() {

        IpAccountOwnerEntity expectedActiveOwner = EntityCreationUtils.buildIpAccountOwnerEntityWithRequiredFields();
        expectedActiveOwner.setStatus(IpAccountOwnerStatus.ACTIVE);
        ipAccountOwnerService.save(expectedActiveOwner);

        IpAccountOwnerEntity waitingConfirmationOwner = EntityCreationUtils.buildIpAccountOwnerEntityWithRequiredFields();
        waitingConfirmationOwner.setStatus(IpAccountOwnerStatus.WAITING_CONFIRMATION);
        ipAccountOwnerService.save(waitingConfirmationOwner);

        boolean hasOwnerWaitingConfirmation = ipAccountOwnerService.hasOwnerWaitingConfirmation();
        assertThat(hasOwnerWaitingConfirmation).isTrue();
    }

}
