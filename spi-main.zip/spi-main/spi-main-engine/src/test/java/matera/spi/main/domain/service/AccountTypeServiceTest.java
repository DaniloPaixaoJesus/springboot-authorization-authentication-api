package matera.spi.main.domain.service;

import matera.spi.main.domain.model.account.AccountTypeEntity;
import matera.spi.main.persistence.AccountTypeRepository;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

@ExtendWith(MockitoExtension.class)
public class AccountTypeServiceTest {

    private static final String ACCOUNT_TYPE_CODE = "ABCD";

    @Mock
    private AccountTypeRepository accountTypeRepository;

    @InjectMocks
    private AccountTypeService accountTypeService;

    @Test
    void shouldGetAccountTypeByCode() {
        accountTypeService.getAccountTypeByCode(ACCOUNT_TYPE_CODE);

        Mockito.verify(accountTypeRepository, Mockito.times(1)).findById(ACCOUNT_TYPE_CODE);
    }

    @Test
    void shouldReturnAnAccountTypeEmpty() {
        Mockito.when(accountTypeService.getAccountTypeByCode(ACCOUNT_TYPE_CODE)).thenReturn(Optional.empty());

        Optional<AccountTypeEntity> accountTypeEntityOptional = accountTypeService.getAccountTypeByCode(ACCOUNT_TYPE_CODE);

        Assertions.assertTrue(accountTypeEntityOptional.isEmpty());
    }

}
