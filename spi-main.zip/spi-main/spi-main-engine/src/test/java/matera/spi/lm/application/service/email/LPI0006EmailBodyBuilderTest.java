package matera.spi.lm.application.service.email;


import matera.spi.lm.application.service.email.lpi0006.Lpi0006ErrorEmailBodyBuilder;
import matera.spi.lm.application.service.email.lpi0006.Lpi0006SuccessEmailBodyBuilder;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

class LPI0006EmailBodyBuilderTest {

    private static final String LPI_0006_XML_SUCCESS = getStringFromXmlFile("lpi0006/lpi0006_EXAMPLE_SUCCESS.xml");
    private static final String LPI_0006_XML_ERROR = getStringFromXmlFile("lpi0006/lpi0006_EXAMPLE_ERROR.xml");
    private static final String SUCCESS_EMAIL_BODY = getStringFromXmlFile("lpi0006/lpi0006_SUCCESS_EMAIL.txt");
    private static final String ERROR_EMAIL_BODY = getStringFromXmlFile("lpi0006/lpi0006_ERROR_EMAIL.txt");

    @Test
    void shouldBuildCorrectlySuccessBody() {
        String successBody = new Lpi0006SuccessEmailBodyBuilder(LPI_0006_XML_SUCCESS, BigDecimal.valueOf(2750)).build();

        assertThat(successBody, is(SUCCESS_EMAIL_BODY));
    }

    @Test
    void shouldBuildCorrectlyErrorBody() {
        String successBody = new Lpi0006ErrorEmailBodyBuilder(LPI_0006_XML_ERROR, BigDecimal.valueOf(3507)).build();

        assertThat(successBody, is(ERROR_EMAIL_BODY));
    }

}
