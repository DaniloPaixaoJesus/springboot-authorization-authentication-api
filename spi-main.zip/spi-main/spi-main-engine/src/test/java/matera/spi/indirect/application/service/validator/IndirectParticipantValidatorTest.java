package matera.spi.indirect.application.service.validator;

import com.matera.commons.utils.exception.BusinessException;

import matera.spi.dto.IndirectParticipantContactDTO;
import matera.spi.dto.IndirectParticipantFinancialFieldsUIDTO;
import matera.spi.dto.IndirectParticipantStatusDTO;
import matera.spi.dto.IndirectParticipantUIDTO;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@ExtendWith(MockitoExtension.class)
class IndirectParticipantValidatorTest {

    private static final String ACCOUNT_NUMBER = "123";
    private static final String BRANCH = "1";
    private static final LocalDate CONTRACT_END_DATE = LocalDate.now().plusDays(1);
    private static final LocalDate CONTRACT_INIT_DATE = LocalDate.now();
    private static final LocalDate CONTRACT_INIT_DATE_BIGGER_THAN_END_DATE = LocalDate.now().plusDays(2);
    private static final String CORPORATE_NAME = "CORP_NAME";
    private static final String ISPB = "00192555";
    private static final String NAME = "NAME";
    private static final String TAX_ID = "79610132000195";

    @Spy
    private IndirectParticipantValidator indirectParticipantValidator;

    @Test
    void shouldReturnFalseWhenContractInitialDateIsBiggerThanContractEndDate() {
        IndirectParticipantUIDTO indirectParticipantDTO = createIndirectParticipantMock();
        indirectParticipantDTO.setContractInitDate(CONTRACT_INIT_DATE_BIGGER_THAN_END_DATE);
        Assertions.assertThrows(BusinessException.class,
            () -> indirectParticipantValidator.validateIndirectParticipant(indirectParticipantDTO));
    }

    @Test
    void shouldReturnTrueWhenContractInitialDateIsSmallerThanContractEndDate() {
        IndirectParticipantUIDTO indirectParticipantDTO = createIndirectParticipantMock();
        Assertions
            .assertDoesNotThrow(() -> indirectParticipantValidator.validateIndirectParticipant(indirectParticipantDTO));
    }

    @Test
    void shouldReturnFalseWhenHavingNullContacts() {
        IndirectParticipantUIDTO indirectParticipantDTO = createIndirectParticipantMock();
        indirectParticipantDTO.setContacts(null);
        Assertions.assertThrows(BusinessException.class,
            () -> indirectParticipantValidator.validateIndirectParticipant(indirectParticipantDTO));
    }

    @Test
    void shouldReturnFalseWhenHavingZeroContacts() {
        IndirectParticipantUIDTO indirectParticipantDTO = createIndirectParticipantMock();
        indirectParticipantDTO.getContacts().clear();
        Assertions.assertThrows(BusinessException.class,
            () -> indirectParticipantValidator.validateIndirectParticipant(indirectParticipantDTO));
    }

    @Test
    void shouldReturnFalseWhenHavingMoreThanFourContacts() {
        IndirectParticipantUIDTO indirectParticipantDTO = createIndirectParticipantMock();

        indirectParticipantDTO.getContacts().add(createIndirectParticipantContactMock());
        indirectParticipantDTO.getContacts().add(createIndirectParticipantContactMock());
        indirectParticipantDTO.getContacts().add(createIndirectParticipantContactMock());
        indirectParticipantDTO.getContacts().add(createIndirectParticipantContactMock());

        Assertions.assertThrows(BusinessException.class,
            () -> indirectParticipantValidator.validateIndirectParticipant(indirectParticipantDTO));
    }

    @Test
    void shouldReturnTrueWhenHavingBetweenOneAndFourContacts() {
        IndirectParticipantUIDTO indirectParticipantDTO = createIndirectParticipantMock();
        Assertions
            .assertDoesNotThrow(() -> indirectParticipantValidator.validateIndirectParticipant(indirectParticipantDTO));
    }

    @Test
    void shouldReturnFalseWhenBalanceValidationThresholdIsActiveAndBalanceLowerThresholdIsNull() {
        IndirectParticipantUIDTO indirectParticipantDTO = createIndirectParticipantMock();
        indirectParticipantDTO.getFinancial().setBalanceValidationThreshold(true);
        indirectParticipantDTO.getFinancial().setBalanceLowerThreshold(null);
        Assertions.assertThrows(BusinessException.class,
            () -> indirectParticipantValidator.validateIndirectParticipant(indirectParticipantDTO));
    }

    @Test
    void shouldReturnFalseWhenBalanceValidationThresholdIsActiveAndBalanceLowerThresholdIsNotBiggerThanZero() {
        IndirectParticipantUIDTO indirectParticipantDTO = createIndirectParticipantMock();
        indirectParticipantDTO.getFinancial().setBalanceValidationThreshold(true);
        indirectParticipantDTO.getFinancial().setBalanceLowerThreshold(BigDecimal.ZERO);
        Assertions.assertThrows(BusinessException.class,
            () -> indirectParticipantValidator.validateIndirectParticipant(indirectParticipantDTO));
    }

    @Test
    void shouldReturnTrueWhenBalanceValidationThresholdIsActiveAndBalanceLowerThresholdIsBiggerThanZero() {
        IndirectParticipantUIDTO indirectParticipantDTO = createIndirectParticipantMock();
        indirectParticipantDTO.getFinancial().setBalanceValidationThreshold(true);
        indirectParticipantDTO.getFinancial().setBalanceLowerThreshold(new BigDecimal("1"));
        Assertions
            .assertDoesNotThrow(() -> indirectParticipantValidator.validateIndirectParticipant(indirectParticipantDTO));
    }

    @Test
    void shouldReturnTrueWhenBalanceValidationThresholdIsNotActive() {
        IndirectParticipantUIDTO indirectParticipantDTO = createIndirectParticipantMock();
        indirectParticipantDTO.getFinancial().setBalanceValidationThreshold(false);
        indirectParticipantDTO.getFinancial().setBalanceLowerThreshold(BigDecimal.ZERO);
        Assertions
            .assertDoesNotThrow(() -> indirectParticipantValidator.validateIndirectParticipant(indirectParticipantDTO));
    }

    private IndirectParticipantUIDTO createIndirectParticipantMock() {
        IndirectParticipantUIDTO indirectParticipant = new IndirectParticipantUIDTO();
        indirectParticipant.setStatus(IndirectParticipantStatusDTO.WAITING_TO_SEND_REGISTRATION_TO_CLEARING);
        indirectParticipant.setAccountNumber(ACCOUNT_NUMBER);
        indirectParticipant.setBranch(BRANCH);
        indirectParticipant.setContacts(createIndirectParticipantContactListMock());
        indirectParticipant.setContractEndDate(CONTRACT_END_DATE);
        indirectParticipant.setContractInitDate(CONTRACT_INIT_DATE);
        indirectParticipant.setCorporateName(CORPORATE_NAME);
        indirectParticipant.setIspb(ISPB);
        indirectParticipant.setFinancial(createIndirectParticipantFinancialFieldsMock());
        indirectParticipant.setName(NAME);
        indirectParticipant.setTaxId(TAX_ID);
        return indirectParticipant;
    }

    private IndirectParticipantFinancialFieldsUIDTO createIndirectParticipantFinancialFieldsMock() {
        IndirectParticipantFinancialFieldsUIDTO indirectParticipantFinancialFields =
            new IndirectParticipantFinancialFieldsUIDTO();
        indirectParticipantFinancialFields.setBalanceLowerThreshold(new BigDecimal("100"));
        indirectParticipantFinancialFields.setBalanceValidationThreshold(true);
        return indirectParticipantFinancialFields;
    }

    private List<IndirectParticipantContactDTO> createIndirectParticipantContactListMock() {
        List<IndirectParticipantContactDTO> indirectParticipantContactList = new ArrayList<>();
        indirectParticipantContactList.add(createIndirectParticipantContactMock());
        return indirectParticipantContactList;
    }

    private IndirectParticipantContactDTO createIndirectParticipantContactMock() {
        IndirectParticipantContactDTO indirectParticipantContact = new IndirectParticipantContactDTO();
        indirectParticipantContact.setDepartment("DEPARTMENT");
        indirectParticipantContact.setEmail("EMAIL@EMAIL.COM");
        indirectParticipantContact.setName("CONTACT_NAME");
        indirectParticipantContact.setPhone("555555555");

        return indirectParticipantContact;
    }

}
