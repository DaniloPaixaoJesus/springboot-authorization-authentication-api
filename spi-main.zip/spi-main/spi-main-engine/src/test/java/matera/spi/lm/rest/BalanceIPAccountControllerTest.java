package matera.spi.lm.rest;

import com.matera.spi.messaging.api.MessagesApi;
import com.matera.spi.messaging.api.SPIMessagingApis;
import com.matera.spi.messaging.model.MessageSentResponseDTO;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import matera.spi.commons.IntegrationTest;
import matera.spi.dto.BalanceLocalIPAccountDTO;
import matera.spi.dto.BalanceLocalIPAccountResponseWrapperDTO;
import matera.spi.lm.application.service.balanceIPAccountService.BalanceIPAccountService;
import matera.spi.lm.domain.model.event.IpAccountBalanceQueryDetailsEntity;
import matera.spi.lm.domain.model.event.IpAccountBalanceQueryEventEntity;
import matera.spi.lm.persistence.SpbEventRepository;
import matera.spi.main.config.MainEngineConfiguration;
import matera.spi.main.domain.model.BalanceAccountPiEntity;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventStatusEntity;
import matera.spi.main.domain.service.MessageSender;
import matera.spi.main.domain.service.util.BalanceIPAccountUtil;
import matera.spi.main.persistence.BalanceAccountPiRepository;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.EventStatusTransitionRepository;
import matera.spi.main.persistence.EventTypeRepository;
import matera.spi.main.utils.FileUtils;
import matera.spi.utils.LocalDateTimeUtils;
import net.javacrumbs.jsonunit.JsonAssert;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.util.UriComponentsBuilder;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.math.BigDecimal.TEN;
import static java.math.BigDecimal.ZERO;
import static matera.spi.utils.LocalDateTimeUtils.formatToQueryParamPattern;
import static matera.spi.utils.LocalDateTimeUtils.getMinLocalDateTime;
import static matera.spi.utils.LocalDateTimeUtils.getTodayUTC;
import static net.javacrumbs.jsonunit.JsonMatchers.jsonNodePresent;
import static org.hamcrest.Matchers.comparesEqualTo;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@IntegrationTest
public class BalanceIPAccountControllerTest  {

    protected static final String HTTP_LOCALHOST = "http://localhost:";
    protected static final String IPACCOUNT_QUERY_BALANCES = "/ui/v1/ip-account/balance/queries";
    protected static final String PATH_TO_IP_ACCOUNT_BALANCE = "/ui/v1/psp/balance/ip-account/mirror";

    private final String RESPONSE_GET_IP_ACCOUNT_QUERY_BALANCE =
        FileUtils.getStringFromJsonFile("balances/response_ip_account_query_balance.json");

    @LocalServerPort
    protected int port;

    @Autowired
    private BalanceIPAccountService balanceIPAccountService;
    @Autowired
    private MainEngineConfiguration meConfig;
    @Spy
    private MainEngineConfiguration mockedMeConfig;

    @Autowired
    protected TestRestTemplate testRestTemplate;

    @Autowired
    private BalanceAccountPiRepository balanceRepository;

    @Autowired
    private BalanceIPAccountUtil balanceUtil;

    @Autowired
    private EventRepository eventRepository;

    @Autowired
    private EventTypeRepository eventTypeRepository;

    @Autowired
    private EventStatusTransitionRepository eventStatusTransitionRepository;

    @Autowired
    private SpbEventRepository spbEventRepository;

    @Autowired
    private MessageSender messageSender;
    @Autowired
    private SPIMessagingApis spiMessagingApisBean;
    @Mock
    private SPIMessagingApis mockedSpiMessagingApis;
    @Mock
    private MessagesApi messagesApi;

    private List<BalanceAccountPiEntity> balances;

    private Map<String, String> urlVariables = new HashMap<>();

    @BeforeEach
    public void init() {
        RestAssured.port = port;
        urlVariables.put("startTimestampUtc", formatToQueryParamPattern(getMinLocalDateTime(getTodayUTC())));
        urlVariables.put("endTimestampUtc", formatToQueryParamPattern(getMinLocalDateTime(getTodayUTC().plusDays(1))));

        buildQueryEventEntity();

        balances = balanceRepository.findAll();
        deleteAllInserts();
        messageSender.setSpiMessagingApis(mockedSpiMessagingApis);
    }

    @AfterEach
    public void restoreDatabaseState() {

        deleteAllInserts();

        balanceRepository.saveAll(balances);
        urlVariables.clear();
        messageSender.setSpiMessagingApis(spiMessagingApisBean);
    }

    private void deleteAllInserts() {
        balanceRepository.deleteAll();
    }

    @Test
    void shouldReturnOKWhenValidRequestWasSent() {
        BalanceLocalIPAccountResponseWrapperDTO response = RestAssured
            .when()
                .get(PATH_TO_IP_ACCOUNT_BALANCE)
            .then()
                .statusCode(200)
            .and().extract()
                .body()
                .as(BalanceLocalIPAccountResponseWrapperDTO.class);

        assertThat(response.getData().getValue(), is(ZERO));
    }

    @Test
    void shouldReturnNotNullBodyWhenValidRequestWasSent() {
        final ResponseEntity<BalanceLocalIPAccountResponseWrapperDTO> responseEntity = getResponseEntityBalanceIPAccount();
        assertNotNull(responseEntity.getBody());
    }

    @Test
    void shouldReturnValidDataBodyValuesWhenValidRequestWasSent() {
        final ResponseEntity<BalanceLocalIPAccountResponseWrapperDTO> responseEntity = getResponseEntityBalanceIPAccount();
        final BalanceLocalIPAccountDTO balance = responseEntity.getBody().getData();

        assertNotNull(balance);
        assertThat(balance.getValue(), comparesEqualTo(ZERO));
    }

    @Test
    void shouldReturnLastInsertedValueWhenValidRequestWasSent() {
        balanceUtil.insertOneCredit(TEN);
        final ResponseEntity<BalanceLocalIPAccountResponseWrapperDTO> responseEntity = getResponseEntityBalanceIPAccount();
        final BalanceLocalIPAccountDTO balance = responseEntity.getBody().getData();

        assertNotNull(balance);
        assertThat(balance.getValue(), comparesEqualTo(TEN));
    }

    @Test
    void shouldReturnPageableBalanceResponseUI() {
        final String responseBalance =
            RestAssured.given()
                .log().all()
                .when()
                .header("pageSize", 5)
                .header("pageNumber", 0)
                .get(getEventUri(IPACCOUNT_QUERY_BALANCES))
                .getBody()
                .asString();

        Assertions.assertNotNull(responseBalance);
        JsonAssert.assertJsonEquals(RESPONSE_GET_IP_ACCOUNT_QUERY_BALANCE, responseBalance);
    }

    private String getEventUri(String baseUri) {
        final UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder.fromUriString(baseUri);
        urlVariables.entrySet()
            .forEach(entry -> uriComponentsBuilder.queryParam(entry.getKey(), entry.getValue()));
        return uriComponentsBuilder.toUriString();
    }

    private ResponseEntity<BalanceLocalIPAccountResponseWrapperDTO> getResponseEntityBalanceIPAccount() {
        return testRestTemplate.getForEntity( HTTP_LOCALHOST + port + PATH_TO_IP_ACCOUNT_BALANCE, BalanceLocalIPAccountResponseWrapperDTO.class);
    }

    private IpAccountBalanceQueryDetailsEntity buildIpAccountQuerybalance() {
        final IpAccountBalanceQueryDetailsEntity queryDetailsEntity = new IpAccountBalanceQueryDetailsEntity();
        queryDetailsEntity.setBalanceAvailable(TEN);
        queryDetailsEntity.setBalanceAvailableTimeUTC(LocalDateTimeUtils.getUtcLocalDateTime());
        queryDetailsEntity.setBalanceBlocked(TEN);
        queryDetailsEntity.setBalanceBlockedTimeUTC(LocalDateTimeUtils.getUtcLocalDateTime());
        queryDetailsEntity.setDateSent(getTodayUTC());
        queryDetailsEntity.setIsCurrentBalance(Boolean.TRUE);
        return queryDetailsEntity;
    }

    private IpAccountBalanceQueryEventEntity buildQueryEventEntity() {
        final IpAccountBalanceQueryEventEntity queryEventEntity = new IpAccountBalanceQueryEventEntity();
        queryEventEntity.setCorrelationId("E00539039202002170828063aec68f6e");
        queryEventEntity.setClearingTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
        queryEventEntity.setInitiationTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
        queryEventEntity.setResponsible("SOME RESPONSIBLE");
        queryEventEntity.setInitiatorIspb(12345);
        queryEventEntity.setValue(BigDecimal.ONE);
        EventStatusEntity eventStatus = new EventStatusEntity();
        eventStatus.setCode(1);
        eventStatus.setDescription("");
        eventStatus.setFinalStatus(true);
        queryEventEntity.setStatus(eventStatus);

        final IpAccountBalanceQueryDetailsEntity queryDetailsEntity = buildIpAccountQuerybalance();
        queryEventEntity.setIpAccountBalanceQueryDetailsEntity(queryDetailsEntity);
        queryDetailsEntity.setIpAccountBalanceQueryEventEntity(queryEventEntity);
        return eventRepository.save(queryEventEntity);
    }

    @Test
    void assertEventWasCreatedWithTypeQuerySent() throws JSONException {
        eventRepository.deleteAll();
        when(messagesApi.sendsMessageV1(any())).thenReturn(getMessageSentResponseDTO());
        when(mockedSpiMessagingApis.messagesApi()).thenReturn(messagesApi);
        JSONObject referenceDate = new JSONObject().put("referenceDate", LocalDate.now());

        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(referenceDate.toString())
            .when()
            .post(IPACCOUNT_QUERY_BALANCES)
            .thenReturn()
            .body()
            .asString();

        List<EventEntity> allEvents = eventRepository.findAll();

        assertThat(allEvents, hasSize(1));
        assertThat(allEvents.get(0).getStatus().getCode(), is(14));
        assertThat(allEvents.get(0).getStatus().getDescription(), is("Query sent"));
    }

    @Test
    void assertReturningEventUuidOnQueryBalance() throws JSONException {
        when(messagesApi.sendsMessageV1(any())).thenReturn(getMessageSentResponseDTO());
        when(mockedSpiMessagingApis.messagesApi()).thenReturn(messagesApi);
        JSONObject referenceDate = new JSONObject().put("referenceDate", LocalDate.now());

        String responseBody = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(referenceDate.toString())
            .when()
            .post(IPACCOUNT_QUERY_BALANCES)
            .thenReturn()
            .body()
            .asString();

        assertThat(responseBody, jsonNodePresent("data.eventUuid"));
    }

    private MessageSentResponseDTO getMessageSentResponseDTO() {
        MessageSentResponseDTO responseDto = new MessageSentResponseDTO();
        responseDto.setPiResourceID("PIResourceID");
        return responseDto;
    }

}
