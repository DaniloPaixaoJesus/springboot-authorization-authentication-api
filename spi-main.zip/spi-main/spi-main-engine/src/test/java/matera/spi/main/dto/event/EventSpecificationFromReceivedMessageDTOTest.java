package matera.spi.main.dto.event;

import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.domain.model.message.MessageTypeEntity;
import matera.spi.utils.DocumentUtils;
import matera.spi.main.dto.MessageReceiverEventDTO;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;

import static matera.spi.main.utils.EntityCreationUtils.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class EventSpecificationFromReceivedMessageDTOTest {

	private static final Document DOCUMENT = DocumentUtils.stringToXmlDocument("<Envelope/>");
	private static final MessageEntity MESSAGE_ENTITY = buildPacs008MessageEntity();
	public static final MessageReceiverEventDTO MESSAGE_RECEIVER_DTO = MessageReceiverEventDTO.builder()
			.messageEntity(MESSAGE_ENTITY)
			.messageDocument(DOCUMENT)
			.build();

	@Test
	void shouldGetTheCorrectValuesFromTheMessageEntityWhenGivenAMessageReceiverDTO() {
		EventSpecificationFromReceivedMessageDTO eventSpecDTO =
				new EventSpecificationFromReceivedMessageDTO(MESSAGE_RECEIVER_DTO, DOCUMENT);
		assertThat(eventSpecDTO.getCorrelationIdXPath()).isEqualTo(PACS_008_CORRELATION_ID_ELEMENT);
		assertThat(eventSpecDTO.getNewEventTypeCode()).isEqualTo(RECEIPT_EVENT_TYPE_CODE);
	}


	@Test
	void shouldThrowInvalidMessageReceiverDTOExceptionWhenMessageTypeEntityDoesNotHaveNewEventTypeCode() {
		MessageEntity messageEntity = new MessageEntity();
		messageEntity.setMessageTypeEntity(new MessageTypeEntity());
		MessageReceiverEventDTO messageReceiverEventDTO = MessageReceiverEventDTO.builder()
											.messageEntity(messageEntity)
											.messageDocument(DOCUMENT)
											.build();
		EventSpecificationFromReceivedMessageDTO eventSpecDTO =
				new EventSpecificationFromReceivedMessageDTO(messageReceiverEventDTO, DOCUMENT);
		assertThatThrownBy(eventSpecDTO::getNewEventTypeCode)
				.isInstanceOf(IllegalStateException.class)
				.hasMessage("%s does not have a NewEventTypeCode.", messageEntity.getMessageTypeEntity());
	}

}