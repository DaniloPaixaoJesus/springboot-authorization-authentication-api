package matera.spi.main.domain.service.event.financial.action;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.service.config.FinancialActionConfiguration;
import matera.spi.main.domain.service.event.Event;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.Mockito.verify;

@IntegrationTest
class FinancialActionDispatcherTest {

	@Autowired
	private FinancialActionDispatcher dispatcher;

    @Autowired
    @Qualifier(FinancialActionConfiguration.FINANCIAL_ACTION_HANDLER)
    private Map<String, FinancialActionHandler> financialActionHandlers;

    @Autowired
    CreditFinancialAction creditFinancialAction;
    @Autowired
    DoNothingFinancialAction doNothingFinancialAction;
    @Autowired
    RevertFinancialAction revertFinancialAction;

    @Mock
    FinancialActionHandler mockedFinancialAction;
    @Mock
	private Event event;

	@Test
    void shouldCallsCreditFinancialActionWhenCREDITAction(){
        financialActionHandlers.put("CREDIT", mockedFinancialAction);

        dispatcher.handleFinancialAction("CREDIT", event);
        verify(mockedFinancialAction).handle(same(event));

        financialActionHandlers.put("CREDIT", creditFinancialAction);
    }

	@Test
	void shouldCallsRevertFinancialActionWhenREVERTAction(){
        financialActionHandlers.put("REVERT", mockedFinancialAction);

        dispatcher.handleFinancialAction("REVERT", event);
        verify(mockedFinancialAction).handle(same(event));

        financialActionHandlers.put("REVERT", revertFinancialAction);
	}

	@Test
	void shouldCallsDoNothingFinancialActionWhenNOTHINGAction(){
        financialActionHandlers.put("NOTHING", mockedFinancialAction);

        dispatcher.handleFinancialAction("NOTHING", event);
        verify(mockedFinancialAction).handle(same(event));

        financialActionHandlers.put("NOTHING", doNothingFinancialAction);
	}


	@Test
	void shouldThrowIllegalStateExceptionWhenAnActionNotMappedItsGiven(){
		assertThatThrownBy(() -> dispatcher.handleFinancialAction("INVALID", event))
				.isInstanceOf(IllegalStateException.class)
				.hasMessageStartingWith("Not found a FinancialActionHandler for action INVALID at financialActionHandlers");
	}

}
