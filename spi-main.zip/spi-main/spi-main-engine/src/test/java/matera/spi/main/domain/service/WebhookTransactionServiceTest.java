package matera.spi.main.domain.service;

import com.matera.spi.webhook.transaction.model.InstantPaymentSettlementCallbackRequestDTO;

import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventStatus;
import matera.spi.main.domain.model.event.EventStatusEntity;
import matera.spi.main.domain.model.event.transaction.ReceiptEventEntity;
import matera.spi.main.domain.model.transaction.ReceiptEntity;
import matera.spi.main.dto.WebhookTransactionDTO;
import matera.spi.utils.LocalDateTimeUtils;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;

@ExtendWith(MockitoExtension.class)
class WebhookTransactionServiceTest {

    public static final String CORRELATION_ID = "E00539039202002170828063aec68f6e";
    public static final String RECEIVER_RECON_IDENTIFIER = "3d0ca315-aff9–4fc2-be61–3b76b9a2d899";

    @InjectMocks
    WebhookTransactionService webhookTransactionService;

    @Mock
    WebhookWorkQueue webhookWorkQueue;

    @Test
    void webhookTransactionSendPaymentConfirmed (){
        ReceiptEventEntity receiptEventEntity = buildReceiptEventEntityPayment(EventStatus.PENDING_CREDIT_ACCOUNT_HOLDER);
        webhookTransactionService.send(receiptEventEntity);
        WebhookTransactionDTO webhookTransactionDTO = new WebhookTransactionDTO();
        webhookTransactionDTO.setTransactionId(receiptEventEntity.getReceiptEntity().getReceiverReconIdentifier());
        InstantPaymentSettlementCallbackRequestDTO instantPaymentSettlementCallbackRequestDTO = new InstantPaymentSettlementCallbackRequestDTO();
        instantPaymentSettlementCallbackRequestDTO.setAdditionalInfo(receiptEventEntity.getRejectionReasonDescription());
        instantPaymentSettlementCallbackRequestDTO.setPaymentConfirmed(isPaymentConfirmed(receiptEventEntity));
        webhookTransactionDTO.setPaymentSettlementCallbackRequest(instantPaymentSettlementCallbackRequestDTO);
        Mockito.verify(webhookWorkQueue).send(webhookTransactionDTO);
    }

    @Test
    void webhookTransactionSendPaymentNotConfirmed (){
        ReceiptEventEntity receiptEventEntity = buildReceiptEventEntityPayment(EventStatus.ERROR);
        webhookTransactionService.send(receiptEventEntity);
        WebhookTransactionDTO webhookTransactionDTO = new WebhookTransactionDTO();
        webhookTransactionDTO.setTransactionId(receiptEventEntity.getReceiptEntity().getReceiverReconIdentifier());
        InstantPaymentSettlementCallbackRequestDTO instantPaymentSettlementCallbackRequestDTO = new InstantPaymentSettlementCallbackRequestDTO();
        instantPaymentSettlementCallbackRequestDTO.setAdditionalInfo(receiptEventEntity.getRejectionReasonDescription());
        instantPaymentSettlementCallbackRequestDTO.setPaymentConfirmed(isPaymentConfirmed(receiptEventEntity));
        webhookTransactionDTO.setPaymentSettlementCallbackRequest(instantPaymentSettlementCallbackRequestDTO);
        Mockito.verify(webhookWorkQueue).send(webhookTransactionDTO);
    }

    @Test
    void webhookTransactionSendPaymentSuccess (){
        ReceiptEventEntity receiptEventEntity = buildReceiptEventEntityPayment(EventStatus.SUCCESS);
        webhookTransactionService.send(receiptEventEntity);
        WebhookTransactionDTO webhookTransactionDTO = new WebhookTransactionDTO();
        webhookTransactionDTO.setTransactionId(receiptEventEntity.getReceiptEntity().getReceiverReconIdentifier());
        InstantPaymentSettlementCallbackRequestDTO instantPaymentSettlementCallbackRequestDTO = new InstantPaymentSettlementCallbackRequestDTO();
        instantPaymentSettlementCallbackRequestDTO.setAdditionalInfo(receiptEventEntity.getRejectionReasonDescription());
        instantPaymentSettlementCallbackRequestDTO.setPaymentConfirmed(isPaymentConfirmed(receiptEventEntity));
        webhookTransactionDTO.setPaymentSettlementCallbackRequest(instantPaymentSettlementCallbackRequestDTO);
        Mockito.verify(webhookWorkQueue).send(webhookTransactionDTO);
    }

    private Boolean isPaymentConfirmed(EventEntity eventEntity) {
        return EventStatus.PENDING_CREDIT_ACCOUNT_HOLDER.getCode().equals(eventEntity.getStatus().getCode())||
               EventStatus.SUCCESS.getCode().equals(eventEntity.getStatus().getCode());
    }

    public static ReceiptEventEntity buildReceiptEventEntityPayment(EventStatus eventStatus) {
        ReceiptEventEntity receiptEventEntity = new ReceiptEventEntity();
        receiptEventEntity.setCorrelationId(CORRELATION_ID);
        receiptEventEntity.setReceiptEntity(new ReceiptEntity());
        receiptEventEntity.getReceiptEntity().setReceiverReconIdentifier(RECEIVER_RECON_IDENTIFIER);
        receiptEventEntity.setClearingTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
        receiptEventEntity.setInitiationTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
        receiptEventEntity.setResponsible("SOME RESPONSIBLE");
        receiptEventEntity.setInitiatorIspb(12345);
        receiptEventEntity.setValue(BigDecimal.ONE);

        EventStatusEntity eventStatusEntity = new EventStatusEntity();

        eventStatusEntity.setCode(eventStatus.getCode());

        receiptEventEntity.setStatus(eventStatusEntity);

        return receiptEventEntity;
    }
}
