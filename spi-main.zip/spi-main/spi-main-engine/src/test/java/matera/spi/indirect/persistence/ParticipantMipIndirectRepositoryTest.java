package matera.spi.indirect.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.indirect.domain.model.ParticipantMipIndirectContactsEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectStatusEntity;
import matera.spi.indirect.domain.model.enums.IndirectParticipantStatusEnum;
import matera.spi.indirect.util.ParticipantMipIndirectDataSetUtil;
import matera.spi.main.domain.model.ParticipantMipEntity;
import matera.spi.main.persistence.ParticipantMipRepository;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.opentest4j.AssertionFailedError;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import java.time.LocalDate;
import java.util.List;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

@IntegrationTest
class ParticipantMipIndirectRepositoryTest {

    private static final String INDIRECT_PARTICIPANT_NOT_FOUND_WITH_ISPB =
        "Indirect participant not found with ISPB %d ";
    private static final String THE_STATUS_ENTITY_MUST_EXIST_IN_DATABASE =
        "The Status entity %s must exist in database.";

    private static final Pageable PAGE = PageRequest.of(0, 2);
    private static final int ISPB = 12345678;

    @Autowired
    private ParticipantMipRepository participantMipRepository;

    @Autowired
    private ParticipantMipIndirectStatusRepository participantMipIndirectStatusRepository;

    @Autowired
    private ParticipantMipIndirectRepository participantMipIndirectRepository;

    @Autowired
    private ParticipantMipIndirectContactsRepository participantMipIndirectContactsRepository;

    @Autowired
    private PlatformTransactionManager transactionManager;

    private TransactionTemplate transactionTemplate;

    @BeforeEach
    void setUpTransactionTemplate() {
        transactionTemplate = new TransactionTemplate(transactionManager);
    }

    @BeforeEach
    @AfterEach
    void cleanData() {
        ParticipantMipIndirectDataSetUtil
            .cleanIndirectParticipantTablesData(null, participantMipIndirectContactsRepository,
                participantMipIndirectRepository, participantMipRepository);
    }

    @Test
    void shouldAddAndFindNewParticipantMipIndirect() {
        final ParticipantMipIndirectEntity participantMipIndirectEntity = participantMipIndirectRepository.saveAndFlush(
            ParticipantMipIndirectDataSetUtil.createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                ParticipantMipIndirectDataSetUtil.createParticipantMip()));

        final ParticipantMipIndirectEntity participantMipIndirectFound =
            participantMipIndirectRepository.findByParticipantMipIspb(ParticipantMipIndirectDataSetUtil.ISPB)
                .orElseThrow(participantNotFoundWithIspb(ParticipantMipIndirectDataSetUtil.ISPB));

        assertThat(participantMipIndirectFound.getParticipantMip())
            .isEqualTo(participantMipIndirectEntity.getParticipantMip());
    }

    @Test
    void shouldFindByIspbJoinFetchParticipantMipAndContacts() {
        final ParticipantMipIndirectEntity participantMipIndirectEntity = participantMipIndirectRepository.saveAndFlush(
            ParticipantMipIndirectDataSetUtil.createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                ParticipantMipIndirectDataSetUtil.createParticipantMip()));

        final ParticipantMipEntity participantMipEntity = participantMipIndirectEntity.getParticipantMip();

        final ParticipantMipIndirectContactsEntity participantMipIndirectContactsEntity =
            participantMipIndirectContactsRepository.saveAndFlush(ParticipantMipIndirectDataSetUtil
                .createParticipantMipIndirectContactsEntity(participantMipIndirectEntity));

        final ParticipantMipIndirectEntity entity = participantMipIndirectRepository
            .findByIspbJoinFetchParticipantAndContacts(ParticipantMipIndirectDataSetUtil.ISPB).get();

        assertThat(entity).isEqualTo(participantMipIndirectEntity);
        assertEquals(participantMipEntity, entity.getParticipantMip());
        assertThat(entity.getContacts()).hasOnlyOneElementSatisfying(participantMipIndirectContactsEntity::equals);
    }

    @Test
    void shouldFindByIspbAndStatusJoinFetchParticipantMipAndContacts() {
        final ParticipantMipIndirectEntity participantMipIndirectEntity = participantMipIndirectRepository.saveAndFlush(
            ParticipantMipIndirectDataSetUtil.createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                ParticipantMipIndirectDataSetUtil.createParticipantMip()));

        final ParticipantMipEntity participantMipEntity = participantMipIndirectEntity.getParticipantMip();

        final ParticipantMipIndirectContactsEntity participantMipIndirectContactsEntity =
            participantMipIndirectContactsRepository.saveAndFlush(ParticipantMipIndirectDataSetUtil
                .createParticipantMipIndirectContactsEntity(participantMipIndirectEntity));

        final List<ParticipantMipIndirectEntity> participantMipIndirectListFound = participantMipIndirectRepository
            .findAllByIspbAndStatusIsActiveIsTrueJoinFetchParticipantAndContacts(
                ParticipantMipIndirectDataSetUtil.ISPB);

        assertThat(participantMipIndirectListFound).hasOnlyOneElementSatisfying(participantMipIndirectEntity::equals);

        final ParticipantMipIndirectEntity entity = participantMipIndirectListFound.iterator().next();

        assertEquals(participantMipEntity, entity.getParticipantMip());
        assertThat(entity.getContacts()).hasOnlyOneElementSatisfying(participantMipIndirectContactsEntity::equals);
    }

    @Test
    void shouldNotFindByIspbAndStatusJoinFetchParticipantAndContactsWhenHasNoValuesWithGivenStatus() {
        transactionTemplate.executeWithoutResult(transactionStatus -> {
            final ParticipantMipIndirectEntity participantMipIndirectEntity = participantMipIndirectRepository
                .saveAndFlush(ParticipantMipIndirectDataSetUtil
                    .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                        ParticipantMipIndirectDataSetUtil.createParticipantMip()));

            participantMipIndirectContactsRepository.saveAndFlush(ParticipantMipIndirectDataSetUtil
                .createParticipantMipIndirectContactsEntity(participantMipIndirectEntity));

            final ParticipantMipIndirectStatusEntity statusEntity =
                participantMipIndirectStatusRepository.findById(IndirectParticipantStatusEnum.ACTIVE.getId())
                    .orElseThrow(() -> new AssertionFailedError(String.format(THE_STATUS_ENTITY_MUST_EXIST_IN_DATABASE,
                        IndirectParticipantStatusEnum.ACTIVE.name())));

            ParticipantMipIndirectDataSetUtil.setStatusFieldValue(statusEntity, "isActive", false);

            participantMipIndirectStatusRepository.save(statusEntity);

            final List<ParticipantMipIndirectEntity> participantMipIndirectListFound = participantMipIndirectRepository
                .findAllByIspbAndStatusIsActiveIsTrueJoinFetchParticipantAndContacts(
                    ParticipantMipIndirectDataSetUtil.ISPB);

            assertThat(participantMipIndirectListFound).hasSize(0);

            transactionStatus.setRollbackOnly();
        });
    }

    @Test
    void shouldFindAllAndStatusIsActiveIsTrueJoinFetchParticipantAndContacts() {
        transactionTemplate.executeWithoutResult(transactionStatus -> {
            participantMipIndirectRepository.saveAndFlush(ParticipantMipIndirectDataSetUtil
                .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                    ParticipantMipIndirectDataSetUtil.createParticipantMip()));

            final ParticipantMipIndirectStatusEntity statusEntity =
                participantMipIndirectStatusRepository.findById(IndirectParticipantStatusEnum.ACTIVE.getId())
                    .orElseThrow(() -> new AssertionFailedError(String.format(THE_STATUS_ENTITY_MUST_EXIST_IN_DATABASE,
                        IndirectParticipantStatusEnum.ACTIVE.name())));

            ParticipantMipIndirectDataSetUtil.setStatusFieldValue(statusEntity, "isActive", false);

            participantMipIndirectStatusRepository.save(statusEntity);

            final ParticipantMipIndirectEntity participantMipIndirectEntity2 = ParticipantMipIndirectDataSetUtil
                .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                    ParticipantMipIndirectDataSetUtil.createParticipantMip(ParticipantMipIndirectDataSetUtil.ISPB + 1));

            final ParticipantMipIndirectStatusEntity statusEntity2 = participantMipIndirectStatusRepository
                .findById(IndirectParticipantStatusEnum.WAITING_DEREGISTRATION_EVALUATION.getId()).orElseThrow(
                    () -> new AssertionFailedError(String.format(THE_STATUS_ENTITY_MUST_EXIST_IN_DATABASE,
                        IndirectParticipantStatusEnum.WAITING_DEREGISTRATION_EVALUATION.name())));

            participantMipIndirectEntity2.setStatus(statusEntity2);

            participantMipIndirectRepository.saveAndFlush(participantMipIndirectEntity2);

            assertThat(participantMipIndirectRepository.findAll()).hasSize(2);
            assertThat(participantMipIndirectRepository.findAllAndStatusIsActiveIsTrueJoinFetchParticipantAndContacts())
                .hasSize(1);

            transactionStatus.setRollbackOnly();
        });
    }

    @Test
    void shouldFindAllFetchContacts() {
        final ParticipantMipIndirectEntity participantMipIndirectEntity = participantMipIndirectRepository.saveAndFlush(
            ParticipantMipIndirectDataSetUtil.createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                ParticipantMipIndirectDataSetUtil.createParticipantMip()));

        final ParticipantMipEntity participantMipEntity = participantMipIndirectEntity.getParticipantMip();

        final ParticipantMipIndirectContactsEntity participantMipIndirectContactsEntity =
            participantMipIndirectContactsRepository.saveAndFlush(ParticipantMipIndirectDataSetUtil
                .createParticipantMipIndirectContactsEntity(participantMipIndirectEntity));

        final List<ParticipantMipIndirectEntity> participantMipIndirectListFound =
            participantMipIndirectRepository.findAllJoinFetchContacts();

        assertThat(participantMipIndirectListFound).hasOnlyOneElementSatisfying(participantMipIndirectEntity::equals);

        final ParticipantMipIndirectEntity entity = participantMipIndirectListFound.iterator().next();

        assertEquals(participantMipEntity, entity.getParticipantMip());
        assertThat(entity.getContacts()).hasOnlyOneElementSatisfying(participantMipIndirectContactsEntity::equals);
    }

    @Test
    void shouldReturnPageOfIndirectParticipantsWhenInfoAllFilters() {
        participantMipIndirectRepository.saveAndFlush(ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                ParticipantMipIndirectDataSetUtil.createParticipantMip()));

        Page<ParticipantMipIndirectEntity> actual = participantMipIndirectRepository.findAll(
            ParticipantMipIndirectSpecification.findByOptionalFields(ParticipantMipIndirectDataSetUtil.ISPB,
                ParticipantMipIndirectDataSetUtil.INDIRECT_PARTICIPANT_NAME, ParticipantMipIndirectDataSetUtil.TAX_ID,
                1, LocalDate.of(2020, 2, 23), LocalDate.of(2020, 9, 25), true), PAGE);

        assertEquals(1, actual.getContent().size());
    }

    @Test
    void shouldReturnNoInformationWhenThereWasNoInformationBetweenTheDatesInformed() {
        participantMipIndirectRepository.saveAndFlush(ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                ParticipantMipIndirectDataSetUtil.createParticipantMip()));

        Page<ParticipantMipIndirectEntity> actual = participantMipIndirectRepository.findAll(
            ParticipantMipIndirectSpecification
                .findByOptionalFields(null, null, null, null, LocalDate.of(2020, 2, 23), LocalDate.of(2020, 3, 25),
                    true),
            PAGE);

        assertEquals(0, actual.getContent().size());
    }

    @Test
    void shouldFindParticipantByStatus() {
        final List<ParticipantMipIndirectEntity> participantMipIndirectEntities = participantMipIndirectRepository.saveAll(
            ParticipantMipIndirectDataSetUtil
                .createParticipantMipIndirectEntitiesWithDifferentStatus(participantMipIndirectStatusRepository));

        ParticipantMipIndirectStatusEntity status =
            participantMipIndirectStatusRepository.findById(IndirectParticipantStatusEnum.DEREGISTERED.getId()).orElseThrow();

        final List<ParticipantMipIndirectEntity> participantMipIndirectFound = participantMipIndirectRepository.findAllByStatus(status);

        assertThat(participantMipIndirectFound.size()).isEqualTo(1);
        participantMipIndirectFound.forEach(participant ->
            assertThat(participant.getStatus().getId()).isEqualTo(IndirectParticipantStatusEnum.DEREGISTERED.getId()));
    }

    @Test
    void shouldReturnCanceledParticipant() {
        participantMipIndirectRepository.saveAndFlush(ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                IndirectParticipantStatusEnum.CANCELED.getId(),
                ParticipantMipIndirectDataSetUtil.createParticipantMip()));

        Page<ParticipantMipIndirectEntity> actual = participantMipIndirectRepository.findAll(
            ParticipantMipIndirectSpecification
                .findByOptionalFields(null, null, null, null, null, null,
                    true),
            PAGE);

        assertEquals(1, actual.getContent().size());
        ParticipantMipIndirectEntity indirectParticipant = actual.stream().collect(Collectors.toList()).get(0);
        assertEquals(IndirectParticipantStatusEnum.CANCELED.getId(), indirectParticipant.getStatus().getId());
    }

    @Test
    void shouldReturnNoCanceledParticipant() {
        participantMipIndirectRepository.saveAndFlush(ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                IndirectParticipantStatusEnum.CANCELED.getId(),
                ParticipantMipIndirectDataSetUtil.createParticipantMip()));

        Page<ParticipantMipIndirectEntity> actual = participantMipIndirectRepository.findAll(
            ParticipantMipIndirectSpecification
                .findByOptionalFields(null, null, null, null, null, null,
                    false),
            PAGE);

        assertEquals(0, actual.getContent().size());
    }

    @Test
    void shouldReturnNoCanceledParticipantBecauseThereIsStatusSpecified() {
        participantMipIndirectRepository.saveAndFlush(ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                IndirectParticipantStatusEnum.CANCELED.getId(),
                ParticipantMipIndirectDataSetUtil.createParticipantMip()));

        participantMipIndirectRepository.saveAndFlush(ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                IndirectParticipantStatusEnum.ACTIVE.getId(),
                ParticipantMipIndirectDataSetUtil.createParticipantMip(ISPB)));

        Page<ParticipantMipIndirectEntity> actual = participantMipIndirectRepository.findAll(
            ParticipantMipIndirectSpecification
                .findByOptionalFields(null, null, null, IndirectParticipantStatusEnum.ACTIVE.getId(), null, null,
                    true),
            PAGE);

        assertEquals(1, actual.getContent().size());
        ParticipantMipIndirectEntity indirectParticipant = actual.stream().collect(Collectors.toList()).get(0);
        assertEquals(IndirectParticipantStatusEnum.ACTIVE.getId(), indirectParticipant.getStatus().getId());
    }

    private Supplier<AssertionFailedError> participantNotFoundWithIspb(Integer ispb) {
        return () -> new AssertionFailedError(String.format(INDIRECT_PARTICIPANT_NOT_FOUND_WITH_ISPB, ispb));
    }

}
