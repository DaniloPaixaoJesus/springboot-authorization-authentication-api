package matera.spi.lm.domain.service.event;

import com.matera.spi.messaging.api.MessagesApi;
import com.matera.spi.messaging.api.SPIMessagingApis;
import com.matera.spi.messaging.model.MessageSentResponseDTO;

import matera.spi.commons.IntegrationTest;
import matera.spi.lm.domain.model.event.IpAccountStatementQueryDetailsEntity;
import matera.spi.lm.domain.model.event.IpAccountStatementQueryEventEntity;
import matera.spi.lm.dto.IpAccountStatementQueryEventSpecificationDTO;
import matera.spi.main.domain.service.MessageSender;
import matera.spi.main.domain.service.event.Event;
import matera.spi.main.domain.service.event.EventFactory;
import matera.spi.utils.LocalDateTimeUtils;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;

import static org.mockito.Mockito.when;

@IntegrationTest
public class IpAccountStatementQueryEventTest  {

    private static final String PI_RESOURCE_ID = "PI-RESOURCE-ID-TEST-STATEMENT";

    private static final LocalDateTime STARTTIMESTAMP = LocalDateTimeUtils.getUtcLocalDateTime();
    private static final LocalDateTime ENDTIMESTAMP = LocalDateTimeUtils.getUtcLocalDateTime().plusHours(5);
    private static final String RESPONSIBLE = "ResponsibleTest";
    private static final Integer INITIATOR_ISPB = 12345678;

    private static Event event;

    @Autowired
    private EventFactory eventFactory;

    @Autowired
    private MessageSender messageSender;
    @Autowired
    private SPIMessagingApis spiMessagingApisBean;
    @Mock
    private SPIMessagingApis mockedSpiMessagingApis;
    @Mock
    private MessagesApi messagesApi;

    @BeforeEach
    void setup() {
        when(mockedSpiMessagingApis.messagesApi()).thenReturn(messagesApi);
        messageSender.setSpiMessagingApis(mockedSpiMessagingApis);
    }

    @AfterEach
    void tearDown() {
        messageSender.setSpiMessagingApis(spiMessagingApisBean);
    }


    @Test
    void shouldCreateNewIpAccountStatementQueryEventFromEventSpecificationDTO() {
        Mockito.doReturn(buildMessageSentResponseDTO()).when(messagesApi).sendsMessageV1(Mockito.any());
        final IpAccountStatementQueryEventSpecificationDTO ipAccountStatementQueryEventSpecificationDTO = buildEventSpecificationDTO();
        event = eventFactory.createNewEvent(ipAccountStatementQueryEventSpecificationDTO);
        Assertions.assertNotNull(event);
        Assertions.assertTrue(event instanceof IpAccountStatementQueryEvent);

        final IpAccountStatementQueryEvent actual = (IpAccountStatementQueryEvent) event;
        final IpAccountStatementQueryEventEntity actualEventEntity = actual.getEventEntity();
        Assertions.assertNotNull(actualEventEntity);
        Assertions.assertEquals(RESPONSIBLE, actualEventEntity.getResponsible());
        Assertions.assertEquals(INITIATOR_ISPB, actualEventEntity.getInitiatorIspb());

        final IpAccountStatementQueryDetailsEntity actualDetailsEntity = actualEventEntity.getIpAccountStatementQueryDetailsEntity();
        Assertions.assertNotNull(actualDetailsEntity);
        Assertions.assertEquals(STARTTIMESTAMP, actualDetailsEntity.getStartTimestampUtc());
        Assertions.assertEquals(ENDTIMESTAMP, actualDetailsEntity.getEndTimestampUtc());
    }

    private IpAccountStatementQueryEventSpecificationDTO buildEventSpecificationDTO() {
        final IpAccountStatementQueryEventSpecificationDTO eventSpecificationDTO = new IpAccountStatementQueryEventSpecificationDTO();
        eventSpecificationDTO.setStartTimestamp(STARTTIMESTAMP);
        eventSpecificationDTO.setEndTimestamp(ENDTIMESTAMP);
        eventSpecificationDTO.setInitiatorIspb(INITIATOR_ISPB);
        eventSpecificationDTO.setResponsible(RESPONSIBLE);
        return eventSpecificationDTO;
    }

    private MessageSentResponseDTO buildMessageSentResponseDTO() {
        final MessageSentResponseDTO messageSentResponseDTO = new MessageSentResponseDTO();
        messageSentResponseDTO.setPiResourceID(PI_RESOURCE_ID);
        return messageSentResponseDTO;
    }
}
