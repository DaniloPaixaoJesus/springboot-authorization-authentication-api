package matera.spi.lm.rest;

import matera.spi.commons.IntegrationTest;
import matera.spi.lm.domain.model.spb.SpbEventEntity;
import matera.spi.lm.domain.model.spb.SpbMessageEntity;
import matera.spi.lm.domain.model.spb.deposit.IpAccountDepositEventEntity;
import matera.spi.lm.persistence.SpbEventRepository;
import matera.spi.lm.persistence.SpbMessageRepository;
import matera.spi.main.domain.model.event.EventStatusEntity;
import matera.spi.main.domain.model.event.EventStatusTransitionEntity;
import matera.spi.main.domain.model.event.EventTypeEntity;
import matera.spi.main.domain.model.transaction.TransactionResultEntity;
import matera.spi.main.persistence.EventStatusRepository;
import matera.spi.main.persistence.EventStatusTransitionRepository;
import matera.spi.main.persistence.EventTypeRepository;
import matera.spi.main.utils.FileUtils;
import matera.spi.utils.LocalDateTimeUtils;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import static net.javacrumbs.jsonunit.JsonMatchers.jsonEquals;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@IntegrationTest
public class EventDetailsApiControllerTest  {

    private final String EVENTS_BASE_URI = "ui/v1/events";

    private final String RESPONSE_EVENT_DETAILS = FileUtils.getStringFromJsonFile("events/response_find_event_details.json");

    @LocalServerPort
    private int port;

    @Autowired
    private SpbEventRepository spbEventRepository;

    @Autowired
    private EventTypeRepository eventTypeRepository;

    @Autowired
    private EventStatusRepository eventStatusRepository;

    @Autowired
    private EventStatusTransitionRepository eventStatusTransitionRepository;

    @Autowired
    private SpbMessageRepository spbMessageRepository;

    @BeforeEach
    void beforeEach() {
        RestAssured.port = port;
        spbEventRepository.deleteAll();
    }

    @Test
    void shouldReturnAnEventDetails() {
        IpAccountDepositEventEntity spbDepositEventEntity = createSpbDepositEventEntity();
        String url = EVENTS_BASE_URI + "/" + spbDepositEventEntity.getId();

        Response response = RestAssured.given().when().get(url);
        String responseBody = response.getBody().asString();

        assertNotNull(responseBody);
        assertThat(responseBody, jsonEquals(RESPONSE_EVENT_DETAILS).whenIgnoringPaths("data.id"));
    }

    private IpAccountDepositEventEntity createSpbDepositEventEntity() {

        EventTypeEntity eventTypeEntity = eventTypeRepository.findById(10).orElseThrow(() -> new RuntimeException("EventType not found"));

        IpAccountDepositEventEntity eventEntity = new IpAccountDepositEventEntity();

        eventEntity.setClearingTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
        eventEntity.setInitiationTimestampUTC(LocalDateTime.of(2020, 1, 1, 1, 2, 3, 123));
        eventEntity.setResponsible("SOME RESPONSIBLE");
        eventEntity.setSpbEventId(222L);
        eventEntity.setInitiatorIspb(12345);
        eventEntity.setValue(BigDecimal.ONE);
        eventEntity.setOriginSystem("Origin System");
        eventEntity.setOrigSystemTransactionId("OriginTransactionId");
        eventEntity.setEventTypeEntity(eventTypeEntity);
        eventEntity.setStatus(eventTypeEntity.getInitialStatus());
        eventEntity.setIpAccountTransactionResult(getTransactionResultEntity());

        spbEventRepository.saveAndFlush(eventEntity);

        createEventStatusTransitionEntity(eventEntity);
        createMessage(eventEntity);

        return eventEntity;
    }

    private void createMessage(SpbEventEntity spbEvent) {
        SpbMessageEntity spbMessageEntity = new SpbMessageEntity();
        spbMessageEntity.setMessageCode("MCODE");
        spbMessageEntity.setMessageContents("CONTENT");
        spbMessageEntity.setEvent(spbEvent);
        spbMessageEntity.setTimestamp(LocalDateTime.of(2020, 1, 2, 2, 3, 5));

        spbMessageRepository.saveAndFlush(spbMessageEntity);
    }

    private TransactionResultEntity getTransactionResultEntity() {
        TransactionResultEntity ipAccountTransactionResult = new TransactionResultEntity();
        ipAccountTransactionResult.setTransactionIdInDdaSystem(BigDecimal.valueOf(123));
        return ipAccountTransactionResult;
    }

    private EventStatusTransitionEntity createEventStatusTransitionEntity(SpbEventEntity spbEvent) {
        EventStatusEntity eventStatusEntity = eventStatusRepository.findById(1)
                                                                   .orElseThrow(() -> new RuntimeException("EventStatus not found!"));

        EventStatusTransitionEntity spbStatusEntity = new EventStatusTransitionEntity();
        spbStatusEntity.setEventStatusCode(eventStatusEntity);
        spbStatusEntity.setResponsible("REPONSIBLE STATUS");
        spbStatusEntity.setTimestamp(LocalDateTime.of(2020, 2, 3, 1, 2, 3));
        spbStatusEntity.setEvent(spbEvent);
        eventStatusTransitionRepository.saveAndFlush(spbStatusEntity);
        return spbStatusEntity;
    }

}
