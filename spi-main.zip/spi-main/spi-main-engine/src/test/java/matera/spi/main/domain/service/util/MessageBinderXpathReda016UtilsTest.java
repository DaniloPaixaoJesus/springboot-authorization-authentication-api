package matera.spi.main.domain.service.util;

import matera.spi.main.domain.model.enums.TransactionStatus;
import matera.spi.utils.DocumentUtils;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;

import static org.assertj.core.api.Assertions.assertThat;

class MessageBinderXpathReda016UtilsTest {

    private static final String REDA_016 = "reda.016/reda.016_sucesso_msg.xml";
	private static final String REDA_016_ERRO = "reda.016/reda.016_erro_msg.xml";

    public static final String MSG_ID = "M0003816612345678901234567890123";
    public static final String CRED_DT_TM = "2020-01-01T08:30:12.000Z";
    public static final String ORGNL_BIZ_INSTR_MSG_ID = "M9999901012345678901234567890123";
    public static final String STS_COMP = "COMP";
    public static final String STS_REJCT = "REJT";
    public static final String PR_TRY_ID = "55555555";
    public static final String PR_TRY_ISSR = "BCB";
    public static final String RSPNSBL_PTY_ID = "99999010";
    public static final String RSPNSBL_PTY_ISSR = "BCB";
    public static final String STS_RSN_PR_TRY = "IND2";

    @Test
    @DisplayName("Test message id at which the message was created for archive reda.016/reda.016_sucesso_msg.xml")
    void shouldMsgId() {
        Document document = DocumentUtils.stringToXmlDocument(getXml(REDA_016));
        String msgId = MessageBinderXpathReda016Utils.getMsgId(document);
        assertThat(msgId).isEqualTo(MSG_ID);
    }

    @Test
    @DisplayName("Test Date and time at which the message was created for archive reda.016/reda.016_sucesso_msg.xml")
    void shouldCreDtTm() {
        Document document = DocumentUtils.stringToXmlDocument(getXml(REDA_016));
        String creDtTm = MessageBinderXpathReda016Utils.getCreDtTm(document);
        assertThat(creDtTm).isEqualTo(CRED_DT_TM);
    }

    @Test
    @DisplayName("Test original message id at which the message was created for archive reda.016/reda.016_sucesso_msg.xml")
    void shouldOrgnlBizInstrMsgId() {
        Document document = DocumentUtils.stringToXmlDocument(getXml(REDA_016));
        String orgnlBizInstrMsgId = MessageBinderXpathReda016Utils.getOrgnlBizInstrMsgId(document);
        assertThat(orgnlBizInstrMsgId).isEqualTo(ORGNL_BIZ_INSTR_MSG_ID);
    }

    @Test
    @DisplayName("Test Status of the party maintenance instruction message at which the message was created for archive reda.016/reda.016_sucesso_msg.xml")
    void shouldSts() {
        Document document = DocumentUtils.stringToXmlDocument(getXml(REDA_016));
        String sts = MessageBinderXpathReda016Utils.getSts(document);
        assertThat(sts).isEqualTo(STS_COMP);
    }

    @Test
    @DisplayName("Test Proprietary information, often a code, issued by the data source scheme issuer message was created for archive reda.016/reda.016_sucesso_msg.xml")
    void shouldPrTryId() {
        Document document = DocumentUtils.stringToXmlDocument(getXml(REDA_016));
        String prTryId = MessageBinderXpathReda016Utils.getPrTryId(document);
        assertThat(prTryId).isEqualTo(PR_TRY_ID);
    }

    @Test
    @DisplayName("Test Entity that assigns the identification message was created for archive reda.016/reda.016_sucesso_msg.xml")
    void shouldPrTryIssr() {
        Document document = DocumentUtils.stringToXmlDocument(getXml(REDA_016));
        String prTryIssr = MessageBinderXpathReda016Utils.getPrTryIssr(document);
        assertThat(prTryIssr).isEqualTo(PR_TRY_ISSR);
    }

    @Test
    @DisplayName("Proprietary information, often a code, issued by the data source scheme issuer message was created for archive reda.016/reda.016_sucesso_msg.xml")
    void shouldRspnsblPtyId() {
        Document document = DocumentUtils.stringToXmlDocument(getXml(REDA_016));
        String rspnsblPtyId = MessageBinderXpathReda016Utils.getRspnsblPtyId(document);
        assertThat(rspnsblPtyId).isEqualTo(RSPNSBL_PTY_ID);
    }

    @Test
    @DisplayName("Test Proprietary information, often a code, issued by the data source scheme issuer. message was created for archive reda.016/reda.016_sucesso_msg.xml")
    void shouldRspnsblPtyIssr() {
        Document document = DocumentUtils.stringToXmlDocument(getXml(REDA_016));
        String rspnsblPtyIssr = MessageBinderXpathReda016Utils.getRspnsblPtyIssr(document);
        assertThat(rspnsblPtyIssr).isEqualTo(RSPNSBL_PTY_ISSR);
    }

    @Test
    @DisplayName("Test message id at which the message was created for archive reda.016/reda.016_erro_msg.xml")
    void shouldMsgIdErro() {
        Document document = DocumentUtils.stringToXmlDocument(getXml(REDA_016_ERRO));
        String msgId = MessageBinderXpathReda016Utils.getMsgId(document);
        assertThat(msgId).isEqualTo(MSG_ID);
    }

    @Test
    @DisplayName("Test Date and time at which the message was created for archive reda.016/reda.016_erro_msg.xml")
    void shouldCreDtTmErro() {
        Document document = DocumentUtils.stringToXmlDocument(getXml(REDA_016_ERRO));
        String creDtTm = MessageBinderXpathReda016Utils.getCreDtTm(document);
        assertThat(creDtTm).isEqualTo(CRED_DT_TM);
    }

    @Test
    @DisplayName("Test Unique identification of the original instruction the message was created for archive reda.016/reda.016_erro_msg.xml")
    void shouldOrgnlBizInstrMsgIdErro() {
        Document document = DocumentUtils.stringToXmlDocument(getXml(REDA_016_ERRO));
        String orgnlBizInstrMsgId = MessageBinderXpathReda016Utils.getOrgnlBizInstrMsgId(document);
        assertThat(orgnlBizInstrMsgId).isEqualTo(ORGNL_BIZ_INSTR_MSG_ID);
    }

    @Test
    @DisplayName("Test Status of the party maintenance instruction the message was created for archive reda.016/reda.016_erro_msg.xml")
    void shouldStsReject() {
        Document document = DocumentUtils.stringToXmlDocument(getXml(REDA_016_ERRO));
        String sts = MessageBinderXpathReda016Utils.getSts(document);
        assertThat(sts).isEqualTo(STS_REJCT);
    }

    @Test
    @DisplayName("Test Reason for the status, in a proprietary form the message was created for archive reda.016/reda.016_erro_msg.xml")
    void shouldStsRsnPrTryErro() {
        Document document = DocumentUtils.stringToXmlDocument(getXml(REDA_016_ERRO));
        String stsRsnPrTry = MessageBinderXpathReda016Utils.getStsRsnPrTry(document);
        assertThat(stsRsnPrTry).isEqualTo(STS_RSN_PR_TRY);
    }

	private String getXml(String arquivo) {
		return getStringFromXmlFile(arquivo);
	}
}
