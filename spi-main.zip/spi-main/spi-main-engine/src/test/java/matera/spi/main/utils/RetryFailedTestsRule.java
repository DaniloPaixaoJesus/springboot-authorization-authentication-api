package matera.spi.main.utils;

import org.junit.rules.TestRule;
import org.junit.runner.Description;
import org.junit.runners.model.Statement;

public final class RetryFailedTestsRule implements TestRule {
    private final int numberOfRetries;

    public RetryFailedTestsRule(int numberOfRetries) {

        if (numberOfRetries < 1) {
            throw new IllegalArgumentException("numberOfRetries < 1: " + numberOfRetries);
        }

        this.numberOfRetries = numberOfRetries;
    }

    @Override
    public Statement apply(final Statement base, Description description) {

        return new Statement() {
            @Override
            public void evaluate() throws Throwable {
                for (int i = 1; i <= numberOfRetries; i++) {
                    try {
                        base.evaluate();
                        break;
                    } catch (Throwable e) {
                        if (i == numberOfRetries) {
                            throw e;
                        }
                    }
                }
            }
        };
    }
}
