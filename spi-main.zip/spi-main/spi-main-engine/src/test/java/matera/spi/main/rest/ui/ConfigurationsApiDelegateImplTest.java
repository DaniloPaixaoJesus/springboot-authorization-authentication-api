package matera.spi.main.rest.ui;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.CustomerTransactionTypeDTO;
import matera.spi.dto.PspConfigUpdateUIDTO;
import matera.spi.main.domain.model.ConfigEntity;
import matera.spi.main.persistence.ConfigRepository;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;

import java.math.BigDecimal;

import static org.junit.Assert.assertThat;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.core.Is.is;

@IntegrationTest
public class ConfigurationsApiDelegateImplTest  {

    @Autowired
    private ConfigRepository configRepository;
    private static final String BASE_URI_CONFIG = "/ui/v1/configs";
    private static final String BASE_URI_CUSTOMER = "/ui/v1/configuration/account/customer";

    @LocalServerPort
    private int port;

    private ConfigEntity lastConfig;

    @BeforeEach
    void beforeEach() {
        RestAssured.port = port;
        lastConfig = configRepository.findAll().get(0);
        configRepository.deleteAll();
    }

    @AfterEach
    void afterEach() {
        configRepository.deleteAll();
        configRepository.saveAndFlush(lastConfig);
    }

    @Test
    void shouldReturnConfiguration() {
        ConfigEntity configMock  = configurationMock();
        configRepository.save(configMock);

        RestAssured.given()
                .when().get(BASE_URI_CONFIG)
                .then()
                .log().all()
                .assertThat()
                .statusCode(HttpStatus.SC_OK)
                .body("data.ispb", Matchers.equalTo(configMock.getIspb()))
                .body("data.pmtSlaTime", Matchers.equalTo(configMock.getPmtSlaTime()))
                .body("data.pmtConfirmRetryAmount", Matchers.equalTo(configMock.getPmtConfirmRetryAmount()))
                .body("data.pmtConfirmRetryInterval", Matchers.equalTo(configMock.getPmtConfirmRetryInterval()))
                .body("data.receiveConfirmRetryAmount", Matchers.equalTo(configMock.getReceiveConfirmRetryAmount()))
                .body("data.receiveConfirmRetryInterval", Matchers.equalTo(configMock.getReceiveConfirmRetryInterval()));
    }

    @Test
    void shouldReturnExceptionIfConfigurationNotFound() {
        RestAssured.given()
                .when().get(BASE_URI_CONFIG)
                .then()
                .log().all()
                .assertThat()
                .statusCode(HttpStatus.SC_INTERNAL_SERVER_ERROR);
    }

    @Test
    void shouldUpdateConfiguration() {
        PspConfigUpdateUIDTO pspConfigUpdateUIDTO = buildExpectedPspConfigUpdateUIDTO();

        ConfigEntity configMock  = configurationMock();
        configRepository.save(configMock);

        assertThat(configMock.getDefaultBranch(), not(buildExpectedPspConfigUpdateUIDTO().getDefaultBranch()));

        RestAssured.given()
            .contentType(ContentType.JSON)
            .body(pspConfigUpdateUIDTO)
            .when().post(BASE_URI_CONFIG)
            .then()
            .log().all()
            .assertThat()
            .statusCode(HttpStatus.SC_OK);

        final ConfigEntity configEntitySaved = configRepository.findAll().get(0);
        assertThat(configEntitySaved.getDefaultBranch(), is(buildExpectedPspConfigUpdateUIDTO().getDefaultBranch()));
    }

    @Test
    void shouldReturnCustomerConfiguration() {
        ConfigEntity configMock  = configurationMock();
        configRepository.save(configMock);

        RestAssured.given()
            .when().get(BASE_URI_CUSTOMER)
            .then()
            .log().all()
            .assertThat()
            .statusCode(HttpStatus.SC_OK)
            .body("data.credit", Matchers.equalTo(configMock.getCustomerCredTransactionType()))
            .body("data.debit", Matchers.equalTo(configMock.getCustomerDebTransactionType()))
            .body("data.drawbackSent", Matchers.equalTo(configMock.getCustDrawbSentTransType()))
            .body("data.drawbackReceived", Matchers.equalTo(configMock.getCustDrawbReceivedTransType()))
            .body("data.creditByDynamicQRCode", Matchers.equalTo(configMock.getQrcodeCredTransactionType()))
            .body("data.intraPspCredit", Matchers.equalTo(configMock.getCustomerIntraPspCredTransactionType()))
            .body("data.intraPspDebit", Matchers.equalTo(configMock.getCustomerIntraPspDebTransactionType()))
            .body("data.intraPspDrawbackSent", Matchers.equalTo(configMock.getCustIntraPspDrawbSentTransType()))
            .body("data.intraPspDrawbackReceived", Matchers.equalTo(configMock.getCustIntraPspDrawbReceivedTransType()));
    }

    @Test
    void shouldUpdateCustomerConfiguration() {
        CustomerTransactionTypeDTO customerTransactionTypeDTO = buildExpectedCustomerTransactionTypeDTO();

        ConfigEntity configMock  = configurationMock();
        configRepository.save(configMock);

        assertThat(configMock.getCustomerCredTransactionType(), not(customerTransactionTypeDTO.getCredit()));
        assertThat(configMock.getCustomerDebTransactionType(), not(customerTransactionTypeDTO.getDebit()));
        assertThat(configMock.getCustDrawbSentTransType(), not(customerTransactionTypeDTO.getDrawbackSent()));
        assertThat(configMock.getCustDrawbReceivedTransType(), not(customerTransactionTypeDTO.getDrawbackReceived()));
        assertThat(configMock.getQrcodeCredTransactionType(), not(customerTransactionTypeDTO.getCreditByDynamicQRCode()));
        assertThat(configMock.getCustomerIntraPspCredTransactionType(), not(customerTransactionTypeDTO.getIntraPspCredit()));
        assertThat(configMock.getCustomerIntraPspDebTransactionType(), not(customerTransactionTypeDTO.getIntraPspDebit()));
        assertThat(configMock.getCustIntraPspDrawbSentTransType(), not(customerTransactionTypeDTO.getIntraPspDrawbackSent()));
        assertThat(configMock.getCustIntraPspDrawbReceivedTransType(), not(customerTransactionTypeDTO.getIntraPspDrawbackReceived()));

        RestAssured.given()
            .contentType(ContentType.JSON)
            .body(customerTransactionTypeDTO)
            .when().post(BASE_URI_CUSTOMER)
            .then()
            .log().all()
            .assertThat()
            .statusCode(HttpStatus.SC_OK);

        final ConfigEntity configEntitySaved = configRepository.findAll().get(0);
        assertThat(configEntitySaved.getCustomerCredTransactionType(), is(customerTransactionTypeDTO.getCredit()));
        assertThat(configEntitySaved.getCustomerDebTransactionType(), is(customerTransactionTypeDTO.getDebit()));
        assertThat(configEntitySaved.getCustDrawbSentTransType(), is(customerTransactionTypeDTO.getDrawbackSent()));
        assertThat(configEntitySaved.getCustDrawbReceivedTransType(), is(customerTransactionTypeDTO.getDrawbackReceived()));
        assertThat(configEntitySaved.getQrcodeCredTransactionType(), is(customerTransactionTypeDTO.getCreditByDynamicQRCode()));
        assertThat(configEntitySaved.getCustomerIntraPspCredTransactionType(), is(customerTransactionTypeDTO.getIntraPspCredit()));
        assertThat(configEntitySaved.getCustomerIntraPspDebTransactionType(), is(customerTransactionTypeDTO.getIntraPspDebit()));
        assertThat(configEntitySaved.getCustIntraPspDrawbSentTransType(), is(customerTransactionTypeDTO.getIntraPspDrawbackSent()));
        assertThat(configEntitySaved.getCustIntraPspDrawbReceivedTransType(), is(customerTransactionTypeDTO.getIntraPspDrawbackReceived()));
    }

    private ConfigEntity configurationMock() {
        ConfigEntity configEntity = new ConfigEntity();
        configEntity.setBalanceValidationThreshold(BigDecimal.valueOf(100));
        configEntity.setCustomerCredTransactionType(1);
        configEntity.setCustomerDebTransactionType(1);
        configEntity.setId(1);
        configEntity.setIspb(100);
        configEntity.setPmtConfirmRetryAmount(500);
        configEntity.setPmtConfirmRetryInterval(150);
        configEntity.setPmtSlaTime(99);
        configEntity.setReceiveConfirmRetryAmount(150);
        configEntity.setReceiveConfirmRetryInterval(150);
        configEntity.setCustDrawbSentTransType(4);
        configEntity.setCustDrawbReceivedTransType(5);
        configEntity.setQrcodeCredTransactionType(6);
        configEntity.setCustomerIntraPspCredTransactionType(11);
        configEntity.setCustomerIntraPspDebTransactionType(12);
        configEntity.setCustIntraPspDrawbSentTransType(13);
        configEntity.setCustIntraPspDrawbReceivedTransType(14);

        return configEntity;
    }

    private PspConfigUpdateUIDTO buildExpectedPspConfigUpdateUIDTO() {
        final PspConfigUpdateUIDTO dto = new PspConfigUpdateUIDTO();
        dto.setIspb(0);
        dto.setDefaultBranch("123");
        return dto;
    }

    private CustomerTransactionTypeDTO buildExpectedCustomerTransactionTypeDTO() {
        final CustomerTransactionTypeDTO dto = new CustomerTransactionTypeDTO();
        dto.setCredit(50);
        dto.setDebit(51);
        dto.setDrawbackSent(52);
        dto.setDrawbackReceived(53);
        dto.setCreditByDynamicQRCode(54);
        dto.setIntraPspCredit(55);
        dto.setIntraPspDebit(56);
        dto.setIntraPspDrawbackSent(57);
        dto.setIntraPspDrawbackReceived(58);

        return dto;
    }

}
