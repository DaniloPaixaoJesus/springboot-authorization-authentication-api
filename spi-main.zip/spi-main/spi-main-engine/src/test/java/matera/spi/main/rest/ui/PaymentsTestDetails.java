package matera.spi.main.rest.ui;

import lombok.Builder;
import lombok.ToString;

@Builder
@ToString
public class PaymentsTestDetails {

    private String jsonPath;
    private Object valueFromJson;
    private String xpath;
    private Object valueFromXml;
}
