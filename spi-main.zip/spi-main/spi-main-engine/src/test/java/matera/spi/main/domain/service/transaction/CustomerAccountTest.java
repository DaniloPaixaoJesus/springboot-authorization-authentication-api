package matera.spi.main.domain.service.transaction;

import com.matera.spi.thirdparties.customers.transactions.model.LancamentoResponseV2DTO;
import com.matera.spi.thirdparties.customers.transactions.model.LancamentoResponseV2DTO.TipoPessoaEnum;

import matera.spi.main.domain.model.ConfigEntity;
import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.domain.model.account.PayerAccountEntity;
import matera.spi.main.domain.model.account.ReceiverAccountEntity;
import matera.spi.main.domain.model.event.transaction.PaymentEventEntity;
import matera.spi.main.domain.model.event.transaction.ReceiptEventEntity;
import matera.spi.main.domain.model.event.transaction.ReturnReceivedEventEntity;
import matera.spi.main.domain.model.event.transaction.ReturnSentEventEntity;
import matera.spi.main.domain.model.transaction.PaymentEntity;
import matera.spi.main.domain.model.transaction.ReceiptEntity;
import matera.spi.main.domain.model.transaction.ReturnReceivedEntity;
import matera.spi.main.domain.model.transaction.ReturnSentEntity;
import matera.spi.main.domain.service.ConfigurationService;
import matera.spi.main.dto.AccountTransactionDetailDTO;
import matera.spi.main.dto.AccountTransactionRequestDTO;
import matera.spi.main.dto.AccountTransactionResponseDTO;
import matera.spi.main.dto.AccountTransactionValidationRequestDTO;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.util.Random;
import java.util.UUID;

import static com.matera.spi.thirdparties.customers.transactions.model.LancamentoResponseV2DTO.ClassificacaoCategoriaContaSPIEnum.CACC;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CustomerAccountTest {

    private static final Random RANDOM = new Random();
    private static final BigDecimal TRANSACTION_ID = BigDecimal.valueOf(99656464813L);
    private static AccountTransactionResponseDTO ACCOUNT_TRANSACTION_RESPONSE_DTO;
    private static final BigDecimal CUSTOMER_ACCOUNT_NUMBER = BigDecimal.valueOf(1231457L);
    private static final int CUSTOMER_BRANCH = 1;
    private static final int CREDIT_TRANSACTION_TYPE = 2;
    private static final int DEBIT_TRANSACTION_TYPE = 3;
    private static final int DRBK_RCVD_TRANSACTION_TYPE = 4;
    private static final int DRBK_SENT_TRANSACTION_TYPE = 5;
    private static final int QRCODE_CRED_TRANSACTION_TYPE = 6;
    private static final int INTRA_PSP_CREDIT_TRANSACTION_TYPE = 102;
    private static final int INTRA_PSP_DEBIT_TRANSACTION_TYPE = 103;
    private static final int INTRA_PSP_DRBK_RCVD_TRANSACTION_TYPE = 104;
    private static final int INTRA_PSP_DRBK_SENT_TRANSACTION_TYPE = 105;
    private static final BigDecimal TRANSACTION_VALUE = BigDecimal.valueOf(100);
    private static final UUID EVENT_ID = UUID.randomUUID();
    private static final String END_TO_END_ID = UUID.randomUUID().toString();
    private static final int RECEIVER_PARTICIPANT_ISPB = 123456789;
    private static final int PAYER_PARTICIPANT_ISPB = 987456321;
    private static final String HISTORIC_COMPLEMENT = "HISTORIC COMPLEMENT";
    private static final String RECEIVER_ACCOUNT_TAXI_ID = "1234.00";
    private static final String INFORMATION_ACCOUNT_HOLDER_TRANSACTION = "INFORMATION ACCOUNT HOLDER TRANSACTION";
    private static final String RECEIVER_TAX_ID = "03259787941";

    private static final String UNSTRUCTURED_INFO = "Unstructured field content";
    private static final String ADDITIONALINFORMATION_INFO = "additionalInformation field content";

    @InjectMocks
    private CustomerAccount customerAccount;

    @Mock
    private AccountTransaction accountTransaction;

    @Mock
    private ConfigurationService configurationService;

    private ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    public void setupTest(){
        ReflectionTestUtils.setField(customerAccount, "objectMapper", objectMapper);
    }

    @BeforeAll
    public static void setup() {

        LancamentoResponseV2DTO lancamentoResponseV2DTO = new LancamentoResponseV2DTO();

        lancamentoResponseV2DTO.setClassificacaoCategoriaContaSPI(CACC);
        lancamentoResponseV2DTO.setCpfCnpjTitular(BigDecimal.valueOf(92082843521L));

        ACCOUNT_TRANSACTION_RESPONSE_DTO = AccountTransactionResponseDTO.builder()
            .transactionId(TRANSACTION_ID)
            .lancamentoResponseV2DTO(lancamentoResponseV2DTO)
            .build();
    }

    @ParameterizedTest(name = "isDynamicQrCode {0}")
    @ValueSource(booleans = {true, false})
    void shouldMakeCustomerCredit(boolean isDynamicQrCode) throws JsonProcessingException {
        //Given:
        when(configurationService.findConfig()).thenReturn(buildConfig());
        when(accountTransaction.makeTransaction(any()))
            .thenReturn(ACCOUNT_TRANSACTION_RESPONSE_DTO);
        //When:
        ReceiptEventEntity receiptEventEntity = buildReceiptEventEntity();
        receiptEventEntity.getTransactionEntity().setIsDynamicQrCode(isDynamicQrCode);
        customerAccount.makeCredit(receiptEventEntity);
        //Then:
        int creditTransactionType = isDynamicQrCode ? QRCODE_CRED_TRANSACTION_TYPE : CREDIT_TRANSACTION_TYPE;
        verify(accountTransaction)
            .makeTransaction(
                eq(getExpectedAccountTransactionRequestDTO(creditTransactionType, IdempotencePrefix.CREDIT_CUSTOMER_ACCOUNT_PREFIX, false))
            );
        verifyNoMoreInteractions(accountTransaction);

        assertThat(receiptEventEntity.getTransactionEntity().getCustomerTransactionResult().getTransactionIdInDdaSystem()).isEqualTo(TRANSACTION_ID);
    }

    @Test
    void shouldMakeCustomerDebit() {
        //Given:
        when(configurationService.findConfig()).thenReturn(buildConfig());
        when(accountTransaction.makeTransaction(any(AccountTransactionRequestDTO.class)))
            .thenReturn(ACCOUNT_TRANSACTION_RESPONSE_DTO);
        //When:
        PaymentEventEntity paymentEventEntity = buildPaymentEventEntity();
        customerAccount.makeDebit(paymentEventEntity);
        //Then:
        verify(accountTransaction)
            .makeTransaction(
                eq(getExpectedAccountTransactionRequestDTO(DEBIT_TRANSACTION_TYPE, IdempotencePrefix.DEBIT_CUSTOMER_ACCOUNT_PREFIX, true))
            );
        verifyNoMoreInteractions(accountTransaction);
        assertThat(paymentEventEntity.getTransactionEntity().getCustomerTransactionResult().getTransactionIdInDdaSystem()).isEqualTo(TRANSACTION_ID);
    }

    @Test
    void shouldMakeCustomerReturnReceived() {
        //Given:
        when(configurationService.findConfig()).thenReturn(buildConfig());
        when(accountTransaction.makeTransaction(any(AccountTransactionRequestDTO.class)))
            .thenReturn(ACCOUNT_TRANSACTION_RESPONSE_DTO);
        //When:
        ReturnReceivedEventEntity returnReceivedEventEntity = buildReturnReceivedEventEntity();
        customerAccount.returnReceived(returnReceivedEventEntity);
        //Then:
        verify(accountTransaction)
            .makeTransaction(
                eq(getExpectedAccountTransactionRequestDTOReturn(DRBK_RCVD_TRANSACTION_TYPE,
                    IdempotencePrefix.RETURN_RECEIVED_CUSTOMER_ACCOUNT_PREFIX,
                    false, INFORMATION_ACCOUNT_HOLDER_TRANSACTION))
            );
        verifyNoMoreInteractions(accountTransaction);

        assertThat(returnReceivedEventEntity.getTransactionEntity().getCustomerTransactionResult().getTransactionIdInDdaSystem()).isEqualTo(TRANSACTION_ID);
    }

    @Test
    void shouldMakeCustomerReturnSent() {
        //Given:
        when(configurationService.findConfig()).thenReturn(buildConfig());
        when(accountTransaction.makeTransaction(any(AccountTransactionRequestDTO.class)))
            .thenReturn(ACCOUNT_TRANSACTION_RESPONSE_DTO);
        //When:
        ReturnSentEventEntity returnSentEventEntity = buildReturnSentEventEntity();
        customerAccount.returnSent(returnSentEventEntity);
        //Then:
        verify(accountTransaction)
            .makeTransaction(
                eq(getExpectedAccountTransactionRequestDTOReturn(DRBK_SENT_TRANSACTION_TYPE,
                    IdempotencePrefix.RETURN_SENT_CUSTOMER_ACCOUNT_PREFIX,
                    true, INFORMATION_ACCOUNT_HOLDER_TRANSACTION))
            );
        verifyNoMoreInteractions(accountTransaction);

        assertThat(returnSentEventEntity.getTransactionEntity().getCustomerTransactionResult().getTransactionIdInDdaSystem()).isEqualTo(TRANSACTION_ID);
    }

    @Test
    void shouldValidateCreditFromAReturnReceivedEventEntity() {
        //Given:
        when(configurationService.findConfig()).thenReturn(buildConfig());
        when(accountTransaction.validateCredit(any(AccountTransactionValidationRequestDTO.class)))
            .thenReturn(true);
        //When:
        ReturnReceivedEventEntity returnReceivedEventEntity = buildReturnReceivedEventEntity();
        assertThat(customerAccount.validateCredit(returnReceivedEventEntity)).isTrue();
        //Then:
        verify(accountTransaction)
            .validateCredit(
                eq(getExpectedAccountTransactionValidationRequestDTO(DRBK_RCVD_TRANSACTION_TYPE, false))
            );
        verifyNoMoreInteractions(accountTransaction);
    }

    @ParameterizedTest(name = "isDynamicQrCode {0}")
    @ValueSource(booleans = {true, false})
    void shouldValidateCreditFromAReceiptEventEntity(boolean isDynamicQrCode) {
        //Given:
        when(configurationService.findConfig()).thenReturn(buildConfig());
        when(accountTransaction.validateCredit(any(AccountTransactionValidationRequestDTO.class)))
            .thenReturn(true);
        //When:
        ReceiptEventEntity receiptEventEntity = buildReceiptEventEntity();
        receiptEventEntity.getTransactionEntity().setIsDynamicQrCode(isDynamicQrCode);
        assertThat(customerAccount.validateCredit(receiptEventEntity)).isTrue();
        //Then:
        int creditTransactionType = isDynamicQrCode ? QRCODE_CRED_TRANSACTION_TYPE : CREDIT_TRANSACTION_TYPE;
        verify(accountTransaction)
            .validateCredit(
                eq(getExpectedAccountTransactionValidationRequestDTO(creditTransactionType, false))
            );
        verifyNoMoreInteractions(accountTransaction);
    }

    @Test
    void shouldMakeCustomerReturnSentInformationAccountHolderTransactionEventId() {
        //Given:
        when(configurationService.findConfig()).thenReturn(buildConfig());
        when(accountTransaction.makeTransaction(any(AccountTransactionRequestDTO.class)))
            .thenReturn(ACCOUNT_TRANSACTION_RESPONSE_DTO);
        //When:
        ReturnSentEventEntity returnSentEventEntity = buildReturnSentEventEntity(EVENT_ID.toString());
        customerAccount.returnSent(returnSentEventEntity);
        //Then:
        verify(accountTransaction)
            .makeTransaction(
                eq(getExpectedAccountTransactionRequestDTOReturn(DRBK_SENT_TRANSACTION_TYPE,
                                    IdempotencePrefix.RETURN_SENT_CUSTOMER_ACCOUNT_PREFIX,
                                    true, EVENT_ID.toString()))
            );
        verifyNoMoreInteractions(accountTransaction);

        assertThat(returnSentEventEntity.getTransactionEntity().getCustomerTransactionResult().getTransactionIdInDdaSystem()).isEqualTo(TRANSACTION_ID);
    }

    @ParameterizedTest
    @EnumSource(value = TipoPessoaEnum.class, names = {"FISICA", "JURIDICA"})
    void shouldMakeCustomerDebitWhenTheTypeOfPersonIsNaturalOrLegal(TipoPessoaEnum tipoPessoa) {
        LancamentoResponseV2DTO lancamentoResponseV2DTO = new LancamentoResponseV2DTO();
        lancamentoResponseV2DTO.setClassificacaoCategoriaContaSPI(CACC);
        lancamentoResponseV2DTO.setCpfCnpjTitular(BigDecimal.valueOf(Long.parseLong("00000000000191")));
        lancamentoResponseV2DTO.setTipoPessoa(tipoPessoa);

        ACCOUNT_TRANSACTION_RESPONSE_DTO = AccountTransactionResponseDTO.builder()
            .transactionId(TRANSACTION_ID)
            .lancamentoResponseV2DTO(lancamentoResponseV2DTO)
            .build();

        when(configurationService.findConfig()).thenReturn(buildConfig());
        when(accountTransaction.makeTransaction(any(AccountTransactionRequestDTO.class)))
            .thenReturn(ACCOUNT_TRANSACTION_RESPONSE_DTO);

        PaymentEventEntity paymentEventEntity = buildPaymentEventEntity();
        customerAccount.makeDebit(paymentEventEntity);
        verify(accountTransaction)
            .makeTransaction(
                eq(getExpectedAccountTransactionRequestDTO(DEBIT_TRANSACTION_TYPE, IdempotencePrefix.DEBIT_CUSTOMER_ACCOUNT_PREFIX, true))
            );
        verifyNoMoreInteractions(accountTransaction);

        assertThat(paymentEventEntity.getPayerAccount().getTaxId()).contains("00000000191");
    }

    @Test
    void shouldThrowIllegalArgumentExceptionWhenTheTaxIdOfTheLaunchIsInvalid() {
        LancamentoResponseV2DTO lancamentoResponseV2DTO = new LancamentoResponseV2DTO();

        lancamentoResponseV2DTO.setClassificacaoCategoriaContaSPI(CACC);
        lancamentoResponseV2DTO.setCpfCnpjTitular(BigDecimal.valueOf(11234543200L));

        ACCOUNT_TRANSACTION_RESPONSE_DTO = AccountTransactionResponseDTO.builder()
            .transactionId(TRANSACTION_ID)
            .lancamentoResponseV2DTO(lancamentoResponseV2DTO)
            .build();

        when(configurationService.findConfig()).thenReturn(buildConfig());
        when(accountTransaction.makeTransaction(any(AccountTransactionRequestDTO.class)))
            .thenReturn(ACCOUNT_TRANSACTION_RESPONSE_DTO);

        PaymentEventEntity paymentEventEntity = buildPaymentEventEntity();
        assertThatThrownBy(() -> customerAccount.makeDebit(paymentEventEntity))
            .isInstanceOf(IllegalArgumentException.class).hasMessage("cpf/cnpj informed is invalid");

        //returning the original value
        lancamentoResponseV2DTO.setCpfCnpjTitular(BigDecimal.valueOf(92082843521L));

    }

    private static AccountTransactionRequestDTO getExpectedAccountTransactionRequestDTO(int transactionType,
                                                                                        String idempotencePrefix,
                                                                                        boolean shouldValidateBalance) {
        return getExpectedAccountTransactionRequestDTO(transactionType, idempotencePrefix, shouldValidateBalance,
            INFORMATION_ACCOUNT_HOLDER_TRANSACTION, ADDITIONALINFORMATION_INFO);
    }

    private static AccountTransactionRequestDTO getExpectedAccountTransactionRequestDTOReturn(int transactionType,
                                                                                              String idempotencePrefix,
                                                                                              boolean shouldValidateBalance,
                                                                                              String informationAccountHolderTransaction) {
        return getExpectedAccountTransactionRequestDTO(transactionType, idempotencePrefix, shouldValidateBalance,
            informationAccountHolderTransaction, UNSTRUCTURED_INFO);
    }

    private static AccountTransactionRequestDTO getExpectedAccountTransactionRequestDTO(int transactionType,
                                                           String idempotencePrefix,
                                                           boolean shouldValidateBalance,
                                                           String informationAccountHolderTransaction,
                                                           String remittanceInformation) {
        return AccountTransactionRequestDTO.builder()
            .idempotenceId(idempotencePrefix + END_TO_END_ID)
            .branch(CUSTOMER_BRANCH)
            .account(CUSTOMER_ACCOUNT_NUMBER)
            .transactionType(transactionType)
            .groupEntries(false)
            .validateBalance(shouldValidateBalance)
            .operationComplement(HISTORIC_COMPLEMENT)
            .endToEndId(END_TO_END_ID)
            .eventId(EVENT_ID)
            .informationAccountHolderTransaction(informationAccountHolderTransaction)
            .details(getJsonAccountTransactionDetails(END_TO_END_ID, remittanceInformation))
            .value(TRANSACTION_VALUE)
            .build();
    }

    private static AccountTransactionValidationRequestDTO getExpectedAccountTransactionValidationRequestDTO
        (int transactionType, boolean shouldValidateBalance) {
        return AccountTransactionValidationRequestDTO.builder()
            .branch(CUSTOMER_BRANCH)
            .account(CUSTOMER_ACCOUNT_NUMBER)
            .transactionType(transactionType)
            .operationComplement(HISTORIC_COMPLEMENT)
            .eventId(EVENT_ID)
            .informationAccountHolderTransaction(INFORMATION_ACCOUNT_HOLDER_TRANSACTION)
            .value(TRANSACTION_VALUE)
            .validateBalance(shouldValidateBalance)
            .accountHolderTaxId(new BigDecimal(RECEIVER_TAX_ID))
            .build();
    }

    @NotNull
    private static ParticipantEntity getPayerParticipantEntity() {
        ParticipantEntity payerParticipant = new ParticipantEntity();
        payerParticipant.setIspb(PAYER_PARTICIPANT_ISPB);
        return payerParticipant;
    }

    private static ParticipantEntity getReceiverParticipantEntity() {
        ParticipantEntity payerParticipant = new ParticipantEntity();
        payerParticipant.setIspb(RECEIVER_PARTICIPANT_ISPB);
        return payerParticipant;
    }

    private static PaymentEventEntity buildPaymentEventEntity() {
        PaymentEntity paymentEntity = new PaymentEntity();
        paymentEntity.setCheckCustomerAccountBalance(true);
        paymentEntity.setHistoricComplement(HISTORIC_COMPLEMENT);
        paymentEntity.setInformationAccountHolderTransaction(INFORMATION_ACCOUNT_HOLDER_TRANSACTION);
        paymentEntity.setPayerAccount(buildPayerAccount());
        paymentEntity.setPayerParticipant(getPayerParticipantEntity());
        paymentEntity.setEndToEndId(END_TO_END_ID);
        paymentEntity.setAdditionalInformation(ADDITIONALINFORMATION_INFO);

        PaymentEventEntity paymentEventEntity = new PaymentEventEntity();
        paymentEventEntity.setId(EVENT_ID);
        paymentEventEntity.setCorrelationId(END_TO_END_ID);
        paymentEventEntity.setValue(TRANSACTION_VALUE);
        paymentEventEntity.setPaymentEntity(paymentEntity);

        paymentEntity.setEvent(paymentEventEntity);

        return paymentEventEntity;
    }

    private static ReceiptEventEntity buildReceiptEventEntity() {
        ReceiptEntity receiptEntity = new ReceiptEntity();
        receiptEntity.setCheckCustomerAccountBalance(false);
        receiptEntity.setHistoricComplement(HISTORIC_COMPLEMENT);
        receiptEntity.setInformationAccountHolderTransaction(INFORMATION_ACCOUNT_HOLDER_TRANSACTION);
        receiptEntity.setPayerAccount(buildPayerAccount());
        receiptEntity.setPayerParticipant(getPayerParticipantEntity());
        receiptEntity.setReceiverAccount(buildReceiverAccount());
        receiptEntity.setReceiverParticipant(getReceiverParticipantEntity());
        receiptEntity.setEndToEndId(END_TO_END_ID);
        receiptEntity.setAdditionalInformation(ADDITIONALINFORMATION_INFO);

        receiptEntity.getReceiverAccount().setTaxId(RECEIVER_TAX_ID);

        ReceiptEventEntity receiptEventEntity = new ReceiptEventEntity();
        receiptEventEntity.setId(EVENT_ID);
        receiptEventEntity.setCorrelationId(END_TO_END_ID);
        receiptEventEntity.setValue(TRANSACTION_VALUE);
        receiptEventEntity.setReceiptEntity(receiptEntity);
        return receiptEventEntity;
    }


    private static ReturnSentEventEntity buildReturnSentEventEntity() {
        return buildReturnSentEventEntity(INFORMATION_ACCOUNT_HOLDER_TRANSACTION);
    }

    private static ReturnSentEventEntity buildReturnSentEventEntity(String informationAccountHolderTransaction) {
        ReturnSentEntity returnSentEntity = new ReturnSentEntity();
        returnSentEntity.setCheckCustomerAccountBalance(true);
        returnSentEntity.setHistoricComplement(HISTORIC_COMPLEMENT);
        returnSentEntity.setInformationAccountHolderTransaction(informationAccountHolderTransaction);
        returnSentEntity.setPayerParticipant(getPayerParticipantEntity());
        returnSentEntity.setPayerAccount(buildPayerAccount());
        returnSentEntity.setEndToEndId(END_TO_END_ID);
        returnSentEntity.setUnstructured(UNSTRUCTURED_INFO);

        ReturnSentEventEntity returnSentEventEntity = new ReturnSentEventEntity();
        returnSentEventEntity.setId(EVENT_ID);
        returnSentEventEntity.setCorrelationId(END_TO_END_ID);
        returnSentEventEntity.setValue(TRANSACTION_VALUE);
        returnSentEventEntity.setReturnSentEntity(returnSentEntity);
        returnSentEventEntity.setOriginalEvent(buildReceiptEventEntity());

        return returnSentEventEntity;
    }

    private static ReturnReceivedEventEntity buildReturnReceivedEventEntity() {
        ReturnReceivedEntity returnReceivedEntity = new ReturnReceivedEntity();
        ReceiverAccountEntity receiverAccountEntity = new ReceiverAccountEntity();
        returnReceivedEntity.setReceiverAccount(receiverAccountEntity);

        returnReceivedEntity.setCheckCustomerAccountBalance(false);
        returnReceivedEntity.setHistoricComplement(HISTORIC_COMPLEMENT);
        returnReceivedEntity.setInformationAccountHolderTransaction(INFORMATION_ACCOUNT_HOLDER_TRANSACTION);
        returnReceivedEntity.setPayerAccount(buildPayerAccount());
        returnReceivedEntity.setPayerParticipant(getPayerParticipantEntity());
        returnReceivedEntity.setReceiverParticipant(getReceiverParticipantEntity());
        returnReceivedEntity.getReceiverAccount().setAccount(RECEIVER_TAX_ID);
        returnReceivedEntity.setEndToEndId(END_TO_END_ID);
        returnReceivedEntity.setUnstructured(UNSTRUCTURED_INFO);

        ReturnReceivedEventEntity returnReceivedEventEntity = new ReturnReceivedEventEntity();
        returnReceivedEventEntity.setId(EVENT_ID);
        returnReceivedEventEntity.setCorrelationId(END_TO_END_ID);
        returnReceivedEventEntity.setValue(TRANSACTION_VALUE);
        returnReceivedEventEntity.setReturnReceivedEntity(returnReceivedEntity);
        returnReceivedEventEntity.setOriginalEvent(buildPaymentEventEntity());
        returnReceivedEventEntity.getReturnReceivedEntity().getReceiverAccount().setTaxId(RECEIVER_ACCOUNT_TAXI_ID);
        returnReceivedEventEntity.getOriginalEvent().getTransactionEntity().getPayerAccount().setTaxId(RECEIVER_TAX_ID);
        return returnReceivedEventEntity;
    }

    private static ConfigEntity buildConfig() {
        ConfigEntity configEntity = new ConfigEntity();
        configEntity.setCustomerCredTransactionType(CREDIT_TRANSACTION_TYPE);
        configEntity.setCustomerDebTransactionType(DEBIT_TRANSACTION_TYPE);
        configEntity.setCustDrawbReceivedTransType(DRBK_RCVD_TRANSACTION_TYPE);
        configEntity.setCustDrawbSentTransType(DRBK_SENT_TRANSACTION_TYPE);
        configEntity.setQrcodeCredTransactionType(QRCODE_CRED_TRANSACTION_TYPE);
        return configEntity;
    }

    private static PayerAccountEntity buildPayerAccount() {
        PayerAccountEntity payerAccount = new PayerAccountEntity();
        payerAccount.setAccount(CUSTOMER_ACCOUNT_NUMBER.toString());
        payerAccount.setBranch(String.valueOf(CUSTOMER_BRANCH));
        payerAccount.setPersonType("PF");
        return payerAccount;
    }

    private static ReceiverAccountEntity buildReceiverAccount() {
        ReceiverAccountEntity receiverAccountEntity = new ReceiverAccountEntity();
        receiverAccountEntity.setAccount(CUSTOMER_ACCOUNT_NUMBER.toString());
        receiverAccountEntity.setBranch(String.valueOf(CUSTOMER_BRANCH));
        return receiverAccountEntity;
    }

    private static String getJsonAccountTransactionDetails(String endToEndId, String remittanceInformation) {
        try {
            return new ObjectMapper().writeValueAsString(
                new AccountTransactionDetailDTO(endToEndId, remittanceInformation));
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

}
