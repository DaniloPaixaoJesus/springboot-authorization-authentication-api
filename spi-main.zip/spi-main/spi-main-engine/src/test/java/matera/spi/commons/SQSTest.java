package matera.spi.commons;

import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.services.sqs.model.*;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.testcontainers.containers.output.Slf4jLogConsumer;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.testcontainers.containers.localstack.LocalStackContainer.Service.SQS;

@Slf4j
@Testcontainers
public class SQSTest extends AbstractLocalStackTest {

    @Autowired
    private static AmazonSQS amazonSQS;

    private String queueURL;

    private static final String QUEUE_NAME = "sqs.queue.teste.fifo";
    private static final Integer QTD_MESSAGES = 5;

    @BeforeAll
    public static void setup() {
        amazonSQS = AmazonSQSClientBuilder.standard()
                .withEndpointConfiguration(localStackContainer.getEndpointConfiguration(SQS))
                .withCredentials(localStackContainer.getDefaultCredentialsProvider())
                .build();

        Slf4jLogConsumer logConsumer = new Slf4jLogConsumer(log);
        localStackContainer.followOutput(logConsumer);
    }

    @BeforeEach
    public void init() {
        Map<String, String> attributes = new HashMap<>();
        attributes.put("FifoQueue", "true");
        attributes.put("ContentBasedDeduplication", "true");

        CreateQueueRequest createQueueRequest = new CreateQueueRequest().withQueueName(QUEUE_NAME).withAttributes(attributes);
        queueURL = amazonSQS.createQueue(createQueueRequest).getQueueUrl();
    }

    @AfterEach
    public void finish() {
        DeleteQueueRequest deleteQueueRequest = new DeleteQueueRequest().withQueueUrl(queueURL);
        amazonSQS.deleteQueue(deleteQueueRequest);
    }

    @Test
    void shouldBeReadMessagesWhenBatchSend() {
        List<SendMessageBatchRequestEntry> listMessagesToSend =  new ArrayList<>();
        for (int i = 0; i < QTD_MESSAGES ; i++) {
            SendMessageBatchRequestEntry sendMessageBatchRequestEntry = new SendMessageBatchRequestEntry()
                    .withMessageBody("This is my message text number " + i + ".")
                    .withMessageGroupId("GroupIdTest")
                    .withId(String.valueOf(i));
            listMessagesToSend.add(sendMessageBatchRequestEntry);
        }

        SendMessageBatchRequest sendMessageRequest = new SendMessageBatchRequest()
                .withQueueUrl(queueURL)
                .withEntries(listMessagesToSend)
                ;

        SendMessageBatchResult sendMessageBatchResult = amazonSQS.sendMessageBatch(sendMessageRequest);

        ReceiveMessageRequest receiveMessageRequest = new ReceiveMessageRequest().withQueueUrl(queueURL).withMaxNumberOfMessages(QTD_MESSAGES);

        ReceiveMessageResult receiveResult = amazonSQS.receiveMessage(receiveMessageRequest);
        List<Message> messages = receiveResult.getMessages();

        Assertions.assertTrue(sendMessageBatchResult.getFailed().isEmpty());
        Assertions.assertEquals(QTD_MESSAGES, messages.size());
    }

    @Test
    void shouldBeReadMessagesWhenSingleSend() {
        for (int i = 0; i < QTD_MESSAGES ; i++) {
            SendMessageRequest sendMessageRequest = new SendMessageRequest()
                    .withQueueUrl(queueURL)
                    .withMessageBody("This is my message text number " + i + ".")
                    .withMessageGroupId("GroupIdTest");
            SendMessageResult sendMessageResult = amazonSQS.sendMessage(sendMessageRequest);
        }

        ReceiveMessageRequest receiveMessageRequest = new ReceiveMessageRequest().withQueueUrl(queueURL).withMaxNumberOfMessages(QTD_MESSAGES);

        ReceiveMessageResult receiveResult = amazonSQS.receiveMessage(receiveMessageRequest);
        List<Message> messages = receiveResult.getMessages();

        Assertions.assertEquals(QTD_MESSAGES, messages.size());
    }
}
