package matera.spi.indirect.application.service.mapper;

import matera.spi.dto.IndirectParticipantPossibleActionsDTO;
import matera.spi.indirect.domain.model.ParticipantMipIndirectStatusEntity;
import matera.spi.indirect.util.ParticipantMipIndirectDataSetUtil;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class IndirectParticipantPossibleActionsDTOMapperTest {

    @Test
    void shouldMapEntityToDto() {
        final ParticipantMipIndirectStatusEntity entity =
            ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectStatusEntity();

        final IndirectParticipantPossibleActionsDTO dto =
            IndirectParticipantPossibleActionsDTOMapper.mapEntityToDto(entity);

        assertEquals(entity.allowsChangeIds(), dto.getChangeIdentification());
        assertEquals(entity.allowsChangeIds(), dto.getChangeGeneralInfo());
        assertEquals(entity.allowsClearingRegistry(), dto.getClearingRegisterRequest());
        assertEquals(entity.allowsClearingRescission(), dto.getClearingRescissionRequest());
    }
}
