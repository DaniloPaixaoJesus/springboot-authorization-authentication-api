package matera.spi.main.domain.service.event.receiver;

import matera.spi.main.dto.MessageReceiverEventDTO;
import matera.spi.main.dto.event.EventSpecificationFromReceivedMessageDTO;
import matera.spi.main.exception.EventErrorException;
import matera.spi.main.exception.IllegalProcessException;
import matera.spi.main.utils.EntityCreationUtils;
import matera.spi.utils.DocumentUtils;
import matera.spi.utils.exceptions.XPathDocumentProcessingException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static matera.spi.main.utils.EntityCreationUtils.PACS_008_REPLY_ELEMENT;
import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static matera.spi.utils.DocumentUtils.stringToXmlDocument;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class MessageReceiverProcessorNonReplyServiceTest {

	private static final String PACS_008_SPI_1_2_CONTA_10_MSG = "pacs.008/pacs.008.spi.1.2_CONTA_10_msg.xml";
	private static final String PACS_002_SPI_1_2_ERRO_1_MSG = "pacs.002/pacs.002.spi.1.2_ERRO_1_msg.xml";
	private static final Document PACS_008_WITH_10_ELEMENTS_DOCUMENT = stringToXmlDocument(getStringFromXmlFile(PACS_008_SPI_1_2_CONTA_10_MSG));
	private static final Document PACS_002_DOCUMENT = stringToXmlDocument(getStringFromXmlFile(PACS_002_SPI_1_2_ERRO_1_MSG));
	private static final int TEN = 10;

	@InjectMocks
	private MessageReceiverProcessorNonReplyService messageReceiverNonReplyService;
	@Mock
	private MessageElementNodeProcessorService messageElementNodeProcessorService;

	@Test
	@DisplayName("when processing a pacs.008 message with ten elements should process the ten nodes")
	void shouldProcessTheTenElementsNodesWhenADocumentWithTenElementsWasProvided() {
		MessageReceiverEventDTO messageReceiverEventDTO = MessageReceiverEventDTO.builder()
				.messageEntity(EntityCreationUtils.buildPacs008MessageEntity())
				.messageDocument(PACS_008_WITH_10_ELEMENTS_DOCUMENT)
				.build();
		messageReceiverNonReplyService.processEvent(messageReceiverEventDTO);

		NodeList nodeList = DocumentUtils.getElementsByExpression(PACS_008_WITH_10_ELEMENTS_DOCUMENT, PACS_008_REPLY_ELEMENT);
		List<EventSpecificationFromReceivedMessageDTO> possibleEventSpecDTOs = IntStream.range(0, 10).mapToObj(nodeList::item)
				.map(node -> new EventSpecificationFromReceivedMessageDTO(messageReceiverEventDTO, node)).collect(Collectors.toList());
		verify(messageElementNodeProcessorService, times(TEN))
				.processElementNodeFromNonReplyMessage(argThat(possibleEventSpecDTOs::contains));
	}

	@Test
	@DisplayName("when not found nodes to iterate should throw EventErrorException")
	void shouldThrowsEventErrorExceptionWhenNotFoundAnyElementIterate() {
		MessageReceiverEventDTO messageReceiverEventDTO = MessageReceiverEventDTO.builder()
				.messageEntity(EntityCreationUtils.buildPacs008MessageEntity())
				.messageDocument(PACS_002_DOCUMENT)
				.build();
		// it won't found the PACS.002 elements with the PACS.008 REPLY_ELEMENT
		assertThatThrownBy(() -> messageReceiverNonReplyService.processEvent(messageReceiverEventDTO))
				.isInstanceOf(EventErrorException.class)
				.hasMessage("Failed to get content nodes from message %s given the content path /Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf", messageReceiverEventDTO.getMessageEntity());
		verify(messageElementNodeProcessorService, never())
				.processElementNodeFromNonReplyMessage(any(EventSpecificationFromReceivedMessageDTO.class));
	}

	@Test
	@DisplayName("when an error occurs while processing a node should throw EventErrorException with all error that happened")
	void shouldThrowsEventErrorExceptionWhenAtLeastOneErrorFoundAtNodeProcessing() {
		MessageReceiverEventDTO messageReceiverEventDTO = MessageReceiverEventDTO.builder()
				.messageEntity(EntityCreationUtils.buildPacs008MessageEntity())
				.messageDocument(PACS_008_WITH_10_ELEMENTS_DOCUMENT)
				.build();
		NodeList nodeList = DocumentUtils.getElementsByExpression(PACS_008_WITH_10_ELEMENTS_DOCUMENT, PACS_008_REPLY_ELEMENT);
		List<EventSpecificationFromReceivedMessageDTO> possibleEventSpecDTOs = IntStream.range(0, 10).mapToObj(nodeList::item)
				.map(node -> new EventSpecificationFromReceivedMessageDTO(messageReceiverEventDTO, node)).collect(Collectors.toList());
		// STUBBING
		//Throw error for second and seven node
		doNothing().when(messageElementNodeProcessorService)
				.processElementNodeFromNonReplyMessage(any(EventSpecificationFromReceivedMessageDTO.class));
		doThrow(XPathDocumentProcessingException.class)
				.when(messageElementNodeProcessorService)
				.processElementNodeFromNonReplyMessage(eq(possibleEventSpecDTOs.get(2)));
		doThrow(RuntimeException.class)
				.when(messageElementNodeProcessorService)
				.processElementNodeFromNonReplyMessage(eq(possibleEventSpecDTOs.get(7)));
		// Testing
		// it won't found the PACS.002 elements with the PACS.008 REPLY_ELEMENT
		assertThatThrownBy(() -> messageReceiverNonReplyService.processEvent(messageReceiverEventDTO))
				.isInstanceOf(EventErrorException.class)
				.hasMessage("Got {2=matera.spi.utils.exceptions.XPathDocumentProcessingException, 7=java.lang.RuntimeException} errors when processing new event message %s", messageReceiverEventDTO);

		verify(messageElementNodeProcessorService, times(TEN))
				.processElementNodeFromNonReplyMessage(argThat(possibleEventSpecDTOs::contains));
	}

    @Test
    void shouldIgnoreIllegalProcessException() {
        MessageReceiverEventDTO messageReceiverEventDTO = MessageReceiverEventDTO.builder()
            .messageEntity(EntityCreationUtils.buildPacs008MessageEntity())
            .messageDocument(PACS_008_WITH_10_ELEMENTS_DOCUMENT)
            .build();

        doThrow(IllegalProcessException.class)
            .when(messageElementNodeProcessorService)
            .processElementNodeFromNonReplyMessage(any());

        Assertions.assertDoesNotThrow(() -> {
            messageReceiverNonReplyService.processEvent(messageReceiverEventDTO);
        });
    }
}
