package matera.spi.lm.domain.service.extractor.message;

import matera.spi.lm.dto.Camt054ExtractMessageDTO;
import matera.spi.utils.DocumentUtils;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static matera.spi.utils.DocumentUtils.stringToXmlDocument;

@ExtendWith(MockitoExtension.class)
public class Camt054MessageExtractorTest {

    private Node expectedNode;
    private Camt054ExtractMessageDTO expectedDTO;

    private static final String EXPECTED_VERSION = "camt.054/1.3";
    private static final String CAMT_054_CONSULTA_LANCAMENTO_PATH = "camt.054/camt.054_consulta_lancamento.xml";
    private static final String CAMT_054_STRING = getStringFromXmlFile(CAMT_054_CONSULTA_LANCAMENTO_PATH);
    private static final Document CAMT_054_DOCUMENT = stringToXmlDocument(CAMT_054_STRING);

    @Spy
    private Camt054MessageExtractor camT054xtractor;

    @BeforeEach
    void init() {
        expectedDTO = buildExpectedDTO();
        expectedNode = DocumentUtils.getElementsByExpression(CAMT_054_DOCUMENT, "Envelope/Document/BkToCstmrDbtCdtNtfctn").item(0);
    }

    @Test
    void shouldReturnValidDTO() {
        final Camt054ExtractMessageDTO actualDTO = camT054xtractor.extractValues(expectedNode);
        Assertions.assertEquals(expectedDTO, actualDTO);
    }

    @Test
    void shouldValidateXmlVersion() {
        Assertions.assertTrue(CAMT_054_STRING.contains(EXPECTED_VERSION));
    }

    private Camt054ExtractMessageDTO buildExpectedDTO() {
        return Camt054ExtractMessageDTO.builder()
            .type("D")
            .value("1000.00")
            .effectiveTimestamp("2020-01-01T08:30:12.000Z")
            .ispbDebtor("13370835")
            .ispbCreditor("00255564")
            .build();
    }
}
