package matera.spi.lm.rest;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.SummaryOfTheDayDTO;
import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.domain.model.event.EventStatusEntity;
import matera.spi.main.domain.model.event.EventTypeEntity;
import matera.spi.main.domain.model.event.transaction.PaymentEventEntity;
import matera.spi.main.domain.model.event.transaction.ReceiptEventEntity;
import matera.spi.main.domain.model.transaction.PaymentEntity;
import matera.spi.main.domain.model.transaction.ReceiptEntity;
import matera.spi.main.domain.service.ConfigurationService;
import matera.spi.main.domain.service.PaymentService;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.EventStatusRepository;
import matera.spi.main.persistence.EventTypeRepository;
import matera.spi.main.persistence.ParticipantRepository;
import matera.spi.main.persistence.PaymentEventRepository;
import matera.spi.main.persistence.ReceiptEventRepository;
import matera.spi.main.persistence.ReceiptRepository;
import matera.spi.main.persistence.TransactionRepository;
import matera.spi.main.utils.PaymentTransactionUtils;
import matera.spi.main.utils.ReceiptTransactionUtils;
import matera.spi.utils.LocalDateTimeUtils;

import io.restassured.RestAssured;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;

import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import static matera.spi.utils.LocalDateTimeUtils.getMaxLocalDateTime;
import static matera.spi.utils.LocalDateTimeUtils.getMinLocalDateTime;
import static matera.spi.utils.LocalDateTimeUtils.getTodayUTC;

@IntegrationTest
public class SummaryApiDelegateImplTest  {

    @Autowired
    private PaymentTransactionUtils paymentTransactionUtils;

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private ReceiptTransactionUtils receiptTransactionUtils;

    @Autowired
    private PaymentEventRepository paymentEventRepository;

    @Autowired
    private ReceiptRepository receiptRepository;

    @Autowired
    private ReceiptEventRepository receiptEventRepository;

    @Autowired
    private EventRepository eventRepository;

    @Autowired
    private EventStatusRepository eventStatusRepository;

    @Autowired
    private EventTypeRepository eventTypeRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private ParticipantRepository participantRepository;

    @Autowired
    private ConfigurationService configurationService;

    @Autowired
    @LocalServerPort
    private int port;

    private Integer ISPB;

    private static final String data = getTodayUTC().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    private static final String startTimestampUtc = getMinLocalDateTime(getTodayUTC()).format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss"));
    private static final String endTimestampUtc = getMaxLocalDateTime(getTodayUTC()).format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss"));
    private static final String PAYMENTS_BASE_URI_MOVEMENT = "ui/v1/psp/summary/last-payments-day";
    private static final String RECEIPTS_BASE_URI_MOVEMENT = "ui/v1/psp/summary/last-receipts-day";
    private static final String MOVIMENT_DATE = "movimentDate=" + data;
    private static final String TIMESTAMPS = "startTimestampUtc=" + startTimestampUtc + "&endTimestampUtc=" + endTimestampUtc;

    private static final int PAYMENT_EVENT_TYPE = 1;

    private static final int RECEIPT_EVENT_TYPE = 2;

    private static final int EVENTS_ARRAY_SIZE = 10;

    private static final List<Integer> PAYMENT_EVENTS_WITH_MACRO_EVENTS_IDS = Arrays.asList(3 , 1 , 2 , 6 , 7 , 4 , 5 , 22);
    private static final List<String> PAYMENT_EVENTS_DESCRIPTIONS = Arrays.asList("Confirmed payments", "Outstanding payments", "Payments rejected by Clearing", "Payments rejected by PSP");

    private static final List<Integer> RECEIPT_EVENTS_WITH_MACRO_EVENTS_IDS = Arrays.asList(3 , 6 , 8 , 9 , 12 , 5 , 20 , 10,21);
    private static final List<String> RECEIPT_EVENTS_DESCRIPTIONS = Arrays.asList("Confirmed receipts", "Pending receipts", "Receipts rejected by Clearing", "Receipts rejected by PSP");

    private static final BigDecimal TRANSACTION_VALUE = BigDecimal.valueOf(150);

    @BeforeEach
    void beforeEach() {
        RestAssured.port = port;
        ISPB = configurationService.findConfig().getIspb();
    }

    @AfterEach
    void deleteAllInsertedValues() {
        paymentTransactionUtils.deleteAllInsertedValues();
        receiptTransactionUtils.deleteAllInsertedValues();
    }

    @Test
    void shouldReturnSummaryOfPaymentsOfTheDayWithTimeStamps() {

        eventRepository.saveAll(createPaymentEventList());

        List<SummaryOfTheDayDTO> summaries = RestAssured.given()
                .log().all()
                .when().get(PAYMENTS_BASE_URI_MOVEMENT + "?" + TIMESTAMPS)
                .getBody()
                .jsonPath()
                .getList("data" , SummaryOfTheDayDTO.class);


        Assertions.assertEquals(EVENTS_ARRAY_SIZE , summaries.stream().mapToInt(SummaryOfTheDayDTO::getTransactionsAmount).sum());
        Assertions.assertTrue(summaries.stream().allMatch(summary -> summary.getCode() > 0 && summary.getCode() <= 4));
        Assertions.assertTrue(summaries.stream().allMatch(summary -> summary.getValue()
                .compareTo(TRANSACTION_VALUE.multiply(BigDecimal.valueOf(summary.getTransactionsAmount())))
                == 0));
        Assertions.assertTrue(summaries.stream().allMatch(summary -> PAYMENT_EVENTS_DESCRIPTIONS.contains(summary.getStatus())));

    }

    @Test
    void shouldReturnSummaryOfReceiptsOfTheDayWithTimeStamps() {

        eventRepository.saveAll(createReceiptEventList());

        List<SummaryOfTheDayDTO> summaries = RestAssured.given()
                .log().all()
                .when().get(RECEIPTS_BASE_URI_MOVEMENT + "?" + TIMESTAMPS)
                .getBody()
                .jsonPath()
                .getList("data" , SummaryOfTheDayDTO.class);


        Assertions.assertEquals(EVENTS_ARRAY_SIZE , summaries.stream().mapToInt(SummaryOfTheDayDTO::getTransactionsAmount).sum());
        Assertions.assertTrue(summaries.stream().allMatch(summary -> summary.getCode() > 4 && summary.getCode() <= 8));
        Assertions.assertTrue(summaries.stream().allMatch(summary -> summary.getValue()
                .compareTo(TRANSACTION_VALUE.multiply(BigDecimal.valueOf(summary.getTransactionsAmount())))
                == 0));
        Assertions.assertTrue(summaries.stream().allMatch(summary -> RECEIPT_EVENTS_DESCRIPTIONS.contains(summary.getStatus())));

    }

    @Test
    void shouldReturnSummaryOfPaymentsOfTheDayWithMovementDate() {

        eventRepository.saveAll(createPaymentEventList());

        List<SummaryOfTheDayDTO> summaries = RestAssured.given()
            .log().all()
            .when().get(PAYMENTS_BASE_URI_MOVEMENT + "?" + MOVIMENT_DATE)
            .getBody()
            .jsonPath()
            .getList("data" , SummaryOfTheDayDTO.class);


        Assertions.assertEquals(EVENTS_ARRAY_SIZE , summaries.stream().mapToInt(SummaryOfTheDayDTO::getTransactionsAmount).sum());
        Assertions.assertTrue(summaries.stream().allMatch(summary -> summary.getCode() > 0 && summary.getCode() <= 4));
        Assertions.assertTrue(summaries.stream().allMatch(summary -> summary.getValue()
                                                                         .compareTo(TRANSACTION_VALUE.multiply(BigDecimal.valueOf(summary.getTransactionsAmount())))
                                                                     == 0));
        Assertions.assertTrue(summaries.stream().allMatch(summary -> PAYMENT_EVENTS_DESCRIPTIONS.contains(summary.getStatus())));

    }

    @Test
    void shouldReturnSummaryOfReceiptsOfTheDayWithMovementDate() {

        eventRepository.saveAll(createReceiptEventList());

        List<SummaryOfTheDayDTO> summaries = RestAssured.given()
            .log().all()
            .when().get(RECEIPTS_BASE_URI_MOVEMENT + "?" + MOVIMENT_DATE)
            .getBody()
            .jsonPath()
            .getList("data" , SummaryOfTheDayDTO.class);


        Assertions.assertEquals(EVENTS_ARRAY_SIZE , summaries.stream().mapToInt(SummaryOfTheDayDTO::getTransactionsAmount).sum());
        Assertions.assertTrue(summaries.stream().allMatch(summary -> summary.getCode() > 4 && summary.getCode() <= 8));
        Assertions.assertTrue(summaries.stream().allMatch(summary -> summary.getValue()
                                                                         .compareTo(TRANSACTION_VALUE.multiply(BigDecimal.valueOf(summary.getTransactionsAmount())))
                                                                     == 0));
        Assertions.assertTrue(summaries.stream().allMatch(summary -> RECEIPT_EVENTS_DESCRIPTIONS.contains(summary.getStatus())));

    }

    @Test
    void shouldReturnBadRequestWhenAllParametersAreInformedToSummaryOfReceiptsOfTheDay() {
        RestAssured.given()
            .log().all()
            .when().get(RECEIPTS_BASE_URI_MOVEMENT + "?" + MOVIMENT_DATE + "&" + TIMESTAMPS)
            .then()
            .statusCode(400)
            .assertThat().body("error[0].message", Matchers.containsString("Invalid combination of parameters. Choose either movimentDate or startTimestampUtc and endTimestampUtc."));
    }

    @Test
    void shouldReturnBadRequestWhenAllParametersAreInformedToSummaryOfPaymentsOfTheDay() {
        RestAssured.given()
            .log().all()
            .when().get(PAYMENTS_BASE_URI_MOVEMENT + "?" + MOVIMENT_DATE + "&" + TIMESTAMPS)
            .then()
            .statusCode(400)
            .assertThat().body("error[0].message", Matchers.containsString("Invalid combination of parameters. Choose either movimentDate or startTimestampUtc and endTimestampUtc."));
    }

    private PaymentEntity createPaymentEntity(int i) {

        var payment = paymentTransactionUtils.buildNewPayment();
        payment.setEndToEndId(paymentService.generateEndToEndID(ISPB.toString()));
        payment.setPayerParticipant(getParticipant());

        return payment;
    }

    private ParticipantEntity getParticipant() {

        return participantRepository.findByIspb(ISPB).orElse(null);
    }

    private ReceiptEntity createReceiptEntity(int i) {

        var receipt = receiptTransactionUtils.buildReceiptEntity();
        receipt.setEndToEndId(paymentService.generateEndToEndID(ISPB.toString()));
        receipt.setReceiverParticipant(getParticipant());

        return receipt;
    }

    private List<PaymentEventEntity> createPaymentEventList() {

        List<PaymentEventEntity> entities = new ArrayList<>();

        for (int i = 0; i < EVENTS_ARRAY_SIZE; i++) {
            PaymentEventEntity paymentEventEntity = new PaymentEventEntity();
            paymentEventEntity.setCorrelationId("123");
            paymentEventEntity.setInitiatorIspb(123);
            paymentEventEntity.setResponsible("RESPONSIBLE");
            paymentEventEntity.setStatus(getPaymentEventStatus());
            paymentEventEntity.setPaymentEntity(createPaymentEntity(i));
            paymentEventEntity.setEventTypeEntity(getEventType(PAYMENT_EVENT_TYPE));
            paymentEventEntity.setValue(TRANSACTION_VALUE);
            paymentEventEntity.setInitiationTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
            paymentEventEntity.setClearingTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
            entities.add(paymentEventEntity);
        }
        return entities;
    }

    private List<ReceiptEventEntity> createReceiptEventList() {

        List<ReceiptEventEntity> entities = new ArrayList<>();

        for (int i = 0; i < EVENTS_ARRAY_SIZE; i++) {
            ReceiptEventEntity receiptEventEntity = new ReceiptEventEntity();
            receiptEventEntity.setCorrelationId("123");
            receiptEventEntity.setInitiatorIspb(123);
            receiptEventEntity.setResponsible("RESPONSIBLE");
            receiptEventEntity.setStatus(getReceiptEventStatus());
            receiptEventEntity.setReceiptEntity(createReceiptEntity(i));
            receiptEventEntity.setEventTypeEntity(getEventType(RECEIPT_EVENT_TYPE));
            receiptEventEntity.setValue(TRANSACTION_VALUE);
            receiptEventEntity.setInitiationTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
            receiptEventEntity.setClearingTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
            entities.add(receiptEventEntity);
        }
        return entities;
    }

    private EventTypeEntity getEventType(int id) {
        return eventTypeRepository.findById(id).orElse(null);
    }

    private EventStatusEntity getPaymentEventStatus() {

        int status = PAYMENT_EVENTS_WITH_MACRO_EVENTS_IDS.get(new Random()
                .nextInt(PAYMENT_EVENTS_WITH_MACRO_EVENTS_IDS.size()));

        return eventStatusRepository.findById(status).orElse(null);

    }

    private EventStatusEntity getReceiptEventStatus() {

        int status = RECEIPT_EVENTS_WITH_MACRO_EVENTS_IDS.get(new Random()
                .nextInt(PAYMENT_EVENTS_WITH_MACRO_EVENTS_IDS.size()));

        return eventStatusRepository.findById(status).orElse(null);

    }

}
