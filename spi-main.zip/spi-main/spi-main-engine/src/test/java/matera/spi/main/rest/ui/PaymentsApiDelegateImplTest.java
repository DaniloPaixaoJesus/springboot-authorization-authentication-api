package matera.spi.main.rest.ui;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.AccountTypeUIDTO;
import matera.spi.dto.InstantPaymentSettlementResponseUIDTO;
import matera.spi.dto.InstantPaymentsResponseDTO;
import matera.spi.dto.InstantPaymentsUIDTO;
import matera.spi.dto.PayerUIDTO;
import matera.spi.dto.PaymentsUIDTO;
import matera.spi.dto.ReceiverUIDTO;
import matera.spi.dto.RemoteAccountUIDTO;
import matera.spi.main.application.service.PaymentsHelper;
import matera.spi.main.application.service.PaymentsService;
import matera.spi.main.application.service.PaymentsValidatorHelper;
import matera.spi.main.domain.service.PaymentService;
import matera.spi.main.domain.service.participants.IntraMipVerifier;
import matera.spi.main.utils.constants.TransactionConstants;
import matera.spi.utils.LocalDateTimeUtils;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;

import java.math.BigDecimal;
import java.util.List;

import static org.hamcrest.Matchers.containsString;
import static org.mockito.Mockito.doReturn;

@IntegrationTest
class PaymentsApiDelegateImplTest  {

    private static final String ISPB_INVALID_LENGTH_12 = "123456789123";
    private static final String ISPB_VALID_LENGTH_8 = "12345678";
    private static final String ISPB_VALID_LENGTH_3 = "123";
    private static final String ISPB_VALID_LENGTH_3_WITH_ZERO = "00000123";
    private static final String ISPB_ALPHA_NUMERIC = "abcd";
    private static final String PREFIX_END_TO_END_ID = "E";
    private static final String BASE_URI = "/ui/v1/instant-payments/end-to-end-id";
    private static final String BASE_URI_INSTANT_PAYMENTS = "/ui/v1/instant-payments";
    private static final String BODY_VALID_LENGTH_8 = generateJson(ISPB_VALID_LENGTH_8);
    private static final String BODY_VALID_LENGTH_3 = generateJson(ISPB_VALID_LENGTH_3);
    private static final String BODY_VALID_LENGTH_12 = generateJson(ISPB_INVALID_LENGTH_12);
    private static final String BODY_WITH_ISPB_ALPHA_NUMERIC = generateJson(ISPB_ALPHA_NUMERIC);
    private static final String EVENT_ID = "3c95633e-738c-11ea-bc55-0242ac130003";
    public static final String END_TO_END_ID = "E0057376820200217082881978247550";


    @Autowired
    private PaymentsApiDelegateImpl paymentsApiDelegateImpl;
    @Autowired
    private PaymentsService paymentsService;
    @Autowired
    private PaymentsValidatorHelper paymentsValidatorHelper;
    @Autowired
    private PaymentsHelper paymentsHelper;
    @Autowired
    private PaymentService paymentService;
    @Mock
    private IntraMipVerifier intraMipVerifier;

    private PaymentsService spiedPaymentsService;


    @LocalServerPort
    private int port;

    @BeforeEach
    void beforeEach() {
        RestAssured.port = port;
        spiedPaymentsService = Mockito.spy(new PaymentsService(paymentsValidatorHelper, paymentsHelper, paymentService, intraMipVerifier));
        paymentsApiDelegateImpl.setPaymentsService(spiedPaymentsService);
    }

    @AfterEach
    void tearDown() {
        paymentsApiDelegateImpl.setPaymentsService(paymentsService);
    }

    @Test
    void shouldReturnAEndToEndIDWhenBodyIsValidAndLengthIsEight() {
        RestAssured.given()
                .contentType(ContentType.JSON)
                .body(BODY_VALID_LENGTH_8)
                .when().post(BASE_URI)
                .then()
                .assertThat()
                .statusCode(HttpStatus.SC_OK)
                .body("data.endToEndID", Matchers.startsWith(PREFIX_END_TO_END_ID + ISPB_VALID_LENGTH_8));
    }

    @Test
    void shouldReturnAEndToEndIDWhenBodyIsValidAndLengthIsThree() {
        RestAssured.given()
                .contentType(ContentType.JSON)
                .body(BODY_VALID_LENGTH_3)
                .when().post(BASE_URI)
                .then()
                .assertThat()
                .statusCode(HttpStatus.SC_OK)
                .body("data.endToEndID", Matchers.startsWith(PREFIX_END_TO_END_ID + ISPB_VALID_LENGTH_3_WITH_ZERO));
    }

    @Test
    void shouldReturn400WhenBodyRequestIsEmpty() {
        RestAssured.given()
                .contentType(ContentType.JSON)
                .when().post(BASE_URI)
                .then()
                .assertThat()
                .statusCode(HttpStatus.SC_BAD_REQUEST);
    }

    @Test
    void shouldReturn400WhenLengthIspbIsBiggerThanEight() {
        RestAssured.given()
                .contentType(ContentType.JSON)
                .body(BODY_VALID_LENGTH_12)
                .when().post(BASE_URI)
                .then()
                .assertThat()
                .statusCode(HttpStatus.SC_BAD_REQUEST);
    }

    @Test
    void shouldReturn400WhenIspbIsAlphaNumeric() {
        RestAssured.given()
                .contentType(ContentType.JSON)
                .body(BODY_WITH_ISPB_ALPHA_NUMERIC)
                .when().post(BASE_URI)
                .then()
                .assertThat()
                .statusCode(HttpStatus.SC_BAD_REQUEST);
    }

    @Test
    void shouldReturnInstantPaymentSettlementResponse() {

        InstantPaymentSettlementResponseUIDTO instantPaymentSettlementResponseMock = createInstantPaymentSettlementResponseMock();
        InstantPaymentsUIDTO instantPaymentsUIDTO = createInstantPaymentsUIDTOMock();

        doReturn(instantPaymentSettlementResponseMock)
                .when(spiedPaymentsService).sendPayments(instantPaymentsUIDTO);

        var responseBody = RestAssured.given()
                .contentType(ContentType.JSON)
                .body(instantPaymentsUIDTO)
                .post(BASE_URI_INSTANT_PAYMENTS)
                .getBody()
                .jsonPath().getObject("data", InstantPaymentSettlementResponseUIDTO.class);


        Assertions.assertEquals(instantPaymentSettlementResponseMock.getInstantPayments().get(0).getEndToEndId(), responseBody.getInstantPayments().get(0).getEndToEndId());
        Assertions.assertEquals(instantPaymentSettlementResponseMock.getInstantPayments().get(0).getEventID(), responseBody.getInstantPayments().get(0).getEventID());
    }

    @Test
    void shouldReturn400WhenInterbankSettlementAmountIsZero() {

        InstantPaymentsUIDTO instantPaymentsUIDTO = createInstantPaymentsUIDTOMock();
        instantPaymentsUIDTO.getPayments().get(0).setInterbankSettlementAmount(BigDecimal.ZERO);

        RestAssured.given()
                .contentType(ContentType.JSON)
                .body(instantPaymentsUIDTO)
                .when().post(BASE_URI_INSTANT_PAYMENTS)
                .then()
                .assertThat()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body(containsString("SPI-ME-002"))
                .and()
                .body(containsString("The value of InterbankSettlementAmount must be greater than ZERO"));
    }

    @Test
    void shouldReturn400WhenInterbankSettlementAmountLessThanZero() {

        InstantPaymentsUIDTO instantPaymentsUIDTO = createInstantPaymentsUIDTOMock();
        instantPaymentsUIDTO.getPayments().get(0).setInterbankSettlementAmount(BigDecimal.valueOf(-1998.66));

        RestAssured.given()
                .contentType(ContentType.JSON)
                .body(instantPaymentsUIDTO)
                .when().post(BASE_URI_INSTANT_PAYMENTS)
                .then()
                .assertThat()
                .statusCode(HttpStatus.SC_BAD_REQUEST)
                .body(containsString("SPI-ME-002"))
                .and()
                .body(containsString("The value of InterbankSettlementAmount must be greater than ZERO"));
    }

    @Test
    void shouldReturn400WhenAccountAndBranchThePayerAndReceiverAreTheSame() {
        InstantPaymentsUIDTO instantPaymentsUIDTO = createInstantPaymentsUIDTOMock();
        instantPaymentsUIDTO.getPayments().get(0).setInterbankSettlementAmount(BigDecimal.TEN);

        RestAssured.given()
            .contentType(ContentType.JSON)
            .body(instantPaymentsUIDTO)
            .when().post(BASE_URI_INSTANT_PAYMENTS)
            .then()
            .assertThat()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .body(containsString("SPI-ME-024"))
            .and()
            .body(containsString("The account number and branch from payer and receiver cannot be the same on an internal payment"));
    }

    private static String generateJson(String ispb) {
        return "{\n" + "  \"ispb\": " + ispb + "\n" + "}";
    }


    private InstantPaymentsUIDTO createInstantPaymentsUIDTOMock() {
        InstantPaymentsUIDTO instantPaymentsUIDTO = new InstantPaymentsUIDTO();
        instantPaymentsUIDTO.setCreationDateTime(LocalDateTimeUtils.getUtcLocalDateTime());
        instantPaymentsUIDTO.setInstructionPriority("HIGH");
        instantPaymentsUIDTO.setPayments(createListOfPaymentsUiDTOMock());
        instantPaymentsUIDTO.setSettlementMethod("CLRG");
        return instantPaymentsUIDTO;
    }

    private List<PaymentsUIDTO> createListOfPaymentsUiDTOMock() {
        PaymentsUIDTO paymentsUIDTO = createPaymentsUiDTOMock();

        return List.of(
                paymentsUIDTO
        );
    }

    private PaymentsUIDTO createPaymentsUiDTOMock() {
        PaymentsUIDTO paymentsUIDTO = new PaymentsUIDTO();
        paymentsUIDTO.setAcceptanceDateTime(LocalDateTimeUtils.getUtcLocalDateTime());
        paymentsUIDTO.setChargeBearer("1234");
        paymentsUIDTO.setEndToEndID("END_TO_END_ID");
        paymentsUIDTO.setInterbankSettlementAmount(BigDecimal.valueOf(100));
        paymentsUIDTO.setOrganisationIdentification(TransactionConstants.PAYER_INITIATING_INSTITUTION_TAX_ID);
        paymentsUIDTO.setTransactionIdentification("TRANSACTION_ID");
        paymentsUIDTO.setUnstructured("UNSTRUCTURED");
        paymentsUIDTO.setPayer(createPayerUIDTOMock());
        paymentsUIDTO.setReceiver(createReceiverUIDTOMock());

        return paymentsUIDTO;
    }

    private PayerUIDTO createPayerUIDTOMock() {
        PayerUIDTO payerUIDTO = new PayerUIDTO();
        payerUIDTO.setInstitutionISPB(13370835);
        payerUIDTO.setName("João da Silva");
        payerUIDTO.setTaxId("78882904008");
        payerUIDTO.setAccount(createRemoteAccountUIDTOMock());

        return payerUIDTO;
    }

    private ReceiverUIDTO createReceiverUIDTOMock() {
        ReceiverUIDTO receiverUIDTO = new ReceiverUIDTO();
        receiverUIDTO.setAddressingKey("ADDRESSING_KEY");
        receiverUIDTO.setInstitutionISPB(13370835);
        receiverUIDTO.setTaxId("41654566000114");
        receiverUIDTO.setAccount(createRemoteAccountUIDTOMock());

        return receiverUIDTO;
    }

    private RemoteAccountUIDTO createRemoteAccountUIDTOMock() {
        RemoteAccountUIDTO remoteAccountUIDTO = new RemoteAccountUIDTO();
        remoteAccountUIDTO.setAccountNumber("11111111111111111111");
        remoteAccountUIDTO.setBranch("2486");
        remoteAccountUIDTO.setAccountType(AccountTypeUIDTO.CACC);

        return remoteAccountUIDTO;
    }

    private InstantPaymentSettlementResponseUIDTO createInstantPaymentSettlementResponseMock() {

        InstantPaymentsResponseDTO instantPaymentsResponseDTO = new InstantPaymentsResponseDTO();
        instantPaymentsResponseDTO.setEndToEndId(END_TO_END_ID);
        instantPaymentsResponseDTO.setEventID(EVENT_ID);

        InstantPaymentSettlementResponseUIDTO instantPaymentSettlementResponseUIDTO = new InstantPaymentSettlementResponseUIDTO();
        instantPaymentSettlementResponseUIDTO.setInstantPayments(List.of(instantPaymentsResponseDTO));

        return instantPaymentSettlementResponseUIDTO;
    }

}
