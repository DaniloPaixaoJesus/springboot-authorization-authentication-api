package matera.spi.main.domain.service.util;

import matera.spi.main.domain.model.BalanceAccountPiEntity;
import matera.spi.main.persistence.BalanceAccountPiRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

import static matera.spi.main.domain.model.enums.EnumTransactionType.CREDIT;
import static matera.spi.main.domain.model.enums.EnumTransactionType.DEBIT;

@Component
public class BalanceIPAccountUtil {

    @Autowired
    private BalanceAccountPiRepository repository;

    public BalanceAccountPiEntity insertOneDebit(BigDecimal insertValue) {
        final BalanceAccountPiEntity lastInsert = getLastValidInsertOrNewOne();
        final BalanceAccountPiEntity entity = new BalanceAccountPiEntity();

        entity.setValue(insertValue);
        entity.setBalance(lastInsert.getBalance().subtract(insertValue));
        entity.setTransactionType(DEBIT);
        return repository.save(entity);
    }

    public BalanceAccountPiEntity insertOneCredit(BigDecimal insertValue) {
        final BalanceAccountPiEntity lastInsert = getLastValidInsertOrNewOne();
        final BalanceAccountPiEntity entity = new BalanceAccountPiEntity();

        entity.setValue(insertValue);
        entity.setBalance(lastInsert.getBalance().add(insertValue));
        entity.setTransactionType(CREDIT);
        return repository.save(entity);
    }

    private BalanceAccountPiEntity getLastValidInsertOrNewOne() {
        BalanceAccountPiEntity lastInsert = repository.findFirstByOrderByIdDesc();

        if (lastInsert == null) {
            lastInsert = new BalanceAccountPiEntity();
            lastInsert.setBalance(BigDecimal.ZERO);
            lastInsert.setValue(BigDecimal.ZERO);
            lastInsert.setTransactionType(CREDIT);
            repository.save(lastInsert);
        }

        return lastInsert;
    }

}
