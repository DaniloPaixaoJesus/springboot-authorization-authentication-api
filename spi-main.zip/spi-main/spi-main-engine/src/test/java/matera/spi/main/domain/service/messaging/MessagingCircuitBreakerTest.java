
package matera.spi.main.domain.service.messaging;

import com.matera.commons.rest.dto.MateraRestReturnDTO;
import com.matera.spi.messaging.api.MessagesApi;
import com.matera.spi.messaging.api.SPIMessagingApis;
import com.matera.spi.messaging.model.MessageSentResponseDTO;
import com.matera.spi.thirdparties.customers.transactions.model.LancamentoResponseV2DTO;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.InstantPaymentSettlementResponseUIDTO;
import matera.spi.dto.InstantPaymentsUIDTO;
import matera.spi.main.application.service.PaymentsHelper;
import matera.spi.main.application.service.ReturnApplicationService;
import matera.spi.main.domain.service.MessageSender;
import matera.spi.main.domain.service.config.MessagingCircuitBreakerConfig;
import matera.spi.main.domain.service.transaction.AccountTransaction;
import matera.spi.main.dto.AccountTransactionRequestDTO;
import matera.spi.main.dto.AccountTransactionResponseDTO;
import matera.spi.main.dto.AccountTransactionValidationRequestDTO;
import matera.spi.main.dto.QueryBalanceRequestDTO;
import matera.spi.main.dto.QueryBalanceResponseDTO;
import matera.spi.main.exception.MessagingUnavailableException;
import matera.spi.main.transactions.port.AccountTransactionExecutorPort;
import matera.spi.main.utils.RetryFailedTestsRule;

import lombok.extern.slf4j.Slf4j;
import org.junit.Rule;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.time.LocalDate;

import javax.transaction.Transactional;

import static matera.spi.main.rest.ui.PaymentsTestHelper.createValidInstantPaymentsUIDTO;

import static com.matera.spi.thirdparties.customers.transactions.model.LancamentoResponseV2DTO.ClassificacaoCategoriaContaSPIEnum.CACC;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.awaitility.Awaitility.await;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@Slf4j
@IntegrationTest
@Transactional
public class MessagingCircuitBreakerTest  {

    private static final String BASE_URI_INSTANT_PAYMENTS = "/ui/v1/instant-payments";
    private static final String ADDRESSING_KEY = "ADDRESSING_KEY";
    public static final int NUMBER_OF_RETRIES = 10;

    @Rule
    private RetryFailedTestsRule retryFailedTestsRule = new RetryFailedTestsRule(NUMBER_OF_RETRIES);

    @Autowired
    private AccountTransaction accountTransaction;
    @Mock
    private AccountTransactionExecutorPort mockedAccountTransactionExecutorPort;
    @Autowired
    private AccountTransactionExecutorPort accountTransactionExecutorPort;

    @Autowired
    private MessagingCircuitBreakerConfig messagingCircuitBreakerConfig;

    @Autowired
    private PaymentsHelper paymentsHelper;

    @Autowired
    private ReturnApplicationService returnApplicationService;

    @Autowired
    private MessagingAvailabilityChecker messagingAvailabilityChecker;

    @Spy
    private MessagingAvailabilityChecker spiedMessagingAvailabilityChecker;

    @Autowired
    private MessageSender messageSender;
    @Autowired
    private SPIMessagingApis spiMessagingApisBean;
    @Mock
    private SPIMessagingApis mockedSpiMessagingApis;
    @Mock
    private MessagesApi mockedMessagesApi;

    @LocalServerPort
    private int port;

    @BeforeEach
    public void setupAccountTransactionExecutorPort() {

        messagingCircuitBreakerConfig.getCircuitBreaker().transitionToClosedState();

        LancamentoResponseV2DTO lancamentoResponseV2DTO = new LancamentoResponseV2DTO();

        lancamentoResponseV2DTO.setClassificacaoCategoriaContaSPI(CACC);
        lancamentoResponseV2DTO.setCpfCnpjTitular(BigDecimal.valueOf(92082843521L));

        accountTransaction.setAccountTransactionExecutorPort(mockedAccountTransactionExecutorPort);
        when(mockedAccountTransactionExecutorPort.makeTransaction(any(AccountTransactionRequestDTO.class))).thenAnswer(
            (Answer<AccountTransactionResponseDTO>) invocation -> AccountTransactionResponseDTO.builder()
                .transactionId(BigDecimal.valueOf(1L))
                .lancamentoResponseV2DTO(lancamentoResponseV2DTO)
                .build());

        when(mockedAccountTransactionExecutorPort.validateCredit(any(AccountTransactionValidationRequestDTO.class)))
            .thenReturn(false);

        when(mockedAccountTransactionExecutorPort.queryBalance(any(QueryBalanceRequestDTO.class))).thenAnswer(
            (Answer<QueryBalanceResponseDTO>) invocation -> QueryBalanceResponseDTO.builder()
                .balanceAvailable(BigDecimal.valueOf(1234546789L))
                .accountingBalance(BigDecimal.valueOf(1234546L))
                .blockedBalance(BigDecimal.valueOf(123454L))
                .accountingBalance(BigDecimal.valueOf(12345L))
                .creditLimitAvailable(BigDecimal.valueOf(1234546789L))
                .date(LocalDate.now())
                .build());

        when(mockedMessagesApi.sendsMessageV1(any())).thenThrow(MessagingUnavailableException.class);
        when(mockedSpiMessagingApis.messagesApi()).thenReturn(mockedMessagesApi);
        messageSender.setSpiMessagingApis(mockedSpiMessagingApis);
        spiedMessagingAvailabilityChecker.setMessagingCircuitBreakerConfig(messagingCircuitBreakerConfig);
        paymentsHelper.setMessagingAvailabilityChecker(spiedMessagingAvailabilityChecker);
        ReflectionTestUtils.setField(returnApplicationService,"messagingAvailabilityChecker",spiedMessagingAvailabilityChecker);
    }

    @AfterEach
    void tearDown() {
        accountTransaction.setAccountTransactionExecutorPort(accountTransactionExecutorPort);
        messageSender.setSpiMessagingApis(spiMessagingApisBean);
        paymentsHelper.setMessagingAvailabilityChecker(messagingAvailabilityChecker);
        ReflectionTestUtils.setField(returnApplicationService,"messagingAvailabilityChecker",messagingAvailabilityChecker);
        messagingCircuitBreakerConfig.getCircuitBreaker().transitionToClosedState();

        await().until(() -> messagingAvailabilityChecker.isCircuitClosed());
    }

    @Test
    void shouldReturnHttpStatusCode503AndOpenCircuitWhenMessagingUnavailableExceptionIsThrow() throws Exception {

        InstantPaymentsUIDTO instantPaymentsUIDTO = createValidInstantPaymentsUIDTO(ADDRESSING_KEY);

        assertThatThrownBy(() -> invokeEndpoint(instantPaymentsUIDTO))
            .hasMessage("503 Service Unavailable");

        assertThat(spiedMessagingAvailabilityChecker.isCircuitClosed()).isFalse();

        verify(spiedMessagingAvailabilityChecker, atLeast(1)).checkMessagingAvailability();

        verify(mockedMessagesApi, atLeast(3)).sendsMessageV1(any());
    }

    @Test
    void shouldReturnHttpStatusCode503WhileCircuitIsBroken() throws Exception {

        messagingCircuitBreakerConfig.getCircuitBreaker().transitionToOpenState();

        InstantPaymentsUIDTO instantPaymentsUIDTO = createValidInstantPaymentsUIDTO(ADDRESSING_KEY);

        assertThatThrownBy(() -> invokeEndpoint(instantPaymentsUIDTO))
            .hasMessage("503 Service Unavailable");

        verify(spiedMessagingAvailabilityChecker, times(1)).checkMessagingAvailability();

        verify(mockedMessagesApi, times(0)).sendsMessageV1(any());
    }

    @Test
    void shouldCloseTheCircuitAfterConfiguredTime() throws Exception {

        messagingCircuitBreakerConfig.getCircuitBreaker().transitionToOpenState();

        await().untilAsserted(() -> assertThat(spiedMessagingAvailabilityChecker.isCircuitClosed()).isTrue());
    }

    @Test
    void shouldAllowNewExecutionAfterConfiguredTime() throws Exception {

        messagingCircuitBreakerConfig.getCircuitBreaker().transitionToOpenState();

        await().untilAsserted(() -> assertThat(spiedMessagingAvailabilityChecker.isCircuitClosed()).isTrue());

        InstantPaymentsUIDTO instantPaymentsUIDTO = createValidInstantPaymentsUIDTO(ADDRESSING_KEY);

        assertThatThrownBy(() -> invokeEndpoint(instantPaymentsUIDTO))
            .hasMessage("503 Service Unavailable");

        verify(spiedMessagingAvailabilityChecker, times(1)).checkMessagingAvailability();

        verify(mockedMessagesApi, atLeast(3)).sendsMessageV1(any());
    }

    private void invokeEndpoint(InstantPaymentsUIDTO instantPaymentsUIDTO) {
        RestTemplate restTemplate = new RestTemplate();
        HttpEntity<InstantPaymentsUIDTO> request = new HttpEntity<>(instantPaymentsUIDTO);
        String url = "http://localhost:" + port + BASE_URI_INSTANT_PAYMENTS;
        MateraRestReturnDTO<InstantPaymentSettlementResponseUIDTO> responseUIDTOMateraRestReturnDTO =
                restTemplate.postForObject(url, request, MateraRestReturnDTO.class);
    }

    private MessageSentResponseDTO getResponseSentDTO() {
        MessageSentResponseDTO messageSentResponseDTO = new MessageSentResponseDTO();
        messageSentResponseDTO.setPiResourceID("SentPiResourceID");
        return messageSentResponseDTO;
    }
}
