package matera.spi.main.domain.service.internal;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.BalanceAccountPiEntity;
import matera.spi.main.persistence.BalanceAccountPiRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;

import static matera.spi.main.domain.model.enums.EnumTransactionType.CREDIT;
import static matera.spi.main.domain.model.enums.EnumTransactionType.DEBIT;

import static org.assertj.core.api.Assertions.assertThat;

@IntegrationTest
class InternalClearingAccountServiceTest  {

	private static BigDecimal THOUSAND = BigDecimal.valueOf(1000);
	private static int ZERO = 0;
	@Autowired
	private InternalClearingAccountService service;
	@Autowired
	private BalanceAccountPiRepository repository;

	@BeforeEach
	void beforeEach() {
		forcesThousandToLastBalance();
	}

	@Test
	@DisplayName("when calling getCurrentBalance() should return the last transaction balance")
	void shouldReturnTheLastTransactionBalanceWhenCallingServiceGetCurrentBalance() {
		assertThat(THOUSAND.compareTo(service.getCurrentBalance())).isEqualTo(ZERO);
	}

	@Test
	@DisplayName("when calling createCreditTransaction() should create a credit transaction")
	void shouldCreateACreditTransactionWhenCallingCreateCreditTransaction() {
		BigDecimal creditValue = BigDecimal.valueOf(1324.56);
		BigDecimal creditTransactionId = service.createCreditTransaction(creditValue);
		BalanceAccountPiEntity entity = service.getTransaction(creditTransactionId.intValue()).get();
		assertThat(entity.getBalance()).isEqualTo(THOUSAND.add(creditValue));
		assertThat(BigDecimal.valueOf(entity.getId())).isEqualTo(creditTransactionId);
		assertThat(entity.getValue()).isEqualTo(creditValue);
		assertThat(entity.getTransactionType()).isEqualTo(CREDIT);
	}

	@Test
	@DisplayName("when calling createDebitTransaction() should create a debit transaction")
	void shouldCreateADebitTransactionWhenCallingCreateDebitTransaction() {
		BigDecimal debitValue = BigDecimal.valueOf(999.99);
		BigDecimal debitTransactionId = service.createDebitTransaction(debitValue);
		BalanceAccountPiEntity entity = service.getTransaction(debitTransactionId.intValue()).get();
		assertThat(entity.getBalance()).isEqualTo(THOUSAND.subtract(debitValue));
		assertThat(BigDecimal.valueOf(entity.getId())).isEqualTo(debitTransactionId);
		assertThat(entity.getValue()).isEqualTo(debitValue);
		assertThat(entity.getTransactionType()).isEqualTo(DEBIT);
	}

	@Test
	@DisplayName("when calling getTransaction() with an existing transactionId should return the corresponding transaction")
	void shouldReturnTheCorrespondingTransactionWhenCallGetTransactionWithSomeId() {
		BigDecimal transactionId = service.createCreditTransaction(BigDecimal.TEN);
		BalanceAccountPiEntity lastTransaction = service.getTransaction(transactionId.intValue()).get();
		assertThat(transactionId).isEqualTo(BigDecimal.valueOf(lastTransaction.getId()));
	}

	@Test
	@DisplayName("when calling getTransaction() with a non existing transactionId should not return a transaction")
	void shouldReturnAnOptionalNullWhenCallingGetTransactionWithAnIdThatNotExists() {
		boolean transactionIsPresent = service.getTransaction(Integer.MAX_VALUE).isPresent();
		assertThat(transactionIsPresent).isFalse();
	}

	/**
	 * forces to the last balance be a thousand
	 */
	private void forcesThousandToLastBalance() {
		BalanceAccountPiEntity entity = new BalanceAccountPiEntity();
		entity.setBalance(THOUSAND);
		entity.setValue(THOUSAND);
		entity.setTransactionType(CREDIT);
		repository.saveAndFlush(entity);
	}
}
