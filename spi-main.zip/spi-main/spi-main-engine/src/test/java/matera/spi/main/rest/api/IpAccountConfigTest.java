package matera.spi.main.rest.api;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.json.JsonMapper;
import io.restassured.RestAssured;
import lombok.extern.slf4j.Slf4j;
import matera.spi.commons.IntegrationTest;
import matera.spi.dto.IpAccountConfigResponseDTO;
import matera.spi.dto.IpAccountConfigResponseWrapperDTO;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.server.LocalServerPort;

import javax.transaction.Transactional;
import java.math.BigDecimal;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

@Slf4j
@IntegrationTest
@Transactional
public class IpAccountConfigTest {

    private static final String BASE_URI_INSTANT_PAYMENTS = "/api/v1/ip-account/";
    public static final String SERVER = "http://localhost:";

    @LocalServerPort
    private int PORT;

    @Value("${spring.liquibase.parameters.me-ip-account-config.account-number}")
    private String accountNumber;
    @Value("${spring.liquibase.parameters.me-ip-account-config.branch}")
    private Long branch;
    @Value("${spring.liquibase.parameters.me-ip-account-config.debit-transaction-type}")
    private Long debitTransactionType;
    @Value("${spring.liquibase.parameters.me-ip-account-config.credit-transaction-type}")
    private Long creditTransactionType;
    @Value("${spring.liquibase.parameters.me-ip-account-config.balance-validation-threshold}")
    private boolean balanceValidationThreshold;
    @Value("${spring.liquibase.parameters.me-ip-account-config.balance-lower-threshold:2000000000.00}")
    private BigDecimal balanceLowerThreshold;
    @Value("${spring.liquibase.parameters.me-ip-account-config.balance-lower-threshold-perc:0.25}")
    private BigDecimal balanceLowerThresholdPercent;
    @Value("${spring.liquibase.parameters.me-ip-account-config.deposit-transaction-type}")
    private Long depositTransactionType;
    @Value("${spring.liquibase.parameters.me-ip-account-config.withdraw-transaction-type}")
    private Long withdrawTransactionType;
    @Value("${spring.liquibase.parameters.me-ip-account-config.qrcode-cred-transaction-type}")
    private Long qrcodeCredTransactionType;

    private JsonMapper mapper = new JsonMapper();

    @Test
    void shouldGetIpAccountConfig() {
        String url = SERVER + PORT + BASE_URI_INSTANT_PAYMENTS;
        IpAccountConfigResponseDTO ipAccountConfigResponseDTO =
            RestAssured.given().log().all().when().header("pageSize", 5).header("pageNumber", 0).get(url).getBody()
                .as(IpAccountConfigResponseWrapperDTO.class)
                .getData();

        assertThat(ipAccountConfigResponseDTO.getAccountNumber(), is(accountNumber));
        assertThat(ipAccountConfigResponseDTO.getBranch(), is(branch));
        assertThat(ipAccountConfigResponseDTO.getDebitTransactionType(), is(debitTransactionType));
        assertThat(ipAccountConfigResponseDTO.getCreditTransactionType(), is(creditTransactionType));
        assertThat(ipAccountConfigResponseDTO.getBalanceLowerThresholdPercent(), is(balanceLowerThresholdPercent));
        assertThat(ipAccountConfigResponseDTO.getQrcodeCredTransactionType(), is(qrcodeCredTransactionType));
        assertThat(ipAccountConfigResponseDTO.getDepositTransactionType(), is(depositTransactionType));
        assertThat(ipAccountConfigResponseDTO.getWithdrawTransactionType(), is(withdrawTransactionType));
    }

}
