package matera.spi.lm.application.services.validation;

import matera.spi.lm.application.service.validation.BigDecimalValidation.BigDecimalValidator;
import matera.spi.lm.exception.LiquidityManagementException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import java.math.BigDecimal;

public class BigDecimalValidatorTest {

    @Spy
    private BigDecimalValidator bigDecimalValidator;

    @BeforeEach
    void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void shouldThrowExceptionIfMinValueIsGreaterThanMaxValue() {
        final BigDecimal minValue = BigDecimal.TEN;
        final BigDecimal maxValue = BigDecimal.ONE;

        Assertions.assertThrows(LiquidityManagementException.class, () -> bigDecimalValidator.validateRangeValues(minValue, maxValue));
    }

}
