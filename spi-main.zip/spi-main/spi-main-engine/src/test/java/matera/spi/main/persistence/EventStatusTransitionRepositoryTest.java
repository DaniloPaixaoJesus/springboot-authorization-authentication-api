package matera.spi.main.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventStatusTransitionEntity;
import matera.spi.main.domain.model.event.transaction.PaymentEventEntity;
import matera.spi.utils.LocalDateTimeUtils;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Commit;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneOffset;

@IntegrationTest
@Transactional
@Commit
class EventStatusTransitionRepositoryTest  {

    @Autowired
    private EventStatusTransitionRepository repository;

    @Autowired
    private EventStatusRepository eventStatusRepository;

    @Autowired
    private EventRepository eventRepository;

    @Autowired
    private EventTypeRepository eventTypeRepository;

    @Test
    void shouldBeFindEntityWhenInserted() {
        EventStatusTransitionEntity expected = new EventStatusTransitionEntity();
        expected.setEventStatusCode(eventStatusRepository.findById(1).get());
        expected.setEvent(buildEventEntity());
        expected.setResponsible("Responsible of transition");
        expected.setTimestamp(LocalDateTime.now(ZoneOffset.UTC));

        repository.saveAndFlush(expected);

        EventStatusTransitionEntity actual = repository.findById(expected.getUuid()).orElse(null);
        Assertions.assertEquals(expected.getUuid(), actual.getUuid());
        Assertions.assertEquals(expected.getEvent(), actual.getEvent());
        Assertions.assertEquals(expected.getEventStatusCode(), actual.getEventStatusCode());
        Assertions.assertEquals(expected.getResponsible(), actual.getResponsible());
    }

    private EventEntity buildEventEntity() {
        PaymentEventEntity entity = new PaymentEventEntity();
        entity.setInitiationTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
        entity.setResponsible("ResponsibleOfEvent");
        entity.setInitiatorIspb(12345678);
        entity.setStatus(eventStatusRepository.findById(1).get());
        entity.setClearingTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
        entity.setValue(new BigDecimal("123.45"));

        eventRepository.saveAndFlush(entity);
        return entity;

    }
}
