package matera.spi.main.domain.service.util;

import matera.spi.utils.DocumentUtils;

import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;

import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;

import static org.assertj.core.api.Assertions.assertThat;

class MessageBinderXpathReda041UtilsTest {

	private static final String REDA_041_REDA_041_SPI_1_0 = "reda.041/reda.041.spi.1.0_msg.xml";

    private static final String MSGID = "M0003816612345678901234567890123";
    private static final String CREDTTM = "2020-01-01T08:30:12.000Z";

	private static final String PRTRY_ID = "55555555";
    private static final String PRTRYID_ISSR = "BCB";

    private String NM_OD_NM = "Pagamentos Instantâneos S/A";
    private String NM_NEW_NM = "PIX S/A";


	@Test
	void shouldGetReda041Data() {
	    Document document = DocumentUtils.stringToXmlDocument(getXml());

        String msgId = MessageBinderXpathReda041Utils.getMsgghdrId(document);
        String creDtTm = MessageBinderXpathReda041Utils.getMsgghdrCreDtTm(document);

		String prtryId = MessageBinderXpathReda041Utils.getPrtryId(document);
        String prtryIssr = MessageBinderXpathReda041Utils.getPrtryIssr(document);

        String odNm = MessageBinderXpathReda041Utils.getOdNm(document);
        String newNm = MessageBinderXpathReda041Utils.getNewNm(document);

        assertThat(msgId).isEqualTo(MSGID);
        assertThat(creDtTm).isEqualTo(CREDTTM);

		assertThat(prtryId).isEqualTo(PRTRY_ID);
        assertThat(prtryIssr).isEqualTo(PRTRYID_ISSR);

        assertThat(odNm).isEqualTo(NM_OD_NM);
        assertThat(newNm).isEqualTo(NM_NEW_NM);
	}


	private String getXml() {
		return getStringFromXmlFile(REDA_041_REDA_041_SPI_1_0);
	}
}
