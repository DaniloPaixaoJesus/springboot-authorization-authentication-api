package matera.spi.main.transactions.adapter.account;

import com.matera.spi.thirdparties.customers.transactions.api.LancamentosApi;
import com.matera.spi.thirdparties.customers.transactions.api.SPICustomersTransactionContractApis;
import com.matera.spi.thirdparties.customers.transactions.api.SaldosApi;
import com.matera.spi.thirdparties.customers.transactions.model.EspecificacaoLancamentosRequestV2DTO;
import com.matera.spi.thirdparties.customers.transactions.model.EspecificacaoLancamentosValidacaoRequestV1DTO;
import com.matera.spi.thirdparties.customers.transactions.model.LancamentoResponseV2DTO;
import com.matera.spi.thirdparties.customers.transactions.model.LancamentoV2DTO;
import com.matera.spi.thirdparties.customers.transactions.model.SaldoResponseDTO;

import matera.spi.main.dto.AccountTransactionRequestDTO;
import matera.spi.main.dto.AccountTransactionResponseDTO;
import matera.spi.main.dto.AccountTransactionValidationRequestDTO;
import matera.spi.main.dto.LocalBookTransferRequestDTO;
import matera.spi.main.dto.LocalBookTransferTransactionInfoDTO;
import matera.spi.main.dto.QueryBalanceRequestDTO;
import matera.spi.main.dto.QueryBalanceResponseDTO;
import matera.spi.main.transactions.port.exception.PortException;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Random;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AccountTransactionExecutorAdapterTest {

    private static final String IDEMPOTENCE_ID = "IDEMPOTENCY_ID";
    private static final Random RANDOM = new Random();
    private static final int DEBIT_BRANCH = RANDOM.nextInt();
    private static final long DEBIT_ACCOUNT = RANDOM.nextLong();
    private static final BigDecimal DEBIT_ACCOUNT_BIG_DECIMAL = BigDecimal.valueOf(DEBIT_ACCOUNT);
    private static final int CREDIT_BRANCH = RANDOM.nextInt();
    private static final long CREDIT_ACCOUNT = RANDOM.nextLong();
    private static final BigDecimal CREDIT_ACCOUNT_BIG_DECIMAL = BigDecimal.valueOf(CREDIT_ACCOUNT);
    private static final BigDecimal ENTRY_BATCH = BigDecimal.valueOf(RANDOM.nextLong());
    private static final BigDecimal TRANSFER_ID = BigDecimal.valueOf(RANDOM.nextLong());
    private static final BigDecimal CREDIT_ENTRY_ID = BigDecimal.valueOf(RANDOM.nextLong());
    private static final BigDecimal DEBIT_ENTRY_ID = BigDecimal.valueOf(RANDOM.nextLong());
    private static final BigDecimal BALANCE_AVAILABLE = BigDecimal.valueOf(RANDOM.nextLong());
    private static final BigDecimal LINKED_BALANCE = BigDecimal.valueOf(RANDOM.nextLong());
    private static final BigDecimal BLOCKED_BALANCE = BigDecimal.valueOf(RANDOM.nextLong());
    private static final BigDecimal ACCOUNTING_BALANCE = BigDecimal.valueOf(RANDOM.nextLong());
    private static final BigDecimal CREDIT_LIMIT_AVAILABLE = BigDecimal.valueOf(RANDOM.nextLong());
    private static final String END_TO_END_ID = "E0057376820200217082881978247550";
    private static final int CREDIT_TRANSACTION_TYPE = 1;
    private static final int DEBIT_TRANSACTION_TYPE = 2;
    private static final boolean INCLUDE_LIMIT = true;
    private static final boolean D_MINUS_ONE = false;
    public static final String ERROR_MESSAGE = "Error during the transaction. Check if the Standin's url is the right one and if it is accessible.";
    public static final String ERROR_MESSAGE_NULL_RESPONSE = ERROR_MESSAGE + " The Standin API returned a NULL response.";


    @InjectMocks
    AccountTransactionExecutorAdapter accountTransactionExecutorAdapter;

    @Mock
    SPICustomersTransactionContractApis spiCustomersTransactionContractApis;

    @Mock
    LancamentosApi lancamentosApi;

    @Mock
    SaldosApi saldosApi;

    @Test
    void makeTransaction() {
        when(spiCustomersTransactionContractApis.lancamentosApi()).thenReturn(lancamentosApi);
        when(lancamentosApi.criarLancamentosParaUmaContaV2(eq(IDEMPOTENCE_ID), eq(DEBIT_BRANCH), eq(DEBIT_ACCOUNT),
            any(EspecificacaoLancamentosRequestV2DTO.class))).thenReturn(buildEntryResponseStub());
        AccountTransactionResponseDTO accountTransactionResponseDTO =
            accountTransactionExecutorAdapter.makeTransaction(buildAccountsTransactionDTO());

        verify(lancamentosApi).criarLancamentosParaUmaContaV2(eq(IDEMPOTENCE_ID), eq(DEBIT_BRANCH), eq(DEBIT_ACCOUNT),
            any(EspecificacaoLancamentosRequestV2DTO.class));
        assertThat(accountTransactionResponseDTO.getTransactionId()).isEqualTo(BigDecimal.ONE);
    }

    @Test
    void queryBalance() {
        when(spiCustomersTransactionContractApis.saldosApi()).thenReturn(saldosApi);
        when(saldosApi.apiV2ContasAgenciaContaSaldosGet(eq(CREDIT_BRANCH), eq(CREDIT_ACCOUNT), eq(INCLUDE_LIMIT), eq(D_MINUS_ONE)))
            .thenReturn(buildSaldoResponseDTO());
        QueryBalanceResponseDTO queryBalanceResponseDTO =
            accountTransactionExecutorAdapter.queryBalance(buildQueryBalanceRequestDTO());

        verify(saldosApi).apiV2ContasAgenciaContaSaldosGet(eq(CREDIT_BRANCH), eq(CREDIT_ACCOUNT), eq(INCLUDE_LIMIT), eq(D_MINUS_ONE));
        assertThat(queryBalanceResponseDTO.getDate()).isToday();
        assertThat(queryBalanceResponseDTO.getBalanceAvailable()).isEqualTo(BALANCE_AVAILABLE);
        assertThat(queryBalanceResponseDTO.getLinkedBalance()).isEqualTo(LINKED_BALANCE);
        assertThat(queryBalanceResponseDTO.getBlockedBalance()).isEqualTo(BLOCKED_BALANCE);
        assertThat(queryBalanceResponseDTO.getAccountingBalance()).isEqualTo(ACCOUNTING_BALANCE);
        assertThat(queryBalanceResponseDTO.getCreditLimitAvailable()).isEqualTo(CREDIT_LIMIT_AVAILABLE);

    }

    @Test
    void validCredit() {
        when(spiCustomersTransactionContractApis.lancamentosApi()).thenReturn(lancamentosApi);
        boolean isValid = accountTransactionExecutorAdapter.validateCredit(buildAccountTransactionValidationDTO());

        verify(lancamentosApi).validarLancamento(eq(DEBIT_BRANCH), eq(DEBIT_ACCOUNT), any(EspecificacaoLancamentosValidacaoRequestV1DTO.class));
        assertThat(isValid).isTrue();
    }

    @Test
    void shouldThrowEventErrorWhenResponseIsNull() {
        when(spiCustomersTransactionContractApis.lancamentosApi()).thenReturn(lancamentosApi);
        LancamentoResponseV2DTO lancamentoResponseV2DTO = null;

        when(lancamentosApi.criarLancamentosParaUmaContaV2(eq(IDEMPOTENCE_ID), eq(DEBIT_BRANCH), eq(DEBIT_ACCOUNT),
            any(EspecificacaoLancamentosRequestV2DTO.class))).thenReturn(lancamentoResponseV2DTO);

        assertThatThrownBy(() -> accountTransactionExecutorAdapter.makeTransaction(buildAccountsTransactionDTO()))
            .isInstanceOf(PortException.class)
            .hasMessage(ERROR_MESSAGE_NULL_RESPONSE);
    }

    private static AccountTransactionRequestDTO buildAccountsTransactionDTO() {
        return AccountTransactionRequestDTO.builder()
            .idempotenceId(IDEMPOTENCE_ID)
            .branch(DEBIT_BRANCH)
            .account(DEBIT_ACCOUNT_BIG_DECIMAL)
            .transactionType(DEBIT_TRANSACTION_TYPE)
            .groupEntries(false)
            .validateBalance(true)
            .endToEndId(END_TO_END_ID)
            .eventId(UUID.randomUUID())
            .value(BigDecimal.TEN)
            .build();
    }

    private static LancamentoResponseV2DTO buildEntryResponseStub() {
        return new LancamentoResponseV2DTO().addLancamentosItem(new LancamentoV2DTO().idLancamento(BigDecimal.ONE));
    }

    private static LocalBookTransferRequestDTO buildTransferRequestDTO(){
        return LocalBookTransferRequestDTO.builder()
            .idempotencyId(IDEMPOTENCE_ID)
            .eventId(UUID.randomUUID())
            .validateBalance(false)
            .creditData(
                LocalBookTransferTransactionInfoDTO.builder()
                    .branch(CREDIT_BRANCH)
                    .account(CREDIT_ACCOUNT_BIG_DECIMAL)
                    .endToEndId(END_TO_END_ID)
                    .operationComplement(" some string")
                    .transactionType(CREDIT_TRANSACTION_TYPE)
                .build()
            )
            .debitData(
                LocalBookTransferTransactionInfoDTO.builder()
                    .branch(DEBIT_BRANCH)
                    .account(DEBIT_ACCOUNT_BIG_DECIMAL)
                    .endToEndId(END_TO_END_ID)
                    .operationComplement(" other string")
                    .transactionType(DEBIT_TRANSACTION_TYPE)
                    .build()
            )
            .value(BigDecimal.TEN)
            .build();
    }

    private static AccountTransactionValidationRequestDTO buildAccountTransactionValidationDTO() {
        return AccountTransactionValidationRequestDTO.builder()
            .branch(DEBIT_BRANCH)
            .account(DEBIT_ACCOUNT_BIG_DECIMAL)
            .transactionType(DEBIT_TRANSACTION_TYPE)
            .validateBalance(true)
            .eventId(UUID.randomUUID())
            .value(BigDecimal.TEN)
            .build();
    }

    private static QueryBalanceRequestDTO buildQueryBalanceRequestDTO() {
        return QueryBalanceRequestDTO.builder()
            .branch(CREDIT_BRANCH)
            .account(CREDIT_ACCOUNT_BIG_DECIMAL)
            .includeLimit(INCLUDE_LIMIT)
            .dMinusOne(D_MINUS_ONE)
            .build();
    }

    private static SaldoResponseDTO buildSaldoResponseDTO() {
        return new SaldoResponseDTO()
            .data(LocalDate.now())
            .saldoDisponivel(BALANCE_AVAILABLE)
            .saldoVinculado(LINKED_BALANCE)
            .saldoBloqueado(BLOCKED_BALANCE)
            .saldoContabil(ACCOUNTING_BALANCE)
            .limiteCreditoDisponivel(CREDIT_LIMIT_AVAILABLE);

    }

}
