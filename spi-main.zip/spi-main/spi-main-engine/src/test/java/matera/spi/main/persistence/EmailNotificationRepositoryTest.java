package matera.spi.main.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.EmailNotificationEntity;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;
import java.util.UUID;

@IntegrationTest
class EmailNotificationRepositoryTest {

    private static final String NEW_NAME_IDENTIFICATION = "new name identification";
    private static final String NEW_EMAIL_ADDRESS = "newemail@email.com";

    private static final String EMAIL_ADDRESS = "email@email.com";
    private static final String NAME_IDENTIFICATION = "name identification";

    @Autowired
    private EmailNotificationRepository emailNotificationRepository;

    @BeforeEach
    void beforeEach() {
        emailNotificationRepository.deleteAll();
    }

    @AfterEach
    void afterEach() {
        emailNotificationRepository.deleteAll();
    }

    @Test
    void shouldBeUpdateEntityAfterInserted() {
        EmailNotificationEntity expected = new EmailNotificationEntity();
        expected.setEmail(EMAIL_ADDRESS);
        expected.setIdentification(NAME_IDENTIFICATION);
        expected.setDateTimeRegister(LocalDateTime.now());
        emailNotificationRepository.saveAndFlush(expected);


        EmailNotificationEntity updated = emailNotificationRepository
            .findById(expected.getUuid())
            .orElse(null);

        updated.setEmail(NEW_EMAIL_ADDRESS);
        updated.setIdentification(NEW_NAME_IDENTIFICATION);
        emailNotificationRepository.saveAndFlush(updated);

        EmailNotificationEntity actual = emailNotificationRepository
            .findById(expected.getUuid())
            .orElse(null);

        Assertions.assertNotEquals(expected, actual);
        Assertions.assertEquals(expected.getUuid(), actual.getUuid());
        Assertions.assertEquals(NEW_NAME_IDENTIFICATION, actual.getIdentification());
        Assertions.assertEquals(NEW_EMAIL_ADDRESS, actual.getEmail());

    }

    @Test
    void shouldBeFindEntityWhenInserted() {
        EmailNotificationEntity expected = new EmailNotificationEntity();
        expected.setEmail(EMAIL_ADDRESS);
        expected.setIdentification(NAME_IDENTIFICATION);
        expected.setDateTimeRegister(LocalDateTime.now());
        emailNotificationRepository.saveAndFlush(expected);

        EmailNotificationEntity actual = emailNotificationRepository
                                                    .findById(expected.getUuid())
                                                    .orElse(null);
        Assertions.assertEquals(expected, actual);
    }

    @Test
    void shouldBeDeletedEntityAfterInserted() {
        EmailNotificationEntity expected = new EmailNotificationEntity();
        expected.setEmail(EMAIL_ADDRESS);
        expected.setIdentification(NAME_IDENTIFICATION);
        expected.setDateTimeRegister(LocalDateTime.now());
        emailNotificationRepository.saveAndFlush(expected);

        UUID uuid = expected.getUuid();
        emailNotificationRepository.deleteById(uuid);

        EmailNotificationEntity found = emailNotificationRepository
            .findById(expected.getUuid())
            .orElse(null);


        Assertions.assertEquals(null, found);
    }

}
