package matera.spi.main.domain.service.event;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.enums.TransactionStatus;
import matera.spi.main.domain.model.event.transaction.PaymentEventEntity;
import matera.spi.main.domain.model.message.FinancialActionMappingEntity;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.domain.model.message.MessageTypeEntity;
import matera.spi.main.domain.service.config.FinancialActionConfiguration;
import matera.spi.main.domain.service.event.financial.action.CreditFinancialAction;
import matera.spi.main.domain.service.event.financial.action.FinancialActionHandler;
import matera.spi.main.domain.service.event.transaction.PaymentEvent;
import matera.spi.main.dto.MessageReceiverEventDTO;
import matera.spi.main.dto.event.EventSpecificationFromReceivedMessageDTO;
import matera.spi.main.persistence.FinancialActionMappingRepository;
import matera.spi.main.persistence.MessageTypeRepository;
import matera.spi.main.utils.EntityCreationUtils;
import matera.spi.utils.DocumentUtils;

import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.opentest4j.AssertionFailedError;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.time.format.DateTimeParseException;
import java.util.Map;

import static matera.spi.main.utils.EntityCreationUtils.PACS_002_REPLY_ELEMENT;
import static matera.spi.main.utils.FileUtils.getDocumentFromXmlFile;
import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static matera.spi.utils.DocumentUtils.stringToXmlDocument;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@IntegrationTest
class EventTest  {

    private static final String FROM_SUCCESS_PACS002 = "pacs.002/pacs.002.spi.1.2_SPI_10_msg.xml";
    private static final String FROM_ERROR_PACS002 = "pacs.002/pacs.002.spi.1.2_SPI_1_date_wrong_format_msg.xml";
    private static final Document PACS_002_DOCUMENT = stringToXmlDocument(getStringFromXmlFile(FROM_SUCCESS_PACS002));
    private static final Document PACS_002_ERROR_DOCUMENT = stringToXmlDocument(getStringFromXmlFile(FROM_ERROR_PACS002));

	@Autowired
	private ApplicationContext context;
	@Autowired
	private MessageTypeRepository messageTypeRepository;
	@Autowired
	private FinancialActionMappingRepository financialActionMappingRepository;

    @Autowired
    @Qualifier(FinancialActionConfiguration.FINANCIAL_ACTION_HANDLER)
    private Map<String, FinancialActionHandler> financialActionHandlers;

    @Autowired
    CreditFinancialAction creditFinancialAction;
    @Mock
    FinancialActionHandler mockedFinancialAction;

    @BeforeEach
    void setUp() {
        financialActionHandlers.put("CREDIT", mockedFinancialAction);
    }

    @AfterEach
    void tearDown() {
        financialActionHandlers.put("CREDIT", creditFinancialAction);
    }

    @Test
	@DisplayName("when processing non financial message should not take a financial action")
	void shouldNotTakeAFinancialActionWhenProcessingNonFinancialMessage() {
        MessageTypeEntity mockMessageType = mock(MessageTypeEntity.class);
		when(mockMessageType.getIsFinancial()).thenReturn(false);
		MessageEntity messageEntity = createMessage();
        messageEntity.setMessageTypeEntity(mockMessageType);
		EventSpecificationFromReceivedMessageDTO specificationFromMessageDTO = EventSpecificationFromReceivedMessageDTO
				.builder()
				.messageEntity(messageEntity)
				.build();
		Event event = context.getBean(PaymentEvent.class, new PaymentEventEntity());

		event.makeMessageFinancialActions(specificationFromMessageDTO);

		verify(mockedFinancialAction, never()).handle(any(Event.class));
	}

	@Test
	@DisplayName("when EventSpecificationFromMessageDTO does not have transaction status should throw IllegalStateException")
	void shouldThrowIllegalStateExceptionWhenEventSpecificationFromMessageDTODoesNotHaveTransactionStatus() {
		MessageEntity messageEntity = createMessage();

        NodeList nodeList = DocumentUtils.getElementsByExpression(PACS_002_DOCUMENT, PACS_002_REPLY_ELEMENT);
        Node currentNode = nodeList.item(0);

		EventSpecificationFromReceivedMessageDTO specificationFromMessageDTO = EventSpecificationFromReceivedMessageDTO
				.builder()
                .specificElement(currentNode)
				.messageEntity(messageEntity)
				.build();
		Event event = context.getBean(PaymentEvent.class, new PaymentEventEntity());

		assertThatThrownBy(() ->  event.makeMessageFinancialActions(specificationFromMessageDTO))
								.isInstanceOf(IllegalStateException.class)
								.hasMessageStartingWith("Not found status element of event");

		verify(mockedFinancialAction, never()).handle(any(Event.class));
    }

	@Test
	@DisplayName("when TransactionStatus does not have a financial action mapped should throw IllegalStateException")
	void shouldThrowIllegalStateExceptionWhenNotFoundFinancialActionForTransactionStatus() {
        MessageTypeEntity pacs002Type = messageTypeRepository.findById("pacs.002").orElseThrow(AssertionFailedError::new);
        FinancialActionMappingEntity financialActionMapping = financialActionMappingRepository.findById(pacs002Type, "ACCC")
            .orElseThrow(AssertionFailedError::new);
        financialActionMappingRepository.delete(financialActionMapping);

        NodeList nodeList = DocumentUtils.getElementsByExpression(PACS_002_DOCUMENT, PACS_002_REPLY_ELEMENT);
        Node currentNode = nodeList.item(0);

        MessageEntity messageEntity = createMessage();
        EventSpecificationFromReceivedMessageDTO specificationFromMessageDTO = EventSpecificationFromReceivedMessageDTO
				.builder()
				.messageEntity(messageEntity)
                .specificElement(currentNode)
				.specificElementStatus(TransactionStatus.ACCC.name())
				.build();
        Event event = context.getBean(PaymentEvent.class, new PaymentEventEntity());

		assertThatThrownBy(() ->  event.makeMessageFinancialActions(specificationFromMessageDTO))
				.isInstanceOf(IllegalStateException.class)
				.hasMessage("The event %s does not have a financial action mapped", event);

        verify(mockedFinancialAction, never()).handle(any(Event.class));
        financialActionMappingRepository.saveAndFlush(financialActionMapping);
    }

	@Test
	@DisplayName("when processing financial message should take a financial action with the action specified at EventSpecificationFromMessageDTO")
	void shouldMakeAFinancialActionWhenReceivingFinancialMessage() {
        NodeList nodeList = DocumentUtils.getElementsByExpression(PACS_002_DOCUMENT, PACS_002_REPLY_ELEMENT);
        Node currentNode = nodeList.item(0);

		MessageEntity messageEntity = createMessage();
		EventSpecificationFromReceivedMessageDTO specificationFromMessageDTO = EventSpecificationFromReceivedMessageDTO
				.builder()
				.messageEntity(messageEntity)
                .specificElement(currentNode)
				.specificElementStatus(TransactionStatus.ACCC.name())
				.build();
		Event event = context.getBean(PaymentEvent.class, new PaymentEventEntity());

		event.makeMessageFinancialActions(specificationFromMessageDTO);

        verify(mockedFinancialAction).handle(any(Event.class));
    }

    @Test
    @DisplayName("when processing financial message should take a financial action with the action specified at EventSpecificationFromMessageDTO")
    void shouldThrowExceptionWithWrongIntrBkSttlmDmWhenReceivingFinancialMessage() {
        NodeList nodeList = DocumentUtils.getElementsByExpression(PACS_002_ERROR_DOCUMENT, PACS_002_REPLY_ELEMENT);
        Node currentNode = nodeList.item(0);

        MessageEntity messageEntity = createMessage();
        EventSpecificationFromReceivedMessageDTO specificationFromMessageDTO = EventSpecificationFromReceivedMessageDTO
            .builder()
            .messageEntity(messageEntity)
            .specificElement(currentNode)
            .specificElementStatus(TransactionStatus.ACCC.name())
            .build();
        Event event = context.getBean(PaymentEvent.class, new PaymentEventEntity());

        assertThatThrownBy(() ->  event.makeMessageFinancialActions(specificationFromMessageDTO))
            .isInstanceOf(DateTimeParseException.class);
    }

	@Test
	public void updateStatusFromReplyMessageTest() {

		String PACS_002_SPI_1_2_ERRO_1_MSG = "pacs.002/pacs.002.spi.1.2_ERRO_1_msg.xml";
		Document PACS_002_DOCUMENT = stringToXmlDocument(getStringFromXmlFile(PACS_002_SPI_1_2_ERRO_1_MSG));

		MessageEntity messageEntity = createMessage();

		NodeList nodeList = DocumentUtils.getElementsByExpression(PACS_002_DOCUMENT, messageEntity.getMessageTypeEntity().getReplyElement());
		Node currentNode = nodeList.item(0);

		EventSpecificationFromReceivedMessageDTO specificationFromMessageDTO = EventSpecificationFromReceivedMessageDTO
				.builder()
				.messageEntity(messageEntity)
				.document(PACS_002_DOCUMENT)
				.specificElement(currentNode)
				.build();
		Event event = context.getBean(PaymentEvent.class, new PaymentEventEntity());

		//event.updateStatusFromReplyMessage(specificationFromMessageDTO);

		Assertions.assertTrue(true);

	}

	private MessageEntity createMessage() {
		MessageEntity messageEntity = new MessageEntity();
		messageEntity.setMessageTypeEntity(getMessageType());
		messageEntity.setPiResourceId("bla");
		return messageEntity;
	}

    private MessageTypeEntity getMessageType() {
        return messageTypeRepository.findById("pacs.002").orElseThrow(AssertionError::new);
    }

    @NotNull
    private EventSpecificationFromReceivedMessageDTO getEventSpecificationFromReceivedMessageDTO(String message) {
        MessageReceiverEventDTO messageReceiverEventDTO = getMessageReceiverEventDTOFromPacs002(message);
        String replyElementXpath = messageReceiverEventDTO.getMessageTypeEntity().getReplyElement();

        Node expectedReplyElementNode =  DocumentUtils
            .getElementsByExpression(messageReceiverEventDTO.getMessageDocument(), replyElementXpath).item(0);

        return new EventSpecificationFromReceivedMessageDTO(messageReceiverEventDTO, expectedReplyElementNode);
    }

    private MessageReceiverEventDTO getMessageReceiverEventDTOFromPacs002(String message) {
        Document pacs002 = getDocumentFromXmlFile(message);
        MessageEntity messageEntity = EntityCreationUtils.buildPacs002MessageEntity();

        return MessageReceiverEventDTO.builder()
            .messageEntity(messageEntity)
            .messageDocument(pacs002)
            .build();
    }

}
