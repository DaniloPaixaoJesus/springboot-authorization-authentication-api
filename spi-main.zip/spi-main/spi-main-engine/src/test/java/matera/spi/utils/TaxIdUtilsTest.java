package matera.spi.utils;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

public class TaxIdUtilsTest {

    private static final String EXPECTED_TAX_ID_STR = "09008464000119";
    private static final String TAX_ID_STR_WITHOUT_ZERO = "9008464000119";
    private static final BigDecimal EXPECTED_TAX_ID = BigDecimal.valueOf(9008464000119l);

    @Test
    public void shouldReturnLeftPadWith0WhenReceiveBigDecimalTaxIdWithLeadingZeros() {
        final String actualTaxId = TaxIdUtils.leftPad(EXPECTED_TAX_ID);
        Assertions.assertEquals(EXPECTED_TAX_ID_STR, actualTaxId);
    }

    @Test
    public void shouldReturnLefPadWith0WhenReceiveBigDecimalToStringWithLeadingZeros() {
        final String taxIdStrWithLeadingZero = EXPECTED_TAX_ID.toString();
        Assertions.assertEquals(TAX_ID_STR_WITHOUT_ZERO, taxIdStrWithLeadingZero);

        final String actualTaxId = TaxIdUtils.leftPad(taxIdStrWithLeadingZero);
        Assertions.assertEquals(EXPECTED_TAX_ID_STR, actualTaxId);
    }

}
