package matera.spi.lm.application.services.validation;

import matera.spi.dto.StatementDetailsRequestDTO;
import matera.spi.lm.application.service.validation.LocalDateTimeValidation.LocalDateTimeValidator;
import matera.spi.lm.application.service.validation.StatementsApiValidator;
import matera.spi.lm.domain.model.event.IpAccountStatementQueryDetailsEntity;
import matera.spi.lm.exception.LiquidityManagementException;
import matera.spi.lm.persistence.IpAccountStatementQueryDetailsRepository;
import matera.spi.utils.LocalDateTimeUtils;

import org.apache.commons.compress.utils.Lists;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.time.LocalDateTime;

import static org.mockito.ArgumentMatchers.any;

public class StatementApiValidator {

    @Spy
    @InjectMocks
    private StatementsApiValidator statementsApiValidator;

    @Mock
    private LocalDateTimeValidator localDateTimeValidator;

    @Mock
    private IpAccountStatementQueryDetailsRepository statementQueryDetailsRepository;

    @BeforeEach
    void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void shouldThrowExceptionWhenPageNumberIsNull() {
        Mockito.doNothing().when(localDateTimeValidator)
            .validateDiffBetweenDates(any(LocalDateTime.class), any(LocalDateTime.class), Mockito.anyLong());
        Mockito.doNothing().when(localDateTimeValidator)
            .validatePeriodBetween(any(LocalDateTime.class), any(LocalDateTime.class));

        final Page page = Mockito.mock(buildResponsePageable(1).getClass());
        Mockito.doReturn(page).when(statementQueryDetailsRepository)
            .findByParams(any(Pageable.class), any(LocalDateTime.class), any(LocalDateTime.class));
        Mockito.doReturn(1).when(page).getNumberOfElements();
        Assertions.assertThrows(LiquidityManagementException.class,
            () -> statementsApiValidator.validateRequestNewStatementDetail(buildStatementDetailsRequestDTO()));
    }

    private Page buildResponsePageable(int totalElements) {
        final PageRequest pageable = PageRequest.of(0, 1);
        return new PageImpl<IpAccountStatementQueryDetailsEntity>(Lists.newArrayList(), pageable, totalElements);
    }

    private StatementDetailsRequestDTO buildStatementDetailsRequestDTO() {
        final StatementDetailsRequestDTO statementDetailsRequestDTO = new StatementDetailsRequestDTO();

        statementDetailsRequestDTO.setStartTimestamp(LocalDateTimeUtils.getUtcLocalDateTime());
        statementDetailsRequestDTO.setEndTimestamp(LocalDateTimeUtils.getUtcLocalDateTime().plusDays(1));
        statementDetailsRequestDTO.setIgnoreDateConflict(Boolean.FALSE);
        return statementDetailsRequestDTO;
    }

}
