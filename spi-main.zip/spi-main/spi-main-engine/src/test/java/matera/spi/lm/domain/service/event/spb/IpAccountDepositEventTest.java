package matera.spi.lm.domain.service.event.spb;

import matera.spi.dto.SpbCallbackDTO;
import matera.spi.lm.domain.model.spb.SpbEventEntity;
import matera.spi.lm.domain.model.spb.deposit.IpAccountDepositDetailsEntity;
import matera.spi.lm.domain.model.spb.deposit.IpAccountDepositEventEntity;
import matera.spi.lm.domain.service.event.IpAccountDepositEvent;
import matera.spi.lm.dto.event.IpAccountDepositEventSpecificationDTO;
import matera.spi.main.domain.model.event.transaction.TransactionEventEntity;
import matera.spi.main.domain.model.transaction.TransactionResultEntity;
import matera.spi.main.domain.service.transaction.MirrorIPAccount;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.TransactionResultRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.util.collections.Sets;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.lenient;

public class IpAccountDepositEventTest {

    public static final String END_TO_END_ID = "E0057376820200217082881978247550";

    @InjectMocks
    private DepositEventTest depositEvent;

    @Mock
    private MirrorIPAccount mirrorIPAccount;

    @Mock
    private TransactionResultRepository transactionResultRepository;

    @Mock
    private EventRepository eventRepository;

    private IpAccountDepositEventEntity depositEventEntity;

    private TransactionResultEntity transactionResultEntity;

    @BeforeEach
    void init() {
        depositEventEntity = createIpAccountDepositEventEntity();
        depositEvent = new DepositEventTest(depositEventEntity);
        transactionResultEntity = buildTransactionResultEntity();
        MockitoAnnotations.initMocks(this);

        lenient().doReturn(transactionResultEntity).when(mirrorIPAccount).makeCredit(any(), any());
        lenient().doReturn(transactionResultEntity).when(transactionResultRepository).save(any());
    }

    @Test
    void shouldSetTransactionResultInEventEntity() {
        Assertions.assertNull(depositEvent.getEventEntity().getTransactionResult());
        final SpbCallbackDTO spbCallbackDTO = buildSpbCallbackDTO();
        depositEvent.actionsOnSpbReturn(spbCallbackDTO);

        final TransactionResultEntity actual = depositEvent.getEventEntity().getTransactionResult();
        Assertions.assertNotNull(actual);
        Assertions.assertEquals(transactionResultEntity.getId(), actual.getId());
        Assertions.assertEquals(transactionResultEntity.getTransactionIdInDdaSystem(), actual.getTransactionIdInDdaSystem());
    }

    private SpbCallbackDTO buildSpbCallbackDTO() {
        final SpbCallbackDTO spbCallbackDTO = new SpbCallbackDTO();
        spbCallbackDTO.setId(1l);
        spbCallbackDTO.setTipoEvento("LPI0001");
        spbCallbackDTO.setSituacaoNm(7);
        spbCallbackDTO.setMessages(List.of("<LPI0001R1><CodMsg>LPI0001R1</CodMsg></LPI0001R1>"));

        return spbCallbackDTO;
    }

    private IpAccountDepositEventEntity createIpAccountDepositEventEntity() {
        final IpAccountDepositEventEntity depositEntity = new IpAccountDepositEventEntity();
        depositEntity.setIpAccountDepositDetails(createSpbDepositEventDetailsEntity());
        setBasicEventInfo(depositEntity);
        return Mockito.spy(depositEntity);
    }

    private IpAccountDepositDetailsEntity createSpbDepositEventDetailsEntity() {
        IpAccountDepositDetailsEntity detailsEntity = new IpAccountDepositDetailsEntity();
        detailsEntity.setIspbif(100L);
        detailsEntity.setIspbpspi(999L);
        return detailsEntity;
    }

    private void setBasicEventInfo(SpbEventEntity spbEventENtity) {
        spbEventENtity.setSpbEventId(1L);
        spbEventENtity.setControlNumber("1a2b3c");
        spbEventENtity.setMovementDate(LocalDate.of(2020,5,11));
        spbEventENtity.setSpbMessageEntity(Sets.newSet());
        spbEventENtity.setValue(BigDecimal.TEN);
        spbEventENtity.setInitiationTimestampUTC(LocalDateTime.now());
        spbEventENtity.setInitiatorIspb(1);
        spbEventENtity.setCorrelationId(END_TO_END_ID);
    }

    private TransactionResultEntity buildTransactionResultEntity() {
        final TransactionResultEntity transactionResultEntity = new TransactionResultEntity();
        transactionResultEntity.setId(UUID.randomUUID());
        transactionResultEntity.setTransactionIdInDdaSystem(BigDecimal.valueOf(200D));
        return transactionResultEntity;
    }

    public static class DepositEventTest extends IpAccountDepositEvent {

        public DepositEventTest(TransactionEventEntity eventEntity) {
            super(eventEntity);
        }

        public DepositEventTest(IpAccountDepositEventSpecificationDTO eventSpecificationDTO) {
            super(eventSpecificationDTO);
        }

        public void actionsOnSpbReturn(SpbCallbackDTO spbCallbackDTO) {
            super.actionsOnSpbReturn(spbCallbackDTO);
        }

    }
}
