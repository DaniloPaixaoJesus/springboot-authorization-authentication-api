package matera.spi.lm.application.services.validation;

import matera.spi.dto.PostBalanceAdjustmentRequestDTO;
import matera.spi.dto.PostBalanceAdjustmentRequestDTO.MessageTypeEnum;
import matera.spi.dto.PostBalanceAdjustmentRequestDTO.TransactionTypeEnum;
import matera.spi.lm.application.service.validation.BalanceAdjustmentValidator;
import matera.spi.lm.domain.model.event.IpAccountBalanceAdjustmentDetailsEntity;
import matera.spi.lm.exception.LiquidityManagementException;
import matera.spi.lm.persistence.IpAccountBalanceAdjustmentDetailsRepository;
import matera.spi.utils.LocalDateTimeUtils;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;

@ExtendWith(MockitoExtension.class)
public class BalanceAdjustmentValidatorTest {

    private static final MessageTypeEnum MESSAGE_TYPE_ENUM = MessageTypeEnum.LPI0001;
    private static final LocalDateTime PI_ACCOUNT_TIMESTAMP = LocalDateTimeUtils.getUtcLocalDateTime();
    private static final String TRANSACTION_ID = "E008921002020021708289943624de78";
    private static final TransactionTypeEnum TRANSACTION_TYPE_ENUM = TransactionTypeEnum.CREDIT;
    private static final BigDecimal VALUE = BigDecimal.TEN;

    @Spy
    @InjectMocks
    private BalanceAdjustmentValidator balanceAdjustmentValidator;

    @Mock
    private IpAccountBalanceAdjustmentDetailsRepository balanceAdjustmentDetailsRepository;

    private IpAccountBalanceAdjustmentDetailsEntity mockedDetailsEntity = buildDetailsEntity();

    private IpAccountBalanceAdjustmentDetailsEntity buildDetailsEntity() {
        final IpAccountBalanceAdjustmentDetailsEntity detailsEntity =
            new IpAccountBalanceAdjustmentDetailsEntity();
        detailsEntity.setUuid(UUID.randomUUID());
        detailsEntity.setControlNumberSTR("E000381662020031815545319832763a");
        return detailsEntity;
    }

    private PostBalanceAdjustmentRequestDTO requestDTO;

    @Test
    void shouldThrowExceptionWhenTransactionTypeIsNull() {
        requestDTO = buildRequestDTO(MESSAGE_TYPE_ENUM, PI_ACCOUNT_TIMESTAMP, TRANSACTION_ID, null, VALUE);
        Assertions.assertThrows(
            LiquidityManagementException.class,
            () -> balanceAdjustmentValidator.validatePostBalanceAdjustmentRequest(requestDTO)
        );
    }

    @Test
    void shouldThrowExceptionWhenValueIsZero() {
        requestDTO = buildRequestDTO(MESSAGE_TYPE_ENUM, PI_ACCOUNT_TIMESTAMP, TRANSACTION_ID, TRANSACTION_TYPE_ENUM, BigDecimal.ZERO);
        Assertions.assertThrows(
            LiquidityManagementException.class,
            () -> balanceAdjustmentValidator.validatePostBalanceAdjustmentRequest(requestDTO)
        );
    }

    @Test
    void shouldThrowExceptionWhenMessageTypeIsNull() {
        requestDTO = buildRequestDTO(null, PI_ACCOUNT_TIMESTAMP, TRANSACTION_ID, TRANSACTION_TYPE_ENUM, VALUE);
        Assertions.assertThrows(
            LiquidityManagementException.class,
            () -> balanceAdjustmentValidator.validatePostBalanceAdjustmentRequest(requestDTO)
        );
    }

    @Test
    void shouldThrowExceptionWhenPiAccountDateTimestampIsNull() {
        requestDTO = buildRequestDTO(MESSAGE_TYPE_ENUM, null, TRANSACTION_ID, TRANSACTION_TYPE_ENUM, VALUE);
        Assertions.assertThrows(
            LiquidityManagementException.class,
            () -> balanceAdjustmentValidator.validatePostBalanceAdjustmentRequest(requestDTO)
        );
    }

    @Test
    void shouldThrowExceptionWhenControlNumberSTRAlreadyInDB() {
        doReturn(List.of(mockedDetailsEntity)).when(balanceAdjustmentDetailsRepository).findByControlNumberSTR(anyString());
        requestDTO = buildRequestDTO(MESSAGE_TYPE_ENUM, PI_ACCOUNT_TIMESTAMP, TRANSACTION_ID, TRANSACTION_TYPE_ENUM, VALUE);
        Assertions.assertThrows(
            LiquidityManagementException.class,
            () -> balanceAdjustmentValidator.validatePostBalanceAdjustmentRequest(requestDTO)
        );
    }

    private PostBalanceAdjustmentRequestDTO buildRequestDTO(MessageTypeEnum messageTypeEnum, LocalDateTime piAccountDateTimestamp, String transactionID, TransactionTypeEnum transactionTypeEnum, BigDecimal value) {
        final PostBalanceAdjustmentRequestDTO dto =
            new PostBalanceAdjustmentRequestDTO();

        dto.setMessageType(messageTypeEnum);
        dto.setPiAccountDatetime(piAccountDateTimestamp);
        dto.setTransactionId(transactionID);
        dto.setTransactionType(transactionTypeEnum);
        dto.setValue(value);

        return dto;
    }

}
