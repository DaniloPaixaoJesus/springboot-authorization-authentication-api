package matera.spi.indirect.util;

import com.matera.spi.messaging.model.MessageSentResponseDTO;

import matera.spi.indirect.domain.model.ParticipantMipIndirectHistoryEntity;
import matera.spi.indirect.domain.model.enums.IndirectParticipantStatusEnum;
import matera.spi.indirect.domain.model.event.IndirectParticipantRescissionEventEntity;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventStatusEntity;
import matera.spi.main.domain.model.event.EventTypeEntity;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.EventTypeRepository;
import matera.spi.utils.LocalDateTimeUtils;

import org.opentest4j.AssertionFailedError;

import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.UUID;

public final class EventDataSetUtil {

    private static final String NOT_FOUND_EVENT_TYPE = "Not found Event Type: %d";

    public static final String PI_RESOURCE_ID = "PI-RESOURCE-ID-TEST-STATEMENT";
    public static final String CORRELATION_ID = "E00539039202002170828063aec68f6e";
    public static final IndirectParticipantStatusEnum INDIRECT_PARTICIPANT_STATUS_ENUM =
        IndirectParticipantStatusEnum.ACTIVE;
    public static final String SOME_RESPONSIBLE = "SOME RESPONSIBLE";
    public static final Integer ISPB = 123454;

    private EventDataSetUtil() {

    }

    public static IndirectParticipantRescissionEventEntity createIndirectParticipantRescissionEventEntity(
        ParticipantMipIndirectHistoryEntity historyEntity,
        EventStatusEntity statusEntity) {
        final IndirectParticipantRescissionEventEntity entity = new IndirectParticipantRescissionEventEntity();

        entity.relateToNewHistory(historyEntity);
        entity.setStatus(statusEntity);

        return entity;
    }

    public static EventStatusEntity createEventStatusEntity() {
        final EventStatusEntity eventStatusEntity = new EventStatusEntity();

        eventStatusEntity.setCode(INDIRECT_PARTICIPANT_STATUS_ENUM.getId());
        eventStatusEntity.setDescription(INDIRECT_PARTICIPANT_STATUS_ENUM.name());
        eventStatusEntity.setFinalStatus(false);

        return eventStatusEntity;
    }

    public static <T extends EventEntity> T createButNotSaveEvent(int eventTypeCode,
                                                                  EventRepository eventRepository,
                                                                  EventTypeRepository eventTypeRepository,
                                                                  Class<T> expectedEventClass) {
        final T expectedEvent = buildEventEntity(eventTypeCode, expectedEventClass);
        final EventTypeEntity eventTypeEntity = eventTypeRepository.findById(eventTypeCode)
            .orElseThrow(() -> new AssertionFailedError(String.format(NOT_FOUND_EVENT_TYPE, eventTypeCode)));

        expectedEvent.setEventTypeEntity(eventTypeEntity);
        expectedEvent.setStatus(eventTypeEntity.getInitialStatus());

        return eventRepository.saveAndFlush(expectedEvent);
    }

    public static <T extends EventEntity> T buildEventEntity(int eventType, Class<T> expectedEventClass) {
        final T expectedEvent;

        try {
            expectedEvent = expectedEventClass.getConstructor(null).newInstance(null);
        } catch (NoSuchMethodException | InstantiationException | IllegalAccessException | InvocationTargetException e) {
            throw new AssertionFailedError(e.getMessage(), e);
        }

        expectedEvent.setId(UUID.randomUUID());
        expectedEvent.setCorrelationId(CORRELATION_ID);
        expectedEvent.setClearingTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
        expectedEvent.setInitiationTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
        expectedEvent.setResponsible(SOME_RESPONSIBLE);
        expectedEvent.setInitiatorIspb(ISPB);
        expectedEvent.setValue(BigDecimal.ONE);

        return expectedEvent;
    }

    public static MessageSentResponseDTO createMessageSentResponseDTO() {
        final MessageSentResponseDTO messageSentResponseDTO = new MessageSentResponseDTO();

        messageSentResponseDTO.setPiResourceID(PI_RESOURCE_ID);

        return messageSentResponseDTO;
    }
}
