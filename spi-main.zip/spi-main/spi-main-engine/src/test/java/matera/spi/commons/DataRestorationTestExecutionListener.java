package matera.spi.commons;

import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.init.ScriptUtils;
import org.springframework.test.context.TestContext;
import org.springframework.test.context.TestExecutionListener;

import java.util.Optional;

public class DataRestorationTestExecutionListener implements TestExecutionListener {
    private Optional<JdbcTemplate> jdbcTemplate(TestContext context) {
        try {
            return Optional.of(context.getApplicationContext().getBean(JdbcTemplate.class));
        } catch (NoSuchBeanDefinitionException ex) {
            return Optional.empty();
        }
    }

    private Resource tearDownScript(TestContext testContext) {
        String sql = testContext.getApplicationContext().getEnvironment().getProperty("spring.datasource.tear-down-sql");
        if (sql == null) {
            throw new IllegalStateException("Could not load a tear-down script for this particular test configuration");
        }
        return testContext.getApplicationContext().getResource("classpath:" + sql);
    }

    @Override
    public void afterTestMethod(TestContext testContext) throws Exception {
        jdbcTemplate(testContext).ifPresent(jdbcTemplate -> {
            restoreDatabase(jdbcTemplate, tearDownScript(testContext));
        });
    }

    private void restoreDatabase(JdbcTemplate jdbcTemplate, Resource resource) {
        jdbcTemplate.execute((ConnectionCallback<Object>) connection -> {
            ScriptUtils.executeSqlScript(connection, resource);
            return null;
        });
    }
}

