package matera.spi.main.domain.service.transaction;

import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.domain.model.ParticipantMipEntity;
import matera.spi.main.domain.model.event.transaction.PaymentEventEntity;
import matera.spi.main.domain.model.event.transaction.ReceiptEventEntity;
import matera.spi.main.domain.model.event.transaction.ReturnReceivedEventEntity;
import matera.spi.main.domain.model.event.transaction.ReturnSentEventEntity;
import matera.spi.main.domain.model.transaction.PaymentEntity;
import matera.spi.main.domain.model.transaction.ReceiptEntity;
import matera.spi.main.domain.model.transaction.ReturnReceivedEntity;
import matera.spi.main.domain.model.transaction.ReturnSentEntity;
import matera.spi.main.domain.service.ParticipantMipService;
import matera.spi.main.dto.AccountTransactionRequestDTO;
import matera.spi.main.dto.AccountTransactionResponseDTO;
import matera.spi.main.dto.BalanceAccountThresholdProcessorDTO;
import matera.spi.main.dto.BalanceThresholdProcessorDTO;
import matera.spi.main.dto.QueryBalanceRequestDTO;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ManagerialIPAccountTest {

    private static final Random RANDOM = new Random();
    private static final BigDecimal TRANSACTION_ID = BigDecimal.valueOf(RANDOM.nextLong());
    private static final AccountTransactionResponseDTO ACCOUNT_TRANSACTION_RESPONSE_DTO = AccountTransactionResponseDTO.builder().transactionId(TRANSACTION_ID).build();
    private static final BigDecimal PARTICIPANT_ACCOUNT_NUMBER = BigDecimal.valueOf(RANDOM.nextInt());
    private static final int PARTICIPANT_ACCOUNT_BRANCH = RANDOM.nextInt();
    private static final int CREDIT_TRANSACTION_TYPE = RANDOM.nextInt();
    private static final int DEBIT_TRANSACTION_TYPE = RANDOM.nextInt();
    private static final int DRBK_RCVD_TRANSACTION_TYPE = RANDOM.nextInt();
    private static final int DRBK_SENT_TRANSACTION_TYPE = RANDOM.nextInt();
    private static final int QRCODE_CRED_TRANSACTION_TYPE = RANDOM.nextInt();
    private static final BigDecimal BALANCE_AVAILABLE = BigDecimal.TEN;
    private static final BigDecimal TRANSACTION_VALUE = BigDecimal.valueOf(RANDOM.nextInt());
    private static final UUID EVENT_ID = UUID.randomUUID();
    private static final String END_TO_END_ID = UUID.randomUUID().toString();

    private static final Integer MOCKED_PAYER_ISPB = RANDOM.nextInt();;
    private static final Integer MOCKED_RECEIVER_ISPB = RANDOM.nextInt();;

    @InjectMocks
    private ManagerialIPAccount managerialIPAccount;

    @Mock
    private AccountTransaction accountTransaction;

    @Mock
    private ParticipantMipService participantMipService;

    @Mock
    private BalanceThresholdProcessorDTO balanceThresholdProcessorDTO;

    @BeforeEach
    void setup() {
        Map<Integer, BalanceAccountThresholdProcessorDTO> balanceAccountThresholds = new HashMap<>();
        balanceAccountThresholds.put(MOCKED_PAYER_ISPB, new BalanceAccountThresholdProcessorDTO(BALANCE_AVAILABLE));
        balanceAccountThresholds.put(MOCKED_RECEIVER_ISPB, new BalanceAccountThresholdProcessorDTO(BALANCE_AVAILABLE));
        lenient()
            .when(balanceThresholdProcessorDTO.getBalanceAccountThresholds())
            .thenReturn(balanceAccountThresholds);
    }

    @Test
    void shouldQueryAndGetManagerialBalance() {
        //Given:
        when(accountTransaction.queryBalance(any(QueryBalanceRequestDTO.class)))
            .thenReturn(BALANCE_AVAILABLE);
        //When:
        BigDecimal balance = managerialIPAccount.queryBalance(buildParticipantMipEntityMock(MOCKED_PAYER_ISPB));
        //Then:
        assertThat(balance).isEqualTo(BALANCE_AVAILABLE);
        verify(accountTransaction).queryBalance(getExpectedQueryBalanceRequestDTO());
        verifyNoMoreInteractions(accountTransaction);
    }

    @ParameterizedTest(name = "isDynamicQrCode {0}")
    @ValueSource(booleans = {true, false})
    void shouldMakeManagerialIpAccountCredit(boolean isDynamicQrCode) {
        //Given:
        when(participantMipService.findByIspb(MOCKED_RECEIVER_ISPB)).thenReturn(Optional.of(buildParticipantMipEntityMock(MOCKED_RECEIVER_ISPB)));
        when(accountTransaction.makeTransaction(any(AccountTransactionRequestDTO.class)))
            .thenReturn(ACCOUNT_TRANSACTION_RESPONSE_DTO);
        //When:
        ReceiptEventEntity receiptEventEntity = buildReceiptEventEntity();
        receiptEventEntity.getTransactionEntity().setIsDynamicQrCode(isDynamicQrCode);
        managerialIPAccount.makeCredit(receiptEventEntity);
        //Then:
        int creditTransactionType = isDynamicQrCode? QRCODE_CRED_TRANSACTION_TYPE : CREDIT_TRANSACTION_TYPE;
        verify(accountTransaction)
            .makeTransaction(
                eq(getExpectedAccountTransactionRequestDTO(creditTransactionType, IdempotencePrefix.CREDIT_MANAGERIAL_IP_ACCOUNT_PREFIX))
            );
        verifyNoMoreInteractions(accountTransaction);

        assertThat(receiptEventEntity.getTransactionResult().getTransactionIdInDdaSystem()).isEqualTo(TRANSACTION_ID);
    }

    @Test
    void shouldMakeManagerialIpAccountDebit() {
        //Given:
        when(participantMipService.findByIspb(MOCKED_PAYER_ISPB)).thenReturn(Optional.of(buildParticipantMipEntityMock(MOCKED_PAYER_ISPB)));


        when(accountTransaction.makeTransaction(any(AccountTransactionRequestDTO.class)))
            .thenReturn(ACCOUNT_TRANSACTION_RESPONSE_DTO);
        //When:
        PaymentEventEntity paymentEventEntity = buildPaymentEventEntity();
        managerialIPAccount.makeDebit(paymentEventEntity);
        //Then:
        verify(accountTransaction)
            .makeTransaction(
                eq(getExpectedAccountTransactionRequestDTO(DEBIT_TRANSACTION_TYPE, IdempotencePrefix.DEBIT_MANAGERIAL_IP_ACCOUNT_PREFIX))
            );
        verifyNoMoreInteractions(accountTransaction);
        assertThat(paymentEventEntity.getTransactionResult().getTransactionIdInDdaSystem()).isEqualTo(TRANSACTION_ID);
    }

    @Test
    void shouldMakeManagerialIpAccountReturnReceived() {
        //Given:
        when(participantMipService.findByIspb(MOCKED_RECEIVER_ISPB)).thenReturn(Optional.of(buildParticipantMipEntityMock(MOCKED_RECEIVER_ISPB)));

        when(accountTransaction.makeTransaction(any(AccountTransactionRequestDTO.class)))
            .thenReturn(ACCOUNT_TRANSACTION_RESPONSE_DTO);
        //When:
        ReturnReceivedEventEntity returnReceivedEventEntity = buildReturnReceivedEventEntity();
        managerialIPAccount.returnReceived(returnReceivedEventEntity);
        //Then:
        verify(accountTransaction)
            .makeTransaction(
                eq(getExpectedAccountTransactionRequestDTO(DRBK_RCVD_TRANSACTION_TYPE, IdempotencePrefix.RETURN_RECEIVED_MANAGERIAL_IP_ACCOUNT_PREFIX))
            );
        verifyNoMoreInteractions(accountTransaction);

        assertThat(returnReceivedEventEntity.getTransactionResult().getTransactionIdInDdaSystem()).isEqualTo(TRANSACTION_ID);
    }

    @Test
    void shouldMakeManagerialIpAccountReturnSent() {
        //Given:
        when(participantMipService.findByIspb(MOCKED_PAYER_ISPB)).thenReturn(Optional.of(buildParticipantMipEntityMock(MOCKED_PAYER_ISPB)));

        when(accountTransaction.makeTransaction(any(AccountTransactionRequestDTO.class)))
            .thenReturn(ACCOUNT_TRANSACTION_RESPONSE_DTO);
        //When:
        ReturnSentEventEntity returnSentEventEntity = buildReturnSentEventEntity();
        managerialIPAccount.returnSent(returnSentEventEntity);
        //Then:
        verify(accountTransaction)
            .makeTransaction(
                eq(getExpectedAccountTransactionRequestDTO(DRBK_SENT_TRANSACTION_TYPE, IdempotencePrefix.RETURN_SENT_MANAGERIAL_IP_ACCOUNT_PREFIX))
            );
        verifyNoMoreInteractions(accountTransaction);

        assertThat(returnSentEventEntity.getTransactionResult().getTransactionIdInDdaSystem()).isEqualTo(TRANSACTION_ID);
    }

    private static QueryBalanceRequestDTO getExpectedQueryBalanceRequestDTO() {
        return QueryBalanceRequestDTO.builder()
            .branch(PARTICIPANT_ACCOUNT_BRANCH)
            .account(PARTICIPANT_ACCOUNT_NUMBER)
            .includeLimit(null)
            .dMinusOne(null)
            .build();
    }

    private static AccountTransactionRequestDTO getExpectedAccountTransactionRequestDTO(int transactionType, String idempotencePrefix) {
        return AccountTransactionRequestDTO.builder()
            .idempotenceId(idempotencePrefix + END_TO_END_ID)
            .branch(PARTICIPANT_ACCOUNT_BRANCH)
            .account(PARTICIPANT_ACCOUNT_NUMBER)
            .transactionType(transactionType)
            .groupEntries(false)
            .validateBalance(true)
            .endToEndId(END_TO_END_ID)
            .eventId(EVENT_ID)
            .value(TRANSACTION_VALUE)
            .details(EVENT_ID.toString())
            .informationAccountHolderTransaction(END_TO_END_ID.toString())
            .operationComplement("ISPBC:" + MOCKED_RECEIVER_ISPB + "#ISPBD:" + MOCKED_PAYER_ISPB)
            .build();
    }

    private static ParticipantEntity getParticipantEntity(Integer ispb) {
        ParticipantEntity payerParticipant = new ParticipantEntity();
        payerParticipant.setIspb(ispb);
        return payerParticipant;
    }

    private static PaymentEventEntity buildPaymentEventEntity() {
        PaymentEntity paymentEntity = new PaymentEntity();
        paymentEntity.setPayerParticipant(getParticipantEntity(MOCKED_PAYER_ISPB));

        paymentEntity.setReceiverParticipant(getParticipantEntity(MOCKED_RECEIVER_ISPB));

        PaymentEventEntity paymentEventEntity = new PaymentEventEntity();
        paymentEventEntity.setId(EVENT_ID);
        paymentEventEntity.setCorrelationId(END_TO_END_ID);
        paymentEventEntity.setValue(TRANSACTION_VALUE);
        paymentEventEntity.setPaymentEntity(paymentEntity);
        return paymentEventEntity;
    }

    private static ReceiptEventEntity buildReceiptEventEntity() {
        ReceiptEntity receiptEntity = new ReceiptEntity();
        receiptEntity.setReceiverParticipant(getParticipantEntity(MOCKED_RECEIVER_ISPB));

        receiptEntity.setPayerParticipant(getParticipantEntity(MOCKED_PAYER_ISPB));

        ReceiptEventEntity receiptEventEntity = new ReceiptEventEntity();
        receiptEventEntity.setId(EVENT_ID);
        receiptEventEntity.setCorrelationId(END_TO_END_ID);
        receiptEventEntity.setValue(TRANSACTION_VALUE);
        receiptEventEntity.setReceiptEntity(receiptEntity);
        return receiptEventEntity;
    }

    private static ReturnSentEventEntity buildReturnSentEventEntity() {
        ReturnSentEntity returnSentEntity = new ReturnSentEntity();
        returnSentEntity.setPayerParticipant(getParticipantEntity(MOCKED_PAYER_ISPB));
        returnSentEntity.setReceiverParticipant(getParticipantEntity(MOCKED_RECEIVER_ISPB));

        ReturnSentEventEntity returnSentEventEntity = new ReturnSentEventEntity();
        returnSentEventEntity.setId(EVENT_ID);
        returnSentEventEntity.setCorrelationId(END_TO_END_ID);
        returnSentEventEntity.setValue(TRANSACTION_VALUE);
        returnSentEventEntity.setReturnSentEntity(returnSentEntity);
        return returnSentEventEntity;
    }

    private static ReturnReceivedEventEntity buildReturnReceivedEventEntity() {
        ReturnReceivedEntity returnReceivedEntity = new ReturnReceivedEntity();
        returnReceivedEntity.setReceiverParticipant(getParticipantEntity(MOCKED_RECEIVER_ISPB));
        returnReceivedEntity.setPayerParticipant(getParticipantEntity(MOCKED_PAYER_ISPB));

        ReturnReceivedEventEntity returnReceivedEventEntity = new ReturnReceivedEventEntity();
        returnReceivedEventEntity.setId(EVENT_ID);
        returnReceivedEventEntity.setCorrelationId(END_TO_END_ID);
        returnReceivedEventEntity.setValue(TRANSACTION_VALUE);
        returnReceivedEventEntity.setReturnReceivedEntity(returnReceivedEntity);
        return returnReceivedEventEntity;
    }

    private static ParticipantMipEntity buildParticipantMipEntityMock(Integer ispb) {
        ParticipantMipEntity participantMipEntity = new ParticipantMipEntity();
        participantMipEntity.setIspb(ispb);
        participantMipEntity.setBranch(PARTICIPANT_ACCOUNT_BRANCH);
        participantMipEntity.setAccountNumber(PARTICIPANT_ACCOUNT_NUMBER);
        participantMipEntity.setCredTransactionType(CREDIT_TRANSACTION_TYPE);
        participantMipEntity.setDebTransactionType(DEBIT_TRANSACTION_TYPE);
        participantMipEntity.setDrawbackReceiveTransactType(DRBK_RCVD_TRANSACTION_TYPE);
        participantMipEntity.setDrawbackSentTransactType(DRBK_SENT_TRANSACTION_TYPE);
        participantMipEntity.setBalanceLowerThreshold(BigDecimal.valueOf(Long.MAX_VALUE)); //force validation true
        participantMipEntity.setBalanceValidationThreshold(true);
        participantMipEntity.setQrcodeCredTransactionType(QRCODE_CRED_TRANSACTION_TYPE);
        return participantMipEntity;
    }

}
