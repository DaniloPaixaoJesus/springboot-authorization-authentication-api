package matera.spi.lm.rest;

import com.matera.spi.messaging.api.MessagesApi;
import com.matera.spi.messaging.api.SPIMessagingApis;
import com.matera.spi.messaging.model.MessageSentResponseDTO;
import com.matera.spi.messaging.model.MessageSpecificationDTO;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.BalanceRequestUIDTO;
import matera.spi.dto.ReferenceDateBalanceResposeDTO;
import matera.spi.main.domain.service.MessageSender;
import matera.spi.main.domain.service.event.receiver.MessageReceiver;
import matera.spi.main.utils.FileUtils;
import matera.spi.main.utils.WireMockUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import net.javacrumbs.jsonunit.JsonAssert;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.messaging.support.GenericMessage;

import java.time.LocalDate;
import java.util.UUID;

import javax.validation.Valid;

import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static matera.spi.main.utils.WireMockUtils.V_1_MESSAGES;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.resetAllRequests;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@IntegrationTest
public class XmlContentListByEventTest {

    private static final String BALANCE_BASE_URI = "/ui/v1/ip-account/balance/queries";

    private final String RESPONSE_FIND_MESSAGES_BY_EVENT_ID =
        FileUtils.getStringFromJsonFile("messages/response_find_all_messages_related_to_event_id.json");
    private final String CAMT_060_RESPONSE_FIND_MESSAGES_BY_EVENT_ID =
        FileUtils.getStringFromJsonFile("messages/camt_060_response_find_all_messages_related_to_event_id.json");

    private static final String CAMT060_PI_RESOURCE_ID_SPECIAL_CHAR = "PI-RESOURCE-ID-TEST-060@";
    private static final String ENCODED_CAMT060_PI_RESOURCE_ID_SPECIAL_CHAR = "PI-RESOURCE-ID-TEST-060%40";

    private static final String CAMT060_PI_RESOURCE_ID = "PI-RESOURCE-ID-TEST-060";
    private static final String CAMT053_PI_RESOURCE_ID = "PI-RESOURCE-ID-TEST-053";
    private static final String CAMT_053_STRING = getStringFromXmlFile("camt.053/camt.053_SALDO_MOMENTO_msg.xml");
    private static final String CAMT_053_XML =
        "<?xml version=\\\"1.0\\\" encoding=\\\"UTF-8\\\" standalone=\\\"no\\\"?> <Envelope xmlns=\\\"https://www.bcb.gov.br/pi/camt.053/1.1\\\">  <AppHdr> <Fr> <FIId> <FinInstnId> <Othr> <Id>00038166</Id> </Othr> </FinInstnId> </FIId> </Fr> <To> <FIId> <FinInstnId> <Othr> <Id>13370835</Id> </Othr> </FinInstnId> </FIId> </To> <BizMsgIdr>M00038166e73f3988f9994441bda31fc</BizMsgIdr> <MsgDefIdr>camt.053.spi.1.1</MsgDefIdr> <CreDt>2020-04-07T13:17:04.766Z</CreDt> <Sgntr/> </AppHdr> <Document> <BkToCstmrStmt> <GrpHdr> <MsgId>M00038166e73f3988f9994441bda31fc</MsgId> <CreDtTm>2020-04-07T13:17:04.766Z</CreDtTm> </GrpHdr> <Stmt> <Id>M9999901075832805ac8d4eaf9712519</Id> <Acct> <Id> <Othr> <Id>99999010</Id> </Othr> </Id> </Acct> <Bal> <Tp> <CdOrPrtry> <Prtry>SADP</Prtry> </CdOrPrtry> </Tp> <Amt Ccy=\\\"BRL\\\">52478.44</Amt> <CdtDbtInd>CRDT</CdtDbtInd> <Dt> <DtTm>2020-04-07T13:17:04.768Z</DtTm> </Dt> </Bal> <Bal> <Tp> <CdOrPrtry> <Prtry>SABK</Prtry> </CdOrPrtry> </Tp> <Amt Ccy=\\\"BRL\\\">27885.31</Amt> <CdtDbtInd>CRDT</CdtDbtInd> <Dt> <DtTm>2020-04-07T13:17:04.768Z</DtTm> </Dt> </Bal> </Stmt> </BkToCstmrStmt> </Document> </Envelope>";
    private static final String CAMT_060_XML =
        "<?xml version=\\\"1.0\\\" encoding=\\\"UTF-8\\\" standalone=\\\"no\\\"?> <Envelope xmlns=\\\"https://www.bcb.gov.br/pi/camt.060/1.1\\\"> <AppHdr> <Fr> <FIId> <FinInstnId> <Othr> <Id>00038166</Id> </Othr> </FinInstnId> </FIId> </Fr> <To> <FIId> <FinInstnId> <Othr> <Id>13370835</Id> </Othr> </FinInstnId> </FIId> </To> <BizMsgIdr>M0003816610ce0b023e95427f9f48a0e</BizMsgIdr> <MsgDefIdr>camt.060.spi.1.1</MsgDefIdr> <CreDt>2020-04-07T13:17:04.716Z</CreDt> <Sgntr /> </AppHdr> <Document>  <AcctRptgReq>  <GrpHdr> <MsgId> M9999901075832805ac8d4eaf9712519</MsgId> <CreDtTm> 2020-06-30T13:26:19.162Z</CreDtTm> </GrpHdr> <RptgReq> <ReqdMsgNmId> camt.053</ReqdMsgNmId> <AcctOwnr> <Agt> <FinInstnId> <ClrSysMmbId> <MmbId> 13370835</MmbId> </ClrSysMmbId> </FinInstnId> </Agt> </AcctOwnr> <RptgPrd> <FrToDt> <FrDt> 2020-04-07Z</FrDt> </FrToDt> <Tp> ALLL</Tp> </RptgPrd> </RptgReq> </AcctRptgReq> </Document> </Envelope>";

    @LocalServerPort
    protected int port;

    @Autowired
    private MessageSender messageSender;
    @Autowired
    private SPIMessagingApis spiMessagingApisBean;
    @Mock
    private SPIMessagingApis mockedSpiMessagingApis;
    @Mock
    private MessagesApi mockedMessagesApi;
    @Captor
    private ArgumentCaptor<MessageSpecificationDTO> messageSpecificationDTOArgumentCaptor;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private MessageReceiver messageReceiver;

    private static final WireMockServer wireMockServer = WireMockUtils.start();

    @BeforeAll
    static void beforeAll() {
        WireMockUtils.stubMessaging();
    }

    @AfterAll
    static void afterAll() {
        wireMockServer.stop();
    }

    @BeforeEach
    public void beforeEach() {
        RestAssured.port = port;
        resetAllRequests();

        when(mockedSpiMessagingApis.messagesApi()).thenReturn(mockedMessagesApi);
        messageSender.setSpiMessagingApis(mockedSpiMessagingApis);
    }

    @AfterEach
    void tearDown() {
        messageSender.setSpiMessagingApis(spiMessagingApisBean);
    }

    @Test
    void shouldReturnXmlContentListByEvent() throws JSONException {
        doReturn(buildMessageSentResponseDTO(CAMT060_PI_RESOURCE_ID)).when(mockedMessagesApi).sendsMessageV1(any());

        String messagesEndpointCamt053 = V_1_MESSAGES + "?piResourceIds=" + CAMT053_PI_RESOURCE_ID;
        stubFor(get(messagesEndpointCamt053).withQueryParam("piResourceIds", equalTo(CAMT053_PI_RESOURCE_ID))
            .willReturn(aResponse().withStatus(HttpStatus.OK.value())
                .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE)
                .withBody(getResponseBodyCamt053())));

        String messagesEndpointCamt060 = V_1_MESSAGES + "?piResourceIds=" + CAMT060_PI_RESOURCE_ID;
        stubFor(get(messagesEndpointCamt060).withQueryParam("piResourceIds", equalTo(CAMT060_PI_RESOURCE_ID))
            .willReturn(aResponse().withStatus(HttpStatus.OK.value())
                .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE)
                .withBody(getResponseBodyCamt060(CAMT060_PI_RESOURCE_ID))));

        final ReferenceDateBalanceResposeDTO statementDetailsResponseDTO =
            RestAssured.given()
                .log().all()
                .contentType(ContentType.JSON)
                .body(buildBalanceRequestDTO())
                .when().post(BALANCE_BASE_URI)
                .then()
                .statusCode(org.eclipse.jetty.http.HttpStatus.CREATED_201)
                .extract().as(ReferenceDateBalanceResposeDTO.class);

        messageReceiver.onMessage(getIncomingMessageCamt053());

        @Valid final UUID eventUuid = statementDetailsResponseDTO.getData().getEventUuid();
        final String responseBody =
            RestAssured.given()
                .when().get("/ui/v1/events/" + eventUuid + "/xml-content")
                .thenReturn()
                .body().asString();

        Assertions.assertNotNull(responseBody);
        JsonAssert.assertJsonEquals(RESPONSE_FIND_MESSAGES_BY_EVENT_ID, responseBody);
    }

    @Test
    void shouldEncodeQueryParamsWhenSendPiResourceIdWithSpecialCharacters() throws JSONException {
        doReturn(buildMessageSentResponseDTO(CAMT060_PI_RESOURCE_ID_SPECIAL_CHAR))
            .when(mockedMessagesApi).sendsMessageV1(any());

        String messagesEndpointCamt060 = V_1_MESSAGES + "?piResourceIds=" + ENCODED_CAMT060_PI_RESOURCE_ID_SPECIAL_CHAR;
        stubFor(
            get(messagesEndpointCamt060)
                .withQueryParam("piResourceIds", equalTo(CAMT060_PI_RESOURCE_ID_SPECIAL_CHAR))
            .willReturn(aResponse().withStatus(HttpStatus.OK.value())
                .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE)
                .withBody(getResponseBodyCamt060(ENCODED_CAMT060_PI_RESOURCE_ID_SPECIAL_CHAR))));

        final ReferenceDateBalanceResposeDTO statementDetailsResponseDTO =
            RestAssured.given()
                .log().all()
                .contentType(ContentType.JSON)
                .body(buildBalanceRequestDTO())
                .when().post(BALANCE_BASE_URI)
                .then()
                .statusCode(org.eclipse.jetty.http.HttpStatus.CREATED_201)
                .extract().as(ReferenceDateBalanceResposeDTO.class);

        @Valid final UUID eventUuid = statementDetailsResponseDTO.getData().getEventUuid();
        final String responseBody =
            RestAssured.given()
                .when().get("/ui/v1/events/" + eventUuid + "/xml-content")
                .thenReturn()
                .body().asString();

        Assertions.assertNotNull(responseBody);
        JsonAssert.assertJsonEquals(CAMT_060_RESPONSE_FIND_MESSAGES_BY_EVENT_ID, responseBody);
    }

    private String getResponseBodyCamt053() {
        return "{\"data\":{\"messages\":[{\"piResourceId\":\"" + CAMT053_PI_RESOURCE_ID +
               "\",\"messageType\":\"camt.053\",\"xml\":\"" + CAMT_053_XML +
               "\",\"timestamp\":\"2020-04-08T10:44:47\"}]}}";
    }

    private String getResponseBodyCamt060(String piResourceId) {
        return "{\"data\":{\"messages\":[{\"piResourceId\":\"" + piResourceId +
               "\",\"messageType\":\"camt.060\",\"xml\":\"" + CAMT_060_XML +
               "\",\"timestamp\":\"2020-04-08T19:00:00\"}]}}";
    }

    private MessageSentResponseDTO buildMessageSentResponseDTO(String piResourceId) {
        final MessageSentResponseDTO messageSentResponseDTO = new MessageSentResponseDTO();
        messageSentResponseDTO.setPiResourceID(piResourceId);
        return messageSentResponseDTO;
    }

    private BalanceRequestUIDTO buildBalanceRequestDTO() {
        final BalanceRequestUIDTO balanceRequestUIDTO = new BalanceRequestUIDTO();
        balanceRequestUIDTO.setReferenceDate(LocalDate.of(2020,4,7));
        return balanceRequestUIDTO;
    }

    private GenericMessage<String> getIncomingMessageCamt053() throws JSONException {

        verify(mockedMessagesApi, atLeastOnce()).sendsMessageV1(messageSpecificationDTOArgumentCaptor.capture());
        MessageSpecificationDTO messageSpecificationDTO = messageSpecificationDTOArgumentCaptor.getValue();

        JSONObject jsonObject = new JSONObject().put("piResourceId", CAMT053_PI_RESOURCE_ID).put("xml", CAMT_053_STRING.replace("M9999901075832805ac8d4eaf9712519", messageSpecificationDTO.getMessageId()))
            .put("messageType", "camt.053");

        return new GenericMessage<>(jsonObject.toString());
    }

}
