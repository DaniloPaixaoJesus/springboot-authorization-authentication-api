package matera.spi.main.domain.service;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.ConfigEntity;
import matera.spi.main.exception.MainEngineConfigurationException;
import matera.spi.main.persistence.ConfigRepository;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@IntegrationTest
class ConfigurationServiceTest  {

    private static final Integer ISPB = 12345678;

    @Autowired
    private ConfigRepository configRepository;

    @Autowired
    private ConfigurationService configurationService;

    private ConfigEntity lastConfig;

    @BeforeEach
    void beforeEach() {
        lastConfig = configRepository.findAll().get(0);
        configRepository.deleteAll();
    }

    @AfterEach
    void afterEach() {
        configRepository.deleteAll();
        configRepository.saveAndFlush(lastConfig);
    }

    void createConfig(Integer ispb) {
        ConfigEntity entity = new ConfigEntity();
        entity.setIspb(ispb);
        entity.setBalanceValidationThreshold(BigDecimal.valueOf(1000000.00));
        entity.setCustomerCredTransactionType(0);
        entity.setCustomerDebTransactionType(0);
        entity.setPmtSlaTime(10);
        entity.setPmtConfirmRetryAmount(600);
        entity.setPmtConfirmRetryInterval(10);
        entity.setReceiveConfirmRetryAmount(600);
        entity.setReceiveConfirmRetryInterval(10);
        entity.setCustDrawbSentTransType(1986);
        entity.setCustDrawbReceivedTransType(7745);
        entity.setQrcodeCredTransactionType(1877);
        configRepository.save(entity);
    }

    @Test
    void shouldBeConfigurationWhenLoad() {
        createConfig(ISPB);
        ConfigEntity expected = configurationService.findConfig();
        assertNotNull(expected);
        assertTrue(expected.getIspb().equals(ISPB)
                && expected.getBalanceValidationThreshold().doubleValue() == 1000000.00
                && expected.getCustomerCredTransactionType().equals(0)
                && expected.getCustomerDebTransactionType().equals(0)
                && expected.getPmtSlaTime().equals(10)
                && expected.getPmtConfirmRetryAmount().equals(600)
                && expected.getPmtConfirmRetryInterval().equals(10)
                && expected.getReceiveConfirmRetryAmount().equals(600)
                && expected.getReceiveConfirmRetryInterval().equals(10)
                && expected.getQrcodeCredTransactionType().equals(1877)
        );
    }

    @Test
    void shouldBeExceptionWhenEmptyTable() {
        MainEngineConfigurationException exception = assertThrows(MainEngineConfigurationException.class, () -> configurationService.findConfig(), "Main Engine Configuration not found.");
    }

    @Test
    void shouldBeExceptionWhenMoreOneConfiguration() {
        createConfig(23456789);
        createConfig(87654321);
        MainEngineConfigurationException exception = assertThrows(MainEngineConfigurationException.class, () -> configurationService.findConfig(), "Main Engine Configuration has more one element.");
    }

    @Test
    void testSave() {

        // Given
        final ConfigEntity entity = new ConfigEntity();
        entity.setIspb(0);
        entity.setBalanceValidationThreshold(new BigDecimal("0.00"));
        entity.setCustomerCredTransactionType(0);
        entity.setCustomerDebTransactionType(0);
        entity.setPmtSlaTime(0);
        entity.setPmtConfirmRetryAmount(0);
        entity.setPmtConfirmRetryInterval(0);
        entity.setReceiveConfirmRetryAmount(0);
        entity.setReceiveConfirmRetryInterval(0);
        entity.setCustDrawbSentTransType(1);
        entity.setCustDrawbReceivedTransType(2);
        entity.setQrcodeCredTransactionType(1241);
        var expected = Optional.of(entity);

        // When

        configurationService.save(entity);

        var actual = configRepository.findById(entity.getId());

        // Then

        assertEquals(expected, actual);
    }

    @Test
    void shouldFindIspb() {
        createConfig(ISPB);
        String ispbActual = configurationService.findByIspb();
        String ispbExpected = String.valueOf(ISPB);

        assertEquals(ispbExpected, ispbActual);
    }
}
