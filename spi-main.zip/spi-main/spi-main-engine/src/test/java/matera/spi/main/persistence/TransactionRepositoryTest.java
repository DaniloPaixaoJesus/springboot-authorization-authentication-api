package matera.spi.main.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.domain.model.account.AccountTypeEntity;
import matera.spi.main.domain.model.account.PayerAccountEntity;
import matera.spi.main.domain.model.account.ReceiverAccountEntity;
import matera.spi.main.domain.model.transaction.PaymentEntity;
import matera.spi.main.domain.model.transaction.TransactionEntity;
import matera.spi.main.domain.model.transaction.TransactionPriorityEntity;
import matera.spi.utils.LocalDateTimeUtils;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

@IntegrationTest
@Transactional
class TransactionRepositoryTest   {

    private static final String ACCOUNT_TYPE_CODE = "ABCD";
    @Autowired
    private TransactionRepository repository;

    @Autowired
    private ParticipantRepository participantRepository;

    @Autowired
    private AccountTypeRepository accountTypeRepository;

    @Autowired
    private TransactionPriorityRepository transactionPriorityRepository;

    @AfterEach
    void afterEach() {
        repository.deleteAll();
        accountTypeRepository.deleteById(ACCOUNT_TYPE_CODE);
    }

    @Test
    void shouldBeFindEntityWhenInserted() {
        PaymentEntity expected = new PaymentEntity();
        expected.setIsLocalPayment(true);
        expected.setClearingAccountBalanceChecked(false);
        expected.setAdditionalInformation("Additional Information teste");
        expected.setCustomerInitTimestampUtc(LocalDateTimeUtils.getUtcLocalDateTime());
        expected.setEndToEndId("M12345678abcdefghijklmnopqrstuvw");
        expected.setInitiatingInstitutionTaxId(1L);
        expected.setPayerParticipant(buildPayerParticipant());
        expected.setReceiverParticipant(buildReceiverParticipant());
        expected.setPayerAccount(buildPayerAccountEntity());
        expected.setReceiverAccount(buildReceiverAccountEntity());
        expected.setPriority(buildTransactionPriorityEntity());
        expected.setReceiverReconIdentifier("Receiver Recon Teste");
        expected.setIsLocalPayment(false);
        expected.setIsDynamicQrCode(true);

        repository.saveAndFlush(expected);

        TransactionEntity actual = repository.findById(expected.getId()).orElse(null);

        Assertions.assertEquals(expected.getTransactionType(),  actual.getTransactionType());
        Assertions.assertEquals(expected.getId(),  actual.getId());
        Assertions.assertEquals(expected.getAdditionalInformation(),  actual.getAdditionalInformation());
        Assertions.assertEquals(expected.getEndToEndId(),  actual.getEndToEndId());
        Assertions.assertEquals(expected.getInitiatingInstitutionTaxId(),  actual.getInitiatingInstitutionTaxId());
        Assertions.assertEquals(expected.getPayerParticipant(),  actual.getPayerParticipant());
        Assertions.assertEquals(expected.getReceiverParticipant(),  actual.getReceiverParticipant());
        Assertions.assertEquals(expected.getPayerAccount(),  actual.getPayerAccount());
        Assertions.assertEquals(expected.getReceiverAccount(),  actual.getReceiverAccount());
        Assertions.assertEquals(expected.getPriority(),  actual.getPriority());
        Assertions.assertEquals(expected.getReceiverReconIdentifier(),  actual.getReceiverReconIdentifier());
        Assertions.assertTrue(expected.isDynamicQrCode());

    }

    private TransactionPriorityEntity buildTransactionPriorityEntity() {
        return transactionPriorityRepository.getOne("HIGH");
    }

    private ParticipantEntity buildPayerParticipant() {
        ParticipantEntity entity = new ParticipantEntity();
        entity.setIspb(12345678);
        entity.setName("Payer Participant");

        participantRepository.saveAndFlush(entity);
        return entity;
    }

    private ParticipantEntity buildReceiverParticipant() {
        ParticipantEntity entity = new ParticipantEntity();
        entity.setIspb(87654321);
        entity.setName("Receiver Participant");

        participantRepository.saveAndFlush(entity);
        return entity;
    }

    private PayerAccountEntity buildPayerAccountEntity() {
        PayerAccountEntity entity = new PayerAccountEntity();
        entity.setTaxId("1230");
        entity.setName("PAYER_NAME");
        entity.setBranch("1234");
        entity.setAccount("22233344");
        entity.setAccountType(buildAccountTypeEntity().getCode());

        return entity;
    }

    private ReceiverAccountEntity buildReceiverAccountEntity() {
        ReceiverAccountEntity entity = new ReceiverAccountEntity();
        entity.setTaxId("3210");
        entity.setBranch("4321");
        entity.setAccount("55566677");
        entity.setAddressingKey("teste@teste.com");
        entity.setAccountType(buildAccountTypeEntity().getCode());

        return entity;
    }

    private AccountTypeEntity buildAccountTypeEntity() {
        AccountTypeEntity entity = new AccountTypeEntity();
        entity.setCode(ACCOUNT_TYPE_CODE);
        entity.setDescription("Account Type");

        accountTypeRepository.saveAndFlush(entity);
        return entity;
    }

}
