package matera.spi.indirect.application.service.mapper;

import matera.spi.dto.IndirectParticipantFinancialFieldsDTO;
import matera.spi.indirect.util.ParticipantMipIndirectDataSetUtil;
import matera.spi.main.domain.model.ParticipantMipEntity;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class ParticipantMipMapperTest {

    @Test
    void shouldMapperEntityToDTO() {
        final ParticipantMipEntity entity = ParticipantMipIndirectDataSetUtil.createParticipantMip();
        final IndirectParticipantFinancialFieldsDTO dto =
            ParticipantMipMapper.mapToIndirectParticipantFinancialFieldsDTO(entity);

        assertEquals(entity.getBalanceLowerThreshold(), dto.getBalanceLowerThreshold());
        assertEquals(entity.isBalanceValidationThreshold(), dto.getBalanceValidationThreshold());
        assertEquals(entity.getCredTransactionType(), dto.getCredTransactionType().intValue());
        assertEquals(entity.getDebTransactionType(), dto.getDebitTransactionType());
        assertEquals(entity.getDrawbackReceiveTransactType(), dto.getDrawbackReceiveTransactType().intValue());
        assertEquals(entity.getDrawbackSentTransactType(), dto.getDrawbackSentTransactType().intValue());
        assertEquals(entity.getQrcodeCredTransactionType(), dto.getQrcodeCredTransactionType().intValue());

        assertEquals(ParticipantMipIndirectDataSetUtil.BALANCE_LOWER_THRESHOLD, dto.getBalanceLowerThreshold());
        assertEquals(ParticipantMipIndirectDataSetUtil.BALANCE_VALIDATION_THRESHOLD,
            dto.getBalanceValidationThreshold());
        assertEquals(ParticipantMipIndirectDataSetUtil.CRED_TRANSACTION_TYPE, dto.getCredTransactionType().intValue());
        assertEquals(ParticipantMipIndirectDataSetUtil.DEB_TRANSACTION_TYPE, dto.getDebitTransactionType());
        assertEquals(ParticipantMipIndirectDataSetUtil.DRAWBACK_RECEIVE_TRANSACT_TYPE,
            dto.getDrawbackReceiveTransactType().intValue());
        assertEquals(ParticipantMipIndirectDataSetUtil.DRAWBACK_SENT_TRANSACT_TYPE,
            dto.getDrawbackSentTransactType().intValue());
        assertEquals(ParticipantMipIndirectDataSetUtil.QRCODE_CRED_TRANSACTION_TYPE,
            dto.getQrcodeCredTransactionType().intValue());
    }

    @Test
    void shouldThrowExceptionWhenArgumentIsNull() {
        final NullPointerException nullPointerException = assertThrows(NullPointerException.class,
            () -> ParticipantMipMapper.mapToIndirectParticipantFinancialFieldsDTO(null));

        assertEquals(ParticipantMipMapper.THE_PARTICIPANT_MIP_ENTITY_PARAMETER_IS_REQUIRED,
            nullPointerException.getMessage());
    }

}
