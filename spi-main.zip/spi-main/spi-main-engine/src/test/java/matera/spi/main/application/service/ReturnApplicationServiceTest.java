package matera.spi.main.application.service;

import com.matera.commons.utils.exception.BusinessException;

import matera.spi.dto.ReturnResponseDTO;
import matera.spi.dto.ReturnSettlementWrapperDTO;
import matera.spi.main.config.MainEngineConfiguration;
import matera.spi.main.domain.model.ClientSystemEntity;
import matera.spi.main.domain.model.account.PayerAccountEntity;
import matera.spi.main.domain.model.account.ReceiverAccountEntity;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventStatus;
import matera.spi.main.domain.model.event.EventStatusEntity;
import matera.spi.main.domain.model.event.transaction.ReceiptEventEntity;
import matera.spi.main.domain.model.event.transaction.ReturnSentEventEntity;
import matera.spi.main.domain.model.transaction.ReceiptEntity;
import matera.spi.main.domain.model.transaction.ReturnSentEntity;
import matera.spi.main.domain.model.transaction.TransactionPriorityEntity;
import matera.spi.main.domain.service.ClientSystemService;
import matera.spi.main.domain.service.CorrelationIdGenerator;
import matera.spi.main.domain.service.PrincipalAuthenticationService;
import matera.spi.main.domain.service.ReturnSentService;
import matera.spi.main.domain.service.ReturnSentValidator;
import matera.spi.main.domain.service.TransactionPriorityService;
import matera.spi.main.domain.service.event.EventFactory;
import matera.spi.main.domain.service.event.transaction.ReturnSentEvent;
import matera.spi.main.domain.service.idempotency.IdempotencyExecutor;
import matera.spi.main.domain.service.idempotency.IdempotencyService;
import matera.spi.main.domain.service.messaging.MessagingAvailabilityChecker;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.ReceiptEventRepository;
import matera.spi.main.utils.EntityCreationUtils;
import matera.spi.utils.LocalDateTimeUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.UUID;

import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ReturnApplicationServiceTest {

	private static final String IDEMPOTENCY_ID = "IDEMPOTENCY_ID";
    private static final String SPI_ME_006 = "SPI-ME-006";
    private static final String SPI_ME_015 = "SPI-ME-015";
    private static final String SPI_ME_028 = "SPI-ME-028";
    private static final String INSTANT_PAYMENT_ID = "f844b47b-2d04-4352-b332-74821358a71b";
    private static final String TRANSACTION_CODE = "HIGH";
    private static final String CHARGE_BEARER = "SLEV";
    private static final String SETTLEMENT_METHOD = "CLRG";
    private static final String ID = "fe7962e7-12a5-46de-bf21-22868af37385";
    private static final String END_TO_END_ID = "D13370835202011241244BHg4WzPAcsx";

    @Mock
    private ReturnSentService returnSentService;

    @Mock
    private ReturnSentValidator returnSentValidator;

    @Mock
    private ClientSystemService clientSystemService;

    @Mock
    private MessagingAvailabilityChecker messagingAvailabilityChecker;

    @Mock
    private ReceiptEventRepository receiptEventRepository;

    @Mock
    private TransactionPriorityService transactionPriorityService;

    @Mock
    private EventRepository eventRepository;

    @Mock
    private MainEngineConfiguration mainEngineConfiguration;

    @Mock
    private PrincipalAuthenticationService principalAuthenticationService;

    @Mock
    private IdempotencyService idempotencyService;

    @Mock
	private EventFactory eventFactory;

    @InjectMocks
    private IdempotencyExecutor idempotencyExecutor = new IdempotencyExecutor();

    @InjectMocks
    private ReturnApplicationService returnApplicationService;

    @Captor
    private ArgumentCaptor<ReturnSentEntity> returnSentEntityArgumentCaptor;


    private ReturnSettlementWrapperDTO returnSettlementWrapper = createReturnSettlementWrapperDTO();

    @Test
    void shouldSentReturnSuccess() throws JsonProcessingException {

        ReceiptEventEntity originalReceiptEntity = createReceiptEventEntity(returnSettlementWrapper.getReturnedAmount(), -89, EventStatus.SUCCESS);

        TransactionPriorityEntity transactionPriorityEntity = createpriorityByCode(TRANSACTION_CODE);
        when(returnSentService.priorityByCode(any())).thenReturn(transactionPriorityEntity);

        ReturnSentEvent returnSentEvent = createReturnSentEvent();

        when(returnSentService.createReturn(any(), eq(originalReceiptEntity), eq(returnSettlementWrapper.getReturnedAmount()), eq(returnSettlementWrapper.getOriginSystem()), eq(IDEMPOTENCY_ID))).thenReturn(returnSentEvent);

        when(receiptEventRepository.findByIdWithOriginalEvent(UUID.fromString(INSTANT_PAYMENT_ID))).thenReturn(Optional.of(originalReceiptEntity));

        mockActiveClientSystem();

    	prepareIdempotencyExecutorMock(returnSettlementWrapper.getOriginSystem());

        ReturnResponseDTO responseDTO = returnApplicationService.sentReturn(returnSettlementWrapper, INSTANT_PAYMENT_ID, IDEMPOTENCY_ID);

        assertEquals(END_TO_END_ID, responseDTO.getEndToEndId());
        assertEquals(returnSentEvent.getId(), responseDTO.getReturnId());
    }

    @Test
    void shouldValidateEventNofFound() {
        prepareIdempotencyExecutorMock(returnSettlementWrapper.getOriginSystem());

        BusinessException thrown = Assertions.assertThrows(BusinessException.class, () -> returnApplicationService.sentReturn(returnSettlementWrapper,INSTANT_PAYMENT_ID, IDEMPOTENCY_ID));
        assertTrue(thrown.getCode().contains(SPI_ME_006));

        verifyNoMoreInteractions(eventRepository);

        verify(returnSentService, times(0)).createReturn(any(), any(), any(), any(), eq(IDEMPOTENCY_ID));
    }

    @Test
    void shouldValidateEventNotFound() {
        Optional<EventEntity> eventEntity = Optional.empty();
        when(receiptEventRepository.findByIdWithOriginalEvent(any())).thenReturn(eventEntity);
    	prepareIdempotencyExecutorMock(returnSettlementWrapper.getOriginSystem());

        BusinessException thrown = Assertions.assertThrows(BusinessException.class, () -> returnApplicationService.sentReturn(returnSettlementWrapper,INSTANT_PAYMENT_ID, IDEMPOTENCY_ID));
        assertTrue(thrown.getCode().contains(SPI_ME_006));
    }

    @Test
    void shouldValidateRejectedEventFound() {

    	when(receiptEventRepository.findByIdWithOriginalEvent(any())).thenReturn(Optional.empty());
    	prepareIdempotencyExecutorMock(returnSettlementWrapper.getOriginSystem());

        BusinessException thrown = Assertions.assertThrows(BusinessException.class, () -> returnApplicationService.sentReturn(returnSettlementWrapper,INSTANT_PAYMENT_ID, IDEMPOTENCY_ID));
        assertTrue(thrown.getCode().contains(SPI_ME_006));
    }

    @Test
    void shouldThrowBusinessExceptionWhenStatusFromEventEntityIsNotAllowReturn() {
        BigDecimal originalEventValue = new BigDecimal(7905);
        Integer daysReturnExpiration = -89;
        EventStatus eventStatus = EventStatus.RECEIPT_REJECTED;
        Optional<EventEntity> eventEntity = Optional.of(createReceiptEventEntity(originalEventValue, daysReturnExpiration, eventStatus));
        when(receiptEventRepository.findByIdWithOriginalEvent(any())).thenReturn(eventEntity);
    	prepareIdempotencyExecutorMock(returnSettlementWrapper.getOriginSystem());

        BusinessException thrown = Assertions.assertThrows(BusinessException.class, () -> returnApplicationService.sentReturn(returnSettlementWrapper,INSTANT_PAYMENT_ID, IDEMPOTENCY_ID));
        assertTrue(thrown.getCode().contains(SPI_ME_028));
    }

    @Test
    void shouldVerifyOriginSystem() {

        when(mainEngineConfiguration.isValidateRequestSystem()).thenReturn(true);

        BigDecimal originalEventValue = new BigDecimal(7905);
        Integer daysReturnExpiration = -89;
        EventStatus eventStatus = EventStatus.SUCCESS;
        Optional<EventEntity> eventEntity = Optional.of(createReceiptEventEntity(originalEventValue, daysReturnExpiration, eventStatus));
        when(receiptEventRepository.findByIdWithOriginalEvent(any())).thenReturn(eventEntity);

        doNothing().when(messagingAvailabilityChecker).checkMessagingAvailability();

        doNothing().when(returnSentValidator).validate(any(ReceiptEventEntity.class), any(BigDecimal.class));

        prepareIdempotencyExecutorMock(returnSettlementWrapper.getOriginSystem());

        BusinessException thrown = Assertions.assertThrows(BusinessException.class, () ->
            returnApplicationService.sentReturn(returnSettlementWrapper,INSTANT_PAYMENT_ID, IDEMPOTENCY_ID));

        assertTrue(thrown.getCode().contains(SPI_ME_015));


        verify(returnSentService, times(0)).createReturn(any(), any(), any(), any(), eq(IDEMPOTENCY_ID));
    }

    @Test
    void shouldSentReturnWithInformationAccountHolder() throws JsonProcessingException {

        //Given
        String expectedInformationAccountHolder = "AAAAAAAAAAA";

        ReturnSettlementWrapperDTO returnSettlementWrapperDTO = createDtoWithInformationAccountHolder(expectedInformationAccountHolder);

    	prepareIdempotencyExecutorMock(returnSettlementWrapperDTO.getOriginSystem());

        when(returnSentService.createReturn(any(),any(),any(),any(), eq(IDEMPOTENCY_ID))).thenReturn(mock(ReturnSentEvent.class));

        mockFindByIdWithOriginalEvent();

        mockActiveClientSystem();

        returnApplicationService.sentReturn(returnSettlementWrapperDTO, INSTANT_PAYMENT_ID, IDEMPOTENCY_ID);

        verify(returnSentService).createReturn(returnSentEntityArgumentCaptor.capture(), any(), any(), any(), eq(IDEMPOTENCY_ID));

        ReturnSentEntity returnSentEntity = returnSentEntityArgumentCaptor.getValue();

        assertEquals(expectedInformationAccountHolder, returnSentEntity.getInformationAccountHolderTransaction());
    }

	@Test
    void shouldSentReturnWithoutInformationAccountHolder() throws JsonProcessingException {

        //Given
        ReturnSettlementWrapperDTO returnSettlementWrapperDTO = createDtoWithoutInformationAccountHolder();

    	prepareIdempotencyExecutorMock(returnSettlementWrapperDTO.getOriginSystem());

        when(returnSentService.createReturn(any(),any(),any(),any(), eq(IDEMPOTENCY_ID))).thenReturn(mock(ReturnSentEvent.class));

        mockFindByIdWithOriginalEvent();

        mockActiveClientSystem();

        returnApplicationService.sentReturn(returnSettlementWrapperDTO, INSTANT_PAYMENT_ID, IDEMPOTENCY_ID);

        verify(returnSentService).createReturn(returnSentEntityArgumentCaptor.capture(), any(), any(), any(), eq(IDEMPOTENCY_ID));

        ReturnSentEntity returnSentEntity = returnSentEntityArgumentCaptor.getValue();

        assertNull(returnSentEntity.getInformationAccountHolderTransaction());
    }

    private void prepareIdempotencyExecutorMock(String originSystem) {
		returnApplicationService.setIdempotencyExecutor(idempotencyExecutor);
		when(idempotencyService.decodeServiceExecutionIfExists(any(), any())).thenReturn(Optional.empty());
		when(eventFactory.findByIdempotencyIdAndOriginSystemAndEventType(eq(IDEMPOTENCY_ID), eq(originSystem), any())).thenReturn(Optional.empty());
	}

    private static ReturnSettlementWrapperDTO createReturnSettlementWrapperDTO() {
        ObjectMapper objectMapper = new ObjectMapper();

        String jsonReturn = "{\n" + "  \"originSystem\": \"MIP\",\n" +
                            "  \"returnedAmount\": \"1637.13\",\n" +
                            "  \"additionalInformation\": \"Return sent bank 000000000\",\n" +
                            "  \"returnReasonCode\": \"AM05\",\n"  +
                            "  \"returnReasonInformation\": \"string\", \n" +
                            "  \"demandsImmediateReturn\":  \"true\"\n" + "}";
        ReturnSettlementWrapperDTO returnSettlementWrapperDTO = null;
        try {
            returnSettlementWrapperDTO = objectMapper.readValue(jsonReturn, ReturnSettlementWrapperDTO.class);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        return returnSettlementWrapperDTO;
    }

    private ReceiptEventEntity createReceiptEventEntity(BigDecimal eventValue, Integer daysReturnExpiration,
                                                        EventStatus eventStatus){
        ReceiptEventEntity receiptEventEntity = new ReceiptEventEntity();
        receiptEventEntity.setValue(eventValue);
        receiptEventEntity.setId(UUID.fromString(ID));
        receiptEventEntity.setInitiationTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime().plusDays(daysReturnExpiration));
        receiptEventEntity.setStatus(new EventStatusEntity());
        receiptEventEntity.setReceiptEntity(new ReceiptEntity());
        receiptEventEntity.getReceiptEntity().setReceiverParticipant(EntityCreationUtils.buildReceiverParticipant());
        receiptEventEntity.getReceiptEntity().setPayerParticipant(EntityCreationUtils.buildSenderParticipant());
        receiptEventEntity.getStatus().setCode(eventStatus.getCode());

        PayerAccountEntity payerAccountEntity = new PayerAccountEntity();
        payerAccountEntity.setTaxId("1234567");
        payerAccountEntity.setAccountType("AccounType");
        payerAccountEntity.setBranch("1234567");
        payerAccountEntity.setAccount("1234567");
        payerAccountEntity.setName("payerAccountEntity");

        receiptEventEntity.getTransactionEntity().setPayerAccount(payerAccountEntity);

        ReceiverAccountEntity receiverAccountEntity = new ReceiverAccountEntity();
        receiverAccountEntity.setTaxId("1234567");
        receiverAccountEntity.setAccountType("AccounType");
        receiverAccountEntity.setBranch("1234567");
        receiverAccountEntity.setAccount("1234567");

        receiptEventEntity.getTransactionEntity().setReceiverAccount(receiverAccountEntity);

        return receiptEventEntity;
    }

    private ReturnSentEvent createReturnSentEvent() {
        ReturnSentEventEntity eventEntity = new ReturnSentEventEntity();
        eventEntity.setId(UUID.fromString(INSTANT_PAYMENT_ID));
        ReturnSentEntity returnSentEntity = new ReturnSentEntity();
        returnSentEntity.setEndToEndId(END_TO_END_ID);
        eventEntity.setReturnSentEntity(returnSentEntity);
        return new ReturnSentEvent(eventEntity);
    }

    private TransactionPriorityEntity createpriorityByCode(String settlementPriority) {
        TransactionPriorityEntity expected = new TransactionPriorityEntity();
        expected.setCode("1000");
        expected.setDescription(settlementPriority);
        return expected;
    }

    public ReturnSentEntity  getReturnSentEntity(ReturnSettlementWrapperDTO returnSettlementWrapperDTO, ReceiptEventEntity originalReceiptEventEntity) {
        ReturnSentEntity returnSentEntity = new ReturnSentEntity();
        returnSentEntity.setPayerParticipant(originalReceiptEventEntity.getTransactionEntity().getReceiverParticipant());
        returnSentEntity.setReceiverParticipant(originalReceiptEventEntity.getTransactionEntity().getPayerParticipant());
        returnSentEntity.setEndToEndId(CorrelationIdGenerator.generateCorrelactionIdPacs004(returnSentEntity.getPayerParticipant().getIspb().toString()));
        returnSentEntity.setAdditionalInformation(returnSettlementWrapper.getAdditionalInformation());
        returnSentEntity.setChargeBearer(CHARGE_BEARER);
        returnSentEntity.setReturnReasonInformationCode(returnSettlementWrapper.getReturnReasonCode());
        returnSentEntity.setSettlementMethod(SETTLEMENT_METHOD);
        returnSentEntity.setPriority(createpriorityByCode(TRANSACTION_CODE));
        return returnSentEntity;
    }


    private ClientSystemEntity createClientSystemEntity() {
        ClientSystemEntity clientSystemEntity = new ClientSystemEntity();
        clientSystemEntity.setActive(true);
        clientSystemEntity.setClientId("123456789");
        clientSystemEntity.setCodeSystem("matera");
        clientSystemEntity.setId(UUID.fromString("f76526be-bae4-11ea-b3de-0242ac130004"));
        clientSystemEntity.setNameSystem("MIP");
        clientSystemEntity.setSecret("secretTest");
        clientSystemEntity.setUrlCallback("https://urlCallback.com");
        clientSystemEntity.setUrlOAuth("https://UrlOAuth.com");
        return clientSystemEntity;
    }

    @NotNull
    private ReceiptEventEntity createReceiptEventEntity() {
        BigDecimal originalEventValue = new BigDecimal(7905);
        Integer daysReturnExpiration = -89;
        EventStatus eventStatus = EventStatus.SUCCESS;

        return createReceiptEventEntity(originalEventValue, daysReturnExpiration, eventStatus);
    }

    private ReturnSettlementWrapperDTO createDtoWithoutInformationAccountHolder() {

        return createDtoWithInformationAccountHolder(null);
    }

    private ReturnSettlementWrapperDTO createDtoWithInformationAccountHolder(String expectedInformationAccountHolder) {

        return new ReturnSettlementWrapperDTO()
            .informationAccountHolder(expectedInformationAccountHolder)
            .returnedAmount(new BigDecimal("1"))
            .originSystem("ORIGIN SYSTEM");
    }

    private void mockFindByIdWithOriginalEvent() {
        ReceiptEventEntity receiptEventEntity = createReceiptEventEntity();

        when(receiptEventRepository.findByIdWithOriginalEvent(any())).thenReturn(Optional.of(receiptEventEntity));
    }

    private void mockActiveClientSystem() {
        ClientSystemEntity clientSystemEntity = new ClientSystemEntity();
        clientSystemEntity.setActive(true);
        when(clientSystemService.findClientSystemByCodeSystem(any())).thenReturn(clientSystemEntity);
    }
}
