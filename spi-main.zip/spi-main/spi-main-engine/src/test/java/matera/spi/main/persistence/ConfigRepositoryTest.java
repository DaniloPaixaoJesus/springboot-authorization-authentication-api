package matera.spi.main.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.ConfigEntity;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;

@IntegrationTest
class ConfigRepositoryTest  {

    @Autowired
    private ConfigRepository configRepository;

    private ConfigEntity lastConfig;

    @BeforeEach
    void beforeEach() {
        lastConfig = configRepository.findAll().get(0);
        configRepository.deleteAll();
    }

    @AfterEach
    void afterEach() {
        configRepository.deleteAll();
        configRepository.saveAndFlush(lastConfig);
    }

    @Test
    void shouldBeFindEntityWhenInserted() {
        ConfigEntity expected = new ConfigEntity();
        expected.setIspb(11111111);
        expected.setBalanceValidationThreshold(BigDecimal.valueOf(2222222.33));
        expected.setCustomerCredTransactionType(9);
        expected.setCustomerDebTransactionType(0);
        expected.setPmtSlaTime(44);
        expected.setPmtConfirmRetryAmount(55);
        expected.setPmtConfirmRetryInterval(66);
        expected.setReceiveConfirmRetryAmount(777);
        expected.setReceiveConfirmRetryInterval(88);
        expected.setCustDrawbSentTransType(587);
        expected.setCustDrawbReceivedTransType(1088);
        expected.setQrcodeCredTransactionType(1258);
        configRepository.saveAndFlush(expected);

        ConfigEntity actual = configRepository.findById(expected.getId()).orElse(null);
        Assertions.assertEquals(expected, actual);
    }

}
