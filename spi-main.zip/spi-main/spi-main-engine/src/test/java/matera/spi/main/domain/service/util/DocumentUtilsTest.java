package matera.spi.main.domain.service.util;

import matera.spi.utils.DocumentUtils;
import org.apache.commons.lang.StringUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.stream.Stream;

import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static org.assertj.core.api.Assertions.assertThat;

class DocumentUtilsTest {

	private static final String ADMI_002_SPI_1_2_SPI_R = "admi.002/admi.002.spi.1.2_SPI_R_msg.xml";
	private static final String PACS_002_SPI_1_2_ERRO_1_MSG = "pacs.002/pacs.002.spi.1.2_ERRO_1_msg.xml";
	private static final String PACS_002_SPI_1_2_PSP_CREDOR_10_MSG = "pacs.002/pacs.002.spi.1.2_PSP_CREDOR_10_msg.xml";
	private static final String PACS_002_SPI_1_2_SPI_10_MSG = "pacs.002/pacs.002.spi.1.2_SPI_10_msg.xml";
	private static final String PACS_008_SPI_1_2_CONTA_1_MSG = "pacs.008/pacs.008.spi.1.2_CONTA_1_msg.xml";
	private static final String PACS_008_SPI_1_2_END_1_MSG = "pacs.008/pacs.008.spi.1.2_END_1_msg.xml";
	private static final String PACS_008_SPI_1_1_WITH_NS_ALIAS = "pacs.008/pacs.008.spi.1.1_with_namespace_prefix.xml";
	private static final String EXPECTED_END_TO_END_ID = "E00539039202002170828063aec68f6e";


	private static Stream<Arguments> providedXMLs() {

		return Stream.of(ADMI_002_SPI_1_2_SPI_R,
				PACS_002_SPI_1_2_ERRO_1_MSG,
				PACS_002_SPI_1_2_PSP_CREDOR_10_MSG,
				PACS_002_SPI_1_2_SPI_10_MSG,
				PACS_008_SPI_1_2_CONTA_1_MSG,
				PACS_008_SPI_1_2_END_1_MSG,
				PACS_008_SPI_1_1_WITH_NS_ALIAS)
				.map(Arguments::of);
	}


	@DisplayName("Converting a String to Document to String again and verifying it's keeps the same")
	@ParameterizedTest
	@MethodSource("providedXMLs")
	void shouldCreateDocumentAndExportToString(String file) {
		String xml = getStringFromXmlFile(file);
		Document document = DocumentUtils.stringToXmlDocument(xml);
		String exportedXmlString = DocumentUtils.nodeToXmlString(document);
		assertThat(xml).isEqualTo(exportedXmlString);
	}

	@DisplayName("Selecting elements by expression from Document that isn't namespace aware")
	@ParameterizedTest(name = "file: {0} | expression: {1} | elements number: {2}")
	@CsvFileSource(resources = "/parameterized/csv/documentUtilsEntries.csv", numLinesToSkip = 1)
	void shouldFindTheNodeListWhenGivenADocumentThatIsNotNamespaceAware(String file, String expression, int elementsNumber, String nodeName) {
		String xml = getStringFromXmlFile(file);
		Document document = DocumentUtils.stringToXmlDocument(xml);
		NodeList nodeList = DocumentUtils.getElementsByExpression(document, expression);

		assertThat(elementsNumber).isEqualTo(nodeList.getLength());
		assertThat(nodeName).isEqualTo(nodeList.item(0).getNodeName());
	}

	@DisplayName("Selecting elements by expression from a namespace aware Document")
	@ParameterizedTest(name = "file: {0} | expression: {1} | elements number: {2}")
	@CsvFileSource(resources = "/parameterized/csv/documentUtilsEntries.csv", numLinesToSkip = 1)
	void shouldFindTheNodeListWhenGivenANamespaceAwareDocument(String file, String expression, int elementsNumber, String nodeName) {
		String xml = getStringFromXmlFile(file);
		Document document = DocumentUtils.stringToXmlDocument(xml, true);
		NodeList nodeList = DocumentUtils.getElementsByExpression(document, expression, true);

		assertThat(elementsNumber).isEqualTo(nodeList.getLength());
		assertThat(nodeName).isEqualTo(nodeList.item(0).getNodeName());
		String localName = StringUtils.substringAfterLast(expression,"/");
		assertThat(localName).isEqualTo(nodeList.item(0).getLocalName());
	}

	@DisplayName("when given an expression getFirstElementTextContentByExpression should return the first found node text context")
	@Test
	void shouldGetTheFirstElementTextContentWhenADocumentWithExpressionItsGiven() {
		String xml = getStringFromXmlFile(PACS_008_SPI_1_2_CONTA_1_MSG);
		String expression = "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/PmtId/EndToEndId";
		Document document = DocumentUtils.stringToXmlDocument(xml);
		String nodeContent = DocumentUtils.getFirstElementTextContentByExpression(document, expression);

		assertThat(EXPECTED_END_TO_END_ID).isEqualTo(nodeContent);
	}

	@DisplayName("when given an expression getFirstElementTextContentByExpression should return the first found node text context from the current node")
	@Test
	void shouldGetTheFirstElementTextContentWhenANodeWithExpressionItsGiven() {
		String xml = getStringFromXmlFile(PACS_008_SPI_1_2_CONTA_1_MSG);
		String expression = "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/PmtId";
		Document document = DocumentUtils.stringToXmlDocument(xml);
		Node node = DocumentUtils.getElementsByExpression(document, expression).item(0);

		String contentExpression = "EndToEndId";
		String nodeContent = DocumentUtils.getFirstElementTextContentByExpression(node, contentExpression);

		assertThat(EXPECTED_END_TO_END_ID).isEqualTo(nodeContent);

		contentExpression = "./EndToEndId";
		nodeContent = DocumentUtils.getFirstElementTextContentByExpression(node, contentExpression);

		assertThat(EXPECTED_END_TO_END_ID).isEqualTo(nodeContent);
	}

	@DisplayName("when given an expression of a node that not exist getFirstElementTextContentByExpression should returns an empty string")
	@Test
	void shouldReturnAnEmptyStringWhenNotFoundANodeDefinedByTheExpression() {
		String xml = getStringFromXmlFile(PACS_008_SPI_1_2_CONTA_1_MSG);
		String expression = "/some/invalid/path";
		Document document = DocumentUtils.stringToXmlDocument(xml);
		String nodeContent = DocumentUtils.getFirstElementTextContentByExpression(document, expression);

		assertThat("").isEqualTo(nodeContent);
	}
}