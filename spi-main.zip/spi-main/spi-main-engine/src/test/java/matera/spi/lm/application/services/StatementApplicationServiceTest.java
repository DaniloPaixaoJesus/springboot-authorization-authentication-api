package matera.spi.lm.application.services;

import matera.spi.dto.ConciliationPeriodRequiredDTO;
import matera.spi.dto.PageableStatementsDTO;
import matera.spi.dto.StatementDTO;
import matera.spi.lm.application.service.statements.DirectStatementsApiService;
import matera.spi.lm.application.service.statements.StatementConciliationService;
import matera.spi.lm.application.service.validation.LocalDateTimeValidation.LocalDateTimeValidator;
import matera.spi.lm.application.service.validation.PageableValidation.PageableValidator;
import matera.spi.lm.config.CsvStorageConfiguration;
import matera.spi.lm.domain.model.event.IpAccountStatementQueryDetailsEntity;
import matera.spi.lm.domain.model.event.IpAccountStatementQueryEventEntity;
import matera.spi.lm.exception.LiquidityManagementException;
import matera.spi.lm.persistence.IpAccountStatementQueryDetailsRepository;
import matera.spi.main.domain.model.event.EventStatusEntity;
import matera.spi.mainengine.utils.Asserts;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationContext;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static org.hamcrest.core.Is.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class StatementApplicationServiceTest {

    private static final UUID DETAIL_UUID = UUID.randomUUID();
    private static final UUID EVENT_UUID = UUID.randomUUID();

    private Resource resource;

    @InjectMocks
    private DirectStatementsApiService statementsApiServiceImpl;

    @Mock
    private PageableValidator pageableValidator;

    @Mock
    private LocalDateTimeValidator localDateTimeValidator;

    @Mock
    private IpAccountStatementQueryDetailsRepository statementRepository;

    @Mock
    private CsvStorageConfiguration csvStorageConfiguration;

    @Mock
    private ApplicationContext applicationContext;

    @Mock
    private StatementConciliationService statementConciliationService;

    @BeforeEach
    void beforeEach() {
    }

    @Test
    void shouldFillCorrectlyPageableFields() {
        when(statementRepository.findByParams(any(), any(), any())).thenReturn(mockRepositoryResponse());
        LocalDateTime dateTimeNow = LocalDateTime.now();
        PageableStatementsDTO statements = statementsApiServiceImpl.getStatements(dateTimeNow, dateTimeNow, 0, 10);

        assertThat(statements.getContent(), hasSize(1));
        assertThat(statements.getPageable(), is(not(nullValue())));
        assertThat(statements.getTotalPages(), is(1));
        assertThat(statements.getTotalElements(), is(1L));
        assertThat(statements.getLast(), is(true));
        assertThat(statements.getFirst(), is(true));
        assertThat(statements.getSort(), is(not(nullValue())));
        assertThat(statements.getNumber(), is(0));
        assertThat(statements.getNumberOfElements(), is(1));
        assertThat(statements.getSize(), is(10));
        assertThat(statements.getEmpty(), is(false));
    }

    @Test
    void shouldReturnListConciliationPeriodRequired() throws Exception {

        List<IpAccountStatementQueryDetailsEntity> listDetailsEntity = new ArrayList<>();

        listDetailsEntity.add(mockDetailsEntityConciliationPeriod(
            LocalDateTime.of(2020,6, 1, 8, 0, 0),
            LocalDateTime.of(2020,6, 8, 12, 0, 0)));

        List<ConciliationPeriodRequiredDTO> listConciliationPeriodRequired = new ArrayList<>();

        listConciliationPeriodRequired.add(mockConciliationPeriodRequiredDTO(
            LocalDateTime.of(2020, 6, 8,12, 0, 0),
            LocalDateTime.of(2020, 6, 20, 21, 0,0)));

        when(statementRepository.findByStatus(any(), any(), any())).thenReturn(listDetailsEntity);
        when(statementConciliationService.extractPeriodNotConciliated(any(), any(), any())).thenReturn(listConciliationPeriodRequired);

        LocalDateTime startTime = LocalDateTime.of(2020,6, 1, 8, 0, 0);
        LocalDateTime endTime = LocalDateTime.of(2020,6, 20, 21, 0, 0);

        List<ConciliationPeriodRequiredDTO> result = statementsApiServiceImpl.getCheckConciliatedTransaction(startTime, endTime);

        Asserts.assertEquals(LocalDateTime.of(2020, 6, 8,12, 0, 0), result.get(0).getStartPeriodTimestamp());
        Asserts.assertEquals(LocalDateTime.of(2020, 6, 20, 21, 0,0), result.get(0).getEndPeriodTimestamp());

    }

    @Test
    void shouldReturnListConciliationPeriodRequiredWithReturnOfRepositoryEmpty() throws Exception {

        List<ConciliationPeriodRequiredDTO> listConciliationPeriodRequired = new ArrayList<>();

        listConciliationPeriodRequired.add(mockConciliationPeriodRequiredDTO(
            LocalDateTime.of(2020,6, 6, 17, 0, 0),
            LocalDateTime.of(2020,6, 8, 12, 0, 0)));

        when(statementRepository.findByStatus(any(), any(), any())).thenReturn(Collections.EMPTY_LIST);
        when(statementConciliationService.createNotConciliatedFullPeriod(any(), any())).thenReturn(listConciliationPeriodRequired);

        LocalDateTime startTime = LocalDateTime.of(2020,6, 6, 17, 0, 0);
        LocalDateTime endTime = LocalDateTime.of(2020,6, 8, 12, 0, 0);

        List<ConciliationPeriodRequiredDTO> result = statementsApiServiceImpl.getCheckConciliatedTransaction(startTime, endTime);

        Asserts.assertEquals(LocalDateTime.of(2020,6, 6, 17, 0, 0), result.get(0).getStartPeriodTimestamp());
        Asserts.assertEquals(LocalDateTime.of(2020,6, 8, 12, 0, 0), result.get(0).getEndPeriodTimestamp());

    }

    @Test
    void shouldReturnListConciliationPeriodRequiredWithreturnOfException() throws Exception {

        String expectedMessage = "SPI-LM-034 - []";
        doThrow(LiquidityManagementException.class).when(statementRepository).findByStatus(any(), any(), any());

        LocalDateTime startTime = LocalDateTime.of(2020,6, 6, 17, 0, 0);
        LocalDateTime endTime = LocalDateTime.of(2020,6, 8, 12, 0, 0);

        try {
            statementsApiServiceImpl.getCheckConciliatedTransaction(startTime, endTime);
        } catch (Exception e) {
            Asserts.assertEquals(expectedMessage, e.getLocalizedMessage());
        }

    }

    @Test
    void shouldFillCorrectlyStatementDto() {
        when(statementRepository.findByParams(any(), any(), any())).thenReturn(mockRepositoryResponse());
        LocalDateTime dateTimeNow = LocalDateTime.now();
        PageableStatementsDTO statements = statementsApiServiceImpl.getStatements(dateTimeNow, dateTimeNow, 0, 10);

        StatementDTO statementDTO = statements.getContent().get(0);

        assertThat(statementDTO.getStatementId(), is(DETAIL_UUID));
        assertThat(statementDTO.getEventId(), is(EVENT_UUID));
        assertThat(statementDTO.getQueryTimestamp(), is(LocalDateTime.of(2020,6, 10, 12, 10, 0)));
        assertThat(statementDTO.getStartTimestampUtc(), is(LocalDateTime.of(2020,6, 10, 10, 5, 5)));
        assertThat(statementDTO.getEndTimestampUtc(), is(LocalDateTime.of(2020,6, 10, 14, 37, 14)));
        assertThat(statementDTO.getReportInformation(), is("Additional Report Information"));
        assertThat(statementDTO.getStatus(), is(not(nullValue())));
    }

    @Test
    void shouldPassCorrectlySortToRepository() {
        when(statementRepository.findByParams(any(), any(), any())).thenReturn(mockRepositoryResponse());
        LocalDateTime dateTimeNow = LocalDateTime.now();
        statementsApiServiceImpl.getStatements(dateTimeNow, dateTimeNow, 0, 10);

        ArgumentCaptor<Pageable> pageableArgumentCaptor = ArgumentCaptor.forClass(Pageable.class);
        verify(statementRepository).findByParams(pageableArgumentCaptor.capture(), any(), any());
        Sort.Order order = pageableArgumentCaptor.getValue().getSort().get().findFirst().get();

        assertThat(order.getDirection(), is(Sort.Direction.DESC));
        assertThat(order.getProperty(), is("creationDateTime"));
    }

    private Page<IpAccountStatementQueryDetailsEntity> mockRepositoryResponse() {
        final IpAccountStatementQueryDetailsEntity detailsEntity = mockDetailsEntity();

        PageRequest pageable = PageRequest.of(0, 10, Sort.by(Sort.Direction.DESC, "startTimestampUtc"));
        return new PageImpl<>(Collections.singletonList(detailsEntity), pageable, 1L);
    }

    private IpAccountStatementQueryDetailsEntity mockDetailsEntity() {
        EventStatusEntity eventStatusEntity = new EventStatusEntity();
        eventStatusEntity.setFinalStatus(false);
        eventStatusEntity.setCode(1);
        eventStatusEntity.setDescription("Payment Initialized");

        IpAccountStatementQueryEventEntity eventEntity = new IpAccountStatementQueryEventEntity();
        eventEntity.setId(EVENT_UUID);
        eventEntity.setStatus(eventStatusEntity);

        IpAccountStatementQueryDetailsEntity detailsEntity = new IpAccountStatementQueryDetailsEntity();
        detailsEntity.setUuid(DETAIL_UUID);
        detailsEntity.setStartTimestampUtc(LocalDateTime.of(2020,6, 10, 10, 5, 5));
        detailsEntity.setEndTimestampUtc(LocalDateTime.of(2020,6, 10, 14, 37, 14));
        detailsEntity.setCreationDateTime(LocalDateTime.of(2020,6, 10, 12, 10, 0));
        detailsEntity.setAdditionalReportInformation("Additional Report Information");
        detailsEntity.setNumberOfEntries(300);
        detailsEntity.setFileUri("Path to file");
        detailsEntity.setIpAccountStatementQueryEventEntity(eventEntity);

        return detailsEntity;
    }

    private IpAccountStatementQueryDetailsEntity mockDetailsEntityConciliationPeriod(LocalDateTime startTime, LocalDateTime EndTime) {

        IpAccountStatementQueryDetailsEntity detailsEntity = new IpAccountStatementQueryDetailsEntity();
        detailsEntity.setStartTimestampUtc(startTime);
        detailsEntity.setEndTimestampUtc(EndTime);

        return detailsEntity;
    }

    private ConciliationPeriodRequiredDTO mockConciliationPeriodRequiredDTO(LocalDateTime startTime, LocalDateTime EndTime) {

        ConciliationPeriodRequiredDTO onciliationPeriodRequiredDTO = new ConciliationPeriodRequiredDTO();
        onciliationPeriodRequiredDTO.setStartPeriodTimestamp(startTime);
        onciliationPeriodRequiredDTO.setEndPeriodTimestamp(EndTime);

        return onciliationPeriodRequiredDTO;

    }

}
