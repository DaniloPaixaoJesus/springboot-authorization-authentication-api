package matera.spi.main.application.service.mapper;

import matera.spi.dto.IpAccountOwnerDTO;
import matera.spi.dto.IpAccountOwnerFullDTO;
import matera.spi.dto.IpAccountOwnerRequestDTO;
import matera.spi.main.domain.model.IpAccountOwnerEntity;
import matera.spi.main.domain.model.event.IpAccountOwnerStatus;
import matera.spi.main.utils.EntityCreationUtils;
import matera.spi.utils.LocalDateTimeUtils;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.UUID;

import static matera.spi.main.application.service.mapper.IpAccountOwnerUIMapper.mapEntityToIpAccountOwnerDTO;
import static matera.spi.main.application.service.mapper.IpAccountOwnerUIMapper.mapEntityToIpAccountOwnerFullDTO;
import static matera.spi.main.application.service.mapper.IpAccountOwnerUIMapper.mapIpAccountOwnerRequestToEntity;
import static matera.spi.main.utils.EntityCreationUtils.DIRECTOR_EMAIL;
import static matera.spi.main.utils.EntityCreationUtils.DIRECTOR_MOBILE;
import static matera.spi.main.utils.EntityCreationUtils.DIRECTOR_NAME;
import static matera.spi.main.utils.EntityCreationUtils.DIRECTOR_PHONE;
import static matera.spi.main.utils.EntityCreationUtils.DIRECTOR_TAX_ID;
import static matera.spi.main.utils.EntityCreationUtils.EMPLOYEE_EMAIL;
import static matera.spi.main.utils.EntityCreationUtils.EMPLOYEE_FAX;
import static matera.spi.main.utils.EntityCreationUtils.EMPLOYEE_MOBILE;
import static matera.spi.main.utils.EntityCreationUtils.EMPLOYEE_PHONE;
import static matera.spi.main.utils.EntityCreationUtils.PASSPHRASE;
import static matera.spi.main.utils.EntityCreationUtils.buildIpAccountOwnerEntityWithAllFields;

import static org.assertj.core.api.Assertions.assertThat;

class IpAccountOwnerUIMapperTest {

    @Test
    void shouldBeAbleToMapIpAccountOwnerRequestDTOToAnEntity() {
        IpAccountOwnerRequestDTO requestDTO = EntityCreationUtils.buildIpAccountOwnerRequestDTOWithAllFields();
        IpAccountOwnerEntity expectedIpAccountOwnerEntity = buildIpAccountOwnerEntityWithAllFields();
        expectedIpAccountOwnerEntity.setInitiationTimestamp(null);
        assertThat(mapIpAccountOwnerRequestToEntity(requestDTO)).isEqualTo(expectedIpAccountOwnerEntity);
    }

    @Test
    void shouldNotMapEmptyNonRequiredFieldsToEntity() {
        IpAccountOwnerRequestDTO requestDTO = EntityCreationUtils.buildIpAccountOwnerRequestDTOWithAllFields();
        requestDTO.setDirectorMobile("");
        requestDTO.setEmployeeMobile("");
        requestDTO.setEmployeeFax("");

        IpAccountOwnerEntity mappedEntity = mapIpAccountOwnerRequestToEntity(requestDTO);
        assertThat(mappedEntity.getDirectorMobile()).isNull();
        assertThat(mappedEntity.getEmployeeMobile()).isNull();
        assertThat(mappedEntity.getEmployeeFax()).isNull();
    }

    @Test
    void shouldBeAbleToMapTheEntityToIpAccountOwnerDTO() {
        LocalDateTime now = LocalDateTimeUtils.getUtcLocalDateTime();
        IpAccountOwnerEntity ipAccountOwnerEntity = buildIpAccountOwnerEntityWithAllFields();
        ipAccountOwnerEntity.setStatus(IpAccountOwnerStatus.ACTIVE);
        ipAccountOwnerEntity.setInitiationTimestamp(now);
        ipAccountOwnerEntity.setClearingTimestamp(now);

        IpAccountOwnerDTO expectedDTO = buildExpectedIpAccountOwnerDTO();
        expectedDTO.status(IpAccountOwnerStatus.ACTIVE.name());
        expectedDTO.setClearingDateTime(now);
        assertThat(mapEntityToIpAccountOwnerDTO(ipAccountOwnerEntity)).isEqualTo(expectedDTO);
    }

    @Test
    void shouldBeAbleToMapTheEntityToIpAccountOwnerFullDTO() {
        LocalDateTime now = LocalDateTimeUtils.getUtcLocalDateTime();
        IpAccountOwnerEntity ipAccountOwnerEntity = buildIpAccountOwnerEntityWithAllFields();
        ipAccountOwnerEntity.setStatus(IpAccountOwnerStatus.ACTIVE);
        ipAccountOwnerEntity.setInitiationTimestamp(now);
        ipAccountOwnerEntity.setClearingTimestamp(now);
        UUID eventId = UUID.randomUUID();
        ipAccountOwnerEntity.setEventId(eventId);

        IpAccountOwnerFullDTO expectedDTO = new IpAccountOwnerFullDTO();
        IpAccountOwnerDTO ipAccountOwnerDTO = buildExpectedIpAccountOwnerDTO();
        ipAccountOwnerDTO.status(IpAccountOwnerStatus.ACTIVE.name());
        ipAccountOwnerDTO.setClearingDateTime(now);
        expectedDTO.setEventId(eventId.toString());
        expectedDTO.setIpAccountOwner(ipAccountOwnerDTO);
        assertThat(mapEntityToIpAccountOwnerFullDTO(ipAccountOwnerEntity)).isEqualTo(expectedDTO);
    }

    public static IpAccountOwnerDTO buildExpectedIpAccountOwnerDTO(){
        return new IpAccountOwnerDTO()
            .directorName(DIRECTOR_NAME)
            .directorEmail(DIRECTOR_EMAIL)
            .directorPhone(DIRECTOR_PHONE)
            .directorMobile(DIRECTOR_MOBILE)
            .directorTaxId(DIRECTOR_TAX_ID)
            .passPhrase(PASSPHRASE)
            .employeeEmail(EMPLOYEE_EMAIL)
            .employeePhone(EMPLOYEE_PHONE)
            .employeeMobile(EMPLOYEE_MOBILE)
            .employeeFax(EMPLOYEE_FAX);
    }

}
