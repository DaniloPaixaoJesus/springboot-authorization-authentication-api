package matera.spi.lm.application.services;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.BalanceLocalIPAccountDTO;
import matera.spi.lm.application.service.balanceIPAccountService.DirectBalanceIPAccountService;
import matera.spi.main.domain.service.transaction.AccountsTransactionDispatcher;
import matera.spi.main.domain.service.transaction.MirrorIPAccount;
import matera.spi.main.domain.service.util.BalanceIPAccountUtil;
import matera.spi.main.persistence.BalanceAccountPiRepository;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;

import static org.hamcrest.Matchers.comparesEqualTo;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.doReturn;

import static java.math.BigDecimal.TEN;


@IntegrationTest
public class BalanceIPAccountServiceTest  {

    protected static final BigDecimal CINCO = BigDecimal.valueOf(5);

    @Autowired
    private DirectBalanceIPAccountService balanceIPAccountService;

    @Autowired
    private BalanceAccountPiRepository repository;

    @Autowired
    private BalanceIPAccountUtil balanceUtil;

    @Spy
    private MirrorIPAccount mockedMirrorIPAccount;

    @Autowired
    private MirrorIPAccount mirrorIPAccountBean;

    @Autowired
    private AccountsTransactionDispatcher accountsTransactionDispatcher;

    @BeforeEach
    public void init() {
        deleteAllRegistryInDB();
        accountsTransactionDispatcher.setMirrorIPAccount(mockedMirrorIPAccount);
    }

    @AfterEach
    void tearDown() {
        accountsTransactionDispatcher.setMirrorIPAccount(mirrorIPAccountBean);
    }

    @Test
    public void shouldReturnZeroValuesWhenDontHaveAnyValueStoredInDB() {
        doReturn(BigDecimal.ZERO).when(mockedMirrorIPAccount).queryBalance();
        final BalanceLocalIPAccountDTO dto = balanceIPAccountService.getBalanceAccountIP();

        assertNotNull(dto);
        assertThat(dto.getValue(), comparesEqualTo(BigDecimal.ZERO));
    }

    @Test
    public void shouldReturnLastBalanceValueWhenHasAtLeastOneInsert() {
        doReturn(BigDecimal.TEN).when(mockedMirrorIPAccount).queryBalance();
        balanceUtil.insertOneCredit(TEN);
        final BalanceLocalIPAccountDTO dto = balanceIPAccountService.getBalanceAccountIP();

        assertNotNull(dto);
        assertThat(dto.getValue(), comparesEqualTo(TEN));
    }

    @Test
    public void shouldReturnLastBalanceValueWhenHasDebitTransaction() {
        doReturn(CINCO).when(mockedMirrorIPAccount).queryBalance();
        balanceUtil.insertOneCredit(TEN);
        balanceUtil.insertOneDebit(CINCO);
        final BalanceLocalIPAccountDTO dto = balanceIPAccountService.getBalanceAccountIP();

        assertNotNull(dto);
        assertThat(dto.getValue(), comparesEqualTo(CINCO));
    }

    private void deleteAllRegistryInDB() {
        repository.deleteAll();
    }

}
