package matera.spi.main.dto;

import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.utils.DocumentUtils;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;

import java.util.List;

import static matera.spi.main.utils.EntityCreationUtils.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class MessageReceiverProcessorEventDTOTest {

	private static final Document DOCUMENT = DocumentUtils.stringToXmlDocument("<Envelope/>");
    private static final int CONSUMABLE_MESSAGE_INDEXES = 1;

    @Test
	void shouldGetTheCorrectValuesFromTheMessageEntityWhenGivenAMessageReceiverDTO() {
		MessageEntity messageEntity = buildPacs008MessageEntity();
		MessageReceiverEventDTO dto = new MessageReceiverEventDTO(messageEntity, DOCUMENT,
                                                                  List.of(CONSUMABLE_MESSAGE_INDEXES));

		assertThat(dto.getMessageElementsXPath()).isEqualTo(PACS_008_REPLY_ELEMENT);
		assertThat(dto.getConsumableMessageIndexes().get(0)).isEqualTo(CONSUMABLE_MESSAGE_INDEXES);
	}

	@Test
	void shouldThrowInvalidMessageReceiverDTOExceptionWhenMessageEntityDoesNotHaveMessageTypeEntity() {
		MessageEntity messageEntity = new MessageEntity();
		MessageReceiverEventDTO dto = new MessageReceiverEventDTO(messageEntity, DOCUMENT,
                                                                  List.of(CONSUMABLE_MESSAGE_INDEXES));

		assertThatThrownBy(dto::getMessageElementsXPath)
				.isInstanceOf(IllegalStateException.class)
				.hasMessage("%s does not have a message type associated with.", messageEntity);
	}

}
