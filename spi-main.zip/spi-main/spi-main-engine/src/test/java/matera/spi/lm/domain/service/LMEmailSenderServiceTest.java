package matera.spi.lm.domain.service;

import matera.spi.lm.application.service.LMEmailSenderService;
import matera.spi.lm.application.service.email.SimpleTextEmailBodyBuilder;
import matera.spi.main.apisInterface.EmailNotificationApiService;
import matera.spi.main.domain.model.EmailNotificationEntity;
import matera.spi.main.domain.service.EmailSenderService;
import matera.spi.main.email.dto.EmailDTO;
import matera.spi.main.email.port.EmailSender;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class LMEmailSenderServiceTest {

    private static final LocalDateTime TIME_REGISTER = LocalDateTime.of(2020, 1, 1, 1, 1);

    @InjectMocks
    private LMEmailSenderService emailSenderService;

    @InjectMocks
    private EmailSenderService mainSenderService;

    @Mock
    private EmailSender emailSender;

    @Mock
    private EmailNotificationApiService emailNotificationApiService;

    @BeforeEach
    void beforeEach() {
        emailSenderService.setEmailSenderApiService(mainSenderService);
        when(emailNotificationApiService.findAll()).thenReturn(emailsDto());
    }

    @Test
    void shoulPassCorrectlyArgumentsToEmailSender() {
        emailSenderService.sendEmail("Subject", new SimpleTextEmailBodyBuilder("Body"));

        ArgumentCaptor<EmailDTO> emailDTOCaptor = ArgumentCaptor.forClass(EmailDTO.class);
        verify(emailSender, times(1)).sendEmail(emailDTOCaptor.capture());

        EmailDTO dtoArgument = emailDTOCaptor.getValue();
        assertThat(dtoArgument.getEmails(), hasSize(1));
        assertThat(dtoArgument.getEmails().get(0), is("email@domain.com"));
        assertThat(dtoArgument.getSubject(), is("Subject"));
        assertThat(dtoArgument.getText(), is("Body"));
    }

    private List<EmailNotificationEntity> emailsDto() {
        EmailNotificationEntity emailNotificationDTO = new EmailNotificationEntity();
        emailNotificationDTO.setUuid(UUID.randomUUID());
        emailNotificationDTO.setEmail("email@domain.com");
        emailNotificationDTO.setDateTimeRegister(TIME_REGISTER);
        emailNotificationDTO.setIdentification("identification");

        return Collections.singletonList(emailNotificationDTO);
    }

}
