package matera.spi.main.application.service;

import com.matera.commons.utils.exception.BusinessException;
import matera.spi.main.config.MainEngineConfiguration;
import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.domain.model.event.EventStatus;
import matera.spi.main.domain.model.event.EventStatusEntity;
import matera.spi.main.domain.model.event.transaction.ReceiptEventEntity;
import matera.spi.main.domain.model.transaction.ReceiptEntity;
import matera.spi.main.domain.service.ReturnSentValidator;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.ParticipantRepository;
import matera.spi.utils.LocalDateTimeUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.UUID;

import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ReturnSentValidatorTest {

    public static final String SPI_ME_002 = "SPI-ME-002";
    public static final String SPI_ME_007 = "SPI-ME-007";
    public static final String SPI_ME_008 = "SPI-ME-008";
    public static final String SPI_ME_019 = "SPI-ME-019";

    public static final int PAYER_ISPB = 99999010;
    public static final int RECEIVER_ISPB = 59979010;

    public static final UUID GENERATED_UUID = UUID.fromString("15e22912-af59-11ea-b3de-0242ac130004");


    @InjectMocks
    private ReturnSentValidator returnSentValidator;

    @Mock
    private EventRepository eventRepository;

    @Mock
    private ParticipantRepository participantRepository;

    @Mock
    private MainEngineConfiguration mainEngineConfiguration;

    @Test
    void shouldValidateReturnValue() {
        BigDecimal amountValueReturn = BigDecimal.ZERO;
        BigDecimal originalEventValue = amountValueReturn;
        Integer daysReturnExpiration = -90;
        EventStatus eventStatus = EventStatus.SUCCESS;

        ReceiptEventEntity receiptEventEntity = createReceiptEventEntity(originalEventValue, daysReturnExpiration, eventStatus);

        BusinessException thrown = Assertions.assertThrows(BusinessException.class, () -> returnSentValidator.validate(receiptEventEntity,amountValueReturn));
        assertTrue(thrown.getCode().contains(SPI_ME_002));
    }

    @Test
    void shouldValidateEventValue() {
        BigDecimal amountValueReturn = new BigDecimal("100.00");
        BigDecimal originalEventValue = amountValueReturn;
        Integer daysReturnExpiration = -91;
        EventStatus eventStatus = EventStatus.SUCCESS;

        ReceiptEventEntity receiptEventEntity = createReceiptEventEntity(originalEventValue, daysReturnExpiration, eventStatus);

        when(eventRepository.returnAmountByCorrelationIdOfReturnSent(any())).thenReturn(receiptEventEntity.getValue());

        BusinessException thrown = Assertions.assertThrows(BusinessException.class, () -> returnSentValidator.validate(receiptEventEntity,amountValueReturn));
        assertTrue(thrown.getCode().contains(SPI_ME_007));
    }

    @Test
    void shouldValidateExpirationDate() {
        BigDecimal amountValueReturn = new BigDecimal("30.00");
        BigDecimal originalEventValue = new BigDecimal("100.00");
        Integer daysReturnExpiration = -73;
        Integer daysReturnExpirationConfiguration = -90;
        EventStatus eventStatus = EventStatus.SUCCESS;

        ReceiptEventEntity receiptEventEntity = createReceiptEventEntity(originalEventValue, daysReturnExpiration, eventStatus);

        when(mainEngineConfiguration.getDaysReturnExpiration()).thenReturn(daysReturnExpirationConfiguration);

        when(eventRepository.returnAmountByCorrelationIdOfReturnSent(any())).thenReturn(amountValueReturn);

        BusinessException thrown = Assertions.assertThrows(BusinessException.class, () -> returnSentValidator.validate(receiptEventEntity,amountValueReturn));
        assertTrue(thrown.getCode().contains(SPI_ME_008));
    }


    @ParameterizedTest
    @ValueSource(ints = { PAYER_ISPB, RECEIVER_ISPB })
    void shouldValidateWhenPayerOrReceiverParticipantIsInactive(int ispb) throws Exception {

        // Given
        boolean shouldPayerBeActive = PAYER_ISPB != ispb;
        lenient().when(participantRepository.findByIspb(PAYER_ISPB)).thenReturn(buildParticipantMock(PAYER_ISPB, shouldPayerBeActive));
        lenient().when(participantRepository.findByIspb(RECEIVER_ISPB)).thenReturn(buildParticipantMock(RECEIVER_ISPB, false));

        BigDecimal amountValueReturn = new BigDecimal("30.00");
        BigDecimal originalEventValue = new BigDecimal("100.00");
        Integer daysReturnExpiration = 1;
        Integer daysReturnExpirationConfiguration = 3;
        EventStatus eventStatus = EventStatus.SUCCESS;

        ReceiptEventEntity receiptEventEntity = createReceiptEventEntity(originalEventValue, daysReturnExpiration, eventStatus);

        when(mainEngineConfiguration.getDaysReturnExpiration()).thenReturn(daysReturnExpirationConfiguration);

        when(eventRepository.returnAmountByCorrelationIdOfReturnSent(any())).thenReturn(amountValueReturn);


        // When
        BusinessException thrown = Assertions.assertThrows(BusinessException.class, () -> returnSentValidator.validate(receiptEventEntity,amountValueReturn));

        // Then
        assertTrue(thrown.getCode().contains(SPI_ME_019));
    }


    private ReceiptEventEntity createReceiptEventEntity(BigDecimal eventValue, Integer daysReturnExpiration,
                                                        EventStatus eventStatus){
        ReceiptEventEntity receiptEventEntity = new ReceiptEventEntity();
        receiptEventEntity.setId(GENERATED_UUID);
        receiptEventEntity.setValue(eventValue);
        receiptEventEntity.setInitiationTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime().plusDays(daysReturnExpiration));
        receiptEventEntity.setStatus(new EventStatusEntity());
        receiptEventEntity.setReceiptEntity(createReceiptEntity());
        receiptEventEntity.getStatus().setCode(eventStatus.getCode());

        return receiptEventEntity;
    }

    private ReceiptEntity createReceiptEntity() {

        ReceiptEntity receiptEntity = new ReceiptEntity();

        ParticipantEntity payerParticipant = new ParticipantEntity();
        payerParticipant.setIspb(PAYER_ISPB);

        ParticipantEntity receiverParticipant = new ParticipantEntity();
        receiverParticipant.setIspb(RECEIVER_ISPB);

        receiptEntity.setPayerParticipant(payerParticipant);
        receiptEntity.setReceiverParticipant(receiverParticipant);

        return receiptEntity;
    }

    private Optional<ParticipantEntity> buildParticipantMock(Integer ispb, boolean active) {
        ParticipantEntity participantEntity = new ParticipantEntity();
        participantEntity.setIspb(ispb);
        participantEntity.setActive(active);

        return Optional.of(participantEntity);
    }

}
