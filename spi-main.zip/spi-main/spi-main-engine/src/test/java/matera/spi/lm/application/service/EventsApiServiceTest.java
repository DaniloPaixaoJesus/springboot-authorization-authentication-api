package matera.spi.lm.application.service;

import matera.spi.dto.EventDetailsDTO;
import matera.spi.lm.domain.model.spb.SpbEventEntity;
import matera.spi.lm.domain.model.spb.SpbMessageEntity;
import matera.spi.lm.domain.model.spb.deposit.IpAccountDepositDetailsEntity;
import matera.spi.lm.domain.model.spb.deposit.IpAccountDepositEventEntity;
import matera.spi.lm.persistence.SpbEventRepository;
import matera.spi.main.domain.model.event.EventStatusEntity;
import matera.spi.main.domain.model.event.EventStatusTransitionEntity;
import matera.spi.main.domain.model.event.EventTypeEntity;
import matera.spi.main.domain.model.transaction.TransactionResultEntity;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.internal.util.collections.Sets;
import org.mockito.junit.jupiter.MockitoExtension;
import org.testcontainers.shaded.com.google.common.collect.Lists;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

import static java.lang.Boolean.FALSE;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.comparesEqualTo;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.nullValue;
import static org.hamcrest.core.Is.is;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class EventsApiServiceTest {

    public static final LocalDateTime TIMESTAMP_UTC = LocalDateTime.now();

    @Mock
    private SpbEventRepository spbEventRepository;

    @InjectMocks
    private EventsApiService eventsApiService;

    @Test
    void findSpbEventDetail() {
        SpbEventEntity spbDepositEventEntity = createSpbDepositEventEntity();
        Mockito.when(spbEventRepository.findDetailsById(any())).thenReturn(Optional.of(spbDepositEventEntity));

        EventDetailsDTO spbEventDetail = eventsApiService.findSpbEventDetail(UUID.randomUUID());

        assertThat(spbEventDetail, is(not(nullValue())));
        assertThat(spbEventDetail.getId(), is(spbDepositEventEntity.getId()));
        assertThat(spbEventDetail.getInitiationTimestampUtc(), is(TIMESTAMP_UTC));
        assertThat(spbEventDetail.getOriginSystemTransactionId(), is("OriginTransactionId"));
        assertThat(spbEventDetail.getResponsible(), is("ResponsibleOfEvent"));
        assertThat(spbEventDetail.getValue(), is(BigDecimal.TEN));
        assertThat(spbEventDetail.getSpbEventId(), is(spbDepositEventEntity.getSpbEventId()));
        assertThat(spbEventDetail.getEventType(), is("EventType"));
        assertThat(spbEventDetail.getIpAccountMirrorTransactionId(), comparesEqualTo(BigDecimal.valueOf(123)));
        assertThat(spbEventDetail.getOriginSystem(), is("Origin System"));
    }

    @Test
    void validateMessageFillOnEventDetailDTO() {
        SpbEventEntity spbDepositEventEntity = createSpbDepositEventEntity();
        Mockito.when(spbEventRepository.findDetailsById(any())).thenReturn(Optional.of(spbDepositEventEntity));

        EventDetailsDTO spbEventDetail = eventsApiService.findSpbEventDetail(UUID.randomUUID());

        assertThat(spbEventDetail.getSpbMessages(), hasSize(1));
        assertThat(spbEventDetail.getSpbMessages().get(0).getTimestampUTC(), is(TIMESTAMP_UTC));
        assertThat(spbEventDetail.getSpbMessages().get(0).getType(), is("MCODE"));
        assertThat(spbEventDetail.getSpbMessages().get(0).getContent(), is(not(nullValue())));
        assertThat(spbEventDetail.getSpbMessages().get(0).getContent().getXmlMessage(), is("CONTENT"));
    }

    @Test
    void validateHistoriesFillOnEventDetailDTO() {
        SpbEventEntity spbDepositEventEntity = createSpbDepositEventEntity();
        Mockito.when(spbEventRepository.findDetailsById(any())).thenReturn(Optional.of(spbDepositEventEntity));

        EventDetailsDTO spbEventDetail = eventsApiService.findSpbEventDetail(UUID.randomUUID());

        assertThat(spbEventDetail.getEventHistory(), hasSize(1));
        assertThat(spbEventDetail.getEventHistory().get(0).getResponsible(), is("REPONSIBLE STATUS"));
        assertThat(spbEventDetail.getEventHistory().get(0).getTimestampUTC(), is(TIMESTAMP_UTC));
        assertThat(spbEventDetail.getEventHistory().get(0).getStatus().getCode(), is(1));
        assertThat(spbEventDetail.getEventHistory().get(0).getStatus().getDescription(), is("DESCRIPTION"));
    }

    private IpAccountDepositDetailsEntity createSpbDepositEventDetailsEntity() {
        IpAccountDepositDetailsEntity detailsEntity = new IpAccountDepositDetailsEntity();
        detailsEntity.setIspbif(100L);
        detailsEntity.setIspbpspi(999L);
        return detailsEntity;
    }

    private IpAccountDepositEventEntity createSpbDepositEventEntity() {
        IpAccountDepositEventEntity depositEntity = new IpAccountDepositEventEntity();
        EventTypeEntity eventTypeEntity = new EventTypeEntity();
        eventTypeEntity.setDescription("EventType");

        depositEntity.setIpAccountDepositDetails(createSpbDepositEventDetailsEntity());
        depositEntity.setIpAccountTransactionResult(getTransactionResultEntity());
        depositEntity.setEventTypeEntity(eventTypeEntity);
        depositEntity.setSpbEventId(1L);
        depositEntity.setControlNumber("1a2b3c");
        depositEntity.setMovementDate(LocalDate.of(2020, 5, 11));
        depositEntity.setSpbMessageEntity(Sets.newSet(getSpbMessageEntity()));
        depositEntity.setValue(BigDecimal.TEN);
        depositEntity.setResponsible("Responsible");
        depositEntity.setInitiationTimestampUTC(TIMESTAMP_UTC);
        depositEntity.setOrigSystemTransactionId("OriginTransactionId");
        depositEntity.setInitiatorIspb(1);
        depositEntity.setResponsible("ResponsibleOfEvent");
        depositEntity.setInitiatorIspb(12345678);
        depositEntity.setStatus(buildEventStatusEntity());
        depositEntity.setEventStatusTransitionEntities(Lists.newArrayList(getEventStatusTransitionEntity()));
        depositEntity.setOriginSystem("Origin System");
        return depositEntity;
    }

    private TransactionResultEntity getTransactionResultEntity() {
        TransactionResultEntity ipAccountTransactionResult = new TransactionResultEntity();
        ipAccountTransactionResult.setTransactionIdInDdaSystem(BigDecimal.valueOf(123));
        return ipAccountTransactionResult;
    }

    private SpbMessageEntity getSpbMessageEntity() {
        SpbMessageEntity spbMessageEntity = new SpbMessageEntity();
        spbMessageEntity.setMessageCode("MCODE");
        spbMessageEntity.setMessageContents("CONTENT");
        spbMessageEntity.setTimestamp(TIMESTAMP_UTC);
        return spbMessageEntity;
    }

    private EventStatusTransitionEntity getEventStatusTransitionEntity() {
        EventStatusEntity eventStatusCode = new EventStatusEntity();
        eventStatusCode.setCode(1);
        eventStatusCode.setDescription("DESCRIPTION");
        eventStatusCode.setFinalStatus(false);

        EventStatusTransitionEntity spbStatusEntity = new EventStatusTransitionEntity();
        spbStatusEntity.setEventStatusCode(eventStatusCode);
        spbStatusEntity.setResponsible("REPONSIBLE STATUS");
        spbStatusEntity.setTimestamp(TIMESTAMP_UTC);
        return spbStatusEntity;
    }

    private EventStatusEntity buildEventStatusEntity() {
        EventStatusEntity entity = new EventStatusEntity();
        entity.setCode(1000);
        entity.setDescription("Event Status Test");
        entity.setFinalStatus(FALSE);
        return entity;
    }

}
