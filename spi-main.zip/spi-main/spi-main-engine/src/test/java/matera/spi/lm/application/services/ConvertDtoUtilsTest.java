package matera.spi.lm.application.services;

import matera.spi.dto.EventStatusDTO;
import matera.spi.dto.PageableDTO;
import matera.spi.dto.SortDTO;
import matera.spi.lm.dto.converter.ConvertDtoUtils;
import matera.spi.main.domain.model.event.EventStatusEntity;

import org.junit.jupiter.api.Test;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.springframework.data.domain.Sort.Direction.DESC;

class ConvertDtoUtilsTest {

    @Test
    void shouldFillCorrectlyPageableDto() {
        PageRequest pageable = PageRequest.of(0, 10, Sort.by(DESC, "someColumn"));

        PageableDTO pageableDTO = ConvertDtoUtils.fillPageableDto(pageable);

        assertThat(pageableDTO.getPageNumber(), is(0));
        assertThat(pageableDTO.getPageSize(), is(10));
        assertThat(pageableDTO.getOffset(), is(0));
        assertThat(pageableDTO.getUnpaged(), is(false));
        assertThat(pageableDTO.getPaged(), is(true));
    }

    @Test
    void shouldFillCorrectlySortDto() {
        Sort sortable = Sort.by(DESC, "someColumn");

        SortDTO sortDTO = ConvertDtoUtils.fillSortDto(sortable);

        assertThat(sortDTO.getSorted(), is(true));
        assertThat(sortDTO.getUnsorted(), is(false));
        assertThat(sortDTO.getEmpty(), is(false));
    }

    @Test
    void shouldFillCorrectlyEventStatusDto() {
        EventStatusEntity eventStatusEntity = new EventStatusEntity();
        eventStatusEntity.setCode(1);
        eventStatusEntity.setDescription("Payment Initialized");
        eventStatusEntity.setFinalStatus(false);

        EventStatusDTO sortDTO = ConvertDtoUtils.fillEventStatusDto(eventStatusEntity);

        assertThat(sortDTO.getCode(), is(1));
        assertThat(sortDTO.getDescription(), is("Payment Initialized"));
    }

}
