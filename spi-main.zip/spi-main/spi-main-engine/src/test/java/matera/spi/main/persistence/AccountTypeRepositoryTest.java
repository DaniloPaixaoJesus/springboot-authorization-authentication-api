package matera.spi.main.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.account.AccountTypeEntity;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

@IntegrationTest
class AccountTypeRepositoryTest  {

    private static final String CODE = "ABCD";
    private static final String DESCRIPTION = "Account Type Descriptiom";

    @Autowired
    private AccountTypeRepository repository;

    @Autowired
    private TransactionRepository transactionRepository;

    @BeforeEach
    void init() {
        transactionRepository.deleteAll();
    }

    @AfterEach
    void clearDatabase() {
        repository.deleteById(CODE);
    }

    @Test
    void shouldBeFindEntityWhenInserted() {
        AccountTypeEntity expected = new AccountTypeEntity();
        expected.setCode(CODE);
        expected.setDescription(DESCRIPTION);

        repository.saveAndFlush(expected);

        AccountTypeEntity actual = repository.findById(expected.getCode()).orElse(null);
        Assertions.assertEquals(expected, actual);
    }

}
