package matera.spi.main.utils;

import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventStatusEntity;
import matera.spi.main.domain.model.event.EventStatusTransitionEntity;
import matera.spi.main.domain.model.event.transaction.PaymentEventEntity;
import matera.spi.main.domain.model.event.transaction.ReceiptEventEntity;
import matera.spi.main.domain.model.transaction.PaymentEntity;
import matera.spi.main.domain.model.transaction.ReceiptEntity;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.EventStatusRepository;
import matera.spi.main.persistence.EventStatusTransitionRepository;
import matera.spi.main.utils.constants.EventConstants;
import matera.spi.utils.LocalDateTimeUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Optional;

@Component
public class EventEntityUtils {

    @Autowired
    private EventRepository eventRepository;

    @Autowired
    private EventStatusRepository eventStatusRepository;

    @Autowired
    private EventStatusTransitionRepository eventStatusTransitionRepository;

    public PaymentEventEntity buildPaymentEventEntity(BigDecimal value, Integer eventStatus) {
        final EventStatusEntity status = getEventStatus(eventStatus);
        PaymentEventEntity entity = new PaymentEventEntity();
        entity.setInitiationTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime().withNano(0));
        entity.setResponsible(EventConstants.EVENT_ENTITY_RESPONSABLE);
        entity.setInitiatorIspb(EventConstants.EVENT_ENTITY_ISPB_INITIATOR);
        entity.setStatus(status);
        entity.setClearingTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
        entity.setValue(value);

        return entity;
    }

    public ReceiptEventEntity buildReceiptEventEntity(BigDecimal value, Integer eventStatus) {
        final EventStatusEntity status = getEventStatus(eventStatus);
        ReceiptEventEntity entity = new ReceiptEventEntity();
        entity.setInitiationTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime().withNano(0));
        entity.setResponsible(EventConstants.EVENT_ENTITY_RESPONSABLE);
        entity.setInitiatorIspb(EventConstants.EVENT_ENTITY_ISPB_INITIATOR);
        entity.setStatus(status);
        entity.setClearingTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
        entity.setValue(value);

        return entity;
    }

    public void deleteAllInsertValuesFromEventEntity() {
        eventStatusTransitionRepository.deleteAll();
//        eventStatusRepository.deleteAll();
        eventRepository.deleteAll();
    }

    public void setPaymentEntityInEvent(PaymentEventEntity paymentEvent, PaymentEntity payment) {
        paymentEvent.setPaymentEntity(payment);
        paymentEvent.setCorrelationId(payment.getEndToEndId());
        payment.setEvent(paymentEvent);
    }

    public void setReceiptEntityInEvent(ReceiptEventEntity receiptEvent, ReceiptEntity receiptEntity) {
        receiptEvent.setReceiptEntity(receiptEntity);
        receiptEvent.setCorrelationId(receiptEntity.getEndToEndId());
        receiptEntity.setEvent(receiptEvent);
    }

    public EventEntity saveEventEntity(EventEntity eventEntity) {
        return eventRepository.saveAndFlush(eventEntity);
    }

    public EventStatusTransitionEntity buildPaymentEventStatusTransitionEntity(PaymentEventEntity entity) {
        EventStatusTransitionEntity eventStatusTransition = new EventStatusTransitionEntity();
        eventStatusTransition.setEventStatusCode(entity.getStatus());
        eventStatusTransition.setEvent(entity);
        eventStatusTransition.setResponsible(EventConstants.EVENT_STATUS_TRANSITION_RESPONSABLE);
        eventStatusTransition.setTimestamp(LocalDateTime.now(ZoneOffset.UTC));
        return eventStatusTransitionRepository.save(eventStatusTransition);
    }

    public EventStatusTransitionEntity buildReceiptEventStatusTransitionEntity(ReceiptEventEntity entity) {
        EventStatusTransitionEntity eventStatusTransition = new EventStatusTransitionEntity();
        eventStatusTransition.setEventStatusCode(entity.getStatus());
        eventStatusTransition.setEvent(entity);
        eventStatusTransition.setResponsible(EventConstants.EVENT_STATUS_TRANSITION_RESPONSABLE);
        eventStatusTransition.setTimestamp(LocalDateTime.now(ZoneOffset.UTC));
        return eventStatusTransitionRepository.save(eventStatusTransition);
    }

    private EventStatusEntity getEventStatus(Integer eventStatus) {
        final Optional<EventStatusEntity> optionalEventStatus = eventStatusRepository.findById(eventStatus);
        return optionalEventStatus.orElseThrow(() -> new IllegalArgumentException("not found event status with code: " + eventStatus));
    }
}
