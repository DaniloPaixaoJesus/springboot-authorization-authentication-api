package matera.spi.main.rest.api;

import com.matera.commons.rest.dto.MateraRestReturnDTO;
import com.matera.commons.utils.exception.BusinessException;
import com.matera.spi.messaging.api.MessagesApi;
import com.matera.spi.messaging.api.SPIMessagingApis;
import com.matera.spi.messaging.model.MessageSentResponseDTO;
import com.matera.spi.messaging.model.MessageSpecificationDTO;
import com.matera.spi.thirdparties.customers.transactions.model.LancamentoResponseV2DTO;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.InstantPaymentSettlementRequestDTO;
import matera.spi.main.domain.service.MessageSender;
import matera.spi.main.domain.service.transaction.AccountTransaction;
import matera.spi.main.dto.AccountTransactionRequestDTO;
import matera.spi.main.dto.AccountTransactionResponseDTO;
import matera.spi.main.dto.AccountTransactionValidationRequestDTO;
import matera.spi.main.dto.QueryBalanceRequestDTO;
import matera.spi.main.dto.QueryBalanceResponseDTO;
import matera.spi.main.exception.EventErrorException;
import matera.spi.main.persistence.MessageRepository;
import matera.spi.main.rest.ui.PaymentsTestDetails;
import matera.spi.main.transactions.port.AccountTransactionExecutorPort;
import matera.spi.utils.DocumentUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.api.SoftAssertions;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EmptySource;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Document;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.transaction.Transactional;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import static matera.spi.main.rest.api.SettlementsTestHelper.createInvalidInstantPaymentSettlementRequestDTO;
import static matera.spi.main.rest.api.SettlementsTestHelper.createJsonXmlMapping;
import static matera.spi.main.rest.api.SettlementsTestHelper.createValidInstantPaymentSettlementRequestDTO;
import static matera.spi.main.utils.XmlValidator.validateWithXSD;

import static com.matera.spi.thirdparties.customers.transactions.model.LancamentoResponseV2DTO.ClassificacaoCategoriaContaSPIEnum.CACC;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@Slf4j
@IntegrationTest
@Transactional
public class SettlementsTest {

    private static final String BASE_URI_INSTANT_PAYMENTS = "/api/v1/settlements/instant-payments";
    private static final String ADDRESSING_KEY = "ADDRESSING_KEY";

    @Autowired
    private AccountTransaction accountTransaction;
    @Autowired
    private AccountTransactionExecutorPort accountTransactionExecutorPort;
    @Mock
    private AccountTransactionExecutorPort mockedAccountTransactionExecutorPort;

    @Autowired
    private MessageSender messageSender;
    @Autowired
    private SPIMessagingApis spiMessagingApisBean;
    @Mock
    private SPIMessagingApis mockedSpiMessagingApis;
    @Mock
    private MessagesApi mockedMessagesApi;

    @Captor
    private ArgumentCaptor<MessageSpecificationDTO> messageSpecificationDTOArgumentCaptor;

    @Autowired
    private ObjectMapper objectMapper;

    @LocalServerPort
    private int port;

    @Value("classpath:xsd/version/*/pacs.008.*.xsd")
    Resource[] pacs008XSDResources;


    @BeforeEach
    public void setup() {

        LancamentoResponseV2DTO lancamentoResponseV2DTO = new LancamentoResponseV2DTO();

        lancamentoResponseV2DTO.setClassificacaoCategoriaContaSPI(CACC);
        lancamentoResponseV2DTO.setCpfCnpjTitular(BigDecimal.valueOf(92082843521L));

        when(mockedAccountTransactionExecutorPort.makeTransaction(any(AccountTransactionRequestDTO.class))).thenAnswer(
            (Answer<AccountTransactionResponseDTO>) invocation -> AccountTransactionResponseDTO.builder()
                .transactionId(BigDecimal.valueOf(1L))
                .lancamentoResponseV2DTO(lancamentoResponseV2DTO)
                .build());

        when(mockedAccountTransactionExecutorPort.validateCredit(any(AccountTransactionValidationRequestDTO.class)))
            .thenReturn(false);

        when(mockedAccountTransactionExecutorPort.queryBalance(any(QueryBalanceRequestDTO.class))).thenAnswer(
            (Answer<QueryBalanceResponseDTO>) invocation -> QueryBalanceResponseDTO.builder()
                .balanceAvailable(BigDecimal.valueOf(1234546789L))
                .accountingBalance(BigDecimal.valueOf(1234546L))
                .blockedBalance(BigDecimal.valueOf(123454L))
                .accountingBalance(BigDecimal.valueOf(12345L))
                .creditLimitAvailable(BigDecimal.valueOf(1234546789L))
                .date(LocalDate.now())
                .build());

        when(mockedSpiMessagingApis.messagesApi()).thenReturn(mockedMessagesApi);
        messageSender.setSpiMessagingApis(mockedSpiMessagingApis);
        accountTransaction.setAccountTransactionExecutorPort(mockedAccountTransactionExecutorPort);
    }

    @AfterEach
    void tearDown() {
        accountTransaction.setAccountTransactionExecutorPort(accountTransactionExecutorPort);
        messageSender.setSpiMessagingApis(spiMessagingApisBean);
    }

    @ParameterizedTest(name = "when given an addressing key as: \"{0}\"")
    @ValueSource(strings = {ADDRESSING_KEY})
    @EmptySource
    @NullSource
    void shouldAllPayloadFieldBeInTheXml(String addressingKey) throws Exception {
        // Given
        mockMessageSender();
        InstantPaymentSettlementRequestDTO instantPaymentsUIDTO = createValidInstantPaymentSettlementRequestDTO(addressingKey);

        // When
        invokeEndpoint(instantPaymentsUIDTO);

        // Then

        SoftAssertions propertyAssertions = addAssertsThatAllFieldsMatchExpectedValues(instantPaymentsUIDTO, addressingKey != null);

        if (StringUtils.isEmpty(addressingKey)) {

            propertyAssertions.assertThat(getXmlMessage())
                .as("Expecting that document does not have any node CdtrAcct/Prxy")
                .doesNotContain("Prxy");
        } else {
            propertyAssertions.assertThat(getXmlMessage())
                    .as("Expecting that document have only one node CdtrAcct/Prxy/Id")
                    .containsPattern("Prxy>[\\s\\n\\t]*<Id");
        }

        propertyAssertions.assertAll();
    }

    @Test
    void shouldAllPayloadFieldBeInTheXmlInvalidDate() {
        Assertions.assertThrows(Throwable.class, () -> {

            mockMessageSender();

            InstantPaymentSettlementRequestDTO instantPaymentsUIDTO = createInvalidInstantPaymentSettlementRequestDTO();

            invokeEndpoint(instantPaymentsUIDTO);

            SoftAssertions propertyAssertions = addAssertsThatAllFieldsMatchExpectedValues(instantPaymentsUIDTO, true);

            propertyAssertions.assertAll();
        });
    }

    @Test
    void shouldReturnHttpStatusCode400WhenBusinessExceptionIsThrow() {

        when(mockedMessagesApi.sendsMessageV1(any())).thenThrow(new BusinessException("SPI-ME-002", "1", "2"));

        InstantPaymentSettlementRequestDTO instantPaymentsUIDTO = createValidInstantPaymentSettlementRequestDTO(ADDRESSING_KEY);

        assertThatThrownBy(() -> invokeEndpoint(instantPaymentsUIDTO))
            .hasMessage("400 Bad Request");
    }

    @Test
    void shouldReturnHttpStatusCode500WhenExceptionOtherThanBusinessExceptionIsThrow() {

        when(mockedMessagesApi.sendsMessageV1(any())).thenThrow(EventErrorException.class);

        InstantPaymentSettlementRequestDTO instantPaymentsUIDTO = createValidInstantPaymentSettlementRequestDTO(ADDRESSING_KEY);

        assertThatThrownBy(() -> invokeEndpoint(instantPaymentsUIDTO))
            .hasMessage("500 Internal Server Error");
    }

    private SoftAssertions addAssertsThatAllFieldsMatchExpectedValues(InstantPaymentSettlementRequestDTO instantPaymentsUIDTO, boolean HasAddressingKey) throws Exception {

        String xmlMessage = getXmlMessage();
        Document xmlDocument = DocumentUtils.stringToXmlDocument(xmlMessage);

        String jsonPayload = objectMapper.writeValueAsString(instantPaymentsUIDTO);
        DocumentContext jsonContext = JsonPath.parse(jsonPayload);

        SoftAssertions propertyAssertions = new SoftAssertions();

        validateWithXSD(xmlMessage, pacs008XSDResources[0]);

        createJsonXmlMapping(HasAddressingKey).forEach((jsonPath, xPath) -> addAssertThatFieldMatchesExpectedValue(propertyAssertions, xmlDocument, jsonContext, jsonPath, xPath));

        return propertyAssertions;
    }

    private void addAssertThatFieldMatchesExpectedValue(SoftAssertions propertyAssertions, Document xmlDocument, DocumentContext jsonContext, String jsonPath, String xPath) {

        try {
            String expected = jsonContext.read(jsonPath, String.class);

            XPath xPathObject = XPathFactory.newInstance().newXPath();
            String actual = (String) xPathObject.compile(xPath).evaluate(xmlDocument, XPathConstants.STRING);

            PaymentsTestDetails paymentsTestDetails = PaymentsTestDetails.builder()
                    .jsonPath(jsonPath)
                    .valueFromJson(expected)
                    .xpath(xPath)
                    .valueFromXml(actual)
                    .build();

            propertyAssertions.assertThat(actual)
                    .as(paymentsTestDetails.toString())
                    .matches("0*" + expected + "Z?");

        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new RuntimeException(e);
        }
    }

    private void invokeEndpoint(InstantPaymentSettlementRequestDTO instantPaymentsUIDTO) {
        String url = "http://localhost:" + port + BASE_URI_INSTANT_PAYMENTS;

        RestTemplate restTemplate = new RestTemplate();

        MultiValueMap<String, String> map= new LinkedMultiValueMap<>();
        map.add("idempotencyId", LocalDateTime.now().toString());

        HttpEntity<InstantPaymentSettlementRequestDTO> request = new HttpEntity<>(instantPaymentsUIDTO, map);

        restTemplate.postForEntity(url, request, MateraRestReturnDTO.class);
    }

    private String getXmlMessage() {

        verify(mockedMessagesApi).sendsMessageV1(messageSpecificationDTOArgumentCaptor.capture());
        MessageSpecificationDTO messageSpecificationDTO = messageSpecificationDTOArgumentCaptor.getValue();

        return messageSpecificationDTO.getMessageContent();
    }

    private void mockMessageSender() {
        MessageSentResponseDTO dtoResponse = new MessageSentResponseDTO();
        dtoResponse.setPiResourceID("ResourceId-" + RandomStringUtils.randomNumeric(5));
        when(mockedMessagesApi.sendsMessageV1(any())).thenReturn(dtoResponse);
    }

}
