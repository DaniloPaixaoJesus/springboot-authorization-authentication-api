package matera.spi.commons;

import org.springframework.test.context.ActiveProfilesResolver;

import java.util.Optional;

public class DatabaseTestProfileResolver implements ActiveProfilesResolver {
    /**
     *  We can supply the test database either by the TEST_DATABASE environment variable or the test.database
     *  system property. If none is supplied, use the mysql database
     */
    private String databaseType() {
        return Optional.ofNullable(System.getenv("TEST_DATABASE"))
                       .orElse(System.getProperty("test.database", "mysql"));
    }
    @Override
    public String[] resolve(Class<?> aClass) {
        return new String[] { "test", databaseType() };
    }
}
