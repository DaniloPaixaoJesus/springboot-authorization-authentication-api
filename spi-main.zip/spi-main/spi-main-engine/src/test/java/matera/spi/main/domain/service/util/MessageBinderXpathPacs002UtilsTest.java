package matera.spi.main.domain.service.util;

import matera.spi.main.domain.model.enums.TransactionStatus;
import matera.spi.utils.DocumentUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static org.assertj.core.api.Assertions.assertThat;

class MessageBinderXpathPacs002UtilsTest {

	private static final String PACS_002_ERRO = "pacs.002/pacs.002.spi.1.2_ERRO_1_msg.xml";
	private static final String PACS_002_PSP_CREDOR = "pacs.002/pacs.002.spi.1.2_PSP_CREDOR_10_msg.xml";
	private static final String PACS_002_SPI = "pacs.002/pacs.002.spi.1.2_SPI_10_msg.xml";
	private static final String PACS_002_RJCT_AB03 = "pacs.002/pacs.002_without_header_RJCT_AB03_with_addtlInf.xml";

	private static final String MSG_ID_ERRO = "M00708531ec0f42fd62604f77a8d890c";
	private static final String CRE_DT_TM_ERRO = "2020-02-14T14:52:04.686Z";
	private static final String CD_ERRO = "AB03";

	private static final String MSG_ID_CREDOR = "M00673146e270dae3af1c410caf9bfaa";
	private static final String CRE_DT_TM_CREDOR = "2020-02-14T14:52:04.653Z";

	private static final String MSG_ID_SPI = "M0026471748f9266fe3344a2bab25b36";
	private static final String CRE_TM_SPI = "2020-02-14T14:52:04.674Z";

	private static final String INTR_BK_STTLM_DM_0 = "2020-02-14";
	private static final String INTR_BK_STTLM_DM_1 = "2020-02-14";
	private static final String INTR_BK_STTLM_DM_2 = "2020-02-14";
	private static final String INTR_BK_STTLM_DM_3 = "2020-02-14";
	private static final String INTR_BK_STTLM_DM_4 = "2020-02-14";
	private static final String INTR_BK_STTLM_DM_5 = "2020-02-14";
	private static final String INTR_BK_STTLM_DM_6 = "2020-02-14";
	private static final String INTR_BK_STTLM_DM_7 = "2020-02-14";
	private static final String INTR_BK_STTLM_DM_8 = "2020-02-14";
	private static final String INTR_BK_STTLM_DM_9 = "2020-02-14";

	private static final String CRE_DT_TM_SPI_0 = "2020-02-14T14:52:04.674Z";
	private static final String CRE_DT_TM_SPI_1 = "2020-02-14T14:52:04.675Z";
	private static final String CRE_DT_TM_SPI_2 = "2020-02-14T14:52:04.675Z";
	private static final String CRE_DT_TM_SPI_3 = "2020-02-14T14:52:04.676Z";
	private static final String CRE_DT_TM_SPI_4 = "2020-02-14T14:52:04.676Z";
	private static final String CRE_DT_TM_SPI_5 = "2020-02-14T14:52:04.676Z";
	private static final String CRE_DT_TM_SPI_6 = "2020-02-14T14:52:04.677Z";
	private static final String CRE_DT_TM_SPI_7 = "2020-02-14T14:52:04.677Z";
	private static final String CRE_DT_TM_SPI_8 = "2020-02-14T14:52:04.677Z";
	private static final String CRE_DT_TM_SPI_9 = "2020-02-14T14:52:04.678Z";


	private static final String ORGNL_END_TO_END_ID_SPI_0 = "E0026471720200214115279f55cb7a72";
	private static final String ORGNL_END_TO_END_ID_SPI_1 = "E0026471720200214115269c9a581d19";
	private static final String ORGNL_END_TO_END_ID_SPI_2 = "E00264717202002141152c6b48a588f8";
	private static final String ORGNL_END_TO_END_ID_SPI_3 = "E00264717202002141152f582f597ff0";
	private static final String ORGNL_END_TO_END_ID_SPI_4 = "E002647172020021411525999bec5862";
	private static final String ORGNL_END_TO_END_ID_SPI_5 = "E0026471720200214115234be649aaeb";
	private static final String ORGNL_END_TO_END_ID_SPI_6 = "E00264717202002141152ffa4e069fb3";
	private static final String ORGNL_END_TO_END_ID_SPI_7 = "E0026471720200214115223fe45c0b21";
	private static final String ORGNL_END_TO_END_ID_SPI_8 = "E002647172020021411527e8859c6a32";
	private static final String ORGNL_END_TO_END_ID_SPI_9 = "E0026471720200214115251b5b57b0e5";

	private static final String ORGNL_INSTR_ID_SPI_0 = "E0026471720200214115279f55cb7a72";
	private static final String ORGNL_INSTR_ID_SPI_1 = "E0026471720200214115269c9a581d19";
	private static final String ORGNL_INSTR_ID_SPI_2 = "E00264717202002141152c6b48a588f8";
	private static final String ORGNL_INSTR_ID_SPI_3 = "E00264717202002141152f582f597ff0";
	private static final String ORGNL_INSTR_ID_SPI_4 = "E002647172020021411525999bec5862";
	private static final String ORGNL_INSTR_ID_SPI_5 = "E0026471720200214115234be649aaeb";
	private static final String ORGNL_INSTR_ID_SPI_6 = "E00264717202002141152ffa4e069fb3";
	private static final String ORGNL_INSTR_ID_SPI_7 = "E0026471720200214115223fe45c0b21";
	private static final String ORGNL_INSTR_ID_SPI_8 = "E002647172020021411527e8859c6a32";
	private static final String ORGNL_INSTR_ID_SPI_9 = "E0026471720200214115251b5b57b0e5";


	private static final String ORGNL_END_TO_END_ID_CREDOR_0 = "E00673146202002141152e43c03632e7";
	private static final String ORGNL_END_TO_END_ID_CREDOR_1 = "E006731462020021411522e575e2109c";
	private static final String ORGNL_END_TO_END_ID_CREDOR_2 = "E00673146202002141152a835e46678e";
	private static final String ORGNL_END_TO_END_ID_CREDOR_3 = "E00673146202002141152c9a98008508";
	private static final String ORGNL_END_TO_END_ID_CREDOR_4 = "E0067314620200214115257599967502";
	private static final String ORGNL_END_TO_END_ID_CREDOR_5 = "E00673146202002141152167e21d2bb5";
	private static final String ORGNL_END_TO_END_ID_CREDOR_6 = "E00673146202002141152756b9ec8428";
	private static final String ORGNL_END_TO_END_ID_CREDOR_7 = "E006731462020021411529b388d1b6ad";
	private static final String ORGNL_END_TO_END_ID_CREDOR_8 = "E0067314620200214115281a294b71f6";
	private static final String ORGNL_END_TO_END_ID_CREDOR_9 = "E00673146202002141152d9c30abd3d3";

	private static final String ORGNL_INSTR_ID_CREDOR_0 = "E00673146202002141152e43c03632e7";
	private static final String ORGNL_INSTR_ID_CREDOR_1 = "E006731462020021411522e575e2109c";
	private static final String ORGNL_INSTR_ID_CREDOR_2 = "E00673146202002141152a835e46678e";
	private static final String ORGNL_INSTR_ID_CREDOR_3 = "E00673146202002141152c9a98008508";
	private static final String ORGNL_INSTR_ID_CREDOR_4 = "E0067314620200214115257599967502";
	private static final String ORGNL_INSTR_ID_CREDOR_5 = "E00673146202002141152167e21d2bb5";
	private static final String ORGNL_INSTR_ID_CREDOR_6 = "E00673146202002141152756b9ec8428";
	private static final String ORGNL_INSTR_ID_CREDOR_7 = "E006731462020021411529b388d1b6ad";
	private static final String ORGNL_INSTR_ID_CREDOR_8 = "E0067314620200214115281a294b71f6";
	private static final String ORGNL_INSTR_ID_CREDOR_9 = "E00673146202002141152d9c30abd3d3";

	private static final String ORGNL_INSTR_ID_ERRO = "E00708531202002141152350051ca53d";
	private static final String ORGNL_END_TO_END_ID_ERRO = "E00708531202002141152350051ca53d";


	List<String> listIntrBkSttlmDM = new ArrayList<>(
			Arrays.asList(INTR_BK_STTLM_DM_0, INTR_BK_STTLM_DM_1, INTR_BK_STTLM_DM_2, INTR_BK_STTLM_DM_3, INTR_BK_STTLM_DM_4,
					INTR_BK_STTLM_DM_5, INTR_BK_STTLM_DM_6,INTR_BK_STTLM_DM_7,INTR_BK_STTLM_DM_8,INTR_BK_STTLM_DM_9)
	);

	List<String> listCreDtTmSpi = new ArrayList<>(
			Arrays.asList(CRE_DT_TM_SPI_0, CRE_DT_TM_SPI_1, CRE_DT_TM_SPI_2, CRE_DT_TM_SPI_3, CRE_DT_TM_SPI_4,
					CRE_DT_TM_SPI_5, CRE_DT_TM_SPI_6,CRE_DT_TM_SPI_7,CRE_DT_TM_SPI_8,CRE_DT_TM_SPI_9)
	);

	List<String> listOrgEndToEndId = new ArrayList<>(
			Arrays.asList(ORGNL_END_TO_END_ID_SPI_0, ORGNL_END_TO_END_ID_SPI_1, ORGNL_END_TO_END_ID_SPI_2, ORGNL_END_TO_END_ID_SPI_3, ORGNL_END_TO_END_ID_SPI_4,
					ORGNL_END_TO_END_ID_SPI_5,ORGNL_END_TO_END_ID_SPI_6,ORGNL_END_TO_END_ID_SPI_7,ORGNL_END_TO_END_ID_SPI_8,ORGNL_END_TO_END_ID_SPI_9)
	);

	List<String> listOrgInstrId = new ArrayList<>(
			Arrays.asList(ORGNL_INSTR_ID_SPI_0, ORGNL_INSTR_ID_SPI_1, ORGNL_INSTR_ID_SPI_2, ORGNL_INSTR_ID_SPI_3, ORGNL_INSTR_ID_SPI_4,
					ORGNL_INSTR_ID_SPI_5,ORGNL_INSTR_ID_SPI_6,ORGNL_INSTR_ID_SPI_7,ORGNL_INSTR_ID_SPI_8,ORGNL_INSTR_ID_SPI_9)
	);

	List<String> listOrgEndToEndIdCredor = new ArrayList<>(
			Arrays.asList(ORGNL_END_TO_END_ID_CREDOR_0, ORGNL_END_TO_END_ID_CREDOR_1, ORGNL_END_TO_END_ID_CREDOR_2, ORGNL_END_TO_END_ID_CREDOR_3, ORGNL_END_TO_END_ID_CREDOR_4,
					ORGNL_END_TO_END_ID_CREDOR_5,ORGNL_END_TO_END_ID_CREDOR_6,ORGNL_END_TO_END_ID_CREDOR_7,ORGNL_END_TO_END_ID_CREDOR_8,ORGNL_END_TO_END_ID_CREDOR_9)
	);

	List<String> listOrgInstIdCredor = new ArrayList<>(
			Arrays.asList(ORGNL_INSTR_ID_CREDOR_0, ORGNL_INSTR_ID_CREDOR_1, ORGNL_INSTR_ID_CREDOR_2, ORGNL_INSTR_ID_CREDOR_3, ORGNL_INSTR_ID_CREDOR_4,
					ORGNL_INSTR_ID_CREDOR_5, ORGNL_INSTR_ID_CREDOR_6,ORGNL_INSTR_ID_CREDOR_7,ORGNL_INSTR_ID_CREDOR_8,ORGNL_INSTR_ID_CREDOR_9)
	);

	List<String> listOrgInstrIdErro = new ArrayList<>(
			Arrays.asList(ORGNL_INSTR_ID_ERRO)
	);

	List<String> listOrgEndToEndIdErro = new ArrayList<>(
			Arrays.asList(ORGNL_END_TO_END_ID_ERRO)
	);

	private static final int TEN = 10;
	private static final int THREE = 3;

	@Test
	@DisplayName("Get All TxInfAndSts Node Test.")
	void shouldGetAllTxInfAndStsCredor() {
		Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_002_PSP_CREDOR));
		NodeList nodeList = MessageBinderXpathPacs002Utils.getAllTxInfAndSts(document);
		assertThat(nodeList.getLength()).isEqualTo(TEN);
	}

	@Test
	@DisplayName("Get All IntrBkSttlmDt Node Test.")
	void shouldIntrBkSttlmDtAB03() {
		Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_002_RJCT_AB03));
		NodeList nodeList = MessageBinderXpathPacs002Utils.getAddTlInfAllNode(document);
		assertThat(nodeList.getLength()).isEqualTo(THREE);
	}

	@Test
	@DisplayName("Test Date and time at which a transaction is completed and cleared, that is, payment is effected for archive pacs.002.spi.1.2_SPI_10_msg.xml")
	void shouldIntrBkSttlmDmSpi() {
		ArrayList<String> itens = new ArrayList<>();
		Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_002_SPI));
		NodeList documentList = MessageBinderXpathPacs002Utils.getAllTxInfAndSts(document);
		for (int z =0; z<documentList.getLength();z++) {
			itens.add(MessageBinderXpathPacs002Utils.getIntrBkSttlmDm(documentList.item(z)));
		}
		assertThat(itens.get(0)).isEqualTo(listIntrBkSttlmDM.get(0));
		assertThat(itens.get(1)).isEqualTo(listIntrBkSttlmDM.get(1));
		assertThat(itens.get(2)).isEqualTo(listIntrBkSttlmDM.get(2));
		assertThat(itens.get(3)).isEqualTo(listIntrBkSttlmDM.get(3));
		assertThat(itens.get(4)).isEqualTo(listIntrBkSttlmDM.get(4));
		assertThat(itens.get(5)).isEqualTo(listIntrBkSttlmDM.get(5));
		assertThat(itens.get(6)).isEqualTo(listIntrBkSttlmDM.get(6));
		assertThat(itens.get(7)).isEqualTo(listIntrBkSttlmDM.get(7));
		assertThat(itens.get(8)).isEqualTo(listIntrBkSttlmDM.get(8));
		assertThat(itens.get(9)).isEqualTo(listIntrBkSttlmDM.get(9));
	}

	@Test
	@DisplayName("Test Key elements used to identify the original transaction that is being referred to for archive pacs.002.spi.1.2_SPI_10_msg.xml")
	void shouldDtTmSpi() {
		ArrayList<String> itens = new ArrayList<>();
		Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_002_SPI));
		NodeList documentList = MessageBinderXpathPacs002Utils.getAllTxInfAndSts(document);
		for (int i =0; i<documentList.getLength();i++){
		    Node node = DocumentUtils.getDocumentByNode(documentList.item(i));
			itens.add(MessageBinderXpathPacs002Utils.getDtMtNode(node));
		}
		assertThat(itens.get(0)).isEqualTo(listCreDtTmSpi.get(0));
		assertThat(itens.get(1)).isEqualTo(listCreDtTmSpi.get(1));
		assertThat(itens.get(2)).isEqualTo(listCreDtTmSpi.get(2));
		assertThat(itens.get(3)).isEqualTo(listCreDtTmSpi.get(3));
		assertThat(itens.get(4)).isEqualTo(listCreDtTmSpi.get(4));
		assertThat(itens.get(5)).isEqualTo(listCreDtTmSpi.get(5));
		assertThat(itens.get(6)).isEqualTo(listCreDtTmSpi.get(6));
		assertThat(itens.get(7)).isEqualTo(listCreDtTmSpi.get(7));
		assertThat(itens.get(8)).isEqualTo(listCreDtTmSpi.get(8));
		assertThat(itens.get(9)).isEqualTo(listCreDtTmSpi.get(9));
	}

	@Test
	@DisplayName("Test Specifies the status of a transaction, in a coded form for archive pacs.002.spi.1.2_SPI_10_msg.xml")
	void shouldTXSTSSpi() {
		ArrayList<String> itens = new ArrayList<>();
		Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_002_SPI));
		NodeList documentList = MessageBinderXpathPacs002Utils.getAllTxInfAndSts(document);
		for (int i =0; i<documentList.getLength();i++){
			itens.add(MessageBinderXpathPacs002Utils.getTXSTS(documentList.item(i)));
		}
		assertThat(itens.get(0)).isEqualTo(TransactionStatus.ACCC.toString());
		assertThat(itens.get(1)).isEqualTo(TransactionStatus.ACCC.toString());
		assertThat(itens.get(2)).isEqualTo(TransactionStatus.ACCC.toString());
		assertThat(itens.get(3)).isEqualTo(TransactionStatus.ACCC.toString());
		assertThat(itens.get(4)).isEqualTo(TransactionStatus.ACCC.toString());
		assertThat(itens.get(5)).isEqualTo(TransactionStatus.ACCC.toString());
		assertThat(itens.get(6)).isEqualTo(TransactionStatus.ACCC.toString());
		assertThat(itens.get(7)).isEqualTo(TransactionStatus.ACCC.toString());
		assertThat(itens.get(8)).isEqualTo(TransactionStatus.ACCC.toString());
		assertThat(itens.get(9)).isEqualTo(TransactionStatus.ACCC.toString());
	}

	@Test
	@DisplayName("Test unambiguously identify the reported status for archive pacs.002.spi.1.2_SPI_10_msg.xml")
	void shouldOrgnlEndToEndIdSpi() {
		ArrayList<String> itens = new ArrayList<>();
		Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_002_SPI));
		NodeList documentList = MessageBinderXpathPacs002Utils.getAllTxInfAndSts(document);
		for (int i =0; i<documentList.getLength();i++){
			itens.add(MessageBinderXpathPacs002Utils.getOrgnlEndToEndId(documentList.item(i)));
		}
		assertThat(itens.get(0)).isEqualTo(listOrgEndToEndId.get(0));
		assertThat(itens.get(1)).isEqualTo(listOrgEndToEndId.get(1));
		assertThat(itens.get(2)).isEqualTo(listOrgEndToEndId.get(2));
		assertThat(itens.get(3)).isEqualTo(listOrgEndToEndId.get(3));
		assertThat(itens.get(4)).isEqualTo(listOrgEndToEndId.get(4));
		assertThat(itens.get(5)).isEqualTo(listOrgEndToEndId.get(5));
		assertThat(itens.get(6)).isEqualTo(listOrgEndToEndId.get(6));
		assertThat(itens.get(7)).isEqualTo(listOrgEndToEndId.get(7));
		assertThat(itens.get(8)).isEqualTo(listOrgEndToEndId.get(8));
		assertThat(itens.get(9)).isEqualTo(listOrgEndToEndId.get(9));
	}

	@Test
	@DisplayName("Test Unique identification, as assigned by the original instructing party for the original instructed party, to unambiguously identify the original instruction for archive pacs.002.spi.1.2_SPI_10_msg.xml")
	void shouldOrgnlInstrIdSpi() {
		ArrayList<String> itens = new ArrayList<>();
		Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_002_SPI));
		NodeList documentList = MessageBinderXpathPacs002Utils.getAllTxInfAndSts(document);
		for (int i =0; i<documentList.getLength();i++){
			itens.add(MessageBinderXpathPacs002Utils.getOrgnlInstrId(documentList.item(i)));
		}
		assertThat(itens.get(0)).isEqualTo(listOrgInstrId.get(0));
		assertThat(itens.get(1)).isEqualTo(listOrgInstrId.get(1));
		assertThat(itens.get(2)).isEqualTo(listOrgInstrId.get(2));
		assertThat(itens.get(3)).isEqualTo(listOrgInstrId.get(3));
		assertThat(itens.get(4)).isEqualTo(listOrgInstrId.get(4));
		assertThat(itens.get(5)).isEqualTo(listOrgInstrId.get(5));
		assertThat(itens.get(6)).isEqualTo(listOrgInstrId.get(6));
		assertThat(itens.get(7)).isEqualTo(listOrgInstrId.get(7));
		assertThat(itens.get(8)).isEqualTo(listOrgInstrId.get(8));
		assertThat(itens.get(9)).isEqualTo(listOrgInstrId.get(9));
	}

	@Test
	@DisplayName("Test Date and time at which the message was created for archive pacs.002.spi.1.2_SPI_10_msg.xml")
	void shouldCreDtTmSpi() {
		Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_002_SPI));
		String creDtTm = MessageBinderXpathPacs002Utils.getCreDtTm(document);
		assertThat(creDtTm).isEqualTo(CRE_TM_SPI);
	}

	@Test
	@DisplayName("Definition: Point to point reference, as assigned by the instructing party, and sent to the next party in the chain to unambiguously identify the message Usage: The instructing party has to make sure that MessageIdentification is unique per instructed party for a pre-agreed period for archive pacs.002.spi.1.2_SPI_10_msg.xml")
	void shouldMsgIdfSpi() {
		Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_002_SPI));
		String msg_id = MessageBinderXpathPacs002Utils.getMsgId(document);
		assertThat(msg_id).isEqualTo(MSG_ID_SPI);
	}

	@Test
	@DisplayName("Test Specifies the status of a transaction, in a coded form for archive pacs.002.spi.1.2_PSP_CREDOR_10_msg.xml")
	void shouldTXSTSCredor() {
		ArrayList<String> itens = new ArrayList<>();
		Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_002_PSP_CREDOR));
		NodeList documentList = MessageBinderXpathPacs002Utils.getAllTxInfAndSts(document);
		for (int i =0; i<documentList.getLength();i++){
			itens.add(MessageBinderXpathPacs002Utils.getTXSTS(documentList.item(i)));
		}
		assertThat(itens.get(0)).isEqualTo(TransactionStatus.ACSP.toString());
		assertThat(itens.get(1)).isEqualTo(TransactionStatus.ACSP.toString());
		assertThat(itens.get(2)).isEqualTo(TransactionStatus.ACSP.toString());
		assertThat(itens.get(3)).isEqualTo(TransactionStatus.ACSP.toString());
		assertThat(itens.get(4)).isEqualTo(TransactionStatus.ACSP.toString());
		assertThat(itens.get(5)).isEqualTo(TransactionStatus.ACSP.toString());
		assertThat(itens.get(6)).isEqualTo(TransactionStatus.ACSP.toString());
		assertThat(itens.get(7)).isEqualTo(TransactionStatus.ACSP.toString());
		assertThat(itens.get(8)).isEqualTo(TransactionStatus.ACSP.toString());
		assertThat(itens.get(9)).isEqualTo(TransactionStatus.ACSP.toString());
	}

	@Test
	@DisplayName("Test unambiguously identify the reported status for archive pacs.002.spi.1.2_PSP_CREDOR_10_msg.xml")
	void shouldOrgnlEndToEndIdCredor() {
		ArrayList<String> itens = new ArrayList<>();
		Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_002_PSP_CREDOR));
		NodeList documentList = MessageBinderXpathPacs002Utils.getAllTxInfAndSts(document);
		for (int i =0; i<documentList.getLength();i++){
			itens.add(MessageBinderXpathPacs002Utils.getOrgnlEndToEndId(documentList.item(i)));
		}
		assertThat(itens.get(0)).isEqualTo(listOrgEndToEndIdCredor.get(0));
		assertThat(itens.get(1)).isEqualTo(listOrgEndToEndIdCredor.get(1));
		assertThat(itens.get(2)).isEqualTo(listOrgEndToEndIdCredor.get(2));
		assertThat(itens.get(3)).isEqualTo(listOrgEndToEndIdCredor.get(3));
		assertThat(itens.get(4)).isEqualTo(listOrgEndToEndIdCredor.get(4));
		assertThat(itens.get(5)).isEqualTo(listOrgEndToEndIdCredor.get(5));
		assertThat(itens.get(6)).isEqualTo(listOrgEndToEndIdCredor.get(6));
		assertThat(itens.get(7)).isEqualTo(listOrgEndToEndIdCredor.get(7));
		assertThat(itens.get(8)).isEqualTo(listOrgEndToEndIdCredor.get(8));
		assertThat(itens.get(9)).isEqualTo(listOrgEndToEndIdCredor.get(9));
	}

	@Test
	@DisplayName("Test Unique identification, as assigned by the original instructing party for the original instructed party, to unambiguously identify the original instruction for archive pacs.002.spi.1.2_PSP_CREDOR_10_msg.xml")
	void shouldOrgnlInstrIdCredor() {
		ArrayList<String> itens = new ArrayList<>();
		Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_002_PSP_CREDOR));
		NodeList documentList = MessageBinderXpathPacs002Utils.getAllTxInfAndSts(document);
		for (int i =0; i<documentList.getLength();i++){
			itens.add(MessageBinderXpathPacs002Utils.getOrgnlInstrId(documentList.item(i)));
		}
		assertThat(itens.get(0)).isEqualTo(listOrgInstIdCredor.get(0));
		assertThat(itens.get(1)).isEqualTo(listOrgInstIdCredor.get(1));
		assertThat(itens.get(2)).isEqualTo(listOrgInstIdCredor.get(2));
		assertThat(itens.get(3)).isEqualTo(listOrgInstIdCredor.get(3));
		assertThat(itens.get(4)).isEqualTo(listOrgInstIdCredor.get(4));
		assertThat(itens.get(5)).isEqualTo(listOrgInstIdCredor.get(5));
		assertThat(itens.get(6)).isEqualTo(listOrgInstIdCredor.get(6));
		assertThat(itens.get(7)).isEqualTo(listOrgInstIdCredor.get(7));
		assertThat(itens.get(8)).isEqualTo(listOrgInstIdCredor.get(8));
		assertThat(itens.get(9)).isEqualTo(listOrgInstIdCredor.get(9));
	}

	@Test
	@DisplayName("Test Date and time at which the message was created for archive pacs.002.spi.1.2_PSP_CREDOR_10_msg.xml")
	void shouldCreDtTmCredor() {
		Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_002_PSP_CREDOR));
		String creDtTm = MessageBinderXpathPacs002Utils.getCreDtTm(document);
		assertThat(creDtTm).isEqualTo(CRE_DT_TM_CREDOR);
	}

	@Test
	@DisplayName("Definition: Point to point reference, as assigned by the instructing party, and sent to the next party in the chain to unambiguously identify the message Usage: The instructing party has to make sure that MessageIdentification is unique per instructed party for a pre-agreed period for archive pacs.002.spi.1.2_PSP_CREDOR_10_msg.xml")
	void shouldMsgIdfCredor() {
		Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_002_PSP_CREDOR));
		String msg_id = MessageBinderXpathPacs002Utils.getMsgId(document);
		assertThat(msg_id).isEqualTo(MSG_ID_CREDOR);
	}

	@Test
	@DisplayName("Definition: Point to point reference, as assigned by the instructing party, and sent to the next party in the chain to unambiguously identify the message Usage: The instructing party has to make sure that MessageIdentification is unique per instructed party for a pre-agreed period for archive pacs.002.spi.1.2_ERRO_1_msg.xml")
	void shouldMsgIdfErro() {
		Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_002_ERRO));
		String msg_id = MessageBinderXpathPacs002Utils.getMsgId(document);
		assertThat(msg_id).isEqualTo(MSG_ID_ERRO);
	}

	@Test
	@DisplayName("Test Date and time at which the message was created for archive pacs.002.spi.1.2_ERRO_1_msg.xml")
	void shouldCreDtTmErro() {
		Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_002_ERRO));
		String creDtTm = MessageBinderXpathPacs002Utils.getCreDtTm(document);
		assertThat(creDtTm).isEqualTo(CRE_DT_TM_ERRO);
	}

	@Test
	@DisplayName("Test Unique identification, as assigned by the original instructing party for the original instructed party, to unambiguously identify the original instruction for archive pacs.002.spi.1.2_ERRO_1_msg.xml")
	void shouldOrgnlInstrIdErro() {
		ArrayList<String> itens = new ArrayList<>();
		Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_002_ERRO));
		NodeList documentList = MessageBinderXpathPacs002Utils.getAllTxInfAndSts(document);
		for (int i =0; i<documentList.getLength();i++){
			itens.add(MessageBinderXpathPacs002Utils.getOrgnlInstrId(documentList.item(i)));
		}
		assertThat(itens.get(0)).isEqualTo(listOrgInstrIdErro.get(0));
	}

	@Test
	@DisplayName("Test unambiguously identify the reported status for archive pacs.002.spi.1.2_ERRO_1_msg.xml")
	void shouldOrgnlEndToEndIdErro() {
		ArrayList<String> itens = new ArrayList<>();
		Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_002_ERRO));
		NodeList documentList = MessageBinderXpathPacs002Utils.getAllTxInfAndSts(document);
		for (int i =0; i<documentList.getLength();i++){
			itens.add(MessageBinderXpathPacs002Utils.getOrgnlInstrId(documentList.item(i)));
		}
		assertThat(itens.get(0)).isEqualTo(listOrgEndToEndIdErro.get(0));
	}

	@Test
	@DisplayName("Test Specifies the status of a transaction, in a coded form for archive pacs.002.spi.1.2_ERRO_1_msg.xml")
	void shouldTXSTSErro() {
		ArrayList<String> itens = new ArrayList<>();
		Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_002_ERRO));
		NodeList documentList = MessageBinderXpathPacs002Utils.getAllTxInfAndSts(document);
		for (int i =0; i<documentList.getLength();i++){
			itens.add(MessageBinderXpathPacs002Utils.getTXSTS(documentList.item(i)));
		}
		assertThat(itens.get(0)).isEqualTo(TransactionStatus.RJCT.toString());
	}

	@Test
	@DisplayName("Test Provides detailed information on the status reason for archive pacs.002.spi.1.2_ERRO_1_msg.xml")
	void shouldCDErro() {
		ArrayList<String> itens = new ArrayList<>();
		Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_002_ERRO));
		NodeList documentList = MessageBinderXpathPacs002Utils.getAllTxInfAndSts(document);
		for (int i =0; i<documentList.getLength();i++){
			itens.add(MessageBinderXpathPacs002Utils.getCodeError(documentList.item(i)));
		}
		assertThat(itens.get(0)).isEqualTo(CD_ERRO);
	}

	private String getXml(String arquivo) {
		return getStringFromXmlFile(arquivo);
	}
}
