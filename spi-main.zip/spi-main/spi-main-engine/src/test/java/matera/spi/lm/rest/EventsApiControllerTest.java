package matera.spi.lm.rest;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.utils.EventEntityUtils;
import matera.spi.main.utils.FileUtils;
import matera.spi.main.utils.PaymentTransactionUtils;
import matera.spi.main.utils.ReceiptTransactionUtils;

import io.restassured.RestAssured;
import net.javacrumbs.jsonunit.JsonAssert;
import org.apache.commons.compress.utils.Lists;
import org.eclipse.jetty.http.HttpStatus;
import org.hamcrest.Matchers;
import org.json.JSONException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpHeaders;
import org.springframework.web.util.UriComponentsBuilder;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static matera.spi.main.domain.model.event.EventStatus.PAYMENT_INITIALIZED;
import static matera.spi.main.domain.model.event.EventStatus.RECEIPT_RECEIVED;
import static matera.spi.utils.LocalDateTimeUtils.formatToQueryParamPattern;
import static matera.spi.utils.LocalDateTimeUtils.getMaxLocalDateTime;
import static matera.spi.utils.LocalDateTimeUtils.getMinLocalDateTime;
import static matera.spi.utils.LocalDateTimeUtils.getTodayUTC;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@IntegrationTest
public class EventsApiControllerTest  {

    private final String EVENTS_BASE_URI = "ui/v1/events";
    private final String EVENTS_TYPE = "/types";
    private final String EVENTS_STATUS = "/statuses";

    private List<EventEntity> insertedEvents;

    private final String RESPONSE_EVENT_TYPES_LIST =
        FileUtils.getStringFromJsonFile("events/response_find_all_event_types.json");
    private final String RESPONSE_EVENT_STATUS_LIST =
        FileUtils.getStringFromJsonFile("events/response_find_all_event_status.json");
    private final String RESPONSE_EVENTS_LIST =
        FileUtils.getStringFromJsonFile("events/response_find_all_events.json");
    private final String RESPONSE_EVENTS_LIST_FILTRED_BY_EVENT_ID =
        FileUtils.getStringFromJsonFile("events/response_find_all_events_filtred_by_event_id.json");
    private final String RESPONSE_EVENTS_LIST_FILTRED_BY_EVENT_TYPE_CODE =
        FileUtils.getStringFromJsonFile("events/response_find_all_events_filtred_by_event_type_code.json");
    private final String RESPONSE_EVENTS_LIST_FILTRED_BY_EVENT_STATUS_CODE =
        FileUtils.getStringFromJsonFile("events/response_find_all_events_filtred_by_event_status_code.json");
    private final String RESPONSE_EVENTS_LIST_FILTRED_BY_TIMESTAMP_ASCENDENTING =
        FileUtils.getStringFromJsonFile("events/response_find_all_events_filtred_by_timestamp_ascendenting.json");
    private final String RESPONSE_EVENTS_LIST_FILTRED_BY_CORRELATION_ID =
        FileUtils.getStringFromJsonFile("events/response_find_all_events_filtred_by_correlation_id.json");

    @Autowired
    private PaymentTransactionUtils paymentUtils;

    @Autowired
    private ReceiptTransactionUtils receiptUtils;

    @Autowired
    private EventEntityUtils eventEntityUtils;

    private Map<String, String> urlVariables = new HashMap<>();

    @Autowired
    @LocalServerPort
    private int port;

    @BeforeEach
    void beforeEach() throws InterruptedException {
        RestAssured.port = port;
        insertedEvents = Lists.newArrayList();
        urlVariables.put("startTimestampUtc", formatToQueryParamPattern(getMinLocalDateTime(getTodayUTC())));
        urlVariables.put("endTimestampUtc", formatToQueryParamPattern(getMaxLocalDateTime(getTodayUTC())));
        addEventsInDB();
    }

    @AfterEach
    void clearDataBase() {
        urlVariables.clear();
        paymentUtils.deleteAllInsertedValues();
        receiptUtils.deleteAllInsertedValues();
    }

    @Test
    void shouldReturnListOfEventType() throws JSONException {
        final String responseEventTypeDTO =
            RestAssured.given().log().all().when().get(EVENTS_BASE_URI + EVENTS_TYPE).getBody().asString();

        assertNotNull(responseEventTypeDTO);
        JsonAssert.assertJsonEquals(RESPONSE_EVENT_TYPES_LIST, responseEventTypeDTO);
    }

    @Test
    void shouldReturnListOfEventStatus() throws JSONException {
        final String responseEventStatusDTO =
            RestAssured.given().log().all().when().get(EVENTS_BASE_URI + EVENTS_STATUS).getBody().asString();

        assertNotNull(responseEventStatusDTO);
        JsonAssert.assertJsonEquals(RESPONSE_EVENT_STATUS_LIST, responseEventStatusDTO);
    }

    @Test
    void shouldReturnListOfEvents() throws JSONException {
        final String responseEventStatusDTO =
            RestAssured.given()
                .log().all()
                .header("pageSize", 5)
                .header("pageNumber", 0)
                .when()
                .get(getEventUri(EVENTS_BASE_URI))
                .getBody()
                .asString();

        JsonAssert.assertJsonEquals(RESPONSE_EVENTS_LIST, responseEventStatusDTO);
    }

    @Test
    void shouldReturnListOfEventsFiltredByEventId() throws JSONException {
        urlVariables.put("eventId", insertedEvents.get(0).getId().toString());
        final String responseEventStatusDTO =
            RestAssured.given()
                .log().all()
                .header("pageSize", 5)
                .header("pageNumber", 0)
                .when()
                .get(getEventUri(EVENTS_BASE_URI))
                .getBody()
                .asString();

        JsonAssert.assertJsonEquals(RESPONSE_EVENTS_LIST_FILTRED_BY_EVENT_ID, responseEventStatusDTO);
    }

    @Test
    void shouldReturnListOfEventsFiltredByEventTypeCode() throws JSONException {
        urlVariables.put("eventTypeCode", insertedEvents.get(1).getEventType().getCode().toString());
        final String responseEventStatusDTO =
            RestAssured.given()
                .log().all()
                .header("pageSize", 5)
                .header("pageNumber", 0)
                .when()
                .get(getEventUri(EVENTS_BASE_URI))
                .getBody()
                .asString();

        JsonAssert.assertJsonEquals(RESPONSE_EVENTS_LIST_FILTRED_BY_EVENT_TYPE_CODE, responseEventStatusDTO);
    }

    @Test
    void shouldReturnListOfEventsFiltredByEventStatusCode() throws JSONException {
        urlVariables.put("eventStatusCode", insertedEvents.get(0).getStatus().getCode().toString());
        final String responseEventStatusDTO =
            RestAssured.given()
                .log().all()
                .header("pageSize", 5)
                .header("pageNumber", 0)
                .when()
                .get(getEventUri(EVENTS_BASE_URI))
                .getBody()
                .asString();

        JsonAssert.assertJsonEquals(RESPONSE_EVENTS_LIST_FILTRED_BY_EVENT_STATUS_CODE, responseEventStatusDTO);
    }

    @Test
    void shouldReturnListOfEventsFiltredByTimestampAscendenting() throws JSONException {
        urlVariables.put("ordering", "initiationTimestampUTC");
        urlVariables.put("orderingDirection", "ASC");
        final String responseEventStatusDTO =
            RestAssured.given()
                .log().all()
                .header("pageSize", 5)
                .header("pageNumber", 0)
                .when()
                .get(getEventUri(EVENTS_BASE_URI))
                .getBody()
                .asString();

        JsonAssert.assertJsonEquals(RESPONSE_EVENTS_LIST_FILTRED_BY_TIMESTAMP_ASCENDENTING, responseEventStatusDTO);
    }

    @Test
    void shouldReturnListOfEventsFilteredByCorrelationId() {
        urlVariables.put("correlationId", insertedEvents.get(1).getCorrelationId());
        final String responseEventStatusDTO =
            RestAssured.given()
                .log().all()
                .header("pageSize", 5)
                .header("pageNumber", 0)
                .when()
                .get(getEventUri(EVENTS_BASE_URI))
                .getBody()
                .asString();

        JsonAssert.assertJsonEquals(RESPONSE_EVENTS_LIST_FILTRED_BY_CORRELATION_ID, responseEventStatusDTO);
    }

    @Test
    void shouldReturnListOfEventsFilteredByCorrelationIdWithEmptyValue() {
        urlVariables.put("correlationId", "");
        final String responseEventStatusDTO =
            RestAssured.given()
                .log().all()
                .header("pageSize", 5)
                .header("pageNumber", 0)
                .when()
                .get(getEventUri(EVENTS_BASE_URI))
                .getBody()
                .asString();

        JsonAssert.assertJsonEquals(RESPONSE_EVENTS_LIST, responseEventStatusDTO);
    }

    @Test
    void shouldReturnListOfEventsFilteredByCorrelationIdConsideringOriginalCorrelationId() {
        EventEntity eventEntity = insertedEvents.get(1);
        eventEntity.setOriginalCorrelationId(eventEntity.getCorrelationId());
        eventEntity.setCorrelationId(null);
        eventEntityUtils.saveEventEntity(eventEntity);

        urlVariables.put("correlationId", eventEntity.getOriginalCorrelationId());
        final String responseEventStatusDTO =
            RestAssured.given()
                .log().all()
                .header("pageSize", 5)
                .header("pageNumber", 0)
                .when()
                .get(getEventUri(EVENTS_BASE_URI))
                .getBody()
                .asString();

        JsonAssert.assertJsonEquals(RESPONSE_EVENTS_LIST_FILTRED_BY_CORRELATION_ID, responseEventStatusDTO);
    }

    @Test
    void shouldReturnBadRequestWhenStartTimestampUtcIsAfterEndTimestampUtc() throws JSONException {
        final LocalDateTime startTimestamp = getMaxLocalDateTime(LocalDate.now());
        final LocalDateTime endTimestamp = startTimestamp.minusDays(1);

        urlVariables.put("correlationId", insertedEvents.get(1).getCorrelationId());
        urlVariables.put("startTimestampUtc", formatToQueryParamPattern(startTimestamp));
        urlVariables.put("endTimestampUtc", formatToQueryParamPattern(endTimestamp));

        RestAssured.given()
            .log().all()
            .header("pageSize", 5)
            .header("pageNumber", 0)
            .header(HttpHeaders.ACCEPT_LANGUAGE,"en-US")
            .when()
            .get(getEventUri(EVENTS_BASE_URI))
            .then()
            .assertThat()
            .statusCode(HttpStatus.BAD_REQUEST_400)
            .body("error[0].message",
            Matchers.startsWith("The value of endTimestampUtc must be greater than startTimestampUtc"));
    }

    private String getEventUri(String baseUri) {
        final UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder.fromUriString(baseUri);
        urlVariables.entrySet()
            .forEach(entry -> uriComponentsBuilder.queryParam(entry.getKey(), entry.getValue()));
        return uriComponentsBuilder.toUriString();
    }

    private void addEventsInDB() throws InterruptedException {
        insertedEvents.add(paymentUtils.newPaymentEntity(BigDecimal.TEN, PAYMENT_INITIALIZED.getCode()).getEvent());
        Thread.sleep(1000L);
        insertedEvents.add(receiptUtils.newReceiptEntity(BigDecimal.ONE, RECEIPT_RECEIVED.getCode()).getEvent());
    }

}
