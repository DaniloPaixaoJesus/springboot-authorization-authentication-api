package matera.spi.main.commons.persistence.repository;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.ErrorReasonEntity;
import matera.spi.main.persistence.ErrorReasonRepository;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Optional;

@IntegrationTest
public class ErrorReasonRepositoryTest  {

    private static final Integer CODE = 123;
    private static final String DESCRIPTION = "description error reason";

    @Autowired
    private ErrorReasonRepository repository;

    private ErrorReasonEntity errorReasonEntity;

    @BeforeEach
    void init() {
        errorReasonEntity = createObject();
    }

    @AfterEach
    void clearDatabase() {
        repository.deleteAll();
    }

    @Test
    public void saveAndFlush() {
        Optional<ErrorReasonEntity> optionalErrorReasonEntity = repository.findByDescription(DESCRIPTION);
        if(optionalErrorReasonEntity.isPresent()) {
            Assertions.assertNotNull(optionalErrorReasonEntity.get().getCode());
            Assertions.assertNotNull(optionalErrorReasonEntity.get().getDescription());
            Assertions.assertEquals(CODE, optionalErrorReasonEntity.get().getCode());
            Assertions.assertEquals(DESCRIPTION, optionalErrorReasonEntity.get().getDescription());
        }
    }

    @Test
    public void findByDescription() {
        Optional<ErrorReasonEntity> optional =  repository.findByDescription(DESCRIPTION);
        if(optional.isPresent())
            Assertions.assertEquals(DESCRIPTION, optional.get().getDescription());
    }

    private ErrorReasonEntity createObject() {
        ErrorReasonEntity errorReasonEntity = new ErrorReasonEntity();
        errorReasonEntity.setCode(CODE);
        errorReasonEntity.setDescription(DESCRIPTION);
        return repository.saveAndFlush(errorReasonEntity);
    }
}
