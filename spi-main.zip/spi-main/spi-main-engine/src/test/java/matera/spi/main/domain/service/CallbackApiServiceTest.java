package matera.spi.main.domain.service;

import com.matera.spi.callback.model.CallbackIntantsPaymentsWrapperDTO;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.ClientSystemEntity;
import matera.spi.main.exception.CallbackException;
import matera.spi.main.exception.CallbackInternalErrorException;
import matera.spi.main.exception.CallbackUnavailableException;
import matera.spi.main.exception.MessageSendingException;
import matera.spi.main.persistence.ClientSystemRepository;
import matera.spi.main.utils.WireMockUtils;

import com.github.tomakehurst.wiremock.WireMockServer;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

import java.nio.charset.Charset;
import java.util.Random;

import static matera.spi.main.utils.WireMockUtils.WIREMOCK_PORT;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.resetAllRequests;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

@IntegrationTest
class CallbackApiServiceTest {

    private static final String CLIENT_ID = "CLIENT_ID";
    private static final String NAME_SYSTEM = "NAME_SYSTEM";
    private static final String SECRET = "SECRET";
    private static final String URL_CALLBACK = "http://localhost:" + WIREMOCK_PORT;
    private static final String URL_O_AUTH = "http://localhost:" + WIREMOCK_PORT;
    public static final String NOT_FOUND_CODE_SYSTEM = "not found code system";

    @Autowired
    private CallbackService callbackService;

    @Autowired
    private ApplicationContext context;

    private static final String OAUTH_CALLBACK = "/api/oauth/token";
    private static final String PAYMENTS_CALLBACK = "/v1/instant-payments/callback/";

	@Autowired
	private CallbackApiService callbackApiService;

    @Autowired
    private ClientSystemRepository clientSystemRepository;

    private static final WireMockServer wireMockServer = WireMockUtils.start();

    @AfterAll
    static void afterAll() {
        wireMockServer.stop();
    }

	@BeforeEach
	void beforeEach() {
		resetAllRequests(); // needed to tests be order independent.
	}

    @Test
    void shouldThrowCallbackExceptionWhenFoundedCodeSystemIsFalse() throws MessageSendingException {

        //Given
        stubFor(post(PAYMENTS_CALLBACK).willReturn(aResponse().withStatus(HttpStatus.SERVICE_UNAVAILABLE.value())));

        //When
        CallbackIntantsPaymentsWrapperDTO callBackRequestDTO = createCallBackInstantsPaymentsWrapperDTO();
        ClientSystemEntity callbackEntity = createCallbackEntity(false, "false-code-system", URL_CALLBACK);

        //Then
        assertThatThrownBy(() -> callbackApiService.sendCallback(callBackRequestDTO, callbackEntity.getCodeSystem()))
            .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void shouldThrowCallbackExceptionWhenNotFoundCodeSystem() throws MessageSendingException {

        //Given
        stubFor(post(PAYMENTS_CALLBACK).willReturn(aResponse().withStatus(HttpStatus.OK.value())
            .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).withBody("{ \"data\": {}")));

        //When
        CallbackIntantsPaymentsWrapperDTO callBackRequestDTO = createCallBackInstantsPaymentsWrapperDTO();

        //Then
        assertThatThrownBy(() -> callbackApiService.sendCallback(callBackRequestDTO, NOT_FOUND_CODE_SYSTEM))
            .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void shouldCallCallbackApiWhenUpdateCallBackSystemCache() throws MessageSendingException {

        //Given
        stubFor(post(PAYMENTS_CALLBACK).willReturn(aResponse().withStatus(HttpStatus.OK.value())
            .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).withBody("{ \"data\": {}")));

        CallbackIntantsPaymentsWrapperDTO callBackRequestDTO = createCallBackInstantsPaymentsWrapperDTO();

        String codeSystem = "code-system";
        ClientSystemEntity callbackEntity = createCallbackEntity(true, codeSystem, "/");

        //When
        callbackEntity.setUrlCallback(URL_CALLBACK);
        clientSystemRepository.saveAndFlush(callbackEntity);

        //Then
        callbackApiService.sendCallback(callBackRequestDTO, codeSystem);

    }

    @Test
	void shouldCallCallbackApiWhenCallingSendCallback() throws MessageSendingException {

        //Given
        stubFor(post(PAYMENTS_CALLBACK).willReturn(aResponse().withStatus(HttpStatus.OK.value())
            .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).withBody("{ \"data\": {}")));

        //When
        CallbackIntantsPaymentsWrapperDTO callBackRequestDTO = createCallBackInstantsPaymentsWrapperDTO();

        ClientSystemEntity callbackEntity = createCallbackEntity();

        //Then
        callbackApiService.sendCallback(callBackRequestDTO, callbackEntity.getCodeSystem());
    }

	@Test
	void shouldThrownCallbackUnavailableExceptionWhenCallbackRespondsWithRestServiceUnavailableException() {

        //Given
        stubFor(post(PAYMENTS_CALLBACK).willReturn(aResponse().withStatus(HttpStatus.SERVICE_UNAVAILABLE.value())));

		//When
        CallbackIntantsPaymentsWrapperDTO callBackRequestDTO = new CallbackIntantsPaymentsWrapperDTO();
        ClientSystemEntity callbackEntity = createCallbackEntity();

        //Then
		assertThatThrownBy(() -> callbackApiService.sendCallback(callBackRequestDTO, callbackEntity.getCodeSystem()))
				.isInstanceOf(CallbackUnavailableException.class);
	}


	@Test
	void shouldThrownCallbackInternalErrorExceptionWhenCallbackRespondsWithInternalServerErrorException() {

        //Given
        stubFor(post(PAYMENTS_CALLBACK).willReturn(aResponse().withStatus(HttpStatus.INTERNAL_SERVER_ERROR.value())));

		//When
        CallbackIntantsPaymentsWrapperDTO callBackRequestDTO = new CallbackIntantsPaymentsWrapperDTO();

        //Then
        assertThatThrownBy(() -> callbackApiService.sendCallback(callBackRequestDTO, createCallbackEntity().getCodeSystem()))
				.isInstanceOf(CallbackInternalErrorException.class);
	}

    private ClientSystemEntity createCallbackEntity() {
        byte[] array = new byte[7]; // length is bounded by 7
        new Random().nextBytes(array);
        String generatedString = new String(array, Charset.forName("UTF-8"));

        return createCallbackEntity(true, generatedString, URL_CALLBACK);
    }

    private ClientSystemEntity createCallbackEntity(boolean active, String codeSystem, String urlCallback) {

        ClientSystemEntity clientSystemEntity = new ClientSystemEntity();
        clientSystemEntity.setClientId(CLIENT_ID);
        clientSystemEntity.setCodeSystem(codeSystem);
        clientSystemEntity.setNameSystem(NAME_SYSTEM);
        clientSystemEntity.setSecret(SECRET);
        clientSystemEntity.setUrlCallback(urlCallback);
        clientSystemEntity.setUrlOAuth(URL_O_AUTH + OAUTH_CALLBACK);
        clientSystemEntity.setActive(active);
        return callbackService.createCallbackEntity(clientSystemEntity);
    }

    private CallbackIntantsPaymentsWrapperDTO createCallBackInstantsPaymentsWrapperDTO() {
        CallbackIntantsPaymentsWrapperDTO callBackRequestDTO = new CallbackIntantsPaymentsWrapperDTO();
        callBackRequestDTO.setEndToEndId("E123456789");
        callBackRequestDTO.setOriginalSystemTransactionIdentifier("9658743114681");
        callBackRequestDTO.setEventId("33652144");
        return callBackRequestDTO;
    }


}

