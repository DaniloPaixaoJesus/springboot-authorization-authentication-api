package matera.spi.indirect.application.service.mapper;

import matera.spi.dto.IndirectParticipantHistoryDTO;
import matera.spi.dto.IndirectParticipantHistoryEventTypeDTO;
import matera.spi.dto.IndirectParticipantStatusDTO;
import matera.spi.dto.PageableIndirectParticipantHistoryResponseDTO;
import matera.spi.indirect.domain.model.ParticipantMipIndirectEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectHistoryEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectStatusEntity;
import matera.spi.indirect.domain.model.enums.IndirectParticipantStatusEnum;
import matera.spi.indirect.persistence.ParticipantMipIndirectStatusRepository;
import matera.spi.indirect.util.ParticipantMipIndirectDataSetUtil;
import matera.spi.main.domain.model.ParticipantMipEntity;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class IndirectParticipantHistoryMapperTest {

    private static final Integer CURRENT_PAGE = 0;
    private static final Integer PAGE_SIZE = 2;
    private static final Integer TOTAL_ELEMENTS = 10;

    @Mock
    private ParticipantMipIndirectStatusRepository participantMipIndirectStatusRepository;

    @Test
    void shouldMapEntityToDTO() {
        Sort sort = Sort.by("eventDateTime");
        Pageable page = PageRequest.of(CURRENT_PAGE, PAGE_SIZE, sort);

        final ParticipantMipIndirectStatusEntity statusEntity =
            ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectStatusEntity();

        when(participantMipIndirectStatusRepository.findById(IndirectParticipantStatusEnum.ACTIVE.getId()))
            .thenReturn(Optional.of(statusEntity));

        final ParticipantMipEntity participantMip = ParticipantMipIndirectDataSetUtil.createParticipantMip();
        final ParticipantMipIndirectEntity participantMipIndirecEntity = ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository, participantMip);

        ParticipantMipIndirectHistoryEntity participantMipIndirectHistory =
            ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectHistoryEntity(participantMipIndirecEntity);

        final Page<ParticipantMipIndirectHistoryEntity> pageEntity =
            new PageImpl<>(List.of(participantMipIndirectHistory), page, TOTAL_ELEMENTS);

        List<IndirectParticipantHistoryDTO> historiesDTO =
            List.of(createIndirectParticipantHistoryDTO(participantMipIndirectHistory));

        final PageableIndirectParticipantHistoryResponseDTO result =
            IndirectParticipantHistoryMapper.createPageableIndirectParticipantHistoryResponseDTO(pageEntity);

        assertEquals(historiesDTO, result.getContent());
        assertTrue(participantMipIndirectHistory.getPreviousStatus().getIsActive());
        assertEquals(result.getPageable().getPageSize(), pageEntity.getPageable().getPageSize());
        assertNotNull(result);
    }

    private IndirectParticipantHistoryDTO createIndirectParticipantHistoryDTO(ParticipantMipIndirectHistoryEntity participantMipIndirectHistory) {
        IndirectParticipantHistoryDTO indirectParticipantHistoryDTO = new IndirectParticipantHistoryDTO();
        indirectParticipantHistoryDTO.setHistoryDateTime(participantMipIndirectHistory.getEventDateTime());
        indirectParticipantHistoryDTO
            .setHistoryType(IndirectParticipantHistoryEventTypeDTO.CLEARING_RESCISSION_REQUEST);
        indirectParticipantHistoryDTO.setIndirectPreviousStatus(IndirectParticipantStatusDTO.ACTIVE);

        return indirectParticipantHistoryDTO;
    }

}
