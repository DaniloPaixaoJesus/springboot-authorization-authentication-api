package matera.spi.main.domain.service;

import com.matera.spi.callback.api.SPICallbackApis;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.ClientSystemEntity;
import matera.spi.main.exception.MessageSendingException;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import java.util.Map;
import java.util.Optional;

@IntegrationTest
class CallbackServiceTest {

    private static final String CLIENT_ID = "123456789";
    private static final String NAME_SYSTEM = "123456789";
    private static final String SECRET = "123456789";
    private static final String URL_CALLBACK = "123456789";
    private static final String URL_O_AUTH = "123456789";
    public static final String CODE_SYSTEM_1 = "codeSystem1";
    public static final String CODE_SYSTEM_2 = "codeSystem2";
    public static final String CODE_SYSTEM_3 = "codeSystem3";

    @Autowired
    private CallbackService callbackService;

    private Map<String, SPICallbackApis> spiCallbackApiMap;

    @Autowired
    private ApplicationContext context;

    private ClientSystemEntity codeSystem1;

    private ClientSystemEntity codeSystem2;

    @BeforeEach
    void init() {
     codeSystem1= createCallbackEntity(CODE_SYSTEM_1, true);
     codeSystem2 = createCallbackEntity(CODE_SYSTEM_2, true);

    }

    @Test
    void shouldCreateCallbackEntity() throws MessageSendingException {
      spiCallbackApiMap= (Map<String, SPICallbackApis>) context.getBean("spiCallbackApisMaps");

        SPICallbackApis spiCallbackApi1 = spiCallbackApiMap.get(CODE_SYSTEM_1);
        SPICallbackApis spiCallbackApi2 = spiCallbackApiMap.get(CODE_SYSTEM_2);
        SPICallbackApis spiCallbackApi3 = spiCallbackApiMap.get(CODE_SYSTEM_3);

        Optional<ClientSystemEntity> codeSystem1Expected = callbackService.findByIdCallbackEntityByUUID(codeSystem1.getId());
        Optional<ClientSystemEntity> codeSystem2Expected = callbackService.findByIdCallbackEntityByUUID(codeSystem2.getId());

        Assert.assertEquals(codeSystem1Expected.get(), codeSystem1);
        Assert.assertEquals(codeSystem2Expected.get(), codeSystem2);

        Assert.assertNotNull(spiCallbackApi1);
        Assert.assertNotNull(spiCallbackApi2);

        Assert.assertNull(spiCallbackApi3);

    }

    private ClientSystemEntity createCallbackEntity(String codeSystem, boolean active) {
        ClientSystemEntity clientSystemEntity = new ClientSystemEntity();
        clientSystemEntity.setClientId(CLIENT_ID);
        clientSystemEntity.setCodeSystem(codeSystem);
        clientSystemEntity.setNameSystem(NAME_SYSTEM);
        clientSystemEntity.setSecret(SECRET);
        clientSystemEntity.setUrlCallback(URL_CALLBACK);
        clientSystemEntity.setUrlOAuth(URL_O_AUTH);
        clientSystemEntity.setActive(active);
        return callbackService.createCallbackEntity(clientSystemEntity);
    }

}

