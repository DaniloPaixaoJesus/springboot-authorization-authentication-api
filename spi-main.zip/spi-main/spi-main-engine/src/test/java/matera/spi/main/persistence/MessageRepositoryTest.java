package matera.spi.main.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.domain.model.enums.TransactionStatus;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.domain.model.message.MessageTypeEntity;
import matera.spi.main.domain.service.CorrelationIdGenerator;
import matera.spi.main.domain.service.pacs.pacs002.ContentPacs002Generator;
import matera.spi.main.domain.service.pacs.pacs002.dto.ContentPacs002;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.ZoneOffset;

@IntegrationTest
@Transactional
class MessageRepositoryTest  {

    private static final LocalDateTime LOCAL_DATE_TIME = LocalDateTime.now(ZoneOffset.UTC);

    private static final String ISPB = "9823982";

    @Autowired
    private MessageRepository repository;

    @Autowired
    private MessageTypeRepository messageTypeRepository;

    @Autowired
    private ParticipantRepository participantRepository;

    @Autowired
    private ContentPacs002Generator contentPacs002Generator;

    @Test
    void shouldFindEntityMessageByMessageId() {
        ContentPacs002 contentPacs002 = contentPacs002Generator.generate(getEndToEndId(), TransactionStatus.ACSP.name());
        final String messageId = contentPacs002.getMessageId();
        MessageEntity messageEntityActual =  createMessageEntity(contentPacs002);

        MessageEntity messageEntityExpected = repository.findMessageEntityByPiResourceIdOrMessageId(messageId).orElse(null);

        Assertions.assertEquals(messageEntityExpected.getUuid(), messageEntityActual.getUuid());
        Assertions.assertEquals(messageEntityExpected.getMessageIdXml(), contentPacs002.getMessageId());
    }

    @Test
    void shouldFindEntityMessageByResourceId() {
        final String resourceId = "ResourceIdTest001";
        ContentPacs002 contentPacs002 = contentPacs002Generator.generate(getEndToEndId(), TransactionStatus.ACSP.name());
        MessageEntity messageEntityActual =  createMessageEntity(contentPacs002);

        MessageEntity messageEntityExpected = repository.findMessageEntityByPiResourceIdOrMessageId(resourceId).orElse(null);

        Assertions.assertEquals(messageEntityExpected.getUuid(), messageEntityActual.getUuid());
        Assertions.assertEquals(messageEntityExpected.getMessageIdXml(), contentPacs002.getMessageId());
        Assertions.assertEquals(messageEntityExpected.getPiResourceId(), resourceId);
    }

    private MessageEntity createMessageEntity(ContentPacs002 contentPacs002 ) {
        MessageEntity messageEntity = new MessageEntity();
        messageEntity.setClearingTimestampUtc(LOCAL_DATE_TIME);
        messageEntity.setPiResourceId("ResourceIdTest001");
        messageEntity.setReceiverParticipant(buildReceiverParticipant());
        messageEntity.setSenderParticipant(buildSenderParticipant());
        messageEntity.setVersion("12345678");
        messageEntity.setTimestampUtc(LOCAL_DATE_TIME);
        messageEntity.setMessageTypeEntity(buildMessageTypeEntity());
        messageEntity.setMessageIdXml(contentPacs002.getMessageId());
        repository.saveAndFlush(messageEntity);
        return messageEntity;
    }

    @Test
    void shouldNotFindEntityMessage() {
        MessageEntity messageEntity = repository.findMessageEntityByPiResourceIdOrMessageId("any").orElse(null);
        Assertions.assertEquals(null, messageEntity);
    }

    @Test
    void shouldBeFindEntityWhenInserted() {

        ContentPacs002 contentPacs002 = contentPacs002Generator.generate(getEndToEndId(), TransactionStatus.ACSP.name());

        MessageEntity expected = new MessageEntity();
        expected.setClearingTimestampUtc(LOCAL_DATE_TIME);
        expected.setPiResourceId("ResourceIdTest");
        expected.setReceiverParticipant(buildReceiverParticipant());
        expected.setSenderParticipant(buildSenderParticipant());
        expected.setVersion("12345678");
        expected.setTimestampUtc(LOCAL_DATE_TIME);
        expected.setMessageTypeEntity(buildMessageTypeEntity());
        expected.setMessageIdXml(contentPacs002.getMessageId());

        repository.saveAndFlush(expected);

        MessageEntity actual = repository.findById(expected.getUuid()).orElse(null);

        Assertions.assertEquals(expected.getUuid(), actual.getUuid());
        Assertions.assertEquals(expected.getPiResourceId(), actual.getPiResourceId());
        Assertions.assertEquals(expected.getReceiverParticipant(), actual.getReceiverParticipant());
        Assertions.assertEquals(expected.getSenderParticipant(), actual.getSenderParticipant());
        Assertions.assertEquals(expected.getVersion(), actual.getVersion());
        Assertions.assertEquals(expected.getMessageIdXml(), actual.getMessageIdXml());
    }

    private ParticipantEntity buildReceiverParticipant() {
        ParticipantEntity entity = new ParticipantEntity();
        entity.setIspb(12345678);
        entity.setName("Payer Participant");
        participantRepository.saveAndFlush(entity);
        return entity;
    }

    private ParticipantEntity buildSenderParticipant() {
        ParticipantEntity entity = new ParticipantEntity();
        entity.setIspb(87654321);
        entity.setName("Receiver Participant");
        participantRepository.saveAndFlush(entity);
        return entity;
    }

    private MessageTypeEntity buildMessageTypeEntity() {
        MessageTypeEntity entity = new MessageTypeEntity();
        entity.setCode("MessageCodeTest");
        entity.setIsFinancial(false);
        messageTypeRepository.saveAndFlush(entity);
        return  entity;
    }

    private String getEndToEndId() {
        return CorrelationIdGenerator.generateCorrelactionIdPacs008(ISPB);
    }
}
