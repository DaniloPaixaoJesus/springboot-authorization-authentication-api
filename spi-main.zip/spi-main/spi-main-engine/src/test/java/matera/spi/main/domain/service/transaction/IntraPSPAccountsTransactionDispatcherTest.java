package matera.spi.main.domain.service.transaction;

import matera.spi.main.config.MainEngineConfiguration;
import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.domain.model.ParticipantMipEntity;
import matera.spi.main.domain.model.event.transaction.PaymentEventEntity;
import matera.spi.main.domain.model.event.transaction.ReceiptEventEntity;
import matera.spi.main.domain.model.event.transaction.ReturnReceivedEventEntity;
import matera.spi.main.domain.model.event.transaction.ReturnSentEventEntity;
import matera.spi.main.domain.model.transaction.PaymentEntity;
import matera.spi.main.domain.model.transaction.ReceiptEntity;
import matera.spi.main.domain.model.transaction.ReturnReceivedEntity;
import matera.spi.main.domain.model.transaction.ReturnSentEntity;
import matera.spi.main.domain.model.transaction.TransactionEntity;

import matera.spi.main.domain.service.AccountAsyncTransaction;
import matera.spi.main.domain.service.ConfigurationService;
import matera.spi.main.domain.service.ParticipantMipService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;

import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class IntraPSPAccountsTransactionDispatcherTest {

    private static final int CURRENT_PARTICIPANT_ISPB = 789;

    @Mock
    private ManagerialIPAccount managerialIPAccount;

    @Mock
    private MirrorIPAccount mirrorIPAccount;

    @Mock
    private MainEngineConfiguration mainEngineConfiguration;

    @Mock
    private AccountAsyncTransaction accountAsyncTransaction;

    @Mock
    private ParticipantMipService participantMipService;

    @Mock
    private ConfigurationService configurationService;

    @InjectMocks
    private AccountsTransactionDispatcher accountsTransactionDispatcher;

    private ParticipantEntity currentParticipant;

    private ParticipantMipEntity participantMipEntity;


    @BeforeEach
    void setUp() {

        lenient().when(configurationService.findByIspb()).thenReturn(Integer.toString(CURRENT_PARTICIPANT_ISPB));

        currentParticipant = new ParticipantEntity();
        currentParticipant.setIspb(CURRENT_PARTICIPANT_ISPB);

        participantMipEntity = new ParticipantMipEntity();
        participantMipEntity.setIspb(CURRENT_PARTICIPANT_ISPB);
        participantMipEntity.setAccountNumber(new BigDecimal(2222));
        participantMipEntity.setBranch(1111);
        participantMipEntity.setManagerialAccountEnabled(true);

        lenient().when(participantMipService.findByIspb(CURRENT_PARTICIPANT_ISPB))
            .thenReturn(Optional.of(participantMipEntity));

    }

    @Test
    void shouldNotMakeDebitMirrorOrManagerialWhenIsIntraPSPTransaction() {
        //given
        PaymentEntity transactionEntity = new PaymentEntity();
        setParticipants(transactionEntity);
        PaymentEventEntity eventMock = new PaymentEventEntity();
        eventMock.setPaymentEntity(transactionEntity);

        //when
        accountsTransactionDispatcher.makeDebit(eventMock);

        //then
        verifyNoInteractions(managerialIPAccount);
        verifyNoInteractions(mirrorIPAccount);
    }

    @Test
    void shouldNotMakeCreditMirrorOrManagerialWhenIsIntraPSPTransaction() {
        //given
        ReceiptEntity receiptEntity = new ReceiptEntity();
        setParticipants(receiptEntity);
        ReceiptEventEntity eventMock = new ReceiptEventEntity();
        eventMock.setReceiptEntity(receiptEntity);

        //when
        accountsTransactionDispatcher.makeCredit(eventMock);

        //then
        verifyNoInteractions(managerialIPAccount);
        verifyNoInteractions(mirrorIPAccount);
    }

    @Test
    void shouldNotMakeReturnSentMirrorOrManagerialWhenIsIntraPSPTransaction() {
        //given
        ReturnSentEntity returnSentEntity = new ReturnSentEntity();
        setParticipants(returnSentEntity);
        ReturnSentEventEntity eventMock = new ReturnSentEventEntity();
        eventMock.setReturnSentEntity(returnSentEntity);

        //when
        accountsTransactionDispatcher.returnSent(eventMock);

        //then
        verifyNoInteractions(managerialIPAccount);
        verifyNoInteractions(mirrorIPAccount);
    }

    @Test
    void shouldNotMakeReturnReceivedMirrorOrManagerialWhenIsIntraPSPTransaction() {
        //given
        ReturnReceivedEntity returnReceivedEntity = new ReturnReceivedEntity();
        setParticipants(returnReceivedEntity);
        ReturnReceivedEventEntity eventMock = new ReturnReceivedEventEntity();
        eventMock.setReturnReceivedEntity(returnReceivedEntity);

        //when
        accountsTransactionDispatcher.returnReceived(eventMock);

        //then
        verifyNoInteractions(managerialIPAccount);
        verifyNoInteractions(mirrorIPAccount);
    }

    private void setParticipants(TransactionEntity transactionEntity) {
        transactionEntity.setPayerParticipant(currentParticipant);
        transactionEntity.setReceiverParticipant(currentParticipant);
    }
}
