package matera.spi.indirect.exception.message;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.Arrays;
import java.util.Properties;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

class ExceptionMessagesTest {

    private static final Properties PROPERTIES_EN = new Properties();
    private static final Properties PROPERTIES_PT_BR = new Properties();
    private static final String INDIRECT_ERROR_MESSAGES_EN = "indirect/indirect_error_messages.properties";
    private static final String INDIRECT_ERROR_MESSAGES_PT_BR = "indirect/indirect_error_messages_pt_BR.properties";
    private static final String THERE_IS_A_MESSAGE_NOT_PRESENT_IN_EN_PROPERTIES_FILE =
        "There is a message not present in (EN) properties file.";
    private static final String THERE_IS_A_MESSAGE_NOT_PRESENT_IN_PT_BR_PROPERTIES_FILE =
        "There is a message not present in (PT_BR) properties file.";
    private static final String SOME_MESSAGE_EN_IS_NOT_PRESENT_IN_ENUM = "Some message (EN) is not present in enum";
    private static final String SOME_MESSAGE_PT_BR_IS_NOT_PRESENT_IN_ENUM = "Some message (PT_BR) is not present in enum";

    @BeforeAll
    static void beforeAll() {
        try {
            final ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();

            PROPERTIES_EN.load(contextClassLoader.getResourceAsStream(INDIRECT_ERROR_MESSAGES_EN));
            PROPERTIES_PT_BR.load(contextClassLoader.getResourceAsStream(INDIRECT_ERROR_MESSAGES_PT_BR));
        } catch (IOException e) {
            Assertions.fail(e);
        }
    }

    @Test
    void shouldEachMessageBeEqualToEachRespectivePropertyInEnglish() {
        final boolean messageNotPresentInPropertiesEN = Arrays.stream(ExceptionMessages.values())
            .map(ExceptionMessages::getCode).anyMatch(code -> PROPERTIES_EN.keySet().stream().noneMatch(code::equals));

        assertFalse(messageNotPresentInPropertiesEN, THERE_IS_A_MESSAGE_NOT_PRESENT_IN_EN_PROPERTIES_FILE);

        final boolean messageNotPresentInPropertiesPT_BR = Arrays.stream(ExceptionMessages.values())
            .map(ExceptionMessages::getCode).anyMatch(code -> PROPERTIES_PT_BR.keySet().stream().noneMatch(code::equals));

        assertFalse(messageNotPresentInPropertiesPT_BR, THERE_IS_A_MESSAGE_NOT_PRESENT_IN_PT_BR_PROPERTIES_FILE);

        final int messagesLength = ExceptionMessages.values().length;

        assertEquals(PROPERTIES_EN.size(), messagesLength, SOME_MESSAGE_EN_IS_NOT_PRESENT_IN_ENUM);
        assertEquals(PROPERTIES_PT_BR.size(), messagesLength, SOME_MESSAGE_PT_BR_IS_NOT_PRESENT_IN_ENUM);
    }

}
