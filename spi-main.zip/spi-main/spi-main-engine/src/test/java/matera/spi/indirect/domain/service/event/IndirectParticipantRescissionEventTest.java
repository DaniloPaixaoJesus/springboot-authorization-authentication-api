package matera.spi.indirect.domain.service.event;

import com.matera.spi.messaging.model.MessageSentResponseDTO;

import matera.spi.indirect.domain.model.ParticipantMipIndirectEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectHistoryEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectStatusEntity;
import matera.spi.indirect.domain.model.event.IndirectParticipantRescissionEventEntity;
import matera.spi.indirect.domain.service.IndirectParticipantHistoryService;
import matera.spi.indirect.domain.service.IndirectParticipantMipService;
import matera.spi.indirect.domain.service.IndirectParticipantStatusService;
import matera.spi.indirect.domain.service.IndirectParticipantUpdateService;
import matera.spi.indirect.domain.service.messages.factory.reda031.Reda031Factory;
import matera.spi.indirect.domain.service.messages.factory.reda031.dto.Reda031DTO;
import matera.spi.indirect.dto.event.IndirectParticipantRescissionEventSpecificationDTO;
import matera.spi.indirect.util.ParticipantMipIndirectDataSetUtil;
import matera.spi.main.config.MainEngineConfiguration;
import matera.spi.main.domain.model.ConfigEntity;
import matera.spi.main.domain.model.ParticipantMipEntity;
import matera.spi.main.domain.model.event.EventStatus;
import matera.spi.main.domain.model.event.EventStatusEntity;
import matera.spi.main.domain.model.event.EventTypeEntity;
import matera.spi.main.domain.model.message.MessageCatalogSpecificationEntity;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.domain.model.message.MessageTypeEntity;
import matera.spi.main.domain.service.ConfigurationService;
import matera.spi.main.domain.service.MessageCatalogSpecificationService;
import matera.spi.main.domain.service.MessageIdService;
import matera.spi.main.domain.service.PrincipalAuthenticationService;
import matera.spi.main.domain.service.event.EventStatusService;
import matera.spi.main.domain.service.util.MessageBinderXpathReda016Utils;
import matera.spi.main.domain.service.util.MessagingResilienceHelper;
import matera.spi.main.dto.event.EventSpecificationFromReceivedMessageDTO;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.MessageRepository;
import matera.spi.main.persistence.ParticipantRepository;
import matera.spi.utils.DocumentUtils;

import org.apache.commons.lang3.StringUtils;
import org.hamcrest.MatcherAssert;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static matera.spi.utils.DocumentUtils.stringToXmlDocument;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class IndirectParticipantRescissionEventTest {

    private static final String REDA_016_ERRO_MSG_XML = "reda.016/reda.016_erro_msg.xml";
    private static final Document REDA_016_ERRO_MSG_DOCUMENT =
        stringToXmlDocument(getStringFromXmlFile(REDA_016_ERRO_MSG_XML));
    private static final String REDA_016_ERRO_MSG_WITHOUT_DATE_XML = "reda.016/reda.016_erro_msg_without_date.xml";
    private static final Document REDA_016_ERRO_MSG_WITHOUT_DATE_DOCUMENT =
        stringToXmlDocument(getStringFromXmlFile(REDA_016_ERRO_MSG_WITHOUT_DATE_XML));
    public static final String SPECIFIC_ELEMENT_FROM_REDA016_ERROR_MSG =
        "Envelope/Document/PtyStsAdvc/PtySts/StsRsn/Rsn/Prtry";

    private MessageIdService messageIdService;
    private Reda031Factory reda031Factory;
    private ParticipantRepository participantRepository;
    private MainEngineConfiguration mainEngineConfiguration;
    private ConfigurationService configurationService;
    private MessageCatalogSpecificationService messageCatalogSpecificationService;
    private MessagingResilienceHelper messagingResilienceHelper;
    private MessageRepository messageRepository;
    private IndirectParticipantMipService indirectParticipantMipService;
    private IndirectParticipantUpdateService indirectParticipantUpdateService;
    private EventStatusService eventStatusService;
    private PrincipalAuthenticationService principalAuthenticationService;
    private IndirectParticipantHistoryService indirectParticipantHistoryService;
    private IndirectParticipantStatusService indirectParticipantStatusService;
    private EventRepository eventRepository;
    private IndirectParticipantRescissionEventEntity rescissionEventEntity;
    private ConfigEntity configEntity;
    private IndirectParticipantRescissionEvent rescissionEvent;
    private final ParticipantMipIndirectHistoryEntity participantMipIndirectHistory =
        new ParticipantMipIndirectHistoryEntity();
    private final IndirectParticipantRescissionEventSpecificationDTO
        indirectParticipantRescissionEventSpecificationDTO =
        new IndirectParticipantRescissionEventSpecificationDTO(participantMipIndirectHistory);

    @BeforeEach
    void setUp() {
        createMocks();
        injectMocks();
    }

    private void createMocks() {
        messageIdService = mock(MessageIdService.class);
        reda031Factory = mock(Reda031Factory.class);
        participantRepository = mock(ParticipantRepository.class);
        mainEngineConfiguration = mock(MainEngineConfiguration.class);
        configurationService = mock(ConfigurationService.class);
        messageCatalogSpecificationService = mock(MessageCatalogSpecificationService.class);
        messagingResilienceHelper = mock(MessagingResilienceHelper.class);
        eventStatusService = mock(EventStatusService.class);
        principalAuthenticationService = mock(PrincipalAuthenticationService.class);
        indirectParticipantHistoryService = mock(IndirectParticipantHistoryService.class);
        indirectParticipantStatusService = mock(IndirectParticipantStatusService.class);
        eventRepository = mock(EventRepository.class);
        configEntity = new ConfigEntity();
        messageRepository = mock(MessageRepository.class);
        indirectParticipantMipService = mock(IndirectParticipantMipService.class);
        rescissionEventEntity = spy(new IndirectParticipantRescissionEventEntity());
        indirectParticipantUpdateService = mock(IndirectParticipantUpdateService.class);
    }

    private void injectMocks() {
        configEntity = new ConfigEntity();
        rescissionEvent =
            spy(new IndirectParticipantRescissionEvent(indirectParticipantRescissionEventSpecificationDTO));
        ReflectionTestUtils.setField(rescissionEvent, "eventEntity", rescissionEventEntity);
        ReflectionTestUtils.setField(rescissionEvent, "reda031Factory", reda031Factory);
        ReflectionTestUtils.setField(rescissionEvent, "messageIdService", messageIdService);
        ReflectionTestUtils.setField(rescissionEvent, "participantRepository", participantRepository);
        ReflectionTestUtils.setField(rescissionEvent, "mainEngineConfiguration", mainEngineConfiguration);
        ReflectionTestUtils.setField(rescissionEvent, "configurationService", configurationService);
        ReflectionTestUtils
            .setField(rescissionEvent, "messageCatalogSpecificationService", messageCatalogSpecificationService);
        ReflectionTestUtils.setField(rescissionEvent, "messagingResilienceHelper", messagingResilienceHelper);
        ReflectionTestUtils.setField(rescissionEvent, "messageRepository", messageRepository);
        ReflectionTestUtils.setField(rescissionEvent, "eventStatusService", eventStatusService);
        ReflectionTestUtils.setField(rescissionEvent, "principalAuthenticationService", principalAuthenticationService);
        ReflectionTestUtils.setField(rescissionEvent, "indirectParticipantHistoryService", indirectParticipantHistoryService);
        ReflectionTestUtils.setField(rescissionEvent, "indirectParticipantStatusService", indirectParticipantStatusService);
        ReflectionTestUtils.setField(rescissionEvent, "eventRepository", eventRepository);
        ReflectionTestUtils.setField(rescissionEvent, "indirectParticipantUpdateService", indirectParticipantUpdateService);
    }

    @Test
    void shouldBeConstructUsingDto() {
        final IndirectParticipantRescissionEvent event = new IndirectParticipantRescissionEvent(
            new IndirectParticipantRescissionEventSpecificationDTO(new ParticipantMipIndirectHistoryEntity()));

        final IndirectParticipantRescissionEventEntity eventEntity = assertDoesNotThrow(event::getEventEntity);

        assertNotNull(eventEntity);
    }

    @Test
    void shouldBeConstructUsingEntity() {
        final IndirectParticipantRescissionEvent event =
            new IndirectParticipantRescissionEvent(indirectParticipantRescissionEventSpecificationDTO);

        final IndirectParticipantRescissionEventEntity eventEntity = assertDoesNotThrow(event::getEventEntity);

        Assertions.assertNotNull(eventEntity);
    }

    @Test
    void shouldFillSpecializedEventEntityAttributesFromEventSpecification() {
        final IndirectParticipantRescissionEvent event =
            Mockito.spy(new IndirectParticipantRescissionEvent(new IndirectParticipantRescissionEventSpecificationDTO(new ParticipantMipIndirectHistoryEntity())));

        final ParticipantMipIndirectHistoryEntity historyEntity = new ParticipantMipIndirectHistoryEntity();

        final IndirectParticipantRescissionEventSpecificationDTO dto =
            new IndirectParticipantRescissionEventSpecificationDTO(historyEntity);

        Assertions.assertDoesNotThrow(() -> event.fillSpecializedEventEntityAttributesFromEventSpecification(dto));
        assertDoesNotThrow(() -> rescissionEvent.fillSpecializedEventEntityAttributesFromEventSpecification(dto));

        final IndirectParticipantRescissionEventEntity eventEntity =
            assertDoesNotThrow(rescissionEvent::getEventEntity);

        MatcherAssert.assertThat(eventEntity,
            Matchers.allOf(
                Matchers.notNullValue(),
                Matchers.hasProperty("histories", Matchers.contains(historyEntity))
            ));

        Assertions.assertNotNull(eventEntity.getInitiationTimestampUTC());
    }

    @Test
    void shouldCreateMessageContentsToSend() {
        final List<ParticipantMipIndirectHistoryEntity> historyList = new ArrayList<>();
        final ParticipantMipIndirectHistoryEntity historyEntity = createHistoryEntity();
        historyList.add(historyEntity);

        rescissionEventEntity.setInitiatorIspb(ParticipantMipIndirectDataSetUtil.ISPB);
        rescissionEventEntity.setHistories(historyList);

        final String fakeMessageId = StringUtils.SPACE;

        when(reda031Factory.createXml(any(Reda031DTO.class))).thenReturn(fakeMessageId);

        final String result = assertDoesNotThrow(() -> rescissionEvent.createMessageContentsToSend(fakeMessageId));

        assertEquals(fakeMessageId, result);

        final ArgumentCaptor<Reda031DTO> reda031Captor = ArgumentCaptor.forClass(Reda031DTO.class);

        verify(reda031Factory).createXml(reda031Captor.capture());

        final Reda031DTO reda031DTO = reda031Captor.getValue();

        assertEquals(fakeMessageId, reda031DTO.getMessageIdentification());

        final Integer ispb = assertDoesNotThrow(() -> Integer.parseInt(reda031DTO.getIndirectParticipantIspb()),
            "The ISPB from DTO is not a valid Integer");

        assertEquals(ParticipantMipIndirectDataSetUtil.ISPB, ispb);
    }

    @Test
    void shouldGetMessageIdFromAEvent() {
        final String fakeMessageId = StringUtils.SPACE;

        when(messageIdService.generateMsgId()).thenReturn(fakeMessageId);

        final String result = assertDoesNotThrow(() -> rescissionEvent.getMessageId());

        assertEquals(fakeMessageId, result);
    }

    @Test
    void shouldSendMessageMethodDefineTheCorrelationIdAndHistoryEvent() {
        final EventTypeEntity eventTypeEntity = new EventTypeEntity();
        final List<ParticipantMipIndirectHistoryEntity> historyList = new ArrayList<>();
        final ParticipantMipIndirectHistoryEntity historyEntity = createHistoryEntity();
        historyList.add(historyEntity);

        eventTypeEntity.setMessageTypeToSend(new MessageTypeEntity());
        rescissionEventEntity.setEventTypeEntity(eventTypeEntity);
        rescissionEventEntity.setInitiatorIspb(ParticipantMipIndirectDataSetUtil.ISPB);
        rescissionEventEntity.setHistories(historyList);

        createHistoryEntity();

        final String fakeMessageId = configureMocksForSendMessageMethod(rescissionEvent);

        assertDoesNotThrow(rescissionEvent::sendMessage);

        verify(rescissionEvent.getEventEntity()).setCorrelationId(fakeMessageId);

        assertHistoryEntityAfterSendMessage();
    }

    private void assertHistoryEntityAfterSendMessage() {
        final Optional<ParticipantMipIndirectHistoryEntity> optionalHistory =
            rescissionEvent.filterLastHistoryFromEntity();

        assertTrue(optionalHistory.isPresent());

        final ParticipantMipIndirectHistoryEntity participantMipIndirectHistoryEntity = optionalHistory.get();

        assertEquals(participantMipIndirectHistoryEntity.getEvent(), rescissionEventEntity);

        final ParticipantMipIndirectEntity indirectParticipantMip =
            participantMipIndirectHistoryEntity.getParticipantMip();

        assertNotNull(indirectParticipantMip);

        final ParticipantMipEntity participantMip = indirectParticipantMip.getParticipantMip();

        assertNotNull(participantMip);
        assertEquals(ParticipantMipIndirectDataSetUtil.ISPB, participantMip.getIspb());
    }

    private String configureMocksForSendMessageMethod(IndirectParticipantRescissionEvent event) {
        configEntity.setIspb(ParticipantMipIndirectDataSetUtil.ISPB);

        final String fakeMessageId = StringUtils.SPACE;
        final MessageSentResponseDTO messageSentResponseDTO = new MessageSentResponseDTO();

        messageSentResponseDTO.setPiResourceID(StringUtils.SPACE);

        when(messageIdService.generateMsgId()).thenReturn(fakeMessageId);
        when(mainEngineConfiguration.getClearingIspb()).thenReturn(ParticipantMipIndirectDataSetUtil.ISPB.toString());
        when(configurationService.findConfig()).thenReturn(configEntity);
        when(messageCatalogSpecificationService.findMessageCatalogSpecificationByCode(any()))
            .thenReturn(new MessageCatalogSpecificationEntity());
        when(messagingResilienceHelper.call(any())).thenReturn(messageSentResponseDTO);

        final ParticipantMipIndirectEntity participantMipIndirectEntity = createIndirectParticipantWithIspb();

        when(indirectParticipantMipService.findByIspb(any())).thenReturn(Optional.of(participantMipIndirectEntity));

        return fakeMessageId;
    }

    private ParticipantMipIndirectEntity createIndirectParticipantWithIspb() {
        final ParticipantMipIndirectEntity participantMipIndirectEntity = new ParticipantMipIndirectEntity();
        final ParticipantMipEntity participantMip = new ParticipantMipEntity();

        participantMip.setIspb(ParticipantMipIndirectDataSetUtil.ISPB);
        participantMipIndirectEntity.setParticipantMip(participantMip);

        return participantMipIndirectEntity;
    }

    @Test
    void shouldRevertAndFireStatusTransitionToError() {
        final EventStatusEntity eventStatusEntity = new EventStatusEntity();
        final ParticipantMipIndirectHistoryEntity participantMipIndirectHistoryEntity = createHistoryEntity();

        eventStatusEntity.setCode(EventStatus.ERROR.getCode());

        when(eventStatusService.findById(any())).thenReturn(eventStatusEntity);
        when(indirectParticipantMipService.findByIspb(any()))
            .thenReturn(Optional.of(participantMipIndirectHistoryEntity.getParticipantMip()));
        when(indirectParticipantStatusService.findById(any())).thenReturn(Optional.of(createNewParticipantStatus()));

        final ParticipantMipIndirectHistoryEntity historyEntity = createHistoryEntity();
        final List<ParticipantMipIndirectHistoryEntity> historyList = new ArrayList<>();

        historyList.add(historyEntity);
        rescissionEvent.getEventEntity().setHistories(historyList);

        when(indirectParticipantHistoryService.createHistoryEntityByType(any(), any())).thenReturn(historyEntity);

        assertDoesNotThrow(rescissionEvent::revert);

        verify(rescissionEvent).fireStatusTransition(Mockito.eq(EventStatus.ERROR));
    }

    private ParticipantMipIndirectStatusEntity createNewParticipantStatus() {
        return ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectStatusEntity(true);
    }

    @Test
    void shouldVerifyReasonCode() {
        final MessageEntity messageEntity = getMessageEntity();
        final NodeList nodeList =
            DocumentUtils.getElementsByExpression(REDA_016_ERRO_MSG_DOCUMENT, SPECIFIC_ELEMENT_FROM_REDA016_ERROR_MSG);
        final Node currentNode = nodeList.item(0);

        final EventSpecificationFromReceivedMessageDTO specificationFromMessageDTO =
            EventSpecificationFromReceivedMessageDTO.builder().messageEntity(messageEntity).specificElement(currentNode)
                .document(REDA_016_ERRO_MSG_DOCUMENT).build();
        final ParticipantMipIndirectHistoryEntity historyEntity = createHistoryEntity();

        rescissionEvent.getEventEntity().setHistories(Arrays.asList(historyEntity));

        assertNull(historyEntity.getRejectReasonCode());
        assertDoesNotThrow(() -> rescissionEvent.verifyReasonCode(specificationFromMessageDTO));
        assertEquals("IND2", historyEntity.getRejectReasonCode());
    }

    private ParticipantMipIndirectHistoryEntity createHistoryEntity() {
        final ParticipantMipIndirectHistoryEntity history = new ParticipantMipIndirectHistoryEntity();

        history.setParticipantMip(createIndirectParticipantWithIspb());
        history.setEventDateTime(LocalDateTime.now());

        return history;
    }

    @Test
    void shouldFireActionsForReplyMessageAndUseDateFromReda016() {
        final List<ParticipantMipIndirectHistoryEntity> historyList = new ArrayList<>();
        final ParticipantMipIndirectHistoryEntity historyEntity = createHistoryEntity();
        historyList.add(historyEntity);

        rescissionEventEntity.setHistories(historyList);

        final MessageEntity messageEntity = getMessageEntity();
        final NodeList nodeList =
            DocumentUtils.getElementsByExpression(REDA_016_ERRO_MSG_DOCUMENT, SPECIFIC_ELEMENT_FROM_REDA016_ERROR_MSG);
        final Node currentNode = nodeList.item(0);

        //@formatter:off
        final EventSpecificationFromReceivedMessageDTO specificationFromMessageDTO =
            EventSpecificationFromReceivedMessageDTO
                .builder()
                .messageEntity(messageEntity)
                .specificElement(currentNode)
                .document(REDA_016_ERRO_MSG_DOCUMENT)
                .build();
        //@formatter:on

        final String clearingTimestampString = MessageBinderXpathReda016Utils.getCreDtTm(currentNode);
        final LocalDateTime localDateTime = LocalDateTime.parse(clearingTimestampString, DateTimeFormatter.ISO_DATE_TIME);

        when(indirectParticipantHistoryService.createHistoryEntityByType(any(), any())).thenReturn(historyEntity);
        when(indirectParticipantStatusService.findById(any())).thenReturn(Optional.of(new ParticipantMipIndirectStatusEntity()));
        when(indirectParticipantUpdateService.saveIndirectParticipantMip(any(), any())).thenReturn(new ParticipantMipIndirectEntity());

        assertNull(messageEntity.getClearingTimestampUtc());
        assertNull(rescissionEventEntity.getClearingTimestampUTC());
        assertDoesNotThrow(() -> rescissionEvent.actionsForReplyMessage(specificationFromMessageDTO));
        assertEquals(localDateTime, messageEntity.getClearingTimestampUtc());
        assertEquals(localDateTime, rescissionEventEntity.getClearingTimestampUTC());
    }

    @Test
    void shouldFireActionsForReplyMessageAndUseANewDate() {
        final List<ParticipantMipIndirectHistoryEntity> historyList = new ArrayList<>();
        final ParticipantMipIndirectHistoryEntity historyEntity = createHistoryEntity();
        historyList.add(historyEntity);

        rescissionEventEntity.setHistories(historyList);

        final MessageEntity messageEntity = getMessageEntity();
        final NodeList nodeList =
            DocumentUtils.getElementsByExpression(REDA_016_ERRO_MSG_WITHOUT_DATE_DOCUMENT, SPECIFIC_ELEMENT_FROM_REDA016_ERROR_MSG);
        final Node currentNode = nodeList.item(0);

        //@formatter:off
        final EventSpecificationFromReceivedMessageDTO specificationFromMessageDTO =
            EventSpecificationFromReceivedMessageDTO
                .builder()
                .messageEntity(messageEntity)
                .specificElement(currentNode)
                .document(REDA_016_ERRO_MSG_WITHOUT_DATE_DOCUMENT)
                .build();
        //@formatter:on

        when(indirectParticipantHistoryService.createHistoryEntityByType(any(), any())).thenReturn(historyEntity);
        when(indirectParticipantStatusService.findById(any())).thenReturn(Optional.of(new ParticipantMipIndirectStatusEntity()));
        when(indirectParticipantUpdateService.saveIndirectParticipantMip(any(), any())).thenReturn(new ParticipantMipIndirectEntity());

        assertEquals(StringUtils.EMPTY, MessageBinderXpathReda016Utils.getCreDtTm(currentNode));
        assertNull(messageEntity.getClearingTimestampUtc());
        assertNull(rescissionEventEntity.getClearingTimestampUTC());
        assertDoesNotThrow(() -> rescissionEvent.actionsForReplyMessage(specificationFromMessageDTO));
        assertNotNull(messageEntity.getClearingTimestampUtc());
        assertNotNull(rescissionEventEntity.getClearingTimestampUTC());
    }

    private MessageEntity getMessageEntity() {
        final MessageTypeEntity messageTypeEntity = new MessageTypeEntity();
        final MessageEntity messageEntity = createMessage(messageTypeEntity);

        messageEntity.setMessageTypeEntity(messageTypeEntity);

        return messageEntity;
    }

    private MessageEntity createMessage(MessageTypeEntity messageTypeEntity) {
        final MessageEntity messageEntity = new MessageEntity();

        messageEntity.setMessageTypeEntity(messageTypeEntity);
        messageEntity.setPiResourceId(StringUtils.SPACE);

        return messageEntity;
    }

}
