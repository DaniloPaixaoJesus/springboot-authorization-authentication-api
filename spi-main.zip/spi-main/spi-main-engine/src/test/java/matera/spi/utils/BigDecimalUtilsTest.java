package matera.spi.utils;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class BigDecimalUtilsTest {

    @Test
    void shouldVerifyIfIsLessThan() {
        // small - big
        assertTrue(BigDecimalUtils.compareIf(BigDecimal.ZERO).isLessThan(BigDecimal.ONE));
        assertTrue(BigDecimalUtils.compareIf(BigDecimal.ZERO).isLessThan(BigDecimal.TEN));
        assertTrue(BigDecimalUtils.compareIf(BigDecimal.ONE).isLessThan(BigDecimal.TEN));
        // equal
        assertFalse(BigDecimalUtils.compareIf(BigDecimal.TEN).isLessThan(BigDecimal.TEN));
        assertFalse(BigDecimalUtils.compareIf(BigDecimal.ONE).isLessThan(BigDecimal.ONE));
        assertFalse(BigDecimalUtils.compareIf(BigDecimal.ZERO).isLessThan(BigDecimal.ZERO));
        //big - small
        assertFalse(BigDecimalUtils.compareIf(BigDecimal.ONE).isLessThan(BigDecimal.ZERO));
        assertFalse(BigDecimalUtils.compareIf(BigDecimal.TEN).isLessThan(BigDecimal.ZERO));
        assertFalse(BigDecimalUtils.compareIf(BigDecimal.TEN).isLessThan(BigDecimal.ONE));
    }

    @Test
    void shouldVerifyIfIsLessOrEqualTo() {
        // small - big
        assertTrue(BigDecimalUtils.compareIf(BigDecimal.ZERO).isLessOrEqualTo(BigDecimal.ONE));
        assertTrue(BigDecimalUtils.compareIf(BigDecimal.ZERO).isLessOrEqualTo(BigDecimal.TEN));
        assertTrue(BigDecimalUtils.compareIf(BigDecimal.ONE).isLessOrEqualTo(BigDecimal.TEN));
        // equal
        assertTrue(BigDecimalUtils.compareIf(BigDecimal.TEN).isLessOrEqualTo(BigDecimal.TEN));
        assertTrue(BigDecimalUtils.compareIf(BigDecimal.ONE).isLessOrEqualTo(BigDecimal.ONE));
        assertTrue(BigDecimalUtils.compareIf(BigDecimal.ZERO).isLessOrEqualTo(BigDecimal.ZERO));
        //big - small
        assertFalse(BigDecimalUtils.compareIf(BigDecimal.ONE).isLessOrEqualTo(BigDecimal.ZERO));
        assertFalse(BigDecimalUtils.compareIf(BigDecimal.TEN).isLessOrEqualTo(BigDecimal.ZERO));
        assertFalse(BigDecimalUtils.compareIf(BigDecimal.TEN).isLessOrEqualTo(BigDecimal.ONE));
    }

    @Test
    void shouldVerifyIfIsGreaterThan() {
        // small - big
        assertFalse(BigDecimalUtils.compareIf(BigDecimal.ZERO).isGreaterThan(BigDecimal.ONE));
        assertFalse(BigDecimalUtils.compareIf(BigDecimal.ZERO).isGreaterThan(BigDecimal.TEN));
        assertFalse(BigDecimalUtils.compareIf(BigDecimal.ONE).isGreaterThan(BigDecimal.TEN));
        // equal
        assertFalse(BigDecimalUtils.compareIf(BigDecimal.TEN).isGreaterThan(BigDecimal.TEN));
        assertFalse(BigDecimalUtils.compareIf(BigDecimal.ONE).isGreaterThan(BigDecimal.ONE));
        assertFalse(BigDecimalUtils.compareIf(BigDecimal.ZERO).isGreaterThan(BigDecimal.ZERO));
        //big - small
        assertTrue(BigDecimalUtils.compareIf(BigDecimal.ONE).isGreaterThan(BigDecimal.ZERO));
        assertTrue(BigDecimalUtils.compareIf(BigDecimal.TEN).isGreaterThan(BigDecimal.ZERO));
        assertTrue(BigDecimalUtils.compareIf(BigDecimal.TEN).isGreaterThan(BigDecimal.ONE));
    }

    @Test
    void shouldVerifyIfIsGreaterOrEqualToThan() {
        // small - big
        assertFalse(BigDecimalUtils.compareIf(BigDecimal.ZERO).isGreaterOrEqualTo(BigDecimal.ONE));
        assertFalse(BigDecimalUtils.compareIf(BigDecimal.ZERO).isGreaterOrEqualTo(BigDecimal.TEN));
        assertFalse(BigDecimalUtils.compareIf(BigDecimal.ONE).isGreaterOrEqualTo(BigDecimal.TEN));
        // equal
        assertTrue(BigDecimalUtils.compareIf(BigDecimal.TEN).isGreaterOrEqualTo(BigDecimal.TEN));
        assertTrue(BigDecimalUtils.compareIf(BigDecimal.ONE).isGreaterOrEqualTo(BigDecimal.ONE));
        assertTrue(BigDecimalUtils.compareIf(BigDecimal.ZERO).isGreaterOrEqualTo(BigDecimal.ZERO));
        //big - small
        assertTrue(BigDecimalUtils.compareIf(BigDecimal.ONE).isGreaterOrEqualTo(BigDecimal.ZERO));
        assertTrue(BigDecimalUtils.compareIf(BigDecimal.TEN).isGreaterOrEqualTo(BigDecimal.ZERO));
        assertTrue(BigDecimalUtils.compareIf(BigDecimal.TEN).isGreaterOrEqualTo(BigDecimal.ONE));
    }

    @Test
    void shouldVerifyIfIsEqualTo() {
        // small - big
        assertFalse(BigDecimalUtils.compareIf(BigDecimal.ZERO).isEqualTo(BigDecimal.ONE));
        assertFalse(BigDecimalUtils.compareIf(BigDecimal.ZERO).isEqualTo(BigDecimal.TEN));
        assertFalse(BigDecimalUtils.compareIf(BigDecimal.ONE).isEqualTo(BigDecimal.TEN));
        // equal
        assertTrue(BigDecimalUtils.compareIf(BigDecimal.TEN).isEqualTo(BigDecimal.TEN));
        assertTrue(BigDecimalUtils.compareIf(BigDecimal.ONE).isEqualTo(BigDecimal.ONE));
        assertTrue(BigDecimalUtils.compareIf(BigDecimal.ZERO).isEqualTo(BigDecimal.ZERO));
        //big - small
        assertFalse(BigDecimalUtils.compareIf(BigDecimal.ONE).isEqualTo(BigDecimal.ZERO));
        assertFalse(BigDecimalUtils.compareIf(BigDecimal.TEN).isEqualTo(BigDecimal.ZERO));
        assertFalse(BigDecimalUtils.compareIf(BigDecimal.TEN).isEqualTo(BigDecimal.ONE));
    }

}
