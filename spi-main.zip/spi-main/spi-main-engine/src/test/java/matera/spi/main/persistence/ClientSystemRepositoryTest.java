package matera.spi.main.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.ClientSystemEntity;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Commit;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@IntegrationTest
@Transactional
@Commit
class ClientSystemRepositoryTest {

    private static final String CLIENT_ID = "123456789";
    private static final String NAME_SYSTEM = "123456789";
    private static final String SECRET = "123456789";
    private static final String URL_CALLBACK = "123456789";
    private static final String URL_O_AUTH = "123456789";
    private static final String URL_OAUTH_SCOPES = "test_scopes.com/.default";

    @Autowired
    private ClientSystemRepository repository;

    private List<ClientSystemEntity> backupEntities;

    @BeforeEach
    void init(){
        backupEntities = repository.findAll();
        createCallbackEntity("123", true);
        createCallbackEntity("456", true);
        createCallbackEntity("789", true);
        createCallbackEntity("321", false);
    }

    @AfterEach
    void afterEach(){
        List<ClientSystemEntity> currentEntities = repository.findAll();

        currentEntities.stream().filter(e -> !backupEntities.contains(e)).forEach(repository::delete);
    }

    @Test
    void shouldCreateACallbackWithScopes() {
        //given
        ClientSystemEntity newClientSystemEntity = createCallbackEntity("987", true);
        newClientSystemEntity.setScopesOauth(URL_OAUTH_SCOPES);
        repository.saveAndFlush(newClientSystemEntity);
        //when
        Optional<ClientSystemEntity> foundCallbackEntity = repository.findById(newClientSystemEntity.getId());
        //then
        Assertions.assertEquals(URL_OAUTH_SCOPES, foundCallbackEntity.get().getScopesOauth());
        //teardown
        repository.delete(newClientSystemEntity);
    }

    @Test
    void shouldCreateAndFindCallbackEntity() {
        ClientSystemEntity newClientSystemEntity = createCallbackEntity("987", true);
        Optional<ClientSystemEntity> findedCallbackEntity = repository.findById(newClientSystemEntity.getId());
        Assertions.assertEquals(findedCallbackEntity.get(), newClientSystemEntity);

        ClientSystemEntity findedClientSystemEntity2 = repository.findByCodeSystem(newClientSystemEntity.getCodeSystem());
        Assertions.assertEquals(findedClientSystemEntity2, newClientSystemEntity);
    }

    @Test
    void shouldCreateAndFindActiveCallbackEntity() {
        List<ClientSystemEntity> listClientSystemEntity = repository.findByActiveTrue();
        for (ClientSystemEntity entity : listClientSystemEntity) {
            Assertions.assertEquals(true, entity.isActive());
        }
    }

    private ClientSystemEntity createCallbackEntity(String codeSystem, boolean active) {
        ClientSystemEntity clientSystemEntity = new ClientSystemEntity();
        clientSystemEntity.setClientId(CLIENT_ID);
        clientSystemEntity.setCodeSystem(codeSystem);
        clientSystemEntity.setNameSystem(NAME_SYSTEM);
        clientSystemEntity.setSecret(SECRET);
        clientSystemEntity.setUrlCallback(URL_CALLBACK);
        clientSystemEntity.setUrlOAuth(URL_O_AUTH);
        clientSystemEntity.setActive(active);
        repository.saveAndFlush(clientSystemEntity);
        return clientSystemEntity;
    }

}
