package matera.spi.lm.rest;

import com.matera.spi.thirdparties.customers.transactions.api.SPICustomersTransactionContractApis;
import com.matera.spi.thirdparties.customers.transactions.model.LancamentoDataResponseV2DTO;
import com.matera.spi.thirdparties.customers.transactions.model.LancamentoResponseV2DTO;
import com.matera.spi.thirdparties.customers.transactions.model.LancamentoV2DTO;
import com.matera.spi.thirdparties.customers.transactions.model.SaldoDTO;
import com.matera.spi.thirdparties.customers.transactions.model.SaldoResponseDTO;
import com.matera.spi.thirdparties.spb.api.EventosApi;
import com.matera.spi.thirdparties.spb.api.SPISPBContractApis;
import com.matera.spi.thirdparties.spb.model.EventoItemResponseDTO;
import com.matera.spi.thirdparties.spb.model.EventoResponseDTO;
import com.matera.spi.thirdparties.spb.model.LoteEventoResponseDataDTO;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.DepositOperationRequestDTO;
import matera.spi.dto.DepositResponseUIDTO;
import matera.spi.dto.DominioSistemaDTO;
import matera.spi.dto.SpbCallbackDTO;
import matera.spi.dto.WithdrawOperationRequestDTO;
import matera.spi.dto.WithdrawResponseUIDTO;
import matera.spi.lm.domain.model.enums.EnumTransferResourceType;
import matera.spi.lm.domain.model.spb.SpbEventEntity;
import matera.spi.lm.domain.model.spb.deposit.IpAccountDepositEventEntity;
import matera.spi.lm.domain.model.spb.withdraw.IpAccountWithdrawEventEntity;
import matera.spi.lm.domain.service.event.spb.SpbEvent;
import matera.spi.lm.domain.service.event.spb.SpbEventFactory;
import matera.spi.lm.persistence.SpbEventRepository;
import matera.spi.lm.transactions.port.SpbOutgoingPort;
import matera.spi.lm.transactions.port.SpbRepliesIncomingPort;
import matera.spi.main.domain.model.event.EventStatus;
import matera.spi.main.domain.service.transaction.AccountTransaction;
import matera.spi.main.domain.service.transaction.AccountTransactionReverter;
import matera.spi.main.persistence.TransactionResultRepository;
import matera.spi.main.transactions.adapter.account.AccountTransactionExecutorAdapter;
import matera.spi.main.transactions.port.AccountTransactionExecutorPort;
import matera.spi.utils.LocalDateTimeUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.hamcrest.MatcherAssert;
import org.hamcrest.core.Is;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import static com.matera.spi.thirdparties.customers.transactions.model.LancamentoResponseV2DTO.ClassificacaoCategoriaContaSPIEnum.CACC;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathMatching;
import static com.github.tomakehurst.wiremock.stubbing.Scenario.STARTED;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.springframework.http.HttpStatus.OK;

import static java.math.BigDecimal.TEN;

@IntegrationTest
public class BalanceIpAccountControllerDepositWithdrawTest {

    private static final String STANDIN_API_OAUTH_TOKEN_URL = "/api/oauth/token";
    private static final String STANDIN_API_LANCAMENTOS = "/api/v2/contas/.*/.*/lancamentos";
    protected static final String IPACCOUNT_DEPOSIT_URI = "/ui/v1/ip-account/deposit";
    protected static final String IPACCOUNT_WITHDRAW_URI = "/ui/v1/ip-account/withdraw";
    protected static final String SPB_CALLBACK_URI = "/api/v1/eventos-retorno";
    private static final String STANDIN_API_SALDOS = "/api/v2/contas/.*/.*/saldos";

    private static WireMockServer wireMockServer = new WireMockServer(8088);
    private final static LancamentoDataResponseV2DTO mockedLancamentoResponse = getDefaultLancamentoResponseV2DTO();
    private static SaldoResponseDTO mockedSaldoResponse = getDefaultSaldoResponseDTO();
    private final static SaldoResponseDTO mockedUpdatedSaldoResponse = updateBalance();

    @LocalServerPort
    protected int port;

    @Autowired
    private AccountTransaction accountTransaction;

    @Autowired
    private SPICustomersTransactionContractApis customersTransactionContractApis;

    private AccountTransactionExecutorPort accountTransactionExecutorPortBackupBean;

    @Autowired
    private SpbEventRepository spbEventRepository;

    @Autowired
    private TransactionResultRepository transactionResultRepository;

    @Autowired
    private SpbOutgoingPort spbOutgoingPort;

    @Autowired
    private SPISPBContractApis spispbContractApisBean;

    @Mock
    private SPISPBContractApis mockedSpispbContractApis;

    @Mock
    private EventosApi eventosApi;

    @Autowired
    private SpbEventFactory spbEventFactory;

    @Autowired
    private SpbRepliesIncomingPort spbRepliesIncomingPort;

    private SpbEventFactory spbEventFactorySpy;

    @BeforeAll
    public static void beforeAll() {
        wireMockServer.stubFor(post(urlEqualTo(STANDIN_API_OAUTH_TOKEN_URL))
            .willReturn(aResponse()
                .withStatus(OK.value())
                .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE)
                .withBody(TokenResponseMock.JSON)));

        wireMockServer.stubFor(post(urlPathMatching(STANDIN_API_LANCAMENTOS))
            .willReturn(aResponse()
                .withStatus(OK.value())
                .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE)
                .withBody(TokenResponseMock.getJson(mockedLancamentoResponse))));

        createWireMockStub(STANDIN_API_SALDOS, STARTED, "AfterOperationState", TokenResponseMock.getJson(mockedSaldoResponse));
        createWireMockStub(STANDIN_API_SALDOS, "AfterOperationState", STARTED, TokenResponseMock.getJson(mockedUpdatedSaldoResponse));
        wireMockServer.start();
    }

    @AfterAll
    static void afterAll() {
        wireMockServer.stop();
    }

    @BeforeEach
    void beforeEach() {
        spbOutgoingPort.setSPISPBContractApis(mockedSpispbContractApis);
        final LoteEventoResponseDataDTO mockedLoteEventoResponseDataDTO = Mockito.spy(buildSpbResponseDataDTO());
        Mockito.when(eventosApi.v2EventosPost(any())).thenReturn(mockedLoteEventoResponseDataDTO);
        Mockito.doReturn(eventosApi).when(mockedSpispbContractApis).eventosApi();
        mockAccountTransactionExecutorPort();
        wireMockServer.resetRequests();
    }

    @AfterEach
    void afterEach() {
        spbOutgoingPort.setSPISPBContractApis(spispbContractApisBean);
    }

    @Test
    void shouldCreateDepositEventWithTransferResourceTypeRBCL() throws InterruptedException {
        final DepositResponseUIDTO responseDeposit =
            RestAssured.given()
                .log().all()
                .contentType(ContentType.JSON)
                .body(buildDepositOperationRequestDtoRBCL())
                .when()
                .post(IPACCOUNT_DEPOSIT_URI)
                .then().extract()
                .as(DepositResponseUIDTO.class);

        Assertions.assertNotNull(responseDeposit);
        final UUID eventUuid = responseDeposit.getData().getEventUuid();
        Assertions.assertNotNull(eventUuid);

        Optional<SpbEventEntity> optionalEventEntity = spbEventRepository.findDetailsById(eventUuid);

        MatcherAssert.assertThat(optionalEventEntity.isPresent(), Is.is(true));
        IpAccountDepositEventEntity depositEvent = (IpAccountDepositEventEntity) optionalEventEntity.get();

        assertSpbEventEntity(depositEvent, eventUuid, "LPI0001", EnumTransferResourceType.RBCL);
        assertThat(depositEvent.getIpAccountDepositDetails()).isNotNull();
        assertThat(depositEvent.getIpAccountDepositDetails().getUuid()).isNotNull();

        assertThat(transactionResultRepository.findAll()).isEmpty();

        doCallbackResponseFromSpb(depositEvent, "LPI0001", SpbEvent.SUCCESS_SITUACAO_NM);
        assertThat(transactionResultRepository.findAll()).hasSize(1);
        verifyStandInCall();

        Mockito.verify(eventosApi, Mockito.times(1)).v2EventosPost(any());
        ReflectionTestUtils.setField(accountTransaction, "accountTransactionExecutorPort", accountTransactionExecutorPortBackupBean);
    }

    @Test
    void shouldCreateDepositEventWithTransferResourceTypeCCME() throws InterruptedException {
        final DepositResponseUIDTO responseDeposit =
            RestAssured.given()
                .log().all()
                .contentType(ContentType.JSON)
                .body(buildDepositOperationRequestDtoCCME())
                .when()
                .post(IPACCOUNT_DEPOSIT_URI)
                .then().extract()
                .as(DepositResponseUIDTO.class);

        Assertions.assertNotNull(responseDeposit);
        final UUID eventUuid = responseDeposit.getData().getEventUuid();
        Assertions.assertNotNull(eventUuid);

        Optional<SpbEventEntity> optionalEventEntity = spbEventRepository.findDetailsById(eventUuid);

        MatcherAssert.assertThat(optionalEventEntity.isPresent(), Is.is(true));
        IpAccountDepositEventEntity depositEvent = (IpAccountDepositEventEntity) optionalEventEntity.get();

        assertSpbEventEntity(depositEvent, eventUuid, "LPI0002", EnumTransferResourceType.CCME);
        assertThat(depositEvent.getIpAccountDepositDetails()).isNotNull();
        assertThat(depositEvent.getIpAccountDepositDetails().getUuid()).isNotNull();

        doCallbackResponseFromSpb(depositEvent, "LPI0002", SpbEvent.SUCCESS_SITUACAO_NM);
        assertThat(transactionResultRepository.findAll()).hasSize(1);
        verifyStandInCall();

        Mockito.verify(eventosApi, Mockito.times(1)).v2EventosPost(any());
        ReflectionTestUtils.setField(accountTransaction, "accountTransactionExecutorPort", accountTransactionExecutorPortBackupBean);
    }

    @Test
    void shouldCreateWithdrawEventWithTransferResourceTypeRBCL() {
        WithdrawResponseUIDTO responseWithdraw = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(buildWithdrawOperationRequestDtoRBCL())
            .when()
            .post(IPACCOUNT_WITHDRAW_URI)
            .then()
            .log()
            .all()
            .and()
            .extract()
            .as(WithdrawResponseUIDTO.class);

        Assertions.assertNotNull(responseWithdraw);
        final UUID eventUuid = responseWithdraw.getData().getEventUuid();
        Assertions.assertNotNull(eventUuid);

        Optional<SpbEventEntity> optionalEventEntity = spbEventRepository.findDetailsById(eventUuid);

        MatcherAssert.assertThat(optionalEventEntity.isPresent(), Is.is(true));
        IpAccountWithdrawEventEntity withdrawEvent = (IpAccountWithdrawEventEntity) optionalEventEntity.get();

        verifyStandInCall();

        assertThat(withdrawEvent.getTransactionResult()).isNotNull();

        assertSpbEventEntity(withdrawEvent, eventUuid, "LPI0003", EnumTransferResourceType.RBCL);
        assertThat(withdrawEvent.getIpAccountWithdrawDetails()).isNotNull();
        assertThat(withdrawEvent.getIpAccountWithdrawDetails().getUuid()).isNotNull();

        Mockito.verify(eventosApi, Mockito.times(1)).v2EventosPost(any());
        ReflectionTestUtils.setField(accountTransaction, "accountTransactionExecutorPort", accountTransactionExecutorPortBackupBean);
    }

    @Test
    void shouldCreateWithdrawEventWithTransferResourceTypeCCME() {
        WithdrawResponseUIDTO responseWithdraw = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(buildWithdrawOperationRequestDtoCCME())
            .when()
            .post(IPACCOUNT_WITHDRAW_URI)
            .then()
            .log()
            .all()
            .and()
            .extract()
            .as(WithdrawResponseUIDTO.class);

        Assertions.assertNotNull(responseWithdraw);
        final UUID eventUuid = responseWithdraw.getData().getEventUuid();
        Assertions.assertNotNull(eventUuid);

        Optional<SpbEventEntity> optionalEventEntity = spbEventRepository.findDetailsById(eventUuid);

        MatcherAssert.assertThat(optionalEventEntity.isPresent(), Is.is(true));
        IpAccountWithdrawEventEntity withdrawEvent = (IpAccountWithdrawEventEntity) optionalEventEntity.get();

        verifyStandInCall();

        assertThat(withdrawEvent.getTransactionResult()).isNotNull();

        assertSpbEventEntity(withdrawEvent, eventUuid, "LPI0004", EnumTransferResourceType.CCME);
        assertThat(withdrawEvent.getIpAccountWithdrawDetails()).isNotNull();
        assertThat(withdrawEvent.getIpAccountWithdrawDetails().getUuid()).isNotNull();

        doCallbackResponseFromSpb(withdrawEvent, "LPI0004", SpbEvent.SUCCESS_SITUACAO_NM);
        Mockito.verify(eventosApi, Mockito.times(1)).v2EventosPost(any());
        ReflectionTestUtils.setField(accountTransaction, "accountTransactionExecutorPort", accountTransactionExecutorPortBackupBean);
    }

    @Test
    void shouldSetEventStatusToDataRetunedWithErrorWhenWithdrawSpbCallBackDTOSituacaoNMIsNotSuccess() {
        WithdrawResponseUIDTO responseWithdraw = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(buildWithdrawOperationRequestDtoCCME())
            .when()
            .post(IPACCOUNT_WITHDRAW_URI)
            .then()
            .log()
            .all()
            .and()
            .extract()
            .as(WithdrawResponseUIDTO.class);

        final UUID eventUuid = responseWithdraw.getData().getEventUuid();
        Optional<SpbEventEntity> optionalEventEntity = spbEventRepository.findDetailsById(eventUuid);
        IpAccountWithdrawEventEntity withdrawEventEntity = (IpAccountWithdrawEventEntity) optionalEventEntity.get();

        final AccountTransactionReverter accountTransactionReverterMock = Mockito.mock(AccountTransactionReverter.class);
        Mockito.doAnswer((answer)->{
            final SpbEvent spbEvent = (SpbEvent) answer.callRealMethod();
            spbEvent.setAccountTransactionReverter(accountTransactionReverterMock);
            Mockito.doNothing().when(accountTransactionReverterMock).revert(Mockito.any());
            ReflectionTestUtils.setField(spbEvent, "accountTransactionReverter", accountTransactionReverterMock);
            return spbEvent;
        }).when(spbEventFactorySpy).findByEventEntity(Mockito.any());
        Assertions.assertEquals(withdrawEventEntity.getStatus().getCode(), EventStatus.INITIALIZED.getCode());
        doCallbackResponseFromSpb(withdrawEventEntity, "LPI0004", 6);
        verifyStandInCall();

        Optional<SpbEventEntity> optionalActualEventEntity = spbEventRepository.findDetailsById(eventUuid);
        IpAccountWithdrawEventEntity actualWithdrawEvent = (IpAccountWithdrawEventEntity) optionalActualEventEntity.get();
        Assertions.assertEquals(actualWithdrawEvent.getStatus().getCode(), EventStatus.DATA_RETURNED_WITH_ERROR.getCode());

        Mockito.verify(accountTransactionReverterMock, Mockito.times(1)).revert(Mockito.any());

        ReflectionTestUtils.setField(accountTransaction, "accountTransactionExecutorPort", accountTransactionExecutorPortBackupBean);
        ReflectionTestUtils.setField(spbRepliesIncomingPort, "spbEventFactory", spbEventFactory);
    }

    @Test
    void shouldSetEventStatusToDataRetunedWithErrorWhenDepositSpbCallBackDTOSituacaoNMIsNotSuccess() throws InterruptedException {
        final DepositResponseUIDTO responseDeposit =
            RestAssured.given()
                .log().all()
                .contentType(ContentType.JSON)
                .body(buildDepositOperationRequestDtoCCME())
                .when()
                .post(IPACCOUNT_DEPOSIT_URI)
                .then().extract()
                .as(DepositResponseUIDTO.class);

        final UUID eventUuid = responseDeposit.getData().getEventUuid();
        Optional<SpbEventEntity> optionalEventEntity = spbEventRepository.findDetailsById(eventUuid);
        IpAccountDepositEventEntity depositEvent = (IpAccountDepositEventEntity) optionalEventEntity.get();

        Assertions.assertEquals(depositEvent.getStatus().getCode(), EventStatus.INITIALIZED.getCode());
        doCallbackResponseFromSpb(depositEvent, "LPI0002", 6);

        Optional<SpbEventEntity> optionalActualEventEntity = spbEventRepository.findDetailsById(eventUuid);
        IpAccountDepositEventEntity actualDepositEvent = (IpAccountDepositEventEntity) optionalActualEventEntity.get();
        Assertions.assertEquals(actualDepositEvent.getStatus().getCode(), EventStatus.DATA_RETURNED_WITH_ERROR.getCode());

        ReflectionTestUtils.setField(accountTransaction, "accountTransactionExecutorPort", accountTransactionExecutorPortBackupBean);
    }

    private void doCallbackResponseFromSpb(SpbEventEntity spbEventEntity, String spbEventType, Integer situacaoNM) {
        RestAssured.given()
            .log().all()
            .contentType(ContentType.JSON)
            .body(buildSpbCallbackResponse(spbEventEntity, spbEventType, situacaoNM))
            .when()
            .post(SPB_CALLBACK_URI)
            .then().statusCode(OK.value());

    }

    private SpbCallbackDTO buildSpbCallbackResponse(SpbEventEntity spbEventEntity, String spbEventType, Integer situacaoNM) {
        List<String> messages = buildMessages(spbEventType);
        final SpbCallbackDTO spbCallbackDTO = new SpbCallbackDTO();
        spbCallbackDTO.setId(spbEventEntity.getSpbEventId());
        spbCallbackDTO.setTipoEvento(spbEventType);
        spbCallbackDTO.setSistemaOrigem("MIP");
        spbCallbackDTO.setDataHoraResposta("2020-08-10 17:18:30");
        spbCallbackDTO.setNumEmpresa(1);
        spbCallbackDTO.setOperacaoOrigemId1(spbEventEntity.getId().toString());
        spbCallbackDTO.setTipoTransacaoOrigem(spbEventType);
        spbCallbackDTO.setSituacaoNm(situacaoNM);
        spbCallbackDTO.setSituacaoLancamento("100");
        spbCallbackDTO.setDominioSistema(DominioSistemaDTO.SPB01);
        spbCallbackDTO.setMessages(messages);
        return spbCallbackDTO;
    }

    private List<String> buildMessages(String spbEventType) {
        final String responseTag = spbEventType + "R1";
        return List.of("<"+responseTag+"></"+responseTag+">");
    }

    private LoteEventoResponseDataDTO buildSpbResponseDataDTO() {
        LoteEventoResponseDataDTO loteEventoResponseDataDTO = new LoteEventoResponseDataDTO();
        final EventoItemResponseDTO eventoItemResponseDTO = new EventoItemResponseDTO();

        eventoItemResponseDTO.setData(buildEventoResponseDTO());
        loteEventoResponseDataDTO.setItems(List.of(eventoItemResponseDTO));
        return loteEventoResponseDataDTO;
    }

    private EventoResponseDTO buildEventoResponseDTO() {
        final EventoResponseDTO eventoResponseDTO = new EventoResponseDTO();
        eventoResponseDTO.setId(1);
        eventoResponseDTO.setSistemaOrigem("MIP");
        eventoResponseDTO.setTipoEvento("LPI0003");
        eventoResponseDTO.setNumEmpresa(1d);
        eventoResponseDTO.setOperador("Operador de Teste");
        eventoResponseDTO.setDataHoraAgendamento(null);
        eventoResponseDTO.setTipoTransacaoOrigem("LPI0003");
        eventoResponseDTO.setOperacaoOrigemId1(UUID.randomUUID().toString());
        eventoResponseDTO.setOperacaoOrigemId2(null);
        eventoResponseDTO.setIspbRemetente("00000123");
        eventoResponseDTO.setIspbDestinatario("00000456");
        eventoResponseDTO.setDescricao("Teste");
        eventoResponseDTO.setValor(BigDecimal.TEN.floatValue());
        eventoResponseDTO.setDominioSistema(EventoResponseDTO.DominioSistemaEnum.SPB01);
        eventoResponseDTO.setMessage("<LPI0003>Content</LPI0003>");
        eventoResponseDTO.setUrl("/v1/eventos-retorno");
        return eventoResponseDTO;
    }

    private void verifyStandInCall() {
        wireMockServer.verify(1, WireMock.postRequestedFor(urlEqualTo("/api/v2/contas/1234/987654123/lancamentos"))
            .withRequestBody(
                WireMock.equalToJson("{\n" +
                    "  \"subSistema\" : \"MIP\",\n" +
                    "  \"lancamentos\" : [ {\n" +
                    "    \"valor\" : 10.0,\n" +
                    "    \"tipoLimite\" : \"SALDO_MAIS_LIMITE\",\n" +
                    "    \"exibeLancamentoAgrupado\" : false,\n" +
                    "    \"enviaNotificacao\" : true,\n" +
                    "    \"validaSaldo\" : \"VALIDA\",\n" +
                    "    \"atualizaValorLote\" : true\n" +
                    "  } ]\n" +
                    "}", true, true)));
    }

    private void assertSpbEventEntity(SpbEventEntity spbEventEntity, UUID eventUuid, String messageCode, EnumTransferResourceType resourceType) {

        assertThat(spbEventEntity.getId()).isEqualTo(eventUuid);
        assertThat(spbEventEntity.getControlNumber()).isNotNull();
        assertThat(spbEventEntity.getMovementDate()).isNotNull();
        assertThat(spbEventEntity.getSpbEventId()).isNotNull();
        assertThat(spbEventEntity.getSpbMessageEntity()).isNotNull();
        assertThat(spbEventEntity.getSpbMessageEntity()).hasOnlyOneElementSatisfying(spbMessage -> {
            assertThat(spbMessage.getMessageContents()).contains(messageCode);
        });
        assertThat(spbEventEntity.getTransferResourceType()).isEqualTo(resourceType);
    }

    private void mockAccountTransactionExecutorPort() {
        RestAssured.port = port;
        accountTransactionExecutorPortBackupBean = (AccountTransactionExecutorPort) ReflectionTestUtils
            .getField(accountTransaction, "accountTransactionExecutorPort");
        ReflectionTestUtils.setField(accountTransaction, "accountTransactionExecutorPort", new AccountTransactionExecutorAdapter(customersTransactionContractApis));

        spbEventFactorySpy = Mockito.spy(spbEventFactory);
        ReflectionTestUtils.setField(spbRepliesIncomingPort, "spbEventFactory", spbEventFactorySpy);
    }

    private DepositOperationRequestDTO buildDepositOperationRequestDtoRBCL() {
        final DepositOperationRequestDTO depositOperationRequestDTO = new DepositOperationRequestDTO();
        depositOperationRequestDTO.setValue(TEN);
        depositOperationRequestDTO.ignoreThresholdViolation(Boolean.TRUE);
        depositOperationRequestDTO.transferResourceType(DepositOperationRequestDTO.TransferResourceTypeEnum.RBCL);
        return depositOperationRequestDTO;
    }

    private DepositOperationRequestDTO buildDepositOperationRequestDtoCCME() {
        final DepositOperationRequestDTO depositOperationRequestDTO = new DepositOperationRequestDTO();
        depositOperationRequestDTO.setValue(TEN);
        depositOperationRequestDTO.ignoreThresholdViolation(Boolean.TRUE);
        depositOperationRequestDTO.transferResourceType(DepositOperationRequestDTO.TransferResourceTypeEnum.CCME);
        return depositOperationRequestDTO;
    }

    private WithdrawOperationRequestDTO buildWithdrawOperationRequestDtoRBCL() {
        final WithdrawOperationRequestDTO withdrawOperationRequestDTO = new WithdrawOperationRequestDTO();
        withdrawOperationRequestDTO.setValue(TEN);
        withdrawOperationRequestDTO.ignoreThresholdViolation(Boolean.TRUE);
        withdrawOperationRequestDTO.transferResourceType(WithdrawOperationRequestDTO.TransferResourceTypeEnum.RBCL);
        return withdrawOperationRequestDTO;
    }

    private WithdrawOperationRequestDTO buildWithdrawOperationRequestDtoCCME() {
        final WithdrawOperationRequestDTO withdrawOperationRequestDTO = new WithdrawOperationRequestDTO();
        withdrawOperationRequestDTO.setValue(TEN);
        withdrawOperationRequestDTO.ignoreThresholdViolation(Boolean.TRUE);
        withdrawOperationRequestDTO.transferResourceType(WithdrawOperationRequestDTO.TransferResourceTypeEnum.CCME);
        return withdrawOperationRequestDTO;
    }

    private static void createWireMockStub(String url, String currentState, String nextState, String responseBody) {
        wireMockServer.stubFor(get(urlPathMatching(url))
            .inScenario("StandinResponseTest")
            .whenScenarioStateIs(currentState)
            .willSetStateTo(nextState)
            .willReturn(aResponse()
                .withStatus(OK.value())
                .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE)
                .withBody(responseBody)));
    }

    private static LancamentoDataResponseV2DTO getDefaultLancamentoResponseV2DTO() {
        final LancamentoResponseV2DTO lancamentoResponseV2DTO = new LancamentoResponseV2DTO();
        lancamentoResponseV2DTO.setSubSistema("STANDIN");
        lancamentoResponseV2DTO.setNomeUsuario("SDBANCO");
        lancamentoResponseV2DTO.setLoteEntrada(BigDecimal.valueOf(3691275723396573863894549962393805119D));
        lancamentoResponseV2DTO.setClassificacaoCategoriaContaSPI(CACC);
        lancamentoResponseV2DTO.setCpfCnpjTitular(BigDecimal.valueOf(24276273137L));
        lancamentoResponseV2DTO.setLancamentos(buildLancamentoV2DTO());
        lancamentoResponseV2DTO.setSaldo(buildSaldoDTO());

        final LancamentoDataResponseV2DTO lancamentoDataResponseV2DTO = new LancamentoDataResponseV2DTO();
        lancamentoDataResponseV2DTO.setData(lancamentoResponseV2DTO);
        return lancamentoDataResponseV2DTO;
    }

    private static SaldoResponseDTO getDefaultSaldoResponseDTO() {
        final SaldoResponseDTO saldoResponseDTO = new SaldoResponseDTO();
        saldoResponseDTO.setData(LocalDateTimeUtils.getTodayUTC());
        saldoResponseDTO.setSaldoBloqueado(BigDecimal.ZERO);
        saldoResponseDTO.setLimiteCreditoDisponivel(BigDecimal.valueOf(10000D));
        saldoResponseDTO.setSaldoDisponivel(BigDecimal.valueOf(10000D));
        saldoResponseDTO.setSaldoVinculado(BigDecimal.ZERO);
        saldoResponseDTO.setSaldoContabil(BigDecimal.ZERO);
        return saldoResponseDTO;
    }

    private static SaldoResponseDTO updateBalance() {
        @Valid final List<LancamentoV2DTO> lancamentos = mockedLancamentoResponse.getData().getLancamentos();
        @NotNull @Valid final BigDecimal lancamentoValue = lancamentos.get(0).getValor();

        final BigDecimal resultBalance = mockedSaldoResponse.getSaldoDisponivel().add(lancamentoValue);
        final SaldoResponseDTO saldoResponseDTO = new SaldoResponseDTO();
        saldoResponseDTO.setData(LocalDateTimeUtils.getTodayUTC());
        saldoResponseDTO.setSaldoBloqueado(BigDecimal.ZERO);
        saldoResponseDTO.setLimiteCreditoDisponivel(BigDecimal.valueOf(10000D));
        saldoResponseDTO.setSaldoDisponivel(resultBalance);
        saldoResponseDTO.setSaldoVinculado(BigDecimal.ZERO);
        saldoResponseDTO.setSaldoContabil(BigDecimal.ZERO);
        return saldoResponseDTO;
    }

    private static SaldoDTO buildSaldoDTO() {
        final SaldoDTO saldoDTO = new SaldoDTO();
        saldoDTO.setData(LocalDateTimeUtils.getTodayUTC());
        saldoDTO.setSaldoBloqueado(BigDecimal.ZERO);
        saldoDTO.setLimiteCreditoDisponivel(BigDecimal.valueOf(10000D));
        saldoDTO.setSaldoDisponivel(BigDecimal.valueOf(10010D));
        saldoDTO.setSaldoVinculado(BigDecimal.ZERO);
        saldoDTO.setSaldoContabil(BigDecimal.ZERO);
        saldoDTO.setSaldoInvestimento(BigDecimal.ZERO);
        return saldoDTO;
    }

    private static List<LancamentoV2DTO> buildLancamentoV2DTO() {
        final LancamentoV2DTO lancamentoV2DTO = new LancamentoV2DTO();
        lancamentoV2DTO.setIdLancamento(BigDecimal.valueOf(2D));
        lancamentoV2DTO.setDataLancamento(LocalDateTimeUtils.getTodayUTC());
        lancamentoV2DTO.setHistorico(120);
        lancamentoV2DTO.setDocumento(123L);
        lancamentoV2DTO.setValor(BigDecimal.TEN);
        lancamentoV2DTO.setComplementoHistorico("TesteSTDIN");
        lancamentoV2DTO.setAgenciaGeradora(1);
        lancamentoV2DTO.setTipoLimite(LancamentoV2DTO.TipoLimiteEnum.SALDO_MAIS_LIMITE);
        lancamentoV2DTO.setReferenciaMovimento("teste1495");
        lancamentoV2DTO.setExibeLancamentoAgrupado(false);
        lancamentoV2DTO.setEnviaNotificacao(true);
        lancamentoV2DTO.setValidaSaldo(LancamentoV2DTO.ValidaSaldoEnum.VALIDA_SE_SISTEMA_CONFIGURADO);
        lancamentoV2DTO.setAtualizaValorLote(true);
        lancamentoV2DTO.setDetalhes("teste1495");

        return List.of(lancamentoV2DTO);
    }

    private static class TokenResponseMock {
        static final String JSON = getJson(new TokenResponseMock());
        public String access_token = "ab12345c-6789-012d-3ee4-f56789g01hij"; // random token
        public String token_type = "bearer";
        public int expires_in = 86399;
        public String scope = "app";

        private static String getJson(Object object) {
            try {
                ObjectMapper mapper = new ObjectMapper();
                mapper.registerModule(new JavaTimeModule());
                mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
                return mapper.writeValueAsString(object);
            } catch (JsonProcessingException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
