package matera.spi.main.domain.service.event.receiver;

import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventStatus;
import matera.spi.main.domain.model.event.transaction.PaymentEventEntity;
import matera.spi.main.domain.model.event.transaction.ReceiptEventEntity;
import matera.spi.main.domain.model.event.transaction.TransactionEventEntity;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.domain.model.message.MessageErrorEntity;
import matera.spi.main.domain.model.transaction.PaymentEntity;
import matera.spi.main.domain.model.transaction.ReceiptEntity;
import matera.spi.main.domain.model.transaction.TransactionResultEntity;
import matera.spi.main.domain.service.MessageErrorService;
import matera.spi.main.domain.service.MessageService;
import matera.spi.main.domain.service.event.Event;
import matera.spi.main.domain.service.event.EventFactory;
import matera.spi.main.dto.MessageReceiverEventDTO;
import matera.spi.main.exception.IllegalProcessException;

import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.w3c.dom.Document;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static matera.spi.utils.DocumentUtils.stringToXmlDocument;
import static matera.spi.main.utils.EntityCreationUtils.buildAdmi002MessageEntity;
import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class MessageReceiverAdmi002ProcessorTest {

    @Mock
    private Event event;

    @Mock
    private MessageService messageService;

    @Mock
    private MessageErrorService messageErrorService;

    @Mock
    private EventFactory eventFactory;

    @InjectMocks
    private MessageReceiverAdmi002Processor messageReceiverAdmi002Processor;

    private static final String ADMI_002_SPI_1_2_SPI_M_MSG = "admi.002/admi.002.spi.1.2_SPI_M_msg.xml";
    private static final String ADMI_002_SPI_1_2_SPI_R_MSG = "admi.002/admi.002.spi.1.2_SPI_R_msg.xml";
    private static final Document ADMI_002_DOCUMENT_M = stringToXmlDocument(getStringFromXmlFile(ADMI_002_SPI_1_2_SPI_M_MSG));
    private static final Document ADMI_002_DOCUMENT_R = stringToXmlDocument(getStringFromXmlFile(ADMI_002_SPI_1_2_SPI_R_MSG));

    @Test
    public void shouldNotProcessAdmi002WhenAdmi002Exist() {
        MessageReceiverEventDTO messageReceiverEventDTO = MessageReceiverEventDTO.builder()
            .messageEntity(buildAdmi002MessageEntity())
            .messageDocument(ADMI_002_DOCUMENT_R)
            .build();

        when(messageErrorService.findByMessage(any(MessageEntity.class)))
            .thenReturn(Optional.of(new MessageErrorEntity()));

        ReceiptEventEntity receiptEventEntity = getReceiptEventEntity();
        when(messageService.findMessageEntityByPiResourceIdOrMessageId(anyString()))
            .thenReturn(createMessageEntityIpAccountTransactionResult(receiptEventEntity));

        messageReceiverAdmi002Processor.processEvent(messageReceiverEventDTO);

        verifyNoMoreInteractions(messageErrorService);
        verifyNoMoreInteractions(eventFactory);
        verifyNoMoreInteractions(event);
    }

    @Test
    public void shouldNotPocessAdmi002PiResourceIdOrMessageIdNotFound() {
        MessageReceiverEventDTO messageReceiverEventDTO = MessageReceiverEventDTO.builder()
            .messageEntity(buildAdmi002MessageEntity())
            .messageDocument(ADMI_002_DOCUMENT_R)
            .build();

        when(messageService.findMessageEntityByPiResourceIdOrMessageId(anyString()))
            .thenThrow(new IllegalProcessException(String.format(
                "Did not found original message for admi.002 with piResourceId or MessageId " +
                "equal to %s, ignoring the admi.002.", anyString())));
        messageReceiverAdmi002Processor.processEvent(messageReceiverEventDTO);

        verifyNoMoreInteractions(messageErrorService);
        verifyNoMoreInteractions(event);
    }

    @Test
    public void shouldPocessAdmi002ResourceEventNoIpAccountTransactionResult() {
        MessageReceiverEventDTO messageReceiverEventDTO = MessageReceiverEventDTO.builder()
                .messageEntity(buildAdmi002MessageEntity())
                .messageDocument(ADMI_002_DOCUMENT_R)
                .build();

        ReceiptEventEntity receiptEventEntity = getReceiptEventEntity();

        when(messageService.findMessageEntityByPiResourceIdOrMessageId(anyString())).thenReturn(createMessageEntityIpAccountTransactionResult(receiptEventEntity));
        when(eventFactory.findByEventEntity(any(EventEntity.class))).thenReturn(event);
        messageReceiverAdmi002Processor.processEvent(messageReceiverEventDTO);


        verify(event).revert();
        verify(event).sendNotification();
        verify(event).fireStatusTransition(EventStatus.ERROR);
        verifyNoMoreInteractions(event);
    }

    @Test
    public void shouldProcessAdmi002ResourceEventIpAccountTransactionResultPayment() {
        MessageReceiverEventDTO messageReceiverEventDTO = MessageReceiverEventDTO.builder()
                .messageEntity(buildAdmi002MessageEntity())
                .messageDocument(ADMI_002_DOCUMENT_R)
                .build();


        PaymentEventEntity paymentEventEntity = getPaymentEventEntity();

        when(messageService.findMessageEntityByPiResourceIdOrMessageId(anyString())).thenReturn(createMessageEntityIpAccountTransactionResult(paymentEventEntity));

        when(eventFactory.findByEventEntity(any(EventEntity.class))).thenReturn(event);

        messageReceiverAdmi002Processor.processEvent(messageReceiverEventDTO);

        verify(event).revert();
        verify(event).sendNotification();
        verify(event).fireStatusTransition(EventStatus.ERROR);
        verifyNoMoreInteractions(event);
    }

    @Test
    public void shouldPocessAdmi002ResourceEventIpAccountTransactionResultReceipt() {
        MessageReceiverEventDTO messageReceiverEventDTO = MessageReceiverEventDTO.builder()
                .messageEntity(buildAdmi002MessageEntity())
                .messageDocument(ADMI_002_DOCUMENT_R)
                .build();

        ReceiptEventEntity receiptEventEntity = getReceiptEventEntity();
        when(messageService.findMessageEntityByPiResourceIdOrMessageId(anyString())).thenReturn(createMessageEntityIpAccountTransactionResult(receiptEventEntity));

        when(eventFactory.findByEventEntity(any(EventEntity.class))).thenReturn(event);

        messageReceiverAdmi002Processor.processEvent(messageReceiverEventDTO);

        verify(event).revert();
        verify(event).sendNotification();
        verify(event).fireStatusTransition(EventStatus.ERROR);
        verifyNoMoreInteractions(event);
    }

    @Test
    public void shouldPocessAdmi002MessageEventNoIpAccountTransactionResult() {
        MessageReceiverEventDTO messageReceiverEventDTO = MessageReceiverEventDTO.builder()
                .messageEntity(buildAdmi002MessageEntity())
                .messageDocument(ADMI_002_DOCUMENT_M)
                .build();

        PaymentEventEntity paymentEventEntity = getPaymentEventEntity();
        when(messageService.findMessageEntityByPiResourceIdOrMessageId(anyString())).thenReturn(createMessageEntityIpAccountTransactionResult(paymentEventEntity));

        when(eventFactory.findByEventEntity(any(EventEntity.class))).thenReturn(event);

        messageReceiverAdmi002Processor.processEvent(messageReceiverEventDTO);

        verify(event).revert();
        verify(event).sendNotification();
        verify(event).fireStatusTransition(EventStatus.ERROR);
        verifyNoMoreInteractions(event);
    }
    private <T extends TransactionEventEntity> MessageEntity createMessageEntityIpAccountTransactionResult(T transactionEvent) {
        MessageEntity messageEntity = new MessageEntity();

        T transactionEntity = transactionEvent;

        TransactionResultEntity transactionResultEntityIpAccount = createTransactionEntity(85423L);
        transactionEntity.setIpAccountTransactionResult(transactionResultEntityIpAccount);

        TransactionResultEntity transactionResultEntityCustumer = createTransactionEntity(96545L);
        transactionEntity.getTransactionEntity().setCustomerTransactionResult(transactionResultEntityCustumer);

        TransactionResultEntity transactionResultEntity = createTransactionEntity(76541L);
        transactionEntity.setTransactionResult(transactionResultEntity);

        messageEntity.setEvents(List.of(transactionEntity));

        return messageEntity;
    }

    private TransactionResultEntity createTransactionEntity(Long idInDdaSystem) {
        TransactionResultEntity transactionResultEntity = new TransactionResultEntity();
        transactionResultEntity.setTransactionIdInDdaSystem(BigDecimal.valueOf(idInDdaSystem));
        return transactionResultEntity;
    }

    @NotNull
    private PaymentEventEntity getPaymentEventEntity() {
        PaymentEventEntity paymentEventEntity = new PaymentEventEntity();
        PaymentEntity transactionEntity = new PaymentEntity();
        paymentEventEntity.setPaymentEntity(transactionEntity);
        return paymentEventEntity;
    }

    @NotNull
    private ReceiptEventEntity getReceiptEventEntity() {
        ReceiptEventEntity receiptEventEntity = new ReceiptEventEntity();
        ReceiptEntity transactionEntity = new ReceiptEntity();
        receiptEventEntity.setReceiptEntity(transactionEntity);
        return receiptEventEntity;
    }

}
