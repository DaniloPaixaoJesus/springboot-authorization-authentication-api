package matera.spi.main.commons.persistence.repository;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.BalanceAccountPiEntity;
import matera.spi.main.domain.model.enums.EnumTransactionType;
import matera.spi.main.persistence.BalanceAccountPiRepository;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

@IntegrationTest
public class BalanceAccountPiRepositoryTest  {

    private static final BigDecimal BALANCE = new BigDecimal("12345678.00");
    private static final BigDecimal VALUE = new BigDecimal("12345666.00");

    @Autowired
    private BalanceAccountPiRepository repository;

    @Test
    public void saveAndFlush() {
        BalanceAccountPiEntity balanceAccountPiEntity = createObject();
        repository.saveAndFlush(balanceAccountPiEntity);
        List<BalanceAccountPiEntity> listBalance = repository.findAll();
        Assertions.assertTrue(listBalance.contains(balanceAccountPiEntity));
    }

    @Test
    @DisplayName("findFirstByOrderByIdDesc should return the last BalanceAccountPiEntity saved")
    public void shouldReturnTheLastRowWhenCallingFindFirstByOrderByIdDesc() {
        repository.saveAndFlush(createObject());
        repository.saveAndFlush(createObject());
        BalanceAccountPiEntity lastSavedEntity = repository.saveAndFlush(createObject());

        BalanceAccountPiEntity filteredEntity = repository.findFirstByOrderByIdDesc();

        assertEquals(lastSavedEntity, filteredEntity);
    }

    private BalanceAccountPiEntity createObject() {
        BalanceAccountPiEntity balanceAccountPiEntity = new BalanceAccountPiEntity();
        balanceAccountPiEntity.setBalance(BALANCE);
        balanceAccountPiEntity.setValue(VALUE);
        balanceAccountPiEntity.setTransactionType(EnumTransactionType.CREDIT);
        return balanceAccountPiEntity;
    }

}
