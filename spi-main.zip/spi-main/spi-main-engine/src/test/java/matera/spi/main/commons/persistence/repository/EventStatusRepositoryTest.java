package matera.spi.main.commons.persistence.repository;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.event.EventStatusEntity;
import matera.spi.main.persistence.EventStatusRepository;

import org.assertj.core.api.SoftAssertions;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import static matera.spi.main.domain.model.event.EventStatus.ERROR;
import static matera.spi.main.domain.model.event.EventStatus.PAYMENT_REJECTED;
import static matera.spi.main.domain.model.event.EventStatus.PAYMENT_REJECTED_BY_CLEARING;
import static matera.spi.main.domain.model.event.EventStatus.RECEIPT_REJECTED;
import static matera.spi.main.domain.model.event.EventStatus.RECEIPT_REJECTED_BY_CLEARING;
import static matera.spi.main.domain.model.event.EventStatus.RECEIPT_REJECTION_CONFIRMED;
import static matera.spi.main.domain.model.event.EventStatus.REJECTED;
import static matera.spi.main.domain.model.event.EventStatus.RETURN_REJECTED;
import static matera.spi.main.domain.model.event.EventStatus.RETURN_REJECTED_BY_CLEARING;
import static matera.spi.main.domain.model.event.EventStatus.RETURN_REJECTION_CONFIRMED;

@IntegrationTest
@Transactional
public class EventStatusRepositoryTest  {

    private static final Integer CODE = 123;
    private static final String DESCRIPTION = "description event type";

    private EventStatusEntity eventStatusEntity;

    @Autowired
    private EventStatusRepository repository;

    @BeforeEach
    void init() {
        eventStatusEntity = createObject();
    }

    @AfterEach
    void deleteInsertedValues() {
        repository.delete(eventStatusEntity);
        repository.flush();
    }

    @Test
    public void shouldReturnAllRejectionStatuses() {

        List<EventStatusEntity> eventStatusEntities = repository.findByRejectionStatusIsTrue();

        SoftAssertions softAssertions = new SoftAssertions();

        softAssertions.assertThat(hasRejectionStatusCode(eventStatusEntities.stream(), ERROR.getCode())).isTrue();
        softAssertions.assertThat(hasRejectionStatusCode(eventStatusEntities.stream(), PAYMENT_REJECTED.getCode())).isTrue();
        softAssertions.assertThat(hasRejectionStatusCode(eventStatusEntities.stream(), PAYMENT_REJECTED_BY_CLEARING.getCode())).isTrue();
        softAssertions.assertThat(hasRejectionStatusCode(eventStatusEntities.stream(), RECEIPT_REJECTED.getCode())).isTrue();
        softAssertions.assertThat(hasRejectionStatusCode(eventStatusEntities.stream(), RECEIPT_REJECTED_BY_CLEARING.getCode())).isTrue();
        softAssertions.assertThat(hasRejectionStatusCode(eventStatusEntities.stream(), RECEIPT_REJECTION_CONFIRMED.getCode())).isTrue();
        softAssertions.assertThat(hasRejectionStatusCode(eventStatusEntities.stream(), REJECTED.getCode())).isTrue();
        softAssertions.assertThat(hasRejectionStatusCode(eventStatusEntities.stream(), RETURN_REJECTED.getCode())).isTrue();
        softAssertions.assertThat(hasRejectionStatusCode(eventStatusEntities.stream(), RETURN_REJECTED_BY_CLEARING.getCode())).isTrue();
        softAssertions.assertThat(hasRejectionStatusCode(eventStatusEntities.stream(), RETURN_REJECTION_CONFIRMED.getCode())).isTrue();

        softAssertions.assertAll();

    }

    @Test
    public void saveAndFlush() {
        repository.saveAndFlush(eventStatusEntity);
        Optional<EventStatusEntity> optionalEventStatusEntity = repository.findByDescription(DESCRIPTION);
        if(optionalEventStatusEntity.isPresent()) {
            Assertions.assertNotNull(optionalEventStatusEntity.get().getCode());
            Assertions.assertNotNull(optionalEventStatusEntity.get().getDescription());
            Assertions.assertEquals(CODE, optionalEventStatusEntity.get().getCode());
            Assertions.assertEquals(DESCRIPTION, optionalEventStatusEntity.get().getDescription());
        }
    }

    @Test
    public void findByDescription() {
        Optional<EventStatusEntity> optional =  repository.findByDescription(DESCRIPTION);
        if(optional.isPresent())
            Assertions.assertEquals(DESCRIPTION, optional.get().getDescription());
    }

    private EventStatusEntity createObject() {
        EventStatusEntity eventStatusEntity = new EventStatusEntity();
        eventStatusEntity.setCode(CODE);
        eventStatusEntity.setDescription(DESCRIPTION);
        eventStatusEntity.setFinalStatus(false);
        return repository.saveAndFlush(eventStatusEntity);
    }

    private boolean hasRejectionStatusCode(Stream<EventStatusEntity> eventStatusEntityStream, Integer errorCode) {

        return eventStatusEntityStream.anyMatch(e -> {

            return e.getCode().equals(errorCode) && e.isRejectionStatus();
        });
    }
}
