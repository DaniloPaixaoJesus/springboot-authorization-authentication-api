package matera.spi.lm.domain.service;

import matera.spi.main.domain.service.ParticipantService;
import matera.spi.main.exception.InvalidIspbException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

@ExtendWith(MockitoExtension.class)
public class ParticipantDomainServiceTest {

    private static final String MOCKED_ISPB = "01234567";

    @InjectMocks
    private ParticipantDomainService participantDomainService;

    @Mock
    private ParticipantService participantService;

    @BeforeEach
    void init() {
    }

    @Test
    void shouldThrowExceptionIfCantFindParticipantByIspb() {
        Mockito.when(participantService.findByIspb(Mockito.anyInt())).thenReturn(Optional.empty());

        Assertions.assertThrows(InvalidIspbException.class,
            () -> participantDomainService.getParticipant(MOCKED_ISPB));
    }

}
