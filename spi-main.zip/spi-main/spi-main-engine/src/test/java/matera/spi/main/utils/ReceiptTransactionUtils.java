package matera.spi.main.utils;

import matera.spi.main.domain.model.ConfigEntity;
import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.domain.model.account.AccountTypeEntity;
import matera.spi.main.domain.model.account.PayerAccountEntity;
import matera.spi.main.domain.model.account.ReceiverAccountEntity;
import matera.spi.main.domain.model.event.transaction.ReceiptEventEntity;
import matera.spi.main.domain.model.transaction.ReceiptEntity;
import matera.spi.main.domain.model.transaction.TransactionEntity;
import matera.spi.main.domain.model.transaction.TransactionPriorityEntity;
import matera.spi.main.domain.service.ConfigurationService;
import matera.spi.main.messages.schema.generated.pacs008.ChargeBearerType1Code;
import matera.spi.main.messages.schema.generated.pacs008.SettlementMethod1Code;
import matera.spi.main.persistence.AccountTypeRepository;
import matera.spi.main.persistence.ParticipantRepository;
import matera.spi.main.persistence.ReceiptRepository;
import matera.spi.main.persistence.TransactionPriorityRepository;
import matera.spi.utils.LocalDateTimeUtils;

import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import static matera.spi.main.utils.constants.TransactionConstants.ACCOUNT_TYPE_CODE;
import static matera.spi.main.utils.constants.TransactionConstants.ACCOUNT_TYPE_DESCRIPTION;
import static matera.spi.main.utils.constants.TransactionConstants.PAYER_ACCOUNT;
import static matera.spi.main.utils.constants.TransactionConstants.PAYER_BRANCH;
import static matera.spi.main.utils.constants.TransactionConstants.PAYER_NAME;
import static matera.spi.main.utils.constants.TransactionConstants.PAYER_PARTICIPANT_ENTITY_NAME_FOR_RECEIPT;
import static matera.spi.main.utils.constants.TransactionConstants.PAYER_TAX_ID;
import static matera.spi.main.utils.constants.TransactionConstants.RECEIPT_INITIATING_INSTITUTION_TAX_ID;
import static matera.spi.main.utils.constants.TransactionConstants.RECEIVER_ACCOUNT;
import static matera.spi.main.utils.constants.TransactionConstants.RECEIVER_ADDITIONAL_INFORMATION;
import static matera.spi.main.utils.constants.TransactionConstants.RECEIVER_ADDRESSING_KEY;
import static matera.spi.main.utils.constants.TransactionConstants.RECEIVER_BRANCH;
import static matera.spi.main.utils.constants.TransactionConstants.RECEIVER_PARTICIPANT_ENTITY_ISPB_FOR_RECEIPT;
import static matera.spi.main.utils.constants.TransactionConstants.RECEIVER_PARTICIPANT_ENTITY_NAME_FOR_RECEIPT;
import static matera.spi.main.utils.constants.TransactionConstants.RECEIVER_RECON_IDENTIFIER;
import static matera.spi.main.utils.constants.TransactionConstants.RECEIVER_TAX_ID;
import static matera.spi.main.utils.constants.TransactionConstants.TRANSACTION_PRIORITY_ENTITY_CODE_FOR_RECEIPT;

@Component
public class ReceiptTransactionUtils {

    @Autowired
    private ParticipantRepository participantRepository;

    @Autowired
    private AccountTypeRepository accountTypeRepository;

    @Autowired
    private TransactionPriorityRepository transactionPriorityRepository;

    @Autowired
    private ReceiptRepository receiptRepository;

    @Autowired
    private EventEntityUtils eventEntityUtils;

    @Autowired
    private ConfigurationService configurationService;

    public ReceiptEntity newReceiptEntity(BigDecimal value, Integer eventStatus) {
        final ReceiptEventEntity eventEntity = eventEntityUtils.buildReceiptEventEntity(value, eventStatus);
        final ReceiptEntity newReceipt = buildReceiptEntity();

        eventEntityUtils.setReceiptEntityInEvent(eventEntity, newReceipt);
        eventEntityUtils.saveEventEntity(eventEntity);
        eventEntityUtils.buildReceiptEventStatusTransitionEntity(eventEntity);

        return newReceipt;
    }

    public ReceiptEntity buildReceiptEntity() {
        final String endToEndId = UUID.randomUUID().toString().replaceAll("-", "");

        ReceiptEntity newReceipt = new ReceiptEntity();
        newReceipt.setAdditionalInformation(RECEIVER_ADDITIONAL_INFORMATION);
        newReceipt.setCustomerInitTimestampUtc(LocalDateTimeUtils.getUtcLocalDateTime());
        newReceipt.setEndToEndId(endToEndId);
        newReceipt.setInitiatingInstitutionTaxId(RECEIPT_INITIATING_INSTITUTION_TAX_ID);
        newReceipt.setPayerParticipant(getPayerParticipant());
        newReceipt.setReceiverParticipant(getReceiverParticipant());
        newReceipt.setPayerAccount(buildPayerAccountEntity());
        newReceipt.setReceiverAccount(buildReceiverAccountEntity());
        newReceipt.setPriority(getTransactionPriorityEntity());
        newReceipt.setReceiverReconIdentifier(RECEIVER_RECON_IDENTIFIER);
        newReceipt.setSettlementMethod(SettlementMethod1Code.CLRG.value());
        newReceipt.setChargeBearer(ChargeBearerType1Code.SLEV.value());
        return newReceipt;
    }

    public void deleteAllInsertedValues() {
        final List<ReceiptEntity> receiptList = receiptRepository.findAll();
        final List<ParticipantEntity> participantReceiverList = participantRepository.findByNameContainingIgnoreCase(RECEIVER_PARTICIPANT_ENTITY_NAME_FOR_RECEIPT);
        final List<ParticipantEntity> participantPayerList = participantRepository.findByNameContainingIgnoreCase(PAYER_PARTICIPANT_ENTITY_NAME_FOR_RECEIPT);
        eventEntityUtils.deleteAllInsertValuesFromEventEntity();
        receiptRepository.deleteAll(receiptList);
        participantRepository.deleteAll(participantReceiverList);
        participantRepository.deleteAll(participantPayerList);

    }


    @NotNull
    private Set<ParticipantEntity> getPayerParticipants(List<ReceiptEntity> receiptList) {
        return receiptList
                .stream()
                .map(TransactionEntity::getPayerParticipant)
                .collect(Collectors.toSet());
    }

    @NotNull
    private Set<ParticipantEntity> getReceiverParticipants(List<ReceiptEntity> receiptList) {
        return receiptList
                .stream()
                .map(TransactionEntity::getReceiverParticipant)
                .collect(Collectors.toSet());
    }

    private TransactionPriorityEntity getTransactionPriorityEntity() {
        final Optional<TransactionPriorityEntity> optional = transactionPriorityRepository.findById(TRANSACTION_PRIORITY_ENTITY_CODE_FOR_RECEIPT);
        return optional.orElseGet(this::buildTransactionPriorityEntity);
    }

    private TransactionPriorityEntity buildTransactionPriorityEntity() {
        return transactionPriorityRepository.getOne("HIGH");
    }

    private ParticipantEntity getPayerParticipant() {
        final Integer ispbNumber = configurationService.findConfig().getIspb();
        final Optional<ParticipantEntity> optional = participantRepository.findByIspb(ispbNumber);
        return optional.orElseGet(() -> buildPayerParticipant(ispbNumber));
    }

    private ParticipantEntity buildPayerParticipant(Integer ispbNumber) {
        final ParticipantEntity entity = new ParticipantEntity();
        entity.setIspb(ispbNumber);
        entity.setName(PAYER_PARTICIPANT_ENTITY_NAME_FOR_RECEIPT);
        participantRepository.saveAndFlush(entity);
        return entity;
    }

    private ParticipantEntity getReceiverParticipant() {
        final Optional<ParticipantEntity> optional = participantRepository.findByIspb(RECEIVER_PARTICIPANT_ENTITY_ISPB_FOR_RECEIPT);
        return optional.orElseGet(this::buildReceiverParticipant);
    }

    private ParticipantEntity buildReceiverParticipant() {
        final ParticipantEntity entity = new ParticipantEntity();
        entity.setIspb(RECEIVER_PARTICIPANT_ENTITY_ISPB_FOR_RECEIPT);
        entity.setName(RECEIVER_PARTICIPANT_ENTITY_NAME_FOR_RECEIPT);

        participantRepository.saveAndFlush(entity);
        return entity;
    }

    private PayerAccountEntity buildPayerAccountEntity() {
        final PayerAccountEntity entity = new PayerAccountEntity();
        entity.setTaxId(PAYER_TAX_ID);
        entity.setName(PAYER_NAME);
        entity.setBranch(PAYER_BRANCH);
        entity.setAccount(PAYER_ACCOUNT);
        entity.setAccountType(getAccountTypeEntity().getCode());

        return entity;
    }

    private ReceiverAccountEntity buildReceiverAccountEntity() {
        final ReceiverAccountEntity entity = new ReceiverAccountEntity();
        entity.setTaxId(RECEIVER_TAX_ID);
        entity.setBranch(RECEIVER_BRANCH);
        entity.setAccount(RECEIVER_ACCOUNT);
        entity.setAddressingKey(RECEIVER_ADDRESSING_KEY);
        entity.setAccountType(getAccountTypeEntity().getCode());

        return entity;
    }

    private AccountTypeEntity getAccountTypeEntity() {
        final Optional<AccountTypeEntity> optinal = accountTypeRepository.findById(ACCOUNT_TYPE_CODE);
        return optinal.orElseGet(this::buildAccountTypeEntity);
    }

    private AccountTypeEntity buildAccountTypeEntity() {
        final AccountTypeEntity entity = new AccountTypeEntity();
        entity.setCode(ACCOUNT_TYPE_CODE);
        entity.setDescription(ACCOUNT_TYPE_DESCRIPTION);

        accountTypeRepository.saveAndFlush(entity);
        return entity;
    }

}
