package matera.spi.indirect.rest.ui;

import com.matera.spi.messaging.api.MessagesApi;
import com.matera.spi.messaging.api.SPIMessagingApis;
import com.matera.spi.messaging.model.MessageSentResponseDTO;
import com.matera.spi.messaging.model.MessageSpecificationDTO;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.IndirectParticipantContactDTO;
import matera.spi.dto.IndirectParticipantCreationRequestDTO;
import matera.spi.dto.IndirectParticipantFinancialFieldsUIDTO;
import matera.spi.dto.IndirectParticipantHistoryDTO;
import matera.spi.dto.IndirectParticipantStatusDTO;
import matera.spi.dto.IndirectParticipantUpdateRequestDTO;
import matera.spi.dto.PageableIndirectParticipantHistoryResponseDTO;
import matera.spi.dto.PageableIndirectParticipantHistoryResponseWrapperDTO;
import matera.spi.indirect.persistence.ParticipantMipIndirectContactsRepository;
import matera.spi.indirect.persistence.ParticipantMipIndirectHistoryRepository;
import matera.spi.indirect.persistence.ParticipantMipIndirectRepository;
import matera.spi.indirect.util.ParticipantMipIndirectDataSetUtil;
import matera.spi.main.domain.service.MessageSender;
import matera.spi.main.persistence.ParticipantMipRepository;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import static matera.spi.dto.IndirectParticipantStatusDTO.REGISTRATION_SENT_TO_CLEARING;
import static matera.spi.dto.IndirectParticipantStatusDTO.WAITING_TO_SEND_REGISTRATION_TO_CLEARING;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import static java.util.Arrays.stream;

@IntegrationTest
public class IndirectHisotoryUiApiDelegateIT {

    // -- URLS --
    private static final String CREATE_INDIRECT_URL = "/ui/v1/indirect";
    private static final String URL_PART_COMPLETE = "/ui/v1/indirect/{ispb}";
    private static final String HISTORY_URL = "/ui/v1/indirect/history/{ispb}";
    private static final String INDIRECT_PART_REGISTER_URL = "/ui/v1/indirect/registration/{ispb}";

    // -- VARIABLES --
    private static final String PI_RESOURCE_ID = "PI-RESOURCE-ID-TEST";
    private static final String TX_ID = "79610132000195";
    private static final String ACCOUNT_NUMBER = "123";
    private static final String BRANCH = "1";
    private static final LocalDate CONTRACT_END_DATE = LocalDate.now().plusDays(1);
    private static final LocalDate CONTRACT_INIT_DATE = LocalDate.now();
    private static final String CORPORATE_NAME = "CORP_NAME";
    private static final String ISPB = "00192555";
    private static final String NAME = "name";

    // -- PARAMS --
    private static final String ISPB_PARAM_NAME = "ispb";
    private static final String PAGE_SIZE_PARAM_NAME = "pageSize";
    private static final String PAGE_NUMBER_PARAM_NAME = "pageNumber";
    private static final Integer PAGE_SIZE = 5;
    private static final Integer PAGE_NUMBER = 0;

    @LocalServerPort
    private int port;

    @Mock
    private SPIMessagingApis mockedSpiMessagingApis;

    @Mock
    private MessagesApi mockedMessagesApi;

    @Autowired
    private MessageSender messageSender;

    @Autowired
    private SPIMessagingApis spiMessagingApisBean;

    @Autowired
    private ParticipantMipIndirectRepository participantMipIndirectRepository;

    @Autowired
    private ParticipantMipRepository participantMipRepository;

    @Autowired
    private ParticipantMipIndirectHistoryRepository participantMipIndirectHistoryRepository;

    @Autowired
    private ParticipantMipIndirectContactsRepository participantMipIndirectContactsRepository;


    @BeforeEach
    @AfterEach
    void cleanData() {
        ParticipantMipIndirectDataSetUtil.cleanIndirectParticipantTablesData(participantMipIndirectHistoryRepository,
            participantMipIndirectContactsRepository, participantMipIndirectRepository, participantMipRepository);
    }

    @BeforeEach
    void setup() {
        when(mockedSpiMessagingApis.messagesApi()).thenReturn(mockedMessagesApi);
        messageSender.setSpiMessagingApis(mockedSpiMessagingApis);
        RestAssured.port = port;
    }

    @AfterEach
    void tearDown() {
        messageSender.setSpiMessagingApis(spiMessagingApisBean);
    }

    @Test
    public void shouldReturnHistoryListAccordingPreviousIndirectStatus() {
        when(mockedMessagesApi.sendsMessageV1(any(MessageSpecificationDTO.class)))
            .thenReturn(buildMessageSentResponseDTO());

        final IndirectParticipantCreationRequestDTO creationRequestDTO = createIndirectParticipantCreationRequestMock();
        final IndirectParticipantUpdateRequestDTO updateRequestDTOMock = createIndirectParticipantUpdateRequestMock();

        executeCreationRequest(creationRequestDTO);
        executeGetHistoryListRequest(creationRequestDTO);
        executeRegistrationRequest(creationRequestDTO);
        executeGetHistoryListRequest(creationRequestDTO);
        executeUpdateRequest(Integer.valueOf(creationRequestDTO.getIspb()), updateRequestDTOMock);

        final PageableIndirectParticipantHistoryResponseDTO pageableIndirectHistoryResponseDTO =
            executeGetHistoryListRequest(creationRequestDTO);

        Assertions.assertFalse(pageableIndirectHistoryResponseDTO.getEmpty());
        Assertions.assertEquals(3, pageableIndirectHistoryResponseDTO.getTotalElements());

        final List<IndirectParticipantStatusDTO> actualPreviousStatusDTOList = getIndirectParticipantStatusDTOList(pageableIndirectHistoryResponseDTO.getContent());
        final List<IndirectParticipantStatusDTO> expectedPreviousStatusDTOList =
            buildExpectedIndirectParticipantStatusDTOList(REGISTRATION_SENT_TO_CLEARING,
                WAITING_TO_SEND_REGISTRATION_TO_CLEARING, WAITING_TO_SEND_REGISTRATION_TO_CLEARING);
        Assertions.assertArrayEquals(expectedPreviousStatusDTOList.toArray(), actualPreviousStatusDTOList.toArray());
    }

    private List<IndirectParticipantStatusDTO> buildExpectedIndirectParticipantStatusDTOList(IndirectParticipantStatusDTO... registrationSentToClearing) {
        return stream(registrationSentToClearing).collect(Collectors.toList());
    }

    private List<IndirectParticipantStatusDTO> getIndirectParticipantStatusDTOList(List<IndirectParticipantHistoryDTO> content) {
        return content.stream()
            .map(IndirectParticipantHistoryDTO::getIndirectPreviousStatus)
            .collect(Collectors.toList());
    }

    private void executeRegistrationRequest(IndirectParticipantCreationRequestDTO creationRequestDTO) {
        //@formatter:off
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(creationRequestDTO)
            .pathParam(ISPB_PARAM_NAME, creationRequestDTO.getIspb())
            .when()
            .post(INDIRECT_PART_REGISTER_URL)
            .then()
            .statusCode(HttpStatus.SC_ACCEPTED)
            .extract();
        //@formatter:on
    }

    private @Valid PageableIndirectParticipantHistoryResponseDTO executeGetHistoryListRequest(IndirectParticipantCreationRequestDTO creationRequestDTO) {
        //@formatter:off
        return RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(StringUtils.EMPTY)
            .header(PAGE_SIZE_PARAM_NAME, PAGE_SIZE)
            .header(PAGE_NUMBER_PARAM_NAME, PAGE_NUMBER)
            .pathParam(ISPB_PARAM_NAME, creationRequestDTO.getIspb())
            .when()
            .get(HISTORY_URL)
            .then()
            .statusCode(HttpStatus.SC_OK)
            .extract().as(PageableIndirectParticipantHistoryResponseWrapperDTO.class)
            .getData();
        //@formatter:on

    }

    private void executeUpdateRequest(Integer ispb,
                                      IndirectParticipantUpdateRequestDTO updateRequestDTOMock) {
        //@formatter:off
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(updateRequestDTOMock)
            .pathParam(ISPB_PARAM_NAME, ispb)
            .when()
            .post(URL_PART_COMPLETE)
            .then()
            .statusCode(HttpStatus.SC_OK);
        //@formatter:on
    }

    private void executeCreationRequest(IndirectParticipantCreationRequestDTO creationRequestDTO) {
        //@formatter:off
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(creationRequestDTO)
            .when()
            .post(CREATE_INDIRECT_URL)
            .then()
            .statusCode(HttpStatus.SC_CREATED)
            .extract();
        //@formatter:on
    }

    private IndirectParticipantCreationRequestDTO createIndirectParticipantCreationRequestMock() {
        IndirectParticipantCreationRequestDTO indirectParticipant = new IndirectParticipantCreationRequestDTO();
        indirectParticipant.setStatus(WAITING_TO_SEND_REGISTRATION_TO_CLEARING);
        indirectParticipant.setAccountNumber(ACCOUNT_NUMBER);
        indirectParticipant.setBranch(BRANCH);
        indirectParticipant.setContacts(createIndirectParticipantContactListMock());
        indirectParticipant.setContractEndDate(CONTRACT_END_DATE);
        indirectParticipant.setContractInitDate(CONTRACT_INIT_DATE);
        indirectParticipant.setCorporateName(CORPORATE_NAME);
        indirectParticipant.setIspb(ISPB);
        indirectParticipant.setFinancial(createIndirectParticipantFinancialFieldsMock());
        indirectParticipant.setName(NAME);
        indirectParticipant.setTaxId(TX_ID);
        return indirectParticipant;
    }

    private IndirectParticipantUpdateRequestDTO createIndirectParticipantUpdateRequestMock() {
        IndirectParticipantUpdateRequestDTO indirectParticipant = new IndirectParticipantUpdateRequestDTO();
        indirectParticipant.setStatus(WAITING_TO_SEND_REGISTRATION_TO_CLEARING);
        indirectParticipant.setAccountNumber(ACCOUNT_NUMBER);
        indirectParticipant.setBranch(BRANCH);
        indirectParticipant.setContacts(createIndirectParticipantContactListMock());
        indirectParticipant.setContractEndDate(CONTRACT_END_DATE);
        indirectParticipant.setContractInitDate(CONTRACT_INIT_DATE);
        indirectParticipant.setCorporateName(CORPORATE_NAME);
        indirectParticipant.setIspb(ISPB);
        indirectParticipant.setFinancial(createIndirectParticipantFinancialFieldsMock());
        indirectParticipant.setName(NAME);
        indirectParticipant.setTaxId(TX_ID);
        return indirectParticipant;
    }

    private List<IndirectParticipantContactDTO> createIndirectParticipantContactListMock() {
        List<IndirectParticipantContactDTO> indirectParticipantContactList = new ArrayList<>();
        IndirectParticipantContactDTO indirectParticipantContact = new IndirectParticipantContactDTO();
        indirectParticipantContact.setDepartment("DEPARTMENT");
        indirectParticipantContact.setEmail("EMAIL@EMAIL.COM");
        indirectParticipantContact.setName("CONTACT_NAME");
        indirectParticipantContact.setPhone("555555555");
        indirectParticipantContactList.add(indirectParticipantContact);
        return indirectParticipantContactList;
    }

    private IndirectParticipantFinancialFieldsUIDTO createIndirectParticipantFinancialFieldsMock() {
        IndirectParticipantFinancialFieldsUIDTO indirectParticipantFinancialFields =
            new IndirectParticipantFinancialFieldsUIDTO();
        indirectParticipantFinancialFields.setBalanceLowerThreshold(new BigDecimal("100"));
        indirectParticipantFinancialFields.setBalanceValidationThreshold(true);
        indirectParticipantFinancialFields.setCredTransactionType(123);
        indirectParticipantFinancialFields.setDebitTransactionType(555);
        indirectParticipantFinancialFields.setDrawbackReceiveTransactType(999);
        indirectParticipantFinancialFields.setDrawbackSentTransactType(111);
        indirectParticipantFinancialFields.setQrcodeCredTransactionType(789);
        return indirectParticipantFinancialFields;
    }

    private static MessageSentResponseDTO buildMessageSentResponseDTO() {
        MessageSentResponseDTO messageSentResponseDTO = new MessageSentResponseDTO();
        messageSentResponseDTO.setPiResourceID(PI_RESOURCE_ID);
        return messageSentResponseDTO;
    }
}
