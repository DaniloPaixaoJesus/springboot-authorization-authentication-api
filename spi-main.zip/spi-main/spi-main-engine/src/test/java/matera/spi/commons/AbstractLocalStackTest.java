package matera.spi.commons;

import org.testcontainers.containers.localstack.LocalStackContainer;
import org.testcontainers.junit.jupiter.Container;

import static org.testcontainers.containers.localstack.LocalStackContainer.Service.SQS;

//@ActiveProfiles(profiles = {"awstest"})
public class AbstractLocalStackTest {

    @Container
    static LocalStackContainer localStackContainer = new LocalStackContainer("0.10.6").withServices(SQS)
            .withEnv("HOSTNAME_EXTERNAL", "localhost");
}
