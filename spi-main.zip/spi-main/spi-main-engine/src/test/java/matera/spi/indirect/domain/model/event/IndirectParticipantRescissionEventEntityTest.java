package matera.spi.indirect.domain.model.event;

import matera.spi.main.domain.model.event.EventType;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

import javax.persistence.DiscriminatorValue;

import static org.junit.jupiter.api.Assertions.assertEquals;

class IndirectParticipantRescissionEventEntityTest {

    public static final String EXPECTED_DISCRIMINATOR_VALUE = "18";

    @Test
    void shouldReturnEventTypeAsIndirectParticipantRescission() {
        assertEquals(EventType.INDIRECT_PARTICIPANT_RESCISSION,
            new IndirectParticipantRescissionEventEntity().getEventType());
    }

    @Test
    void shouldHaveTheDiscriminatorValueAsNine() {
        final DiscriminatorValue annotationsByType =
            IndirectParticipantRescissionEventEntity.class.getAnnotation(DiscriminatorValue.class);

        Assertions
            .assertThat(annotationsByType)
            .isNotNull()
            .hasFieldOrPropertyWithValue("value", EXPECTED_DISCRIMINATOR_VALUE);
    }

}
