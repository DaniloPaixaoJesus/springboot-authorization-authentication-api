package matera.spi.lm.application.services.validation;

import matera.spi.dto.SpbCallbackDTO;
import matera.spi.lm.application.service.validation.SpbApiValidator;
import matera.spi.lm.exception.SpbCallbackException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import java.util.List;

public class SpbApiValidatorTest {

    @Spy
    private SpbApiValidator spbApiValidator;

    @BeforeEach
    void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void shouldThrowSpbExecptionWhenMessagesIsNull() {
        final SpbCallbackDTO spbCallbackDTO = new SpbCallbackDTO();
        Assertions.assertThrows(SpbCallbackException.class, () -> {
            spbApiValidator.validateSpbCallback(spbCallbackDTO);
        });
    }

    @Test
    void shouldThrowSpbExecptionWhenMessagesIsGreaterThanOne() {
        final SpbCallbackDTO spbCallbackDTO = new SpbCallbackDTO();
        spbCallbackDTO.setMessages(List.of("Test1", "Test2"));

        Assertions.assertEquals(2, spbCallbackDTO.getMessages().size());
        Assertions.assertThrows(SpbCallbackException.class, () -> {
            spbApiValidator.validateSpbCallback(spbCallbackDTO);
        });
    }

}
