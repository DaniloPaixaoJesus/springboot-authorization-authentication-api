package matera.spi.indirect.application.service;

import com.matera.commons.utils.exception.BusinessException;

import matera.spi.dto.IndirectParticipantCancelmentResponseDTO;
import matera.spi.dto.IndirectParticipantContactDTO;
import matera.spi.dto.IndirectParticipantCreationRequestDTO;
import matera.spi.dto.IndirectParticipantCreationResponseDTO;
import matera.spi.dto.IndirectParticipantFinancialFieldsUIDTO;
import matera.spi.dto.IndirectParticipantHistoryDTO;
import matera.spi.dto.IndirectParticipantHistoryEventTypeDTO;
import matera.spi.dto.IndirectParticipantIdentificationUIDTO;
import matera.spi.dto.IndirectParticipantPossibleActionsDTO;
import matera.spi.dto.IndirectParticipantRegistrationResponseDTO;
import matera.spi.dto.IndirectParticipantRescissionResponseDTO;
import matera.spi.dto.IndirectParticipantStatusDTO;
import matera.spi.dto.IndirectParticipantUIDTO;
import matera.spi.dto.IndirectParticipantUpdateRequestDTO;
import matera.spi.dto.IndirectParticipantUpdateResponseDTO;
import matera.spi.dto.PageableIndirectParticipantHistoryResponseDTO;
import matera.spi.dto.PageableIndirectParticipantResponseDTO;
import matera.spi.indirect.application.service.mapper.IndirectParticipantPossibleActionsDTOMapper;
import matera.spi.indirect.application.service.mapper.IndirectParticipantRescissionResponseDTOMapper;
import matera.spi.indirect.application.service.validator.IndirectParticipantRegisterValidator;
import matera.spi.indirect.application.service.validator.IndirectParticipantRescissionValidator;
import matera.spi.indirect.application.service.validator.IndirectParticipantValidator;
import matera.spi.indirect.domain.model.ParticipantMipIndirectEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectHistoryEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectStatusEntity;
import matera.spi.indirect.domain.model.enums.IndirectParticipantStatusEnum;
import matera.spi.indirect.domain.model.event.IndirectParticipantRescissionEventEntity;
import matera.spi.indirect.domain.service.IndirectParticipantCancelmentService;
import matera.spi.indirect.domain.service.IndirectParticipantCreationService;
import matera.spi.indirect.domain.service.IndirectParticipantHistoryService;
import matera.spi.indirect.domain.service.IndirectParticipantInformationRetriever;
import matera.spi.indirect.domain.service.IndirectParticipantMipService;
import matera.spi.indirect.domain.service.IndirectParticipantRegistryService;
import matera.spi.indirect.domain.service.IndirectParticipantRescissionService;
import matera.spi.indirect.domain.service.IndirectParticipantStatusService;
import matera.spi.indirect.domain.service.IndirectParticipantUpdateService;
import matera.spi.indirect.domain.service.event.IndirectParticipantRegisterEvent;
import matera.spi.indirect.domain.service.event.IndirectParticipantRescissionEvent;
import matera.spi.indirect.dto.event.IndirectParticipantRegisterEventSpecificationDTO;
import matera.spi.indirect.dto.event.IndirectParticipantRescissionEventSpecificationDTO;
import matera.spi.indirect.exception.EntityNotFoundException;
import matera.spi.indirect.exception.message.ExceptionMessages;
import matera.spi.indirect.persistence.ParticipantMipIndirectHistoryRepository;
import matera.spi.indirect.persistence.ParticipantMipIndirectRepository;
import matera.spi.indirect.util.ParticipantMipIndirectDataSetUtil;
import matera.spi.main.domain.model.ParticipantMipEntity;
import matera.spi.main.domain.model.event.EventStatusEntity;
import matera.spi.utils.IspbUtils;

import org.assertj.core.util.Lists;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static matera.spi.utils.IspbUtils.leftPadIspb;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class IndirectParticipantApplicationUIServiceTest {

    private static final String ACCOUNT_NUMBER = "123";
    private static final String BRANCH = "1";
    private static final LocalDate CONTRACT_END_DATE = LocalDate.now().plusDays(1);
    private static final LocalDate CONTRACT_INIT_DATE = LocalDate.now();
    private static final LocalDate CONTRACT_INIT_DATE_BIGGER_THAN_END_DATE = LocalDate.now().plusDays(2);
    private static final String CORPORATE_NAME = "CORP_NAME";
    private static final Integer ISPB = 192555;
    private static final String NAME = "name";
    private static final String TAX_ID = "79610132000195";
    private static final Integer PAGE_SIZE = 10;
    private static final Integer CURRENT_PAGE = 0;
    private static final Integer PAGE_NUMBER = 0;
    private static final Integer TOTAL_ELEMENTS = 1;
    private static final Integer TOTAL_PAGES = 1;
    private static final LocalDateTime EVENT_DATE_TIME = LocalDateTime.of(2020, 4, 7, 13, 14, 55);

    @Mock
    private IndirectParticipantCreationService indirectParticipantCreationService;

    @Mock
    private ParticipantMipIndirectRepository participantMipIndirectRepository;

    @Mock
    private IndirectParticipantUpdateService indirectParticipantUpdateService;

    @Mock
    private IndirectParticipantStatusService indirectParticipantStatusService;

    @Mock
    private IndirectParticipantInformationRetriever indirectParticipantInformationRetriever;

    @Mock
    private IndirectParticipantRegistryService indirectParticipantRegistryService;

    @Mock
    private ParticipantMipIndirectHistoryRepository participantMipIndirectHistoryRepository;

    @Mock
    private IndirectParticipantRescissionService indirectParticipantRescissionService;

    @Mock
    private IndirectParticipantCancelmentService indirectParticipantCancelmentService;

    @Spy
    @InjectMocks
    private IndirectParticipantHistoryService indirectParticipantHistoryService;

    @Spy
    private IndirectParticipantValidator indirectParticipantValidator;

    @Spy
    private IndirectParticipantRegisterValidator indirectParticipantRegisterValidator;

    @Spy
    private IndirectParticipantRescissionValidator indirectParticipantRescissionValidator;

    @InjectMocks
    private IndirectParticipantApplicationUIService indirectParticipantApplicationUIService;

    private final IndirectParticipantMipService indirectParticipantMipService = new IndirectParticipantMipService(participantMipIndirectRepository);

    @Test
    void shouldCreateIndirectParticipantWhenInformationIsValid() {
        Optional<ParticipantMipIndirectEntity> response = createParticipantMipIndirectEntityMock();
        IndirectParticipantCreationRequestDTO indirectParticipantCreationRequestMock =
            createIndirectParticipantCreationRequestMock();

        when(indirectParticipantCreationService.createIndirectParticipant(any()))
            .thenReturn(response.orElseThrow());

        IndirectParticipantCreationResponseDTO indirectParticipantCreationResponseDTO =
            indirectParticipantApplicationUIService.createIndirectParticipant(indirectParticipantCreationRequestMock);

        assertNotNull(indirectParticipantCreationResponseDTO.getStatus());
        assertEquals(indirectParticipantCreationResponseDTO.getStatus(),
            indirectParticipantCreationRequestMock.getStatus());
    }

    @Test
    void shouldNotCreateIndirectParticipantWhenInformationIsInvalid() {
        IndirectParticipantCreationRequestDTO indirectParticipantCreationRequestDTO =
            createIndirectParticipantCreationRequestMock();
        indirectParticipantCreationRequestDTO.setContractInitDate(CONTRACT_INIT_DATE_BIGGER_THAN_END_DATE);

        assertThrows(BusinessException.class, () -> indirectParticipantApplicationUIService
            .createIndirectParticipant(indirectParticipantCreationRequestDTO));
    }

    @Test
    void shouldUpdateIndirectParticipantWhenInformationIsValid() {
        Optional<ParticipantMipIndirectEntity> response = createParticipantMipIndirectEntityMock();
        IndirectParticipantUpdateRequestDTO indirectParticipantUpdateRequestMock =
            createIndirectParticipantUpdateRequestMock();

        when(indirectParticipantUpdateService.updateIndirectParticipant(anyInt(), any()))
            .thenReturn(response.orElseThrow());

        IndirectParticipantUpdateResponseDTO indirectParticipantUpdateResponseDTO =
            indirectParticipantApplicationUIService
                .updateIndirectParticipant(ISPB, createIndirectParticipantUpdateRequestMock());

        assertNotNull(indirectParticipantUpdateResponseDTO.getStatus());
        assertEquals(indirectParticipantUpdateResponseDTO.getStatus(),
            indirectParticipantUpdateRequestMock.getStatus());
    }

    @Test
    void shouldNotUpdateIndirectParticipantWhenInformationIsInvalid() {
        IndirectParticipantUpdateRequestDTO indirectParticipantUpdateRequestDTO =
            createIndirectParticipantUpdateRequestMock();
        indirectParticipantUpdateRequestDTO.setContractInitDate(CONTRACT_INIT_DATE_BIGGER_THAN_END_DATE);

        assertThrows(BusinessException.class, () -> indirectParticipantApplicationUIService
            .updateIndirectParticipant(ISPB, indirectParticipantUpdateRequestDTO));
    }

    @Test
    void shouldReturnCompleteIndirectParticipantInfoWhenInformValidIspb() {
        IndirectParticipantUIDTO indirectParticipantDTO = createIndirectParticipantMock();
        indirectParticipantDTO.setTaxId("79.610.132/0001-95");
        indirectParticipantDTO.setAccountNumber("444555");
        indirectParticipantDTO.setBranch("0123");
        indirectParticipantDTO.setManagerialAccountEnabled(false);

        ParticipantMipIndirectEntity participantMipIndirectEntity = createParticipantMipIndirectEntityMock().orElseThrow();
        participantMipIndirectEntity.setParticipantMip(ParticipantMipIndirectDataSetUtil.createParticipantMip(ISPB));
        participantMipIndirectEntity.setContacts(List.of(ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectContactsEntity(participantMipIndirectEntity)));
        when(indirectParticipantInformationRetriever.findIndirectParticipantCompleteInformation(ISPB)).thenReturn(participantMipIndirectEntity);

        IndirectParticipantUIDTO result = indirectParticipantApplicationUIService.findIndirectCompleteInfo(ISPB);

        assertEquals(result, indirectParticipantDTO);
    }

    @Test
    void shouldReturnIndirectParticipantsSummaryInfoWhenInformValidFilters() {
        Pageable page = PageRequest.of(CURRENT_PAGE, PAGE_SIZE);

        IndirectParticipantIdentificationUIDTO indirectParticipantDTO = createIndirectParticipantIdentificationUIMock();
        indirectParticipantDTO.setStatus(IndirectParticipantStatusDTO.WAITING_TO_SEND_REGISTRATION_TO_CLEARING);

        PageableIndirectParticipantResponseDTO response = createPageableWithoutContentMock();
        response.setContent(List.of(indirectParticipantDTO));

        ParticipantMipIndirectEntity participantMipIndirect = createParticipantMipIndirectEntityMock().orElseThrow();
        participantMipIndirect.setParticipantMip(ParticipantMipIndirectDataSetUtil.createParticipantMip(ISPB));
        Page<ParticipantMipIndirectEntity> pageEntity = new PageImpl<>(List.of(participantMipIndirect), page,
            TOTAL_ELEMENTS);

        doReturn(pageEntity).when(indirectParticipantInformationRetriever).findIndirectParticipantSummaryInfo(any(), any(), any(), any(), any(), any(), any(),
            any());

        PageableIndirectParticipantResponseDTO result = indirectParticipantApplicationUIService
            .findIndirectParticipant(PAGE_SIZE,
                PAGE_NUMBER,
                null,
                null,
                ISPB,
                null,
                null,
                null,
                null,
                null, true);

        assertEquals(result.getContent(), response.getContent());
    }

    @Test
    void shouldFindIndirectPossibleActions() {
        final ParticipantMipIndirectStatusEntity entityToMock =
            ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectStatusEntity();

        doReturn(Optional.of(entityToMock)).when(indirectParticipantStatusService)
            .findById(eq(IndirectParticipantStatusEnum.ACTIVE.getId()));

        final IndirectParticipantPossibleActionsDTO dtoFromAppService =
            indirectParticipantApplicationUIService.findIndirectPossibleActions(IndirectParticipantStatusDTO.ACTIVE);

        verify(indirectParticipantStatusService).findById(eq(IndirectParticipantStatusEnum.ACTIVE.getId()));
        assertNotNull(dtoFromAppService);
        assertEquals(IndirectParticipantPossibleActionsDTOMapper.mapEntityToDto(entityToMock), dtoFromAppService);
    }

    @Test
    void shouldReturnIndirectParticipantHistoriesByIspb() {
        Pageable page = PageRequest.of(CURRENT_PAGE, PAGE_SIZE);
        Optional<ParticipantMipIndirectEntity> participantMipIndirectEntity = createParticipantMipIndirectEntityMock();
        ParticipantMipIndirectHistoryEntity participantMipIndirectHistory =
            createParticipantMipIndirectHistoryEntityMock(participantMipIndirectEntity.orElseThrow());
        Page<ParticipantMipIndirectHistoryEntity>
            pageHistEntity = new PageImpl<>(List.of(participantMipIndirectHistory), page,
            TOTAL_ELEMENTS);

        final IndirectParticipantHistoryDTO historyDTO = new IndirectParticipantHistoryDTO();
        historyDTO.setIndirectPreviousStatus(IndirectParticipantStatusDTO.WAITING_TO_SEND_REGISTRATION_TO_CLEARING);
        historyDTO.setEventId(participantMipIndirectHistory.getId());
        historyDTO.setHistoryDateTime(participantMipIndirectHistory.getEventDateTime());
        historyDTO.setHistoryType(IndirectParticipantHistoryEventTypeDTO.CLEARING_REGISTRATION_QUEUED_RESPONSE);

        final PageableIndirectParticipantHistoryResponseDTO response = createPageableWithoutContentByHistoryMock();
        response.setContent(List.of(historyDTO));

        when(indirectParticipantInformationRetriever.findHistory(any(), any())).thenReturn(pageHistEntity);

        PageableIndirectParticipantHistoryResponseDTO result = indirectParticipantApplicationUIService
            .findIndirectParticipantHistory(PAGE_SIZE, PAGE_NUMBER, ISPB, null, null);

        assertEquals(result.getContent(), response.getContent());
    }

    private IndirectParticipantHistoryDTO createIndirectParticipantHistoryMock() {
        IndirectParticipantHistoryDTO historyDTO = new IndirectParticipantHistoryDTO();
        historyDTO.setEventId(UUID.randomUUID());
        historyDTO.indirectPreviousStatus(IndirectParticipantStatusDTO.ACTIVE);
        historyDTO.setHistoryType(IndirectParticipantHistoryEventTypeDTO.CLEARING_REGISTRATION_QUEUED_RESPONSE);
        historyDTO.setHistoryDateTime(EVENT_DATE_TIME);

        return historyDTO;
    }

    private PageableIndirectParticipantHistoryResponseDTO createPageableWithoutContentByHistoryMock() {
        PageableIndirectParticipantHistoryResponseDTO pageableWithoutContentDTO =
            new PageableIndirectParticipantHistoryResponseDTO();
        pageableWithoutContentDTO.setNumber(PAGE_NUMBER);
        pageableWithoutContentDTO.setTotalPages(TOTAL_PAGES);
        pageableWithoutContentDTO.setSize(PAGE_SIZE);
        pageableWithoutContentDTO.setNumberOfElements(TOTAL_ELEMENTS);

        return pageableWithoutContentDTO;
    }

    private PageableIndirectParticipantResponseDTO createPageableWithoutContentMock() {
        PageableIndirectParticipantResponseDTO pageableWithoutContentDTO = new PageableIndirectParticipantResponseDTO();
        pageableWithoutContentDTO.setNumber(PAGE_NUMBER);
        pageableWithoutContentDTO.setTotalPages(TOTAL_PAGES);
        pageableWithoutContentDTO.setSize(PAGE_SIZE);
        pageableWithoutContentDTO.setNumberOfElements(TOTAL_ELEMENTS);

        return pageableWithoutContentDTO;
    }

    @NotNull
    private IndirectParticipantIdentificationUIDTO createIndirectParticipantIdentificationUIMock() {
        IndirectParticipantIdentificationUIDTO indirectParticipantDTO = new IndirectParticipantIdentificationUIDTO();
        indirectParticipantDTO.setIspb(leftPadIspb(ISPB));
        indirectParticipantDTO.setName(NAME);
        indirectParticipantDTO.setStatus(IndirectParticipantStatusEnum
            .getDtoById(ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectStatusEntity().getId()));
        indirectParticipantDTO.setTaxId(TAX_ID);
        indirectParticipantDTO.setCorporateName(CORPORATE_NAME);
        indirectParticipantDTO.setContractInitDate(CONTRACT_INIT_DATE);
        indirectParticipantDTO.setContractEndDate(CONTRACT_END_DATE);
        return indirectParticipantDTO;
    }

    private IndirectParticipantUIDTO createIndirectParticipantMock() {
        IndirectParticipantUIDTO indirectParticipant = new IndirectParticipantUIDTO();
        indirectParticipant.setStatus(IndirectParticipantStatusDTO.WAITING_TO_SEND_REGISTRATION_TO_CLEARING);
        indirectParticipant.setAccountNumber(ACCOUNT_NUMBER);
        indirectParticipant.setBranch(BRANCH);
        indirectParticipant.setContacts(createIndirectParticipantContactListMock());
        indirectParticipant.setContractEndDate(CONTRACT_END_DATE);
        indirectParticipant.setContractInitDate(CONTRACT_INIT_DATE);
        indirectParticipant.setCorporateName(CORPORATE_NAME);
        indirectParticipant.setIspb(leftPadIspb(ISPB));
        indirectParticipant.setFinancial(createIndirectParticipantFinancialFieldsMock());
        indirectParticipant.setName(NAME);
        indirectParticipant.setTaxId(TAX_ID);
        return indirectParticipant;
    }

    @Test
    void shouldNotRegisterIndirectParticipantWhenInformationIsInvalid() {
        when(indirectParticipantInformationRetriever.findAllIndirectParticipantsAccordingFilters(ISPB, false,
            true))
            .thenReturn(new ArrayList<>());

        assertThrows(BusinessException.class, ()-> indirectParticipantApplicationUIService
            .registerIndirectParticipant(ISPB));
    }

    @Test
    void shouldRegisterIndirectParticipantWhenInformationIsValid() {
        Optional<ParticipantMipIndirectEntity> entity = createParticipantMipIndirectEntityMock();
        IndirectParticipantRegisterEvent event = createIndirectParticipantRegisterEventMock(entity);
        when(indirectParticipantInformationRetriever.findAllIndirectParticipantsAccordingFilters(ISPB, false,
            true)).thenReturn(List.of(entity.get()));
        when(indirectParticipantRegistryService.registerIndirectParticipant(any())).thenReturn(event);
        IndirectParticipantRegistrationResponseDTO response =
            indirectParticipantApplicationUIService.registerIndirectParticipant(ISPB);
        assertNotNull(response);
    }

    private IndirectParticipantRegisterEvent createIndirectParticipantRegisterEventMock(Optional<ParticipantMipIndirectEntity> entity) {
        ParticipantMipIndirectHistoryEntity participantMipIndirectHistoryEntity =
            createParticipantMipIndirectHistoryEntityMock(entity.get());
        IndirectParticipantRegisterEventSpecificationDTO indirectParticipantRegisterEventSpecificationDTO =
            new IndirectParticipantRegisterEventSpecificationDTO(participantMipIndirectHistoryEntity);

        IndirectParticipantRegisterEvent indirectParticipantRegisterEvent =
            new IndirectParticipantRegisterEvent(indirectParticipantRegisterEventSpecificationDTO);

        indirectParticipantRegisterEvent.getEventEntity().relateToNewHistory(participantMipIndirectHistoryEntity);
        return indirectParticipantRegisterEvent;
    }

    private IndirectParticipantCreationRequestDTO createIndirectParticipantCreationRequestMock() {
        IndirectParticipantCreationRequestDTO indirectParticipant = new IndirectParticipantCreationRequestDTO();
        indirectParticipant.setStatus(IndirectParticipantStatusDTO.WAITING_TO_SEND_REGISTRATION_TO_CLEARING);
        indirectParticipant.setAccountNumber(ACCOUNT_NUMBER);
        indirectParticipant.setBranch(BRANCH);
        indirectParticipant.setContacts(createIndirectParticipantContactListMock());
        indirectParticipant.setContractEndDate(CONTRACT_END_DATE);
        indirectParticipant.setContractInitDate(CONTRACT_INIT_DATE);
        indirectParticipant.setCorporateName(CORPORATE_NAME);
        indirectParticipant.setIspb(IspbUtils.leftPadIspb(ISPB));
        indirectParticipant.setFinancial(createIndirectParticipantFinancialFieldsMock());
        indirectParticipant.setName(NAME);
        indirectParticipant.setTaxId(TAX_ID);
        return indirectParticipant;
    }

    private ParticipantMipIndirectHistoryEntity createParticipantMipIndirectHistoryEntityMock(
        ParticipantMipIndirectEntity participantMipIndirectEntity) {
        ParticipantMipIndirectHistoryEntity historyEntity = indirectParticipantHistoryService
            .createHistoryEntityByType(participantMipIndirectEntity,
                ParticipantMipIndirectHistoryEntity.Type.CLEARING_REGISTRATION_QUEUED_RESPONSE);
        historyEntity.setPreviousStatus(createParticipantMipIndirectStatusEntityMock());
        return historyEntity;
    }

    private Optional<ParticipantMipIndirectEntity> createParticipantMipIndirectEntityMock() {
        ParticipantMipIndirectEntity participantMipIndirectEntity = ReflectionTestUtils
            .invokeMethod(indirectParticipantMipService, "createIndirectParticipantEntityFromDTO",
                createIndirectParticipantCreationRequestMock());

        participantMipIndirectEntity.setStatus(createParticipantMipIndirectStatusEntityMock());
        return Optional.ofNullable(participantMipIndirectEntity);
    }

    private IndirectParticipantUpdateResponseDTO createIndirectParticipantUpdateResponseDTOMock() {
        IndirectParticipantUpdateResponseDTO response = new IndirectParticipantUpdateResponseDTO();
        response.setStatus(IndirectParticipantStatusDTO.WAITING_TO_SEND_REGISTRATION_TO_CLEARING);
        return response;
    }

    private IndirectParticipantCreationResponseDTO createIndirectParticipantCreationResponseDTOMock() {
        IndirectParticipantCreationResponseDTO response = new IndirectParticipantCreationResponseDTO();
        response.setStatus(IndirectParticipantStatusDTO.WAITING_TO_SEND_REGISTRATION_TO_CLEARING);
        return response;
    }

    private ParticipantMipIndirectStatusEntity createParticipantMipIndirectStatusEntityMock() {
        ParticipantMipIndirectStatusEntity status = new ParticipantMipIndirectStatusEntity();
        ReflectionTestUtils.setField(status, "id", 6);
        ReflectionTestUtils.setField(status, "status", "Waiting to send registration to Clearing");
        ReflectionTestUtils.setField(status, "isActive", true);
        ReflectionTestUtils.setField(status, "allowsClearingRegistry", true);
        return status;
    }

    private IndirectParticipantUpdateRequestDTO createIndirectParticipantUpdateRequestMock() {
        IndirectParticipantUpdateRequestDTO indirectParticipant = new IndirectParticipantUpdateRequestDTO();
        indirectParticipant.setStatus(IndirectParticipantStatusDTO.WAITING_TO_SEND_REGISTRATION_TO_CLEARING);
        indirectParticipant.setAccountNumber(ACCOUNT_NUMBER);
        indirectParticipant.setBranch(BRANCH);
        indirectParticipant.setContacts(createIndirectParticipantContactListMock());
        indirectParticipant.setContractEndDate(CONTRACT_END_DATE);
        indirectParticipant.setContractInitDate(CONTRACT_INIT_DATE);
        indirectParticipant.setCorporateName(CORPORATE_NAME);
        indirectParticipant.setIspb(IspbUtils.leftPadIspb(ISPB));
        indirectParticipant.setFinancial(createIndirectParticipantFinancialFieldsMock());
        indirectParticipant.setName(NAME);
        indirectParticipant.setTaxId(TAX_ID);
        return indirectParticipant;
    }

    private IndirectParticipantFinancialFieldsUIDTO createIndirectParticipantFinancialFieldsMock() {
        IndirectParticipantFinancialFieldsUIDTO indirectParticipantFinancialFields =
            new IndirectParticipantFinancialFieldsUIDTO();
        indirectParticipantFinancialFields.setBalanceLowerThreshold(new BigDecimal("1002430.57"));
        indirectParticipantFinancialFields.setDebitTransactionType(12);
        indirectParticipantFinancialFields.setCredTransactionType(344);
        indirectParticipantFinancialFields.setQrcodeCredTransactionType(9875);
        indirectParticipantFinancialFields.setDrawbackReceiveTransactType(77);
        indirectParticipantFinancialFields.setDrawbackSentTransactType(11);
        indirectParticipantFinancialFields.setBalanceValidationThreshold(true);
        return indirectParticipantFinancialFields;
    }

    private List<IndirectParticipantContactDTO> createIndirectParticipantContactListMock() {
        List<IndirectParticipantContactDTO> indirectParticipantContactList = new ArrayList<>();
        IndirectParticipantContactDTO indirectParticipantContact = new IndirectParticipantContactDTO();
        indirectParticipantContact.setDepartment("Department");
        indirectParticipantContact.setEmail("email@provider.domain");
        indirectParticipantContact.setName("Contact");
        indirectParticipantContact.setPhone("+55(11)9-9876-5432");
        indirectParticipantContactList.add(indirectParticipantContact);
        return indirectParticipantContactList;
    }

    @Test
    void shouldThrowExceptionWhenHasNotDataToFindIndirectPossibleActions() {
        doReturn(Optional.empty()).when(indirectParticipantStatusService)
            .findById(eq(IndirectParticipantStatusEnum.ACTIVE.getId()));

        final EntityNotFoundException entityNotFoundException = assertThrows(EntityNotFoundException.class,
            () -> indirectParticipantApplicationUIService
                .findIndirectPossibleActions(IndirectParticipantStatusDTO.ACTIVE));

        assertEquals(ExceptionMessages.SPI_IND_010.getCode(), entityNotFoundException.getCode());
        verify(indirectParticipantStatusService).findById(eq(IndirectParticipantStatusEnum.ACTIVE.getId()));
    }

    @Test
    void shouldCreateIndirectParticipantRescission() {
        final ParticipantMipEntity participantMip = ParticipantMipIndirectDataSetUtil.createParticipantMip();
        final ParticipantMipIndirectEntity participantMipIndirectEntity = ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(
                ParticipantMipIndirectDataSetUtil.getMockedStatusRepoReturningActiveById(), participantMip);
        final ParticipantMipIndirectHistoryEntity participantMipIndirectHistoryEntity =
            new ParticipantMipIndirectHistoryEntity();
        participantMipIndirectHistoryEntity.setParticipantMip(participantMipIndirectEntity);

        final EventStatusEntity eventStatusEntity = new EventStatusEntity();
        eventStatusEntity.setCode(IndirectParticipantStatusEnum.DEREGISTRATION_SENT_TO_CLEARING.getId());

        final IndirectParticipantRescissionEventEntity eventEntity = new IndirectParticipantRescissionEventEntity();
        eventEntity.setStatus(eventStatusEntity);
        eventEntity.relateToNewHistory(participantMipIndirectHistoryEntity);

        final IndirectParticipantRescissionEvent event = new IndirectParticipantRescissionEvent(
            new IndirectParticipantRescissionEventSpecificationDTO(participantMipIndirectHistoryEntity));

        event.getEventEntity().relateToNewHistory(participantMipIndirectHistoryEntity);

        when(indirectParticipantInformationRetriever
            .findAllIndirectParticipantsAccordingFilters(ParticipantMipIndirectDataSetUtil.ISPB, Boolean.TRUE,
                true))
            .thenReturn(List.of(participantMipIndirectEntity));

        when(indirectParticipantRescissionService.createRescissionRequest(eq(participantMipIndirectEntity)))
            .thenReturn(event);

        final IndirectParticipantRescissionResponseDTO dto = indirectParticipantApplicationUIService
            .createIndirectParticipantRescissionRequest(ParticipantMipIndirectDataSetUtil.ISPB);

        verify(indirectParticipantRescissionValidator).validateIndirectParticipantRescission(any());

        assertEquals(IndirectParticipantRescissionResponseDTOMapper.mapEntityToDto(event.filterLastHistoryFromEntity().get()), dto);
    }

    @Test
    void shouldThrowEntityNotFoundExceptionCreateIndirectParticipantRescission() {
        when(indirectParticipantInformationRetriever
            .findAllIndirectParticipantsAccordingFilters(ParticipantMipIndirectDataSetUtil.ISPB, true,
                true))
            .thenReturn(Lists.emptyList());

        final BusinessException entityNotFoundException = assertThrows(BusinessException.class,
            () -> indirectParticipantApplicationUIService
                .createIndirectParticipantRescissionRequest(ParticipantMipIndirectDataSetUtil.ISPB));

        assertEquals(ExceptionMessages.SPI_IND_001.getCode(), entityNotFoundException.getCode());
    }

    @Test
    void shouldThrowInvalidOperationDueToCurrentStatusExceptionCreateIndirectParticipantRescission() {
        final ParticipantMipEntity participantMip = ParticipantMipIndirectDataSetUtil.createParticipantMip();
        final ParticipantMipIndirectEntity participantMipIndirectEntity = ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(
                ParticipantMipIndirectDataSetUtil.getMockedStatusRepoReturningActiveById(), participantMip);

        participantMipIndirectEntity
            .setStatus(ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectStatusEntity(false));

        when(indirectParticipantInformationRetriever
            .findAllIndirectParticipantsAccordingFilters(ParticipantMipIndirectDataSetUtil.ISPB, true,
                true))
            .thenReturn(List.of(participantMipIndirectEntity));

        final BusinessException invalidOperationDueToCurrentStatusException =
            assertThrows(BusinessException.class,
                () -> indirectParticipantApplicationUIService
                    .createIndirectParticipantRescissionRequest(ParticipantMipIndirectDataSetUtil.ISPB));

        assertEquals(ExceptionMessages.SPI_IND_006.getCode(), invalidOperationDueToCurrentStatusException.getCode());
    }

    @Test
    void shouldCallCancelIndirectParticipant() {
        Optional<ParticipantMipIndirectEntity> participantMipIndirectEntityMock =
            createParticipantMipIndirectEntityMock();

        when(indirectParticipantCancelmentService.cancelIndirectParticipant(anyInt()))
            .thenReturn(participantMipIndirectEntityMock.orElseThrow());

        IndirectParticipantCancelmentResponseDTO responseDTO =
            indirectParticipantApplicationUIService
                .cancelIndirectParticipant(ISPB);

        verify(indirectParticipantCancelmentService).cancelIndirectParticipant(anyInt());
    }

}
