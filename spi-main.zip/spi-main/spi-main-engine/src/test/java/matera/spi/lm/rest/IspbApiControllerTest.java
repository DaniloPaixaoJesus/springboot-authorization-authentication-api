package matera.spi.lm.rest;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.IspbQueryDTO;
import matera.spi.dto.IspbQueryListResponseDTO;
import matera.spi.indirect.domain.model.ParticipantMipIndirectEntity;
import matera.spi.indirect.persistence.ParticipantMipIndirectRepository;
import matera.spi.indirect.persistence.ParticipantMipIndirectStatusRepository;
import matera.spi.indirect.util.ParticipantMipIndirectDataSetUtil;
import matera.spi.main.domain.model.ParticipantMipEntity;
import matera.spi.main.domain.service.ConfigurationService;
import matera.spi.main.persistence.ParticipantMipRepository;

import io.restassured.RestAssured;
import org.eclipse.jetty.http.HttpStatus;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;

import java.util.List;

import static matera.spi.indirect.util.ParticipantMipIndirectDataSetUtil.createParticipantMip;

import static org.junit.jupiter.api.Assertions.*;

@IntegrationTest
public class IspbApiControllerTest {

    private static final String ISPB_BASE_URI = "/ui/v1/ispb/query";

    @LocalServerPort
    private int port;

    @Autowired
    private ConfigurationService configurationService;

    @Autowired
    private ParticipantMipRepository participantMipRepository;

    @Autowired
    private ParticipantMipIndirectRepository participantMipIndirectRepository;

    @Autowired
    private ParticipantMipIndirectStatusRepository participantMipIndirectStatusRepository;

    @BeforeEach
    void beforeEach() {
        RestAssured.port = port;
    }

    @Test
    void givenIndirectParticipantThenShouldReturnListThatContainOnlyNameAndIspbFromSearchedBank() {
        final IspbQueryListResponseDTO ispbListResponse =
            RestAssured.given()
                .when().get(ISPB_BASE_URI)
                .then()
                .statusCode(HttpStatus.OK_200)
                .extract()
                .as(IspbQueryListResponseDTO.class);

        assertNotNull(ispbListResponse);

        List<IspbQueryDTO> ispbList = ispbListResponse.getData();
        assertEquals(2, ispbList.size());
    }

    @Test
    void givenDirectParticipantThenShouldReturnListThatContainDirectAndIndirectParticipantsFromSearchedBank() {
        ParticipantMipEntity participantMip = createParticipantMip();
        ParticipantMipIndirectEntity participantMipIndirectEntity =
            ParticipantMipIndirectDataSetUtil
                .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository, participantMip);

        participantMipIndirectRepository.saveAndFlush(participantMipIndirectEntity);

        final IspbQueryListResponseDTO ispbListResponse =
            RestAssured.given()
                .when().get(ISPB_BASE_URI)
                .then()
                .statusCode(HttpStatus.OK_200)
                .extract()
                .as(IspbQueryListResponseDTO.class);

        assertNotNull(ispbListResponse);

        List<IspbQueryDTO> ispbList = ispbListResponse.getData();
        assertEquals(2, ispbList.size());
    }
}
