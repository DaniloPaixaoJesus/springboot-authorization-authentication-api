package matera.spi.lm.domain.service.messages.factory.camt060;

import matera.spi.main.apisInterface.ConfigurationApiService;
import matera.spi.main.apisInterface.MessageIdApiService;
import matera.spi.main.domain.model.ConfigEntity;
import matera.spi.main.messages.schema.generated.camt060.GroupHeader77;
import matera.spi.main.messages.schema.generated.camt060.ReportingRequest5;
import matera.spi.main.messages.schema.generated.camt060.ReqdMsgNmIdType;
import matera.spi.main.messages.schema.generated.camt060.SPIEnvelopeMessage;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.datatype.XMLGregorianCalendar;

import static matera.spi.utils.IspbUtils.leftPadIspb;
import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static matera.spi.utils.GregorianCalendarUtils.getXmlGregorianCalendarFrom;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import static java.lang.String.format;

@ExtendWith(MockitoExtension.class)
public class Camt060FactoryTest {

    private static final String EXPECTED_VERSION = "camt.060/1.3";
    private static final String MESSAGE_ID = "M00673146e270dae3af1c410caf9bfaa";
    private static final LocalDate LOCALDATE = LocalDate.of(2020, 2, 3);
    private static final XMLGregorianCalendar XML_GREGORIAN_CALENDAR = getXmlGregorianCalendarFrom(LOCALDATE);

    private static final String CAMT_060_SOLICITACAO_LANCAMENTO_XML = "camt.060/camt.060-solicitacao-lancamento.xml";
    private static final String EXPECTED_CAMT_060_XML = getStringFromXmlFile(CAMT_060_SOLICITACAO_LANCAMENTO_XML);

    @InjectMocks
    private Camt060Factory camt060Factory;

    @Mock
    private MessageIdApiService messageIdApiService;

    @Mock
    private ConfigurationApiService configurationApiService;

    @Test
    void shouldGenerateCamt060AsExpected() {
        when(configurationApiService.getIspbDirectPsp()).thenReturn(createIspb());
        Camt060SpecificationDTO camt060SpecificationDTO = Camt060SpecificationDTO
            .builder()
            .identification("E9999901012341234123412345678900")
            .messageId("M9999901012345678901234567890123")
            .type(ReqdMsgNmIdType.CAMT_054)
            .build();

        final String actualCamt060Xml = camt060Factory.createXml(camt060SpecificationDTO);

        Assertions.assertNotNull(actualCamt060Xml);
        Assertions.assertTrue(actualCamt060Xml.contains(EXPECTED_VERSION));
        Assertions.assertEquals(getContentByTag("Id", EXPECTED_CAMT_060_XML), getContentByTag("Id", actualCamt060Xml));
        Assertions.assertEquals(getContentByTag("MsgId", EXPECTED_CAMT_060_XML), getContentByTag("MsgId", actualCamt060Xml));
        Assertions.assertEquals(getContentByTag("MmbId", EXPECTED_CAMT_060_XML), getContentByTag("MmbId", actualCamt060Xml));
    }

    private String getContentByTag(String tag, String camt060Xml) {
        final Matcher matcher = Pattern
            .compile(format("<%s>(.*)</%s>", tag, tag))
            .matcher(camt060Xml);;


        if (matcher.find()) {
            return matcher.group(0);
        }

        return null;
    }

    @Test
    void shouldThrownExceptionIfDateAndIdentificationIsSetTogether() {
        Camt060SpecificationDTO identificationDto = Camt060SpecificationDTO.builder()
                                                                           .date(LOCALDATE)
                                                                           .identification("Identification")
                                                                           .build();

        assertThrows(IllegalStateException.class, () -> camt060Factory.buildEnvelopeFromDto(identificationDto));
    }

    @Test
    void shouldThrownExceptionIfTypeAndIdentificationIsSetTogether() {
        ReqdMsgNmIdType reqdMsgNmIdType = ReqdMsgNmIdType.fromValue(ReqdMsgNmIdType.CAMT_052.value());
        Camt060SpecificationDTO identificationDto = Camt060SpecificationDTO.builder()
                                                                           .type(reqdMsgNmIdType)
                                                                           .identification("Identification")
                                                                           .build();

        assertThrows(IllegalStateException.class, () -> camt060Factory.buildEnvelopeFromDto(identificationDto));
    }

    @Test
    void shouldNotThrownExceptionIfDateAndTypeIsSetTogether() {
        when(configurationApiService.getIspbDirectPsp()).thenReturn(createIspb());
        ReqdMsgNmIdType reqdMsgNmIdType = ReqdMsgNmIdType.fromValue(ReqdMsgNmIdType.CAMT_052.value());
        Camt060SpecificationDTO identificationDto = Camt060SpecificationDTO.builder().type(reqdMsgNmIdType).date(LOCALDATE).build();

        assertDoesNotThrow(() -> camt060Factory.buildEnvelopeFromDto(identificationDto));
    }

    @Test
    void shouldFillXmlWithIdentification() {
        when(configurationApiService.getIspbDirectPsp()).thenReturn(createIspb());

        Camt060SpecificationDTO identificationDto = Camt060SpecificationDTO
            .builder()
            .identification("Identification")
            .messageId(MESSAGE_ID)
            .build();
        SPIEnvelopeMessage spiEnvelopeMessage = camt060Factory.buildEnvelopeFromDto(identificationDto);

        GroupHeader77 grpHdr = getGrpHdr(spiEnvelopeMessage);
        ReportingRequest5 rptgReq = getRptgReq(spiEnvelopeMessage);

        assertThat(spiEnvelopeMessage, is(not(nullValue())));
        assertThat(grpHdr.getMsgId(), is(MESSAGE_ID));
        assertThat(grpHdr.getCreDtTm(), is(not(nullValue())));
        assertThat(rptgReq.getReqdMsgNmId(), is(nullValue()));
        assertThat(rptgReq.getId(), is("Identification"));
        assertThat(rptgReq.getAcctOwnr().getAgt().getFinInstnId().getClrSysMmbId().getMmbId(), is(leftPadIspb("123")));
    }

    @Test
    void shouldFillXmlWithDate() {
        when(configurationApiService.getIspbDirectPsp()).thenReturn(createIspb());

        ReqdMsgNmIdType reqdMsgNmIdType = ReqdMsgNmIdType.fromValue(ReqdMsgNmIdType.CAMT_052.value());
        Camt060SpecificationDTO identificationDto = Camt060SpecificationDTO.builder()
            .date(LOCALDATE)
            .type(reqdMsgNmIdType)
            .messageId(MESSAGE_ID)
            .build();

        SPIEnvelopeMessage spiEnvelopeMessage = camt060Factory.buildEnvelopeFromDto(identificationDto);

        GroupHeader77 grpHdr = getGrpHdr(spiEnvelopeMessage);
        ReportingRequest5 rptgReq = getRptgReq(spiEnvelopeMessage);

        assertThat(spiEnvelopeMessage, is(not(nullValue())));
        assertThat(grpHdr.getMsgId(), is(MESSAGE_ID));
        assertThat(grpHdr.getCreDtTm(), is(not(nullValue())));
        assertThat(rptgReq.getReqdMsgNmId().value(), is(reqdMsgNmIdType.value()));
        assertThat(rptgReq.getRptgPrd(), is(not(nullValue())));
        assertThat(rptgReq.getId(), is(nullValue()));
        assertThat(rptgReq.getRptgPrd().getFrToDt().getFrDt(), is(XML_GREGORIAN_CALENDAR));
        assertThat(rptgReq.getAcctOwnr().getAgt().getFinInstnId().getClrSysMmbId().getMmbId(), is(leftPadIspb("123")));
    }

    private String createIspb() {
        return "123";
    }

    private ReportingRequest5 getRptgReq(SPIEnvelopeMessage spiEnvelopeMessage) {
        return spiEnvelopeMessage.getDocument().getAcctRptgReq().getRptgReq();
    }

    private GroupHeader77 getGrpHdr(SPIEnvelopeMessage spiEnvelopeMessage) {
        return spiEnvelopeMessage.getDocument().getAcctRptgReq().getGrpHdr();
    }

}
