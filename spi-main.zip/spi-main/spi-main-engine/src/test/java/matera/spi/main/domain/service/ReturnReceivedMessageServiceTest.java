package matera.spi.main.domain.service;

import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.domain.model.account.PayerAccountEntity;
import matera.spi.main.domain.model.account.ReceiverAccount;
import matera.spi.main.domain.model.account.ReceiverAccountEntity;
import matera.spi.main.domain.model.event.transaction.PaymentEventEntity;
import matera.spi.main.domain.model.event.transaction.ReturnReceivedEventEntity;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.domain.model.message.MessageTypeEntity;
import matera.spi.main.domain.model.transaction.ReturnReceivedEntity;
import matera.spi.main.domain.model.transaction.TransactionPriorityEntity;
import matera.spi.main.dto.event.EventSpecificationFromReceivedMessageDTO;
import matera.spi.main.persistence.PaymentEventRepository;
import matera.spi.utils.DocumentUtils;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ReturnReceivedMessageServiceTest {

    private static final String CORRELATION_ID = "D99999010202004071047433f7f98372";
    private static final String ORIGINAL_END_TO_END_ID = "E9999901020200407104757c757114fe";
    private static final String PACS_004_SPI_1_1_MSG_XML = "pacs.004/pacs.004.spi.1.1_msg.xml";
    private static final String REPLY_ELEMENT = "/Envelope/Document/PmtRtr/TxInf";
    public static final int PAYER_ISPB = 99999010;
    public static final int RECEIVER_ISPB = 59979010;

    @Mock
    private ParticipantService participantService;

    @Mock
    private MessageTypeService messageTypeService;

    @Mock
    private PaymentEventRepository paymentEventRepository;

    @Mock
    private PaymentEventEntity originalEventEntityMock;

    @Mock
    private PayerAccountEntity payerAccountEntityMock;

    @Mock
    private ReceiverAccountEntity receiverAccountEntityMock;

    @Mock
    private TransactionPriorityService transactionPriorityService;

    @InjectMocks
    private ReturnReceivedMessageService returnReceivedMessageService;

    @BeforeEach
    void setUp() {
        when(participantService.findByIspb(PAYER_ISPB)).thenReturn(buildParticipantMock(PAYER_ISPB));
        when(participantService.findByIspb(RECEIVER_ISPB)).thenReturn(buildParticipantMock(RECEIVER_ISPB));
        when(paymentEventRepository.findByCorrelationId(eq(ORIGINAL_END_TO_END_ID)))
            .thenReturn(Optional.of(originalEventEntityMock));

        when(originalEventEntityMock.getReceiverAccount()).thenReturn(receiverAccountEntityMock);
        when(originalEventEntityMock.getPayerAccount()).thenReturn(payerAccountEntityMock);

        when(transactionPriorityService.getPriorityByCode(any())).thenReturn(new TransactionPriorityEntity());
    }

    @Test
    void shouldFillAllAttributed() {
        String xmlPacs004 = getStringFromXmlFile(PACS_004_SPI_1_1_MSG_XML);
        Document documentPacs004 = DocumentUtils.stringToXmlDocument(xmlPacs004);
        Node specificElement = getSpecificElement(documentPacs004);
        ReturnReceivedEventEntity returnReceivedEventEntity = new ReturnReceivedEventEntity();
        returnReceivedEventEntity.setCorrelationId(CORRELATION_ID);
        MessageEntity messageEntity = new MessageEntity();
        messageEntity.setMessageTypeEntity(new MessageTypeEntity());

        EventSpecificationFromReceivedMessageDTO eventSpecificationFromReceivedMessageDTO = EventSpecificationFromReceivedMessageDTO.builder()
            .messageEntity(messageEntity)
            .specificElement(specificElement)
            .document(documentPacs004)
            .build();

        returnReceivedMessageService.fillAllAttributes(returnReceivedEventEntity, eventSpecificationFromReceivedMessageDTO);
        ReturnReceivedEntity returnReceivedEntity = returnReceivedEventEntity.getReturnReceivedEntity();
        assertThat(returnReceivedEntity).isNotNull();

        assertThat(returnReceivedEntity.getEvent()).isEqualTo(returnReceivedEventEntity);
        assertThat(returnReceivedEntity.getPayerParticipant().getIspb()).isEqualTo(PAYER_ISPB);
        assertThat(returnReceivedEntity.getReceiverParticipant().getIspb()).isEqualTo(RECEIVER_ISPB);
        assertThat(returnReceivedEntity.getEndToEndId()).isEqualTo(CORRELATION_ID);
        assertThat(returnReceivedEntity.getAdditionalInformation()).isEqualTo("Additional information");
        assertThat(returnReceivedEntity.getChargeBearer()).isEqualTo("SLEV");
        assertThat(returnReceivedEntity.getCustomerInitTimestampUtc()).isEqualTo(
            LocalDateTime.parse("2020-04-07T13:47:22.528Z", DateTimeFormatter.ISO_DATE_TIME));
        assertThat(returnReceivedEntity.getSettlementMethod()).isEqualTo("CLRG");
        assertThat(returnReceivedEntity.getEvent().getValue()).isEqualTo("4551.87");
        assertThat(returnReceivedEntity.getReturnReasonInformationCode()).isEqualTo("UPAY");


        assertThat(returnReceivedEventEntity.getOriginalEvent()).isEqualTo(originalEventEntityMock);
    }

    private static Node getSpecificElement(Document document) {
        NodeList nodeList = DocumentUtils.getElementsByExpression(document, REPLY_ELEMENT);
        return nodeList.item(0);
    }

    private Optional<ParticipantEntity> buildParticipantMock(Integer ispb) {
        ParticipantEntity participantEntity = new ParticipantEntity();
        participantEntity.setIspb(ispb);

        return Optional.of(participantEntity);
    }
}
