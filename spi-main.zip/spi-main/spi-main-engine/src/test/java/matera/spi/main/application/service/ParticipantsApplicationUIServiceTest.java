package matera.spi.main.application.service;

import matera.spi.dto.PaymentServiceProviderQueryResponseWapperDataDTO;
import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.domain.service.ParticipantService;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@ExtendWith(MockitoExtension.class)
class ParticipantsApplicationUIServiceTest {

    public static final Integer ISPB_BAR = 123;
    public static final Integer ISPB_FOO = 456;
    public static final String NAME_BAR = "BAR";
    public static final String NAME_FOO = "FOO";

    @Mock
    private ParticipantService participantService;

    @InjectMocks
    private ParticipantsApplicationUIService participantsApplicationUIService;

    @Test
    void shouldTransformParticipantListToPaymentServiceProviderQueryResponseWapperDataDTO() {
        Mockito.when(participantService.findAllParticipant()).thenReturn(participantsEntityMock());

        PaymentServiceProviderQueryResponseWapperDataDTO responseWapperDataDTO = participantsApplicationUIService.getAllParticipant(
            null);

        Assertions.assertNotNull(responseWapperDataDTO);
    }

    private List<ParticipantEntity> participantsEntityMock() {
        var participants = new ArrayList<ParticipantEntity>();
        participants.addAll(Arrays.asList(participantEntityMock(ISPB_BAR, NAME_BAR, true), participantEntityMock(ISPB_FOO, NAME_FOO, false)));
        return participants;
    }

    private ParticipantEntity participantEntityMock(Integer ispb, String name, Boolean active) {
        var participantEntity = new ParticipantEntity();
        participantEntity.setIspb(ispb);
        participantEntity.setName(name);
        participantEntity.setActive(active);
        return participantEntity;
    }

}
