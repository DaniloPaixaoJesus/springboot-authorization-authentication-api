package matera.spi.main.domain.service;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.PmtApprovalConfigEntity;
import matera.spi.main.persistence.PmtApprovalConfigRepository;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;

@IntegrationTest
class PmtApprovalConfigServiceTest  {

    @Autowired
    private PmtApprovalConfigRepository pmtApprovalConfigRepository;

    @Autowired
    private PmtApprovalConfigService pmtApprovalConfigService;

    @AfterEach
    void clearDatabase() { pmtApprovalConfigRepository.deleteAll(); }


    @Test
    void testFindByPaymentOrigin() {
        // Given

        var paymentOrigin = "paymentOrigin";

        var pmtApprovalConfigEntity = new PmtApprovalConfigEntity();
        pmtApprovalConfigEntity.setPaymentOrigin(paymentOrigin);
        pmtApprovalConfigEntity.setPaymentValue(new BigDecimal("0.00"));
        var expected = Optional.of(pmtApprovalConfigEntity);

        // When

        pmtApprovalConfigRepository.save(pmtApprovalConfigEntity);

        var actual = pmtApprovalConfigService.findByPaymentOrigin(paymentOrigin);

        // Then
        assertEquals(expected, actual);
    }

    @Test
    void testSave() {

        //Given

        var paymentOrigin = "paymentOrigin";

        var pmtApprovalConfigEntity = new PmtApprovalConfigEntity();
        pmtApprovalConfigEntity.setPaymentOrigin(paymentOrigin);
        pmtApprovalConfigEntity.setPaymentValue(new BigDecimal("0.00"));
        var expected = Optional.of(pmtApprovalConfigEntity);

        // When

        pmtApprovalConfigService.save(pmtApprovalConfigEntity);

        var actual = pmtApprovalConfigRepository.findByPaymentOrigin(paymentOrigin);

        // Then
        assertEquals(expected, actual);
    }
}
