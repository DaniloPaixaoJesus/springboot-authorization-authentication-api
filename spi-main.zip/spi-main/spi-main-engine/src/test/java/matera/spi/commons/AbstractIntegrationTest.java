package matera.spi.commons;

@IntegrationTest
public abstract class AbstractIntegrationTest {

}
