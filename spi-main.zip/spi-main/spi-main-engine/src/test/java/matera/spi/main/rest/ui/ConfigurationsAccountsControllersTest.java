package matera.spi.main.rest.ui;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import matera.spi.commons.IntegrationTest;
import matera.spi.dto.ManagerialBalanceThresholdDTO;
import matera.spi.dto.ManagerialTransactionTypeDTO;
import matera.spi.dto.MirrorBalanceThresholdDTO;
import matera.spi.dto.MirrorTransactionTypeDTO;
import matera.spi.dto.PspManagerialAccountConfigUIDTO;
import matera.spi.dto.PspMirrorAccountConfigUIDTO;
import matera.spi.main.domain.model.IpAccountConfigEntity;
import matera.spi.main.domain.model.ParticipantMipEntity;
import matera.spi.main.persistence.IpAccountConfigRepository;
import matera.spi.main.persistence.ParticipantMipRepository;
import org.apache.http.HttpStatus;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;

import java.math.BigDecimal;

@IntegrationTest
public class ConfigurationsAccountsControllersTest {

    private static final String BASE_URI_MIRROR_CONFIGURATION = "/ui/v1/configuration/account/mirror";
    private static final String BASE_URI_MANAGERIAL_CONFIGURATION = "/ui/v1/configuration/account/managerial";

    @LocalServerPort
    private int port;

    @Autowired
    private IpAccountConfigRepository ipAccountconfigRepository;

    @Autowired
    private ParticipantMipRepository participantMipRepository;

    private IpAccountConfigEntity ipAccountConfigEntity;
    private ParticipantMipEntity participantMipEntity;

    @BeforeEach
    void beforeEach() {
        RestAssured.port = port;
        ipAccountConfigEntity = ipAccountconfigRepository.findAll().get(0);
        participantMipEntity = participantMipRepository.findAll().get(0);
    }

    @AfterEach
    void afterEach() {
        ipAccountconfigRepository.saveAndFlush(ipAccountConfigEntity);
        participantMipRepository.saveAndFlush(participantMipEntity);
    }

    @Test
    void shouldUpdateMirrorAccountConfig() {
        PspMirrorAccountConfigUIDTO pspMirrorAccountConfigUIDTO = buildExpectedPspMirrorAccountConfigDTO();

        RestAssured.given()
                .contentType(ContentType.JSON)
                .body(pspMirrorAccountConfigUIDTO)
                .when().post(BASE_URI_MIRROR_CONFIGURATION)
                .then()
                .log().all()
                .assertThat()
                .statusCode(HttpStatus.SC_OK);
    }

    @Test
    void shouldUpdateManagerialAccountConfig() {
        PspManagerialAccountConfigUIDTO pspManagerialAccountConfigUIDTO = buildExpectedPspManagerialAccountConfigDTO();

        RestAssured.given()
            .contentType(ContentType.JSON)
            .body(pspManagerialAccountConfigUIDTO)
            .when().post(BASE_URI_MANAGERIAL_CONFIGURATION)
            .then()
            .log().all()
            .assertThat()
            .statusCode(HttpStatus.SC_OK);
    }

    private PspManagerialAccountConfigUIDTO buildExpectedPspManagerialAccountConfigDTO() {
        final PspManagerialAccountConfigUIDTO dto = new PspManagerialAccountConfigUIDTO();
        dto.setAccount("1");
        dto.setBranch(11);
        dto.setBalanceThreshold(buildManagerialBalanceThresholdDTO());
        dto.setTransactionType(buildManagerialTransactionTypeDTO());

        return dto;
    }

    private ManagerialTransactionTypeDTO buildManagerialTransactionTypeDTO() {
        final ManagerialTransactionTypeDTO dto = new ManagerialTransactionTypeDTO();
        dto.setDebitPayment(8);
        dto.setStandardCreditReceipt(9);
        dto.setDevolutionReceived(10);
        dto.setDevolutionSent(11);
        dto.setCreditByDynamicQRCode(12);

        return dto;
    }

    private ManagerialBalanceThresholdDTO buildManagerialBalanceThresholdDTO() {
        final ManagerialBalanceThresholdDTO dto = new ManagerialBalanceThresholdDTO();
        dto.setValidatesBalanceManagerialDirectAccount(true);
        dto.setLowerLimitValidateBalance(BigDecimal.valueOf(120));

        return dto;
    }

    private PspMirrorAccountConfigUIDTO buildExpectedPspMirrorAccountConfigDTO() {
        final PspMirrorAccountConfigUIDTO dto = new PspMirrorAccountConfigUIDTO();
        dto.setAccount("123");
        dto.setBranch(11);
        dto.setTransactionType(buildMockedMirrorTransactionTypeDTO());
        dto.setBalanceThreshold(buildMockedMirrorBalanceThreshold());
        return dto;
    }

    private MirrorBalanceThresholdDTO buildMockedMirrorBalanceThreshold() {
        final MirrorBalanceThresholdDTO dto = new MirrorBalanceThresholdDTO();
        dto.setValidatesBalanceMirrorAccount(true);
        dto.setUpperLimitAutoDeposit(BigDecimal.valueOf(150));
        dto.setPercentOnUpperBalanceLimit(BigDecimal.valueOf(0.75));
        dto.setLowerLimitValidateBalance(BigDecimal.valueOf(200));
        dto.setPercentOnLowerBalanceLimit(BigDecimal.valueOf(0.25));

        return dto;
    }

    private MirrorTransactionTypeDTO buildMockedMirrorTransactionTypeDTO() {
        final MirrorTransactionTypeDTO dto = new MirrorTransactionTypeDTO();
        dto.setDebitPayment(1);
        dto.setStandardCreditReceipt(2);
        dto.setCreditByDynamicQRCode(3);
        dto.setDrawbackReceived(4);
        dto.setDrawbackSent(5);
        dto.setDeposit(6);
        dto.setWithdraw(7);
        dto.setAutoDepositLPI0006(8);
        dto.setBalanceAdjustmentCredit(9);
        dto.setBalanceAdjustmentDebit(10);

        return dto;
    }

}
