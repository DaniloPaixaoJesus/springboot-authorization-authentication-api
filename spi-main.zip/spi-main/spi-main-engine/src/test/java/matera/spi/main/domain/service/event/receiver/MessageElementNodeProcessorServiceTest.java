package matera.spi.main.domain.service.event.receiver;

import matera.spi.main.domain.model.event.transaction.PaymentEventEntity;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.domain.service.event.Event;
import matera.spi.main.domain.service.event.EventFactory;
import matera.spi.main.exception.DuplicateCorrelationIdException;
import matera.spi.main.utils.EntityCreationUtils;
import matera.spi.utils.DocumentUtils;
import matera.spi.main.dto.event.EventSpecificationFromReceivedMessageDTO;
import matera.spi.main.dto.MessageReceiverEventDTO;
import matera.spi.main.exception.CorrelationIdNotFoundException;
import matera.spi.main.persistence.EventRepository;

import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.Optional;
import java.util.stream.Stream;

import static matera.spi.main.utils.FileUtils.getDocumentFromXmlFile;
import static matera.spi.utils.DocumentUtils.stringToXmlDocument;
import static matera.spi.main.utils.EntityCreationUtils.*;
import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class MessageElementNodeProcessorServiceTest {

	private static final String PACS_008_SPI_1_2_CONTA_10_MSG = "pacs.008/pacs.008.spi.1.2_CONTA_10_msg.xml";
	private static final String PACS_002_SPI_1_2_SPI_10_MSG = "pacs.002/pacs.002.spi.1.2_SPI_10_msg.xml";
	private static final Document PACS_008_DOCUMENT = stringToXmlDocument(getStringFromXmlFile(PACS_008_SPI_1_2_CONTA_10_MSG));
	private static final Document PACS_002_DOCUMENT = stringToXmlDocument(getStringFromXmlFile(PACS_002_SPI_1_2_SPI_10_MSG));
	private static final MessageReceiverEventDTO MESSAGE_RECEIVER_DTO = MessageReceiverEventDTO.builder()
			.messageEntity(buildPacs008MessageEntity())
			.messageDocument(PACS_008_DOCUMENT)
			.build();

	@InjectMocks
	private MessageElementNodeProcessorService messageElementNodeProcessorService;
	@Mock
	private EventRepository eventRepository;
	@Mock
	private EventFactory eventFactory;
	@Mock
	private PaymentEventEntity paymentEventEntity;
	@Mock
    private ReceiveReplyMessageService receiveReplyMessageService;

	private static Stream<Arguments> provideAllIndexAndCorrelationIdFromPacs008Conta10MSG() {
		return Stream.of(
				Arguments.of(0, "E0057376820200217082881978247550"),
				Arguments.of(1, "E0057376820200217082867862e07bb9"),
				Arguments.of(2, "E00573768202002170828c2267bf924b"),
				Arguments.of(3, "E0057376820200217082879f96811591"),
				Arguments.of(4, "E005737682020021708283dc5b23fbdd"),
				Arguments.of(5, "E00573768202002170828df6f5733a1a"),
				Arguments.of(6, "E005737682020021708283d622c92812"),
				Arguments.of(7, "E00573768202002170828efac943650a"),
				Arguments.of(8, "E00573768202002170828ced14cdc371"),
				Arguments.of(9, "E005737682020021708289dd5b39e351")

		);
	}

	private static Stream<Arguments> provideAllIndexAndCorrelationIdFromPacs002SPI10MSG() {
		return Stream.of(
				Arguments.of(0, "E0026471720200214115279f55cb7a72"),
				Arguments.of(1, "E0026471720200214115269c9a581d19"),
				Arguments.of(2, "E00264717202002141152c6b48a588f8"),
				Arguments.of(3, "E00264717202002141152f582f597ff0"),
				Arguments.of(4, "E002647172020021411525999bec5862"),
				Arguments.of(5, "E0026471720200214115234be649aaeb"),
				Arguments.of(6, "E00264717202002141152ffa4e069fb3"),
				Arguments.of(7, "E0026471720200214115223fe45c0b21"),
				Arguments.of(8, "E002647172020021411527e8859c6a32"),
				Arguments.of(9, "E0026471720200214115251b5b57b0e5")

		);
	}

	@ParameterizedTest(name = "Processing nodeIndex: {0} with correlationId: {1}")
	@DisplayName("when processing a new element from a non-reply message and it have a new correlation id should generate a new event from eventFactory")
	@MethodSource("provideAllIndexAndCorrelationIdFromPacs008Conta10MSG")
	void shouldProcessNewEventWhenDoestNotHaveAnyOtherEventWithSameCorrelationId(int nodeIndex, String expectedCorrelationId) {
		NodeList nodeList = DocumentUtils.getElementsByExpression(PACS_008_DOCUMENT, PACS_008_REPLY_ELEMENT);
		Node currentNode = nodeList.item(nodeIndex);
        when(eventFactory.createNewEventFromReceivedMessage(any())).thenReturn(mock(Event.class));
		MESSAGE_RECEIVER_DTO.getMessageTypeEntity().getNewEventType().setCode(PAYMENT_EVENT_TYPE_CODE);
		EventSpecificationFromReceivedMessageDTO dto = new EventSpecificationFromReceivedMessageDTO(MESSAGE_RECEIVER_DTO, currentNode);
		messageElementNodeProcessorService.processElementNodeFromNonReplyMessage(dto);

		verify(eventRepository).findFirstNonFinalEventByEventTypeCodeAndByCorrelationId(PAYMENT_EVENT_TYPE_CODE, expectedCorrelationId);
		verify(eventFactory).createNewEventFromReceivedMessage(new EventSpecificationFromReceivedMessageDTO(MESSAGE_RECEIVER_DTO, currentNode));
		verifyNoMoreInteractions(eventRepository);
	}

	@ParameterizedTest(name = "Processing nodeIndex: {0} with correlationId: {1}")
	@DisplayName("when processing an element from a reply message should generate calls event.receiveReplyMessage")
	@MethodSource("provideAllIndexAndCorrelationIdFromPacs002SPI10MSG")
	void shouldCallsReceiveReplyMessageWhenProcessingAnElementFromAReplyMessage(int nodeIndex, String expectedCorrelationId) {
		MessageReceiverEventDTO messageReceiverEventDTO = MessageReceiverEventDTO.builder()
				.messageEntity(buildPacs002MessageEntity())
				.messageDocument(PACS_002_DOCUMENT)
				.build();
		NodeList nodeList = DocumentUtils.getElementsByExpression(PACS_002_DOCUMENT, PACS_002_REPLY_ELEMENT);
		Node currentNode = nodeList.item(nodeIndex);
		EventSpecificationFromReceivedMessageDTO dto = new EventSpecificationFromReceivedMessageDTO(messageReceiverEventDTO, currentNode);

		messageElementNodeProcessorService.processElementNodeFromReplyMessage(dto);

		verify(receiveReplyMessageService).receiveReplyMessage(expectedCorrelationId, dto.getMessageTypeEntity(), dto);
	}

	@ParameterizedTest(name = "Processing nodeIndex: {0} with correlationId: {1}")
	@DisplayName("when processing a new element from a non-reply message and it have a correlation id that already exists should relate it with the existing event")
	@MethodSource("provideAllIndexAndCorrelationIdFromPacs008Conta10MSG")
	void shouldRelateTheProcessingElementWithExistingCorrelationIdWithTheRelatedEvent(int nodeIndex, String expectedCorrelationId) {
		when(eventRepository.findFirstNonFinalEventByEventTypeCodeAndByCorrelationId(PAYMENT_EVENT_TYPE_CODE, expectedCorrelationId))
				.thenReturn(Optional.of(paymentEventEntity));

		NodeList nodeList = DocumentUtils.getElementsByExpression(PACS_008_DOCUMENT, PACS_008_REPLY_ELEMENT);
		Node currentNode = nodeList.item(nodeIndex);
		MESSAGE_RECEIVER_DTO.getMessageTypeEntity().getNewEventType().setCode(PAYMENT_EVENT_TYPE_CODE);
		EventSpecificationFromReceivedMessageDTO dto = new EventSpecificationFromReceivedMessageDTO(MESSAGE_RECEIVER_DTO, currentNode);
		assertThatThrownBy(() -> messageElementNodeProcessorService.processElementNodeFromNonReplyMessage(dto)).isInstanceOf(
            DuplicateCorrelationIdException.class);

		verify(eventRepository).findFirstNonFinalEventByEventTypeCodeAndByCorrelationId(PAYMENT_EVENT_TYPE_CODE, expectedCorrelationId);
		verifyNoInteractions(eventFactory);
	}

	@Test
	@DisplayName("when not found the correlation id at the current node should throws CorrelationIdNotFoundException")
	void shouldThrowsCorrelationIdNotFoundExceptionWhenCorrelationIdNotFoundAtCurrentNode() {
		//passing the full document it will not found the correlationId with the correlation id xpath
		EventSpecificationFromReceivedMessageDTO dto = new EventSpecificationFromReceivedMessageDTO(MESSAGE_RECEIVER_DTO, PACS_008_DOCUMENT);
		assertThatThrownBy(() -> messageElementNodeProcessorService.processElementNodeFromNonReplyMessage(dto))
				.isInstanceOf(CorrelationIdNotFoundException.class)
				.hasMessageStartingWith("Not found correlation id at node ")
				.hasMessageEndingWith(" from xpath " + PACS_008_CORRELATION_ID_ELEMENT);
	}

	/**
	 * based on
	 *
	 * @see <a href="https://blog.apnic.net/2018/02/08/testing-springs-transactional/">Testing Spring Transactional</a>
	 * @see <a href="https://docs.spring.io/spring/docs/5.0.2.RELEASE/spring-framework-reference/data-access.html#transaction-programmatic">
	 * Spring Transactional docs</a>
	 */
	@Test
	@DisplayName("should rollback the transaction when some RuntimeException happens")
	void shouldRollbackWhenSomeExceptionIsThrown() {
		PlatformTransactionManager monitoringTransactionManager = mock(PlatformTransactionManager.class);
        when(monitoringTransactionManager.getTransaction(any())).thenReturn(mock(TransactionStatus.class));

        final TransactionTemplate transactionTemplate = new TransactionTemplate(monitoringTransactionManager);
		final TransactionCallbackWithoutResult transactionCallback = new TransactionCallbackWithoutResult() {
			@Override
			protected void doInTransactionWithoutResult(@NotNull TransactionStatus status) {
				Node currentNode = mock(Node.class);
				//will throw a CorrelationIdNotFoundException when not found the correlation Id at the mocked node
				EventSpecificationFromReceivedMessageDTO dto = new EventSpecificationFromReceivedMessageDTO(MESSAGE_RECEIVER_DTO, currentNode);
				messageElementNodeProcessorService.processElementNodeFromNonReplyMessage(dto);
			}
		};

		assertThatThrownBy(() -> transactionTemplate.execute(transactionCallback))
				.isInstanceOf(CorrelationIdNotFoundException.class);
		verify(monitoringTransactionManager).rollback(any());
		verify(monitoringTransactionManager, never()).commit(any());
	}

	/**
	 * based on
	 *
	 * @see <a href="https://blog.apnic.net/2018/02/08/testing-springs-transactional/">Testing Spring Transactional</a>
	 * @see <a href="https://docs.spring.io/spring/docs/5.0.2.RELEASE/spring-framework-reference/data-access.html#transaction-programmatic">
	 * Spring Transactional docs</a>
	 */
	@Test
	@DisplayName("should commit the transaction when no exception thrown")
	void shouldCommitTheTransactionWhenNoExceptionThrown() {
		PlatformTransactionManager monitoringTransactionManager = mock(PlatformTransactionManager.class);
		when(monitoringTransactionManager.getTransaction(any())).thenReturn(mock(TransactionStatus.class));

		final TransactionTemplate transactionTemplate = new TransactionTemplate(monitoringTransactionManager);
        when(eventFactory.createNewEventFromReceivedMessage(any())).thenReturn(mock(Event.class));
		final TransactionCallbackWithoutResult transactionCallback = new TransactionCallbackWithoutResult() {
			@Override
			protected void doInTransactionWithoutResult(@NotNull TransactionStatus status) {
				NodeList nodeList = DocumentUtils.getElementsByExpression(PACS_008_DOCUMENT, PACS_008_REPLY_ELEMENT);
				Node currentNode = nodeList.item(1);
				EventSpecificationFromReceivedMessageDTO dto = new EventSpecificationFromReceivedMessageDTO(MESSAGE_RECEIVER_DTO, currentNode);
				messageElementNodeProcessorService.processElementNodeFromNonReplyMessage(dto);
			}
		};

		transactionTemplate.execute(transactionCallback);
		verify(monitoringTransactionManager, never()).rollback(any());
		verify(monitoringTransactionManager).commit(any());
	}

    @Test
    @DisplayName("when processing a reda.016 reply message should get the reply element node")
    void shouldProcessReda016ReplyNode() {

        MessageReceiverEventDTO messageReceiverEventDTO = getMessageReceiverEventDTOFromReda016();

        String orgnlBizInstrFromRead016 = "M9999901012345678901234567890123";

        EventSpecificationFromReceivedMessageDTO dto =
            getEventSpecificationFromReceivedMessageDTO(messageReceiverEventDTO);

        messageElementNodeProcessorService.processElementNodeFromReplyMessage(dto);

        verify(receiveReplyMessageService).receiveReplyMessage(orgnlBizInstrFromRead016, dto.getMessageTypeEntity(), dto);

    }

    private MessageReceiverEventDTO getMessageReceiverEventDTOFromReda016() {
        Document reda016 = getDocumentFromXmlFile("reda.016/reda.016_sucesso_msg.xml");
        MessageEntity messageEntity = EntityCreationUtils.buildReda016MessageEntity();

        return MessageReceiverEventDTO.builder()
            .messageEntity(messageEntity)
            .messageDocument(reda016)
            .build();
    }

    @NotNull
    private EventSpecificationFromReceivedMessageDTO getEventSpecificationFromReceivedMessageDTO(MessageReceiverEventDTO messageReceiverEventDTO) {
        String replyElementXpath = messageReceiverEventDTO.getMessageTypeEntity().getReplyElement();

        Node expectedReplyElementNode =  DocumentUtils
            .getElementsByExpression(messageReceiverEventDTO.getMessageDocument(), replyElementXpath).item(0);

        return new EventSpecificationFromReceivedMessageDTO(messageReceiverEventDTO, expectedReplyElementNode);
    }

}
