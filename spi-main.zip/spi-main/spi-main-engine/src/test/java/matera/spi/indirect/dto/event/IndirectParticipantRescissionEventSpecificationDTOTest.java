package matera.spi.indirect.dto.event;

import matera.spi.indirect.domain.model.ParticipantMipIndirectHistoryEntity;
import matera.spi.main.domain.model.event.EventType;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

class IndirectParticipantRescissionEventSpecificationDTOTest {

    @Test
    void shouldGenerateDtoAsExpected() {
        final ParticipantMipIndirectHistoryEntity historyEntity = new ParticipantMipIndirectHistoryEntity();

        final IndirectParticipantRescissionEventSpecificationDTO dto =
            new IndirectParticipantRescissionEventSpecificationDTO(historyEntity);

        Assertions
            .assertThat(dto)
            .hasFieldOrPropertyWithValue("participantMipIndirectHistory", historyEntity)
            .hasFieldOrPropertyWithValue("eventType", EventType.INDIRECT_PARTICIPANT_RESCISSION);
    }

}
