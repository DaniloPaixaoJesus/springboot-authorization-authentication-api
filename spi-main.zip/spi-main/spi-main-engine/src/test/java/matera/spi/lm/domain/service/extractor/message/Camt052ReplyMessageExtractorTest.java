package matera.spi.lm.domain.service.extractor.message;

import matera.spi.lm.dto.Camt052ExtractMessageDTO;
import matera.spi.utils.DocumentUtils;

import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import java.time.LocalDateTime;

import static matera.spi.lm.domain.service.extractor.message.ExtractorFactory.*;
import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static matera.spi.utils.DocumentUtils.stringToXmlDocument;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.nullValue;
import static org.hamcrest.core.Is.is;

class Camt052ReplyMessageExtractorTest {

    private static final String CAMT_052_MSG = "camt.052/camt.052.xml";
    private static final Document CAMT_052_DOCUMENT = stringToXmlDocument(getStringFromXmlFile(CAMT_052_MSG));

    @Test
    void extractValues() {
        String bkToCstmrAcctRpt = "/Envelope/Document/BkToCstmrAcctRpt";
        NodeList nodeList = DocumentUtils.getElementsByExpression(CAMT_052_DOCUMENT, bkToCstmrAcctRpt);

        Camt052ExtractMessageDTO extractedValues = camt052MessageExtractor().extractValues(nodeList.item(0));

        LocalDateTime creationDt = LocalDateTime.of(2020, 4, 7, 13, 17, 4, 717000000);

        assertThat(extractedValues, is(not(nullValue())));
        assertThat(extractedValues.getNumberOfEntries(), is(300));
        assertThat(extractedValues.getAdditionalReportInformation(), is("da814877563a34794f4cfe65e28a69df2de75f1d3166242722b7c01e26d754e5"));
    }

}
