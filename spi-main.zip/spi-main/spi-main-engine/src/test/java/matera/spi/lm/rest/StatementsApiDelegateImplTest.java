package matera.spi.lm.rest;

import com.matera.spi.messaging.api.MessagesApi;
import com.matera.spi.messaging.api.SPIMessagingApis;
import com.matera.spi.messaging.model.MessageSentResponseDTO;
import com.mysql.cj.exceptions.AssertionFailedException;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import matera.spi.commons.IntegrationTest;
import matera.spi.dto.StatementDetailsRequestDTO;
import matera.spi.dto.StatementDetailsResponseDTO;
import matera.spi.lm.config.CsvStorageConfiguration;
import matera.spi.lm.config.DownloadFileConfiguration;
import matera.spi.lm.domain.model.event.IpAccountStatementQueryDetailsEntity;
import matera.spi.lm.domain.model.event.IpAccountStatementQueryEventEntity;
import matera.spi.lm.persistence.IpAccountStatementQueryDetailsRepository;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventStatusEntity;
import matera.spi.main.domain.model.event.EventTypeEntity;
import matera.spi.main.domain.service.MessageSender;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.EventStatusRepository;
import matera.spi.main.persistence.EventStatusTransitionRepository;
import matera.spi.main.persistence.EventTypeRepository;
import matera.spi.utils.LocalDateTimeUtils;
import org.eclipse.jetty.http.HttpStatus;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

import static matera.spi.main.utils.FileUtils.getStringFromJsonFile;
import static net.javacrumbs.jsonunit.JsonMatchers.jsonEquals;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.Is.isA;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

@IntegrationTest
class StatementsApiDelegateImplTest  {

    private static final String PI_RESOURCE_ID = "PI-RESOURCE-ID-TEST-STATEMENTS";
    private static final String STATEMENTS_BASE_URI = "/ui/v1/statement/details/queries";
    private static final String RESPONSE_STATEMENT = getStringFromJsonFile("statement/response_statement_query.json");

    @LocalServerPort
    private int port;

    @Autowired
    private IpAccountStatementQueryDetailsRepository statementeRepository;

    @Autowired
    private EventStatusRepository eventStatusRepository;

    @Autowired
    private EventTypeRepository eventTypeRepository;

    @Autowired
    private EventRepository eventRepository;

    @Autowired
    private EventStatusTransitionRepository transitionRepository;

    @Autowired
    private MessageSender messageSender;
    @Autowired
    private SPIMessagingApis spiMessagingApisBean;
    @Mock
    private SPIMessagingApis mockedSpiMessagingApis;
    @Mock
    private MessagesApi mockedMessagesApi;

    @BeforeEach
    void beforeEach() {
        RestAssured.port = port;

        when(mockedSpiMessagingApis.messagesApi()).thenReturn(mockedMessagesApi);
        messageSender.setSpiMessagingApis(mockedSpiMessagingApis);
    }

    @AfterEach
    void afterEach() {
        statementeRepository.deleteAll();
        transitionRepository.deleteAll();
        eventRepository.deleteAll();

        messageSender.setSpiMessagingApis(spiMessagingApisBean);
    }

    @Test
    void testGetAllStatementsDetails() {
        createEvent();

        String responseBody = RestAssured
            .given()
                .header("pageSize", 5)
                .header("pageNumber",0)
                .queryParam("startTimestampUtc", "2020-05-01T10:00:00")
                .queryParam("endTimestampUtc", "2020-05-01T16:00:00")
            .when()
                .get(STATEMENTS_BASE_URI)
            .then()
                .extract()
                .body()
                .asString();

        assertThat(responseBody, jsonEquals(RESPONSE_STATEMENT));
    }

    @Test
    void shouldReturnEventUUIDWhenSendPostRequestToStatementQueryDetails() {
        Mockito.doReturn(buildMessageSentResponseDTO()).when(mockedMessagesApi).sendsMessageV1(Mockito.any());

        StatementDetailsResponseDTO statementDetailsResponseDTO = RestAssured
            .given()
                .contentType(ContentType.JSON)
                .body(buildStatementDetailsRequestDTO())
            .when()
                .post(STATEMENTS_BASE_URI)
            .then()
                .statusCode(HttpStatus.CREATED_201)
            .extract()
                .as(StatementDetailsResponseDTO.class);

        assertNotNull(statementDetailsResponseDTO);
        UUID eventUuid = statementDetailsResponseDTO.getData().getEventUuid();
        Optional<EventEntity> optionalEventEntity = eventRepository.findById(eventUuid);

        assertThat(optionalEventEntity.isPresent(), is(true));
        assertThat(optionalEventEntity.get(), isA(IpAccountStatementQueryEventEntity.class));
    }

    @Test
    void assertReturnCsvFile() throws IOException {
        IpAccountStatementQueryEventEntity event = createEvent();

        byte[] bytes = RestAssured
            .when()
                .get("/ui/v1/statement/" + event.getId() + "/csv")
            .then()
                .log()
                .all()
            .extract()
                .body()
                .asByteArray();

        byte[] bytesOriginal = Files.readAllBytes(Path.of("src/test/resources/__files/zip/camt052.zip"));

        assertThat(bytes, is(bytesOriginal));

    }

    private IpAccountStatementQueryEventEntity createEvent() {
        EventStatusEntity eventStatus =
            eventStatusRepository.findById(1).orElseThrow(() -> new AssertionFailedException("Not found EventStatus"));

        EventTypeEntity eventType =
            eventTypeRepository.findById(1).orElseThrow(() -> new AssertionFailedException("Not found EventType"));

        LocalDateTime queryDateTime = LocalDateTime.of(2020, 5, 1, 0, 0, 0);
        LocalDateTime startDatetime = LocalDateTime.of(2020, 5, 1, 0, 0, 1);
        LocalDateTime endDatetime = LocalDateTime.of(2020, 5, 1, 23, 59, 59);

        IpAccountStatementQueryDetailsEntity detailsEntity = new IpAccountStatementQueryDetailsEntity();
        detailsEntity.setAdditionalReportInformation("Additional Report Information");
        detailsEntity.setCreationDateTime(queryDateTime);
        detailsEntity.setFileUri("camt052.zip");
        detailsEntity.setNumberOfEntries(250);
        detailsEntity.setStartTimestampUtc(startDatetime);
        detailsEntity.setEndTimestampUtc(endDatetime);

        IpAccountStatementQueryEventEntity eventEntity = new IpAccountStatementQueryEventEntity();
        eventEntity.setCorrelationId("CORRELATION_ID");
        eventEntity.setClearingTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
        eventEntity.setInitiationTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
        eventEntity.setResponsible(UUID.randomUUID().toString());
        eventEntity.setInitiatorIspb(12345);
        eventEntity.setValue(BigDecimal.ONE);
        eventEntity.setEventTypeEntity(eventType);
        eventEntity.setStatus(eventStatus);
        eventEntity.setIpAccountStatementQueryDetailsEntity(detailsEntity);

        eventRepository.saveAndFlush(eventEntity);

        return eventEntity;
    }

    private StatementDetailsRequestDTO buildStatementDetailsRequestDTO() {
        final StatementDetailsRequestDTO statementDetailsRequestDTO = new StatementDetailsRequestDTO();

        statementDetailsRequestDTO.setStartTimestamp(LocalDateTimeUtils.getUtcLocalDateTime());
        statementDetailsRequestDTO.setEndTimestamp(LocalDateTimeUtils.getUtcLocalDateTime().plusDays(1));
        statementDetailsRequestDTO.setIgnoreDateConflict(Boolean.FALSE);
        return statementDetailsRequestDTO;
    }

    private MessageSentResponseDTO buildMessageSentResponseDTO() {
        final MessageSentResponseDTO messageSentResponseDTO = new MessageSentResponseDTO();
        messageSentResponseDTO.setPiResourceID(PI_RESOURCE_ID);
        return messageSentResponseDTO;
    }

}
