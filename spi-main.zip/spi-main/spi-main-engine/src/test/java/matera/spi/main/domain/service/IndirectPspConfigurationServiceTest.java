package matera.spi.main.domain.service;

import matera.spi.main.exception.MainEngineConfigurationException;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class IndirectPspConfigurationServiceTest {

    @Spy
    private IndirectPspConfigurationService indirectPspConfigurationService;

    @ParameterizedTest
    @ValueSource(strings = {
        "1.2", "1 3", "1A3", "1-3",
        ".12", " 13", "A13", "-13",
        "12.", "13 ", "13A", "13-"
    })
    void shouldNotAllowIspbWithNonNumericalCharacters(String ispb) {

        indirectPspConfigurationService.ispbDirectPsp = ispb;

        Assertions.assertThatThrownBy(() -> indirectPspConfigurationService.validateDirectPspIspb())
            .isInstanceOf(MainEngineConfigurationException.class)
            .hasMessage("The 'spi.mainengine.direct-psp.ispb' property is empty or contains non numeric characters.");
    }

    @ParameterizedTest
    @ValueSource(strings = {
        "0", "1", "12", "123", "1234"
    })
    void shouldAllowIspbWithOnlyNumericalCharacters(String ispb) {

        indirectPspConfigurationService.ispbDirectPsp = ispb;
    }

}
