package matera.spi.main.domain.service;

import matera.spi.main.config.MainEngineConfiguration;

import org.apache.commons.lang.StringUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class MessageIdServiceTest {

    private static final String ISPB_WITH_LENGTH_EIGHT = "12345678";
    private static final String ISPB_WITH_LENGTH_FIVE = "12345";
    private static final String PREFIX_MSG_ID = "M";
    private static final String COMPLEMENT_THE_ZERO_TO_ISPB_LESS_THAN_EIGHT = "000";
    private static final int LENGTH_MAX_TO_MSG_ID = 32;

    @Mock
    private ConfigurationService configurationService;

    @Mock
    private MainEngineConfiguration mainEngineConfiguration;

    @InjectMocks
    private MessageIdService messageIdService;

    @Test
    void shouldGenerateAMsgIdFromApplicationSetup() {
        Mockito.when(configurationService.getIspbDirectPsp()).thenReturn(ISPB_WITH_LENGTH_EIGHT);

        String msgIdActual = messageIdService.generateMsgId();

        Assertions.assertNotNull(msgIdActual);
        Assertions.assertTrue(msgIdActual.startsWith(PREFIX_MSG_ID + ISPB_WITH_LENGTH_EIGHT));
        Assertions.assertEquals(LENGTH_MAX_TO_MSG_ID, msgIdActual.length());
    }

    @Test
    void shouldGenerateAMsgIdWhenLengthTheIspbIsEight() {
        Mockito.when(configurationService.getIspbDirectPsp()).thenReturn(ISPB_WITH_LENGTH_EIGHT);

        String msgIdActual = messageIdService.generateMsgId();

        Assertions.assertNotNull(msgIdActual);
        Assertions.assertTrue(msgIdActual.startsWith(PREFIX_MSG_ID + ISPB_WITH_LENGTH_EIGHT));
        Assertions.assertEquals(LENGTH_MAX_TO_MSG_ID, msgIdActual.length());
    }

    @Test
    void shouldGenerateAMsgIdWhenLengthTheIspbIsLessThanEight() {
        Mockito.when(configurationService.getIspbDirectPsp()).thenReturn(ISPB_WITH_LENGTH_FIVE);

        String msgIdActual = messageIdService.generateMsgId();

        Assertions.assertNotNull(msgIdActual);
        Assertions.assertTrue(msgIdActual
            .startsWith(PREFIX_MSG_ID + COMPLEMENT_THE_ZERO_TO_ISPB_LESS_THAN_EIGHT + ISPB_WITH_LENGTH_FIVE));
        Assertions.assertEquals(LENGTH_MAX_TO_MSG_ID, msgIdActual.length());
    }

    @Test
    void shouldThrowIllegalStateException() {
        Mockito.when(configurationService.getIspbDirectPsp()).thenReturn(StringUtils.EMPTY);

        Assertions.assertThrows(IllegalStateException.class, () -> messageIdService.generateMsgId());
    }

}
