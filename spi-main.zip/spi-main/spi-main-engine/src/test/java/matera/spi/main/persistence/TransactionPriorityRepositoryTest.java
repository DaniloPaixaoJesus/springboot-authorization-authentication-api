package matera.spi.main.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.transaction.TransactionPriorityEntity;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

@IntegrationTest
class TransactionPriorityRepositoryTest   {

    @Autowired
    private TransactionPriorityRepository repository;

    @Test
    void shouldBeFindEntityWhenInserted() {
        TransactionPriorityEntity expected = new TransactionPriorityEntity();
        expected.setCode("1000");
        expected.setDescription("Transaction priority Description");

        repository.saveAndFlush(expected);

        TransactionPriorityEntity actual = repository.findById(expected.getCode()).orElse(null);
        Assertions.assertEquals(expected, actual);
    }

}
