package matera.spi.main.rest.ui;

import matera.spi.commons.IntegrationTest;

import io.restassured.RestAssured;
import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.web.server.LocalServerPort;

@IntegrationTest
class ParticipantsApiDelegateImplTest  {


    private static final String BASE_URI = "/ui/v1/payment-service-providers";

    @LocalServerPort
    private int port;

    @BeforeEach
    void beforeEach() {
        RestAssured.port = port;
    }

    @Test
    void shouldReturnAParticipantList() {
        RestAssured.given()
                .when().get(BASE_URI)
                .then()
                .assertThat()
                .statusCode(HttpStatus.SC_OK)
                .body("data.participants.size()", Matchers.greaterThanOrEqualTo(1))
                ;
    }

}
