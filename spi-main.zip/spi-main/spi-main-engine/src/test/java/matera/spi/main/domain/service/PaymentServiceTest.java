package matera.spi.main.domain.service;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class PaymentServiceTest {

    private static final String ISPB = "12345678";
    private static final String ISPB_LENGTH_THREE = "123";
    private static final String PREFIX_TO_ISPB_LENGTH_THREE = "E00000123";
    private static final String ISPB_EMPTY = "";

    private PaymentService paymentService = new PaymentService();

    @Test
    void shouldReturnAEndToEndID() {
        String EndToEndID = paymentService.generateEndToEndID(ISPB);

        Assertions.assertNotNull(EndToEndID);
    }

    @Test
    void shouldReturnAEndToEndIDWithZeroTheLeft() {
        String EndToEndID = paymentService.generateEndToEndID(ISPB_LENGTH_THREE);

        Assertions.assertTrue(EndToEndID.startsWith(PREFIX_TO_ISPB_LENGTH_THREE));
    }

    @Test
    void shouldThrowIllegalStateException() {
        Assertions.assertThrows(IllegalStateException.class, () -> paymentService.generateEndToEndID(ISPB_EMPTY));
    }

}
