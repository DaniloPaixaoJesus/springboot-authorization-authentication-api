package matera.spi.commons;

import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.test.context.TestContext;
import org.springframework.test.context.TestExecutionListener;

import java.util.Optional;

public class CaffeineRefreshTestExecutionListener implements TestExecutionListener {
    private Optional<CaffeineCacheManager> caffeineCacheManager(TestContext context) {
        try {
            return Optional.of(context.getApplicationContext().getBean(CaffeineCacheManager.class));
        } catch (NoSuchBeanDefinitionException ex) {
            return Optional.empty();
        }
    }

    @Override
    public void afterTestExecution(TestContext testContext) throws Exception {
        caffeineCacheManager(testContext).ifPresent(this::clearCache);
    }

    private void clearCache(CaffeineCacheManager c) {
        c.getCacheNames().forEach(x -> c.getCache(x).clear());
    }
}
