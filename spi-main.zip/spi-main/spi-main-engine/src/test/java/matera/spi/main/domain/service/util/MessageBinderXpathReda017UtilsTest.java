package matera.spi.main.domain.service.util;

import matera.spi.main.utils.FileUtils;
import matera.spi.utils.DocumentUtils;

import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;

import static org.assertj.core.api.Assertions.assertThat;

public class MessageBinderXpathReda017UtilsTest {

    private static final String REDA_017 = "reda.017/reda.017_msg.xml";
    private static final Document DOCUMENT = DocumentUtils.stringToXmlDocument(getXml(REDA_017));

    private static final String EXPECTED_PRTRY_ID = "00123454";
    private static final String EXPECTED_MKTSPCFCATTR = "2020-01-02T08:30:12.000Z";


    @Test
    void shouldReturnRspnsblPtyId() {
        String msgId = MessageBinderXpathReda017Utils.getRspnsblPtyId(DOCUMENT);
        assertThat(EXPECTED_PRTRY_ID).isEqualTo(msgId);
    }

    @Test
    void shouldReturnMktspcfcAttr() {
        String msgId = MessageBinderXpathReda017Utils.getMktspcfcAttrVal(DOCUMENT);
        assertThat(EXPECTED_MKTSPCFCATTR).isEqualTo(msgId);
    }

    private static String getXml(String arquivo) {
        return FileUtils.getStringFromXmlFile(arquivo);
    }
}
