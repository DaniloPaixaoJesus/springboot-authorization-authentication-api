package matera.spi.main.domain.service;

import com.matera.client.rest.exception.RestBadRequestException;
import com.matera.commons.rest.dto.MateraRestErrorDTO;
import matera.spi.main.config.MainEngineConfiguration;
import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.domain.model.event.EventStatus;
import matera.spi.main.domain.model.event.EventStatusEntity;
import matera.spi.main.domain.model.event.transaction.PaymentEventEntity;
import matera.spi.main.domain.model.event.transaction.ReceiptEventEntity;
import matera.spi.main.domain.model.event.transaction.ReturnReceivedEventEntity;
import matera.spi.main.domain.model.transaction.CreditEntity;
import matera.spi.main.domain.model.transaction.PaymentEntity;
import matera.spi.main.domain.model.transaction.ReturnReceivedEntity;
import matera.spi.main.domain.service.event.transaction.validation.CreditEventValidator;
import matera.spi.main.domain.service.transaction.CustomerAccount;
import matera.spi.main.exception.EventValidatorException;
import matera.spi.main.persistence.EventRepository;

import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ReturnReceivedEventValidatorTest {

    private static final Integer DAYS_RETURN_EXPIRATION = 90;
    public static final String END_TO_END_ID = "E8657376820200217082881978247522";
    public static final int ORIGINAL_PAYER_ISPB = 12345;
    public static final int ORIGINAL_RECEIVER_ISPB = 9876;
    private static final String CREDIT_ON_ACCOUNT_NOT_VALIDATED_CODE = "ED05";
    private static final String CREDIT_ON_ACCOUNT_NOT_VALIDATED_DESCRIPTION = "Settlement of the transaction has failed";

    @Mock
    private MainEngineConfiguration mainEngineConfiguration;

    @Mock
    private EventRepository eventRepository;

    @Mock
    private CustomerAccount customerAccount;

    @Mock
    private TransactionRejectReasonStandinService transactionRejectReasonStandinService;

    @Mock
    private ReceiptService receiptService;

    @Mock
    private CreditEventValidator creditEventValidator;

    @InjectMocks
    private ReturnReceivedEventValidator receiptEventValidator;

    private static final String CREDIT_ON_ACCOUNT_NOT_VALIDATED = "ED05";

    @Test
    public void shouldValidateOk() throws EventValidatorException {
        when(eventRepository.sumByOriginalCorrelationIdOfReturnReceived(END_TO_END_ID)).thenReturn(BigDecimal.valueOf(300));
        ReturnReceivedEntity returnReceivedEntity = createReturnReceivedEntity();
        receiptEventValidator.validate(returnReceivedEntity);
    }

    @Test
    public void shouldThrowErrorOnOriginalCorrelationIdNull() {
        ReturnReceivedEntity returnReceivedEntity = createReturnReceivedEntity();
        returnReceivedEntity.getEvent().setOriginalCorrelationId(null);

        EventValidatorException exception = Assertions
            .assertThrows(EventValidatorException.class, () -> receiptEventValidator.validate(returnReceivedEntity));
        assertTrue(exception.getMessage().contains("Original event not found"));
    }

    @Test
    public void shouldThrowErrorOnOriginalCorrelationIdEmpty() {
        ReturnReceivedEntity returnReceivedEntity = createReturnReceivedEntity();
        returnReceivedEntity.getEvent().setOriginalCorrelationId("");

        EventValidatorException exception = Assertions
            .assertThrows(EventValidatorException.class, () -> receiptEventValidator.validate(returnReceivedEntity));
        assertTrue(exception.getMessage().contains("Original event not found"));
    }

    @Test
    public void shouldThrowErrorOnOriginalEventNull() {
        ReturnReceivedEntity returnReceivedEntity = createReturnReceivedEntity();
        returnReceivedEntity.getEvent().setOriginalEvent(null);

        EventValidatorException exception = Assertions
            .assertThrows(EventValidatorException.class, () -> receiptEventValidator.validate(returnReceivedEntity));
        assertTrue(exception.getMessage().contains("Not found event with this End to End Id"));
    }

    @Test
    public void shouldThrowErrorOnOriginalEventTypeError() {
        ReturnReceivedEntity returnReceivedEntity = createReturnReceivedEntity();
        ReceiptEventEntity receiptEventEntity = new ReceiptEventEntity();
        returnReceivedEntity.getEvent().setOriginalEvent(receiptEventEntity);

        EventValidatorException exception = Assertions
            .assertThrows(EventValidatorException.class, () -> receiptEventValidator.validate(returnReceivedEntity));
        assertTrue(exception.getMessage().contains("Original event is not in the state that allows return"));
    }

    @Test
    public void shouldThrowErrorOnOriginalEventStatusError() {
        ReturnReceivedEntity returnReceivedEntity = createReturnReceivedEntity();
        returnReceivedEntity.getEvent().getOriginalEvent().getStatus().setCode(EventStatus.ERROR.getCode());

        EventValidatorException exception = Assertions
            .assertThrows(EventValidatorException.class, () -> receiptEventValidator.validate(returnReceivedEntity));
        assertTrue(exception.getMessage().contains("Original event is not in the state that allows return"));
    }

    @Test
    public void shouldThrowErrorOnReturnReasonNull() {
        ReturnReceivedEntity returnReceivedEntity = createReturnReceivedEntity();
        returnReceivedEntity.setReturnReasonInformationCode(null);

        EventValidatorException exception = Assertions
            .assertThrows(EventValidatorException.class, () -> receiptEventValidator.validate(returnReceivedEntity));
        assertTrue(exception.getMessage().contains("Return reason information invalid"));
    }

    @Test
    public void shouldThrowErrorOnReturnReasonEmpty() {
        ReturnReceivedEntity returnReceivedEntity = createReturnReceivedEntity();
        returnReceivedEntity.setReturnReasonInformationCode("");

        EventValidatorException exception = Assertions
            .assertThrows(EventValidatorException.class, () -> receiptEventValidator.validate(returnReceivedEntity));
        assertTrue(exception.getMessage().contains("Return reason information invalid"));
    }

    @Test
    public void shouldThrowErrorOnExpiredReturnDate() {
        when(mainEngineConfiguration.getDaysReturnExpiration()).thenReturn(DAYS_RETURN_EXPIRATION);

        ReturnReceivedEntity returnReceivedEntity = createReturnReceivedEntity();
        returnReceivedEntity.getEvent().getOriginalEvent().setInitiationTimestampUTC(LocalDateTime.now().minusDays(DAYS_RETURN_EXPIRATION + 10));

        EventValidatorException exception = Assertions
            .assertThrows(EventValidatorException.class, () -> receiptEventValidator.validate(returnReceivedEntity));
        assertEquals("DT05", exception.getRejectCode());
    }

    @Test
    public void shouldThrowErrorOnZeroValue() {
        when(mainEngineConfiguration.getDaysReturnExpiration()).thenReturn(DAYS_RETURN_EXPIRATION);

        ReturnReceivedEntity returnReceivedEntity = createReturnReceivedEntity();
        returnReceivedEntity.getEvent().setValue(BigDecimal.ZERO);

        EventValidatorException exception = Assertions
            .assertThrows(EventValidatorException.class, () -> receiptEventValidator.validate(returnReceivedEntity));
        assertTrue(exception.getMessage().contains("Amount received is not the amount agreed or expected"));
    }

    @Test
    public void shouldThrowErrorOnValueBiggerThanPayment() {
        when(mainEngineConfiguration.getDaysReturnExpiration()).thenReturn(DAYS_RETURN_EXPIRATION);
        when(eventRepository.sumByOriginalCorrelationIdOfReturnReceived(END_TO_END_ID)).thenReturn(BigDecimal.valueOf(1500));

        ReturnReceivedEntity returnReceivedEntity = createReturnReceivedEntity();
        returnReceivedEntity.getEvent().setValue(BigDecimal.valueOf(500));

        EventValidatorException exception = Assertions
            .assertThrows(EventValidatorException.class, () -> receiptEventValidator.validate(returnReceivedEntity));
        assertTrue(exception.getMessage().contains("Amount received is not the amount agreed or expected"));
    }

    @Test
    public void shouldValidateCredit() throws EventValidatorException {
        when(eventRepository.sumByOriginalCorrelationIdOfReturnReceived(END_TO_END_ID)).thenReturn(BigDecimal.valueOf(300));
        ReturnReceivedEntity returnReceivedEntity = createReturnReceivedEntity();

        RestBadRequestException restBadRequestException = new RestBadRequestException(1, null, CREDIT_ON_ACCOUNT_NOT_VALIDATED_CODE, (MateraRestErrorDTO[]) null);


        EventValidatorException eventValidatorException = new EventValidatorException(CREDIT_ON_ACCOUNT_NOT_VALIDATED_CODE, CREDIT_ON_ACCOUNT_NOT_VALIDATED_DESCRIPTION);

        doThrow(eventValidatorException).when(creditEventValidator).validateCredit(any(CreditEntity.class));

        EventValidatorException exception = assertThrows(EventValidatorException.class, () -> {
            receiptEventValidator.validate(returnReceivedEntity);
        });

        String actualRejectCode = exception.getRejectCode();
        Assertions.assertTrue(actualRejectCode.contains(CREDIT_ON_ACCOUNT_NOT_VALIDATED));
    }

    @NotNull
    private ReturnReceivedEntity createReturnReceivedEntity() {
        ReturnReceivedEntity returnReceivedEntity = new ReturnReceivedEntity();
        ReturnReceivedEventEntity event = new ReturnReceivedEventEntity();
        event.setOriginalCorrelationId(END_TO_END_ID);
        event.setValue(BigDecimal.valueOf(300));

        EventStatusEntity eventStatusEntity = new EventStatusEntity();
        eventStatusEntity.setCode(EventStatus.SUCCESS.getCode());
        PaymentEventEntity paymentEventEntity = getOriginalPaymentEventEntity(eventStatusEntity);

        event.setOriginalEvent(paymentEventEntity);
        //should be inverted the participants
        returnReceivedEntity.setPayerParticipant(getOriginalReceiverParticipant());
        returnReceivedEntity.setReceiverParticipant(getOriginalPayerParticipant());
        returnReceivedEntity.setEvent(event);
        returnReceivedEntity.setReturnReasonInformationCode("UPAY");

        return returnReceivedEntity;
    }

    @NotNull
    private PaymentEventEntity getOriginalPaymentEventEntity(EventStatusEntity eventStatusEntity) {
        PaymentEventEntity paymentEventEntity = new PaymentEventEntity();
        paymentEventEntity.setStatus(eventStatusEntity);
        paymentEventEntity.setInitiationTimestampUTC(LocalDateTime.now().minusHours(1));
        paymentEventEntity.setValue(BigDecimal.valueOf(1000));

        PaymentEntity paymentEntity = getOriginalTransaction();
        paymentEventEntity.setPaymentEntity(paymentEntity);
        return paymentEventEntity;
    }

    @NotNull
    private PaymentEntity getOriginalTransaction() {
        PaymentEntity paymentEntity = new PaymentEntity();
        paymentEntity.setPayerParticipant(getOriginalPayerParticipant());
        paymentEntity.setReceiverParticipant(getOriginalReceiverParticipant());
        return paymentEntity;
    }

    private ParticipantEntity getOriginalPayerParticipant() {
        ParticipantEntity payerParticipant = new ParticipantEntity();
        payerParticipant.setIspb(ORIGINAL_PAYER_ISPB);
        return payerParticipant;
    }

    private ParticipantEntity getOriginalReceiverParticipant() {
        ParticipantEntity receiverParticipant = new ParticipantEntity();
        receiverParticipant.setIspb(ORIGINAL_RECEIVER_ISPB);
        return receiverParticipant;
    }
}
