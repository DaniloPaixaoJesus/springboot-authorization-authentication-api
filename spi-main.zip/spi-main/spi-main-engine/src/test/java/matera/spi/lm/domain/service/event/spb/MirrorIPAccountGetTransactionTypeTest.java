package matera.spi.lm.domain.service.event.spb;

import matera.spi.lm.domain.model.spb.SpbEventEntity;
import matera.spi.lm.domain.model.spb.deposit.IpAccountDepositDetailsEntity;
import matera.spi.lm.domain.model.spb.deposit.IpAccountDepositEventEntity;
import matera.spi.lm.domain.service.event.IpAccountAutoDepositEvent;
import matera.spi.lm.domain.service.event.IpAccountDepositEvent;
import matera.spi.lm.dto.IpAccountAutoDepositSpecificationDTO;
import matera.spi.lm.dto.event.IpAccountDepositEventSpecificationDTO;
import matera.spi.main.domain.model.IpAccountConfigEntity;
import matera.spi.main.domain.model.event.transaction.TransactionEventEntity;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.mockito.internal.util.collections.Sets;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.function.ToIntFunction;

public class MirrorIPAccountGetTransactionTypeTest {

    private static final String END_TO_END_ID = "E0057376820200217082881978247550";

    private DepositEventTest depositEvent;

    private AutoDepositEventTest autoDepositEventTest;

    private IpAccountConfigEntity ipAccountConfigEntity;

    @BeforeEach
    void init() {
        final IpAccountDepositEventEntity depositEventEntity = createIpAccountDepositEventEntity();
        ipAccountConfigEntity = buildIpAccountConfigEntity();
        depositEvent = new DepositEventTest(depositEventEntity);
        autoDepositEventTest = new AutoDepositEventTest(depositEventEntity);
    }

    @Test
    void shouldReturnExpectedValueWhenDepositTransactionTypeIsCalled() {
        final ToIntFunction<IpAccountConfigEntity> transactionType = depositEvent.getTransactionType();
        final int actual = transactionType.applyAsInt(ipAccountConfigEntity);
        Assertions.assertEquals(123, actual);
    }

    @Test
    void shouldReturnExpectedValueWhenAutoDepositTransactionTypeIsCalled() {
        final ToIntFunction<IpAccountConfigEntity> transactionType = autoDepositEventTest.getTransactionType();
        final int actual = transactionType.applyAsInt(ipAccountConfigEntity);
        Assertions.assertEquals(321, actual);
    }

    private IpAccountConfigEntity buildIpAccountConfigEntity() {
        final IpAccountConfigEntity ipAccountConfigEntity = new IpAccountConfigEntity();
        ipAccountConfigEntity.setDepositTransactionType(123);
        ipAccountConfigEntity.setAutoDepositTransactionType(321);
        return ipAccountConfigEntity;
    }

    private IpAccountDepositEventEntity createIpAccountDepositEventEntity() {
        final IpAccountDepositEventEntity depositEntity = new IpAccountDepositEventEntity();
        depositEntity.setIpAccountDepositDetails(createSpbDepositEventDetailsEntity());
        setBasicEventInfo(depositEntity);
        return Mockito.spy(depositEntity);
    }

    private IpAccountDepositDetailsEntity createSpbDepositEventDetailsEntity() {
        IpAccountDepositDetailsEntity detailsEntity = new IpAccountDepositDetailsEntity();
        detailsEntity.setIspbif(100L);
        detailsEntity.setIspbpspi(999L);
        return detailsEntity;
    }

    private void setBasicEventInfo(SpbEventEntity spbEventENtity) {
        spbEventENtity.setSpbEventId(1L);
        spbEventENtity.setControlNumber("1a2b3c");
        spbEventENtity.setMovementDate(LocalDate.of(2020,5,11));
        spbEventENtity.setSpbMessageEntity(Sets.newSet());
        spbEventENtity.setValue(BigDecimal.TEN);
        spbEventENtity.setInitiationTimestampUTC(LocalDateTime.now());
        spbEventENtity.setInitiatorIspb(1);
        spbEventENtity.setCorrelationId(END_TO_END_ID);
    }

    public static class DepositEventTest extends IpAccountDepositEvent {

        public DepositEventTest(TransactionEventEntity eventEntity) {
            super(eventEntity);
        }

        public DepositEventTest(IpAccountDepositEventSpecificationDTO eventSpecificationDTO) {
            super(eventSpecificationDTO);
        }

        public ToIntFunction<IpAccountConfigEntity> getTransactionType() {
            return super.getTransactionType();
        }

    }

    public static class AutoDepositEventTest extends IpAccountAutoDepositEvent {

        public AutoDepositEventTest(TransactionEventEntity eventEntity) {
            super(eventEntity);
        }

        public AutoDepositEventTest(IpAccountAutoDepositSpecificationDTO eventSpecificationDTO) {
            super(eventSpecificationDTO);
        }

        public ToIntFunction<IpAccountConfigEntity> getTransactionType() {
            return super.getTransactionType();
        }

    }
}
