package matera.spi.main.application.service;

import matera.spi.lm.domain.service.IpAccountBalanceAnalyzerDomainService;
import matera.spi.lm.exception.BalanceThresholdViolationException;
import matera.spi.main.domain.model.IpAccountConfigEntity;
import matera.spi.main.domain.service.IpAccountConfigurationService;
import matera.spi.main.dto.IpAccountBalanceAnalyzerAction;
import matera.spi.main.dto.IpAccountBalanceAnalyzerDTO;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.comparesEqualTo;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class IpAccountBalanceAnalyzerDomainServiceApplicationServiceTest {

    private final BigDecimal BALANCE_LOWER_THRESHOLD = BigDecimal.valueOf(100);
    private final BigDecimal BALANCE_UPPER_THRESHOLD = BigDecimal.valueOf(250);
    private final BigDecimal BALANCE_LOWER_THRESHOLD_PERCENT = BigDecimal.valueOf(0.10);
    private final BigDecimal BALANCE_UPPER_THRESHOLD_PERCENT = BigDecimal.valueOf(0.10);

    @Mock
    private IpAccountConfigurationService ipAccountConfigurationService;

    @InjectMocks
    private IpAccountBalanceAnalyzerDomainService ipAccountBalanceAnalyzerDomainService;

    @BeforeEach
    void beforeEach() {
        when(ipAccountConfigurationService.findConfig()).thenReturn(getAccountConfiguration());
    }

    @Test
    void testBalanceIsLowerThenLowerThreshold() {
        BigDecimal ipAccountBalance = BigDecimal.valueOf(80);
        Optional<IpAccountBalanceAnalyzerDTO> actionNeddedOpt = ipAccountBalanceAnalyzerDomainService.isActionNedded(ipAccountBalance);

        assertThat(actionNeddedOpt.isPresent(), is(true));

        IpAccountBalanceAnalyzerDTO actionNedded = actionNeddedOpt.get();

        assertThat(actionNedded.getAction(), is(IpAccountBalanceAnalyzerAction.DEPOSIT));
        assertThat(actionNedded.getValue(), comparesEqualTo(BigDecimal.valueOf(30)));
    }

    @Test
    void testBalanceIsGreaterThenUpperThreshold() {
        BigDecimal ipAccountBalance = BigDecimal.valueOf(1500);

        Optional<IpAccountBalanceAnalyzerDTO> actionNeddedOpt = ipAccountBalanceAnalyzerDomainService.isActionNedded(ipAccountBalance);

        assertThat(actionNeddedOpt.isPresent(), is(true));

        IpAccountBalanceAnalyzerDTO actionNedded = actionNeddedOpt.get();

        assertThat(actionNedded.getAction(), is(IpAccountBalanceAnalyzerAction.WITHDRAW));
        assertThat(actionNedded.getValue(), comparesEqualTo(BigDecimal.valueOf(1275)));
    }

    @Test
    void testWhenActionIsNotNedded() {
        BigDecimal ipAccountBalance = BigDecimal.valueOf(120);

        Optional<IpAccountBalanceAnalyzerDTO> actionNedded = ipAccountBalanceAnalyzerDomainService.isActionNedded(ipAccountBalance);

        assertThat(actionNedded.isEmpty(), is(true));
    }

    @Test
    void shouldThrowLowerException() {
        BigDecimal ipAccountBalance = BigDecimal.valueOf(50);
        assertThrows(BalanceThresholdViolationException.class,
                     () -> ipAccountBalanceAnalyzerDomainService.validateOnLimitsConfig(ipAccountBalance),
                     "SPI-LM-001 - [50, 100]");
    }

    @Test
    void shouldThrowUpperException() {
        BigDecimal ipAccountBalance = BigDecimal.valueOf(300);
        assertThrows(BalanceThresholdViolationException.class,
                     () -> ipAccountBalanceAnalyzerDomainService.validateOnLimitsConfig(ipAccountBalance),
                     "SPI-LM-002 - [300, 250]");
    }

    @Test
    void shouldNotThrowException() {
        BigDecimal ipAccountBalance = BigDecimal.valueOf(120);
        assertDoesNotThrow(() -> ipAccountBalanceAnalyzerDomainService.validateOnLimitsConfig(ipAccountBalance));
    }

    private Optional<IpAccountConfigEntity> getAccountConfiguration() {
        IpAccountConfigEntity entity = new IpAccountConfigEntity();
        entity.setAccountNumber(BigDecimal.valueOf(12345678));
        entity.setBranch(4321);
        entity.setCreditTransactionType(5678);
        entity.setDebitTransactionType(1234);
        entity.setBalanceLowerThreshold(BALANCE_LOWER_THRESHOLD);
        entity.setBalanceLowerThresholdPercent(BALANCE_LOWER_THRESHOLD_PERCENT);
        entity.setBalanceUpperThreshold(BALANCE_UPPER_THRESHOLD);
        entity.setBalanceUpperThresholdPercent(BALANCE_UPPER_THRESHOLD_PERCENT);
        entity.setDepositTransactionType(9876);
        entity.setWithdrawTransactionType(5432);

        return Optional.of(entity);
    }

}
