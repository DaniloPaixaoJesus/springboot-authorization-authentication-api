package matera.spi.main.utils.constants;

public class EventConstants {

    private EventConstants() {/* Constant class should not be instantiated*/}

    public static final String EVENT_ENTITY_RESPONSABLE = "Responsible Of Event";
    public static final Integer EVENT_ENTITY_ISPB_INITIATOR = 12345678;

    public static final String EVENT_STATUS_TRANSITION_RESPONSABLE = "Responsible of transition";

    public static final Integer EVENT_STATUS_FOR_TEST_CODE = 1000;
    public static final String EVENT_STATUS_FOR_TEST_DESCRIPTION = "Event Status Test";

    public static final Integer EVENT_STATUS_PAYMENT_INITIALIZED = 1;
    public static final Integer EVENT_STATUS_WAITING_PAYMENT_CONFIRM = 2;
    public static final Integer EVENT_STATUS_SUCCESS = 3;
    public static final Integer EVENT_STATUS_PAYMENT_REJECTED_BY_CLEARING = 4;
    public static final Integer EVENT_STATUS_ERROR = 5;
    public static final Integer EVENT_STATUS_UNCONFIRMED_OPERATION = 6;
    public static final Integer EVENT_STATUS_PAYMENT_WAITING_APRROVAL = 7;
    public static final Integer EVENT_STATUS_RECEIPT_RECEIVED = 8;
    public static final Integer EVENT_STATUS_WAITING_RECEIPT_CONFIRM = 9;
    public static final Integer EVENT_STATUS_RECEIPT_REJECTED = 10;
    public static final Integer EVENT_STATUS_PENDING_PROCESSING = 12;
    public static final Integer EVENT_STATUS_NOTICE_RECEIVED = 13;
    public static final Integer EVENT_STATUS_QUERY_SENT = 14;
    public static final Integer EVENT_STATUS_DATA_RETURNED_WITH_ERROR = 16;
    public static final Integer EVENT_STATUS_UPDATE_SENT = 17;
    public static final Integer EVENT_STATUS_EVENT_WAITING_APPROVAL = 19;
    public static final Integer EVENT_STATUS_RECEIPT_REJECTED_BY_CLEARING = 20;
    public static final Integer EVENT_STATUS_RECEIPT_REJECTION_CONFIRMED = 21;
    public static final Integer EVENT_STATUS_PAYMENT_REJECTED = 22;

}
