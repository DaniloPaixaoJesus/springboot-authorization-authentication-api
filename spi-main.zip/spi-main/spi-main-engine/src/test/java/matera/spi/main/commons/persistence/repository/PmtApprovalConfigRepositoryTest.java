package matera.spi.main.commons.persistence.repository;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.PmtApprovalConfigEntity;
import matera.spi.main.persistence.PmtApprovalConfigRepository;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;

import java.math.BigDecimal;
import java.util.Optional;

@IntegrationTest
public class PmtApprovalConfigRepositoryTest  {

    private static final String PAYMENTORIGIN = "origin";
    private static final BigDecimal PAYMENTVALUE = new BigDecimal("12345678.00");

    @Autowired
    private PmtApprovalConfigRepository repository;

    @Test
    @Order(1)
    public void saveAndFlush() {
        PmtApprovalConfigEntity pmtApprovalConfigEntity = createObject();
        repository.saveAndFlush(pmtApprovalConfigEntity);
        Optional<PmtApprovalConfigEntity> optionalPmtApprovalConfigEntity =
                repository.findByPaymentOrigin(PAYMENTORIGIN);
        if (optionalPmtApprovalConfigEntity.isPresent()){
            Assertions.assertNotNull(pmtApprovalConfigEntity.getId());
            Assertions.assertNotNull(pmtApprovalConfigEntity.getPaymentOrigin());
            Assertions.assertNotNull(pmtApprovalConfigEntity.getPaymentValue());
            Assertions.assertEquals(PAYMENTORIGIN, optionalPmtApprovalConfigEntity.get().getPaymentOrigin());
            Assertions.assertEquals(PAYMENTVALUE, optionalPmtApprovalConfigEntity.get().getPaymentValue());
        }
    }

    @Test
    @Order(2)
    public void find() {
        Optional<PmtApprovalConfigEntity> optional = repository.findByPaymentOrigin(PAYMENTORIGIN);
        if(optional.isPresent())
            Assertions.assertEquals(PAYMENTORIGIN, optional.get().getPaymentOrigin());
    }

    private PmtApprovalConfigEntity createObject() {
        PmtApprovalConfigEntity pmtApprovalConfigEntity = new PmtApprovalConfigEntity();
        pmtApprovalConfigEntity.setPaymentOrigin(PAYMENTORIGIN);
        pmtApprovalConfigEntity.setPaymentValue(PAYMENTVALUE);
        return pmtApprovalConfigEntity;
    }

}
