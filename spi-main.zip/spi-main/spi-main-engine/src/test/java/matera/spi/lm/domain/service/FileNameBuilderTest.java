package matera.spi.lm.domain.service;

import matera.spi.lm.domain.model.event.IpAccountStatementQueryDetailsEntity;
import matera.spi.lm.domain.model.event.IpAccountStatementQueryEventEntity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.UUID;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

@ExtendWith(MockitoExtension.class)
class FileNameBuilderTest {

    @Mock
    private IpAccountStatementQueryEventEntity ipAccountStatementQueryEventEntity;

    private static final LocalDateTime START_DATETIME = LocalDateTime.of(2020, 1, 2, 1, 2, 3);
    private static final LocalDateTime END_DATETIME = LocalDateTime.of(2020, 1, 3, 1, 2, 3);
    private static final String EXPECTED_UUID = "8ce08888-4cb9-422b-aead-3a477847ce29";

    @BeforeEach
    void init() {
        Mockito.doReturn(UUID.fromString(EXPECTED_UUID)).when(ipAccountStatementQueryEventEntity).getId();
    }

    @Test
    void buildZipFileName() {
        final IpAccountStatementQueryDetailsEntity statementQueryDetailsEntity = buildDetailsEntity();
        String fileName = FileNameBuilder.build(statementQueryDetailsEntity.getIpAccountStatementQueryEventEntity().getId(), statementQueryDetailsEntity.getAdditionalReportInformation());

        assertThat(fileName, is(EXPECTED_UUID + "_additional.zip"));
    }

    private IpAccountStatementQueryDetailsEntity buildDetailsEntity() {
        IpAccountStatementQueryDetailsEntity detailsEntity = new IpAccountStatementQueryDetailsEntity();
        detailsEntity.setStartTimestampUtc(START_DATETIME);
        detailsEntity.setEndTimestampUtc(END_DATETIME);
        detailsEntity.setAdditionalReportInformation("additional");
        detailsEntity.setIpAccountStatementQueryEventEntity(ipAccountStatementQueryEventEntity);

        return detailsEntity;
    }

}
