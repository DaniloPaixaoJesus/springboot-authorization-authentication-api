package matera.spi.main.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.transaction.TransactionResultEntity;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;

@IntegrationTest
class TransactionResultRepositoryTest   {

    @Autowired
    private TransactionResultRepository repository;

    @AfterEach
    void clearDatabase() {
        repository.deleteAll();
    }

    @Test
    void shouldBeFindEntityWhenInserted() {
        TransactionResultEntity expected = new TransactionResultEntity();
        expected.setTransactionIdInDdaSystem(BigDecimal.valueOf(10000L));
        expected.setInternalServerError(true);
        expected.setErrorReturned("Erro retornado de teste");
        expected.setReverted(false);

        repository.saveAndFlush(expected);

        TransactionResultEntity actual = repository.findById(expected.getId()).orElse(null);
        Assertions.assertEquals(expected, actual);
    }
}
