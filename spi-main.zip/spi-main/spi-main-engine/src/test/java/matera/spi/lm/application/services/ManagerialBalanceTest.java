package matera.spi.lm.application.services;

import matera.spi.lm.application.service.balanceIPAccountService.DirectBalanceIPAccountService;
import matera.spi.lm.exception.LiquidityManagementException;
import matera.spi.main.apisInterface.ConfigurationApiService;
import matera.spi.main.apisInterface.ParticipantMipApiService;
import matera.spi.main.domain.model.ConfigEntity;
import matera.spi.main.domain.service.ParticipantMipService;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doReturn;

@ExtendWith(MockitoExtension.class)
class ManagerialBalanceTest {

    @InjectMocks
    private DirectBalanceIPAccountService balanceIPAccountService;

    @Mock
    private ConfigurationApiService configurationApiServiceMocked;

    @Mock
    private ParticipantMipApiService participantMipService;

    private final ConfigEntity configEntityMocked = buildConfigEntity();

    @BeforeEach
    void init() {
        doReturn(configEntityMocked).when(configurationApiServiceMocked).findConfig();
    }

    private ConfigEntity buildConfigEntity() {
        final ConfigEntity configEntityMocked = new ConfigEntity();
        configEntityMocked.setIspb(123);
        return configEntityMocked;
    }

    @Test
    void shouldThrowExceptionWhenParticipantMipEntityNotFind() {
        doReturn(Optional.empty()).when(participantMipService).findByIspb(anyInt());
        Assertions.assertThrows(LiquidityManagementException.class, () -> balanceIPAccountService.getManagerialIpAccountBalance());
    }
}
