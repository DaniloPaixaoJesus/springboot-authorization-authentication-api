package matera.spi.main.domain.service;

import com.matera.client.exception.InternalServerErrorException;
import com.matera.client.exception.ServiceUnavailableException;
import com.matera.spi.messaging.model.MessageSentResponseDTO;
import com.matera.spi.messaging.model.MessageSpecificationDTO;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.exception.MessageSendingException;
import matera.spi.main.exception.MessagingInternalErrorException;
import matera.spi.main.exception.MessagingUnavailableException;
import matera.spi.main.utils.WireMockUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;

import java.time.LocalDateTime;

import static matera.spi.main.utils.WireMockUtils.V_1_MESSAGES;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalToJson;
import static com.github.tomakehurst.wiremock.client.WireMock.exactly;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.resetAllRequests;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

@IntegrationTest
class MessageSenderTest {

	private static final String SOME_PI_RESOURCE_ID = "SOME-PI-RESOURCE-ID";

	@Autowired
	private MessageSender messageSender;

    private static final WireMockServer wireMockServer = WireMockUtils.start();

    @AfterAll
    static void afterAll() {
        wireMockServer.stop();
    }


	@BeforeEach
	void beforeEach() {
		resetAllRequests(); // needed to tests be order independent.
	}

	@Test
	@DisplayName("When calling sendMessage should perform a request to /v1/messages/ with the messageSpecification")
	void shouldCallMessagingApiWhenCallingSendMessage() throws MessageSendingException {
		stubFor(post(V_1_MESSAGES)
				.willReturn(aResponse()
						.withStatus(HttpStatus.OK.value())
						.withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
						.withBody("{ \"data\": {\"PI-Resource-ID\":\"" + SOME_PI_RESOURCE_ID + "\"} }")));

		MessageSpecificationDTO messageSpecification = createMessageSpecificationDTO();
		MessageSentResponseDTO response = messageSender.sendMessage(messageSpecification);

		assertThat(response.getPiResourceID()).isEqualTo(SOME_PI_RESOURCE_ID);

		verify(exactly(1), postRequestedFor(urlEqualTo(V_1_MESSAGES))
				.withRequestBody(
						equalToJson("{\"messageContent\":\"<Envelope></Envelope>\"," +
								"\"messageId\":\"M1234567890000\"," +
								"\"messageDefinitionIdentifier\":\"pacs.002.spi.1.1\"," +
								"\"messageCreationDateTime\":\"2020-11-16T15:30:25\"}")));
	}

	@Test
	@DisplayName("When /v1/messages/ responds with serviceUnavailable, sendMessage should thrown a MessagingUnavailableException with the ServiceUnavailableException as cause")
	void shouldThrownMessagingUnavailableExceptionWhenMessagesV1RespondsWithServiceUnavailableException() {
		stubFor(post(V_1_MESSAGES)
				.willReturn(aResponse()
						.withStatus(HttpStatus.SERVICE_UNAVAILABLE.value())));

		MessageSpecificationDTO messageSpecification = createMessageSpecificationDTO();
		assertThatThrownBy(() -> messageSender.sendMessage(messageSpecification))
				.isInstanceOf(MessagingUnavailableException.class)
				.hasCauseInstanceOf(ServiceUnavailableException.class);
		verify(exactly(1), postRequestedFor(urlEqualTo(V_1_MESSAGES)));
	}

	@Test
	@DisplayName("When /v1/messages/ responds with internalServerError, sendMessage should thrown a MessagingInternalErrorException with the InternalServerErrorException as cause")
	void shouldThrownMessagingInternalErrorExceptionWhenMessagesV1RespondsWithInternalServerErrorException() {
		stubFor(post(V_1_MESSAGES)
				.willReturn(aResponse()
						.withStatus(HttpStatus.INTERNAL_SERVER_ERROR.value())));

		MessageSpecificationDTO messageSpecification = createMessageSpecificationDTO();
		assertThatThrownBy(() -> messageSender.sendMessage(messageSpecification))
				.isInstanceOf(MessagingInternalErrorException.class)
				.hasCauseInstanceOf(InternalServerErrorException.class);
		verify(exactly(1), postRequestedFor(urlEqualTo(V_1_MESSAGES)));
	}

	@NotNull
	private MessageSpecificationDTO createMessageSpecificationDTO() {
		MessageSpecificationDTO messageSpecification = new MessageSpecificationDTO();
		messageSpecification.messageContent("<Envelope></Envelope>")
				.messageId("M1234567890000")
				.messageCreationDateTime(LocalDateTime.of(2020, 11, 16, 15, 30, 25))
				.messageDefinitionIdentifier("pacs.002.spi.1.1");
		return messageSpecification;
	}

}
