package matera.spi.main.domain.model.event.transaction;

import matera.spi.lm.domain.model.IpAccountAutoDepositEventEntity;
import matera.spi.lm.domain.model.spb.deposit.IpAccountDepositEventEntity;
import matera.spi.lm.domain.model.spb.withdraw.IpAccountWithdrawEventEntity;
import matera.spi.main.domain.model.ConfigEntity;
import matera.spi.main.domain.model.IpAccountConfigEntity;
import matera.spi.main.domain.model.ParticipantMipEntity;
import matera.spi.main.domain.model.transaction.ReceiptEntity;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class TransactionTypeGetterTest {

    private static final int IP_ACCOUNT_TRANSACTION_TYPE = 100;
    private static final int PARTICIPANT_MIP_TRANSACTION_TYPE = 120;
    private static final int CONFIG_CUSTOMER_TRANSACTION_TYPE = 140;

    @Test
    public void returnRightValuesWithPaymentEventEntity() {
        PaymentEventEntity paymentEventEntity = new PaymentEventEntity();
        IpAccountConfigEntity ipAccountConfigEntity = new IpAccountConfigEntity();
        ipAccountConfigEntity.setDebitTransactionType(IP_ACCOUNT_TRANSACTION_TYPE);
        int mirrorTransactionType = paymentEventEntity.mirrorTransactionTypeGetter().applyAsInt(ipAccountConfigEntity);
        assertEquals(IP_ACCOUNT_TRANSACTION_TYPE, mirrorTransactionType);

        ParticipantMipEntity participantMipEntity = new ParticipantMipEntity();
        participantMipEntity.setDebTransactionType(PARTICIPANT_MIP_TRANSACTION_TYPE);
        int managerialTransactionType = paymentEventEntity.managerialTransactionTypeGetter().applyAsInt(participantMipEntity);
        assertEquals(PARTICIPANT_MIP_TRANSACTION_TYPE, managerialTransactionType);

        ConfigEntity configEntity = new ConfigEntity();
        configEntity.setCustomerDebTransactionType(CONFIG_CUSTOMER_TRANSACTION_TYPE);
        int customerTransactionType = paymentEventEntity.customerTransactionTypeGetter().applyAsInt(configEntity);
        assertEquals(CONFIG_CUSTOMER_TRANSACTION_TYPE, customerTransactionType);
    }

    @Test
    public void returnNullWithPaymentEventEntityNotFilled() {
        PaymentEventEntity paymentEventEntity = new PaymentEventEntity();

        assertThat(paymentEventEntity.mirrorTransactionTypeGetter().applyAsInt(new IpAccountConfigEntity())).isNull();

        assertThat(paymentEventEntity.managerialTransactionTypeGetter().applyAsInt(new ParticipantMipEntity())).isNull();

        assertThat(paymentEventEntity.customerTransactionTypeGetter().applyAsInt(new ConfigEntity())).isNull();
    }

    @Test
    public void returnRightValuesWithReceiptEventEntity() {
        ReceiptEventEntity receiptEventEntity = new ReceiptEventEntity();
        IpAccountConfigEntity ipAccountConfigEntity = new IpAccountConfigEntity();
        ipAccountConfigEntity.setCreditTransactionType(IP_ACCOUNT_TRANSACTION_TYPE);
        int mirrorTransactionType = receiptEventEntity.mirrorTransactionTypeGetter().applyAsInt(ipAccountConfigEntity);
        assertEquals(IP_ACCOUNT_TRANSACTION_TYPE, mirrorTransactionType);

        ParticipantMipEntity participantMipEntity = new ParticipantMipEntity();
        participantMipEntity.setCredTransactionType(PARTICIPANT_MIP_TRANSACTION_TYPE);
        int managerialTransactionType = receiptEventEntity.managerialTransactionTypeGetter().applyAsInt(participantMipEntity);
        assertEquals(PARTICIPANT_MIP_TRANSACTION_TYPE, managerialTransactionType);

        ConfigEntity configEntity = new ConfigEntity();
        configEntity.setCustomerCredTransactionType(CONFIG_CUSTOMER_TRANSACTION_TYPE);
        receiptEventEntity.setTransactionEntity(new ReceiptEntity());
        int customerTransactionType = receiptEventEntity.customerTransactionTypeGetter().applyAsInt(configEntity);
        assertEquals(CONFIG_CUSTOMER_TRANSACTION_TYPE, customerTransactionType);
    }

    @Test
    public void returnRightValuesWithReceiptEventEntityQrCode() {
        ReceiptEventEntity receiptEventEntity = new ReceiptEventEntity();

        ConfigEntity configEntity = new ConfigEntity();
        configEntity.setQrcodeCredTransactionType(CONFIG_CUSTOMER_TRANSACTION_TYPE);

        ReceiptEntity receiptEntity = new ReceiptEntity();
        receiptEntity.setIsDynamicQrCode(true);

        receiptEventEntity.setTransactionEntity(receiptEntity);
        int customerTransactionType = receiptEventEntity.customerTransactionTypeGetter().applyAsInt(configEntity);
        assertEquals(CONFIG_CUSTOMER_TRANSACTION_TYPE, customerTransactionType);
    }

    @Test
    public void returnNullWithReceiptEventEntityNotFilled() {
        ReceiptEventEntity receiptEventEntity = new ReceiptEventEntity();
        receiptEventEntity.setReceiptEntity(new ReceiptEntity());

        assertThat(receiptEventEntity.mirrorTransactionTypeGetter().applyAsInt(new IpAccountConfigEntity())).isNull();

        assertThat(receiptEventEntity.managerialTransactionTypeGetter().applyAsInt(new ParticipantMipEntity())).isNull();

        assertThat(receiptEventEntity.customerTransactionTypeGetter().applyAsInt(new ConfigEntity())).isNull();
    }

    @Test
    public void returnRightValuesWithReturnReceivedEventEntity() {
        ReturnReceivedEventEntity returnReceivedEventEntity = new ReturnReceivedEventEntity();
        IpAccountConfigEntity ipAccountConfigEntity = new IpAccountConfigEntity();
        ipAccountConfigEntity.setDrawbackReceiveTransactType(IP_ACCOUNT_TRANSACTION_TYPE);
        int mirrorTransactionType = returnReceivedEventEntity.mirrorTransactionTypeGetter().applyAsInt(ipAccountConfigEntity);
        assertEquals(IP_ACCOUNT_TRANSACTION_TYPE, mirrorTransactionType);

        ParticipantMipEntity participantMipEntity = new ParticipantMipEntity();
        participantMipEntity.setDrawbackReceiveTransactType(PARTICIPANT_MIP_TRANSACTION_TYPE);
        int managerialTransactionType = returnReceivedEventEntity.managerialTransactionTypeGetter().applyAsInt(participantMipEntity);
        assertEquals(PARTICIPANT_MIP_TRANSACTION_TYPE, managerialTransactionType);

        ConfigEntity configEntity = new ConfigEntity();
        configEntity.setCustDrawbReceivedTransType(CONFIG_CUSTOMER_TRANSACTION_TYPE);
        returnReceivedEventEntity.setTransactionEntity(new ReceiptEntity());
        int customerTransactionType = returnReceivedEventEntity.customerTransactionTypeGetter().applyAsInt(configEntity);
        assertEquals(CONFIG_CUSTOMER_TRANSACTION_TYPE, customerTransactionType);
    }

    @Test
    public void returnNullWithReturnReceivedEventEntityNotFilled() {
        ReturnReceivedEventEntity returnReceivedEventEntity = new ReturnReceivedEventEntity();

        assertThat(returnReceivedEventEntity.mirrorTransactionTypeGetter().applyAsInt(new IpAccountConfigEntity())).isNull();

        assertThat(returnReceivedEventEntity.managerialTransactionTypeGetter().applyAsInt(new ParticipantMipEntity())).isNull();

        assertThat(returnReceivedEventEntity.customerTransactionTypeGetter().applyAsInt(new ConfigEntity())).isNull();
    }

    @Test
    public void returnRightValuesWithReturnSentEventEntity() {
        ReturnSentEventEntity returnSentEventEntity = new ReturnSentEventEntity();
        IpAccountConfigEntity ipAccountConfigEntity = new IpAccountConfigEntity();
        ipAccountConfigEntity.setDrawbackSentTransactType(IP_ACCOUNT_TRANSACTION_TYPE);
        int mirrorTransactionType = returnSentEventEntity.mirrorTransactionTypeGetter().applyAsInt(ipAccountConfigEntity);
        assertEquals(IP_ACCOUNT_TRANSACTION_TYPE, mirrorTransactionType);

        ParticipantMipEntity participantMipEntity = new ParticipantMipEntity();
        participantMipEntity.setDrawbackSentTransactType(PARTICIPANT_MIP_TRANSACTION_TYPE);
        int managerialTransactionType = returnSentEventEntity.managerialTransactionTypeGetter().applyAsInt(participantMipEntity);
        assertEquals(PARTICIPANT_MIP_TRANSACTION_TYPE, managerialTransactionType);

        ConfigEntity configEntity = new ConfigEntity();
        configEntity.setCustDrawbSentTransType(CONFIG_CUSTOMER_TRANSACTION_TYPE);
        returnSentEventEntity.setTransactionEntity(new ReceiptEntity());
        int customerTransactionType = returnSentEventEntity.customerTransactionTypeGetter().applyAsInt(configEntity);
        assertEquals(CONFIG_CUSTOMER_TRANSACTION_TYPE, customerTransactionType);
    }

    @Test
    public void returnNullWithReturnSentEventEntityNotFilled() {
        ReturnSentEventEntity returnSentEventEntity = new ReturnSentEventEntity();

        assertThat(returnSentEventEntity.mirrorTransactionTypeGetter().applyAsInt(new IpAccountConfigEntity())).isNull();

        assertThat(returnSentEventEntity.managerialTransactionTypeGetter().applyAsInt(new ParticipantMipEntity())).isNull();

        assertThat(returnSentEventEntity.customerTransactionTypeGetter().applyAsInt(new ConfigEntity())).isNull();
    }

    @Test
    public void returnUnsuportedOperationWithIpAccountDepositEventEntity() {
        IpAccountDepositEventEntity ipAccountDepositEventEntity = new IpAccountDepositEventEntity();
        assertThrows(UnsupportedOperationException.class, () -> ipAccountDepositEventEntity.mirrorTransactionTypeGetter().applyAsInt(new IpAccountConfigEntity()));

        assertThrows(UnsupportedOperationException.class, () -> ipAccountDepositEventEntity.managerialTransactionTypeGetter().applyAsInt(new ParticipantMipEntity()));

        assertThrows(UnsupportedOperationException.class, () -> ipAccountDepositEventEntity.customerTransactionTypeGetter().applyAsInt(new ConfigEntity()));
    }

    @Test
    public void returnUnsuportedOperationWithIpAccountWithdrawEventEntity() {
        IpAccountWithdrawEventEntity ipAccountWithdrawEventEntity = new IpAccountWithdrawEventEntity();
        assertThrows(UnsupportedOperationException.class, () -> ipAccountWithdrawEventEntity.mirrorTransactionTypeGetter().applyAsInt(new IpAccountConfigEntity()));

        assertThrows(UnsupportedOperationException.class, () -> ipAccountWithdrawEventEntity.managerialTransactionTypeGetter().applyAsInt(new ParticipantMipEntity()));

        assertThrows(UnsupportedOperationException.class, () -> ipAccountWithdrawEventEntity.customerTransactionTypeGetter().applyAsInt(new ConfigEntity()));
    }

    @Test
    public void returnUnsuportedOperationWithIpAccountAutoDepositEventEntity() {
        IpAccountAutoDepositEventEntity ipAccountAutoDepositEventEntity = new IpAccountAutoDepositEventEntity();
        assertThrows(UnsupportedOperationException.class, () -> ipAccountAutoDepositEventEntity.mirrorTransactionTypeGetter().applyAsInt(new IpAccountConfigEntity()));

        assertThrows(UnsupportedOperationException.class, () -> ipAccountAutoDepositEventEntity.managerialTransactionTypeGetter().applyAsInt(new ParticipantMipEntity()));

        assertThrows(UnsupportedOperationException.class, () -> ipAccountAutoDepositEventEntity.customerTransactionTypeGetter().applyAsInt(new ConfigEntity()));
    }

    @Test
    public void returnUnsuportedOperationWithCreditEventEntity() {
        CreditEventEntity creditEventEntity = new CreditEventEntity();
        assertThrows(UnsupportedOperationException.class, () -> creditEventEntity.mirrorTransactionTypeGetter().applyAsInt(new IpAccountConfigEntity()));

        assertThrows(UnsupportedOperationException.class, () -> creditEventEntity.managerialTransactionTypeGetter().applyAsInt(new ParticipantMipEntity()));

        assertThrows(UnsupportedOperationException.class, () -> creditEventEntity.customerTransactionTypeGetter().applyAsInt(new ConfigEntity()));
    }

    @Test
    public void returnUnsuportedOperationWithDebitEventEntity() {
        DebitEventEntity debitEventEntity = new DebitEventEntity();
        assertThrows(UnsupportedOperationException.class, () -> debitEventEntity.mirrorTransactionTypeGetter().applyAsInt(new IpAccountConfigEntity()));

        assertThrows(UnsupportedOperationException.class, () -> debitEventEntity.managerialTransactionTypeGetter().applyAsInt(new ParticipantMipEntity()));

        assertThrows(UnsupportedOperationException.class, () -> debitEventEntity.customerTransactionTypeGetter().applyAsInt(new ConfigEntity()));
    }

}
