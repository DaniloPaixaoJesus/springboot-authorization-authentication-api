package matera.spi.main.utils;

import matera.spi.dto.IpAccountOwnerDTO;
import matera.spi.dto.IpAccountOwnerRequestDTO;
import matera.spi.indirect.domain.model.event.IndirectParticipantRescissionEventEntity;
import matera.spi.lm.domain.model.event.IpAccountBalanceQueryEventEntity;
import matera.spi.lm.domain.model.spb.deposit.IpAccountDepositEventEntity;
import matera.spi.lm.domain.model.spb.withdraw.IpAccountWithdrawEventEntity;
import matera.spi.main.domain.model.IpAccountOwnerEntity;
import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventStatus;
import matera.spi.main.domain.model.event.EventStatusEntity;
import matera.spi.main.domain.model.event.EventStatusTransitionEntity;
import matera.spi.main.domain.model.event.EventType;
import matera.spi.main.domain.model.event.EventTypeEntity;
import matera.spi.main.domain.model.event.IpAccountOwnerStatus;
import matera.spi.main.domain.model.event.IpAccountOwnerUpdateEventEntity;
import matera.spi.main.domain.model.event.transaction.PaymentEventEntity;
import matera.spi.main.domain.model.event.transaction.ReceiptEventEntity;
import matera.spi.main.domain.model.event.transaction.ReturnReceivedEventEntity;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.domain.model.message.MessageTypeEntity;
import matera.spi.main.domain.model.transaction.ReceiptEntity;
import matera.spi.main.domain.model.transaction.TransactionPriorityEntity;
import matera.spi.main.domain.service.CpfCnpjFormatter;
import matera.spi.utils.LocalDateTimeUtils;

import org.apache.commons.lang.RandomStringUtils;
import org.jetbrains.annotations.NotNull;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

public class EntityCreationUtils {

    private EntityCreationUtils() {/* utilit classes should not be instantiated*/}

    public static final String DIRECTOR_NAME = "The Director Name";
    public static final String DIRECTOR_EMAIL = "director@mail.com";
    public static final String DIRECTOR_PHONE = "+55-6144444444";
    public static final String DIRECTOR_MOBILE = "+55-613333333";
    public static final String DIRECTOR_TAX_ID = "57533154029";
    public static final String PASSPHRASE = "12345678";
    public static final String EMPLOYEE_EMAIL = "employee@mail.com";
    public static final String EMPLOYEE_PHONE = "+55-14911223344";
    public static final String EMPLOYEE_MOBILE = "+55-14900000000";
    public static final String EMPLOYEE_FAX = "+55-14911111111";

    public static final String CORRELATION_ID = "E00539039202002170828063aec68f6e";
    public static final String PACS_008_REPLY_ELEMENT = "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf";
    public static final String PACS_008_CORRELATION_ID_ELEMENT = "PmtId/EndToEndId";
    public static final String PACS_002_REPLY_ELEMENT = "/Envelope/Document/FIToFIPmtStsRpt/TxInfAndSts";
    public static final String PACS_002_CORRELATION_ID_ELEMENT = "OrgnlEndToEndId";

    public static final String ADMI_002_REPLY_ELEMENT = "";
    public static final String ADMI_002_CORRELATION_ID_ELEMENT = "/Envelope/Document/admi.002.001.01/RltdRef/Ref";

	public static final int PAYMENT_EVENT_TYPE_CODE = 1;
    public static final int RECEIPT_EVENT_TYPE_CODE = 2;
    public static final int RETURN_RECEIVED_EVENT_TYPE_CODE = 13;
    public static final int BALANCE_QUERY_EVENT_TYPE_CODE = 4;
    public static final int DEPOSIT_EVENT_TYPE_CODE = 10;
    public static final int WITHDRAW_EVENT_TYPE_CODE = 11;
    private static final int IP_ACCOUNT_OWNER_UPDATE_CODE = 7;
    private static final int INDIRECT_PARTICIPANT_RESCISSION = 18;


    @NotNull
	public static MessageEntity buildAdmi002MessageEntity() {
		MessageEntity messageEntity = buildGenericMessageEntity();
		messageEntity.setMessageTypeEntity(buildAdmi002MessageTypeEntity());
		return messageEntity;
	}

    @NotNull
    public static MessageEntity buildPacs008MessageEntity() {
        MessageEntity messageEntity = buildGenericMessageEntity();
        messageEntity.setMessageTypeEntity(buildPacs008MessageTypeEntity());
        return messageEntity;
    }

	@NotNull
	public static MessageEntity buildPacs002MessageEntity() {
		MessageEntity messageEntity = buildGenericMessageEntity();
		messageEntity.setMessageTypeEntity(buildPacs002MessageTypeEntity());
		return messageEntity;
	}

    @NotNull
    public static MessageEntity buildReda016MessageEntity() {
        MessageEntity messageEntity = buildGenericMessageEntity();
        messageEntity.setMessageTypeEntity(buildReda016MessageTypeEntity());
        return messageEntity;
    }

    @NotNull
    public static MessageEntity buildCamt053MessageEntity() {
        MessageEntity messageEntity = buildGenericMessageEntity();
        messageEntity.setMessageTypeEntity(buildCamt053MessageTypeEntity());
        return messageEntity;
    }

    @NotNull
    private static MessageEntity buildGenericMessageEntity() {
        MessageEntity messageEntity = new MessageEntity();
        messageEntity.setClearingTimestampUtc(LocalDateTime.now(ZoneOffset.UTC));
        messageEntity.setPiResourceId(RandomStringUtils.randomAlphabetic(12));
        messageEntity.setVersion("12345678");
        messageEntity.setTimestampUtc(LocalDateTime.now(ZoneOffset.UTC));
        return messageEntity;
    }

	public static ParticipantEntity buildReceiverParticipant() {
		ParticipantEntity entity = new ParticipantEntity();
		entity.setIspb(13370835);
		entity.setName("Payer Participant");
		entity.setActive(Boolean.TRUE);
		return entity;
	}

    public static ParticipantEntity buildSenderParticipant() {
        ParticipantEntity entity = new ParticipantEntity();
        entity.setIspb(87654321);
        entity.setName("Receiver Participant");

        return entity;
    }

    @NotNull
    public static MessageTypeEntity buildAdmi002MessageTypeEntity() {
        MessageTypeEntity messageTypeEntity = new MessageTypeEntity();
        messageTypeEntity.setCode("admi.002");
        messageTypeEntity.setIsFinancial(false);
        messageTypeEntity.setStatusElement("");
        messageTypeEntity.setReplyElement(ADMI_002_REPLY_ELEMENT);
        messageTypeEntity.setCorrelationIdElement(ADMI_002_CORRELATION_ID_ELEMENT);
        messageTypeEntity.setNewEventType(buildEventTypeEntity());
        return messageTypeEntity;
    }

    @NotNull
    public static MessageTypeEntity buildPacs008MessageTypeEntity() {
        MessageTypeEntity messageTypeEntity = new MessageTypeEntity();
        messageTypeEntity.setCode("pacs.008");
        messageTypeEntity.setIsFinancial(false);
        messageTypeEntity.setStatusElement("");
        messageTypeEntity.setReplyElement(PACS_008_REPLY_ELEMENT);
        messageTypeEntity.setCorrelationIdElement(PACS_008_CORRELATION_ID_ELEMENT);
        messageTypeEntity.setNewEventType(buildEventTypeEntity());
        return messageTypeEntity;
    }

    @NotNull
    public static MessageTypeEntity buildPacs004MessageTypeEntity() {
        MessageTypeEntity messageTypeEntity = new MessageTypeEntity();
        messageTypeEntity.setCode("pacs.004");
        messageTypeEntity.setIsFinancial(false);
        messageTypeEntity.setStatusElement("");
        messageTypeEntity.setReplyElement("Envelope/Document/PmtRtr/TxInf");
        messageTypeEntity.setCorrelationIdElement("RtrId");
        messageTypeEntity.setNewEventType(buildEventTypeEntity());
        return messageTypeEntity;
    }

    @NotNull
    public static MessageTypeEntity buildPacs002MessageTypeEntity() {
        MessageTypeEntity messageTypeEntity = new MessageTypeEntity();
        messageTypeEntity.setCode("pacs.002");
        messageTypeEntity.setIsFinancial(true);
        messageTypeEntity.setStatusElement("TxSts");
        messageTypeEntity.setReplyElement(PACS_002_REPLY_ELEMENT);
        messageTypeEntity.setCorrelationIdElement(PACS_002_CORRELATION_ID_ELEMENT);
        return messageTypeEntity;
    }

    @NotNull
    public static MessageTypeEntity buildReda016MessageTypeEntity() {
        MessageTypeEntity messageTypeEntity = new MessageTypeEntity();
        messageTypeEntity.setCode("reda.016");
        messageTypeEntity.setIsFinancial(false);
        messageTypeEntity.setReplyElement("/Envelope/Document/PtyStsAdvc");
        messageTypeEntity.setCorrelationIdElement("MsgHdr/OrgnlBizInstr/MsgId");
        messageTypeEntity.setStatusElement("PtySts/Sts");
        return messageTypeEntity;
    }

	@NotNull
	public static MessageTypeEntity buildCamt053MessageTypeEntity() {
		MessageTypeEntity messageTypeEntity = new MessageTypeEntity();
		messageTypeEntity.setCode("camt.053");
		messageTypeEntity.setIsFinancial(false);
		messageTypeEntity.setStatusElement("");
		messageTypeEntity.setReplyElement("");
		messageTypeEntity.setCorrelationIdElement("");
		messageTypeEntity.setNewEventType(null);

        EventTypeEntity eventTypeEntity = new EventTypeEntity();
        eventTypeEntity.setCode(BALANCE_QUERY_EVENT_TYPE_CODE);
        messageTypeEntity.setOriginalEventType(eventTypeEntity);
        return messageTypeEntity;
    }

    @NotNull
    public static EventTypeEntity buildEventTypeEntity() {
        EventTypeEntity eventTypeEntity = new EventTypeEntity();
        eventTypeEntity.setCode(RECEIPT_EVENT_TYPE_CODE);
        return eventTypeEntity;
    }

    public static EventTypeEntity buildPaymentEventTypeEntity() {
        EventTypeEntity eventTypeEntity = new EventTypeEntity();
        eventTypeEntity.setCode(PAYMENT_EVENT_TYPE_CODE);
        eventTypeEntity.setDescription("Payment");
        eventTypeEntity.setInitialStatus(buildPaymentInitializedEventStatusEntity());
        eventTypeEntity.setSuccessStatus(buildSuccessEventStatusEntity());
        eventTypeEntity.setMessageTypeToSend(buildPacs008MessageTypeEntity());
        return eventTypeEntity;
    }

    public static EventTypeEntity buildReturnSentEventTypeEntity() {
        EventTypeEntity eventTypeEntity = new EventTypeEntity();
        eventTypeEntity.setCode(EventType.RETURN_SENDER.getCode());
        eventTypeEntity.setDescription("Return sender");
        eventTypeEntity.setInitialStatus(buildReturnInitiatedEventStatusEntity());
        eventTypeEntity.setSuccessStatus(buildSuccessEventStatusEntity());
        eventTypeEntity.setMessageTypeToSend(buildPacs004MessageTypeEntity());
        return eventTypeEntity;
    }

    public static EventTypeEntity buildReturnReceivedEventTypeEntity() {
        EventTypeEntity eventTypeEntity = new EventTypeEntity();
        eventTypeEntity.setCode(EventType.RETURN_RECEIVER.getCode());
        eventTypeEntity.setDescription("Return receiver");
        eventTypeEntity.setInitialStatus(buildReturnReceivedEventStatusEntity());
        eventTypeEntity.setSuccessStatus(buildSuccessEventStatusEntity());
        return eventTypeEntity;
    }

    public static EventStatusEntity buildReturnInitiatedEventStatusEntity() {
        EventStatusEntity status = new EventStatusEntity();
        status.setCode(EventStatus.RETURN_INITIATED.getCode());
        status.setDescription("Return initiated");
        status.setFinalStatus(false);
        return status;
    }

    public static EventStatusEntity buildReturnReceivedEventStatusEntity() {
        EventStatusEntity status = new EventStatusEntity();
        status.setCode(EventStatus.RETURN_RECEIVED.getCode());
        status.setDescription("Return received");
        status.setFinalStatus(false);
        return status;
    }

    public static EventStatusEntity buildPaymentInitializedEventStatusEntity() {
	    EventStatusEntity paymentInitialized = new EventStatusEntity();
        paymentInitialized.setCode(EventStatus.PAYMENT_INITIALIZED.getCode());
	    paymentInitialized.setDescription("Payment initialized");
	    paymentInitialized.setFinalStatus(false);
	    return paymentInitialized;
    }

    public static EventStatusEntity buildWaitingPaymentConfirmEventStatusEntity() {
        EventStatusEntity status = new EventStatusEntity();
        status.setCode(EventStatus.WAITING_PAYMENT_CONFIRM.getCode());
        status.setDescription("Waiting payment confirm");
        status.setFinalStatus(false);
        return status;
    }



    public static EventStatusEntity buildSuccessEventStatusEntity() {
        EventStatusEntity status = new EventStatusEntity();
        status.setCode(EventStatus.SUCCESS.getCode());
        status.setDescription("Success");
        status.setFinalStatus(true);
        return status;
    }

    public static EventEntity buildEventEntity() {
		return buildEventEntity(PAYMENT_EVENT_TYPE_CODE);
	}

	@NotNull
	public static EventEntity buildEventEntity(int eventType) {
		EventEntity expectedEvent = getExpectedEvent(eventType);
        expectedEvent.setId(UUID.randomUUID());
		expectedEvent.setCorrelationId(CORRELATION_ID);
		expectedEvent.setClearingTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
		expectedEvent.setInitiationTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
		expectedEvent.setResponsible("SOME RESPONSIBLE");
		expectedEvent.setInitiatorIspb(12345);
		expectedEvent.setValue(BigDecimal.ONE);
		return expectedEvent;
	}

    public static ReceiptEntity buildReceiptEntity() {
        ReceiptEntity receiptEntity = new ReceiptEntity();

        receiptEntity.setPayerParticipant(buildSenderParticipant());
        receiptEntity.setReceiverParticipant(buildReceiverParticipant());
        receiptEntity.setCustomerInitTimestampUtc(LocalDateTime.now());
        receiptEntity.setEndToEndId(CORRELATION_ID);
        TransactionPriorityEntity priority = new TransactionPriorityEntity();
        priority.setCode("HIGH");
        receiptEntity.setPriority(priority);

	    return receiptEntity;
    }

	@NotNull
	private static EventEntity getExpectedEvent(int eventTypeCode) {
		switch (eventTypeCode) {
			case PAYMENT_EVENT_TYPE_CODE:
                PaymentEventEntity paymentEventEntity = new PaymentEventEntity();
                paymentEventEntity.setEventTypeEntity(buildPaymentEventTypeEntity());
                return paymentEventEntity;
			case RECEIPT_EVENT_TYPE_CODE:
				return new ReceiptEventEntity();
            case RETURN_RECEIVED_EVENT_TYPE_CODE:
                ReturnReceivedEventEntity returnReceivedEventEntity = new ReturnReceivedEventEntity();
                returnReceivedEventEntity.setEventTypeEntity(buildReturnReceivedEventTypeEntity());
                return returnReceivedEventEntity;
			case BALANCE_QUERY_EVENT_TYPE_CODE:
				return new IpAccountBalanceQueryEventEntity();
            case DEPOSIT_EVENT_TYPE_CODE:
                return new IpAccountDepositEventEntity();
            case WITHDRAW_EVENT_TYPE_CODE:
                return new IpAccountWithdrawEventEntity();
            case IP_ACCOUNT_OWNER_UPDATE_CODE:
                return new IpAccountOwnerUpdateEventEntity();
            case INDIRECT_PARTICIPANT_RESCISSION:
                return new IndirectParticipantRescissionEventEntity();
			default:
				throw new IllegalArgumentException("EventType " + eventTypeCode + " has no mapped EventEntity at EntityCreationUtils" );
		}
	}

    @NotNull
    public static EventEntity buildEventEntityWithEventStatusTransitionEntity() {
        EventEntity expectedEvent = getExpectedEvent(PAYMENT_EVENT_TYPE_CODE);
        expectedEvent.setCorrelationId(CORRELATION_ID);
        expectedEvent.setClearingTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
        expectedEvent.setInitiationTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
        expectedEvent.setResponsible("SOME RESPONSIBLE");
        expectedEvent.setInitiatorIspb(12345);
        expectedEvent.setValue(BigDecimal.ONE);
        EventStatusEntity eventStatus = new EventStatusEntity();
        eventStatus.setCode(1);
        eventStatus.setDescription("");
        eventStatus.setFinalStatus(true);
        expectedEvent.setStatus(eventStatus);

        EventStatusTransitionEntity eventStatusTransition = new EventStatusTransitionEntity();
        eventStatusTransition.setEvent(expectedEvent);
        eventStatusTransition.setEventStatusCode(expectedEvent.getStatus());
        eventStatusTransition.setResponsible(expectedEvent.getResponsible());
        eventStatusTransition.setTimestamp(LocalDateTime.now(ZoneOffset.UTC));

        expectedEvent.relateToNewStatus(eventStatusTransition);

		return expectedEvent;
	}

    @NotNull
    public static IpAccountOwnerEntity buildIpAccountOwnerEntityWithRequiredFields() {
        IpAccountOwnerEntity ipAccountOwnerEntity = new IpAccountOwnerEntity();
        ipAccountOwnerEntity.setDirectorName(DIRECTOR_NAME);
        ipAccountOwnerEntity.setDirectorPhone(DIRECTOR_PHONE);
        ipAccountOwnerEntity.setDirectorEmail(DIRECTOR_EMAIL);
        ipAccountOwnerEntity.setDirectorTaxId(DIRECTOR_TAX_ID);
        ipAccountOwnerEntity.setPassphrase(PASSPHRASE);
        ipAccountOwnerEntity.setEmployeeEmail(EMPLOYEE_EMAIL);
        ipAccountOwnerEntity.setEmployeePhone(EMPLOYEE_PHONE);
        LocalDateTime now = getNowWithMillisPrecision();
        ipAccountOwnerEntity.setInitiationTimestamp(now);
        return ipAccountOwnerEntity;
    }

    public static IpAccountOwnerEntity buildIpAccountOwnerEntityWithAllFields() {
        IpAccountOwnerEntity ipAccountOwnerEntity = buildIpAccountOwnerEntityWithRequiredFields();
        ipAccountOwnerEntity.setDirectorMobile(DIRECTOR_MOBILE);
        ipAccountOwnerEntity.setEmployeeMobile(EMPLOYEE_MOBILE);
        ipAccountOwnerEntity.setEmployeeFax(EMPLOYEE_FAX);
        return ipAccountOwnerEntity;
    }

        @NotNull
    public static LocalDateTime getNowWithMillisPrecision() {
        LocalDateTime nowWithNanoPrecision = LocalDateTimeUtils.getUtcLocalDateTime();
        DateTimeFormatter formatterWithMillisPrecision = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss:SSS");

        String dateStringWithMillisPrecision = nowWithNanoPrecision.format(formatterWithMillisPrecision);

        return LocalDateTime.parse(dateStringWithMillisPrecision, formatterWithMillisPrecision);
    }

    public static IpAccountOwnerRequestDTO buildIpAccountOwnerRequestDTO() {
        return new IpAccountOwnerRequestDTO()
            .directorName(DIRECTOR_NAME)
            .directorEmail(DIRECTOR_EMAIL)
            .directorPhone(DIRECTOR_PHONE)
            .directorTaxId(DIRECTOR_TAX_ID)
            .passPhrase(PASSPHRASE)
            .employeeEmail(EMPLOYEE_EMAIL)
            .employeePhone(EMPLOYEE_PHONE);
    }

    public static IpAccountOwnerRequestDTO buildIpAccountOwnerRequestDTOWithAllFields() {
        return buildIpAccountOwnerRequestDTO()
            .directorMobile(DIRECTOR_MOBILE)
            .employeeMobile(EMPLOYEE_MOBILE)
            .employeeFax(EMPLOYEE_FAX);

    }

    public static IpAccountOwnerDTO buildIpAccountOwnerDTOWithAllFields(IpAccountOwnerStatus expectedStatus) {
        return buildIpAccountOwnerDTO(expectedStatus)
            .directorMobile(DIRECTOR_MOBILE)
            .employeeMobile(EMPLOYEE_MOBILE)
            .employeeFax(EMPLOYEE_FAX);
    }

    public static IpAccountOwnerDTO buildIpAccountOwnerDTO(IpAccountOwnerStatus expectedStatus) {
        return new IpAccountOwnerDTO()
            .directorName(DIRECTOR_NAME)
            .directorEmail(DIRECTOR_EMAIL)
            .directorPhone(DIRECTOR_PHONE)
            .directorTaxId(CpfCnpjFormatter.padCpf(DIRECTOR_TAX_ID))
            .passPhrase(PASSPHRASE)
            .employeeEmail(EMPLOYEE_EMAIL)
            .employeePhone(EMPLOYEE_PHONE)
            .status(expectedStatus.name());
    }

}
