package matera.spi;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.service.event.Event;

import com.tngtech.archunit.base.DescribedPredicate;
import com.tngtech.archunit.core.domain.JavaClass;
import com.tngtech.archunit.core.importer.ImportOption;
import com.tngtech.archunit.junit.AnalyzeClasses;
import com.tngtech.archunit.junit.ArchTest;
import com.tngtech.archunit.lang.ArchRule;
import com.tngtech.archunit.lang.syntax.ArchRuleDefinition;
import com.tngtech.archunit.lang.syntax.elements.GivenClassesConjunction;
import com.tngtech.archunit.library.Architectures;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import static com.tngtech.archunit.core.domain.JavaClass.Predicates.assignableTo;

@AnalyzeClasses(packages = "matera.spi", importOptions = {ImportOption.DoNotIncludeTests.class, ImportOption.DoNotIncludeJars.class})
public class ArchitecturalConstraintsTest {

    private static final DescribedPredicate<JavaClass> EVENT_ASSIGNABLES = assignableTo(Event.class);

    // @formatter:off
    @ArchTest
    public static final ArchRule layersRules = Architectures
            .layeredArchitecture()
            .layer("REST").definedBy("matera.spi.rest")

            //Main engine
            .layer("MainEngineREST").definedBy("..main.rest..")
            .layer("MainEngineApplicationServices").definedBy("..main.application.service..")
            .layer("MainEngineDomainServices").definedBy("..main.domain.service..")
            .layer("MainEngineDomainModel").definedBy("..main.domain.model..")
            .layer("MainEnginePersistence").definedBy("..main.persistence..")
            .layer("MainEngineDTO").definedBy("..main.dto..")
            .layer("MainEngineException").definedBy("..main.exception..")
            .layer("MainEnginePort").definedBy("..main.transactions.port..")
            .layer("MainEngineAdapter").definedBy("..main.transactions.adapter..")
            .layer("MainEngineApisInterface").definedBy("..main.apisInterface..")

            //Liquidity Management
            .layer("LiquidityManagementREST").definedBy("..lm.rest..")
            .layer("LiquidityManagementApplicationServices").definedBy("..lm.application.service..")
            .layer("LiquidityManagementDomainServices").definedBy("..lm.domain.service..")
            .layer("LiquidityManagementDomainModel").definedBy("..lm.domain.model..")
            .layer("LiquidityManagementPersistence").definedBy("..lm.persistence..")
            .layer("LiquidityManagementDTO").definedBy("..lm.dto..")
            .layer("LiquidityManagementException").definedBy("..lm.exception..")
            .layer("LiquidityManagementAdapter").definedBy("..lm.transactions.adapter..")
            .layer("LiquidityManagementPort").definedBy("..lm.transactions.port..")
            .layer("LiquidityManagementParticipantConfig").definedBy("..lm.config.participant..")

            //Indirect
            .layer("IndirectParticipantDomainModel").definedBy("..indirect.domain.model..")
            .layer("IndirectParticipantPersistence").definedBy("..indirect.persistence..")
            .layer("IndirectParticipantMessages").definedBy("..indirect.exception.message..")
            .layer("IndirectParticipantApplicationServices").definedBy("..indirect.application.service..")
            .layer("IndirectParticipantDomainServices").definedBy("..indirect.domain.service..")
            .layer("IndirectParticipantREST").definedBy("..indirect.rest..")
            .layer("IndirectParticipantDTO").definedBy("..indirect.dto..")
            .layer("IndirectParticipantApisInterface").definedBy("..indirect.apisInterface..")

            //Utils - This package can only contain classes without implementing business rules
            .layer("UTILS").definedBy("matera.spi.utils..")

            .whereLayer("REST").mayOnlyBeAccessedByLayers("MainEngineREST", "LiquidityManagementREST", "IndirectParticipantREST")
            .whereLayer("UTILS").mayOnlyBeAccessedByLayers("MainEngineApplicationServices", "MainEngineDomainServices", "MainEngineDTO", "MainEngineAdapter", "MainEngineApisInterface", "LiquidityManagementApplicationServices", "LiquidityManagementDomainServices", "LiquidityManagementDTO", "IndirectParticipantDomainServices", "IndirectParticipantApplicationServices", "IndirectParticipantMessages")
            //Rules - LM
            .whereLayer("LiquidityManagementREST").mayNotBeAccessedByAnyLayer()
            .whereLayer("LiquidityManagementApplicationServices").mayOnlyBeAccessedByLayers("LiquidityManagementREST", "LiquidityManagementApplicationServices", "LiquidityManagementParticipantConfig")
            .whereLayer("LiquidityManagementDomainServices").mayOnlyBeAccessedByLayers("LiquidityManagementApplicationServices", "LiquidityManagementDomainServices", "LiquidityManagementAdapter")
            .whereLayer("LiquidityManagementDomainModel").mayOnlyBeAccessedByLayers("LiquidityManagementApplicationServices", "LiquidityManagementDomainServices", "LiquidityManagementDomainModel", "LiquidityManagementDTO", "LiquidityManagementPersistence")
            .whereLayer("LiquidityManagementPersistence").mayOnlyBeAccessedByLayers("LiquidityManagementDomainServices", "LiquidityManagementApplicationServices")
            .whereLayer("LiquidityManagementDTO").mayOnlyBeAccessedByLayers("LiquidityManagementREST", "LiquidityManagementApplicationServices", "LiquidityManagementDomainServices", "LiquidityManagementException", "LiquidityManagementAdapter", "LiquidityManagementPort")
            .whereLayer("LiquidityManagementException").mayOnlyBeAccessedByLayers("LiquidityManagementApplicationServices", "LiquidityManagementDomainServices")
            .whereLayer("LiquidityManagementAdapter").mayNotBeAccessedByAnyLayer()

            //Rules - Indirect
            .whereLayer("IndirectParticipantDomainModel").mayOnlyBeAccessedByLayers( "IndirectParticipantDomainModel", "IndirectParticipantPersistence", "IndirectParticipantApplicationServices", "IndirectParticipantDomainServices", "IndirectParticipantDTO")
            .whereLayer("IndirectParticipantApplicationServices").mayOnlyBeAccessedByLayers("IndirectParticipantApplicationServices", "IndirectParticipantREST")
            .whereLayer("IndirectParticipantApisInterface").mayOnlyBeAccessedByLayers("IndirectParticipantDomainServices", "IndirectParticipantApplicationServices", "LiquidityManagementApplicationServices", "LiquidityManagementDomainServices", "LiquidityManagementAdapter")
            .ignoreDependency(EVENT_ASSIGNABLES, DescribedPredicate.alwaysTrue())

            //Rules - ME
            .whereLayer("MainEngineREST").mayNotBeAccessedByAnyLayer()
            .whereLayer("MainEngineApisInterface").mayOnlyBeAccessedByLayers("MainEngineDomainServices", "LiquidityManagementApplicationServices", "LiquidityManagementDomainServices")
            .whereLayer("MainEngineApplicationServices").mayOnlyBeAccessedByLayers("MainEngineREST", "MainEngineApplicationServices", "IndirectParticipantApplicationServices")
            .whereLayer("MainEngineDomainServices").mayOnlyBeAccessedByLayers("MainEngineApplicationServices", "MainEngineDomainServices", "MainEngineAdapter", "MainEngineApisInterface", "LiquidityManagementDomainServices", "IndirectParticipantDomainServices", "IndirectParticipantApplicationServices")
            .whereLayer("MainEngineDomainModel").mayOnlyBeAccessedByLayers("MainEngineApplicationServices", "MainEngineDomainServices", "MainEngineDTO", "MainEnginePersistence", "LiquidityManagementApplicationServices", "LiquidityManagementDomainServices", "LiquidityManagementDomainModel", "LiquidityManagementPersistence", "MainEngineApisInterface", "LiquidityManagementDTO", "IndirectParticipantDomainModel", "IndirectParticipantPersistence", "IndirectParticipantDomainServices", "IndirectParticipantApplicationServices", "IndirectParticipantDTO")
            .whereLayer("MainEnginePersistence").mayOnlyBeAccessedByLayers("MainEngineDomainServices", "MainEngineApplicationServices", "IndirectParticipantDomainServices", "IndirectParticipantPersistence")
            .whereLayer("MainEngineDTO").mayOnlyBeAccessedByLayers("MainEngineREST", "MainEngineApplicationServices", "MainEngineDomainServices", "MainEnginePort", "MainEngineAdapter", "MainEngineException", "LiquidityManagementApplicationServices", "LiquidityManagementDomainServices", "LiquidityManagementDTO", "LiquidityManagementAdapter", "MainEngineApisInterface", "IndirectParticipantDTO", "IndirectParticipantDomainServices", "IndirectParticipantApplicationServices")
            .whereLayer("MainEngineException").mayOnlyBeAccessedByLayers("MainEngineApplicationServices", "MainEngineDomainServices", "LiquidityManagementApplicationServices", "LiquidityManagementDomainServices", "IndirectParticipantDomainServices")
            .whereLayer("MainEnginePort").mayOnlyBeAccessedByLayers("MainEngineDomainServices", "MainEngineAdapter")
            .whereLayer("MainEngineAdapter").mayNotBeAccessedByAnyLayer();

    @ArchTest
    public static final ArchRule nothingShouldDependOnAdapters = ArchRuleDefinition
            .noClasses()
            .that().resideOutsideOfPackages("..adapter..")
            .should().dependOnClassesThat().resideInAnyPackage("..adapter..");

    private static final GivenClassesConjunction allClassesExceptSpecialOnes = ArchRuleDefinition
            .classes()
            .that()
            .doNotHaveFullyQualifiedName(MainEngineApplication.class.getName())
            .and()
            .doNotHaveFullyQualifiedName(ArchitecturalConstraintsTest.class.getName())
            .and()
            .doNotHaveFullyQualifiedName(ArchitecturalConstraintsTest.class.getName() + "$1");

    @ArchTest
    public static final ArchRule everyClassMustBeInSomeAllowedPackage =
            allClassesExceptSpecialOnes
                    .should()
                    .resideInAnyPackage(
                            "..config..",
                            "..application.service..",
                            "..domain.service..",
                            "..domain.model..",
                            "..port..",
                            "..adapter..",
                            "..persistence..",
                            "..exception..",
                            "..message..",
                            "..dto..",
                            "..receive..",
                            "..schema..",
                            "..commons..",
                            "matera.spi.main.dto",
                            "..rest..",
                            "..apisInterface",
                            "matera.spi.utils..");

    @ArchTest
    public static final ArchRule adapterClassesShouldNotBeScannedByDefaultRule = ArchRuleDefinition
            .noClasses()
            .that().resideInAPackage("..adapter..")
            .should()
            .beAnnotatedWith(Component.class)
            .orShould()
            .beAnnotatedWith(Service.class)
            .orShould()
            .beAnnotatedWith(Repository.class);

    @ArchTest
    public static final ArchRule testClassesShouldNotUseMockBeanOrSpyBean = ArchRuleDefinition
        .noClasses()
        .that().areAnnotatedWith(SpringBootTest.class).or().areAnnotatedWith(IntegrationTest.class)
        .should().dependOnClassesThat().haveFullyQualifiedName("org.springframework.boot.test.mock.mockito.MockBean")
        .orShould().dependOnClassesThat().haveFullyQualifiedName("org.springframework.boot.test.mock.mockito.SpyBean");

    @ArchTest
    public static final ArchRule jpaDependencyRule = ArchRuleDefinition
            .noClasses()
            .that().resideOutsideOfPackages("..persistence..", "..domain.model..")
            .should().dependOnClassesThat().resideInAnyPackage("javax.persistence..", "org.springframework.data.jpa..");

    @ArchTest
    public static final ArchRule servletApiDependencyRule = ArchRuleDefinition
            .noClasses()
            .that()
                    .resideOutsideOfPackages("..rest..", "..commons..")
            .should().dependOnClassesThat().resideInAnyPackage("javax.servlet..", "..http..");

    // @formatter:on
}
