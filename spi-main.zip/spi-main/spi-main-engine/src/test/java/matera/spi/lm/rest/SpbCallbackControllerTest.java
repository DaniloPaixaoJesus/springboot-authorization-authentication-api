package matera.spi.lm.rest;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import matera.spi.commons.IntegrationTest;
import matera.spi.dto.DominioSistemaDTO;
import matera.spi.dto.SpbCallbackDTO;
import matera.spi.lm.domain.model.IpAccountAutoDepositEventEntity;
import matera.spi.lm.domain.model.spb.SpbEventEntity;
import matera.spi.lm.domain.model.spb.deposit.IpAccountDepositEventEntity;
import matera.spi.lm.domain.model.spb.withdraw.IpAccountWithdrawEventEntity;
import matera.spi.lm.persistence.IpAccountAutoDepositDetailsRepository;
import matera.spi.lm.persistence.SpbEventRepository;
import matera.spi.lm.persistence.SpbMessageRepository;
import matera.spi.main.apisInterface.EmailNotificationApiService;
import matera.spi.main.domain.model.BalanceAccountPiEntity;
import matera.spi.main.domain.model.EmailNotificationEntity;
import matera.spi.main.domain.model.event.EventTypeEntity;
import matera.spi.main.domain.service.EmailSenderService;
import matera.spi.main.email.dto.EmailDTO;
import matera.spi.main.email.port.EmailSender;
import matera.spi.main.persistence.BalanceAccountPiRepository;
import matera.spi.main.persistence.EventStatusTransitionRepository;
import matera.spi.main.persistence.EventTypeRepository;
import org.assertj.core.api.Assertions;
import org.eclipse.jetty.http.HttpStatus;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Spy;
import org.mockito.internal.util.collections.Sets;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.transaction.support.TransactionTemplate;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.util.ReflectionTestUtils.setField;

@IntegrationTest
public class SpbCallbackControllerTest {

    private static final String SPB_CALLBACK_BASE_URI = "/api/v1/eventos-retorno";

    private static final String LPI0006 = "LPI0006";
    private static final String LPI0006_PATH_SUCCESS = "lpi0006/lpi0006_EXAMPLE_SUCCESS.xml";
    private static final String LPI0006_XML_STRING_SUCCESS = getStringFromXmlFile(LPI0006_PATH_SUCCESS);

    private static final String LPI0006_PATH_ERROR = "lpi0006/lpi0006_EXAMPLE_ERROR.xml";
    private static final String LPI0006_XML_STRING_ERROR = getStringFromXmlFile(LPI0006_PATH_ERROR);

    @LocalServerPort
    private int port;

    @Autowired
    private EventTypeRepository eventTypeRepository;

    @Autowired
    private SpbEventRepository spbEventRepository;

    @Autowired
    private BalanceAccountPiRepository balanceRepository;

    @Autowired
    private EventStatusTransitionRepository eventStatusTransitionRepository;

    private List<BalanceAccountPiEntity> balances;

    @Autowired
    private EmailSender emailSender;

    @Spy
    private EmailSender emailSenderSpy;

    @Captor
    private ArgumentCaptor<EmailDTO> emailCaptor;

    @Autowired
    private EmailNotificationApiService emailNotificationApiService;

    @Spy
    private EmailNotificationApiService emailNotificationApiServiceSpy;

    @Autowired
    private SpbMessageRepository spbMessageRepository;

    @Autowired
    private TransactionTemplate transactionTemplate;

    @Autowired
    private EmailSenderService emailSenderService;

    @Autowired
    private IpAccountAutoDepositDetailsRepository ipAccountAutoDepositDetailsRepository;

    @BeforeEach
    void beforeEach() {
        RestAssured.port = port;
        balances = balanceRepository.findAll();
    }

    @AfterEach
    void afterEach() {
        eventStatusTransitionRepository.deleteAll();
        spbMessageRepository.deleteAll();
        spbEventRepository.deleteAll();
        ipAccountAutoDepositDetailsRepository.deleteAll();
        balanceRepository.deleteAll();
        balanceRepository.saveAll(balances);
    }

    @Test
    void shouldCreateDepositEventWhenRequested() {
        balanceRepository.saveAll(balances);
        createDepositSpbEvent();

        RestAssured
            .given()
                .contentType(ContentType.JSON)
                .body(buildSpbCallbackRequestDTO())
            .log().all()
            .when()
                .post(SPB_CALLBACK_BASE_URI)
            .then()
                .and()
                .statusCode(HttpStatus.OK_200);
    }

    @Test
    void shouldCreateWithdrawEventWhenRequested() {
        balanceRepository.saveAll(balances);
        createWithdrawSpbEvent();

        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(buildSpbCallbackRequestDTO())
            .log().all()
            .when()
            .post(SPB_CALLBACK_BASE_URI)
            .then()
            .and()
            .statusCode(HttpStatus.OK_200);
    }

    @Test
    void shouldCreateAutoDepositEvent() {
        setField(emailSenderService, "emailNotificationService", emailNotificationApiServiceSpy);
        setField(emailSenderService, "emailSender", emailSenderSpy);

        when(emailNotificationApiServiceSpy.findAll()).thenReturn(emailsDto());
        doNothing().when(emailSenderSpy).sendEmail(any());

        balanceRepository.saveAll(balances);

        SpbCallbackDTO spbCallbackDTO = buildSpbCallbackRequestDTO();
        spbCallbackDTO.setMessages(List.of(LPI0006_XML_STRING_SUCCESS));
        spbCallbackDTO.setTipoEvento(LPI0006);

        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(spbCallbackDTO)
            .log().all()
            .when()
            .post(SPB_CALLBACK_BASE_URI)
            .then()
            .statusCode(HttpStatus.OK_200);

        verify(emailSenderSpy).sendEmail(emailCaptor.capture());
        assertThat(emailCaptor.getValue().getSubject())
            .isNotNull()
            .isEqualTo("Operação realizada com sucesso - Aporte em conta PI própria fora da grade de operações (LPI0006)");

        assertAutoDepositEntity("7");

        setField(emailSenderService, "emailNotificationService", emailNotificationApiService);
        setField(emailSenderService, "emailSender", emailSender);
    }

    @Test
    void errorWhenTryToCreateAutoDepositEvent() {
        setField(emailSenderService, "emailNotificationService", emailNotificationApiServiceSpy);
        setField(emailSenderService, "emailSender", emailSenderSpy);
        when(emailNotificationApiServiceSpy.findAll()).thenReturn(emailsDto());
        doNothing().when(emailSenderSpy).sendEmail(any());

        balanceRepository.saveAll(balances);

        SpbCallbackDTO spbCallbackDTO = buildSpbCallbackRequestDTO();
        spbCallbackDTO.setMessages(List.of(LPI0006_XML_STRING_ERROR));
        spbCallbackDTO.setTipoEvento(LPI0006);
        spbCallbackDTO.setSituacaoNm(16);

        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(spbCallbackDTO)
            .log().all()
            .when()
            .post(SPB_CALLBACK_BASE_URI)
            .then()
            .statusCode(HttpStatus.OK_200);

        verify(emailSenderSpy).sendEmail(emailCaptor.capture());
        assertThat(emailCaptor.getValue().getSubject())
            .isNotNull()
            .isEqualTo("Operação realizada com erro - Aporte em conta PI própria fora da grade de operações (LPI0006)");

        assertAutoDepositEntity("16");

        setField(emailSenderService, "emailNotificationService", emailNotificationApiService);
        setField(emailSenderService, "emailSender", emailSender);
    }

    private void assertAutoDepositEntity(String situation) {
        transactionTemplate.execute(status -> {
            SpbEventEntity spbEventEntity = spbEventRepository.findAll().get(0);

            Assertions.assertThat(spbEventEntity).isNotNull();
            IpAccountAutoDepositEventEntity autoDepositEvent = (IpAccountAutoDepositEventEntity) spbEventEntity;

            assertSpbEventEntity(autoDepositEvent);
            assertAutoDepositDetails(autoDepositEvent, situation);
            return null;
        });
    }

    private void assertSpbEventEntity(IpAccountAutoDepositEventEntity spbEventEntity) {
        assertThat(spbEventEntity.getControlNumber()).isNotNull();
        assertThat(spbEventEntity.getMovementDate()).isNotNull();
        assertThat(spbEventEntity.getSpbEventId()).isNull();
        assertThat(spbEventEntity.getSpbMessageEntity()).hasOnlyOneElementSatisfying(spbMessage -> {
            assertThat(spbMessage.getMessageContents()).contains(LPI0006);
            assertThat(spbMessage.getMessageCode()).contains(LPI0006);
        });
        assertThat(spbEventEntity.getTransferResourceType()).isNull();
    }

    private void assertAutoDepositDetails(IpAccountAutoDepositEventEntity autoDepositEvent, String situation) {
        assertThat(autoDepositEvent.getIpAccountAutoDepositDetailsEntity()).isNotNull().satisfies(autoDepositDetails -> {
            assertThat(autoDepositDetails.getUuid()).isNotNull();
            assertThat(autoDepositDetails.getTransactionTimestampUtc()).isNotNull();
            assertThat(autoDepositDetails.getReceivers()).isEqualTo("email@domain.com");
            assertThat(autoDepositDetails.getSituation()).isEqualTo(situation);
        });
    }

    private void createDepositSpbEvent() {
        EventTypeEntity eventTypeEntity = eventTypeRepository.findById(10).orElseThrow(() -> new RuntimeException("EventType not found"));
        IpAccountDepositEventEntity spbEventEntity = new IpAccountDepositEventEntity();
        spbEventEntity.setSpbEventId(1L);
        spbEventEntity.setControlNumber("1a2b3c");
        spbEventEntity.setMovementDate(LocalDate.of(2020, 5, 11));
        spbEventEntity.setSpbMessageEntity(Sets.newSet());
        spbEventEntity.setValue(BigDecimal.TEN);
        spbEventEntity.setResponsible("Responsible");
        spbEventEntity.setInitiationTimestampUTC(LocalDateTime.now());
        spbEventEntity.setInitiatorIspb(1);
        spbEventEntity.setResponsible("ResponsibleOfEvent");
        spbEventEntity.setInitiatorIspb(12345678);
        spbEventEntity.setStatus(eventTypeEntity.getInitialStatus());

        spbEventRepository.saveAndFlush(spbEventEntity);
    }

    private void createWithdrawSpbEvent() {
        EventTypeEntity eventTypeEntity = eventTypeRepository.findById(10).orElseThrow(() -> new RuntimeException("EventType not found"));
        IpAccountWithdrawEventEntity spbEventEntity = new IpAccountWithdrawEventEntity();
        spbEventEntity.setSpbEventId(1L);
        spbEventEntity.setControlNumber("1a2b3c");
        spbEventEntity.setMovementDate(LocalDate.of(2020, 5, 11));
        spbEventEntity.setSpbMessageEntity(Sets.newSet());
        spbEventEntity.setValue(BigDecimal.TEN);
        spbEventEntity.setResponsible("Responsible");
        spbEventEntity.setInitiationTimestampUTC(LocalDateTime.now());
        spbEventEntity.setInitiatorIspb(1);
        spbEventEntity.setResponsible("ResponsibleOfEvent");
        spbEventEntity.setInitiatorIspb(12345678);
        spbEventEntity.setStatus(eventTypeEntity.getInitialStatus());

        spbEventRepository.saveAndFlush(spbEventEntity);
    }

    private SpbCallbackDTO buildSpbCallbackRequestDTO() {
        final SpbCallbackDTO spbCallbackDTO = new SpbCallbackDTO();
        spbCallbackDTO.setId(1l);
        spbCallbackDTO.setTipoEvento("LPI0001");
        spbCallbackDTO.setSituacaoNm(7);
        spbCallbackDTO.setMessages(List.of("<LPI0001R1><CodMsg>LPI0001R1</CodMsg></LPI0001R1>"));
        spbCallbackDTO.setOperacaoOrigemId1("OperacaoOrigemId1");
        spbCallbackDTO.setOperacaoOrigemId2("OperacaoOrigemId2");
        spbCallbackDTO.setDataHoraResposta("2020-08-10 17:25:30");
        spbCallbackDTO.setNumEmpresa(456);
        spbCallbackDTO.setDominioSistema(DominioSistemaDTO.SPB01);
        spbCallbackDTO.setSistemaOrigem("MIP");

        return spbCallbackDTO;
    }

    private List<EmailNotificationEntity> emailsDto() {
        EmailNotificationEntity emailNotificationDTO = new EmailNotificationEntity();
        emailNotificationDTO.setUuid(UUID.randomUUID());
        emailNotificationDTO.setEmail("email@domain.com");
        emailNotificationDTO.setDateTimeRegister(LocalDateTime.of(2020, 1, 1, 1, 1));
        emailNotificationDTO.setIdentification("identification");

        return Collections.singletonList(emailNotificationDTO);
    }
}
