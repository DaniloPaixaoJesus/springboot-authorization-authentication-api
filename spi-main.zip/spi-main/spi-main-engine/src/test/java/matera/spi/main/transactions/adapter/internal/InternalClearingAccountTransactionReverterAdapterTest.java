package matera.spi.main.transactions.adapter.internal;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.service.internal.InternalClearingAccountService;
import matera.spi.main.dto.event.transaction.AccountTransactionReverterDTO;
import matera.spi.main.dto.event.transaction.TransactionReverterDTO;
import matera.spi.main.transactions.port.AccountTransactionReverterPort;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;

@IntegrationTest
class InternalClearingAccountTransactionReverterAdapterTest  {

	@Autowired
	private InternalClearingAccountService clearingAccountService;

	@Autowired
	private AccountTransactionReverterPort debitReverter;

	@Test
	@DisplayName("should reverts the DEBIT done identified by a transaction id")
	void shouldRevertsBalanceWhenGivenTheLastDebitTransactionId() {
		BigDecimal debitValue = BigDecimal.valueOf(100);
		BigDecimal debitTransactionId = clearingAccountService.createDebitTransaction(debitValue);

		BigDecimal balanceBeforeDebitRevert = clearingAccountService.getCurrentBalance();

		TransactionReverterDTO transactionReverterDTO = TransactionReverterDTO.builder()
				.entryId(debitTransactionId)
				.build();

		AccountTransactionReverterDTO accountTransactionReverterDTO = AccountTransactionReverterDTO.builder().build().addReversals(transactionReverterDTO);

		debitReverter.revertDebit(accountTransactionReverterDTO);

		assertThat(balanceBeforeDebitRevert).isEqualTo(clearingAccountService.getCurrentBalance().subtract(debitValue));
	}
}
