package matera.spi.lm.rest;

import com.matera.spi.messaging.api.MessagesApi;
import com.matera.spi.messaging.api.SPIMessagingApis;
import com.matera.spi.messaging.model.MessageSentResponseDTO;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.PageableTransactionsDTO;
import matera.spi.dto.ResponseTransactionsDTO;
import matera.spi.dto.TransactionDTO;
import matera.spi.lm.domain.model.TransactionQueryEntity;
import matera.spi.lm.domain.model.event.TransactionQueryEventEntity;
import matera.spi.lm.persistence.TransactionQueryRepository;
import matera.spi.main.config.MainEngineConfiguration;
import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventTypeEntity;
import matera.spi.main.domain.model.event.transaction.TransactionEventEntity;
import matera.spi.main.domain.model.transaction.PaymentEntity;
import matera.spi.main.domain.model.transaction.ReceiptEntity;
import matera.spi.main.domain.service.MessageSender;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.EventTypeRepository;
import matera.spi.main.persistence.ParticipantRepository;
import matera.spi.main.persistence.PaymentRepository;
import matera.spi.main.persistence.ReceiptRepository;
import matera.spi.main.utils.FileUtils;
import matera.spi.main.utils.PaymentTransactionUtils;
import matera.spi.main.utils.ReceiptTransactionUtils;
import matera.spi.main.utils.constants.EventConstants;
import matera.spi.utils.LocalDateTimeUtils;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.opentest4j.AssertionFailedError;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.util.UriComponentsBuilder;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import static matera.spi.utils.LocalDateTimeUtils.formatToQueryParamPattern;
import static matera.spi.utils.LocalDateTimeUtils.getMaxLocalDateTime;
import static matera.spi.utils.LocalDateTimeUtils.getMinLocalDateTime;
import static matera.spi.utils.LocalDateTimeUtils.getTodayUTC;

import static net.javacrumbs.jsonunit.JsonMatchers.jsonEquals;
import static net.javacrumbs.jsonunit.JsonMatchers.jsonNodePresent;
import static org.hamcrest.Matchers.comparesEqualTo;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;

@IntegrationTest
public class TransactionsApiControllerTest  {

    protected Integer ISPB_NUMBER = 0;
    protected static final String HTTP_LOCALHOST = "http://localhost:";
    protected static final String PAYMENT = "/payment";
    protected static final String RECEIPT = "/receipt";
    protected static final String TRANSACTION_DETAILS_QUERY_PATH = "/ui/v1/transaction/details/queries";

    private final Integer INTEGER_ZERO = 0;
    private final Integer INTEGER_ONE = 1;
    private final Integer INTEGER_TWO = 2;
    private final Long LONG_ONE = 1L;
    private final Long LONG_TWO = 2L;

    private final String RESPONSE_TRANSACTIONS_DETAILS_LIST = FileUtils.getStringFromJsonFile(
        "transactions/response_find_all_transactions.json");

    @LocalServerPort
    protected int port;

    @Autowired
    protected TestRestTemplate testRestTemplate;

    @Autowired
    private PaymentTransactionUtils paymentUtils;

    @Autowired
    private ReceiptTransactionUtils receiptUtils;

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private ReceiptRepository receiptRepository;

    @Autowired
    private TransactionQueryRepository transactionQueryRepository;

    @Autowired
    private EventRepository eventRepository;

    @Autowired
    private EventTypeRepository eventTypeRepository;

    @Autowired
    private ParticipantRepository participantRepository;

    @Autowired
    private MainEngineConfiguration mainEngineConfiguration;

    @Autowired
    private MessageSender messageSender;
    @Autowired
    private SPIMessagingApis spiMessagingApisBean;
    @Mock
    private SPIMessagingApis mockedSpiMessagingApis;
    @Mock
    private MessagesApi mockedMessagesApi;

    private Map<String, String> urlVariables = new HashMap<>();

    @BeforeEach
    void init() {
        RestAssured.port = port;
        urlVariables.put("movimentDate", getTodayUTC().toString());
        urlVariables.put("startTimestampUtc", formatToQueryParamPattern(getMinLocalDateTime(getTodayUTC())));
        urlVariables.put("endTimestampUtc", formatToQueryParamPattern(getMaxLocalDateTime(getTodayUTC())));

        when(mockedSpiMessagingApis.messagesApi()).thenReturn(mockedMessagesApi);
        messageSender.setSpiMessagingApis(mockedSpiMessagingApis);
    }

    @AfterEach
    void clearDataBase() {
        ISPB_NUMBER = 0;
        urlVariables.clear();
        paymentUtils.deleteAllInsertedValues();
        receiptUtils.deleteAllInsertedValues();

        messageSender.setSpiMessagingApis(spiMessagingApisBean);
    }

    @Test
    void testReceiptEndPoint() {
        final HttpHeaders headers = getCustomHeaders(0, 100);
        final String url = buildUri(RECEIPT);
        final ResponseEntity<ResponseTransactionsDTO> responseEntity = testRestTemplate.exchange(url,
                                                                                                 HttpMethod.GET,
                                                                                                 new HttpEntity(headers),
                                                                                                 ResponseTransactionsDTO.class);
        assertThat(responseEntity.getStatusCode(), is(HttpStatus.OK));
    }

    @Test
    void shouldReturnOnlyOneReceiptValueWhenSendValidRequestWithMinValueFilter() throws InterruptedException {
        urlVariables.put("minValue", "110");
        final ReceiptEntity receiptEntity1 = receiptUtils.newReceiptEntity(new BigDecimal("120"),
                                                                           EventConstants.EVENT_STATUS_RECEIPT_RECEIVED);
        Thread.sleep(1000);
        final ReceiptEntity receiptEntity2 = receiptUtils.newReceiptEntity(new BigDecimal("100"),
                                                                           EventConstants.EVENT_STATUS_RECEIPT_REJECTED_BY_CLEARING);
        final ResponseEntity<ResponseTransactionsDTO> responseEntity = getResponseEntityReceiptTransactions(0, 1);
        assertThat(responseEntity.getStatusCode(), is(HttpStatus.OK));

        @Valid final PageableTransactionsDTO pageableReturned = responseEntity.getBody().getData();
        assertNotNull(pageableReturned);
        assertThat(pageableReturned.getNumber(), is(INTEGER_ZERO));
        assertThat(pageableReturned.getSize(), is(INTEGER_ONE));
        assertThat(pageableReturned.getTotalPages(), is(INTEGER_ONE));
        assertThat(pageableReturned.getTotalElements(), is(LONG_ONE));
        assertThat(pageableReturned.getLast(), is(TRUE));
        assertThat(pageableReturned.getFirst(), is(TRUE));
        assertThat(pageableReturned.getNumber(), is(INTEGER_ZERO));
        assertThat(pageableReturned.getNumberOfElements(), is(INTEGER_ONE));
        assertThat(pageableReturned.getSize(), is(INTEGER_ONE));
        assertThat(pageableReturned.getEmpty(), is(FALSE));
    }

    @Test
    void shouldReturnOnlyOneValueWhenSendValidRequestWithMinValueFilter() throws InterruptedException {
        urlVariables.put("minValue", "110");
        final PaymentEntity savedPayment1 = paymentUtils.newPaymentEntity(new BigDecimal("120"), EventConstants.EVENT_STATUS_SUCCESS);
        Thread.sleep(1000);
        final PaymentEntity savedPayment2 = paymentUtils.newPaymentEntity(new BigDecimal("100"), EventConstants.EVENT_STATUS_ERROR);
        final ResponseEntity<ResponseTransactionsDTO> responseEntity = getResponseEntityPaymentTransactions(0, 1);
        assertThat(responseEntity.getStatusCode(), is(HttpStatus.OK));

        @Valid final PageableTransactionsDTO pageableReturned = responseEntity.getBody().getData();
        assertNotNull(pageableReturned);
        assertThat(pageableReturned.getNumber(), is(INTEGER_ZERO));
        assertThat(pageableReturned.getSize(), is(INTEGER_ONE));
        assertThat(pageableReturned.getTotalPages(), is(INTEGER_ONE));
        assertThat(pageableReturned.getTotalElements(), is(LONG_ONE));
        assertThat(pageableReturned.getLast(), is(TRUE));
        assertThat(pageableReturned.getFirst(), is(TRUE));
        assertThat(pageableReturned.getNumber(), is(INTEGER_ZERO));
        assertThat(pageableReturned.getNumberOfElements(), is(INTEGER_ONE));
        assertThat(pageableReturned.getSize(), is(INTEGER_ONE));
        assertThat(pageableReturned.getEmpty(), is(FALSE));

        @NotNull @Valid final List<TransactionDTO> content = pageableReturned.getContent();
        assertNotNull(content);
        assertThat(content, hasSize(INTEGER_ONE));
        assertPaymentContentDTO(content.get(0), savedPayment1);
    }

    @Test
    void shouldReturnOnlyOneValueWhenSendValidRequestWithMaxValueFilter() throws InterruptedException {
        urlVariables.put("maxValue", "110");
        final PaymentEntity savedPayment1 = paymentUtils.newPaymentEntity(new BigDecimal("120"), EventConstants.EVENT_STATUS_SUCCESS);
        Thread.sleep(1000);
        final PaymentEntity savedPayment2 = paymentUtils.newPaymentEntity(new BigDecimal("100"), EventConstants.EVENT_STATUS_ERROR);
        final ResponseEntity<ResponseTransactionsDTO> responseEntity = getResponseEntityPaymentTransactions(0, 1);
        assertThat(responseEntity.getStatusCode(), is(HttpStatus.OK));

        @Valid final PageableTransactionsDTO pageableReturned = responseEntity.getBody().getData();
        assertNotNull(pageableReturned);
        assertThat(pageableReturned.getNumber(), is(INTEGER_ZERO));
        assertThat(pageableReturned.getSize(), is(INTEGER_ONE));
        assertThat(pageableReturned.getTotalPages(), is(INTEGER_ONE));
        assertThat(pageableReturned.getTotalElements(), is(LONG_ONE));
        assertThat(pageableReturned.getLast(), is(TRUE));
        assertThat(pageableReturned.getFirst(), is(TRUE));
        assertThat(pageableReturned.getNumber(), is(INTEGER_ZERO));
        assertThat(pageableReturned.getNumberOfElements(), is(INTEGER_ONE));
        assertThat(pageableReturned.getSize(), is(INTEGER_ONE));
        assertThat(pageableReturned.getEmpty(), is(FALSE));

        @NotNull @Valid final List<TransactionDTO> content = pageableReturned.getContent();
        assertNotNull(content);
        assertThat(content, hasSize(INTEGER_ONE));
        assertPaymentContentDTO(content.get(0), savedPayment2);
    }

    @Test
    void shouldReturnRegistersAccordingIspbNumberFilteringWhenIsAPayment() throws InterruptedException {
        ISPB_NUMBER = 4715685;
        final Optional<ParticipantEntity> payerParticipant = participantRepository.findByIspb(ISPB_NUMBER);
        final PaymentEntity savedPayment1 = paymentUtils.newPaymentEntity(new BigDecimal("120"), EventConstants.EVENT_STATUS_SUCCESS);
        Thread.sleep(1000);

        final PaymentEntity savedPayment2 = paymentUtils.newPaymentEntity(new BigDecimal("100"), EventConstants.EVENT_STATUS_ERROR);
        savedPayment2.setPayerParticipant(payerParticipant.get());
        paymentRepository.saveAndFlush(savedPayment2);
        final ResponseEntity<ResponseTransactionsDTO> responseEntity = getResponseEntityPaymentTransactions(0, 1);
        assertThat(responseEntity.getStatusCode(), is(HttpStatus.OK));

        @Valid final PageableTransactionsDTO pageableReturned = responseEntity.getBody().getData();
        assertNotNull(pageableReturned);
        assertThat(pageableReturned.getNumber(), is(INTEGER_ZERO));
        assertThat(pageableReturned.getSize(), is(INTEGER_ONE));
        assertThat(pageableReturned.getTotalPages(), is(INTEGER_ONE));
        assertThat(pageableReturned.getTotalElements(), is(LONG_ONE));
        assertThat(pageableReturned.getLast(), is(TRUE));
        assertThat(pageableReturned.getFirst(), is(TRUE));
        assertThat(pageableReturned.getNumber(), is(INTEGER_ZERO));
        assertThat(pageableReturned.getNumberOfElements(), is(INTEGER_ONE));
        assertThat(pageableReturned.getSize(), is(INTEGER_ONE));
        assertThat(pageableReturned.getEmpty(), is(FALSE));

        @NotNull @Valid final List<TransactionDTO> content = pageableReturned.getContent();
        assertNotNull(content);
        assertThat(content, hasSize(INTEGER_ONE));
        assertPaymentContentDTO(content.get(0), savedPayment1);
    }

    @Test
    void shouldReturnRegistersFiltredByEventStatus() throws InterruptedException {
        urlVariables.put("status", "1");
        final PaymentEntity savedPayment1 = paymentUtils.newPaymentEntity(new BigDecimal("120"), EventConstants.EVENT_STATUS_SUCCESS);
        Thread.sleep(1000);

        final PaymentEntity savedPayment2 = paymentUtils.newPaymentEntity(new BigDecimal("100"),
                                                                          EventConstants.EVENT_STATUS_PAYMENT_INITIALIZED);
        final ResponseEntity<ResponseTransactionsDTO> responseEntity = getResponseEntityPaymentTransactions(0, 1);
        assertThat(responseEntity.getStatusCode(), is(HttpStatus.OK));

        @Valid final PageableTransactionsDTO pageableReturned = responseEntity.getBody().getData();
        assertNotNull(pageableReturned);
        assertThat(pageableReturned.getNumber(), is(INTEGER_ZERO));
        assertThat(pageableReturned.getSize(), is(INTEGER_ONE));
        assertThat(pageableReturned.getTotalPages(), is(INTEGER_ONE));
        assertThat(pageableReturned.getTotalElements(), is(LONG_ONE));
        assertThat(pageableReturned.getLast(), is(TRUE));
        assertThat(pageableReturned.getFirst(), is(TRUE));
        assertThat(pageableReturned.getNumber(), is(INTEGER_ZERO));
        assertThat(pageableReturned.getNumberOfElements(), is(INTEGER_ONE));
        assertThat(pageableReturned.getSize(), is(INTEGER_ONE));
        assertThat(pageableReturned.getEmpty(), is(FALSE));

        @NotNull @Valid final List<TransactionDTO> content = pageableReturned.getContent();
        assertNotNull(content);
        assertThat(content, hasSize(INTEGER_ONE));
        assertPaymentContentDTO(content.get(0), savedPayment1);
    }

    @Test
    void shouldReturnOKWhenSendValidRequest() throws InterruptedException {
        final PaymentEntity savedPayment1 = paymentUtils.newPaymentEntity(new BigDecimal("120"), EventConstants.EVENT_STATUS_SUCCESS);
        Thread.sleep(1000);
        final PaymentEntity savedPayment2 = paymentUtils.newPaymentEntity(new BigDecimal("100"), EventConstants.EVENT_STATUS_ERROR);
        final ResponseEntity<ResponseTransactionsDTO> responseEntity = getResponseEntityPaymentTransactions(0, 1);
        assertThat(responseEntity.getStatusCode(), is(HttpStatus.OK));

        @Valid final PageableTransactionsDTO pageableReturned = responseEntity.getBody().getData();
        assertNotNull(pageableReturned);
        assertThat(pageableReturned.getNumber(), is(INTEGER_ZERO));
        assertThat(pageableReturned.getSize(), is(INTEGER_ONE));
        assertThat(pageableReturned.getTotalPages(), is(INTEGER_TWO));
        assertThat(pageableReturned.getTotalElements(), is(LONG_TWO));
        assertThat(pageableReturned.getLast(), is(FALSE));
        assertThat(pageableReturned.getFirst(), is(TRUE));
        assertThat(pageableReturned.getNumber(), is(INTEGER_ZERO));
        assertThat(pageableReturned.getNumberOfElements(), is(INTEGER_ONE));
        assertThat(pageableReturned.getSize(), is(INTEGER_ONE));
        assertThat(pageableReturned.getEmpty(), is(FALSE));

        @NotNull @Valid final List<TransactionDTO> content = pageableReturned.getContent();
        assertNotNull(content);
        assertThat(content, hasSize(INTEGER_ONE));
        assertPaymentContentDTO(content.get(0), savedPayment2);
    }

    @Test
    void shouldCreateTransactionDetailsQuery() throws JSONException {
        String endToEndId = "E00038166201907261559y6j6mt9l0pi";

        eventRepository.deleteAll();
        Mockito.when(mockedMessagesApi.sendsMessageV1(Mockito.any())).thenReturn(getMessageSentResponseDTO());
        JSONObject requestBody = new JSONObject().put("endToEndId", endToEndId);

        String responseBody = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(requestBody.toString())
            .when()
            .post(TRANSACTION_DETAILS_QUERY_PATH)
            .thenReturn()
            .body()
            .asString();

        List<EventEntity> allEvents = eventRepository.findAll();
        assertThat(allEvents, hasSize(1));
        TransactionQueryEventEntity transactionEvent = (TransactionQueryEventEntity) allEvents.get(0);

        assertThat(transactionEvent.getStatus().getCode(), is(14));
        assertThat(transactionEvent.getStatus().getDescription(), is("Query sent"));
        assertThat(transactionEvent.getTransactionQueryEntity().getEndToEndID(), is(endToEndId));

        assertThat(responseBody, jsonNodePresent("data.eventUuid"));

        eventRepository.deleteAll();
    }

    @Test
    void shouldCreateTransactionDetailsQueryWithEndToEndIdThatStartsWithSTR() throws JSONException {
        String endToEndId = "STR20200608000001230";

        eventRepository.deleteAll();
        Mockito.when(mockedMessagesApi.sendsMessageV1(Mockito.any())).thenReturn(getMessageSentResponseDTO());
        JSONObject requestBody = new JSONObject().put("endToEndId", endToEndId);

        String responseBody = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(requestBody.toString())
            .when()
            .post(TRANSACTION_DETAILS_QUERY_PATH)
            .thenReturn()
            .body()
            .asString();

        List<EventEntity> allEvents = eventRepository.findAll();
        assertThat(allEvents, hasSize(1));
        TransactionQueryEventEntity transactionEvent = (TransactionQueryEventEntity) allEvents.get(0);

        assertThat(transactionEvent.getStatus().getCode(), is(14));
        assertThat(transactionEvent.getStatus().getDescription(), is("Query sent"));
        assertThat(transactionEvent.getTransactionQueryEntity().getEndToEndID(), is(endToEndId));

        assertThat(responseBody, jsonNodePresent("data.eventUuid"));

        eventRepository.deleteAll();
    }

    @Test
    void shouldReturnAllTransactions() {
        createTransactions();

        String responseBody = RestAssured.given()
            .queryParam("startTimestampUtc", "2020-01-03T00:00:00")
            .queryParam("endTimestampUtc", "2020-01-04T00:00:00")
            .header("pageSize", 10)
            .header("pageNumber", 0)
            .when()
            .get(TRANSACTION_DETAILS_QUERY_PATH)
            .thenReturn()
            .body()
            .asString();

        assertThat(RESPONSE_TRANSACTIONS_DETAILS_LIST,
            jsonEquals(responseBody).whenIgnoringPaths("data.content[0].mipEvent.eventUUID"));
    }

    @Test
    void shouldReturnRegistersAccordingIspbNumberFilteringWhenIsAReceipt() throws InterruptedException {
        ISPB_NUMBER = 4715685;
        final Optional<ParticipantEntity> receiptParticipant = participantRepository.findByIspb(ISPB_NUMBER);
        final ReceiptEntity receiptEntity1 = receiptUtils.newReceiptEntity(new BigDecimal("120"), EventConstants.EVENT_STATUS_RECEIPT_RECEIVED);
        Thread.sleep(1000);

        final ReceiptEntity receiptEntity2 = receiptUtils.newReceiptEntity(new BigDecimal("100"), EventConstants.EVENT_STATUS_RECEIPT_REJECTED_BY_CLEARING);
        receiptEntity2.setReceiverParticipant(receiptParticipant.get());
        receiptRepository.saveAndFlush(receiptEntity2);
        final ResponseEntity<ResponseTransactionsDTO> responseEntity = getResponseEntityReceiptTransactions(0, 1);
        assertThat(responseEntity.getStatusCode(), is(HttpStatus.OK));

        @Valid final PageableTransactionsDTO pageableReturned = responseEntity.getBody().getData();
        assertNotNull(pageableReturned);
        assertThat(pageableReturned.getNumber(), is(INTEGER_ZERO));
        assertThat(pageableReturned.getSize(), is(INTEGER_ONE));
        assertThat(pageableReturned.getTotalPages(), is(INTEGER_ONE));
        assertThat(pageableReturned.getTotalElements(), is(LONG_ONE));
        assertThat(pageableReturned.getLast(), is(TRUE));
        assertThat(pageableReturned.getFirst(), is(TRUE));
        assertThat(pageableReturned.getNumber(), is(INTEGER_ZERO));
        assertThat(pageableReturned.getNumberOfElements(), is(INTEGER_ONE));
        assertThat(pageableReturned.getSize(), is(INTEGER_ONE));
        assertThat(pageableReturned.getEmpty(), is(FALSE));

        @NotNull @Valid final List<TransactionDTO> content = pageableReturned.getContent();
        assertNotNull(content);
        assertThat(content, hasSize(INTEGER_ONE));
        assertReceiptContentDTO(content.get(0), receiptEntity1);
    }

    private void createTransactions() {
        TransactionQueryEntity transactionQueryEntity = new TransactionQueryEntity();
        transactionQueryEntity.setEndToEndID("EndToEndId");
        transactionQueryEntity.setType("C");
        transactionQueryEntity.setEffectiveTimestamp(LocalDateTime.of(2020, 1, 3, 10, 14, 25));
        transactionQueryEntity.setValue(BigDecimal.TEN);
        transactionQueryEntity.setIspbDebtor("13370835");
        transactionQueryEntity.setIspbCreditor("00255564");

        EventTypeEntity eventTypeEntity = eventTypeRepository.findById(1)
                                                             .orElseThrow(() -> new AssertionFailedError("Not found EventType"));

        TransactionQueryEventEntity expectedEvent = new TransactionQueryEventEntity();
        expectedEvent.setCorrelationId("E00539039202002170828063aec68f6e");
        expectedEvent.setClearingTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
        expectedEvent.setInitiationTimestampUTC(LocalDateTime.of(2020, 1, 3, 12, 23, 3));
        expectedEvent.setResponsible("SOME RESPONSIBLE");
        expectedEvent.setInitiatorIspb(12345);
        expectedEvent.setValue(BigDecimal.ONE);
        expectedEvent.setEventTypeEntity(eventTypeEntity);
        expectedEvent.setStatus(eventTypeEntity.getInitialStatus());
        expectedEvent.setTransactionQueryEntity(transactionQueryEntity);
        eventRepository.saveAndFlush(expectedEvent);
    }

    private void assertPaymentContentDTO(TransactionDTO actual, PaymentEntity expected) {
        final TransactionEventEntity expectedEvent = expected.getEvent();
        assertThat(actual.getTransactionId(), is(expected.getId()));
        assertThat(actual.getEventId(), is(expectedEvent.getId()));
        assertThat(actual.getEndToEndId(), is(expected.getEndToEndId()));
        assertThat(actual.getPayerCpfCnpj(), is(expected.getPayerAccount().getTaxId()));
        assertThat(actual.getReceiverCpfCnpj(), is(expected.getReceiverAccount().getTaxId()));
        assertThat(actual.getPaymentTimestamp(), is(expectedEvent.getInitiationTimestampUTC()));
        assertThat(actual.getEventStatus().getCode(), is(expectedEvent.getStatus().getCode()));
        assertThat(actual.getEventStatus().getDescription(), is(expectedEvent.getStatus().getDescription()));
        assertThat(actual.getValue(), comparesEqualTo(expectedEvent.getValue()));
    }

    private void assertReceiptContentDTO(TransactionDTO actual, ReceiptEntity expected) {
        final TransactionEventEntity expectedEvent = expected.getEvent();
        assertThat(actual.getTransactionId(), is(expected.getId()));
        assertThat(actual.getEventId(), is(expectedEvent.getId()));
        assertThat(actual.getEndToEndId(), is(expected.getEndToEndId()));
        assertThat(actual.getPayerCpfCnpj(), is(expected.getPayerAccount().getTaxId()));
        assertThat(actual.getReceiverCpfCnpj(), is(expected.getReceiverAccount().getTaxId()));
        assertThat(actual.getPaymentTimestamp(), is(expectedEvent.getInitiationTimestampUTC()));
        assertThat(actual.getEventStatus().getCode(), is(expectedEvent.getStatus().getCode()));
        assertThat(actual.getEventStatus().getDescription(), is(expectedEvent.getStatus().getDescription()));
        assertThat(actual.getValue(), comparesEqualTo(expectedEvent.getValue()));
    }

    private HttpHeaders getCustomHeaders(Integer pageNumber, Integer pageSize) {
        final HttpHeaders headers = new HttpHeaders();
        headers.set("pageSize", String.valueOf(pageSize));
        headers.set("pageNumber", String.valueOf(pageNumber));

        return headers;
    }

    private ResponseEntity<ResponseTransactionsDTO> getResponseEntityPaymentTransactions(Integer pageNumber, Integer pageSize) {
        final HttpHeaders headers = getCustomHeaders(pageNumber, pageSize);
        return testRestTemplate.exchange(buildUri(PAYMENT), HttpMethod.GET, new HttpEntity(headers), ResponseTransactionsDTO.class);
    }

    private String buildUri(String transactionType) {
        final String PATH_TO_IP_ACCOUNT_BALANCE = "/ui/v1/psp/transactions";
        final UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder.fromHttpUrl(HTTP_LOCALHOST + port + PATH_TO_IP_ACCOUNT_BALANCE + transactionType);
        urlVariables.entrySet().forEach(entry -> uriComponentsBuilder.queryParam(entry.getKey(), entry.getValue()));
        return uriComponentsBuilder.toUriString();
    }

    private ResponseEntity<ResponseTransactionsDTO> getResponseEntityReceiptTransactions(Integer pageNumber, Integer pageSize) {
        final HttpHeaders headers = getCustomHeaders(pageNumber, pageSize);
        return testRestTemplate.exchange(buildUri(RECEIPT), HttpMethod.GET, new HttpEntity(headers), ResponseTransactionsDTO.class);
    }

    private MessageSentResponseDTO getMessageSentResponseDTO() {
        MessageSentResponseDTO responseDto = new MessageSentResponseDTO();
        responseDto.setPiResourceID("PIResourceID");
        return responseDto;
    }
}
