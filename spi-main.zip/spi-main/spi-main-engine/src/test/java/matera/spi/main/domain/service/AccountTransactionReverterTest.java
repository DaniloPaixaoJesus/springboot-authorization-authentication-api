package matera.spi.main.domain.service;

import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.transaction.ReceiptEventEntity;
import matera.spi.main.domain.model.transaction.ReceiptEntity;
import matera.spi.main.domain.model.transaction.TransactionResultEntity;
import matera.spi.main.domain.service.transaction.AccountTransactionReverter;
import matera.spi.main.dto.event.transaction.AccountTransactionReverterDTO;
import matera.spi.main.persistence.TransactionResultRepository;
import matera.spi.main.transactions.port.AccountTransactionReverterPort;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class AccountTransactionReverterTest {

    public static final BigDecimal TRANSACTION_ID_IN_DDA_SYSTEM = BigDecimal.valueOf(123456L);
    @InjectMocks
    private AccountTransactionReverter accountTransactionReverter;

    @Mock
    private TransactionResultRepository transactionResultRepository;

    @Mock
    private AccountTransactionReverterPort accountTransactionReverterAdapter;

    @Test
    void shouldRevertEventEntityWithAccountTransactionResult() {
        EventEntity eventEntity = createReceiptEventEntityWithAccountTransactionResult();
        accountTransactionReverter.revert(eventEntity);

        verify(transactionResultRepository).saveAndFlush(any(TransactionResultEntity.class));
        verifyNoMoreInteractions(transactionResultRepository);

        verify(accountTransactionReverterAdapter).revertDebit(any(AccountTransactionReverterDTO.class));
        verifyNoMoreInteractions(accountTransactionReverterAdapter);
    }

    @Test
    void shouldRevertEventEntityWithCustomerTransactionResult() {
        EventEntity eventEntity = createReceiptEventEntityWithCustomerTransactionResult();
        accountTransactionReverter.revert(eventEntity);

        verify(transactionResultRepository, times(2)).saveAndFlush(any(TransactionResultEntity.class));
        verifyNoMoreInteractions(transactionResultRepository);

        verify(accountTransactionReverterAdapter,  times(1)).revertDebit(any(AccountTransactionReverterDTO.class));
        verifyNoMoreInteractions(accountTransactionReverterAdapter);
    }

    @Test
    void shouldRevertEventEntityWithIpAccountTransactionResult() {
        EventEntity eventEntity = createReceiptEventEntityWithIpAccountTransactionResult();
        accountTransactionReverter.revert(eventEntity);

        verify(transactionResultRepository, times(3)).saveAndFlush(any(TransactionResultEntity.class));
        verifyNoMoreInteractions(transactionResultRepository);

        verify(accountTransactionReverterAdapter,  times(1)).revertDebit(any(AccountTransactionReverterDTO.class));
        verifyNoMoreInteractions(accountTransactionReverterAdapter);
    }

    private ReceiptEventEntity createReceiptEventEntityWithAccountTransactionResult(){
        ReceiptEventEntity eventEntity = new ReceiptEventEntity();
        eventEntity.setReceiptEntity(new ReceiptEntity());
        TransactionResultEntity transactionResult = new TransactionResultEntity();
        transactionResult.setReverted(false);
        eventEntity.setTransactionResult(transactionResult);
        eventEntity.getTransactionResult().setTransactionIdInDdaSystem(TRANSACTION_ID_IN_DDA_SYSTEM);
        return eventEntity;
    }

    private ReceiptEventEntity createReceiptEventEntityWithCustomerTransactionResult(){
        ReceiptEventEntity eventEntity = createReceiptEventEntityWithAccountTransactionResult();
        eventEntity.setReceiptEntity(new ReceiptEntity());
        TransactionResultEntity customerTransactionResult = new TransactionResultEntity();
        customerTransactionResult.setReverted(false);
        eventEntity.getReceiptEntity().setCustomerTransactionResult(customerTransactionResult);
        eventEntity.getReceiptEntity().getCustomerTransactionResult().setTransactionIdInDdaSystem(TRANSACTION_ID_IN_DDA_SYSTEM);
        eventEntity.getTransactionEntity().setPayerParticipant(new ParticipantEntity());
        return eventEntity;
    }

    private EventEntity createReceiptEventEntityWithIpAccountTransactionResult(){
        ReceiptEventEntity eventEntity = createReceiptEventEntityWithCustomerTransactionResult();
        TransactionResultEntity ipAccountTransactionResult = new TransactionResultEntity();
        ipAccountTransactionResult.setReverted(false);
        eventEntity.setIpAccountTransactionResult(ipAccountTransactionResult);
        eventEntity.getIpAccountTransactionResult().setTransactionIdInDdaSystem(TRANSACTION_ID_IN_DDA_SYSTEM);
        return eventEntity;
    }
}
