package matera.spi.main.application.service;

import com.matera.commons.utils.exception.BusinessException;

import matera.spi.dto.AccountTypeUIDTO;
import matera.spi.dto.EndToEndIDRequestDTO;
import matera.spi.dto.EndToEndResponseDTO;
import matera.spi.dto.InstantPaymentSettlementResponseUIDTO;
import matera.spi.dto.InstantPaymentsUIDTO;
import matera.spi.dto.PayerUIDTO;
import matera.spi.dto.PaymentsUIDTO;
import matera.spi.dto.ReceiverUIDTO;
import matera.spi.dto.RemoteAccountUIDTO;
import matera.spi.main.config.MainEngineConfiguration;
import matera.spi.main.domain.model.ConfigEntity;
import matera.spi.main.domain.model.event.transaction.PaymentEventEntity;
import matera.spi.main.domain.model.transaction.PaymentEntity;
import matera.spi.main.domain.service.ConfigurationService;
import matera.spi.main.domain.service.PaymentService;
import matera.spi.main.domain.service.event.transaction.PaymentEvent;
import matera.spi.main.domain.service.messaging.MessagingAvailabilityChecker;
import matera.spi.main.domain.service.participants.IntraMipVerifier;
import matera.spi.main.dto.SendPaymentsDTO;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.transactions.port.AccountTransactionExecutorPort;

import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PaymentsServiceTest {

	private static final Integer LENGTH_ISPB_EIGHT = 12345678;
	private static final Integer LENGTH_ISPB_FOUR = 1234;
	private static final String PREFIX_TO_COMPARE_ISPB_FOUR = "E00001234";

	public static final String ADDRESSING_KEY = "ADDRESSING_KEY";
	public static final int RECEIVER_ISPB = 250699;
	public static final String RECEIVER_TAX_ID = "11707205795";

	public static final int PAYER_ISPB = 13370835;
    public static final String PAYER_NAME = "TESTE NAME";
	public static final String PAYER_ACCOUNT = "99999999";
	public static final String PAYER_BRANCH = "1234";
	public static final String PAYER_TAX_ID = "11707205795";

	public static final String RECEIVER_ACCOUNT = "35";
	public static final String RECEIVER_BRANCH = "1";

    private static final String SETTLEMENT_METHOD = "CLRG";
    private static final String TRANSACTION_CODE = "HIGH";

	public static final long ORGANISATION_IDENTIFICATION = 89784628000139L;

    @Mock
    private AccountTransactionExecutorPort accountTransactionExecutorPort;

    @Mock
    private EventRepository eventRepository;

	@Mock
	private PaymentFactory paymentFactory;

    @Mock
	private ConfigurationService configurationService;

    @Mock
    private MainEngineConfiguration mainEngineConfiguration;

	@Mock
    private MessagingAvailabilityChecker messagingAvailabilityChecker;

    @InjectMocks
    private PaymentService paymentService;

    @Spy
    private PaymentsValidatorHelper paymentsValidatorHelper;

    @InjectMocks
    private PaymentsHelper paymentHelper;

    @Mock
    private IntraMipVerifier intraMipVerifier;

	private PaymentsService paymentsService;

    @BeforeEach
    public void setUp() {
        ReflectionTestUtils.setField(paymentsValidatorHelper, "configurationService", configurationService);
        ReflectionTestUtils.setField(paymentsValidatorHelper, "mainEngineConfiguration", mainEngineConfiguration);

        paymentsService = new PaymentsService(paymentsValidatorHelper, paymentHelper, paymentService, intraMipVerifier);
    }

	@Test
	void shouldGetAEndToEndIDWhenLengthIspbIsEight() {
		EndToEndResponseDTO endToEndResponseDTO = paymentsService.getEndToEndID(new EndToEndIDRequestDTO().ispb(LENGTH_ISPB_EIGHT));

		Assertions.assertNotNull(endToEndResponseDTO);
		Assertions.assertNotNull(endToEndResponseDTO.getEndToEndID());
	}

	@Test
	void shouldGetAEndToEndIDWhenLengthIspbForLessThanEight() {
		EndToEndResponseDTO endToEndResponseDTO = paymentsService.getEndToEndID(new EndToEndIDRequestDTO().ispb(LENGTH_ISPB_FOUR));

		Assertions.assertNotNull(endToEndResponseDTO);
		Assertions.assertNotNull(endToEndResponseDTO.getEndToEndID());
		Assertions.assertTrue(endToEndResponseDTO.getEndToEndID().startsWith(PREFIX_TO_COMPARE_ISPB_FOUR));
	}

	@Test
	void shouldThrowBusinessExceptionWhenTransactionValueIsEqualZero() {

        PaymentsUIDTO payment = new PaymentsUIDTO().interbankSettlementAmount(BigDecimal.ZERO);
        payment.setPayer(createPayerUIDTOMock());
        payment.setReceiver(createReceiverUIDTOMock());

		InstantPaymentsUIDTO instantPaymentsUIDTO = new InstantPaymentsUIDTO();
		instantPaymentsUIDTO.payments(Collections.singletonList(payment));

		assertThatThrownBy(() -> paymentsService.sendPayments(instantPaymentsUIDTO))
				.isInstanceOf(BusinessException.class)
				.hasMessage("SPI-ME-002 - [InterbankSettlementAmount, ZERO]");

	}

    @Test
    void shouldThrowBusinessExceptionWhenAccountAndBranchThePayerAndReceiverAreTheSame() {
        PaymentsUIDTO payment = new PaymentsUIDTO().interbankSettlementAmount(BigDecimal.TEN);

        PayerUIDTO payerUIDTO = createPayerUIDTOMock();
        payerUIDTO.setInstitutionISPB(RECEIVER_ISPB);
        payerUIDTO.setAccount(createRemoteAccountUIDTOMock(RECEIVER_ACCOUNT, RECEIVER_BRANCH));
        payment.setPayer(payerUIDTO);
        payment.setReceiver(createReceiverUIDTOMock());

        InstantPaymentsUIDTO instantPaymentsUIDTO = new InstantPaymentsUIDTO();
        instantPaymentsUIDTO.setSettlementMethod("CLRG");
        instantPaymentsUIDTO.setInstructionPriority("HIGH");
        instantPaymentsUIDTO.payments(Collections.singletonList(payment));

        assertThatThrownBy(() -> paymentsService.sendPayments(instantPaymentsUIDTO))
            .isInstanceOf(BusinessException.class);

    }

	@Test
	void shouldThrowBusinessExceptionWhenTransactionValueIsLesserThanZero() {

		PaymentsUIDTO payment = new PaymentsUIDTO().interbankSettlementAmount(BigDecimal.valueOf(-157.99));
        payment.setPayer(createPayerUIDTOMock());
        payment.setReceiver(createReceiverUIDTOMock());

		InstantPaymentsUIDTO instantPaymentsUIDTO = new InstantPaymentsUIDTO();
		instantPaymentsUIDTO.payments(Collections.singletonList(payment));

		assertThatThrownBy(() -> paymentsService.sendPayments(instantPaymentsUIDTO))
				.isInstanceOf(BusinessException.class)
				.hasMessage("SPI-ME-002 - [InterbankSettlementAmount, ZERO]");
	}

	@Test
	void shouldThrowBusinessExceptionPayerWhenNullTaxId() {
		InstantPaymentsUIDTO instantPaymentsUIDTO = new InstantPaymentsUIDTO();
		PaymentsUIDTO payment = new PaymentsUIDTO().interbankSettlementAmount(BigDecimal.TEN);
		instantPaymentsUIDTO.payments(Collections.singletonList(payment));

		PayerUIDTO payerUIDTO = createPayerUIDTOMock();
		payerUIDTO.setTaxId(null);
		instantPaymentsUIDTO.getPayments().get(0).setPayer(payerUIDTO);
		instantPaymentsUIDTO.getPayments().get(0).setReceiver(createReceiverUIDTOMock());

		assertThatThrownBy(() -> paymentsService.sendPayments(instantPaymentsUIDTO))
				.isInstanceOf(BusinessException.class)
				.hasMessage("SPI-ME-005 - [Payer]");
	}

	@Test
	void shouldThrowBusinessExceptionReceiverWhenNullTaxId() {
		InstantPaymentsUIDTO instantPaymentsUIDTO = new InstantPaymentsUIDTO();
		PaymentsUIDTO payment = new PaymentsUIDTO().interbankSettlementAmount(BigDecimal.TEN);
		instantPaymentsUIDTO.payments(Collections.singletonList(payment));

		ReceiverUIDTO receiverDTO = createReceiverUIDTOMock();
		receiverDTO.setTaxId(null);
		instantPaymentsUIDTO.getPayments().get(0).setPayer(createPayerUIDTOMock());
		instantPaymentsUIDTO.getPayments().get(0).setReceiver(receiverDTO);

		assertThatThrownBy(() -> paymentsService.sendPayments(instantPaymentsUIDTO))
				.isInstanceOf(BusinessException.class)
				.hasMessage("SPI-ME-005 - [Receiver]");
	}

	@Test
	void shouldThrowBusinessExceptionOrganisationIdentificationWhenNullTaxId() {
		InstantPaymentsUIDTO instantPaymentsUIDTO = new InstantPaymentsUIDTO();
		PaymentsUIDTO payment = new PaymentsUIDTO().interbankSettlementAmount(BigDecimal.TEN);
		instantPaymentsUIDTO.payments(Collections.singletonList(payment));

		instantPaymentsUIDTO.getPayments().get(0).setOrganisationIdentification(160L);

		instantPaymentsUIDTO.getPayments().get(0).setPayer(createPayerUIDTOMock());
		instantPaymentsUIDTO.getPayments().get(0).setReceiver(createReceiverUIDTOMock());

		assertThatThrownBy(() -> paymentsService.sendPayments(instantPaymentsUIDTO))
				.isInstanceOf(BusinessException.class)
				.hasMessage("SPI-ME-005 - [InitiatingParty]");
	}

	private static ReceiverUIDTO createReceiverUIDTOMock() {
		ReceiverUIDTO receiverUIDTO = new ReceiverUIDTO();
		receiverUIDTO.setAddressingKey(ADDRESSING_KEY);
		receiverUIDTO.setInstitutionISPB(RECEIVER_ISPB);
		receiverUIDTO.setTaxId(RECEIVER_TAX_ID);
		receiverUIDTO.setAccount(createRemoteAccountUIDTOMock(RECEIVER_ACCOUNT, RECEIVER_BRANCH));

		return receiverUIDTO;
	}

	private static PayerUIDTO createPayerUIDTOMock() {
		PayerUIDTO payerUIDTO = new PayerUIDTO();
		payerUIDTO.setName(PAYER_NAME);
		payerUIDTO.setInstitutionISPB(PAYER_ISPB);
		payerUIDTO.setTaxId(PAYER_TAX_ID);
		payerUIDTO.setAccount(createRemoteAccountUIDTOMock(PAYER_ACCOUNT, PAYER_BRANCH));

		return payerUIDTO;
	}

	private static RemoteAccountUIDTO createRemoteAccountUIDTOMock(String account, String branch) {
		RemoteAccountUIDTO remoteAccountUIDTO = new RemoteAccountUIDTO();
		remoteAccountUIDTO.setAccountNumber(account);
		remoteAccountUIDTO.setBranch(branch);
		remoteAccountUIDTO.setAccountType(AccountTypeUIDTO.CACC);

		return remoteAccountUIDTO;
	}

	@Test
	void shouldReturnInstantPaymentSettlementResponseUIDTOWhenValueIsGreaterThanZero() {
		UUID id = UUID.randomUUID();
		String endToEndId = "END-TO-END-ID";
		PaymentEvent paymentEventMock = getPaymentEventMock(id, endToEndId);
		when(paymentFactory.createPayment(any(SendPaymentsDTO.class))).thenReturn(paymentEventMock);

        ConfigEntity configMock = new ConfigEntity();
        configMock.setIspb(13370835);
        when(configurationService.findConfig()).thenReturn(configMock);
        when(mainEngineConfiguration.isValidatePayerDirectPsp()).thenReturn(true);

        InstantPaymentsUIDTO instantPaymentsUIDTO = createInstantPaymentsUIDTO();

        instantPaymentsUIDTO.getPayments().get(0).setOrganisationIdentification(ORGANISATION_IDENTIFICATION);

        instantPaymentsUIDTO.getPayments().get(0).setPayer(createPayerUIDTOMock());
        instantPaymentsUIDTO.getPayments().get(0).setReceiver(createReceiverUIDTOMock());
        InstantPaymentSettlementResponseUIDTO response = paymentsService.sendPayments(instantPaymentsUIDTO);

		assertThat(response.getInstantPayments()).hasSize(1);
		assertThat(response.getInstantPayments().get(0).getEndToEndId()).isEqualTo(endToEndId);
		assertThat(response.getInstantPayments().get(0).getEventID()).isEqualTo(id.toString());

	}

    @Test
    void shouldThrowBusinessExceptionWhenBranchIsInvalid() {

        InstantPaymentsUIDTO instantPaymentsUIDTO = createInstantPaymentsUIDTO();
        instantPaymentsUIDTO.getPayments().get(0).getPayer().getAccount().setBranch("12345");
        assertThatThrownBy(() -> paymentsService.sendPayments(instantPaymentsUIDTO))
            .isInstanceOf(BusinessException.class)
            .hasMessage("SPI-ME-010 - [Branch, 4]");

        instantPaymentsUIDTO.getPayments().get(0).setPayer(createPayerUIDTOMock());
        instantPaymentsUIDTO.getPayments().get(0).setReceiver(createReceiverUIDTOMock());
        instantPaymentsUIDTO.getPayments().get(0).getReceiver().getAccount().setBranch("12345");
        assertThatThrownBy(() -> paymentsService.sendPayments(instantPaymentsUIDTO))
            .isInstanceOf(BusinessException.class)
            .hasMessage("SPI-ME-010 - [Branch, 4]");

        instantPaymentsUIDTO.getPayments().get(0).setPayer(createPayerUIDTOMock());
        instantPaymentsUIDTO.getPayments().get(0).setReceiver(createReceiverUIDTOMock());
        instantPaymentsUIDTO.getPayments().get(0).getPayer().getAccount().setBranch("123a");
        assertThatThrownBy(() -> paymentsService.sendPayments(instantPaymentsUIDTO))
            .isInstanceOf(BusinessException.class)
            .hasMessage("SPI-ME-011 - [Branch]");

        instantPaymentsUIDTO.getPayments().get(0).setPayer(createPayerUIDTOMock());
        instantPaymentsUIDTO.getPayments().get(0).setReceiver(createReceiverUIDTOMock());
        instantPaymentsUIDTO.getPayments().get(0).getReceiver().getAccount().setBranch("a123");
        assertThatThrownBy(() -> paymentsService.sendPayments(instantPaymentsUIDTO))
            .isInstanceOf(BusinessException.class)
            .hasMessage("SPI-ME-011 - [Branch]");

    }

    @Test
    void shouldThrowBusinessExceptionWhenAccountIsInvalid() {

        InstantPaymentsUIDTO instantPaymentsUIDTO = createInstantPaymentsUIDTO();
        instantPaymentsUIDTO.getPayments().get(0).getPayer().getAccount().setAccountNumber("012345678901234567891");
        assertThatThrownBy(() -> paymentsService.sendPayments(instantPaymentsUIDTO))
            .isInstanceOf(BusinessException.class)
            .hasMessage("SPI-ME-010 - [Account Number, 20]");

        instantPaymentsUIDTO.getPayments().get(0).setPayer(createPayerUIDTOMock());
        instantPaymentsUIDTO.getPayments().get(0).setReceiver(createReceiverUIDTOMock());
        instantPaymentsUIDTO.getPayments().get(0).getReceiver().getAccount().setAccountNumber("012345678901234567891");
        assertThatThrownBy(() -> paymentsService.sendPayments(instantPaymentsUIDTO))
            .isInstanceOf(BusinessException.class)
            .hasMessage("SPI-ME-010 - [Account Number, 20]");

        instantPaymentsUIDTO.getPayments().get(0).setPayer(createPayerUIDTOMock());
        instantPaymentsUIDTO.getPayments().get(0).setReceiver(createReceiverUIDTOMock());
        instantPaymentsUIDTO.getPayments().get(0).getPayer().getAccount().setAccountNumber("0123456a");
        assertThatThrownBy(() -> paymentsService.sendPayments(instantPaymentsUIDTO))
            .isInstanceOf(BusinessException.class)
            .hasMessage("SPI-ME-011 - [Account Number]");

        instantPaymentsUIDTO.getPayments().get(0).setPayer(createPayerUIDTOMock());
        instantPaymentsUIDTO.getPayments().get(0).setReceiver(createReceiverUIDTOMock());
        instantPaymentsUIDTO.getPayments().get(0).getReceiver().getAccount().setAccountNumber("012345b");
        assertThatThrownBy(() -> paymentsService.sendPayments(instantPaymentsUIDTO))
            .isInstanceOf(BusinessException.class)
            .hasMessage("SPI-ME-011 - [Account Number]");

    }

    @Test
    void shouldThrowBusinessExceptionWhenPayerIspbIsWrong() {
        ConfigEntity configMock = new ConfigEntity();
        configMock.setIspb(250699);
        when(configurationService.findConfig()).thenReturn(configMock);
        when(mainEngineConfiguration.isValidatePayerDirectPsp()).thenReturn(true);

        InstantPaymentsUIDTO instantPaymentsUIDTO = createInstantPaymentsUIDTO();

        instantPaymentsUIDTO.getPayments().get(0).setOrganisationIdentification(ORGANISATION_IDENTIFICATION);

        instantPaymentsUIDTO.getPayments().get(0).setPayer(createPayerUIDTOMock());
        instantPaymentsUIDTO.getPayments().get(0).setReceiver(createReceiverUIDTOMock());

        assertThatThrownBy(() -> paymentsService.sendPayments(instantPaymentsUIDTO))
            .isInstanceOf(BusinessException.class)
            .hasMessage("SPI-ME-021 - [13370835]");
    }

    @NotNull
    private InstantPaymentsUIDTO createInstantPaymentsUIDTO() {
        InstantPaymentsUIDTO instantPaymentsUIDTO = new InstantPaymentsUIDTO();
        PaymentsUIDTO payment = new PaymentsUIDTO().interbankSettlementAmount(BigDecimal.TEN);
        instantPaymentsUIDTO.payments(Collections.singletonList(payment));
        instantPaymentsUIDTO.setSettlementMethod(SETTLEMENT_METHOD);
        instantPaymentsUIDTO.instructionPriority(TRANSACTION_CODE);
        instantPaymentsUIDTO.getPayments().get(0).setPayer(createPayerUIDTOMock());
        instantPaymentsUIDTO.getPayments().get(0).setReceiver(createReceiverUIDTOMock());
        instantPaymentsUIDTO.getPayments().get(0).setOrganisationIdentification(ORGANISATION_IDENTIFICATION);
        return instantPaymentsUIDTO;
    }

    @NotNull
	private PaymentEvent getPaymentEventMock(UUID id, String endToEndId) {
		PaymentEventEntity paymentEventEntity = new PaymentEventEntity();
		paymentEventEntity.setId(id);

		PaymentEntity paymentEntity = new PaymentEntity();
		paymentEntity.setEvent(paymentEventEntity);
		paymentEntity.setEndToEndId(endToEndId);

		PaymentEvent paymentEvent = Mockito.mock(PaymentEvent.class);
		when(paymentEvent.getPaymentEntity()).thenReturn(paymentEntity);
		return paymentEvent;
	}

}
