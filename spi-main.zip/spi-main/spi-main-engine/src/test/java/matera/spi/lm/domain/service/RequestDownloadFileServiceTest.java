package matera.spi.lm.domain.service;

import matera.spi.commons.IntegrationTest;
import matera.spi.lm.commons.HttpRequestExecutor;
import matera.spi.lm.config.CsvStorageConfiguration;
import matera.spi.lm.config.DownloadFileConfiguration;
import matera.spi.lm.domain.model.event.IpAccountStatementQueryDetailsEntity;
import matera.spi.lm.domain.model.event.IpAccountStatementQueryEventEntity;
import matera.spi.main.dto.QueryBalanceResponseDTO;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.MappingBuilder;
import com.github.tomakehurst.wiremock.client.ResponseDefinitionBuilder;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.UUID;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.anyRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.anyUrl;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.getRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@IntegrationTest
class RequestDownloadFileServiceTest {

    private static final String EXPECTED_UUID = "8ce08888-4cb9-422b-aead-3a477847ce29";
    private static final String ROOT_DIR = System.getProperty("user.dir");
    private static final String RESULT_DIR = ROOT_DIR + "/result-file";
    private static WireMockConfiguration wireMockConfig = wireMockConfig().dynamicPort();
    private static WireMockServer wireMockServer = new WireMockServer(wireMockConfig);
    private static File resultFolderFile = new File(RESULT_DIR);

    @Autowired
    private RequestDownloadFileService requestDownloadFileService;

    @Mock
    private DownloadFileConfiguration mockedDownloadFileConfiguration;
    @Autowired
    private DownloadFileConfiguration downloadFileConfigurationBean;

    @Mock
    private CsvStorageConfiguration mockedCsvStorageConfiguration;
    @Autowired
    private CsvStorageConfiguration csvStorageConfigurationBean;

    @Mock
    private HttpRequestExecutor mockedHttpRequestExecutor;
    @Autowired
    private HttpRequestExecutor httpRequestExecutor;

    @Mock
    private IpAccountStatementQueryEventEntity mockedStatementQueryEventEntity;

    @BeforeEach
    void setup() throws IOException {
        requestDownloadFileService.setCsvStorageConfiguration(mockedCsvStorageConfiguration);
        requestDownloadFileService.setDownloadFileConfiguration(mockedDownloadFileConfiguration);
        requestDownloadFileService.setHttpClient(mockedHttpRequestExecutor);
        when(mockedHttpRequestExecutor.doGet(any())).thenReturn(new FileInputStream(new File(ROOT_DIR + "/src/test/resources/__files/zip/camt052.zip")));
        Mockito.doReturn(UUID.fromString(EXPECTED_UUID)).when(mockedStatementQueryEventEntity).getId();
    }

    @BeforeAll
    static void beforeAll() {
        wireMockServer.start();
        resultFolderFile.mkdir();
    }

    @AfterEach
    void afterEach() {
        requestDownloadFileService.setCsvStorageConfiguration(csvStorageConfigurationBean);
        requestDownloadFileService.setDownloadFileConfiguration(downloadFileConfigurationBean);
        requestDownloadFileService.setHttpClient(httpRequestExecutor);

        for (File file : resultFolderFile.listFiles()) {
            file.delete();
        }
    }

    @AfterAll
    static void afterAll() {
        wireMockServer.stop();
        resultFolderFile.delete();
    }

    @Test
    void assertRequestUrl() {
        when(mockedDownloadFileConfiguration.getUrlBase()).thenReturn("http://url.com");
        when(mockedDownloadFileConfiguration.getUriZip()).thenReturn("/v1");

        String url = requestDownloadFileService.buildUrl("aditional");
        assertThat(url, is("http://url.com/v1/aditional.zip"));
    }

    @Test
    void shouldDownloadFile() throws IOException {
        wireMockServer.stubFor(responseFile());
        when(mockedDownloadFileConfiguration.getUrlBase()).thenReturn(getUrlWiremock());
        when(mockedDownloadFileConfiguration.getUriZip()).thenReturn("/v1");
        when(mockedCsvStorageConfiguration.getPath()).thenReturn("file://" + RESULT_DIR);

        requestDownloadFileService.requestFile(buildDetailsEntity());

        File resultFile = resultFolderFile.listFiles()[0];

        byte[] originalFile = Files.readAllBytes(Path.of(ROOT_DIR + "/src/test/resources/__files/zip/camt052.zip"));
        byte[] targetFile = Files.readAllBytes(Path.of(resultFile.getAbsolutePath()));

        assertThat(originalFile, is(targetFile));
    }

    @Test
    void testFileExist() throws IOException {
        wireMockServer.stubFor(responseFile());
        when(mockedDownloadFileConfiguration.getUrlBase()).thenReturn(getUrlWiremock());
        when(mockedDownloadFileConfiguration.getUriZip()).thenReturn("/v1");
        when(mockedCsvStorageConfiguration.getPath()).thenReturn("file://" + RESULT_DIR);

        IpAccountStatementQueryDetailsEntity detailsEntity = buildDetailsEntity();
        requestDownloadFileService.requestFile(detailsEntity);
        requestDownloadFileService.requestFile(detailsEntity);

        File resultFile = resultFolderFile.listFiles()[0];

        byte[] originalFile = Files.readAllBytes(Path.of(ROOT_DIR + "/src/test/resources/__files/zip/camt052.zip"));
        byte[] targetFile = Files.readAllBytes(Path.of(resultFile.getAbsolutePath()));

        assertThat(originalFile, is(targetFile));
        assertThat(resultFolderFile.listFiles().length, is(1));
        verify(mockedHttpRequestExecutor, times(1)).doGet(any());
    }

    @Test
    void testHeaderHostIsWithoutPort() {
        requestDownloadFileService.setHttpClient(httpRequestExecutor);
        when(mockedDownloadFileConfiguration.getUrlBase()).thenReturn(getUrlWiremock());
        when(mockedDownloadFileConfiguration.getUriZip()).thenReturn("/v1");
        when(mockedCsvStorageConfiguration.getPath()).thenReturn("file://" + RESULT_DIR);

        IpAccountStatementQueryDetailsEntity detailsEntity = buildDetailsEntity();
        requestDownloadFileService.requestFile(detailsEntity);

        wireMockServer.verify(getRequestedFor(urlEqualTo("/v1/additional.zip")).withHeader("Host", equalTo("localhost")));
    }

    private String getUrlWiremock() {
        return "http://localhost:" + wireMockServer.port();
    }

    private QueryBalanceResponseDTO getQueryBalanceDto() {
        return QueryBalanceResponseDTO.builder().balanceAvailable(
            BigDecimal.TEN).build();
    }

    private IpAccountStatementQueryDetailsEntity buildDetailsEntity() {
        IpAccountStatementQueryDetailsEntity detailsEntity = new IpAccountStatementQueryDetailsEntity();
        detailsEntity.setStartTimestampUtc(LocalDateTime.now());
        detailsEntity.setEndTimestampUtc(LocalDateTime.now());
        detailsEntity.setAdditionalReportInformation("additional");
        detailsEntity.setIpAccountStatementQueryEventEntity(mockedStatementQueryEventEntity);
        detailsEntity.setFileUri("");

        return detailsEntity;
    }

    private MappingBuilder responseFile() {
        ResponseDefinitionBuilder responseDefinitionBuilder = aResponse().withBodyFile("zip/camt052.zip");
        return get(urlEqualTo("/v1/additional.zip")).willReturn(responseDefinitionBuilder);
    }

}
