package matera.spi.indirect.application.service;

import matera.spi.dto.IndirectParticipantDTO;
import matera.spi.indirect.application.service.mapper.ParticipantMipIndirectMapper;
import matera.spi.indirect.domain.model.ParticipantMipIndirectEntity;
import matera.spi.indirect.domain.service.IndirectParticipantInformationRetriever;
import matera.spi.indirect.persistence.ParticipantMipIndirectStatusRepository;
import matera.spi.indirect.util.ParticipantMipIndirectDataSetUtil;
import matera.spi.main.domain.model.ParticipantMipEntity;

import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class IndirectParticipantApplicationAPIImplTest {

    @Mock
    private IndirectParticipantInformationRetriever indirectParticipantInformationRetriever;

    @Mock
    private ParticipantMipIndirectStatusRepository participantMipIndirectStatusRepository;

    @InjectMocks
    private IndirectParticipantAPIImpl indirectParticipantApplicationAPIImpl;

    @ParameterizedTest
    @MethodSource("truthTable")
    void shouldFindIndirectCompleteInfo(boolean statusArgument, boolean showCanceledIndirects) {
        doReturn(Optional.of(ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectStatusEntity()))
            .when(participantMipIndirectStatusRepository).findById(Mockito.any());

        final ParticipantMipEntity participantMip = ParticipantMipIndirectDataSetUtil.createParticipantMip();
        final ParticipantMipIndirectEntity participantMipIndirectEntity = ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository, participantMip);

        doReturn(Arrays.asList(participantMipIndirectEntity)).when(indirectParticipantInformationRetriever)
            .findAllIndirectParticipantsAccordingFilters(eq(ParticipantMipIndirectDataSetUtil.ISPB), eq(statusArgument),
                eq(showCanceledIndirects));

        final List<IndirectParticipantDTO> indirectParticipantDTOList = indirectParticipantApplicationAPIImpl
            .findIndirectCompleteInfo(ParticipantMipIndirectDataSetUtil.ISPB, statusArgument, showCanceledIndirects);
        final IndirectParticipantDTO indirectParticipantDTO =
            ParticipantMipIndirectMapper.mapEntityToIndirectParticipantDTO(participantMipIndirectEntity);

        verify(indirectParticipantInformationRetriever)
            .findAllIndirectParticipantsAccordingFilters(eq(ParticipantMipIndirectDataSetUtil.ISPB), eq(statusArgument),
                eq(showCanceledIndirects));
        assertThat(indirectParticipantDTOList).hasOnlyOneElementSatisfying(indirectParticipantDTO::equals);
    }

    @ParameterizedTest
    @MethodSource("truthTable")
    void shouldTHaveNoDataAccordingGivenArguments(boolean statusArgument, boolean showCanceledIndirects) {
        doReturn(new ArrayList<>()).when(indirectParticipantInformationRetriever)
            .findAllIndirectParticipantsAccordingFilters(eq(ParticipantMipIndirectDataSetUtil.ISPB), eq(statusArgument),
                eq(showCanceledIndirects));

        assertThat(indirectParticipantApplicationAPIImpl
            .findIndirectCompleteInfo(ParticipantMipIndirectDataSetUtil.ISPB, statusArgument, showCanceledIndirects)).hasSize(0);

        verify(indirectParticipantInformationRetriever)
            .findAllIndirectParticipantsAccordingFilters(eq(ParticipantMipIndirectDataSetUtil.ISPB), eq(statusArgument),
                eq(showCanceledIndirects));
    }

    private static Stream<Arguments> truthTable() {
        return Stream.of(
            Arguments.of(true, true),
            Arguments.of(true, false),
            Arguments.of(false, true),
            Arguments.of(false, false)
        );
    }

}
