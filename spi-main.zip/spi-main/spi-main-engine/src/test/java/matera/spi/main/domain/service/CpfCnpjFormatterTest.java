package matera.spi.main.domain.service;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class CpfCnpjFormatterTest {

    private static final String VALID_CPF = "911.718.910-16";
    private static final String VALID_CPF_FORMMATED = "91171891016";
    private static final String VALID_CNPJ = "03.730.561/0001-34";
    private static final String VALID_CNPJ_FORMMATED = "03730561000134";
    private static final String INVALID_TAX_ID = "123/09756.00.--0000";

    @Test
    void shouldCorrectPadCpf() {
        String cpfFormmated = CpfCnpjFormatter.padCpfCnpj(VALID_CPF);
        assertThat(cpfFormmated).isEqualTo(VALID_CPF_FORMMATED);
    }

    @Test
    void shouldCorrectPadCnpj() {
        String cpfFormmated = CpfCnpjFormatter.padCpfCnpj(VALID_CNPJ);
        assertThat(cpfFormmated).isEqualTo(VALID_CNPJ_FORMMATED);
    }

    @Test
    void shouldInvalidTaxId() {
        String cpfFormmated = CpfCnpjFormatter.padCpfCnpj(INVALID_TAX_ID);
        assertThat(cpfFormmated).isNotEqualTo(INVALID_TAX_ID);
    }

    @Test
    void shouldformatCpf() {
        Long sanitizeInput = CpfCnpjFormatter.sanitizeInput(VALID_CPF);
        assertThat(VALID_CPF).isEqualTo(CpfCnpjFormatter.formatCpfWithMaskCharacters(sanitizeInput));
    }

    @Test
    void shouldformatCNPJ() {
        Long sanitizeInput = CpfCnpjFormatter.sanitizeInput(VALID_CNPJ);
        assertThat(VALID_CNPJ).isEqualTo(CpfCnpjFormatter.formatCnpjWithMaskCharacters(sanitizeInput));
    }

}
