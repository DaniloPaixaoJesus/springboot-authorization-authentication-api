package matera.spi.indirect.application.service.validator;

import com.matera.commons.utils.exception.BusinessException;

import matera.spi.dto.IndirectParticipantContactDTO;
import matera.spi.dto.IndirectParticipantCreationRequestDTO;
import matera.spi.dto.IndirectParticipantFinancialFieldsUIDTO;
import matera.spi.dto.IndirectParticipantStatusDTO;
import matera.spi.indirect.domain.model.ParticipantMipIndirectEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectStatusEntity;
import matera.spi.indirect.domain.service.IndirectParticipantCreationService;
import matera.spi.indirect.domain.service.IndirectParticipantMipService;
import matera.spi.indirect.domain.service.IndirectParticipantStatusService;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class IndirectParticipantRegisterValidatorTest {

    private static final String ACCOUNT_NUMBER = "123";
    private static final String BRANCH = "1";
    private static final LocalDate CONTRACT_END_DATE = LocalDate.now().plusDays(1);
    private static final LocalDate CONTRACT_INIT_DATE = LocalDate.now();
    private static final String CORPORATE_NAME = "CORP_NAME";
    private static final String ISPB = "00192555";
    private static final String NAME = "NAME";
    private static final String TAX_ID = "22222255522";

    IndirectParticipantMipService indirectParticipantMipService = new IndirectParticipantMipService(null);

    @Spy
    IndirectParticipantRegisterValidator indirectParticipantRegisterValidator;

    @Test
    void shouldThrowExceptionWhenIndirectParticipantDoesNotExist() {
        Assertions.assertThrows(BusinessException.class, () -> {
            {
                indirectParticipantRegisterValidator.validateIndirectParticipantRegister(Optional.empty());
            }
        });
    }

    @Test
    void shouldThrowExceptionWhenIndirectParticipantStatusDoesNotAllowRegistration() {
        ParticipantMipIndirectStatusEntity statusEntityMock = createParticipantMipIndirectStatusEntityMock();
        ReflectionTestUtils.setField(statusEntityMock, "allowsClearingRegistry", false);

        Optional<ParticipantMipIndirectEntity> entityMock = createParticipantMipIndirectEntityMock();
        entityMock.get().setStatus(statusEntityMock);

        Assertions.assertThrows(BusinessException.class, () -> {
            {
                indirectParticipantRegisterValidator.validateIndirectParticipantRegister(entityMock);
            }
        });
    }

    @Test
    void shouldNotThrowExceptionWhenIndirectParticipantExistsAndStatusIsAllowedForRegistration() {
        ParticipantMipIndirectStatusEntity statusEntityMock = createParticipantMipIndirectStatusEntityMock();
        ReflectionTestUtils.setField(statusEntityMock, "allowsClearingRegistry", true);

        Optional<ParticipantMipIndirectEntity> entityMock = createParticipantMipIndirectEntityMock();
        entityMock.get().setStatus(statusEntityMock);

        Assertions.assertDoesNotThrow(() -> {
            {
                indirectParticipantRegisterValidator.validateIndirectParticipantRegister(entityMock);
            }
        });
    }

    private ParticipantMipIndirectStatusEntity createParticipantMipIndirectStatusEntityMock() {
        ParticipantMipIndirectStatusEntity statusEntity = new ParticipantMipIndirectStatusEntity();
        ReflectionTestUtils.setField(statusEntity, "id", 1);
        return statusEntity;
    }

    private Optional<ParticipantMipIndirectEntity> createParticipantMipIndirectEntityMock() {
        return Optional.ofNullable(ReflectionTestUtils
            .invokeMethod(indirectParticipantMipService, "createIndirectParticipantEntityFromDTO",
                createIndirectParticipantCreationRequestMock()));
    }

    private IndirectParticipantCreationRequestDTO createIndirectParticipantCreationRequestMock() {
        IndirectParticipantCreationRequestDTO indirectParticipant = new IndirectParticipantCreationRequestDTO();
        indirectParticipant.setStatus(IndirectParticipantStatusDTO.WAITING_TO_SEND_REGISTRATION_TO_CLEARING);
        indirectParticipant.setAccountNumber(ACCOUNT_NUMBER);
        indirectParticipant.setBranch(BRANCH);
        indirectParticipant.setContacts(createIndirectParticipantContactListMock());
        indirectParticipant.setContractEndDate(CONTRACT_END_DATE);
        indirectParticipant.setContractInitDate(CONTRACT_INIT_DATE);
        indirectParticipant.setCorporateName(CORPORATE_NAME);
        indirectParticipant.setIspb(ISPB);
        indirectParticipant.setFinancial(createIndirectParticipantFinancialFieldsMock());
        indirectParticipant.setName(NAME);
        indirectParticipant.setTaxId(TAX_ID);
        return indirectParticipant;
    }

    private IndirectParticipantFinancialFieldsUIDTO createIndirectParticipantFinancialFieldsMock() {
        IndirectParticipantFinancialFieldsUIDTO indirectParticipantFinancialFields =
            new IndirectParticipantFinancialFieldsUIDTO();
        indirectParticipantFinancialFields.setBalanceLowerThreshold(new BigDecimal("100"));
        indirectParticipantFinancialFields.setBalanceValidationThreshold(true);
        return indirectParticipantFinancialFields;
    }

    private List<IndirectParticipantContactDTO> createIndirectParticipantContactListMock() {
        List<IndirectParticipantContactDTO> indirectParticipantContactList = new ArrayList<>();
        IndirectParticipantContactDTO indirectParticipantContact = new IndirectParticipantContactDTO();
        indirectParticipantContact.setDepartment("DEPARTMENT");
        indirectParticipantContact.setEmail("EMAIL@EMAIL.COM");
        indirectParticipantContact.setName("CONTACT_NAME");
        indirectParticipantContact.setPhone("555555555");
        indirectParticipantContactList.add(indirectParticipantContact);
        return indirectParticipantContactList;
    }

}
