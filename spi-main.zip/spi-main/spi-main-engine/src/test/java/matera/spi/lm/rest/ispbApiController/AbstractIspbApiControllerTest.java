package matera.spi.lm.rest.ispbApiController;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.IspbQueryDTO;
import matera.spi.dto.IspbQueryListResponseDTO;

import io.restassured.RestAssured;
import org.eclipse.jetty.http.HttpStatus;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.boot.web.server.LocalServerPort;

@IntegrationTest
public abstract class AbstractIspbApiControllerTest {

    private static final String ISPB_BASE_URI = "/ui/v1/ispb/query";

    @LocalServerPort
    private int port;

    @BeforeEach
    void beforeEach() {
        RestAssured.port = port;
    }

    public IspbQueryListResponseDTO executeRequest() {
        return RestAssured.given()
            .when().get(ISPB_BASE_URI)
            .then()
            .statusCode(HttpStatus.OK_200)
            .extract()
            .as(IspbQueryListResponseDTO.class);
    }

    public IspbQueryDTO buildIspbQueryDTO(String name, String ispb, Boolean isLocalIspb) {
        IspbQueryDTO ispbQueryDTO = new IspbQueryDTO();
        ispbQueryDTO.setName(name);
        ispbQueryDTO.setIspb(ispb);
        ispbQueryDTO.setIsLocalIspb(isLocalIspb);

        return ispbQueryDTO;
    }
}
