package matera.spi.main.domain.service.event.financial.action;

import matera.spi.main.domain.service.event.transaction.CreditTransactionEvent;
import matera.spi.main.domain.service.event.transaction.DebitTransactionEvent;
import matera.spi.main.domain.service.transaction.AccountsTransactionDispatcher;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class CreditFinancialActionTest {

	@InjectMocks
	private CreditFinancialAction creditFinancialAction;
	@Mock
	private AccountsTransactionDispatcher accountsTransactionDispatcher;

	@Test
	@DisplayName("when handling CreditFinancialAction should make a credit by accountsTransactionDispatcherService")
	void shouldMakeACreditToIPAccountWhenHandlingCreditFinancialAction() {
        CreditTransactionEvent creditTransactionEvent = mock(CreditTransactionEvent.class);
		creditFinancialAction.handle(creditTransactionEvent);

        verify(creditTransactionEvent).makeIPAccountsTransaction();
	}

	@Test
	@DisplayName("when called with a DebitTransactionEvent should not call accountsTransactionDispatcherService.makeCredit")
	void shouldNotCallIpAccountServiceWhenAPaymentEventEntityIsGiven() {
        DebitTransactionEvent debitTransactionEvent = mock(DebitTransactionEvent.class);

		creditFinancialAction.handle(debitTransactionEvent);

        verify(debitTransactionEvent, never()).makeIPAccountsTransaction();
    }

}
