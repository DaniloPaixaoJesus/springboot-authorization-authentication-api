package matera.spi.main.domain.service.util;

import matera.spi.utils.DocumentUtils;

import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;

import static org.assertj.core.api.Assertions.assertThat;

class MessageBinderXpathCamt014UtilsTest {

    private static final String CAMT_014_CAMT_014_MSG = "camt.014/camt.014_msg.xml";
    private static final String CAMT_014_CAMT_014_2_MSG = "camt.014/camt.014_2_msg.xml";

    private static final int ONE = 1;
    private static final int TWO = 2;

    private static final String MSGID = "M0003816612345678901234567890123";
    private static final String CREDTTM = "2020-01-01T10:30:12.000Z";

    private static final String CLRSYSMMBID_MMBID_0 = "67676767";
    private static final String MMBORERR_MMB_NM_0 = "PIX S/A";
    private static final String MMBORERR_MMB_TP_0 = "IDRT";
    private static final String MMBORERR_MMB_STS_0 = "ENBL";

    private static final String CLRSYSMMBID_MMBID_1 = "96969696";
    private static final String MMBORERR_MMB_NM_1 = "INSTANT PAYMENT";
    private static final String MMBORERR_MMB_TP_1 = "DRCT";
    private static final String MMBORERR_MMB_STS_1 = "DLTD";



    @Test
    void shouldGetCamt014Data2msgs() {
        Document document = DocumentUtils.stringToXmlDocument(getXml(CAMT_014_CAMT_014_2_MSG));

        String msgid = MessageBinderXpathCamt014Utils.getMsgid(document);
        String credttm = MessageBinderXpathCamt014Utils.getCredttm(document);

        NodeList nodeList = MessageBinderXpathCamt014Utils.getAllRpts(document);

        assertThat(msgid).isEqualTo(MSGID);
        assertThat(credttm).isEqualTo(CREDTTM);

        assertThat(MessageBinderXpathCamt014Utils.getClrSysMmbId(nodeList.item(0))).isEqualTo(CLRSYSMMBID_MMBID_0);
        assertThat(MessageBinderXpathCamt014Utils.getMmbOrErrMmbNm(nodeList.item(0))).isEqualTo(MMBORERR_MMB_NM_0);
        assertThat(MessageBinderXpathCamt014Utils.getMmbOrErrMmbTp(nodeList.item(0))).isEqualTo(MMBORERR_MMB_TP_0);
        assertThat(MessageBinderXpathCamt014Utils.getMmbOrErrMmbSts(nodeList.item(0))).isEqualTo(MMBORERR_MMB_STS_0);

        assertThat(MessageBinderXpathCamt014Utils.getClrSysMmbId(nodeList.item(1))).isEqualTo(CLRSYSMMBID_MMBID_1);
        assertThat(MessageBinderXpathCamt014Utils.getMmbOrErrMmbNm(nodeList.item(1))).isEqualTo(MMBORERR_MMB_NM_1);
        assertThat(MessageBinderXpathCamt014Utils.getMmbOrErrMmbTp(nodeList.item(1))).isEqualTo(MMBORERR_MMB_TP_1);
        assertThat(MessageBinderXpathCamt014Utils.getMmbOrErrMmbSts(nodeList.item(1))).isEqualTo(MMBORERR_MMB_STS_1);

        assertThat(nodeList.getLength()).isEqualTo(TWO);
    }

    @Test
    void shouldGetCamt014Data1msg() {
        Document document = DocumentUtils.stringToXmlDocument(getXml(CAMT_014_CAMT_014_MSG));

        String msgid = MessageBinderXpathCamt014Utils.getMsgid(document);
        String credttm = MessageBinderXpathCamt014Utils.getCredttm(document);

        NodeList nodeList = MessageBinderXpathCamt014Utils.getAllRpts(document);

        assertThat(msgid).isEqualTo(MSGID);
        assertThat(credttm).isEqualTo(CREDTTM);

        assertThat(MessageBinderXpathCamt014Utils.getClrSysMmbId(nodeList.item(0))).isEqualTo(CLRSYSMMBID_MMBID_0);
        assertThat(MessageBinderXpathCamt014Utils.getMmbOrErrMmbNm(nodeList.item(0))).isEqualTo(MMBORERR_MMB_NM_0);
        assertThat(MessageBinderXpathCamt014Utils.getMmbOrErrMmbTp(nodeList.item(0))).isEqualTo(MMBORERR_MMB_TP_0);
        assertThat(MessageBinderXpathCamt014Utils.getMmbOrErrMmbSts(nodeList.item(0))).isEqualTo(MMBORERR_MMB_STS_0);

        assertThat(nodeList.getLength()).isEqualTo(ONE);
    }

    private String getXml(String path) {
        return getStringFromXmlFile(path);
    }
}
