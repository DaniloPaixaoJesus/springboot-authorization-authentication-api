package matera.spi.indirect.util;

import matera.spi.indirect.domain.model.ParticipantMipIndirectContactsEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectHistoryEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectStatusEntity;
import matera.spi.indirect.domain.model.enums.IndirectParticipantStatusEnum;
import matera.spi.indirect.persistence.ParticipantMipIndirectContactsRepository;
import matera.spi.indirect.persistence.ParticipantMipIndirectHistoryRepository;
import matera.spi.indirect.persistence.ParticipantMipIndirectRepository;
import matera.spi.indirect.persistence.ParticipantMipIndirectStatusRepository;
import matera.spi.main.domain.model.ParticipantMipEntity;
import matera.spi.main.persistence.ParticipantMipRepository;

import org.mockito.Mockito;
import org.opentest4j.AssertionFailedError;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public final class ParticipantMipIndirectDataSetUtil {

    public static final String STATUS_NOT_FOUND_WITH_ID = "Status not found with id: ";
    public static final Integer ISPB = 123454;
    public static final String INDIRECT_PARTICIPANT_NAME = "Indirect Participant";
    public static final String CONTACT_NAME = "Contact";
    public static final String EMAIL = "email@provider.domain";
    public static final String PHONE = "+55(11)9-9876-5432";
    public static final String DEPARTMENT = "Department";
    public static final String CORPORATE_NAME = "Indirect";
    public static final LocalDate CONTRACT_INIT_DATE = LocalDate.of(2020, 8, 13);
    public static final LocalDate CONTRACT_END_DATE = LocalDate.of(2020, 8, 20);
    public static final boolean DIRECT_PARTICIPANT_FLAG = false;
    public static final boolean BALANCE_VALIDATION_THRESHOLD = true;
    public static final BigDecimal BALANCE_LOWER_THRESHOLD = BigDecimal.valueOf(1002430.57);
    public static final BigDecimal ACCOUNT_NUMBER = BigDecimal.valueOf(444555);
    public static final BigDecimal TAX_ID = BigDecimal.valueOf(79610132000195L);
    public static final int QRCODE_CRED_TRANSACTION_TYPE = 9875;
    public static final int BALANCE_LOWER_THRESHOLD_PERC = 10;
    public static final int DRAWBACK_RECEIVE_TRANSACT_TYPE = 77;
    public static final int DRAWBACK_SENT_TRANSACT_TYPE = 11;
    public static final int WITHDRAW_TRANSACTION_TYPE = 1147;
    public static final int DEPOSIT_TRANSACTION_TYPE = 4789;
    public static final int CRED_TRANSACTION_TYPE = 344;
    public static final int DEB_TRANSACTION_TYPE = 12;
    public static final int BRANCH = 123;
    public static final ParticipantMipIndirectHistoryEntity.Type HISTORY_TYPE =
        ParticipantMipIndirectHistoryEntity.Type.CLEARING_RESCISSION_REQUEST;
    public static final LocalDateTime HISTORY_EVENT_DATE_TIME = LocalDateTime.now(ZoneOffset.UTC);

    private ParticipantMipIndirectDataSetUtil() {

    }

    //@formatter:off

    public static ParticipantMipIndirectEntity createCustomParticipantMipIndirectEntity(
        ParticipantMipIndirectStatusRepository participantMipIndirectStatusRepository,
        ParticipantMipEntity participantMip,
        String indirectName,
        String corporateName,
        BigDecimal taxId,
        IndirectParticipantStatusEnum status) {
        return createParticipantMipIndirectEntity(participantMipIndirectStatusRepository, participantMip, indirectName, corporateName, taxId, status.getId());
    }

    public static ParticipantMipIndirectEntity createDefaultParticipantMipIndirectEntity(
                                        ParticipantMipIndirectStatusRepository participantMipIndirectStatusRepository,
                                        ParticipantMipEntity participantMip) {
        return createParticipantMipIndirectEntity(participantMipIndirectStatusRepository, participantMip, INDIRECT_PARTICIPANT_NAME,
            CORPORATE_NAME, TAX_ID, IndirectParticipantStatusEnum.ACTIVE.getId());
    }

    public static ParticipantMipIndirectEntity createDefaultParticipantMipIndirectEntity(
        ParticipantMipIndirectStatusRepository participantMipIndirectStatusRepository,
        Integer statusId,
        ParticipantMipEntity participantMip) {
        return createParticipantMipIndirectEntity(participantMipIndirectStatusRepository, participantMip, INDIRECT_PARTICIPANT_NAME,
            CORPORATE_NAME, TAX_ID, statusId);
    }

    public static ParticipantMipIndirectEntity createParticipantMipIndirectEntity(
                                        ParticipantMipIndirectStatusRepository participantMipIndirectStatusRepository,
                                        ParticipantMipEntity participantMip,
                                        String indirectName,
                                        String corporateName,
                                        BigDecimal taxId,
                                        Integer statusId) {
        //@formatter:on
        final ParticipantMipIndirectEntity participantMipIndirect = new ParticipantMipIndirectEntity();

        participantMipIndirect.setParticipantMip(participantMip);
        participantMipIndirect.setName(indirectName);
        participantMipIndirect.setCorporateName(corporateName);
        participantMipIndirect.setTaxId(taxId);
        participantMipIndirect
            .setStatus(findParticipantMipIndirectStatus(statusId, participantMipIndirectStatusRepository));
        participantMipIndirect.setContractInitDate(CONTRACT_INIT_DATE);
        participantMipIndirect.setContractEndDate(CONTRACT_END_DATE);

        return participantMipIndirect;
    }

    public static ParticipantMipEntity createParticipantMip() {
        return createParticipantMip(ISPB);
    }

    public static ParticipantMipEntity createParticipantMip(Integer ispb) {
        final ParticipantMipEntity participantMip = new ParticipantMipEntity();

        participantMip.setIspb(ispb);
        participantMip.setBranch(BRANCH);
        participantMip.setAccountNumber(ACCOUNT_NUMBER);
        participantMip.setDebTransactionType(DEB_TRANSACTION_TYPE);
        participantMip.setCredTransactionType(CRED_TRANSACTION_TYPE);
        participantMip.setDepositTransactionType(DEPOSIT_TRANSACTION_TYPE);
        participantMip.setWithdrawTransactionType(WITHDRAW_TRANSACTION_TYPE);
        participantMip.setDrawbackSentTransactType(DRAWBACK_SENT_TRANSACT_TYPE);
        participantMip.setDrawbackReceiveTransactType(DRAWBACK_RECEIVE_TRANSACT_TYPE);
        participantMip.setBalanceValidationThreshold(BALANCE_VALIDATION_THRESHOLD);
        participantMip.setBalanceLowerThreshold(BALANCE_LOWER_THRESHOLD);
        participantMip.setBalanceLowerThresholdPerc(BALANCE_LOWER_THRESHOLD_PERC);
        participantMip.setDirectParticipant(DIRECT_PARTICIPANT_FLAG);
        participantMip.setQrcodeCredTransactionType(QRCODE_CRED_TRANSACTION_TYPE);

        return participantMip;
    }

    public static ParticipantMipIndirectStatusEntity findParticipantMipIndirectStatusActive(
        ParticipantMipIndirectStatusRepository participantMipIndirectStatusRepository) {
        return participantMipIndirectStatusRepository.findById(IndirectParticipantStatusEnum.ACTIVE.getId())
            .orElseThrow(() -> new AssertionFailedError(
                STATUS_NOT_FOUND_WITH_ID + IndirectParticipantStatusEnum.ACTIVE.getId()));
    }

    //@formatter:off
    public static ParticipantMipIndirectStatusEntity findParticipantMipIndirectStatus(
                                       Integer statusId,
                                       ParticipantMipIndirectStatusRepository participantMipIndirectStatusRepository) {
        //@formatter:on
        return participantMipIndirectStatusRepository.findById(statusId)
            .orElseThrow(() -> new AssertionFailedError(STATUS_NOT_FOUND_WITH_ID + statusId));
    }

    public static ParticipantMipIndirectStatusEntity findParticipantMipIndirectStatus(
        ParticipantMipIndirectStatusRepository participantMipIndirectStatusRepository,
        Integer id) {
        Integer statusId = IndirectParticipantStatusEnum.getEnumById(id).getId();
        return participantMipIndirectStatusRepository.findById(statusId)
            .orElseThrow(() -> new AssertionFailedError(STATUS_NOT_FOUND_WITH_ID + statusId));
    }

    public static ParticipantMipIndirectContactsEntity createParticipantMipIndirectContactsEntity(
        ParticipantMipIndirectEntity participantMipIndirectEntity) {
        final ParticipantMipIndirectContactsEntity participantMipIndirectContactsEntity =
            new ParticipantMipIndirectContactsEntity();

        participantMipIndirectContactsEntity.setDepartment(DEPARTMENT);
        participantMipIndirectContactsEntity.setEmail(EMAIL);
        participantMipIndirectContactsEntity.setName(CONTACT_NAME);
        participantMipIndirectContactsEntity.setParticipantMip(participantMipIndirectEntity);
        participantMipIndirectContactsEntity.setPhone(PHONE);

        return participantMipIndirectContactsEntity;
    }

    public static ParticipantMipIndirectStatusEntity createParticipantMipIndirectStatusEntity() {
        return createParticipantMipIndirectStatusEntity(true);
    }

    public static ParticipantMipIndirectStatusEntity createParticipantMipIndirectStatusEntity(boolean allowsClearingRescission) {
        final ParticipantMipIndirectStatusEntity status = new ParticipantMipIndirectStatusEntity();

        try {
            setStatusFieldValue(status, "id", 1);
            setStatusFieldValue(status, "status", "Active");
            setStatusFieldValue(status, "isActive", true);
            setStatusFieldValue(status, "allowsChangeIds", true);
            setStatusFieldValue(status, "allowsChangeInfo", true);
            setStatusFieldValue(status, "allowsClearingRescission", allowsClearingRescission);
            setStatusFieldValue(status, "allowsClearingRegistry", false);
        } catch (Exception e) {
            throw new AssertionFailedError(e.getMessage(), e);
        }

        return status;
    }

    public static void setStatusFieldValue(ParticipantMipIndirectStatusEntity status, String fieldName, Object value) {
        final Field isActive = ReflectionUtils.findField(status.getClass(), fieldName);
        isActive.setAccessible(true);
        ReflectionUtils.setField(isActive, status, value);
    }

    //@formatter:off
    public static void cleanIndirectParticipantTablesData(
                                    ParticipantMipIndirectHistoryRepository participantMipIndirectHistoryRepository,
                                    ParticipantMipIndirectContactsRepository participantMipIndirectContactsRepository,
                                    ParticipantMipIndirectRepository participantMipIndirectRepository,
                                    ParticipantMipRepository participantMipRepository) {
        //@formatter:on
        Optional.ofNullable(participantMipIndirectHistoryRepository)
            .ifPresent(ParticipantMipIndirectDataSetUtil::removeFKFromHistoryAvoidingExceptionOnDelete);
        Optional.ofNullable(participantMipIndirectHistoryRepository)
            .ifPresent(ParticipantMipIndirectHistoryRepository::deleteAll);
        Optional.ofNullable(participantMipIndirectHistoryRepository)
            .ifPresent(ParticipantMipIndirectHistoryRepository::flush);
        Optional.ofNullable(participantMipIndirectContactsRepository)
            .ifPresent(ParticipantMipIndirectDataSetUtil::removeFKFromContactAvoidingExceptionOnDelete);
        Optional.ofNullable(participantMipIndirectContactsRepository)
            .ifPresent(ParticipantMipIndirectContactsRepository::deleteAll);
        Optional.ofNullable(participantMipIndirectContactsRepository)
            .ifPresent(ParticipantMipIndirectContactsRepository::flush);
        participantMipIndirectRepository.deleteAll();
        participantMipIndirectRepository.flush();
        participantMipRepository.findByIspb(ISPB).ifPresent(participantMipRepository::delete);
        participantMipRepository.flush();
    }

    //@formatter:off
    public static void removeFKFromContactAvoidingExceptionOnDelete(
                                    ParticipantMipIndirectContactsRepository participantMipIndirectContactsRepository) {
        participantMipIndirectContactsRepository.findAll().forEach(contactsEntity -> {
            contactsEntity.setParticipantMip(null);
            participantMipIndirectContactsRepository.saveAndFlush(contactsEntity);
        });
    }

    public static void removeFKFromHistoryAvoidingExceptionOnDelete(
                                      ParticipantMipIndirectHistoryRepository participantMipIndirectHistoryRepository) {
        participantMipIndirectHistoryRepository.findAll().forEach(historyEntity -> {
            historyEntity.setEvent(null);
            participantMipIndirectHistoryRepository.saveAndFlush(historyEntity);
        });
    }

    public static ParticipantMipIndirectHistoryEntity createParticipantMipIndirectHistoryEntity(
                                                            ParticipantMipIndirectEntity participantMipIndirectEntity) {
        final ParticipantMipIndirectHistoryEntity historyEntity = new ParticipantMipIndirectHistoryEntity();

        historyEntity.setType(HISTORY_TYPE);
        historyEntity.setEventDateTime(HISTORY_EVENT_DATE_TIME);
        historyEntity.setParticipantMip(participantMipIndirectEntity);
        historyEntity.setPreviousStatus(participantMipIndirectEntity.getStatus());

        return historyEntity;
    }

    //@formatter:on

    public static ParticipantMipIndirectStatusRepository getMockedStatusRepoReturningActiveById() {
        final ParticipantMipIndirectStatusRepository repo = Mockito.mock(ParticipantMipIndirectStatusRepository.class);

        Mockito.when(repo.findById(IndirectParticipantStatusEnum.ACTIVE.getId()))
            .thenReturn(Optional.of(createParticipantMipIndirectStatusEntity()));

        return repo;
    }

    public static List<ParticipantMipIndirectEntity> createParticipantMipIndirectEntitiesWithDifferentStatus(
        ParticipantMipIndirectStatusRepository participantMipIndirectStatusRepository) {

        List<ParticipantMipIndirectEntity> indirectParticipants = new ArrayList<>();

        for (int i = 1; i <= 5; i++) {
            final ParticipantMipIndirectEntity participantMipIndirect = new ParticipantMipIndirectEntity();

            participantMipIndirect.setParticipantMip(createParticipantMip(666666 + i));
            participantMipIndirect.setName(INDIRECT_PARTICIPANT_NAME + i);
            participantMipIndirect.setCorporateName(CORPORATE_NAME);
            participantMipIndirect.setTaxId(TAX_ID);
            participantMipIndirect
                .setStatus(findParticipantMipIndirectStatus(participantMipIndirectStatusRepository, i));
            participantMipIndirect.setContractInitDate(CONTRACT_INIT_DATE);
            participantMipIndirect.setContractEndDate(CONTRACT_END_DATE);
            indirectParticipants.add(participantMipIndirect);
        }

        return indirectParticipants;
    }

}
