package matera.spi.main.domain.service.pacs.pacs002;

import matera.spi.main.domain.model.enums.TransactionStatus;
import matera.spi.main.domain.model.message.MessageCatalogSpecificationEntity;
import matera.spi.main.domain.service.MessageCatalogSpecificationService;
import matera.spi.main.domain.service.MessageIdService;

import matera.spi.main.domain.service.pacs.pacs002.dto.ContentPacs002;

import org.apache.commons.lang.StringUtils;

import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ContentPacs002GeneratorTest {

    private static final String MESSAGE_ID = "M12345678";
    private static final String END_TO_END_ID = "E12345678";
    public static final String PACS_002_SPI_1_4 = "pacs.002.spi.1.4";

    @Mock
    private MessageIdService messageIdService;

    @Mock
    private MessageCatalogSpecificationService messageCatalogSpecificationService;

    @InjectMocks
    private ContentPacs002Generator contentPacs002Generator;

    @Test
    void shouldGenerateAContentPacs002() {
        Mockito.when(messageIdService.generateMsgId()).thenReturn(MESSAGE_ID);
        Mockito.when(messageCatalogSpecificationService.findMessageCatalogSpecificationByCode("pacs.002"))
            .thenReturn(buildMessageCatalogSpecificationMock());

        ContentPacs002 contentPacs002 = contentPacs002Generator.generate(END_TO_END_ID, TransactionStatus.ACSP.name());

        Assertions.assertNotNull(contentPacs002);
        Assertions.assertNotNull(contentPacs002.getCreationDate());
        Assertions.assertNotNull(contentPacs002.getMessageId());
        Assertions.assertNotNull(contentPacs002.getEndToEndId());
        Assertions.assertEquals(PACS_002_SPI_1_4, contentPacs002.getMessageIdentifier());
        Assertions.assertNotNull(contentPacs002.getTransactionStatus());
    }

    @Test
    void shouldThrowNullPointerExceptionWhenMessageIdAndEndToEndIdIsNull() {
        Mockito.when(messageIdService.generateMsgId()).thenReturn(null);
        Assertions.assertThrows(NullPointerException.class, () -> contentPacs002Generator.generate(null,null));
    }

    @Test
    void shouldGenerateAContentPacs002WithMessageIdAndEndToEndIdEmpty() {
        Mockito.when(messageIdService.generateMsgId()).thenReturn(StringUtils.EMPTY);
        Mockito.when(messageCatalogSpecificationService.findMessageCatalogSpecificationByCode("pacs.002"))
            .thenReturn(buildMessageCatalogSpecificationMock());

        ContentPacs002 contentPacs002 = contentPacs002Generator.generate(StringUtils.EMPTY, TransactionStatus.ACSP.name());

        Assertions.assertNotNull(contentPacs002);
        Assertions.assertNotNull(contentPacs002.getCreationDate());
        Assertions.assertEquals(PACS_002_SPI_1_4, contentPacs002.getMessageIdentifier());
        Assertions.assertNotNull(contentPacs002.getTransactionStatus());
        Assertions.assertEquals(StringUtils.EMPTY, contentPacs002.getMessageId());
        Assertions.assertEquals(StringUtils.EMPTY, contentPacs002.getEndToEndId());
    }

    @Test
    void shouldGenerateAContentPacs002AddNullAdditionalInformation() {
        Mockito.when(messageIdService.generateMsgId()).thenReturn(MESSAGE_ID);
        Mockito.when(messageCatalogSpecificationService.findMessageCatalogSpecificationByCode("pacs.002"))
            .thenReturn(buildMessageCatalogSpecificationMock());

        ContentPacs002 contentPacs002 = contentPacs002Generator.generate(END_TO_END_ID, TransactionStatus.ACSP.name());

        contentPacs002.addAdditionalInformation(null);

        Assertions.assertEquals(0, contentPacs002.getAdditionalInformations().size());
    }

    @Test
    void shouldGenerateAContentPacs002AddEmptyAdditionalInformation() {
        Mockito.when(messageIdService.generateMsgId()).thenReturn(MESSAGE_ID);
        Mockito.when(messageCatalogSpecificationService.findMessageCatalogSpecificationByCode("pacs.002"))
            .thenReturn(buildMessageCatalogSpecificationMock());

        ContentPacs002 contentPacs002 = contentPacs002Generator.generate(END_TO_END_ID, TransactionStatus.ACSP.name());

        contentPacs002.addAdditionalInformation(StringUtils.EMPTY);

        Assertions.assertEquals(0, contentPacs002.getAdditionalInformations().size());
    }

    @Test
    void shouldGenerateAContentPacs002AddAdditionalInformation() {
        Mockito.when(messageIdService.generateMsgId()).thenReturn(MESSAGE_ID);
        Mockito.when(messageCatalogSpecificationService.findMessageCatalogSpecificationByCode("pacs.002"))
            .thenReturn(buildMessageCatalogSpecificationMock());

        ContentPacs002 contentPacs002 = contentPacs002Generator.generate(END_TO_END_ID, TransactionStatus.ACSP.name());

        contentPacs002.addAdditionalInformation("Test");

        Assertions.assertEquals(1, contentPacs002.getAdditionalInformations().size());
    }

    @NotNull
    private MessageCatalogSpecificationEntity buildMessageCatalogSpecificationMock() {
        MessageCatalogSpecificationEntity messageCatalogSpecificationEntity = new MessageCatalogSpecificationEntity();
        messageCatalogSpecificationEntity.setMessageDefinition(PACS_002_SPI_1_4);

        return messageCatalogSpecificationEntity;
    }
}
