package matera.spi.main.domain.service.internal;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.exception.InternalClearingAccountDebitReverterException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

@IntegrationTest
class InternalClearingAccountTransactionReverterTest  {

	@Autowired
	private InternalClearingAccountService clearingAccountService;

	@Autowired
	private InternalClearingAccountTransactionReverterService debitReverterService;

	@ParameterizedTest(name = "[{index}] reverting debit of {0} value")
	@DisplayName("should reverts the DEBIT done identified by a transaction id")
	@ValueSource(doubles = {0.01, 9999.99, 123456.09})
	void shouldRevertsBalanceWhenGivenTheLastDebitTransactionId(double value) {
		BigDecimal debitValue = BigDecimal.valueOf(value);
		BigDecimal debitTransactionId = clearingAccountService.createDebitTransaction(debitValue);
		givenSomeOtherTransactions();
		BigDecimal balanceBeforeDebitRevert = clearingAccountService.getCurrentBalance();

		debitReverterService.revertDebit(debitTransactionId);

		assertThat(balanceBeforeDebitRevert).isEqualTo(clearingAccountService.getCurrentBalance().subtract(debitValue));
	}

	@Test
	@DisplayName("should thrown an InternalClearingAccountDebitReverterException when trying to revert a CREDIT transaction")
	void shouldThrowAnExceptionWhenGivenACreditTransactionId() {
		BigDecimal creditTransactionId = clearingAccountService.createCreditTransaction(BigDecimal.valueOf(9999.99));

		BigDecimal balanceBeforeDebitRevert = clearingAccountService.getCurrentBalance();

		assertThatThrownBy(() -> debitReverterService.revertDebit(creditTransactionId))
				.isInstanceOf(InternalClearingAccountDebitReverterException.class)
				.hasMessage("ID %s is a CREDIT transaction, can only revert debit transactions.", creditTransactionId);
		BigDecimal postDebitRevertBalance = clearingAccountService.getCurrentBalance();
		assertThat(balanceBeforeDebitRevert).isEqualTo(postDebitRevertBalance);
	}

	@Test
	@DisplayName("should thrown an InternalClearingAccountDebitReverterException when trying to revert a transaction with id that doesn't exist")
	void shouldNotRevertBalanceWhenGivenACreditTransactionId() {
		BigDecimal lastBalance = clearingAccountService.getCurrentBalance();

		assertThatThrownBy(() -> debitReverterService.revertDebit(BigDecimal.valueOf(9999L)))
				.isInstanceOf(InternalClearingAccountDebitReverterException.class)
				.hasMessage("Not found debit with id 9999 to revert.");

		assertThat(lastBalance).isEqualTo(clearingAccountService.getCurrentBalance());

	}

	private void givenSomeOtherTransactions() {
		clearingAccountService.createCreditTransaction(BigDecimal.valueOf(123456.99));

		clearingAccountService.createDebitTransaction(BigDecimal.valueOf(100));
		clearingAccountService.createDebitTransaction(BigDecimal.valueOf(999.99));

		clearingAccountService.createCreditTransaction(BigDecimal.valueOf(111.11));

		clearingAccountService.createDebitTransaction(BigDecimal.valueOf(50.05));
	}
}
