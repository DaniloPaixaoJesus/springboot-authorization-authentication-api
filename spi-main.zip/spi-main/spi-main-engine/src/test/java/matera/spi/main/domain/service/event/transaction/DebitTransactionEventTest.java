package matera.spi.main.domain.service.event.transaction;

import matera.spi.main.config.MainEngineConfiguration;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.transaction.PaymentEventEntity;
import matera.spi.main.domain.model.event.transaction.ReturnSentEventEntity;
import matera.spi.main.domain.service.transaction.AccountsTransactionDispatcher;

import org.assertj.core.api.Condition;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.invocation.Invocation;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Collection;
import java.util.function.Predicate;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockingDetails;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;

@ExtendWith(MockitoExtension.class)
class DebitTransactionEventTest {

    private static final Predicate<Invocation> IS_CUSTOMER_DEBIT_OR_RETURN_SENT = invocation -> {
        String methodName = invocation.getMethod().getName();
        return "customerMakeDebit".equals(methodName) || "customerReturnSent".equals(methodName);
    };

    static Stream<Arguments> debitTransactionEventArguments() {
        PaymentEventEntity paymentEventEntity = new PaymentEventEntity();
        PaymentEvent paymentEvent = new PaymentEvent(paymentEventEntity);

        ReturnSentEventEntity returnSentEventEntity = new ReturnSentEventEntity();
        ReturnSentEvent returnSentEvent = new ReturnSentEvent(returnSentEventEntity);

        return Stream.of(
            Arguments.of(paymentEvent, paymentEventEntity),
            Arguments.of(returnSentEvent, returnSentEventEntity)
        );
    }

    @ParameterizedTest
    @MethodSource("debitTransactionEventArguments")
    void actionsBeforeEventApprovalShouldNotMakeCustomerTransactionWhenIsNotAnTransactionByApi(DebitTransactionEvent debitTransactionEvent) {
        //given
        AccountsTransactionDispatcher transactionDispatcher = mock(AccountsTransactionDispatcher.class);
        ReflectionTestUtils.setField(debitTransactionEvent, "accountsTransactionDispatcher", transactionDispatcher);

        DebitTransactionEvent spiedEvent = spy(debitTransactionEvent);

        //when
        spiedEvent.actionsBeforeEventApproval();

        //then
        verify(spiedEvent, never()).makeCustomerTransaction();
        verifyNoInteractions(transactionDispatcher);
    }

    @ParameterizedTest
    @MethodSource("debitTransactionEventArguments")
    void actionsBeforeEventApprovalShouldNotMakeCustomerTransactionWhenIsTransactionByApiAndIsNotDirectPsp(
        DebitTransactionEvent debitTransactionEvent,
        EventEntity eventEntity) {
        //given
        AccountsTransactionDispatcher transactionDispatcher = mock(AccountsTransactionDispatcher.class);
        ReflectionTestUtils.setField(debitTransactionEvent, "accountsTransactionDispatcher", transactionDispatcher);

        MainEngineConfiguration mainEngineConfiguration = new MainEngineConfiguration();
        ReflectionTestUtils.setField(debitTransactionEvent, "mainEngineConfiguration", mainEngineConfiguration);

        mainEngineConfiguration.setDirectPsp(false);
        eventEntity.setOriginSystem("SOME_ORIGIN_SYSTEM");

        DebitTransactionEvent spiedEvent = spy(debitTransactionEvent);

        //when
        spiedEvent.actionsBeforeEventApproval();

        //then
        verify(spiedEvent, never()).makeCustomerTransaction();
        verifyNoInteractions(transactionDispatcher);
    }

    @ParameterizedTest
    @MethodSource("debitTransactionEventArguments")
    void actionsBeforeEventApprovalShouldMakeCustomerTransactionWhenIsTransactionByApiAndIsDirectPsp(
        DebitTransactionEvent debitTransactionEvent,
        EventEntity eventEntity) {
        //given
        AccountsTransactionDispatcher transactionDispatcher = mock(AccountsTransactionDispatcher.class);
        ReflectionTestUtils.setField(debitTransactionEvent, "accountsTransactionDispatcher", transactionDispatcher);

        MainEngineConfiguration mainEngineConfiguration = new MainEngineConfiguration();
        ReflectionTestUtils.setField(debitTransactionEvent, "mainEngineConfiguration", mainEngineConfiguration);

        eventEntity.setOriginSystem("SOME_ORIGIN_SYSTEM");
        mainEngineConfiguration.setDirectPsp(true);

        DebitTransactionEvent spiedEvent = spy(debitTransactionEvent);

        //when
        spiedEvent.actionsBeforeEventApproval();

        //then
        verify(spiedEvent).makeCustomerTransaction();
        verifyTransactionDispatcherDebitWasCalledOnce(transactionDispatcher);
    }

    private void verifyTransactionDispatcherDebitWasCalledOnce(AccountsTransactionDispatcher transactionDispatcher) {
        Collection<Invocation> invocations = mockingDetails(transactionDispatcher).getInvocations();
        assertThat(invocations).hasSize(1);
        assertThat(invocations.toArray(new Invocation[]{})[0])
            .has(new Condition<>(IS_CUSTOMER_DEBIT_OR_RETURN_SENT, "should called customerMakeDebit or customerMakeReturnSent"));
    }

}
