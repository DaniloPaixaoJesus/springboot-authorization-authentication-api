package matera.spi;

import matera.spi.commons.IntegrationTest;

import com.tngtech.archunit.junit.AnalyzeClasses;
import com.tngtech.archunit.junit.ArchTest;
import com.tngtech.archunit.lang.ArchRule;
import com.tngtech.archunit.lang.syntax.ArchRuleDefinition;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.TestPropertySources;

@AnalyzeClasses(packages = "matera.spi")
public class ArchitecturalConstraintsForTestingTest {

    // @formatter:off
    @ArchTest
    public static final ArchRule testFieldsShouldNotUseMockBeanOrSpyBean = ArchRuleDefinition
        .noFields()
        .should().beAnnotatedWith(MockBean.class)
        .orShould().beAnnotatedWith(SpyBean.class)
        .because("it will force to reload the spring context, use mock/spy and set where it will be used instead");

    @ArchTest
    public static final ArchRule testClassesShouldNotDefineTestPropertySource = ArchRuleDefinition
        .noClasses()
        .should().beAnnotatedWith(TestPropertySource.class)
        .orShould().beAnnotatedWith(TestPropertySources.class)
        .orShould().beAnnotatedWith(TestConfiguration.class)
        .because("it will force to reload the spring context, use a new profile instead");

    @ArchTest
    public static final ArchRule testClassesShouldNotUseDirtiesContextAnnotation = ArchRuleDefinition
        .noClasses()
        .should().beAnnotatedWith(DirtiesContext.class)
        .because("it will force to reload the spring context");

    @ArchTest
    public static final ArchRule testClassesShouldNotUseContextConfiguration = ArchRuleDefinition
        .noClasses()
        .should().beAnnotatedWith(ContextConfiguration.class)
        .because("it will force to reload the spring context");

    @ArchTest
    public static final ArchRule testClassesShouldNotUseSpringBootTestDirectly = ArchRuleDefinition
        .noClasses().that().doNotHaveFullyQualifiedName(IntegrationTest.class.getName())
        .should().beAnnotatedWith(SpringBootTest.class)
        .because("should use @IntegrationTest instead to use the same testing context");

    @ArchTest
    public static final ArchRule testClassesShouldNoDataJPATest = ArchRuleDefinition
        .noClasses()
        .should().beAnnotatedWith(DataJpaTest.class)
        .because("should use @IntegrationTest instead to use the same testing context");

    // @formatter:on

}
