package matera.spi.main.domain.service;

import matera.spi.dto.EntryReply;
import matera.spi.dto.Error;
import matera.spi.main.domain.model.enums.EnumTransactionResultStatus;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventStatusEntity;
import matera.spi.main.domain.model.transaction.TransactionResultEntity;
import matera.spi.main.domain.service.transaction.AccountTransactionReverter;
import matera.spi.main.domain.service.transaction.IdempotencePrefix;
import matera.spi.main.persistence.EventRepositoryWithLock;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static matera.spi.main.domain.model.event.EventStatus.ERROR;
import static matera.spi.main.domain.model.event.EventStatus.PAYMENT_REJECTED;
import static matera.spi.main.domain.model.event.EventStatus.PAYMENT_REJECTED_BY_CLEARING;
import static matera.spi.main.domain.model.event.EventStatus.RECEIPT_REJECTED;
import static matera.spi.main.domain.model.event.EventStatus.RECEIPT_REJECTED_BY_CLEARING;
import static matera.spi.main.domain.model.event.EventStatus.RECEIPT_REJECTION_CONFIRMED;
import static matera.spi.main.domain.model.event.EventStatus.REJECTED;
import static matera.spi.main.domain.model.event.EventStatus.RETURN_REJECTED;
import static matera.spi.main.domain.model.event.EventStatus.RETURN_REJECTED_BY_CLEARING;
import static matera.spi.main.domain.model.event.EventStatus.RETURN_REJECTION_CONFIRMED;
import static matera.spi.main.utils.EntityCreationUtils.buildEventEntity;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AsyncManagementAccountsServiceTest {

    private static final UUID EVENT_ID = UUID.randomUUID();
    private static final Integer ENTRY_ID_VALUE = 1234;
    private static final int CODE_SUCESS = 3;
    private static final String MANAGERIAL_IP_ACCOUNT_PREFIX = IdempotencePrefix.MANAGERIAL_IP_ACCOUNT_PREFIX;
    private static final String MIRROR_IP_ACCOUNT_PREFIX = IdempotencePrefix.MIRROR_IP_ACCOUNT_PREFIX;
    private static final String MESSAGE_ERROR_IDEMPOTENCYID_NULL = "IdempotencyId not provided";
    private static final String MESSAGE_ERROR_PREFIX_INVALID = "Not matching mirror/managerial prefix";
    private static final String MESSAGE_ERROR_TO_ERROR_NULL = "No entryId or error received";
    private static final String ERROR_RETURNED_TO_AMOUNT_DIFFERENT = "Reply entry amount does not matches event value";

    @Mock
    private EventRepositoryWithLock eventRepositoryWithLock;

    @Mock
    private AccountTransactionReverter accountTransactionReverter;

    private ObjectMapper objectMapper = new ObjectMapper();

    @InjectMocks
    private AsyncManagementAccountsService asyncManagementAccountsService;

    @BeforeEach
    void beforeEach(){
        ReflectionTestUtils
            .setField(asyncManagementAccountsService, "objectMapper", objectMapper);

    }

    @Test
    void shouldSaveAnEventEntityWhenTheEntryIsMirrorAccountAndTheIpAccountTransactionResultAttributeIsNull() {
        EntryReply entryReply = createEntryReply(MIRROR_IP_ACCOUNT_PREFIX);
        EventStatusEntity status = createEventStatusEntity(CODE_SUCESS);
        EventEntity eventEntity = createEventEntity(status);

        when(eventRepositoryWithLock.findById(EVENT_ID)).thenReturn(Optional.of(eventEntity));
        assertThat(eventEntity.getIpAccountTransactionResult()).isNull();

        asyncManagementAccountsService.processItem(entryReply);
        verify(eventRepositoryWithLock).save(eq(eventEntity));
        verify(accountTransactionReverter, never()).revert(any());

        validationsOfTheExpectedResult(eventEntity.getIpAccountTransactionResult());
    }

    @Test
    void shouldSaveAnEventEntityWhenTheEntryIsMirrorAccountAndTheIpAccountTransactionResultAttributeIsNotNull() {
        EntryReply entryReply = createEntryReply(MIRROR_IP_ACCOUNT_PREFIX);

        TransactionResultEntity ipAccountTransactionResult = new TransactionResultEntity();
        ipAccountTransactionResult.setIdempotencyIdInDdaSystem(entryReply.getIdempotencyId());

        EventStatusEntity status = createEventStatusEntity(CODE_SUCESS);
        EventEntity eventEntity = createEventEntity(status);
        eventEntity.setIpAccountTransactionResult(ipAccountTransactionResult);

        when(eventRepositoryWithLock.findById(EVENT_ID)).thenReturn(Optional.of(eventEntity));
        assertThat(eventEntity.getIpAccountTransactionResult()).isNotNull();

        asyncManagementAccountsService.processItem(entryReply);
        verify(eventRepositoryWithLock).save(eq(eventEntity));
        verify(accountTransactionReverter, never()).revert(any());

        validationsOfTheExpectedResult(eventEntity.getIpAccountTransactionResult());
    }

    @Test
    void shouldSaveAnEventEntityWhenTheEntryIsManagerialAccountAndTheTransactionResultAttributeIsNull() {
        EntryReply entryReply = createEntryReply(MANAGERIAL_IP_ACCOUNT_PREFIX);
        EventStatusEntity status = createEventStatusEntity(CODE_SUCESS);
        EventEntity eventEntity = createEventEntity(status);

        when(eventRepositoryWithLock.findById(EVENT_ID)).thenReturn(Optional.of(eventEntity));
        assertThat(eventEntity.getTransactionResult()).isNull();

        asyncManagementAccountsService.processItem(entryReply);
        verify(eventRepositoryWithLock).save(eq(eventEntity));
        verify(accountTransactionReverter, never()).revert(any());

        validationsOfTheExpectedResult(eventEntity.getTransactionResult());
    }

    @Test
    void shouldSaveAnEventEntityWhenTheEntryIsManagerialAccountAndTheTransactionResultAttributeIsNotNull() {
        EntryReply entryReply = createEntryReply(MANAGERIAL_IP_ACCOUNT_PREFIX);
        EventStatusEntity status = createEventStatusEntity(CODE_SUCESS);
        EventEntity eventEntity = createEventEntity(status);

        TransactionResultEntity transactionResult = new TransactionResultEntity();
        transactionResult.setIdempotencyIdInDdaSystem(entryReply.getIdempotencyId());
        eventEntity.setTransactionResult(transactionResult);

        when(eventRepositoryWithLock.findById(EVENT_ID)).thenReturn(Optional.of(eventEntity));
        assertThat(eventEntity.getTransactionResult()).isNotNull();

        asyncManagementAccountsService.processItem(entryReply);
        verify(eventRepositoryWithLock).save(eq(eventEntity));
        verify(accountTransactionReverter, never()).revert(any());

        validationsOfTheExpectedResult(eventEntity.getTransactionResult());
    }

    @Test
    void shouldSaveAnEventEntityWithErrorStatusWhenEntryValueIsDifferentFromValueTheEvent() {
        EntryReply entryReply = createEntryReply(MANAGERIAL_IP_ACCOUNT_PREFIX);
        EventStatusEntity status = createEventStatusEntity(CODE_SUCESS);
        EventEntity eventEntity = createEventEntity(status);
        eventEntity.setValue(BigDecimal.TEN);

        when(eventRepositoryWithLock.findById(EVENT_ID)).thenReturn(Optional.of(eventEntity));
        assertThat(eventEntity.getTransactionResult()).isNull();

        asyncManagementAccountsService.processItem(entryReply);
        verify(eventRepositoryWithLock).save(eq(eventEntity));
        verify(accountTransactionReverter, never()).revert(eq(eventEntity));

        assertThat(eventEntity.getTransactionResult()).isNotNull();
        assertThat(eventEntity.getTransactionResult().getErrorReturned()).isEqualTo(ERROR_RETURNED_TO_AMOUNT_DIFFERENT);
        assertThat(eventEntity.getTransactionResult().getTransactionStatus())
            .isEqualTo(EnumTransactionResultStatus.ERROR.getValue());
    }

    @Test
    void shouldSaveAnEventEntityWithErrorStatusWhenIdempontencyIdFromEntryIsDifferentTheIdempotencyIdInDdaSystem() {
        EntryReply entryReply = createEntryReply(MANAGERIAL_IP_ACCOUNT_PREFIX);
        EventStatusEntity status = createEventStatusEntity(CODE_SUCESS);
        EventEntity eventEntity = createEventEntity(status);

        TransactionResultEntity transactionResult = new TransactionResultEntity();
        transactionResult.setIdempotencyIdInDdaSystem(MIRROR_IP_ACCOUNT_PREFIX);
        eventEntity.setTransactionResult(transactionResult);

        when(eventRepositoryWithLock.findById(EVENT_ID)).thenReturn(Optional.of(eventEntity));

        asyncManagementAccountsService.processItem(entryReply);
        verify(eventRepositoryWithLock).save(eq(eventEntity));
        verify(accountTransactionReverter, never()).revert(eq(eventEntity));

        assertThat(eventEntity.getTransactionResult()).isNotNull();
        assertThat(eventEntity.getTransactionResult().getErrorReturned())
            .isEqualTo("IdempotencyId _ACCOUNT_ did not match transaction result idempotencyId");
        assertThat(eventEntity.getTransactionResult().getTransactionStatus())
            .isEqualTo(EnumTransactionResultStatus.ERROR.getValue());
    }

    @ParameterizedTest
    @MethodSource("getEventStatusFromErrors")
    void shouldSaveAnEventEntityAndCallTheRevertMethodWhenEntryIdIsNotNull(Integer codeStatus) {
        EntryReply entryReply = createEntryReply(MANAGERIAL_IP_ACCOUNT_PREFIX);

        EventStatusEntity status = createEventStatusEntity(codeStatus, true);
        EventEntity eventEntity = createEventEntity(status);

        when(eventRepositoryWithLock.findById(EVENT_ID)).thenReturn(Optional.of(eventEntity));
        assertThat(eventEntity.getTransactionResult()).isNull();

        asyncManagementAccountsService.processItem(entryReply);
        verify(eventRepositoryWithLock).save(eq(eventEntity));
        verify(accountTransactionReverter).revert(any());

        assertThat(eventEntity.getTransactionResult()).isNotNull();
        assertThat(eventEntity.getTransactionResult().getTransactionStatus())
            .isEqualTo(EnumTransactionResultStatus.SUCCESS.getValue());
    }

    @ParameterizedTest
    @MethodSource("getEventStatusFromErrors")
    void shouldSaveAnEventEntityWithStatusErrorAndNotMakeTheErrorMessageTruncatedWhenEntryIdIsNullAndErrorIsNull(Integer codeStatus) {
        EntryReply entryReply = createEntryReply(MANAGERIAL_IP_ACCOUNT_PREFIX);
        entryReply.setEntryId(null);
        EventStatusEntity status = createEventStatusEntity(codeStatus);
        EventEntity eventEntity = createEventEntity(status);

        when(eventRepositoryWithLock.findById(EVENT_ID)).thenReturn(Optional.of(eventEntity));
        assertThat(eventEntity.getTransactionResult()).isNull();

        asyncManagementAccountsService.processItem(entryReply);
        verify(eventRepositoryWithLock).save(eq(eventEntity));
        verify(accountTransactionReverter, never()).revert(eq(eventEntity));

        assertThat(eventEntity.getTransactionResult()).isNotNull();
        assertThat(eventEntity.getTransactionResult().getErrorReturned()).isEqualTo(MESSAGE_ERROR_TO_ERROR_NULL);
        assertThat(eventEntity.getTransactionResult().getTransactionStatus())
            .isEqualTo(EnumTransactionResultStatus.ERROR.getValue());
    }

    @ParameterizedTest
    @MethodSource("getEventStatusFromErrors")
    void shouldSaveAnEventEntityAndMakeTheErrorMessageTruncatedWhenEntryIdIsNullAndErrorIsNotNull(Integer codeStatus) {
        EntryReply entryReply = createEntryReply(MIRROR_IP_ACCOUNT_PREFIX);
        entryReply.setEntryId(null);
        List<Error> errors = List.of(new Error());
        entryReply.setErrors(errors);

        EventStatusEntity status = createEventStatusEntity(codeStatus);
        EventEntity eventEntity = createEventEntity(status);

        when(eventRepositoryWithLock.findById(EVENT_ID)).thenReturn(Optional.of(eventEntity));
        assertThat(eventEntity.getIpAccountTransactionResult()).isNull();

        asyncManagementAccountsService.processItem(entryReply);
        verify(eventRepositoryWithLock).save(eq(eventEntity));
        verify(accountTransactionReverter, never()).revert(any());

        assertThat(eventEntity.getIpAccountTransactionResult()).isNotNull();
        assertThat(eventEntity.getIpAccountTransactionResult().getErrorReturned()).isNotNull();
        assertThat(eventEntity.getIpAccountTransactionResult().getTransactionStatus())
            .isEqualTo(EnumTransactionResultStatus.ERROR.getValue());
    }

    @Test
    void shouldThrowIllegalArgumentExceptionWhenIdempotencyIdIsNull() {
        EntryReply entryReply = createEntryReply(null);

        assertThatThrownBy(() -> asyncManagementAccountsService.processItem(entryReply))
            .isInstanceOf(IllegalArgumentException.class)
            .hasMessage(MESSAGE_ERROR_IDEMPOTENCYID_NULL);
    }

    @Test
    void shouldThrowIllegalArgumentExceptionWhenIdempotencyIdIsInvalid() {
        EntryReply entryReply = createEntryReply("foo");

        assertThatThrownBy(() -> asyncManagementAccountsService.processItem(entryReply))
            .isInstanceOf(IllegalArgumentException.class)
            .hasMessage(MESSAGE_ERROR_PREFIX_INVALID);
    }

    @Test
    void shouldThrowIllegalArgumentExceptionWhenEventIdIsNotFound() {
        EntryReply entryReply = createEntryReply(MANAGERIAL_IP_ACCOUNT_PREFIX);
        entryReply.setDetails(String.valueOf(EVENT_ID));

        assertThatThrownBy(() -> asyncManagementAccountsService.processItem(entryReply))
            .isInstanceOf(IllegalArgumentException.class).hasMessage("Not found event with id " + EVENT_ID);
    }

    @ParameterizedTest
    @ValueSource(strings = {MIRROR_IP_ACCOUNT_PREFIX, MANAGERIAL_IP_ACCOUNT_PREFIX})
    void shouldThrowIllegalArgumentExceptionWhenEventEntityStatusIsNull(String idempotencyId) {
        EntryReply entryReply = createEntryReply(idempotencyId);
        EventEntity eventEntity = createEventEntity(null);

        when(eventRepositoryWithLock.findById(EVENT_ID)).thenReturn(Optional.of(eventEntity));
        assertThatThrownBy(() -> asyncManagementAccountsService.processItem(entryReply))
            .isInstanceOf(IllegalArgumentException.class)
            .hasMessage("EventEntity[" + eventEntity.getId() + "] does not have status");
    }

    private void validationsOfTheExpectedResult(TransactionResultEntity ipAccountTransactionResult) {
        assertThat(ipAccountTransactionResult).isNotNull();
        assertThat(ipAccountTransactionResult.getTransactionIdInDdaSystem()).isEqualTo(ENTRY_ID_VALUE.toString());
        assertThat(ipAccountTransactionResult.getTransactionStatus())
            .isEqualTo(EnumTransactionResultStatus.SUCCESS.getValue());
    }

    private static EntryReply createEntryReply(String idempontecyId) {
        EntryReply entryReply = new EntryReply();
        entryReply.setDetails(String.valueOf(EVENT_ID));
        entryReply.setEntryId(BigDecimal.valueOf(ENTRY_ID_VALUE));
        entryReply.setIdempotencyId(idempontecyId);
        entryReply.setAmount(BigDecimal.ONE);
        return entryReply;
    }

    private static EventStatusEntity createEventStatusEntity(Integer code) {
        return createEventStatusEntity(code, false);
    }

    private static EventStatusEntity createEventStatusEntity(Integer code, boolean isRejection) {
        EventStatusEntity status = new EventStatusEntity();
        status.setCode(code);
        status.setRejectionStatus(isRejection);
        return status;
    }

    private static EventEntity createEventEntity(EventStatusEntity status) {
        EventEntity eventEntity = buildEventEntity();
        eventEntity.setStatus(status);
        return eventEntity;
    }

    private static Stream<Arguments> getEventStatusFromErrors() {
        return Stream.of(
            Arguments.of(ERROR.getCode()),
            Arguments.of(PAYMENT_REJECTED.getCode()),
            Arguments.of(PAYMENT_REJECTED_BY_CLEARING.getCode()),
            Arguments.of(RECEIPT_REJECTED.getCode()),
            Arguments.of(RECEIPT_REJECTED_BY_CLEARING.getCode()),
            Arguments.of(RECEIPT_REJECTION_CONFIRMED.getCode()),
            Arguments.of(REJECTED.getCode()),
            Arguments.of(RETURN_REJECTED.getCode()),
            Arguments.of(RETURN_REJECTED_BY_CLEARING.getCode()),
            Arguments.of(RETURN_REJECTION_CONFIRMED.getCode())
        );
    }

    private static List<EventStatusEntity> buildRejectionEventStatusList() {

        return getEventStatusFromErrors()
            .map(argument -> {
                Integer code = (Integer)argument.get()[0];

                EventStatusEntity eventStatusEntity = new EventStatusEntity();
                eventStatusEntity.setCode(code);

                return eventStatusEntity;
            })
            .collect(Collectors.toList());
    }

}
