
package matera.spi.main.transactions.adapter.internal;

import com.matera.client.exception.BadRequestException;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.BalanceAccountPiEntity;
import matera.spi.main.domain.model.IpAccountConfigEntity;
import matera.spi.main.domain.model.enums.EnumTransactionType;
import matera.spi.main.domain.service.IpAccountConfigurationService;
import matera.spi.main.dto.AccountTransactionRequestDTO;
import matera.spi.main.dto.QueryBalanceRequestDTO;
import matera.spi.main.persistence.BalanceAccountPiRepository;
import matera.spi.main.transactions.port.AccountTransactionExecutorPort;

import org.jetbrains.annotations.Nullable;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.event.annotation.BeforeTestClass;
import org.springframework.web.server.ServerErrorException;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;


@IntegrationTest
class InternalRepositoryClearingAccountTransactionExecutorAdapterTest  {

    Logger logger = Logger.getLogger(String.valueOf(
        InternalRepositoryClearingAccountTransactionExecutorAdapterTest.class));

    //BalanceAccountPiEntity
    private static final BigDecimal BALANCE_ACCOUNT = new BigDecimal("12345678.00");
    private static final BigDecimal VALUE_ACCOUNT = new BigDecimal  ("11111111.00");

    //ClearingAccountRequestDTO
    private static final String IDEMPOTENCE_ID_DTO = "2345234523";
    private static final BigDecimal VALUE_DTO = new BigDecimal  ("11111111.00");
    private static final String END_TO_END_ID_DTO = "0989076756756";
    private static final boolean VALIDATE_BALANCE_DTO = true;

    @Autowired
    private BalanceAccountPiRepository balanceAccountPiRepository;
    @Autowired
    private IpAccountConfigurationService ipAccountConfigurationService;
    @Autowired
    private AccountTransactionExecutorPort accountTransactionExecutorPort;

    @BeforeTestClass
    void clearDatabaseBalanceAccountPi() {
        balanceAccountPiRepository.deleteAll();
    }

    @Test
    @DisplayName("get Balance ClearingAccountTransactionExecutorPort")
    void getBalanceClearingAccountTransactionPort() {
        salveAndFlushBalanceAccountPiEntity();
        BigDecimal balance = accountTransactionExecutorPort.queryBalance(buildQueryBalanceRequestDTO()).getBalanceAvailable();
        Assertions.assertEquals(BALANCE_ACCOUNT,balance);
    }

    @Nullable
    private QueryBalanceRequestDTO buildQueryBalanceRequestDTO() {
        IpAccountConfigEntity ipAccountConfigEntity = findIpAccountConfigEntity();
        return QueryBalanceRequestDTO.builder()
            .branch(ipAccountConfigEntity.getBranch())
            .account(ipAccountConfigEntity.getAccountNumber())
            .build();
    }

    @Test
    @DisplayName("make transaction ClearingAccountTransactionExecutorPort")
    void makeTransactionClearingAccountTransactionPort() {
        AccountTransactionRequestDTO accountsTransactionDTO = createObjectClearingAccountResponseDTO();
        BigDecimal id = null;
        try{
            id = accountTransactionExecutorPort.makeTransaction(accountsTransactionDTO).getTransactionId();
        }catch (BadRequestException b){
            logger.finest("BadRequestException : make transaction ClearingAccountTransactionExecutorPort");
        }catch (ServerErrorException s){
            logger.finest("ServerErrorException : make transaction ClearingAccountTransactionExecutorPort");
        }
        Assertions.assertNotNull(id);
    }

    private BalanceAccountPiEntity createObjectBalanceAccountPiEntity() {
        BalanceAccountPiEntity balanceAccountPiEntity = new BalanceAccountPiEntity();
        balanceAccountPiEntity.setBalance(BALANCE_ACCOUNT);
        balanceAccountPiEntity.setValue(VALUE_ACCOUNT);
        balanceAccountPiEntity.setTransactionType(EnumTransactionType.CREDIT);
        return balanceAccountPiEntity;
    }

    void salveAndFlushBalanceAccountPiEntity() {
        BalanceAccountPiEntity balanceAccountPiEntity = createObjectBalanceAccountPiEntity();
        balanceAccountPiRepository.saveAndFlush(balanceAccountPiEntity);
        List<BalanceAccountPiEntity> listBalance = balanceAccountPiRepository.findAll();
        Assertions.assertTrue(listBalance.contains(balanceAccountPiEntity));
    }

    private AccountTransactionRequestDTO createObjectClearingAccountResponseDTO() {
        IpAccountConfigEntity ipAccountConfigEntity = findIpAccountConfigEntity();
        return AccountTransactionRequestDTO.builder()
            .idempotenceId(IDEMPOTENCE_ID_DTO)
            .endToEndId(END_TO_END_ID_DTO)
            .account(ipAccountConfigEntity.getAccountNumber())
            .branch(ipAccountConfigEntity.getBranch())
            .validateBalance(VALIDATE_BALANCE_DTO)
            .value(VALUE_DTO)
            .transactionType(ipAccountConfigEntity.getCreditTransactionType())
            .eventId(UUID.randomUUID())
            .groupEntries(false)
            .build();
    }

    private IpAccountConfigEntity findIpAccountConfigEntity() {
        return ipAccountConfigurationService.findConfig().orElse(null);
    }

}
