package matera.spi.main.domain.service.event.receiver;

import matera.spi.dto.AccountTypeUIDTO;
import matera.spi.dto.CreditTopicContract;
import matera.spi.main.config.MainEngineConfiguration;
import matera.spi.main.domain.model.account.PayerAccountEntity;
import matera.spi.main.domain.model.account.ReceiverAccountEntity;
import matera.spi.main.domain.model.event.EventStatus;
import matera.spi.main.domain.model.event.EventStatusEntity;
import matera.spi.main.domain.model.event.transaction.CreditEventEntity;
import matera.spi.main.domain.model.event.transaction.ReceiptEventEntity;
import matera.spi.main.domain.model.transaction.ReceiptEntity;
import matera.spi.main.domain.service.CreditTopicContractQueue;
import matera.spi.main.domain.service.FireStatusTransitionService;
import matera.spi.main.domain.service.event.EventFactory;
import matera.spi.main.domain.service.event.transaction.CreditTransactionEvent;
import matera.spi.main.domain.service.event.transaction.DebitTransactionEvent;
import matera.spi.main.utils.EntityCreationUtils;
import matera.spi.utils.JsonService;
import matera.spi.utils.LocalDateTimeUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.messaging.support.GenericMessage;

import java.util.Optional;
import java.util.UUID;

import static matera.spi.main.utils.EntityCreationUtils.RECEIPT_EVENT_TYPE_CODE;
import static matera.spi.main.utils.EntityCreationUtils.buildEventTypeEntity;
import static matera.spi.main.utils.EntityCreationUtils.buildReceiptEntity;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AccountTransactionReceiverTest {

    private static final UUID EVENT_ID = UUID.randomUUID();

    @InjectMocks
    AccountTransactionReceiver accountTransactionReceiver;
    @Spy
    private final JsonService jsonService = new JsonService(new ObjectMapper());
    @Mock
    private CreditTopicContractQueue creditTopicContractQueue;
    @Mock
    private EventFactory eventFactory;
    @Mock
    private FireStatusTransitionService fireStatusTransitionService;
    @Mock
    private MainEngineConfiguration mainEngineConfiguration;

    @Test
    void shouldMakeCustomerTransactionWhenEventIsPendingCreditHolder() throws JSONException {
        JSONObject json = new JSONObject().put("eventId", EVENT_ID);

        CreditTransactionEvent eventMock = mock(CreditTransactionEvent.class);
        when(eventFactory.findById(EVENT_ID)).thenReturn(Optional.of(eventMock));

        Integer pendingCreditStatusCode = EventStatus.PENDING_CREDIT_ACCOUNT_HOLDER.getCode();

        CreditEventEntity eventEntity = buildEventEntity(pendingCreditStatusCode);
        when(eventMock.getEventEntity()).thenReturn(eventEntity);
        when(eventMock.getEndToEndId()).thenReturn(eventEntity.getCorrelationId());
        when(eventMock.shouldDoCustomerTransaction()).thenReturn(true);
        accountTransactionReceiver.onMessage(new GenericMessage<>(json.toString()));

        verify(eventMock).save();
        verify(eventMock).makeCustomerTransaction();
        verifyNoMoreInteractions(eventMock);
        verify(fireStatusTransitionService).fireStatusTransition(eventEntity, EventStatus.SUCCESS);
        verify(creditTopicContractQueue).send(any(CreditTopicContract.class), any());
        Assertions.assertEquals(eventMock.getEndToEndId(), eventEntity.getCorrelationId());

    }

    @Test
    void shouldNotMakeCustomerTransactionWhenEventShouldDoCustomerTransactionIsFalse() throws JSONException {
        JSONObject json = new JSONObject().put("eventId", EVENT_ID);

        CreditTransactionEvent eventMock = mock(CreditTransactionEvent.class);
        when(eventFactory.findById(EVENT_ID)).thenReturn(Optional.of(eventMock));

        Integer pendingCreditStatusCode = EventStatus.PENDING_CREDIT_ACCOUNT_HOLDER.getCode();

        CreditEventEntity eventEntity = buildEventEntity(pendingCreditStatusCode);
        when(eventMock.getEventEntity()).thenReturn(eventEntity);
        when(eventMock.shouldDoCustomerTransaction()).thenReturn(false);
        accountTransactionReceiver.onMessage(new GenericMessage<>(json.toString()));

        verify(eventMock).save();
        verify(eventMock, never()).makeCustomerTransaction();
        verifyNoMoreInteractions(eventMock);
        verify(fireStatusTransitionService).fireStatusTransition(eventEntity, EventStatus.SUCCESS);
        verify(creditTopicContractQueue).send(any(CreditTopicContract.class), any());

    }

    @Test
    void shouldNotMakeCustomerTransactionWhenEventDifferent() throws JSONException {
        JSONObject json = new JSONObject().put("eventId", EVENT_ID);

        CreditTransactionEvent eventMock = mock(CreditTransactionEvent.class);
        when(eventFactory.findById(EVENT_ID)).thenReturn(Optional.of(eventMock));

        Integer successCreditStatusCode = EventStatus.SUCCESS.getCode();

        CreditEventEntity eventEntity = buildEventEntity(successCreditStatusCode);
        when(eventMock.getEventEntity()).thenReturn(eventEntity);
        accountTransactionReceiver.onMessage(new GenericMessage<>(json.toString()));

        verify(eventMock).save();
        verify(eventMock, never()).makeCustomerTransaction();
        verifyNoMoreInteractions(eventMock);
        verify(creditTopicContractQueue).send(any(CreditTopicContract.class), any());
    }

    @Test
    void shouldThrowIllegalArgumentExceptionWhenEventItsNotCreditTransactionEvent() throws JSONException {
        JSONObject json = new JSONObject().put("eventId", EVENT_ID);

        DebitTransactionEvent eventMock = mock(DebitTransactionEvent.class);
        when(eventFactory.findById(EVENT_ID)).thenReturn(Optional.of(eventMock));

        assertThatThrownBy(() -> accountTransactionReceiver.onMessage(new GenericMessage<>(json.toString())))
            .isInstanceOf(IllegalArgumentException.class)
            .hasMessage("Event with id %s it's not an CreditTransactionEvent", EVENT_ID);
    }

    @Test
    void shouldThrowIllegalArgumentExceptionWhenNotFoundEventWithTheGivenId() throws JSONException {
        JSONObject json = new JSONObject().put("eventId", EVENT_ID);
        assertThatThrownBy(() -> accountTransactionReceiver.onMessage(new GenericMessage<>(json.toString())))
            .isInstanceOf(IllegalArgumentException.class)
            .hasMessage("Not found event with id %s", EVENT_ID);
    }


    @NotNull
    private CreditEventEntity buildEventEntity(int statusCode) {
        ReceiptEventEntity receiptEventEntity =
            (ReceiptEventEntity) EntityCreationUtils.buildEventEntity(RECEIPT_EVENT_TYPE_CODE);
        receiptEventEntity.setEventTypeEntity(buildEventTypeEntity());
        receiptEventEntity.setId(EVENT_ID);
        receiptEventEntity.setStatus(buildStatusEntity(statusCode));

        ReceiptEntity receiptEntity = buildReceiptEntity();
        receiptEntity.setPayerAccount(buildPayerAccountEntity());
        receiptEntity.setReceiverAccount(buildReceiverAccountEntity());
        receiptEntity.setCustomerInitTimestampUtc(LocalDateTimeUtils.getUtcLocalDateTime());
        receiptEventEntity.setReceiptEntity(receiptEntity);

        return receiptEventEntity;
    }

    private PayerAccountEntity buildPayerAccountEntity() {
        PayerAccountEntity entity = new PayerAccountEntity();
        entity.setTaxId("1230");
        entity.setName("PAYER_NAME");
        entity.setBranch("1234");
        entity.setAccount("22233344");
        entity.setAccountType(AccountTypeUIDTO.CACC.name());

        return entity;
    }

    private ReceiverAccountEntity buildReceiverAccountEntity() {
        ReceiverAccountEntity entity = new ReceiverAccountEntity();
        entity.setTaxId("3210");
        entity.setBranch("4321");
        entity.setAccount("55566677");
        entity.setAddressingKey("teste@teste.com");
        entity.setAccountType(AccountTypeUIDTO.SVGS.name());

        return entity;
    }

    @NotNull
    private EventStatusEntity buildStatusEntity(int statusCode) {
        EventStatusEntity eventStatusEntity = new EventStatusEntity();
        eventStatusEntity.setCode(statusCode);
        return eventStatusEntity;
    }
}
