package matera.spi.main.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.message.MessageTypeEntity;
import matera.spi.main.utils.EntityCreationUtils;

import org.assertj.core.api.SoftAssertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.opentest4j.AssertionFailedError;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.jupiter.api.Assertions.assertEquals;

@IntegrationTest
class MessageTypeRepositoryTest {

    @Autowired
    private MessageTypeRepository messageTypeRepository;

    @Test
    void shouldBeFindEntityWhenInserted() {
        MessageTypeEntity expected = new MessageTypeEntity();
        expected.setCode("MessageCodeTest");
        expected.setIsFinancial(false);

        messageTypeRepository.saveAndFlush(expected);

        MessageTypeEntity actual = messageTypeRepository.findById(expected.getCode()).orElse(null);

        assertEquals(expected, actual);

    }

    @DisplayName("Verifying if the ME_MESSAGE_TYPE default values are added correctly")
    @ParameterizedTest(name = "for code: {0}")
    @CsvFileSource(resources = "/parameterized/csv/MessageTypeRepositoryTest-default-values.csv", numLinesToSkip = 1)
    void shouldEventTypeDefaultValuesBeAdded(String code,
                                             boolean isFinancial,
                                             String replyElement,
                                             String correlationIdElement,
                                             String statusElement,
                                             Integer newEventTypeCode,
                                             Integer originalEventTypeCode) {
        MessageTypeEntity actualMessageTypeEntity = messageTypeRepository.findById(code)
            .orElseThrow(() -> new AssertionFailedError("not found MessageTypeEntity with id: " + code));

        SoftAssertions softly = new SoftAssertions();
        softly.assertThat(actualMessageTypeEntity.getCode()).as("code").isEqualTo(code);
        softly.assertThat(actualMessageTypeEntity.getIsFinancial()).as("isFinancial").isEqualTo(isFinancial);
        softly.assertThat(actualMessageTypeEntity.getReplyElement()).as("replyElement").isEqualTo(replyElement);
        softly.assertThat(actualMessageTypeEntity.getCorrelationIdElement()).as("correlationIdElement").isEqualTo(correlationIdElement);
        softly.assertThat(actualMessageTypeEntity.getStatusElement()).as("statusElement").isEqualTo(statusElement);

        if (newEventTypeCode != null) {
            softly.assertThat(actualMessageTypeEntity.getNewEventType().getCode()).as("newEventTypeCode").isEqualTo(newEventTypeCode);
        } else {
            softly.assertThat(actualMessageTypeEntity.getNewEventType()).as("newEventTypeCode").isNull();
        }

        if (originalEventTypeCode != null) {
            softly.assertThat(actualMessageTypeEntity.getOriginalEventType().getCode()).as("originalEventTypeCode").isEqualTo(originalEventTypeCode);
        } else {
            softly.assertThat(actualMessageTypeEntity.getOriginalEventType()).as("originalEventTypeCode").isNull();
        }

        softly.assertAll();
    }

    @Test
    @DisplayName("the reda.016 message type created by EntityCreationUtils should be equals to the inserted at database")
    void shouldRead016MessageTypeCreatedByEntityCreationUtilsEqualsToTheInsertedAtDatabase() {
        MessageTypeEntity actualMessageType = EntityCreationUtils.buildReda016MessageTypeEntity();
        MessageTypeEntity expectedMessageType = messageTypeRepository.findById("reda.016").orElse(null);

        assertEquals(expectedMessageType, actualMessageType);

    }
}
