package matera.spi.lm.domain.service;

import matera.spi.commons.IntegrationTest;
import matera.spi.lm.persistence.IpAccountStatementReportDetailsRepository;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static matera.spi.utils.LocalDateTimeUtils.parseLocalDateTimeUTC;

@IntegrationTest
public class IpAccountStatementReportDetailsDomainServiceTest {

    private static final LocalDateTime startTimestamp = parseLocalDateTimeUTC("2020-06-10T00:00:01.000Z");
    private static final LocalDateTime endTimestamp = parseLocalDateTimeUTC("2020-06-12T23:59:59.000Z");

    private static final String BASE_DIR = "src/test/resources/examples";
    private static final String CSV_FILEPATH_2 = BASE_DIR + "/csv/csv_camt052_example2.csv";
    private static final String CSV_FILEPATH_4 = BASE_DIR + "/csv/csv_camt052_example4.csv";

    @Autowired
    private IpAccountStatementReportDetailsDomainService statementReportDomainService;

    @Autowired
    private IpAccountStatementReportDetailsRepository statementReportDetailsRepository;

    @Autowired
    private RequestDownloadFileService requestDownloadFileService;

    @AfterEach
    void clearDB() {
        statementReportDetailsRepository.deleteAll();
    }

    @Test
    @Transactional
    public void shouldTest() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        LocalDateTime startTimestamp = LocalDateTime.parse("2020-06-20T13:40:30.000Z", formatter);
        LocalDateTime endTimestamp = LocalDateTime.parse("2020-06-20T13:40:30.000Z", formatter);
        String filename = "camt052.zip";

        requestDownloadFileService.unzipAndSave(startTimestamp, endTimestamp, filename);
    }

    /*@Test
    void shouldSaveAllRegisterInCSVFile2() {
        statementReportDomainService.extractAndSaveValues(getCsvFile(CSV_FILEPATH_2), StatementReportCsvDTO.class);

        final List<IpAccountStatementReportDetails> actual = statementReportDetailsRepository.findAll();
        Assertions.assertNotNull(expected);
        Assertions.assertNotNull(actual);
        Assertions.assertTrue(containsInSameSize(expected, actual));
    }

    @Test
    void shouldSaveAllRegisterInCSVFile4() {
        statementReportDomainService.extractAndSaveValues(getCsvFile(CSV_FILEPATH_4), StatementReportCsvDTO.class);

        final List<IpAccountStatementReportDetails> actual = statementReportDetailsRepository.findAll();
        Assertions.assertNotNull(expected);
        Assertions.assertNotNull(actual);
        Assertions.assertTrue(containsInSameSize(expected, actual));
    }

    @Test
    void shouldDeleteAllRegistersWhenNewCSVFileIsImportedInSamePeriod() {
        statementReportDomainService.extractAndSaveValues(getCsvFile(CSV_FILEPATH_2), StatementReportCsvDTO.class);

        final List<IpAccountStatementReportDetails> expectedFirstRegisters = statementReportDetailsRepository.findAll();
        Assertions.assertNotNull(firstRegisters);
        Assertions.assertTrue(containsInSameSize(expectedFirstRegisters, firstRegisters));

        statementReportDomainService.deleteRegistersInPeriod(startTimestamp, endTimestamp);
        statementReportDomainService.extractAndSaveValues(getCsvFile(CSV_FILEPATH_4), StatementReportCsvDTO.class);

        final List<IpAccountStatementReportDetails> expected = statementReportDetailsRepository.findAll();
        Assertions.assertNotNull(firstRegisters);
        Assertions.assertTrue(containsInSameSize(expected, actual));
    }

    private static StatementReportCsvDTO buildExpectedRegistry(Integer accountIdentification,
                                                               String amount,
                                                               String creditDebitIndicator,
                                                               String statusCode,
                                                               String bookingDate,
                                                               String valueDate,
                                                               String instructionIdentification,
                                                               String endToEndIdentification,
                                                               String clearingSystemReference,
                                                               Long initiatingParty,
                                                               Integer debtorAgent,
                                                               Integer creditorAgent) {
        return StatementReportCsvDTO.builder()
            .accountIdentification(accountIdentification)
            .amount(amount)
            .creditDebitIndicator(creditDebitIndicator)
            .statusCode(statusCode)
            .bookingDate(bookingDate)
            .valueDate(valueDate)
            .instructionIdentification(instructionIdentification)
            .endToEndIdentification(endToEndIdentification)
            .clearingSystemReference(clearingSystemReference)
            .initiatingParty(initiatingParty)
            .debtorAgent(debtorAgent)
            .creditorAgent(creditorAgent)
            .build();
    }

    private boolean containsInSameSize(List<IpAccountStatementReportDetails> expected,
                                       List<IpAccountStatementReportDetails> actual) {
        return expected.size() == actual.size() && expected.containsAll(actual) && actual.containsAll(expected);
    }

    private ZipInputStream getCsvFile(String pathToFile) {
        try {
            return new ZipInputStream(new FileInputStream(new File(pathToFile)));
        } catch (IOException e) {
            throw new LiquidityManagementException("SPI-LM-012");
        }
    }*/
}
