package matera.spi.lm.application.services.participants;

import matera.spi.dto.IspbQueryDTO;
import matera.spi.lm.application.service.participantService.IndirectParticipantApplicationService;
import matera.spi.lm.domain.service.ParticipantDomainService;
import matera.spi.main.domain.model.ConfigEntity;
import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.domain.service.ConfigurationService;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.assertj.core.util.Lists.list;
import static org.mockito.ArgumentMatchers.anyString;

import static java.lang.Boolean.TRUE;

@ExtendWith(MockitoExtension.class)
public class IndirectParticipantApplicationServiceTest {

    private static final Integer MOCKED_ISPB_INTEGER = 1234567;
    private static final String MOCKED_ISPB_STRING = "01234567";
    private static final String MOCKED_NAME_STRING = "Test name";

    @InjectMocks
    private IndirectParticipantApplicationService indirectParticipantService;

    @Mock
    private ConfigurationService configurationService;

    @Mock
    private ParticipantDomainService participantDomainService;

    @BeforeEach
    void init() {
        final ParticipantEntity participantEntity = buildParticipantEntity();
        final ConfigEntity mockedConfigEntity = buildConfigEntity();

        Mockito.lenient().when(configurationService.findConfig()).thenReturn(mockedConfigEntity);
        Mockito.doReturn(MOCKED_ISPB_STRING).when(configurationService).findByIspb();
        Mockito.lenient().doReturn(participantEntity).when(participantDomainService).getParticipant(anyString());
    }

    @Test
    void shouldReturnListOnlyWithIndirectIspb() {
        final List<IspbQueryDTO> expectedIspbQueryList = list(buildIspbDTO(MOCKED_ISPB_STRING, MOCKED_NAME_STRING));
        final List<IspbQueryDTO> actualIspbQueryList = indirectParticipantService.getIspbQueryList();

        Assertions.assertEquals(expectedIspbQueryList, actualIspbQueryList);
    }

    private IspbQueryDTO buildIspbDTO(String ispb, String name) {
        final IspbQueryDTO ispbQueryDTO = new IspbQueryDTO();
        ispbQueryDTO.setName(name);
        ispbQueryDTO.setIspb(ispb);
        ispbQueryDTO.setIsLocalIspb(TRUE);
        return ispbQueryDTO;
    }

    private ConfigEntity buildConfigEntity() {
        final ConfigEntity configEntity = new ConfigEntity();
        configEntity.setIspb(MOCKED_ISPB_INTEGER);
        return configEntity;
    }

    private ParticipantEntity buildParticipantEntity() {
        final ParticipantEntity participantEntity = new ParticipantEntity();
        participantEntity.setName(MOCKED_NAME_STRING);
        participantEntity.setIspb(MOCKED_ISPB_INTEGER);

        return participantEntity;
    }
}
