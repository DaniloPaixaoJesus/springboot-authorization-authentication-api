package matera.spi.lm.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.lm.domain.model.TransactionQueryEntity;
import matera.spi.lm.domain.model.event.TransactionQueryEventEntity;
import matera.spi.main.domain.model.event.EventTypeEntity;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.EventTypeRepository;
import matera.spi.utils.LocalDateTimeUtils;

import org.junit.jupiter.api.Test;
import org.opentest4j.AssertionFailedError;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.core.Is.is;

@IntegrationTest
@Transactional
class TransactionQueryRepositoryTest  {

    @Autowired
    private TransactionQueryRepository transactionQueryRepository;

    @Autowired
    private EventTypeRepository eventTypeRepository;

    @Autowired
    private EventRepository eventRepository;

    @Test
    void listTransactionsBetweenDates() {
        createEntities();

        LocalDateTime startDate = LocalDateTime.of(2020, 1, 3, 1, 2, 3);
        LocalDateTime endDate = LocalDateTime.of(2020, 1, 4, 1, 2, 3);

        Page<TransactionQueryEntity> result = transactionQueryRepository.findByParameters(getPageable(),
                                                                                          startDate,
                                                                                          endDate,
                                                                                          null,
                                                                                          null,
                                                                                          null);

        assertThat(result.getContent(), hasSize(1));
        assertThat(result.getContent().get(0).getEndToEndID(), is("EndToEndId"));
    }

    @Test
    void shouldNotReturnBecauseEndToEndIdNotExists() {
        createEntities();

        LocalDateTime startDate = LocalDateTime.of(2020, 1, 3, 1, 2, 3);
        LocalDateTime endDate = LocalDateTime.of(2020, 1, 4, 1, 2, 3);

        Page<TransactionQueryEntity> result = transactionQueryRepository.findByParameters(getPageable(),
                                                                                          startDate,
                                                                                          endDate,
                                                                                          "NotExistsE2EId",
                                                                                          null,
                                                                                          null);

        assertThat(result.getContent(), hasSize(0));
    }

    @Test
    void shouldNotReturnBecauseValueIsLowerThanParameter() {
        createEntities();

        LocalDateTime startDate = LocalDateTime.of(2020, 1, 3, 1, 2, 3);
        LocalDateTime endDate = LocalDateTime.of(2020, 1, 4, 1, 2, 3);

        Page<TransactionQueryEntity> result = transactionQueryRepository.findByParameters(getPageable(),
                                                                                          startDate,
                                                                                          endDate,
                                                                                          null,
                                                                                          BigDecimal.valueOf(175),
                                                                                          null);

        assertThat(result.getContent(), hasSize(0));
    }

    @Test
    void shouldNotReturnBecauseValueIsHigherThanParameter() {
        createEntities();

        LocalDateTime startDate = LocalDateTime.of(2020, 1, 3, 1, 2, 3);
        LocalDateTime endDate = LocalDateTime.of(2020, 1, 4, 1, 2, 3);

        Page<TransactionQueryEntity> result = transactionQueryRepository.findByParameters(getPageable(),
                                                                                          startDate,
                                                                                          endDate,
                                                                                          null,
                                                                                          null,
                                                                                          BigDecimal.valueOf(5));

        assertThat(result.getContent(), hasSize(0));
    }

    @Test
    void shouldReturnOnceByAllParametersFilter() {
        createEntities();

        LocalDateTime startDate = LocalDateTime.of(2020, 6, 10, 1, 2, 3);
        LocalDateTime endDate = LocalDateTime.of(2020, 6, 16, 1, 2, 3);

        Page<TransactionQueryEntity> result = transactionQueryRepository.findByParameters(getPageable(),
                                                                                          startDate,
                                                                                          endDate,
                                                                                          "MyE2E",
                                                                                          BigDecimal.valueOf(100),
                                                                                          BigDecimal.valueOf(200));

        assertThat(result.getContent(), hasSize(1));
        assertThat(result.getContent().get(0).getEndToEndID(), is("MyE2E"));
    }

    @Test
    void shouldReturnOnceByEndToEndId() {
        createEntities();

        LocalDateTime startDate = LocalDateTime.of(2020, 6, 10, 1, 2, 3);
        LocalDateTime endDate = LocalDateTime.of(2020, 6, 16, 1, 2, 3);

        Page<TransactionQueryEntity> result = transactionQueryRepository.findByParameters(getPageable(),
                                                                                          startDate,
                                                                                          endDate,
                                                                                          "MyE2E",
                                                                                          null,
                                                                                          null);

        assertThat(result.getContent(), hasSize(1));
        assertThat(result.getContent().get(0).getEndToEndID(), is("MyE2E"));
    }

    @Test
    void shouldReturnOnceByLowerValue() {
        createEntities();

        LocalDateTime startDate = LocalDateTime.of(2020, 6, 10, 1, 2, 3);
        LocalDateTime endDate = LocalDateTime.of(2020, 6, 16, 1, 2, 3);

        Page<TransactionQueryEntity> result = transactionQueryRepository.findByParameters(getPageable(),
                                                                                          startDate,
                                                                                          endDate,
                                                                                          null,
                                                                                          BigDecimal.valueOf(100),
                                                                                          null);

        assertThat(result.getContent(), hasSize(1));
        assertThat(result.getContent().get(0).getValue(), is(BigDecimal.valueOf(150)));
    }

    @Test
    void shouldReturnOnceByHigherValue() {
        createEntities();

        LocalDateTime startDate = LocalDateTime.of(2020, 6, 10, 1, 2, 3);
        LocalDateTime endDate = LocalDateTime.of(2020, 6, 16, 1, 2, 3);

        Page<TransactionQueryEntity> result = transactionQueryRepository.findByParameters(getPageable(),
                                                                                          startDate,
                                                                                          endDate,
                                                                                          null,
                                                                                          null,
                                                                                          BigDecimal.valueOf(200));

        assertThat(result.getContent(), hasSize(1));
        assertThat(result.getContent().get(0).getValue(), is(BigDecimal.valueOf(150)));
    }

    private void createEntities() {
        TransactionQueryEntity transactionQueryEntity = new TransactionQueryEntity();
        transactionQueryEntity.setEndToEndID("EndToEndId");
        transactionQueryEntity.setEffectiveTimestamp(LocalDateTime.of(2020, 1, 3, 12, 13, 3));
        transactionQueryEntity.setValue(BigDecimal.TEN);
        transactionQueryRepository.saveAndFlush(transactionQueryEntity);
        createEvent(transactionQueryEntity);

        TransactionQueryEntity transactionQueryEntity2 = new TransactionQueryEntity();
        transactionQueryEntity2.setEndToEndID("MyE2E");
        transactionQueryEntity2.setEffectiveTimestamp(LocalDateTime.of(2020, 1, 3, 12, 13, 3));
        transactionQueryEntity2.setValue(BigDecimal.valueOf(150));
        transactionQueryRepository.saveAndFlush(transactionQueryEntity2);

        TransactionQueryEventEntity event2 = createEvent(transactionQueryEntity2);
        event2.setInitiationTimestampUTC(LocalDateTime.of(2020, 6, 14, 16, 10, 15));
        eventRepository.saveAndFlush(event2);
    }

    private Pageable getPageable() {
        return PageRequest.of(0, 10);
    }

    private TransactionQueryEventEntity createEvent(TransactionQueryEntity transactionQueryEntity) {
        EventTypeEntity eventTypeEntity = eventTypeRepository.findById(6).orElseThrow(() -> new AssertionFailedError("Not found Event"));
        TransactionQueryEventEntity expectedEvent = new TransactionQueryEventEntity();
        expectedEvent.setCorrelationId("E00539039202002170828063aec68f6e");
        expectedEvent.setClearingTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
        expectedEvent.setInitiationTimestampUTC(LocalDateTime.of(2020, 1, 3, 12, 23, 3));
        expectedEvent.setResponsible("SOME RESPONSIBLE");
        expectedEvent.setInitiatorIspb(12345);
        expectedEvent.setValue(BigDecimal.ONE);
        expectedEvent.setEventTypeEntity(eventTypeEntity);
        expectedEvent.setStatus(eventTypeEntity.getInitialStatus());
        expectedEvent.setTransactionQueryEntity(transactionQueryEntity);
        expectedEvent = eventRepository.saveAndFlush(expectedEvent);
        return expectedEvent;
    }

}
