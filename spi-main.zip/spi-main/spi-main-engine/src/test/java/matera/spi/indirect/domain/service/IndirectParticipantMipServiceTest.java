package matera.spi.indirect.domain.service;

import matera.spi.indirect.domain.model.ParticipantMipIndirectEntity;
import matera.spi.indirect.persistence.ParticipantMipIndirectHistoryRepository;
import matera.spi.indirect.persistence.ParticipantMipIndirectRepository;
import matera.spi.indirect.persistence.ParticipantMipIndirectStatusRepository;
import matera.spi.indirect.util.ParticipantMipIndirectDataSetUtil;
import matera.spi.main.domain.model.ParticipantMipEntity;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.any;

@ExtendWith(MockitoExtension.class)
class IndirectParticipantMipServiceTest {

    public static final String ENTITY_NOT_FOUND = "Entity %s not found";
    private static final Integer ISPB = 123454;
    private static final Integer CURRENT_PAGE = 0;
    private static final Integer PAGE_SIZE = 2;
    private static final Integer TOTAL_ELEMENTS = 10;

    @Mock
    private ParticipantMipIndirectRepository participantMipIndirectRepository;

    @Mock
    private ParticipantMipIndirectStatusRepository participantMipIndirectStatusRepository;

    @Mock
    private ParticipantMipIndirectHistoryRepository participantMipIndirectHistoryRepository;

    @InjectMocks
    private IndirectParticipantMipService indirectParticipantMipService;

    @Test
    void shouldReturnIndirectParticipantWhenfindByIspb() {
        doReturn(Optional.of(ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectStatusEntity()))
            .when(participantMipIndirectStatusRepository).findById(any());

        final ParticipantMipEntity participantMip = ParticipantMipIndirectDataSetUtil.createParticipantMip();
        final ParticipantMipIndirectEntity entity = ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository, participantMip);

        when(participantMipIndirectRepository.findByParticipantMipIspb(ISPB)).thenReturn(Optional.of(entity));

        ParticipantMipIndirectEntity result = indirectParticipantMipService.findByIspb(ISPB).orElseThrow();

        assertTrue(result.equals(entity));

    }

    @Test
    void shouldReturnIndirectParticipantWhenIspbIsInvalid() {
        when(participantMipIndirectRepository.findByParticipantMipIspb(ISPB)).thenReturn(Optional.empty());
        Optional<ParticipantMipIndirectEntity> result = indirectParticipantMipService.findByIspb(ISPB);

        assertTrue(result.isEmpty());

    }

}
