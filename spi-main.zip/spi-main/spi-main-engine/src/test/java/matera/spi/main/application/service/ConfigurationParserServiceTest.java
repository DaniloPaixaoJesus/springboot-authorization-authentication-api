package matera.spi.main.application.service;

import matera.spi.dto.CustomerTransactionTypeDTO;
import matera.spi.dto.PspConfigUIDTO;
import matera.spi.dto.PspConfigUpdateUIDTO;
import matera.spi.main.domain.model.ConfigEntity;
import matera.spi.main.domain.service.ConfigurationService;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;

import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class ConfigurationParserServiceTest {

    @Spy
    @InjectMocks
    ConfigurationParserService configurationParserService;

    @Mock
    private ConfigurationService configurationService;

    private  ConfigEntity configEntity;

    @Captor
    private ArgumentCaptor<ConfigEntity> configEntityArgumentCaptor;

    @BeforeEach
     void init(){
        MockitoAnnotations.initMocks(this);
        configEntity = createConfigEntity();
        Mockito.when(configurationService.findConfig()).thenReturn(configEntity);
    }

    @Test
    void shouldRetrieveAllInformationOfPspConfigUIDTO() {

        PspConfigUIDTO parsedConfig = configurationParserService.getPspConfigUIDTO();
        PspConfigUIDTO expectedParsedConfig = createParsedConfig();

        Assertions.assertEquals(expectedParsedConfig,parsedConfig);
    }

    @Test
    void shouldSaveAllInformationOfPspConfigUpdateUIDTO() {

        PspConfigUpdateUIDTO pspConfigUpdateUIDTO = new PspConfigUpdateUIDTO();
        pspConfigUpdateUIDTO.setIspb(123456);
        pspConfigUpdateUIDTO.setDefaultBranch("456");

        configurationParserService.updatePspConfig(pspConfigUpdateUIDTO);

        verify(configurationService).save(configEntityArgumentCaptor.capture());

        final ConfigEntity configEntitySaved = configEntityArgumentCaptor.getValue();

        Assertions.assertEquals(configEntitySaved.getDefaultBranch(), pspConfigUpdateUIDTO.getDefaultBranch());
    }

    @Test
    void shouldRetrieveAllInformationOfCustomerTransactionTypeDTO() {

        CustomerTransactionTypeDTO customerTransactionTypeDTO = configurationParserService.getCustomerTransactionTypeDTO();

        Assertions.assertEquals(configEntity.getCustomerCredTransactionType(), customerTransactionTypeDTO.getCredit());
        Assertions.assertEquals(configEntity.getCustomerDebTransactionType(), customerTransactionTypeDTO.getDebit());
        Assertions.assertEquals(configEntity.getCustDrawbSentTransType(), customerTransactionTypeDTO.getDrawbackSent());
        Assertions.assertEquals(configEntity.getCustDrawbReceivedTransType(), customerTransactionTypeDTO.getDrawbackReceived());
        Assertions.assertEquals(configEntity.getQrcodeCredTransactionType(), customerTransactionTypeDTO.getCreditByDynamicQRCode());
        Assertions.assertEquals(configEntity.getCustomerIntraPspCredTransactionType(), customerTransactionTypeDTO.getIntraPspCredit());
        Assertions.assertEquals(configEntity.getCustomerIntraPspDebTransactionType(), customerTransactionTypeDTO.getIntraPspDebit());
        Assertions.assertEquals(configEntity.getCustIntraPspDrawbSentTransType(), customerTransactionTypeDTO.getIntraPspDrawbackSent());
        Assertions.assertEquals(configEntity.getCustIntraPspDrawbReceivedTransType(), customerTransactionTypeDTO.getIntraPspDrawbackReceived());
    }

    @Test
    void shouldSaveAllInformationOfCustomerTransactionTypeDTO() {

        CustomerTransactionTypeDTO customerTransactionTypeDTO = new CustomerTransactionTypeDTO();
        customerTransactionTypeDTO.setCredit(11);
        customerTransactionTypeDTO.setDebit(12);
        customerTransactionTypeDTO.setDrawbackSent(13);
        customerTransactionTypeDTO.setDrawbackReceived(14);
        customerTransactionTypeDTO.setCreditByDynamicQRCode(15);
        customerTransactionTypeDTO.setIntraPspCredit(16);
        customerTransactionTypeDTO.setIntraPspDebit(17);
        customerTransactionTypeDTO.setIntraPspDrawbackSent(18);
        customerTransactionTypeDTO.setIntraPspDrawbackReceived(19);

        configurationParserService.updateCustomerAccountConfig(customerTransactionTypeDTO);

        verify(configurationService).save(configEntityArgumentCaptor.capture());

        final ConfigEntity configEntitySaved = configEntityArgumentCaptor.getValue();

        Assertions.assertEquals(configEntitySaved.getCustomerCredTransactionType(), customerTransactionTypeDTO.getCredit());
        Assertions.assertEquals(configEntitySaved.getCustomerDebTransactionType(), customerTransactionTypeDTO.getDebit());
        Assertions.assertEquals(configEntitySaved.getCustDrawbSentTransType(), customerTransactionTypeDTO.getDrawbackSent());
        Assertions.assertEquals(configEntitySaved.getCustDrawbReceivedTransType(), customerTransactionTypeDTO.getDrawbackReceived());
        Assertions.assertEquals(configEntitySaved.getQrcodeCredTransactionType(), customerTransactionTypeDTO.getCreditByDynamicQRCode());
        Assertions.assertEquals(configEntitySaved.getCustomerIntraPspCredTransactionType(), customerTransactionTypeDTO.getIntraPspCredit());
        Assertions.assertEquals(configEntitySaved.getCustomerIntraPspDebTransactionType(), customerTransactionTypeDTO.getIntraPspDebit());
        Assertions.assertEquals(configEntitySaved.getCustIntraPspDrawbSentTransType(), customerTransactionTypeDTO.getIntraPspDrawbackSent());
        Assertions.assertEquals(configEntitySaved.getCustIntraPspDrawbReceivedTransType(), customerTransactionTypeDTO.getIntraPspDrawbackReceived());
    }

    private ConfigEntity createConfigEntity() {
        ConfigEntity config = new ConfigEntity();
        config.setBalanceValidationThreshold(BigDecimal.valueOf(100));
        config.setCustomerCredTransactionType(1);
        config.setCustomerDebTransactionType(1);
        config.setId(1);
        config.setIspb(null);
        config.setPmtConfirmRetryAmount(500);
        config.setPmtConfirmRetryInterval(null);
        config.setPmtSlaTime(99);
        config.setReceiveConfirmRetryAmount(null);
        config.setReceiveConfirmRetryInterval(150);
        config.setQrcodeCredTransactionType(2);
        config.setCustomerIntraPspCredTransactionType(3);
        config.setCustomerIntraPspDebTransactionType(4);
        config.setCustIntraPspDrawbSentTransType(5);
        config.setCustIntraPspDrawbReceivedTransType(6);
        config.setDefaultBranch("0123");

        return  config;
    }

    private PspConfigUIDTO createParsedConfig() {
        PspConfigUIDTO parsedConfig = new PspConfigUIDTO();
        parsedConfig.setBalanceValidationThreshold(BigDecimal.valueOf(100));
        parsedConfig.setIspb(null);
        parsedConfig.setPmtConfirmRetryAmount(Long.valueOf(500));
        parsedConfig.setPmtConfirmRetryInterval(null);
        parsedConfig.setPmtSlaTime(99);
        parsedConfig.setReceiveConfirmRetryAmount(null);
        parsedConfig.setReceiveConfirmRetryInterval(Long.valueOf(150));
        parsedConfig.setDefaultBranch("0123");

        return  parsedConfig;
    }

}
