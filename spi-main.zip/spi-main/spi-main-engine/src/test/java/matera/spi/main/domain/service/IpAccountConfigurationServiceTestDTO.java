package matera.spi.main.domain.service;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.IpAccountConfigEntity;
import matera.spi.main.exception.MainEngineConfigurationException;
import matera.spi.main.persistence.IpAccountConfigRepository;

import org.assertj.core.api.SoftAssertions;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

@IntegrationTest
class IpAccountConfigurationServiceTestDTO  {

    private final BigDecimal BALANCE_LOWER_THRESHOLD = new BigDecimal(2000000000.00);
    private final BigDecimal BALANCE_UPPER_THRESHOLD = new BigDecimal(666666666.66);
    private final BigDecimal BALANCE_LOWER_THRESHOLD_PERCENT = BigDecimal.valueOf(0.25);
    private final BigDecimal BALANCE_UPPER_THRESHOLD_PERCENT = BigDecimal.valueOf(0.75);
    private final Integer DEPOSIT_TRANSACTION_TYPE = 9876;
    private final Integer WITHDRAW_TRANSACTION_TYPE = 5432;

    @Autowired
    private IpAccountConfigRepository ipAccountConfigRepository;

    @Autowired
    private IpAccountConfigurationService ipAccountConfigurationService;

    private IpAccountConfigEntity configEntityBackup;

    @BeforeEach
    public void setup() {
        configEntityBackup = ipAccountConfigurationService.findConfig().orElse(null);
        ipAccountConfigRepository.deleteAll();
    }

    @AfterEach
    public void tearDown() {
        ipAccountConfigRepository.deleteAll();
        ipAccountConfigurationService.save(configEntityBackup);
    }

    void createIpAccountConfig(Integer branch, Integer accountNumber, Integer creditTransactionType, Integer debitTransactionType) {
        IpAccountConfigEntity entity = new IpAccountConfigEntity();
        entity.setAccountNumber(BigDecimal.valueOf(accountNumber));
        entity.setBranch(branch);
        entity.setCreditTransactionType(creditTransactionType);
        entity.setDebitTransactionType(debitTransactionType);
        entity.setBalanceLowerThreshold(BALANCE_LOWER_THRESHOLD);
        entity.setBalanceLowerThresholdPercent(BALANCE_LOWER_THRESHOLD_PERCENT);
        entity.setBalanceUpperThreshold(BALANCE_UPPER_THRESHOLD);
        entity.setBalanceUpperThresholdPercent(BALANCE_UPPER_THRESHOLD_PERCENT);
        entity.setDepositTransactionType(DEPOSIT_TRANSACTION_TYPE);
        entity.setWithdrawTransactionType(WITHDRAW_TRANSACTION_TYPE);
        entity.setDrawbackReceiveTransactType(5823);
        entity.setDrawbackSentTransactType(1111);
        entity.setQrcodeCredTransactionType(7423);
        entity.setBalanceAdjustmentCredit(1234);
        entity.setBalanceAdjustmentDebit(4312);

        ipAccountConfigurationService.save(entity);
    }

    @Test
    void shouldBeConfigurationWhenLoad() {
        createIpAccountConfig(4321, 12345678, 5678, 1234);
        IpAccountConfigEntity expected = ipAccountConfigurationService.findConfig().orElse(null);
        assertNotNull(expected);

        SoftAssertions softly = new SoftAssertions();
        softly.assertThat(expected.getBranch()).isEqualTo(4321);
        softly.assertThat(expected.getAccountNumber()).isEqualTo(BigDecimal.valueOf(12345678));
        softly.assertThat(expected.getCreditTransactionType()).isEqualTo(5678);
        softly.assertThat(expected.getDebitTransactionType()).isEqualTo(1234);
        softly.assertAll();
    }

    @Test
    void shouldBeConfigurationWhenHasRegisterIntoTable() {
        createIpAccountConfig(4321, 12345678, 1234, 5678);
        IpAccountConfigEntity expected = ipAccountConfigurationService.findConfig().orElse(null);
        assertNotNull(expected);

        SoftAssertions softly = new SoftAssertions();
        softly.assertThat(expected.getAccountNumber()).isEqualTo(BigDecimal.valueOf(12345678));
        softly.assertThat(expected.getCreditTransactionType()).isEqualTo(1234);
        softly.assertThat(expected.getDebitTransactionType()).isEqualTo(5678);
        softly.assertAll();
    }

    @Test
    void shouldBeExceptionWhenMoreOneConfiguration() {
        createIpAccountConfig(4321,12345678, 1234, 5678);
        createIpAccountConfig(1234,87654321, 4321, 8765);

        List<IpAccountConfigEntity> list = ipAccountConfigRepository.findAll();

        assertEquals(2, list.size());

        assertThrows(
                MainEngineConfigurationException.class,
                () -> ipAccountConfigurationService.findConfig(),
                "Main Engine Ip Account Configuration has more than one element.");

    }

    @Test
    void testCreateIpAccountConfig() {

        // Given
        final IpAccountConfigEntity expected = new IpAccountConfigEntity();
        expected.setDebitTransactionType(0);
        expected.setBranch(0);
        expected.setAccountNumber(BigDecimal.valueOf(0));
        expected.setCreditTransactionType(0);
        expected.setBalanceLowerThreshold(new BigDecimal("0"));
        expected.setBalanceLowerThresholdPercent(BigDecimal.ZERO);
        expected.setBalanceUpperThreshold(new BigDecimal("0"));
        expected.setBalanceUpperThresholdPercent(BigDecimal.ZERO);
        expected.setDrawbackReceiveTransactType(5823);
        expected.setDrawbackSentTransactType(1111);
        expected.setDepositTransactionType(0);
        expected.setWithdrawTransactionType(0);
        expected.setQrcodeCredTransactionType(22);
        expected.setBalanceAdjustmentCredit(1234);
        expected.setBalanceAdjustmentDebit(4312);

        // When
        ipAccountConfigurationService.save(expected);

        var actual = ipAccountConfigRepository.findById(expected.getUuid()).get();

        // Then

        assertEquals(expected.getDebitTransactionType(), actual.getDebitTransactionType());
        assertEquals(expected.getBranch(), actual.getBranch());
        assertEquals(expected.getAccountNumber(), actual.getAccountNumber());
        assertEquals(expected.getCreditTransactionType(), actual.getCreditTransactionType());
        assertEquals(expected.getDepositTransactionType(), actual.getDepositTransactionType());
        assertEquals(expected.getWithdrawTransactionType(), actual.getWithdrawTransactionType());
        assertEquals(expected.getBalanceAdjustmentCredit(), actual.getBalanceAdjustmentCredit());
        assertEquals(expected.getBalanceAdjustmentDebit(), actual.getBalanceAdjustmentDebit());
        assertEquals(0, expected.getBalanceLowerThresholdPercent().compareTo(actual.getBalanceLowerThresholdPercent()));
        assertEquals(0, expected.getBalanceLowerThreshold().compareTo(actual.getBalanceLowerThreshold()));
        assertEquals(0, expected.getBalanceUpperThresholdPercent().compareTo(actual.getBalanceUpperThresholdPercent()));
        assertEquals(0, expected.getBalanceUpperThreshold().compareTo(actual.getBalanceUpperThreshold()));
    }
}
