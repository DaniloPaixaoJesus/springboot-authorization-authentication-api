package matera.spi.main.commons.persistence.repository;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.event.EventTypeEntity;
import matera.spi.main.persistence.EventTypeRepository;

import org.apache.commons.lang3.StringUtils;
import org.assertj.core.api.SoftAssertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.opentest4j.AssertionFailedError;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;

@IntegrationTest
class EventTypeRepositoryTest  {

    private static final Integer CODE = 123;
    private static final String DESCRIPTION = "description event type";

    @Autowired
    private EventTypeRepository repository;

    @Test
    void saveAndFlush() {
        EventTypeEntity eventTypeEntity = createObject();
        repository.saveAndFlush(eventTypeEntity);

        Optional<EventTypeEntity> optionalEventTypeEntity = repository.findByDescription(DESCRIPTION);
        EventTypeEntity eventType = optionalEventTypeEntity
                .orElseThrow(() -> new AssertionFailedError("not found EventEntity with description: " + DESCRIPTION));

        assertEquals(CODE, eventType.getCode());
        assertEquals(DESCRIPTION, eventType.getDescription());
        repository.deleteById(eventTypeEntity.getCode());
    }

    @DisplayName("Verifying if the ME_EVENT_TYPE default values are added correctly")
    @ParameterizedTest(name = "code: {0} | description: {1} | initial code: {2} | initial status: {3} | success code: {4} | success status: {5} | Message to send: {6} | status after sent: {7} ")
    @CsvFileSource(resources = "/parameterized/csv/EventTypeRepositoryTest-default-values.csv", numLinesToSkip = 1)
    void shouldEventTypeDefaultValuesBeAdded(int code, String description, int initialCode, String initialStatus,  int successCode, String successStatus, String messageToSend, String statusAfterSent) {
        EventTypeEntity eventType = repository.findById(code)
                .orElseThrow(() -> new AssertionFailedError("not found EventEntity with id: " + code));

        SoftAssertions softly = new SoftAssertions();
        softly.assertThat(eventType.getDescription()).as("description").isEqualTo(description);
        softly.assertThat(eventType.getInitialStatus().getCode()).as("initialCode").isEqualTo(initialCode);
        softly.assertThat(eventType.getInitialStatus().getDescription()).as("initialStatus").isEqualTo(initialStatus);
        softly.assertThat(eventType.getSuccessStatus().getCode()).as("successCode").isEqualTo(successCode);
        softly.assertThat(eventType.getSuccessStatus().getDescription()).as("successStatus").isEqualTo(successStatus);
        if (StringUtils.isBlank(messageToSend)) {
            softly.assertThat(eventType.getMessageTypeToSend()).as("messageToSend").isNull();
        } else {
            softly.assertThat(eventType.getMessageTypeToSend().getCode()).as("messageToSend").isEqualTo(messageToSend);
        }

        if (StringUtils.isBlank(statusAfterSent)) {
            softly.assertThat(eventType.getStatusAfterSending()).as("statusAfterSent").isNull();
        } else {
            softly.assertThat(eventType.getStatusAfterSending().getDescription()).as("statusAfterSent").isEqualTo(statusAfterSent);
        }
        softly.assertAll();
    }

    private EventTypeEntity createObject() {
        EventTypeEntity eventTypeEntity = new EventTypeEntity();
        eventTypeEntity.setCode(CODE);
        eventTypeEntity.setDescription(DESCRIPTION);
        return eventTypeEntity;
    }
}
