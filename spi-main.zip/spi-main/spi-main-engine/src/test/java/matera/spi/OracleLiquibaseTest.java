package matera.spi;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.event.EventStatusEntity;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;

import java.sql.SQLException;
import java.util.List;

import static org.junit.Assert.assertEquals;

@IntegrationTest
@ActiveProfiles("oracle")
public class OracleLiquibaseTest {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Test
    public void testSimple() throws SQLException {
        assertEquals(jdbcTemplate.queryForObject("SELECT 1 FROM dual", Long.class), Long.valueOf(1L));
    }

    @Test
    public void testOrderByWithCase() throws SQLException {
        List<Integer> status = jdbcTemplate.queryForList(
            "SELECT NEW_EVENT_STATUS_CODE FROM ME_REL_MSG_STATUS_EVT_STATUS WHERE " +
            "REPORTED_STATUS = 'REJT' AND " +
            "CURRENT_EVENT_STATUS = 37 AND " +
            "(COALESCE(REASON_CODE, 'IND2') = 'IND2') " +
            "ORDER BY CASE WHEN REASON_CODE is null THEN 1 ELSE 0 END ASC",
            Integer.class);
        assertEquals(Integer.valueOf(3), status.get(0));
        assertEquals(Integer.valueOf(36), status.get(1));
    }
}
