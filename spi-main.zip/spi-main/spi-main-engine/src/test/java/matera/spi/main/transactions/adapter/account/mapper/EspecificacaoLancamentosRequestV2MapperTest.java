package matera.spi.main.transactions.adapter.account.mapper;

import com.matera.spi.thirdparties.customers.transactions.model.EspecificacaoLancamentoV2DTO;
import com.matera.spi.thirdparties.customers.transactions.model.EspecificacaoLancamentosRequestV2DTO;
import matera.spi.main.dto.AccountTransactionRequestDTO;
import org.assertj.core.api.SoftAssertions;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.UUID;

class EspecificacaoLancamentosRequestV2MapperTest {

    private static final String DEFAULT_SUB_SYSTEM = "MIP";
    public static final UUID EVENT_ID = UUID.fromString("b7592b91-48c4-4921-a148-7427e9af73da");

    @Test
    public void referenciaMovimentoIsEqualToInformationAccountHolderWhenItsValueIsNotNull() {

        AccountTransactionRequestDTO accountTransactionRequestDTO = createAccountTransactionRequestDTOWithAccountInformationHolder("Some important information.");

        EspecificacaoLancamentosRequestV2DTO especificacaoLancamentosRequestV2DTO = EspecificacaoLancamentosRequestV2Mapper.buildRequestDTO(accountTransactionRequestDTO);
        EspecificacaoLancamentoV2DTO especificacaoLancamentoV2DTO = especificacaoLancamentosRequestV2DTO.getLancamentos().get(0);

        SoftAssertions softAssertions = new SoftAssertions();

        softAssertions.assertThat(especificacaoLancamentosRequestV2DTO.getSubSistema()).isEqualTo(DEFAULT_SUB_SYSTEM);
        softAssertions.assertThat(especificacaoLancamentoV2DTO.getHistorico()).isEqualTo(accountTransactionRequestDTO.getTransactionType());
        softAssertions.assertThat(especificacaoLancamentoV2DTO.getValor()).isEqualTo(accountTransactionRequestDTO.getValue().setScale(2));
        softAssertions.assertThat(especificacaoLancamentoV2DTO.getComplementoHistorico()).isEqualTo(accountTransactionRequestDTO.getOperationComplement());
        softAssertions.assertThat(especificacaoLancamentoV2DTO.getTipoLimite()).isEqualTo(EspecificacaoLancamentoV2DTO.TipoLimiteEnum.SALDO_MAIS_LIMITE);
        softAssertions.assertThat(especificacaoLancamentoV2DTO.getReferenciaMovimento()).isEqualTo(accountTransactionRequestDTO.getInformationAccountHolderTransaction());
        softAssertions.assertThat(especificacaoLancamentoV2DTO.getExibeLancamentoAgrupado()).isEqualTo(accountTransactionRequestDTO.getGroupEntries());
        softAssertions.assertThat(especificacaoLancamentoV2DTO.getValidaSaldo()).isEqualTo(EspecificacaoLancamentoV2DTO.ValidaSaldoEnum.VALIDA);
        softAssertions.assertThat(especificacaoLancamentoV2DTO.getDetalhes()).isEqualTo(accountTransactionRequestDTO.getDetails());

        softAssertions.assertAll();
    }

    @Test
    public void referenciaMovimentoIsEqualToEventIdWhenInformationAccountHolderIsNull() {

        AccountTransactionRequestDTO accountTransactionRequestDTO = createAccountTransactionRequestDTOWithoutAccountInformationHolder();

        EspecificacaoLancamentosRequestV2DTO especificacaoLancamentosRequestV2DTO = EspecificacaoLancamentosRequestV2Mapper.buildRequestDTO(accountTransactionRequestDTO);
        EspecificacaoLancamentoV2DTO especificacaoLancamentoV2DTO = especificacaoLancamentosRequestV2DTO.getLancamentos().get(0);

        SoftAssertions softAssertions = new SoftAssertions();

        softAssertions.assertThat(especificacaoLancamentosRequestV2DTO.getSubSistema()).isEqualTo(DEFAULT_SUB_SYSTEM);
        softAssertions.assertThat(especificacaoLancamentoV2DTO.getHistorico()).isEqualTo(accountTransactionRequestDTO.getTransactionType());
        softAssertions.assertThat(especificacaoLancamentoV2DTO.getValor()).isEqualTo(accountTransactionRequestDTO.getValue().setScale(2));
        softAssertions.assertThat(especificacaoLancamentoV2DTO.getComplementoHistorico()).isEqualTo(accountTransactionRequestDTO.getOperationComplement());
        softAssertions.assertThat(especificacaoLancamentoV2DTO.getTipoLimite()).isEqualTo(EspecificacaoLancamentoV2DTO.TipoLimiteEnum.SALDO_MAIS_LIMITE);
        softAssertions.assertThat(especificacaoLancamentoV2DTO.getReferenciaMovimento()).isEqualTo(accountTransactionRequestDTO.getEventId().toString());
        softAssertions.assertThat(especificacaoLancamentoV2DTO.getExibeLancamentoAgrupado()).isEqualTo(accountTransactionRequestDTO.getGroupEntries());
        softAssertions.assertThat(especificacaoLancamentoV2DTO.getValidaSaldo()).isEqualTo(EspecificacaoLancamentoV2DTO.ValidaSaldoEnum.VALIDA);

        softAssertions.assertAll();
    }

    private AccountTransactionRequestDTO createAccountTransactionRequestDTOWithoutAccountInformationHolder() {

        return createAccountTransactionRequestDTOWithAccountInformationHolder(null);
    }

    private AccountTransactionRequestDTO createAccountTransactionRequestDTOWithAccountInformationHolder(String informationAccountHolderTransaction) {

        return AccountTransactionRequestDTO.builder()
            .account(BigDecimal.valueOf(1L))
            .branch(1)
            .groupEntries(true)
            .idempotenceId("123456789")
            .transactionType(8)
            .validateBalance(true)
            .endToEndId("E31242353456465876897")
            .eventId(EVENT_ID)
            .value(BigDecimal.valueOf(123))
            .informationAccountHolderTransaction(informationAccountHolderTransaction)
            .operationComplement("Some relevant complement")
            .build();
    }
}
