package matera.spi.main.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.ParticipantMipEntity;

import org.junit.jupiter.api.Test;
import org.opentest4j.AssertionFailedError;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.test.context.TestConfiguration;

import java.math.BigDecimal;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@IntegrationTest
class ParticipantMipRepositoryTest  {

	@Autowired
	private ParticipantMipRepository participantMipRepository;

	@Test
	void shouldAddNewParticipantMip() {
		ParticipantMipEntity participantMip = new ParticipantMipEntity();
		int ispb = 123456;
		participantMip.setIspb(ispb);
		participantMip.setBranch(123);
		participantMip.setAccountNumber(BigDecimal.valueOf(444555));
		participantMip.setDebTransactionType(12);
		participantMip.setCredTransactionType(344);
		participantMip.setDepositTransactionType(4789);
		participantMip.setWithdrawTransactionType(1147);
		participantMip.setDrawbackSentTransactType(11);
		participantMip.setDrawbackReceiveTransactType(77);
		participantMip.setBalanceValidationThreshold(true);
		participantMip.setBalanceLowerThreshold(BigDecimal.valueOf(1002430.57));
		participantMip.setBalanceLowerThresholdPerc(10);
        participantMip.setDirectParticipant(false);
        participantMip.setQrcodeCredTransactionType(9875);

        participantMipRepository.saveAndFlush(participantMip);

		ParticipantMipEntity searchedParticipantMip = participantMipRepository.findByIspb(ispb)
				.orElseThrow(() -> new AssertionFailedError("Not found PARTICIPANT MIP " + ispb));

		assertThat(searchedParticipantMip).isEqualTo(participantMip);

		//tearDown
        participantMipRepository.delete(searchedParticipantMip);
    }
}
