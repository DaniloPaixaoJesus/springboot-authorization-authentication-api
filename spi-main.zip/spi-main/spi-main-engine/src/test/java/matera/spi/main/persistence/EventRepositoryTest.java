package matera.spi.main.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.indirect.domain.model.ParticipantMipIndirectEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectHistoryEntity;
import matera.spi.indirect.domain.model.event.IndirectParticipantRescissionEventEntity;
import matera.spi.indirect.persistence.ParticipantMipIndirectContactsRepository;
import matera.spi.indirect.persistence.ParticipantMipIndirectHistoryRepository;
import matera.spi.indirect.persistence.ParticipantMipIndirectRepository;
import matera.spi.indirect.persistence.ParticipantMipIndirectStatusRepository;
import matera.spi.indirect.util.ParticipantMipIndirectDataSetUtil;
import matera.spi.lm.dto.OutstandingBalanceSumDTO;
import matera.spi.main.domain.model.IpAccountOwnerEntity;
import matera.spi.main.domain.model.ParticipantMipEntity;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventStatusTransitionEntity;
import matera.spi.main.domain.model.event.EventType;
import matera.spi.main.domain.model.event.EventTypeEntity;
import matera.spi.main.domain.model.event.IpAccountOwnerUpdateEventEntity;
import matera.spi.main.domain.model.event.transaction.TransactionEventEntity;
import matera.spi.main.domain.model.message.MessageTypeEntity;
import matera.spi.main.domain.model.transaction.PaymentEntity;
import matera.spi.main.domain.service.IpAccountOwnerService;

import org.assertj.core.api.Assertions;
import matera.spi.main.utils.PaymentTransactionUtils;
import matera.spi.main.utils.constants.EventConstants;
import matera.spi.main.utils.constants.TransactionConstants;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.opentest4j.AssertionFailedError;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import static matera.spi.main.utils.EntityCreationUtils.BALANCE_QUERY_EVENT_TYPE_CODE;
import static matera.spi.main.utils.EntityCreationUtils.CORRELATION_ID;
import static matera.spi.main.utils.EntityCreationUtils.DEPOSIT_EVENT_TYPE_CODE;
import static matera.spi.main.utils.EntityCreationUtils.PAYMENT_EVENT_TYPE_CODE;
import static matera.spi.main.utils.EntityCreationUtils.RECEIPT_EVENT_TYPE_CODE;
import static matera.spi.main.utils.EntityCreationUtils.WITHDRAW_EVENT_TYPE_CODE;
import static matera.spi.main.utils.EntityCreationUtils.buildEventEntity;
import static matera.spi.main.utils.EntityCreationUtils.buildEventEntityWithEventStatusTransitionEntity;
import static matera.spi.main.utils.EntityCreationUtils.buildIpAccountOwnerEntityWithRequiredFields;

import static org.assertj.core.api.Assertions.assertThat;

@IntegrationTest
@Transactional
class EventRepositoryTest {

    private static final String NOT_FOUND_EVENT_TYPE = "Not found Event Type: ";
    private static final String EVENT_NOT_FOUND_WITH_ID = "Event not found with id ";
    private static final String EVENT_ATTR_NAME = "event";

    @Autowired
    private EventRepository eventRepository;

    @Autowired
    private TransactionEventRepository transactionEventRepository;

	@Autowired
    private EventTypeRepository eventTypeRepository;

    @Autowired
    private MessageTypeRepository messageTypeRepository;

    @Autowired
    private IpAccountOwnerService ipAccountOwnerService;

    @Autowired
    private PaymentTransactionUtils paymentTransactionUtils;

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private ParticipantMipRepository participantMipRepository;

    @Autowired
    private ParticipantMipIndirectRepository participantMipIndirectRepository;

    @Autowired
    private ParticipantMipIndirectStatusRepository participantMipIndirectStatusRepository;

    @Autowired
    private ParticipantMipIndirectHistoryRepository participantMipIndirectHistoryRepository;

    @Autowired
    private PlatformTransactionManager transactionManager;

    @Autowired
    private ParticipantMipIndirectContactsRepository participantMipIndirectContactsRepository;

    private TransactionTemplate transactionTemplate;

    @BeforeEach
    void setUpTransactionTemplate() {
        transactionTemplate = new TransactionTemplate(transactionManager);
    }
    @DisplayName("when given a non final event should find it by the event_type_code and the correlation_id")
    @Test
    @Transactional
    void shouldFindEventStatusTransitionEntityAndACorrelationId() {
        EventEntity event = createEventMessageEntityEventStatusTransitionEntity();

        List<EventEntity> searchedEvents =
            eventRepository.findNonFinalEventByEventTypeCodeAndByCorrelationId(PAYMENT_EVENT_TYPE_CODE, CORRELATION_ID);
        EventEntity actualEventEntity = searchedEvents.get(0);
        List<EventStatusTransitionEntity> actualEventStatusTransitionEntities =
            actualEventEntity.getEventStatusTransitionEntities();

        assertThat(searchedEvents).hasSize(1);
        assertThat(actualEventStatusTransitionEntities).hasSize(1);
        assertThat(actualEventEntity.getCorrelationId()).isEqualTo(event.getCorrelationId());
        assertThat(actualEventStatusTransitionEntities.get(0).getUuid())
            .isEqualTo(event.getEventStatusTransitionEntities().get(0).getUuid());
    }

    @AfterEach
    void cleanData() {
        ParticipantMipIndirectDataSetUtil.cleanIndirectParticipantTablesData(participantMipIndirectHistoryRepository,
            participantMipIndirectContactsRepository, participantMipIndirectRepository, participantMipRepository);
    }

    @DisplayName("when given two events with the same correlation_id findFirstNonFinalEventByCorrelationId should return the first event")
    @Test
    void shouldFindNonFinalEventGivenAEventTypeAndACorrelationId() {
        EventEntity firstEvent = createAndSaveEvent(PAYMENT_EVENT_TYPE_CODE);
        EventEntity secondEvent = createAndSaveEvent(PAYMENT_EVENT_TYPE_CODE);

        List<EventEntity> searchedEvents =
            eventRepository.findNonFinalEventByEventTypeCodeAndByCorrelationId(PAYMENT_EVENT_TYPE_CODE, CORRELATION_ID);
        assertThat(searchedEvents).hasSize(2);
        assertThat(searchedEvents).containsExactlyInAnyOrder(firstEvent, secondEvent);

        EventEntity searchedFirstEvent = eventRepository
            .findFirstNonFinalEventByEventTypeCodeAndByCorrelationId(PAYMENT_EVENT_TYPE_CODE, CORRELATION_ID)
            .orElseThrow(() -> new AssertionFailedError(
                "Not found first non final event with correlation id:" + CORRELATION_ID));
        assertThat(searchedEvents).contains(searchedFirstEvent);
    }

    @DisplayName("when searching for a payment event given a correlation id and the message type should return " +
                 "an EventEntity that has the same correlationId and the EventType equals the MessageType originalEventTypeCode ")
    @Test
    void shouldSearchForAPaymentEventGivenACorrelationIdAndAMessageType() {
        EventEntity paymentEvent = createAndSaveEvent(PAYMENT_EVENT_TYPE_CODE);
        EventEntity searchedPaymentEvent =
            eventRepository.findFirstByCorrelationIdAndMessageType(CORRELATION_ID, getPacs002MessageType()).orElseThrow(
                () -> new AssertionFailedError("Not found event entity with correlationId " + CORRELATION_ID +
                                               " and event type from message type " + getPacs002MessageType()));

        assertThat(paymentEvent).isEqualTo(searchedPaymentEvent);
    }

    @DisplayName("when searching for a receipt event given a correlation id and the message type should return " +
                 "an EventEntity that has the same correlationId and the EventType equals the MessageType originalEventTypeCode ")
    @Test
    void shouldSearchForAReceiptEventGivenACorrelationIdAndAMessageType() {
        EventEntity firstEvent = createAndSaveEvent(RECEIPT_EVENT_TYPE_CODE);
        EventEntity secondEvent = createAndSaveEvent(RECEIPT_EVENT_TYPE_CODE);

        List<EventEntity> searchedEvents =
            eventRepository.findByCorrelationIdAndMessageType(CORRELATION_ID, getPacs002MessageType());
        assertThat(searchedEvents).hasSize(2);
        assertThat(searchedEvents).containsExactlyInAnyOrder(firstEvent, secondEvent);

        EventEntity searchedReceiptEvent =
            eventRepository.findFirstByCorrelationIdAndMessageType(CORRELATION_ID, getPacs002MessageType()).orElseThrow(
                () -> new AssertionFailedError("Not found event entity with correlationId " + CORRELATION_ID +
                                               " and event type from message type " + getPacs002MessageType()));

        assertThat(searchedEvents).contains(searchedReceiptEvent);
    }

    @DisplayName("when searching for a balance query event given should return the older event with a non final status")
    @Test
    void shouldSearchForTheOlderEventWithANonFinalStatus() {
        EventEntity firstEvent = createAndSaveEvent(BALANCE_QUERY_EVENT_TYPE_CODE);
        EventEntity secondEvent = createAndSaveEvent(BALANCE_QUERY_EVENT_TYPE_CODE);
        EventEntity thirdEvent = createAndSaveEvent(BALANCE_QUERY_EVENT_TYPE_CODE);

        firstEvent.setStatus(firstEvent.getEventTypeEntity().getSuccessStatus());
        eventRepository.saveAndFlush(firstEvent);

        List<EventEntity> searchedEvents =
            eventRepository.findNonFinalEventByEventType(eventTypeRepository.getOne(BALANCE_QUERY_EVENT_TYPE_CODE));
        assertThat(searchedEvents).hasSize(2);
        assertThat(searchedEvents).containsExactly(secondEvent, thirdEvent);

        EventEntity eventFound =
            eventRepository.findFirstNonFinalEventByEventType(eventTypeRepository.getOne(BALANCE_QUERY_EVENT_TYPE_CODE))
                .orElseThrow(() -> new AssertionFailedError(
                    "Not found event entity with event type: " + BALANCE_QUERY_EVENT_TYPE_CODE));

        assertThat(eventFound).isEqualTo(secondEvent);
    }

    @Test
    void shouldBeAbleToCreateIpAccountOwnerUpdateEventEntity() {
        Integer eventTypeCode = EventType.IP_ACCOUNT_OWNER_UPDATE.getCode();
        IpAccountOwnerUpdateEventEntity eventEntity =
            (IpAccountOwnerUpdateEventEntity) createAndSaveEvent(eventTypeCode);

        IpAccountOwnerEntity ipAccountOwnerEntity = buildIpAccountOwnerEntityWithRequiredFields();
        ipAccountOwnerService.save(ipAccountOwnerEntity);

        eventEntity.setIpAccountOwnerEntity(ipAccountOwnerEntity);
        eventRepository.saveAndFlush(eventEntity);

        IpAccountOwnerUpdateEventEntity searchedEventEntity =
            (IpAccountOwnerUpdateEventEntity) eventRepository.findById(eventEntity.getId())
                .orElseThrow(AssertionError::new);

        assertThat(searchedEventEntity.getIpAccountOwnerEntity()).isNotNull();
        assertThat(searchedEventEntity.getIpAccountOwnerEntity()).isEqualTo(ipAccountOwnerEntity);
    }

    @Test
    void shouldSumOutstandingBalance() {
        createAndSaveEvent(WITHDRAW_EVENT_TYPE_CODE);
        createAndSaveEvent(DEPOSIT_EVENT_TYPE_CODE);
        createAndSaveEvent(DEPOSIT_EVENT_TYPE_CODE);

        List<OutstandingBalanceSumDTO> outstandingBalances = eventRepository.findOutstandingBalance();

        OutstandingBalanceSumDTO depositAmount =
            new OutstandingBalanceSumDTO(BigDecimal.valueOf(2), EventType.IP_ACCOUNT_DEPOSIT.getCode());
        OutstandingBalanceSumDTO withdrawAmount =
            new OutstandingBalanceSumDTO(BigDecimal.valueOf(1), EventType.IP_ACCOUNT_WITHDRAW.getCode());

        assertThat(outstandingBalances).hasSize(2);
        assertThat(outstandingBalances.get(0).getSumAmount()).isEqualByComparingTo(depositAmount.getSumAmount());
        assertThat(outstandingBalances.get(0).getEventType()).isEqualByComparingTo(depositAmount.getEventType());
        assertThat(outstandingBalances.get(1).getSumAmount()).isEqualByComparingTo(withdrawAmount.getSumAmount());
        assertThat(outstandingBalances.get(1).getEventType()).isEqualByComparingTo(withdrawAmount.getEventType());
    }

    @Test
    void shouldSumOutstandingBalanceQuery() {
        createAndSaveEvent(WITHDRAW_EVENT_TYPE_CODE);
        createAndSaveEvent(DEPOSIT_EVENT_TYPE_CODE);
        createAndSaveEvent(DEPOSIT_EVENT_TYPE_CODE);

        BigDecimal outstandingBalances = eventRepository.findOutstandingBalanceQuery(DEPOSIT_EVENT_TYPE_CODE).get();

        assertThat(outstandingBalances).isEqualByComparingTo(BigDecimal.valueOf(2));
    }

    @DisplayName("when searching for all events should ignore parameters with null value")
    @Test
    void shouldSearchWithOptionalFilters() {
        EventEntity firstEvent = createAndSaveEvent(PAYMENT_EVENT_TYPE_CODE);
        EventEntity secondEvent = createAndSaveEvent(RECEIPT_EVENT_TYPE_CODE);
        EventEntity thirdEvent = createAndSaveEvent(BALANCE_QUERY_EVENT_TYPE_CODE);

        Pageable pageable = Pageable.unpaged();
        LocalDateTime startTimestampUtc = null;
        LocalDateTime endTimestampUtc = null;
        String endToEndId = null;
        List<Integer> transactionType = null;
        List<Integer> transactionStatus = null;

        Page<EventEntity> entityPage = eventRepository.findAllWithOptionalParameters(pageable,
            startTimestampUtc,
            endTimestampUtc,
            endToEndId,
            null, transactionType,
            transactionStatus);

        assertThat(entityPage).hasSize(3);

        transactionType = List.of(RECEIPT_EVENT_TYPE_CODE);

        Page<EventEntity> entityPageWithTransactionType = eventRepository.findAllWithOptionalParameters(pageable,
            startTimestampUtc,
            endTimestampUtc,
            endToEndId,
            null, transactionType,
            transactionStatus);

        assertThat(entityPageWithTransactionType).hasSize(1);
    }

    @DisplayName("when searching by payer branch and account")
    @Test
    void shouldSearchWithOptionalFiltersPayerBranchAndAccount() {
        PaymentEntity paymentEntity = paymentTransactionUtils.newPaymentEntity(new BigDecimal("120.00"), EventConstants.EVENT_STATUS_SUCCESS);

        paymentRepository.saveAndFlush(paymentEntity);

        Pageable pageable = Pageable.unpaged();
        LocalDateTime startTimestampUtc = null;
        LocalDateTime endTimestampUtc = null;
        String branch = TransactionConstants.PAYER_BRANCH;
        String accountNumber = TransactionConstants.PAYER_ACCOUNT;
        String endToEndId = null;
        List<Integer> transactionType = null;
        List<Integer> transactionStatus = null;

        Page<TransactionEventEntity> entityPage = transactionEventRepository.findAllWithOptionalParameters(pageable,
            startTimestampUtc,
            endTimestampUtc,
            branch,
            accountNumber,
            endToEndId,
            null, transactionType,
            transactionStatus);

        assertThat(entityPage).hasSize(1);

    }

    private MessageTypeEntity getPacs002MessageType() {
        return messageTypeRepository.findById("pacs.002")
            .orElseThrow(() -> new AssertionFailedError("Not found message type pacs.002"));
    }


    @DisplayName("when searching payment by receiver branch and account")
    @Test
    void shouldNotFoundWhenSearchWithOptionalFiltersReceiverBranchAndAccount() {
        PaymentEntity paymentEntity = paymentTransactionUtils.newPaymentEntity(new BigDecimal("120.00"), EventConstants.EVENT_STATUS_SUCCESS);

        paymentRepository.saveAndFlush(paymentEntity);

        Pageable pageable = Pageable.unpaged();
        LocalDateTime startTimestampUtc = null;
        LocalDateTime endTimestampUtc = null;
        String branch = TransactionConstants.RECEIVER_BRANCH;
        String accountNumber = TransactionConstants.RECEIVER_ACCOUNT;
        String endToEndId = null;
        List<Integer> transactionType = null;
        List<Integer> transactionStatus = null;

        Page<TransactionEventEntity> entityPage = transactionEventRepository.findAllWithOptionalParameters(pageable,
            startTimestampUtc,
            endTimestampUtc,
            branch,
            accountNumber,
            endToEndId,
            null, transactionType,
            transactionStatus);

        assertThat(entityPage).hasSize(0);

    }

    @NotNull
    private EventEntity createAndSaveEvent(int eventTypeCode) {
        EventEntity expectedEvent = buildEventEntity(eventTypeCode);
        EventTypeEntity eventTypeEntity = eventTypeRepository.findById(eventTypeCode)
            .orElseThrow(() -> new AssertionFailedError(NOT_FOUND_EVENT_TYPE + eventTypeCode));
        expectedEvent.setEventTypeEntity(eventTypeEntity);
        expectedEvent.setStatus(eventTypeEntity.getInitialStatus());
        expectedEvent = eventRepository.saveAndFlush(expectedEvent);
        return expectedEvent;
    }

    @NotNull
    private EventEntity createEventMessageEntityEventStatusTransitionEntity() {
        EventEntity expectedEvent = buildEventEntityWithEventStatusTransitionEntity();
        EventTypeEntity eventTypeEntity = eventTypeRepository.findById(PAYMENT_EVENT_TYPE_CODE)
            .orElseThrow(() -> new AssertionFailedError("Not found Payment Type"));
        expectedEvent.setStatus(eventTypeEntity.getInitialStatus());
        expectedEvent.setEventTypeEntity(eventTypeEntity);
        expectedEvent = eventRepository.saveAndFlush(expectedEvent);
        return expectedEvent;
    }

    @Test
    void shouldUpdateIndirectParticipantRescissionEventEntityAndCascadeHistory() {
        transactionTemplate.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        transactionTemplate.executeWithoutResult(transactionStatus -> {
            transactionStatus.setRollbackOnly();

            final Integer eventTypeCode = EventType.INDIRECT_PARTICIPANT_RESCISSION.getCode();
            final IndirectParticipantRescissionEventEntity eventEntity =
                (IndirectParticipantRescissionEventEntity) createAndSaveEvent(eventTypeCode);
            final ParticipantMipEntity participantMip = ParticipantMipIndirectDataSetUtil.createParticipantMip();
            final ParticipantMipIndirectEntity participantMipIndirectEntity = ParticipantMipIndirectDataSetUtil
                .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository, participantMip);

            participantMipIndirectRepository.saveAndFlush(participantMipIndirectEntity);

            final ParticipantMipIndirectHistoryEntity participantMipIndirectHistoryEntity =
                ParticipantMipIndirectDataSetUtil
                    .createParticipantMipIndirectHistoryEntity(participantMipIndirectEntity);

            eventEntity.relateToNewHistory(participantMipIndirectHistoryEntity);
            participantMipIndirectHistoryEntity.setEvent(eventEntity);

            eventRepository.saveAndFlush(eventEntity);

            final EventEntity eventEntityFound = eventRepository.findById(eventEntity.getId())
                .orElseThrow(() -> new AssertionFailedError(EVENT_NOT_FOUND_WITH_ID + eventEntity.getId()));

            final ParticipantMipIndirectHistoryEntity historyEntity =
                participantMipIndirectHistoryRepository.findAll().iterator().next();

            org.junit.jupiter.api.Assertions.assertNotNull(eventEntityFound);

            final ParticipantMipIndirectHistoryEntity historyFound =
                IndirectParticipantRescissionEventEntity.class.cast(eventEntityFound).getHistories().iterator().next();

            org.junit.jupiter.api.Assertions.assertEquals(historyEntity, historyFound);

            Assertions.assertThat(historyEntity).hasFieldOrPropertyWithValue(EVENT_ATTR_NAME, eventEntityFound);
        });
    }

    @Test
    void shouldSaveIndirectParticipantRescissionEventEntityAndCascadeHistory() {
        transactionTemplate.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        transactionTemplate.executeWithoutResult(transactionStatus -> {
            transactionStatus.setRollbackOnly();

            final Integer eventTypeCode = EventType.INDIRECT_PARTICIPANT_RESCISSION.getCode();
            final IndirectParticipantRescissionEventEntity eventEntity =
                (IndirectParticipantRescissionEventEntity) createButNotSaveEvent(eventTypeCode);
            final ParticipantMipEntity participantMip = ParticipantMipIndirectDataSetUtil.createParticipantMip();
            final ParticipantMipIndirectEntity participantMipIndirectEntity = ParticipantMipIndirectDataSetUtil
                .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository, participantMip);

            participantMipIndirectRepository.saveAndFlush(participantMipIndirectEntity);

            final ParticipantMipIndirectHistoryEntity participantMipIndirectHistoryEntity =
                ParticipantMipIndirectDataSetUtil
                    .createParticipantMipIndirectHistoryEntity(participantMipIndirectEntity);

            eventEntity.relateToNewHistory(participantMipIndirectHistoryEntity);
            participantMipIndirectHistoryEntity.setEvent(eventEntity);

            eventRepository.saveAndFlush(eventEntity);

            final EventEntity eventEntityFound = eventRepository.findById(eventEntity.getId())
                .orElseThrow(() -> new AssertionFailedError(EVENT_NOT_FOUND_WITH_ID + eventEntity.getId()));

            final ParticipantMipIndirectHistoryEntity historyEntity =
                participantMipIndirectHistoryRepository.findAll().iterator().next();

            org.junit.jupiter.api.Assertions.assertNotNull(eventEntityFound);

            final ParticipantMipIndirectHistoryEntity historyFound =
                IndirectParticipantRescissionEventEntity.class.cast(eventEntityFound).getHistories().iterator().next();

            org.junit.jupiter.api.Assertions.assertEquals(historyEntity, historyFound);

            Assertions.assertThat(historyEntity).hasFieldOrPropertyWithValue(EVENT_ATTR_NAME, eventEntityFound);
        });
    }

    private EventEntity createButNotSaveEvent(int eventTypeCode) {
        final EventEntity expectedEvent = buildEventEntity(eventTypeCode);
        final EventTypeEntity eventTypeEntity = eventTypeRepository.findById(eventTypeCode)
            .orElseThrow(() -> new AssertionFailedError(NOT_FOUND_EVENT_TYPE + eventTypeCode));

        expectedEvent.setEventTypeEntity(eventTypeEntity);
        expectedEvent.setStatus(eventTypeEntity.getInitialStatus());

        return eventRepository.saveAndFlush(expectedEvent);
    }

}
