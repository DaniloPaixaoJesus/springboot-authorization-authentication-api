package matera.spi.lm.transactions.adapter.spb;

import matera.spi.dto.SpbCallbackDTO;
import matera.spi.lm.domain.model.spb.SpbEventEntity;
import matera.spi.lm.domain.model.spb.deposit.IpAccountDepositDetailsEntity;
import matera.spi.lm.domain.model.spb.deposit.IpAccountDepositEventEntity;
import matera.spi.lm.domain.service.event.spb.SpbEvent;
import matera.spi.lm.domain.service.event.spb.SpbEventDomainService;
import matera.spi.lm.domain.service.event.spb.SpbEventFactory;
import matera.spi.main.config.MainEngineConfiguration;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.internal.util.collections.Sets;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SpbRepliesIncomingAdapterTest {

    private static final String LPI0006_PATH = "lpi0006/lpi0006_EXAMPLE_SUCCESS.xml";
    private static final String LPI0006_XML_STRING = getStringFromXmlFile(LPI0006_PATH);

    @InjectMocks
    private SpbRepliesIncomingAdapter spbRepliesIncomingAdapter;

    @Mock
    private SpbEventFactory spbEventFactory;

    @Mock
    private SpbEventDomainService spbEventDomainService;

    @Mock
    private SpbEvent spbEvent;

    @Mock
    private MainEngineConfiguration mainEngineConfiguration;

    @Test
    void assertGetSpbEventBySpbEventFactory() {
        when(spbEventFactory.findByEventEntity(any())).thenReturn(spbEvent);
        when(spbEventDomainService.findBySpbEventId(any())).thenReturn(Optional.of(createSpbDepositEventEntity()));
        final SpbCallbackDTO spbCallbackDTO = buildSpbCallbackDTO();

        spbRepliesIncomingAdapter.processSpbReply(spbCallbackDTO);
        verify(spbEventFactory, times(1)).findByEventEntity(any());
    }

    @Test
    void assertCallSpbEventHandle() {
        when(spbEventFactory.findByEventEntity(any())).thenReturn(spbEvent);
        when(spbEventDomainService.findBySpbEventId(any())).thenReturn(Optional.of(createSpbDepositEventEntity()));
        final SpbCallbackDTO spbCallbackDTO = buildSpbCallbackDTO();

        spbRepliesIncomingAdapter.processSpbReply(spbCallbackDTO);
        verify(spbEvent, times(1)).handleSpbReturn(any());
    }

    @Test
    void assertCreatNewEventWhenSpbCallbackDTONotFoundAnySpbEventEntity() {
        when(mainEngineConfiguration.getClearingIspb()).thenReturn("123");
        when(spbEventFactory.createNewEvent(any())).thenReturn(spbEvent);
        when(spbEventDomainService.findBySpbEventId(any())).thenReturn(Optional.empty());
        final SpbCallbackDTO spbCallbackDTO = buildSpbCallbackDTO();

        spbRepliesIncomingAdapter.processSpbReply(spbCallbackDTO);
        verify(spbEventFactory, times(1)).createNewEvent(any());
    }

    @Test
    void shouldThrowWhenEventNotExist() {
        final SpbCallbackDTO spbCallbackDTO = buildSpbCallbackDTO();
        assertThrows(RuntimeException.class, () -> spbRepliesIncomingAdapter.processSpbReply(spbCallbackDTO));
    }

    private SpbCallbackDTO buildSpbCallbackDTO() {
        final SpbCallbackDTO spbCallbackDTO = new SpbCallbackDTO();
        spbCallbackDTO.setId(1l);
        spbCallbackDTO.setTipoEvento("LPI0001");
        spbCallbackDTO.setSituacaoNm(7);
        spbCallbackDTO.setMessages(List.of(LPI0006_XML_STRING));

        return spbCallbackDTO;
    }

    private IpAccountDepositEventEntity createSpbDepositEventEntity() {
        final IpAccountDepositEventEntity depositEntity = new IpAccountDepositEventEntity();
        depositEntity.setIpAccountDepositDetails(createSpbDepositEventDetailsEntity());
        setBasicEventInfo(depositEntity);
        return depositEntity;
    }

    private IpAccountDepositDetailsEntity createSpbDepositEventDetailsEntity() {
        IpAccountDepositDetailsEntity detailsEntity = new IpAccountDepositDetailsEntity();
        detailsEntity.setIspbif(100L);
        detailsEntity.setIspbpspi(999L);
        return detailsEntity;
    }

    private void setBasicEventInfo(SpbEventEntity spbEventENtity) {
        spbEventENtity.setSpbEventId(1L);
        spbEventENtity.setControlNumber("1a2b3c");
        spbEventENtity.setMovementDate(LocalDate.of(2020, 5, 11));
        spbEventENtity.setSpbMessageEntity(Sets.newSet());
        spbEventENtity.setValue(BigDecimal.TEN);
        spbEventENtity.setInitiationTimestampUTC(LocalDateTime.now());
        spbEventENtity.setInitiatorIspb(1);
    }

}
