package matera.spi.main.domain.service.event.receiver;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.dto.MessageReceiverDTO;
import matera.spi.main.dto.MessageReceiverEventDTO;
import matera.spi.main.exception.MessageReceiverException;
import matera.spi.main.persistence.MessageRepository;
import matera.spi.main.persistence.MessageTypeRepository;
import matera.spi.main.persistence.ParticipantRepository;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.testcontainers.shaded.com.fasterxml.jackson.core.JsonProcessingException;
import org.testcontainers.shaded.com.fasterxml.jackson.databind.ObjectMapper;

import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

@Slf4j
@IntegrationTest
class MessageReceiverTest  {

	@Autowired
	private MessageReceiver messageReceiver;

	@Autowired
	private ParticipantRepository participantRepository;

	@Autowired
	private MessageRepository messageRepository;

	@Autowired
	private MessageTypeRepository messageTypeRepository;

	@Autowired
	private MessageReceiverProcessorReplyService messageReceiverProcessorReplyService;
	@Mock
    private MessageReceiverProcessorReplyService mockedMessageReceiverProcessorReplyService;

    @Autowired
	private MessageReceiverProcessorNonReplyService messageReceiverProcessorNonReplyService;
    @Mock
    private MessageReceiverProcessorNonReplyService mockedMessageReceiverProcessorNonReplyService;

    @Autowired
	private MessageReceiverAdmi002Processor messageReceiverAdmi002Processor;
    @Mock
    private MessageReceiverAdmi002Processor mockedMessageReceiverAdmi002Processor;

    private static final String PACS_002_SPI_1_2_PSP_CREDOR_10_MSG = "pacs.002/pacs.002.spi.1.2_PSP_CREDOR_10_msg.xml";
	private static final String PACS_002_SPI_1_2_INEXIST_ISPB = "invalid/pacs.002.spi.1.2_inexist_ispb.xml";
	private static final String PACS_002_SPI_1_2_INVALID_MESSAGETYPE = "invalid/pacs.002.spi.1.2_invalid_messagetype.xml";
	private static final String PACS_008_SPI_1_2_END_1_MSG = "pacs.008/pacs.008.spi.1.2_END_1_msg.xml";
	private static final String ADMI_002_SPI_1_2_SPI_M_MSG = "admi.002/admi.002.spi.1.2_SPI_M_msg.xml";

    @BeforeEach
    void setUp() {
        messageReceiver.setMessageReceiverAdmi002Processor(mockedMessageReceiverAdmi002Processor);
        messageReceiver.setMessageReceiverProcessorNonReplyService(mockedMessageReceiverProcessorNonReplyService);
        messageReceiver.setMessageReceiverProcessorReplyService(mockedMessageReceiverProcessorReplyService);
    }

    @AfterEach
    public void tearDown(){
        messageRepository.deleteAll();
        participantRepository.deleteParticipants("Sender Financial Instituition");
        participantRepository.deleteParticipants("Receiver Financial Instituition");

        messageReceiver.setMessageReceiverAdmi002Processor(messageReceiverAdmi002Processor);
        messageReceiver.setMessageReceiverProcessorNonReplyService(messageReceiverProcessorNonReplyService);
        messageReceiver.setMessageReceiverProcessorReplyService(messageReceiverProcessorReplyService);
    }

    @Test
    void shouldNotBeProcessAdmi002WhenPiResourceIdOrMessageIdNotFound() throws JsonProcessingException {
        messageReceiver.readIncomingMessage(createMessageMock("ResourceId 01", "txn 01", ADMI_002_SPI_1_2_SPI_M_MSG));

        MessageEntity messageExample = new MessageEntity();
        messageExample.setPiResourceId("ResourceId 01");
        Long count = messageRepository.count(Example.of(messageExample));
        Assertions.assertEquals(1, count);
        verify(mockedMessageReceiverAdmi002Processor).processEvent(any(MessageReceiverEventDTO.class));
        verify(mockedMessageReceiverProcessorReplyService, never()).processEvent(any(MessageReceiverEventDTO.class));
        verify(mockedMessageReceiverProcessorNonReplyService, never()).processEvent(any(MessageReceiverEventDTO.class));
    }

    @Test
	void shouldBeProcessWhenAdmi002MessageReceived() throws JsonProcessingException {
		messageReceiver.readIncomingMessage(createMessageMock("ResourceId 01", "txn 01", ADMI_002_SPI_1_2_SPI_M_MSG));

		MessageEntity messageExample = new MessageEntity();
		messageExample.setPiResourceId("ResourceId 01");
		Long count = messageRepository.count(Example.of(messageExample));
		Assertions.assertEquals(1, count);
		verify(mockedMessageReceiverAdmi002Processor).processEvent(any(MessageReceiverEventDTO.class));
		verify(mockedMessageReceiverProcessorReplyService, never()).processEvent(any(MessageReceiverEventDTO.class));
		verify(mockedMessageReceiverProcessorNonReplyService, never()).processEvent(any(MessageReceiverEventDTO.class));
	}
	@Test
	void shouldBeProcessOkWhenPacs008MessageReceived() throws JsonProcessingException {
		insertParticipant(892100, "Sender Financial Instituition");
		insertParticipant(00001, "Receiver Financial Instituition");
		messageReceiver.readIncomingMessage(createMessageMock("ResourceId 01", "txn 01", PACS_008_SPI_1_2_END_1_MSG));
		MessageEntity messageExample = new MessageEntity();
		messageExample.setPiResourceId("ResourceId 01");
		Long count = messageRepository.count(Example.of(messageExample));
		Assertions.assertEquals(1, count);
		verify(mockedMessageReceiverProcessorNonReplyService).processEvent(any(MessageReceiverEventDTO.class));
	}

	@Test
	void shouldBeProcessOkWhenPacs002MessageReceived() throws JsonProcessingException {
		insertParticipant(673146, "Sender Financial Instituition");
		insertParticipant(00001, "Receiver Financial Instituition");
		messageReceiver.readIncomingMessage(createMessageMock("ResourceId 01", "txn 01", PACS_002_SPI_1_2_PSP_CREDOR_10_MSG));
		MessageEntity messageExample = new MessageEntity();
		messageExample.setPiResourceId("ResourceId 01");
		Long count = messageRepository.count(Example.of(messageExample));
		Assertions.assertEquals(1, count);
		verify(mockedMessageReceiverProcessorReplyService).processEvent(any(MessageReceiverEventDTO.class));
	}

	@Test
	void shouldBeExceptionSavedWhenMessageTypeNotFound() throws JsonProcessingException {
		insertParticipant(673146, "Sender Financial Instituition");
		insertParticipant(00001, "Receiver Financial Instituition");
		Assertions.assertThrows(MessageReceiverException.class,
				() -> messageReceiver.readIncomingMessage(createMessageMock("ResourceId 01", "txn 01", PACS_002_SPI_1_2_INVALID_MESSAGETYPE)),
				"Cannot find MessageType into Enumeration EnumMessageType");
	}

	@Test
	void shouldBeExceptionSavedWhenParticipantNotFound() {
		insertParticipant(673146, "Sender Financial Instituition");
		Assertions.assertThrows(MessageReceiverException.class,
				() -> messageReceiver.readIncomingMessage(createMessageMock("ResourceId 01", "txn 01", PACS_002_SPI_1_2_INEXIST_ISPB)),
				"Cannot find participant with ispb 00038166");
	}

	@Test
	void shouldBeProcessOkWhenPiResourceIdExists() throws JsonProcessingException {
		insertParticipant(673146, "Sender Financial Instituition");
		insertParticipant(00000001, "Receiver Financial Instituition");
		messageReceiver.readIncomingMessage(createMessageMock("ResourceId 01", "txn 01", PACS_002_SPI_1_2_PSP_CREDOR_10_MSG));
		messageReceiver.readIncomingMessage(createMessageMock("ResourceId 01", "txn 01", PACS_002_SPI_1_2_PSP_CREDOR_10_MSG));
		MessageEntity messageExample = new MessageEntity();
		messageExample.setPiResourceId("ResourceId 01");
		Long count = messageRepository.count(Example.of(messageExample));
		Assertions.assertEquals(1, count);
	}

	private void insertParticipant(Integer ispb, String name) {
		ParticipantEntity participantEntity = new ParticipantEntity();
		participantEntity.setIspb(ispb);
		participantEntity.setName(name);
		participantRepository.saveAndFlush(participantEntity);
	}

	private String createMessageMock(String piResourceId, String txnId, String xmlFileName) throws JsonProcessingException {
		String xml = getStringFromXmlFile(xmlFileName);
		MessageReceiverDTO messageReceiverDTO = MessageReceiverDTO.builder().piResourceId(piResourceId).xml(xml).build();
		return new ObjectMapper().writeValueAsString(messageReceiverDTO);
	}
}
