package matera.spi.main.domain.service;

import com.matera.client.rest.exception.RestBadRequestException;
import com.matera.commons.rest.dto.MateraRestErrorDTO;

import matera.spi.main.domain.model.RejectReasonStandinEntity;
import matera.spi.main.domain.model.transaction.ReceiptEntity;
import matera.spi.main.domain.model.transaction.TransactionRejectReasonEntity;
import matera.spi.main.exception.EventValidatorException;
import matera.spi.main.persistence.TransactionRejectReasonRepository;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TransactionRejectReasonStandinServiceTest {

    private static final String MESSAGE_ERROR = "Settlement of the transaction has failed";
    private static final String MESSAGE_ERROR_STANDIN =
        "[MateraErrorDTO [code=%s, message=Agência 2 e conta 208858 não foi encontrada., field=null, action=null]]";
    private static final String CODE_STD = "STD-002";
    private static final String CODE_MTR = "MTR-002";

    @Mock
    private ReceiptService receiptService;

    @Mock
    private RejectionReasonStandinService rejectionReasonStandinService;

    @Mock
    private TransactionRejectReasonRepository transactionRejectReasonRepository;

    @InjectMocks
    private TransactionRejectReasonStandinService transactionRejectReasonStandinService;

    @Test
    void shouldReturnEventValidatorExceptionWhenMateraRestErrorDTOIsGreaterThanZero() {
        RejectReasonStandinEntity rejectReasonStandinEntity = createRejectReasonStandinEntity();
        RestBadRequestException restBadRequestException = createRestBadRequestException(CODE_STD);

        when(rejectionReasonStandinService.findByRejectionCodeStandin(any())).thenReturn(List.of(rejectReasonStandinEntity));

        assertThatThrownBy(() -> transactionRejectReasonStandinService
            .transactionRejectReasonToRejectReasonStandin(restBadRequestException, new ReceiptEntity()))
            .isInstanceOf(EventValidatorException.class)
            .hasMessage(MESSAGE_ERROR_STANDIN, CODE_STD);

        verify(receiptService).setReasonCodeFromEventEntity(any(), any(), any());
    }

    @Test
    void shouldReturnEventValidatorExceptionWhenRejectReasonStandinEntityIsEmpty() {
        RejectReasonStandinEntity rejectReasonStandinEntity = createRejectReasonStandinEntity();
        RestBadRequestException restBadRequestException = createRestBadRequestException(CODE_STD);

        when(rejectionReasonStandinService.findByRejectionCodeStandin(any())).thenReturn(List.of());

        assertThatThrownBy(() -> transactionRejectReasonStandinService
            .transactionRejectReasonToRejectReasonStandin(restBadRequestException, new ReceiptEntity()))
            .isInstanceOf(EventValidatorException.class)
            .hasMessage(MESSAGE_ERROR);

        verify(receiptService).setReasonCodeFromEventEntity(any(), any(), any());
    }

    @Test
    void shouldReturnEventValidatorExceptionWhenMateraErrorCodeIsDifferentTheNullAndTransactionRejectReasonEntityIsNull() {
        RestBadRequestException restBadRequestException = createRestBadRequestException(CODE_MTR);

        when(transactionRejectReasonRepository.findById(CODE_MTR)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> transactionRejectReasonStandinService
            .transactionRejectReasonToRejectReasonStandin(restBadRequestException, new ReceiptEntity()))
            .isInstanceOf(EventValidatorException.class)
            .hasMessage(MESSAGE_ERROR);

        verify(receiptService, never()).setReasonCodeFromEventEntity(any(), any(), any());

    }

    @Test
    void shouldReturnEventValidatorExceptionWhenMateraErrorCodeIsDifferentTheNullAndTransactionRejectReasonEntityIsNotNull() {
        RestBadRequestException restBadRequestException = createRestBadRequestException(CODE_MTR);

        when(transactionRejectReasonRepository.findById(CODE_MTR)).thenReturn(Optional.of(new TransactionRejectReasonEntity()));

        assertThatThrownBy(() -> transactionRejectReasonStandinService
            .transactionRejectReasonToRejectReasonStandin(restBadRequestException, new ReceiptEntity()))
            .isInstanceOf(EventValidatorException.class)
            .hasMessage(MESSAGE_ERROR_STANDIN, CODE_MTR);

        verify(receiptService).setReasonCodeFromEventEntity(any(), any(), any());
    }

    @Test
    void shouldReturnEventValidatorExceptionWhenTheExceptionReceivedInTheParameterIsNotRestBadRequestException() {
        assertThatThrownBy(() -> transactionRejectReasonStandinService
            .transactionRejectReasonToRejectReasonStandin(new Exception(), new ReceiptEntity()))
            .isInstanceOf(EventValidatorException.class)
            .hasMessage(MESSAGE_ERROR);

        verify(receiptService).setReasonCodeFromEventEntity(any(), any(), any());

    }

    private RejectReasonStandinEntity createRejectReasonStandinEntity() {
        RejectReasonStandinEntity rejectReasonStandinEntity = new RejectReasonStandinEntity();
        TransactionRejectReasonEntity transactionRejectReasonEntity = new TransactionRejectReasonEntity();
        transactionRejectReasonEntity.setCode("13213");
        rejectReasonStandinEntity.setTransactionRejectReasonEntity(transactionRejectReasonEntity);
        return rejectReasonStandinEntity;
    }

    private RestBadRequestException createRestBadRequestException(String code) {
        MateraRestErrorDTO materaRestErrorDTO = createMateraRestErrorDTO(code);
        return new RestBadRequestException(1,"","", Optional.of(List.of(materaRestErrorDTO)));
    }

    private MateraRestErrorDTO createMateraRestErrorDTO(String code) {
        MateraRestErrorDTO materaRestErrorDTO = new MateraRestErrorDTO();
        materaRestErrorDTO.setCode(code);
        materaRestErrorDTO.setMessage("Agência 2 e conta 208858 não foi encontrada.");
        return materaRestErrorDTO;
    }

}
