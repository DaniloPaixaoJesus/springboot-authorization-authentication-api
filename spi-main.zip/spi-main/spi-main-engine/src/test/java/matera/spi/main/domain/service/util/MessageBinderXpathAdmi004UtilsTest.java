package matera.spi.main.domain.service.util;

import matera.spi.utils.DocumentUtils;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;

import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;

import static org.assertj.core.api.Assertions.assertThat;

class MessageBinderXpathAdmi004UtilsTest {

	private static final String ADMI_004 = "admi.004/admi.004_msg.xml";
	private static final String EVT_CD = "SPI";
    private static final String CD = "mudança da data contábil";

	@Test
	@DisplayName("Proprietary code used to specify an event that occurred in a system.")
	void shouldEvtcCd() {
		Document document = DocumentUtils.stringToXmlDocument(getXml());
		String evtCd = MessageBinderXpathAdmi004Utils.getEvtCd(document);
		assertThat(evtCd).isEqualTo(EVT_CD);
	}

    @Test
    @DisplayName("Free text used to describe an event which occurred in a system.")
    void shouldCd() {
        Document document = DocumentUtils.stringToXmlDocument(getXml());
        String evtDesc = MessageBinderXpathAdmi004Utils.getEvtDesc(document);
        assertThat(evtDesc).isEqualTo(CD);
    }

	private String getXml() {
		return getStringFromXmlFile(ADMI_004);
	}
}
