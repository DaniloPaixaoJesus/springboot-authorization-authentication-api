package matera.spi.main.domain.service.event;

import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventStatusEntity;
import matera.spi.main.domain.model.event.EventType;
import matera.spi.main.domain.model.message.MessageTypeEntity;
import matera.spi.main.exception.DuplicateMessageException;
import matera.spi.main.persistence.RelMsgStatusEvtStatusRepository;
import matera.spi.main.utils.EntityCreationUtils;

import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class EventStatusServiceTest {

    @InjectMocks
    private EventStatusService eventStatusService;

    @Mock
    private RelMsgStatusEvtStatusRepository relMsgStatusEvtStatusRepository;

    @ParameterizedTest(name="[{index}] |{0}|")
    @NullAndEmptySource
    @DisplayName("when message element status it's not provided it should return the event type defined success status")
    void shouldReturnEventTypeSuccessStatusWhenMessageElementStatusItsNotProvided(String emptyMessageStatus) {

        EventEntity eventEntity = buildEventEntity();
        EventStatusEntity expectedNextEventStatus = eventEntity.getEventTypeEntity().getSuccessStatus();

        EventStatusEntity nextEventStatus =
            eventStatusService.getNextEventStatus(eventEntity, buildReplyMessageType(), emptyMessageStatus);

        assertThat(nextEventStatus).isEqualTo(expectedNextEventStatus);

    }

    @ParameterizedTest(name="[{index}] |{0}|")
    @NullAndEmptySource
    @DisplayName("when message element status it's not provided and event type does not have success status it should throws IllegalArgumentException")
    void shouldThrowIllegalArgumentExceptionWhenMessageElementStatusItsNotProvidedAndEventTypeDoesNotHaveSuccessStatus(String emptyMessageStatus) {

        EventEntity eventEntity = buildEventEntity();
        eventEntity.getEventTypeEntity().setDescription("SOME EVENT TYPE");
        eventEntity.getEventTypeEntity().setSuccessStatus(null);

        MessageTypeEntity replyMessageType = buildReplyMessageType();
        assertThatThrownBy(() -> eventStatusService.getNextEventStatus(eventEntity, replyMessageType, emptyMessageStatus))
            .isInstanceOf(IllegalArgumentException.class)
            .hasMessage("EventType %s does not have success status defined", eventEntity.getEventTypeEntity().getDescription());

    }


    @Test
    @DisplayName("when event was already on a final status it should throws an DuplicatedMessageException")
    void shouldThrowDuplicatedMessageExceptionWhenEventWasAlreadyOnAFinalStatus() {

        EventEntity eventEntity = buildEventEntity();
        eventEntity.setStatus(EntityCreationUtils.buildSuccessEventStatusEntity());

        MessageTypeEntity replyMessageType = buildReplyMessageType();
        assertThatThrownBy(() -> eventStatusService.getNextEventStatus(eventEntity, replyMessageType, "NOT RELEVANT"))
            .isInstanceOf(DuplicateMessageException.class)
            .hasMessage("Current event status is final. [event id: %s]", eventEntity.getId());

    }

    @Test
    @DisplayName("given eventEntity with a reply message and the message status it should return the new status mapped at ME_REL_MSG_STS_EVT_STS")
    void shouldReturnTheMappedRelMsgStsEvtSts() {

        EventEntity eventEntity = buildEventEntity();

        EventStatusEntity expectedNextEventStatus = mock(EventStatusEntity.class);
        MessageTypeEntity messageType = buildReplyMessageType();
        String messageStatus = "ACSC";

        when(relMsgStatusEvtStatusRepository
            .findNextEventStatus(eventEntity.getEventTypeEntity(), messageType, eventEntity.getStatus(), messageStatus))
            .thenReturn(Optional.of(expectedNextEventStatus));

        EventStatusEntity nextEventStatus =
            eventStatusService.getNextEventStatus(eventEntity, messageType, messageStatus);

        assertThat(nextEventStatus).isEqualTo(expectedNextEventStatus);
    }

    @Test
    @DisplayName("when findNextEventStatus return the same current event status it should throws DuplicatedMessageException")
    void shouldThrowDuplicatedMessageExceptionFindNextEventStatusReturnSameCurrentEventStatus() {

        EventEntity eventEntity = buildEventEntity();
        MessageTypeEntity messageType = buildReplyMessageType();
        String messageStatus = "ACSC";


        EventStatusEntity sameCurrentEventStatus = eventEntity.getStatus();
        when(relMsgStatusEvtStatusRepository
            .findNextEventStatus(eventEntity.getEventTypeEntity(), messageType, eventEntity.getStatus(), messageStatus))
            .thenReturn(Optional.of(sameCurrentEventStatus));

        assertThatThrownBy(() ->
            eventStatusService.getNextEventStatus(eventEntity, messageType, messageStatus))
            .isInstanceOf(DuplicateMessageException.class)
            .hasMessage("Event %s was already with status %s", eventEntity.getId(), sameCurrentEventStatus.getDescription());

    }

    @Test
    @DisplayName("when findNextStatus returns empty optional it should throws IllegalArgumentException")
    void shouldThrowIllegalArgumentExceptionWhenNotFindNextDoesNotFoundNextStatus() {

        EventEntity eventEntity = buildEventEntity();

        doReturn(Optional.empty()).when(relMsgStatusEvtStatusRepository).findNextEventStatus(any(), any(), any(), any());

        MessageTypeEntity replyMessageType = buildReplyMessageType();
        assertThatThrownBy(() ->
            eventStatusService.getNextEventStatus(eventEntity, replyMessageType, "SOME MSG STS"))
            .isInstanceOf(IllegalArgumentException.class)
            .hasMessageStartingWith("Not found new status for event type");

    }

    @NotNull
    private MessageTypeEntity buildReplyMessageType() {
        return EntityCreationUtils.buildPacs002MessageTypeEntity();
    }

    @NotNull
    private EventEntity buildEventEntity() {
        EventEntity eventEntity = EntityCreationUtils.buildEventEntity(EventType.PAYMENT.getCode());
        eventEntity.setStatus(EntityCreationUtils.buildWaitingPaymentConfirmEventStatusEntity());
        return eventEntity;
    }

}
