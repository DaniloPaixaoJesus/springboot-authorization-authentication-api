package matera.spi.main.domain.service.event.transaction;

import matera.spi.main.domain.model.ParticipantMipEntity;
import matera.spi.main.domain.model.event.transaction.PaymentEventEntity;
import matera.spi.main.domain.model.event.transaction.ReceiptEventEntity;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.domain.model.transaction.ReceiptEntity;
import matera.spi.main.domain.model.transaction.TransactionRejectReasonEntity;
import matera.spi.main.domain.service.ParticipantMipService;
import matera.spi.main.persistence.TransactionRejectReasonRepository;
import matera.spi.utils.DocumentUtils;
import matera.spi.main.dto.event.EventSpecificationFromReceivedMessageDTO;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

import static matera.spi.utils.DocumentUtils.stringToXmlDocument;
import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static matera.spi.main.utils.EntityCreationUtils.PACS_002_REPLY_ELEMENT;
import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TransactionEventTest {

    private static final String PACS_002_SPI_1_2_SPI_10_MSG = getStringFromXmlFile("pacs.002/pacs.002.spi.1.2_SPI_10_msg.xml");
	private static final String PACS_002_SPI_1_2_PSP_CREDOR_10_MSG = getStringFromXmlFile("pacs.002/pacs.002.spi.1.2_PSP_CREDOR_10_msg.xml");
	private static final String PACS_002_SPI_1_2_ERROR = getStringFromXmlFile("pacs.002/pacs.002.spi.1.2_ERRO_1_msg.xml");
    private static final String PACS_002_SPI_1_2_ERROR_WRONG_REASON_CODE = getStringFromXmlFile("pacs.002/pacs.002.spi.1.2_ERRO_1_msg_WRONG_REASON_CODE.xml");

	private static final Document PACS_002_SPI_DOCUMENT = stringToXmlDocument(PACS_002_SPI_1_2_SPI_10_MSG);
    private static final Document PACS_002_PSP_CREDOR_DOCUMENT = stringToXmlDocument(PACS_002_SPI_1_2_PSP_CREDOR_10_MSG);
    private static final Document PACS_002_ERROR = stringToXmlDocument(PACS_002_SPI_1_2_ERROR);
    private static final Document PACS_002_ERROR_WRONG_REASON_CODE = stringToXmlDocument(PACS_002_SPI_1_2_ERROR_WRONG_REASON_CODE);

    public static final String VALID_REJECTION_CODE = "AB03";
    public static final String VALID_REJECTION_DESCRIPTION = "Settlement aborted due to timeout";
    public static final String INVALID_REJECTION_CODE = "FAKE";


    @Mock
	private TransactionRejectReasonRepository mockTransactionRejectReasonRepository;

    @Test
    void shouldStoreReasonDescriptionWhenReasonCodeIsValid() {

        EventSpecificationFromReceivedMessageDTO specificationFromMessageDTO = createDTO(PACS_002_ERROR);
        ReceiptEventEntity receiptEventEntity = new ReceiptEventEntity();
        receiptEventEntity.setTransactionEntity(new ReceiptEntity());
        TransactionEvent transactionEvent = new ReceiptEvent(receiptEventEntity);

        TransactionRejectReasonEntity transactionRejectReasonEntity = new TransactionRejectReasonEntity();

        transactionRejectReasonEntity.setCode(VALID_REJECTION_CODE);
        transactionRejectReasonEntity.setDescription(VALID_REJECTION_DESCRIPTION);

        when(mockTransactionRejectReasonRepository.findById(VALID_REJECTION_CODE))
            .thenReturn(Optional.of(transactionRejectReasonEntity));

        ReflectionTestUtils.setField(transactionEvent, "transactionRejectReasonRepository", mockTransactionRejectReasonRepository);

        transactionEvent.verifyReasonCode(specificationFromMessageDTO);

        assertThat(transactionEvent.getTransaction().getTransactRejectionReasonCode())
            .isEqualTo(VALID_REJECTION_CODE);

        assertThat(transactionEvent.getEventEntity().getRejectionReasonDescription())
            .isEqualTo(VALID_REJECTION_DESCRIPTION);
    }

    @Test
    void shouldNotStoreReasonDescriptionWhenReasonCodeDoesNotExistInDatabase() {

        EventSpecificationFromReceivedMessageDTO specificationFromMessageDTO = createDTO(PACS_002_ERROR_WRONG_REASON_CODE);
        ReceiptEventEntity receiptEventEntity = new ReceiptEventEntity();
        receiptEventEntity.setTransactionEntity(new ReceiptEntity());
        TransactionEvent transactionEvent = new ReceiptEvent(receiptEventEntity);

        when(mockTransactionRejectReasonRepository.findById(INVALID_REJECTION_CODE))
            .thenReturn(Optional.ofNullable(null));

        ReflectionTestUtils.setField(transactionEvent, "transactionRejectReasonRepository", mockTransactionRejectReasonRepository);

        transactionEvent.verifyReasonCode(specificationFromMessageDTO);

        assertThat(transactionEvent.getTransaction().getTransactRejectionReasonCode())
            .isEqualTo(INVALID_REJECTION_CODE);

        assertThat(transactionEvent.getEventEntity().getRejectionReasonDescription())
            .isNull();
    }

    @Test
    void shouldNotStoreReasonDescriptionWhenReasonCodeIsEmpty() {

        EventSpecificationFromReceivedMessageDTO specificationFromMessageDTO = createDTO(PACS_002_SPI_DOCUMENT);
        ReceiptEventEntity receiptEventEntity = new ReceiptEventEntity();
        receiptEventEntity.setTransactionEntity(new ReceiptEntity());
        TransactionEvent transactionEvent = new ReceiptEvent(receiptEventEntity);

        transactionEvent.verifyReasonCode(specificationFromMessageDTO);

        assertThat(transactionEvent.getTransaction().getTransactRejectionReasonCode())
            .isNull();

        assertThat(transactionEvent.getEventEntity().getRejectionReasonDescription())
            .isNull();
    }

    @Test
	@DisplayName("when taking an action for reply of a transaction event should set the clearingTimestampUTC from event")
	void shouldTakeAnActionForReply() {
		EventSpecificationFromReceivedMessageDTO specificationFromMessageDTO = createDTO(PACS_002_SPI_DOCUMENT);
		ReceiptEventEntity receiptEventEntity = new ReceiptEventEntity();
		TransactionEvent event = new ReceiptEvent(receiptEventEntity);

		assertThat(receiptEventEntity.getClearingTimestampUTC()).isNull();
		event.actionsForReplyMessage(specificationFromMessageDTO);

		assertThat(receiptEventEntity.getClearingTimestampUTC()).isEqualTo("2020-02-14T14:52:04.674");
	}

	@Test
	@DisplayName("when not found DtTm at specific element node should fill with LocalDateTimeNow")
	void shouldFillWithLocalDateTimeNowUtcWhenNotFoundDtTmAtSpecificElementNode() {
		EventSpecificationFromReceivedMessageDTO specificationFromMessageDTO = createDTO(PACS_002_PSP_CREDOR_DOCUMENT);
		ReceiptEventEntity receiptEventEntity = new ReceiptEventEntity();
		TransactionEvent event = new ReceiptEvent(receiptEventEntity);

		assertThat(receiptEventEntity.getClearingTimestampUTC()).isNull();
		event.actionsForReplyMessage(specificationFromMessageDTO);

		assertThat(receiptEventEntity.getClearingTimestampUTC()).isCloseToUtcNow(within(1, ChronoUnit.SECONDS));

	}

	private EventSpecificationFromReceivedMessageDTO createDTO(Document document) {

		NodeList nodeList = DocumentUtils.getElementsByExpression(document, PACS_002_REPLY_ELEMENT);
		Node currentNode = nodeList.item(0);

		return EventSpecificationFromReceivedMessageDTO
				.builder()
				.messageEntity(mock(MessageEntity.class))
				.document(document)
				.specificElement(currentNode)
				.build();
	}

}
