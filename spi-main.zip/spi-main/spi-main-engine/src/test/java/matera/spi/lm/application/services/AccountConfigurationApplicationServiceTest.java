package matera.spi.lm.application.services;

import matera.spi.dto.ManagerialBalanceThresholdDTO;
import matera.spi.dto.ManagerialTransactionTypeDTO;
import matera.spi.dto.MirrorBalanceThresholdDTO;
import matera.spi.dto.MirrorTransactionTypeDTO;
import matera.spi.dto.PspManagerialAccountConfigUIDTO;
import matera.spi.dto.PspMirrorAccountConfigUIDTO;
import matera.spi.lm.application.service.AccountConfigurationApplicationService;
import matera.spi.lm.application.service.AccountConfigurationValidator;
import matera.spi.lm.exception.LiquidityManagementException;
import matera.spi.main.apisInterface.ConfigurationApiService;
import matera.spi.main.apisInterface.IpAccountConfigurationApiService;
import matera.spi.main.apisInterface.ParticipantMipApiService;
import matera.spi.main.domain.model.ConfigEntity;
import matera.spi.main.domain.model.IpAccountConfigEntity;
import matera.spi.main.domain.model.ParticipantMipEntity;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class AccountConfigurationApplicationServiceTest {

    @InjectMocks
    private AccountConfigurationApplicationService accountConfigurationService;

    @Mock
    private IpAccountConfigurationApiService ipAccountConfigurationService;

    @Mock
    private ConfigurationApiService configurationService;

    @Mock
    private ParticipantMipApiService participantMipApiService;

    @Spy
    private AccountConfigurationValidator accountConfigurationValidatorMock;

    @Captor
    private ArgumentCaptor<IpAccountConfigEntity> configEntityArgumentCaptor;

    @Captor
    private ArgumentCaptor<ParticipantMipEntity> participantMipEntityArgumentCaptor;

    private PspMirrorAccountConfigUIDTO expectedMirrorConfigurationDTO = buildExpectedPspMirrorAccountConfigDTO();
    private PspManagerialAccountConfigUIDTO expectedManagerialConfigurationDTO = buildExpectedPspManagerialAccountConfigDTO();


    @BeforeEach
    void init() {
        mockIpAccountConfigurationServiceResponses();
    }

    @Test
    void shouldGetPspMirrorAccountConfigDTO() {
        final PspMirrorAccountConfigUIDTO actualDTO =
            accountConfigurationService.getMirrorIpAccountConfiguration();
        Assertions.assertEquals(expectedMirrorConfigurationDTO, actualDTO);
    }

    @Test
    void shouldUpdatePspMirrorAccountConfigDTO() {
        PspMirrorAccountConfigUIDTO dto = buildExpectedPspMirrorAccountConfigDTO();

        accountConfigurationService.saveMirrorAccountConfig(dto);

        verify(ipAccountConfigurationService).save(configEntityArgumentCaptor.capture());

        IpAccountConfigEntity configEntityUpdated = configEntityArgumentCaptor.getValue();
        assertThat(configEntityUpdated.getBranch()).isEqualTo(dto.getBranch());
        assertThat(configEntityUpdated.getAccountNumber()).isEqualTo(new BigDecimal(dto.getAccount()));

        assertThat(configEntityUpdated.getDebitTransactionType()).isEqualTo(dto.getTransactionType().getDebitPayment());
        assertThat(configEntityUpdated.getCreditTransactionType()).isEqualTo(dto.getTransactionType().getStandardCreditReceipt());
        assertThat(configEntityUpdated.getDrawbackReceiveTransactType()).isEqualTo(dto.getTransactionType().getDrawbackReceived());
        assertThat(configEntityUpdated.getDrawbackSentTransactType()).isEqualTo(dto.getTransactionType().getDrawbackSent());
        assertThat(configEntityUpdated.getQrcodeCredTransactionType()).isEqualTo(dto.getTransactionType().getCreditByDynamicQRCode());
        assertThat(configEntityUpdated.getDepositTransactionType()).isEqualTo(dto.getTransactionType().getDeposit());
        assertThat(configEntityUpdated.getWithdrawTransactionType()).isEqualTo(dto.getTransactionType().getWithdraw());
        assertThat(configEntityUpdated.getBalanceAdjustmentDebit()).isEqualTo(dto.getTransactionType().getBalanceAdjustmentDebit());
        assertThat(configEntityUpdated.getBalanceAdjustmentCredit()).isEqualTo(dto.getTransactionType().getBalanceAdjustmentCredit());
        assertThat(configEntityUpdated.getAutoDepositTransactionType()).isEqualTo(dto.getTransactionType().getAutoDepositLPI0006());

        assertThat(configEntityUpdated.isBalanceValidationThreshold()).isEqualTo(dto.getBalanceThreshold().getValidatesBalanceMirrorAccount());
        assertThat(configEntityUpdated.getBalanceUpperThreshold()).isEqualTo(dto.getBalanceThreshold().getUpperLimitAutoDeposit());
        assertThat(configEntityUpdated.getBalanceUpperThresholdPercent()).isEqualTo(dto.getBalanceThreshold().getPercentOnUpperBalanceLimit());
        assertThat(configEntityUpdated.getBalanceLowerThreshold()).isEqualTo(dto.getBalanceThreshold().getLowerLimitValidateBalance());
        assertThat(configEntityUpdated.getBalanceLowerThresholdPercent()).isEqualTo(dto.getBalanceThreshold().getPercentOnLowerBalanceLimit());
    }

    @Test
    void shouldGetPspManagerialAccountConfigDTO() {
        mockConfigurationServiceResponses();
        mockParticipantMipServiceResponse();

        final PspManagerialAccountConfigUIDTO actualDTO =
            accountConfigurationService.getManagerialIpAccountConfiguration();
        Assertions.assertEquals(expectedManagerialConfigurationDTO, actualDTO);
    }

    @Test
    void shouldUpdatePspManagerialAccountConfigDTO() {
        mockConfigurationServiceResponses();
        mockParticipantMipServiceResponse();

        PspManagerialAccountConfigUIDTO dto = buildExpectedPspManagerialAccountConfigDTO();

        accountConfigurationService.saveManagerialAccountConfig(dto);

        verify(participantMipApiService).save(participantMipEntityArgumentCaptor.capture());

        ParticipantMipEntity participantUpdated = participantMipEntityArgumentCaptor.getValue();
        assertThat(participantUpdated.getBranch()).isEqualTo(dto.getBranch());
        assertThat(participantUpdated.getAccountNumber()).isEqualTo(dto.getAccount());

        assertThat(participantUpdated.getDebTransactionType()).isEqualTo(dto.getTransactionType().getDebitPayment());
        assertThat(participantUpdated.getCredTransactionType()).isEqualTo(dto.getTransactionType().getStandardCreditReceipt());
        assertThat(participantUpdated.getDrawbackReceiveTransactType()).isEqualTo(dto.getTransactionType().getDevolutionReceived());
        assertThat(participantUpdated.getDrawbackSentTransactType()).isEqualTo(dto.getTransactionType().getDevolutionSent());
        assertThat(participantUpdated.getQrcodeCredTransactionType()).isEqualTo(dto.getTransactionType().getCreditByDynamicQRCode());

        assertThat(participantUpdated.isBalanceValidationThreshold()).isEqualTo(dto.getBalanceThreshold().getValidatesBalanceManagerialDirectAccount());
        assertThat(participantUpdated.getBalanceLowerThreshold()).isEqualTo(dto.getBalanceThreshold().getLowerLimitValidateBalance());
    }

    @ParameterizedTest
    @ValueSource(strings = { "1.00", "1,00", "string", "123s2s3", "123456789012345678901" })
    void shouldThrowLiquidityExceptionWithSpiLm032WhenAccountNumberIsInvalid(String account) {
        PspManagerialAccountConfigUIDTO dto = buildExpectedPspManagerialAccountConfigDTO();
        dto.setAccount(account);
        dto.getBalanceThreshold().setLowerLimitValidateBalance(new BigDecimal(99999));

        LiquidityManagementException exception = Assertions
            .assertThrows(LiquidityManagementException.class,
                () -> accountConfigurationValidatorMock.validatesManagerialAccountConfig(dto));

        Assertions.assertEquals("SPI-LM-033", exception.getCode());
    }

    @ParameterizedTest
    @ValueSource(strings = { "1", "12345678", "12345678901234567890" })
    void shouldNotThrowLiquidityExceptionWithSpiLm032WhenAccountNumberIsValid(String account) {
        PspManagerialAccountConfigUIDTO dto = buildExpectedPspManagerialAccountConfigDTO();
        dto.setAccount(account);
        dto.getBalanceThreshold().setLowerLimitValidateBalance(new BigDecimal(99999));

        Assertions.assertDoesNotThrow(() -> accountConfigurationValidatorMock.validatesManagerialAccountConfig(dto));
    }

    private PspManagerialAccountConfigUIDTO buildExpectedPspManagerialAccountConfigDTO() {
        final PspManagerialAccountConfigUIDTO dto = new PspManagerialAccountConfigUIDTO();
        dto.setEnable(true);
        dto.setAccount("1");
        dto.setBranch(11);
        dto.setBalanceThreshold(buildManagerialBalanceThresholdDTO());
        dto.setTransactionType(buildManagerialTransactionTypeDTO());

        return dto;
    }

    private ManagerialTransactionTypeDTO buildManagerialTransactionTypeDTO() {
        final ManagerialTransactionTypeDTO dto = new ManagerialTransactionTypeDTO();
        dto.setDebitPayment(8888);
        dto.setStandardCreditReceipt(9999);
        dto.setDevolutionReceived(1010);
        dto.setDevolutionSent(1111);
        dto.setCreditByDynamicQRCode(1212);

        return dto;
    }

    private ManagerialBalanceThresholdDTO buildManagerialBalanceThresholdDTO() {
        final ManagerialBalanceThresholdDTO dto = new ManagerialBalanceThresholdDTO();
        dto.setValidatesBalanceManagerialDirectAccount(true);
        dto.setLowerLimitValidateBalance(BigDecimal.valueOf(120));

        return dto;
    }

    private PspMirrorAccountConfigUIDTO buildExpectedPspMirrorAccountConfigDTO() {
        final PspMirrorAccountConfigUIDTO dto = new PspMirrorAccountConfigUIDTO();
        dto.setAccount("123");
        dto.setBranch(11);
        dto.setTransactionType(buildMockedMirrorTransactionTypeDTO());
        dto.setBalanceThreshold(buildMockedMirrorBalanceThreshold());
        return dto;
    }

    private MirrorBalanceThresholdDTO buildMockedMirrorBalanceThreshold() {
        final MirrorBalanceThresholdDTO dto = new MirrorBalanceThresholdDTO();
        dto.setValidatesBalanceMirrorAccount(true);
        dto.setUpperLimitAutoDeposit(BigDecimal.valueOf(150));
        dto.setPercentOnUpperBalanceLimit(BigDecimal.valueOf(0.75));
        dto.setLowerLimitValidateBalance(BigDecimal.valueOf(200));
        dto.setPercentOnLowerBalanceLimit(BigDecimal.valueOf(0.25));

        return dto;
    }

    private MirrorTransactionTypeDTO buildMockedMirrorTransactionTypeDTO() {
        final MirrorTransactionTypeDTO dto = new MirrorTransactionTypeDTO();
        dto.setDebitPayment(1);
        dto.setStandardCreditReceipt(2);
        dto.setCreditByDynamicQRCode(3);
        dto.setDrawbackReceived(4);
        dto.setDrawbackSent(5);
        dto.setDeposit(6);
        dto.setWithdraw(7);
        dto.setAutoDepositLPI0006(8);
        dto.setBalanceAdjustmentCredit(9);
        dto.setBalanceAdjustmentDebit(10);

        return dto;
    }

    private Optional<IpAccountConfigEntity> createMockedIpAccountConfigEntity() {
        final IpAccountConfigEntity ipAccountConfigEntity = new IpAccountConfigEntity();
        ipAccountConfigEntity.setAccountNumber(BigDecimal.valueOf(123));
        ipAccountConfigEntity.setBranch(11);
        ipAccountConfigEntity.setDebitTransactionType(1);
        ipAccountConfigEntity.setCreditTransactionType(2);
        ipAccountConfigEntity.setQrcodeCredTransactionType(3);
        ipAccountConfigEntity.setDrawbackReceiveTransactType(4);
        ipAccountConfigEntity.setDrawbackSentTransactType(5);
        ipAccountConfigEntity.setDepositTransactionType(6);
        ipAccountConfigEntity.setWithdrawTransactionType(7);
        ipAccountConfigEntity.setAutoDepositTransactionType(8);
        ipAccountConfigEntity.setBalanceAdjustmentCredit(9);
        ipAccountConfigEntity.setBalanceAdjustmentDebit(10);
        ipAccountConfigEntity.setBalanceValidationThreshold(true);
        ipAccountConfigEntity.setBalanceUpperThreshold(BigDecimal.valueOf(150));
        ipAccountConfigEntity.setBalanceUpperThresholdPercent(BigDecimal.valueOf(0.75));
        ipAccountConfigEntity.setBalanceLowerThreshold(BigDecimal.valueOf(200));
        ipAccountConfigEntity.setBalanceLowerThresholdPercent(BigDecimal.valueOf(0.25));
        return Optional.of(ipAccountConfigEntity);
    }

    private void mockParticipantMipServiceResponse() {
        final Optional<ParticipantMipEntity> mockedParticipantMipEntity = createMockedParticipantMipEntity();
        doReturn(mockedParticipantMipEntity).when(participantMipApiService).findByIspb(anyInt());
    }

    private Optional<ParticipantMipEntity> createMockedParticipantMipEntity() {
        final ParticipantMipEntity participantMipEntity = new ParticipantMipEntity();
        participantMipEntity.setManagerialAccountEnabled(true);
        participantMipEntity.setAccountNumber(BigDecimal.ONE);
        participantMipEntity.setBranch(11);
        participantMipEntity.setDebTransactionType(1111);
        participantMipEntity.setCredTransactionType(2222);
        participantMipEntity.setDrawbackReceiveTransactType(3333);
        participantMipEntity.setDrawbackSentTransactType(4444);
        participantMipEntity.setQrcodeCredTransactionType(5555);
        participantMipEntity.setWithdrawTransactionType(6666);
        participantMipEntity.setDepositTransactionType(7777);
        participantMipEntity.setDebTransactionType(8888);
        participantMipEntity.setCredTransactionType(9999);
        participantMipEntity.setDrawbackReceiveTransactType(1010);
        participantMipEntity.setDrawbackSentTransactType(1111);
        participantMipEntity.setQrcodeCredTransactionType(1212);
        participantMipEntity.setBalanceValidationThreshold(true);
        participantMipEntity.setBalanceLowerThreshold(BigDecimal.valueOf(120));

        return Optional.of(participantMipEntity);
    }

    private void mockConfigurationServiceResponses() {
        final ConfigEntity configEntity = createMockedConfigEntity();
        doReturn(configEntity).when(configurationService).findConfig();
    }

    private ConfigEntity createMockedConfigEntity() {
        final ConfigEntity configEntity = new ConfigEntity();
        configEntity.setIspb(123);
        configEntity.setCustomerDebTransactionType(1);
        configEntity.setCustomerCredTransactionType(2);
        configEntity.setCustDrawbReceivedTransType(3);
        configEntity.setCustDrawbSentTransType(4);
        configEntity.setQrcodeCredTransactionType(5);

        return configEntity;
    }

    private void mockIpAccountConfigurationServiceResponses() {
        final Optional<IpAccountConfigEntity> mockedIpAccountConfigEntity = createMockedIpAccountConfigEntity();
        lenient().doReturn(mockedIpAccountConfigEntity).when(ipAccountConfigurationService).findConfig();
    }

}
