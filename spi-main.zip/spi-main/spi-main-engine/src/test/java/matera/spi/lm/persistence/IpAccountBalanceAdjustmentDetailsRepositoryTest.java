package matera.spi.lm.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.lm.domain.model.enums.EnumMessageType;
import matera.spi.lm.domain.model.event.IpAccountBalanceAdjustmentDetailsEntity;
import matera.spi.lm.domain.model.event.IpAccountBalanceAdjustmentEventEntity;
import matera.spi.lm.domain.model.event.MessageType;
import matera.spi.main.domain.model.enums.EnumTransactionType;
import matera.spi.main.domain.model.event.EventStatusEntity;
import matera.spi.main.domain.model.event.EventTypeEntity;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.EventStatusRepository;
import matera.spi.main.persistence.EventTypeRepository;
import matera.spi.utils.BigDecimalUtils;
import matera.spi.utils.LocalDateTimeUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@IntegrationTest
public class IpAccountBalanceAdjustmentDetailsRepositoryTest {

    private static final Sort SORT = Sort.by(Sort.Direction.DESC, "event.initiationTimestampUTC");

    @Autowired
    private IpAccountBalanceAdjustmentDetailsRepository balanceAdjustmentRepository;

    @Autowired
    private EventStatusRepository eventStatusRepository;

    @Autowired
    private EventTypeRepository eventTypeRepository;

    @Autowired
    private EventRepository eventRepository;

    @AfterEach
    void cleanDatabase() {
        balanceAdjustmentRepository.deleteAll();
    }

    @Test
    void shouldInsertInRepositoryWhenValidRequestIsSent() {
        final IpAccountBalanceAdjustmentDetailsEntity expected = createBalanceAdjustmentDetails();
        balanceAdjustmentRepository.saveAndFlush(expected);

        final IpAccountBalanceAdjustmentDetailsEntity actual =
            balanceAdjustmentRepository.findById(expected.getUuid()).orElse(null);
        assertThat(actual).isNotNull();
        assertThat(actual.getControlNumberSTR()).isEqualTo(expected.getControlNumberSTR());
        assertThat(BigDecimalUtils.compareIf(expected.getValue()).isEqualTo(actual.getValue())).isTrue();
        assertThat(actual.getMessageType().getTransactionType()).isEqualTo(expected.getMessageType().getTransactionType());
        assertThat(actual.getMessageType().getMessageType()).isEqualTo(expected.getMessageType().getMessageType());
        assertThat(actual.getTransactionTimestamp()).isEqualTo(expected.getTransactionTimestamp());
    }

    @Test
    void shouldFindWithoutFilterParameters() {
        final IpAccountBalanceAdjustmentDetailsEntity expected = createBalanceAdjustmentDetails();
        balanceAdjustmentRepository.saveAndFlush(expected);

        PageRequest pageable = PageRequest.of(0, 10, SORT);
        Page<IpAccountBalanceAdjustmentDetailsEntity> result =
            balanceAdjustmentRepository.findByParameters(pageable, null, null,null,
                null, null, null, null, null);

        assertThat(result.getContent()).hasSize(1);

        IpAccountBalanceAdjustmentDetailsEntity actual = result.getContent().get(0);
        assertDetails(expected, actual);
    }

    @Test
    void shouldFindWithFilterParameterStartTimestampUtc() {
        final IpAccountBalanceAdjustmentDetailsEntity expected = createBalanceAdjustmentDetails();
        balanceAdjustmentRepository.saveAndFlush(expected);

        PageRequest pageable = PageRequest.of(0, 10, SORT);
        Page<IpAccountBalanceAdjustmentDetailsEntity> result =
            balanceAdjustmentRepository.findByParameters(pageable,
                LocalDateTimeUtils.getUtcLocalDateTime().minusDays(1),
                null,null, null, null, null, null, null);

        assertThat(result.getContent()).hasSize(1);

        IpAccountBalanceAdjustmentDetailsEntity actual = result.getContent().get(0);
        assertDetails(expected, actual);
    }

    @Test
    void shouldFindWithFilterParameterStartTimestampUtcAndEndTimestampUtc() {
        final IpAccountBalanceAdjustmentDetailsEntity expected = createBalanceAdjustmentDetails();
        balanceAdjustmentRepository.saveAndFlush(expected);

        PageRequest pageable = PageRequest.of(0, 10, SORT);
        Page<IpAccountBalanceAdjustmentDetailsEntity> result =
            balanceAdjustmentRepository.findByParameters(pageable,
                LocalDateTimeUtils.getUtcLocalDateTime().minusDays(1),
                LocalDateTimeUtils.getUtcLocalDateTime().plusDays(1),
                null, null, null, null, null, null);

        assertThat(result.getContent()).hasSize(1);

        IpAccountBalanceAdjustmentDetailsEntity actual = result.getContent().get(0);
        assertDetails(expected, actual);
    }

    @Test
    void shouldFindWithFilterParameterEventId() {
        final IpAccountBalanceAdjustmentDetailsEntity expected = createBalanceAdjustmentDetails();
        balanceAdjustmentRepository.saveAndFlush(expected);

        PageRequest pageable = PageRequest.of(0, 10, SORT);
        Page<IpAccountBalanceAdjustmentDetailsEntity> result =
            balanceAdjustmentRepository.findByParameters(pageable, null, null,
                expected.getEvent().getId(),
                null, null, null, null, null);

        assertThat(result.getContent()).hasSize(1);

        IpAccountBalanceAdjustmentDetailsEntity actual = result.getContent().get(0);
        assertDetails(expected, actual);
    }

    @Test
    void shouldFindWithFilterParameterMessageType() {
        final IpAccountBalanceAdjustmentDetailsEntity expected = createBalanceAdjustmentDetails();
        balanceAdjustmentRepository.saveAndFlush(expected);

        PageRequest pageable = PageRequest.of(0, 10, SORT);
        Page<IpAccountBalanceAdjustmentDetailsEntity> result =
            balanceAdjustmentRepository.findByParameters(pageable, null, null, null,
                expected.getMessageType().getMessageType().getCode(),
                null, null, null, null);

        assertThat(result.getContent()).hasSize(1);

        IpAccountBalanceAdjustmentDetailsEntity actual = result.getContent().get(0);
        assertDetails(expected, actual);
    }

    @Test
    void shouldFindWithFilterParameterTransactionType() {
        final IpAccountBalanceAdjustmentDetailsEntity expected = createBalanceAdjustmentDetails();
        balanceAdjustmentRepository.saveAndFlush(expected);

        PageRequest pageable = PageRequest.of(0, 10, SORT);
        Page<IpAccountBalanceAdjustmentDetailsEntity> result =
            balanceAdjustmentRepository.findByParameters(pageable, null, null, null,
                null,
                expected.getMessageType().getTransactionType().getType(),
                null, null, null);

        assertThat(result.getContent()).hasSize(1);

        IpAccountBalanceAdjustmentDetailsEntity actual = result.getContent().get(0);
        assertDetails(expected, actual);
    }

    @Test
    void shouldFindWithFilterParameterEndToEndId() {
        final IpAccountBalanceAdjustmentDetailsEntity expected = createBalanceAdjustmentDetails();
        balanceAdjustmentRepository.saveAndFlush(expected);

        PageRequest pageable = PageRequest.of(0, 10, SORT);
        Page<IpAccountBalanceAdjustmentDetailsEntity> result =
            balanceAdjustmentRepository.findByParameters(pageable, null, null, null,
                null, null,
                expected.getControlNumberSTR(),
                null, null);

        assertThat(result.getContent()).hasSize(1);

        IpAccountBalanceAdjustmentDetailsEntity actual = result.getContent().get(0);
        assertDetails(expected, actual);
    }

    @Test
    void shouldFindWithControlNumberSTRAndFilterParameterEndToEndIdNull() {
        final IpAccountBalanceAdjustmentDetailsEntity expected = createBalanceAdjustmentDetails();
        expected.setControlNumberSTR(null);
        balanceAdjustmentRepository.saveAndFlush(expected);

        PageRequest pageable = PageRequest.of(0, 10, SORT);
        Page<IpAccountBalanceAdjustmentDetailsEntity> result =
            balanceAdjustmentRepository.findByParameters(pageable,
                LocalDateTimeUtils.getUtcLocalDateTime().minusDays(1),
                LocalDateTimeUtils.getUtcLocalDateTime().plusDays(1),
                expected.getEvent().getId(),
                expected.getMessageType().getMessageType().getCode(),
                expected.getMessageType().getTransactionType().getType(),
                null,
                BigDecimal.valueOf(9), BigDecimal.valueOf(20));

        assertThat(result.getContent()).hasSize(1);

        IpAccountBalanceAdjustmentDetailsEntity actual = result.getContent().get(0);
        assertDetails(expected, actual);
    }

    @Test
    void shouldNotFindWithFilterParameterValueOutOfRange() {
        final IpAccountBalanceAdjustmentDetailsEntity expected = createBalanceAdjustmentDetails();
        balanceAdjustmentRepository.saveAndFlush(expected);

        PageRequest pageable = PageRequest.of(0, 10, SORT);
        Page<IpAccountBalanceAdjustmentDetailsEntity> result =
            balanceAdjustmentRepository.findByParameters(pageable, null, null, null,
                null, null, null,
                BigDecimal.valueOf(11), BigDecimal.valueOf(20));

        assertThat(result.getContent()).isEmpty();
    }

    @Test
    void shouldNotFindWithFilterParameterStartTimestampUtcAndEndTimestampUtc() {
        final IpAccountBalanceAdjustmentDetailsEntity expected = createBalanceAdjustmentDetails();
        balanceAdjustmentRepository.saveAndFlush(expected);

        PageRequest pageable = PageRequest.of(0, 10, SORT);
        Page<IpAccountBalanceAdjustmentDetailsEntity> result =
            balanceAdjustmentRepository.findByParameters(pageable,
                LocalDateTimeUtils.getUtcLocalDateTime().plusDays(1),
                LocalDateTimeUtils.getUtcLocalDateTime().plusDays(2),
                null, null, null, null, null, null);

        assertThat(result.getContent()).isEmpty();
    }

    private void assertDetails(IpAccountBalanceAdjustmentDetailsEntity expected, IpAccountBalanceAdjustmentDetailsEntity actual) {
        assertThat(actual.getControlNumberSTR()).isEqualTo(expected.getControlNumberSTR());
        assertThat(BigDecimalUtils.compareIf(expected.getValue()).isEqualTo(actual.getValue())).isTrue();
        assertThat(actual.getMessageType()).isEqualTo(expected.getMessageType());
        assertThat(actual.getTransactionTimestamp()).isEqualTo(expected.getTransactionTimestamp());
        assertThat(actual.getEvent().getEventType()).isEqualTo(expected.getEvent().getEventType());
    }

    private IpAccountBalanceAdjustmentDetailsEntity createBalanceAdjustmentDetails() {
        IpAccountBalanceAdjustmentEventEntity ipAccountBalanceAdjustmentEventEntity = new IpAccountBalanceAdjustmentEventEntity();

        ipAccountBalanceAdjustmentEventEntity.setCorrelationId("E00539039202002170828063aec68f6e");
        ipAccountBalanceAdjustmentEventEntity.setClearingTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
        ipAccountBalanceAdjustmentEventEntity.setInitiationTimestampUTC(LocalDateTimeUtils.getUtcLocalDateTime());
        ipAccountBalanceAdjustmentEventEntity.setResponsible(UUID.randomUUID().toString());
        ipAccountBalanceAdjustmentEventEntity.setInitiatorIspb(12345);
        ipAccountBalanceAdjustmentEventEntity.setValue(BigDecimal.TEN);

        EventStatusEntity eventStatusEntity = eventStatusRepository.findByDescription("Query sent").orElseThrow();
        ipAccountBalanceAdjustmentEventEntity.setStatus(eventStatusEntity);

        EventTypeEntity eventTypeEntity = eventTypeRepository.findByDescription("Ip Account Balance Adjustment").orElseThrow();
        ipAccountBalanceAdjustmentEventEntity.setEventTypeEntity(eventTypeEntity);

        final IpAccountBalanceAdjustmentDetailsEntity entity = new IpAccountBalanceAdjustmentDetailsEntity();
        entity.setControlNumberSTR("MIP202006061423547");
        entity.setValue(BigDecimal.TEN);
        entity.setMessageType(buildMessageType());
        entity.setTransactionTimestamp(LocalDateTime.of(2020,6,6,15,30,30));
        entity.setEvent(ipAccountBalanceAdjustmentEventEntity);

        ipAccountBalanceAdjustmentEventEntity.setIpAccountBalanceAdjustmentDetailsEntity(entity);
        eventRepository.saveAndFlush(ipAccountBalanceAdjustmentEventEntity);

        return entity;
    }

    private MessageType buildMessageType() {
        return new MessageType(EnumTransactionType.CREDIT, EnumMessageType.PACS_004);
    }

}
