package matera.spi.main.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.transaction.PaymentEntity;
import matera.spi.main.domain.model.transaction.ReceiptEntity;
import matera.spi.main.domain.model.transaction.TransactionType;
import matera.spi.main.utils.PaymentTransactionUtils;
import matera.spi.main.utils.ReceiptTransactionUtils;
import matera.spi.main.utils.constants.EventConstants;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@IntegrationTest
@Transactional
public class ReceiptRepositoryTest  {

    private static final Integer INTEGER_ONE = 1;

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private AccountTypeRepository accountTypeRepository;

    @Autowired
    private PaymentTransactionUtils paymentTransactionUtils;

    @Autowired
    private ReceiptTransactionUtils receiptTransactionUtils;

    @Autowired
    private ReceiptRepository receiptRepository;

    @Test
    void shouldBeFindEntityWhenInserted() {
        final ReceiptEntity expected = receiptTransactionUtils.newReceiptEntity(new BigDecimal("120"), EventConstants.EVENT_STATUS_RECEIPT_RECEIVED);
        receiptRepository.saveAndFlush(expected);

        final ReceiptEntity actual = receiptRepository.findById(expected.getId()).orElse(null);
        Assertions.assertEquals(TransactionType.RECEIPT,  actual.getTransactionType());
        Assertions.assertEquals(expected.getId(),  actual.getId());
        Assertions.assertEquals(expected.getAdditionalInformation(),  actual.getAdditionalInformation());
        Assertions.assertEquals(expected.getEndToEndId(),  actual.getEndToEndId());
        Assertions.assertEquals(expected.getInitiatingInstitutionTaxId(),  actual.getInitiatingInstitutionTaxId());
        Assertions.assertEquals(expected.getPayerParticipant(),  actual.getPayerParticipant());
        Assertions.assertEquals(expected.getReceiverParticipant(),  actual.getReceiverParticipant());
        Assertions.assertEquals(expected.getPayerAccount(),  actual.getPayerAccount());
        Assertions.assertEquals(expected.getReceiverAccount(),  actual.getReceiverAccount());
        Assertions.assertEquals(expected.getPriority(),  actual.getPriority());
        Assertions.assertEquals(expected.getReceiverReconIdentifier(),  actual.getReceiverReconIdentifier());
    }

    @Test
    void shouldReturnJustReceiptTransactionsWhenAlsoHasReceiptTransactionsStoredInDB() {
        final PaymentEntity paymentEntity = paymentTransactionUtils.newPaymentEntity(new BigDecimal("120.00"), EventConstants.EVENT_STATUS_SUCCESS);
        paymentRepository.saveAndFlush(paymentEntity);

        final ReceiptEntity receiptEntity = receiptTransactionUtils.newReceiptEntity(new BigDecimal("120"), EventConstants.EVENT_STATUS_RECEIPT_RECEIVED);
        receiptRepository.saveAndFlush(receiptEntity);

        final List<ReceiptEntity> receiptEntities = receiptRepository.findAll();
        Assertions.assertEquals(INTEGER_ONE, receiptEntities.size());
    }
}
