package matera.spi.main.domain.service.pacs.pacs002;

import com.matera.client.rest.exception.RestBadRequestException;
import com.matera.spi.messaging.api.MessagesApi;
import com.matera.spi.messaging.api.SPIMessagingApis;
import com.matera.spi.messaging.model.MessageSentResponseDTO;
import com.matera.spi.messaging.model.MessageSpecificationDTO;

import com.matera.spi.webhook.transaction.model.TransactionIdValidationResponseDTO;
import matera.spi.commons.IntegrationTest;
import matera.spi.dto.AccountTypeDTO;
import matera.spi.main.domain.model.enums.TransactionStatus;
import matera.spi.main.domain.model.event.transaction.ReceiptEventEntity;
import matera.spi.main.domain.model.transaction.ReceiptEntity;
import matera.spi.main.domain.service.CorrelationIdGenerator;
import matera.spi.main.domain.service.MessageSender;
import matera.spi.main.domain.service.ReceiptEventValidator;
import matera.spi.main.domain.service.TransactionRejectReasonStandinService;
import matera.spi.main.domain.service.WebhookTransactionValidationService;
import matera.spi.main.domain.service.event.receiver.MessageReceiver;
import matera.spi.main.domain.service.event.transaction.validation.DirectPSPCreditEventValidator;
import matera.spi.main.domain.service.pacs.pacs002.dto.ContentPacs002;
import matera.spi.main.domain.service.transaction.CustomerAccount;
import matera.spi.main.exception.EventValidatorException;
import matera.spi.main.utils.EntityCreationUtils;
import matera.spi.utils.DocumentUtils;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.annotation.Transactional;
import org.w3c.dom.Document;

import javax.validation.constraints.NotNull;

import static matera.spi.main.domain.model.enums.TransactionStatus.RJCT;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasXPath;
import static org.hamcrest.Matchers.not;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

@IntegrationTest
@Transactional
class MessageRejectPacs002Test  {

    private static final String ISPB = "12345678";

    private static final String RIGHT_BRANCH = "1";
    private static final String RIGHT_ACCOUNT = "35";
    private static final String RIGHT_ACCOUN_TYPE = AccountTypeDTO.CACC.toString();
    private static final String RIGHT_TAXID = "31953073832";

    private static final String INCORRECT_BRANCH = "7";
    private static final String INCORRECT_ACCOUNT = "33";
    private static final String INCORRECT_ACCOUN_TYPE = AccountTypeDTO.SLRY.toString();
    private static final String INCORRECT_TAXID = "11707205795";

    private static final String CREDIT_ON_ACCOUNT_NOT_VALIDATED_CODE = "ED05";
    private static final String CREDIT_ON_ACCOUNT_NOT_VALIDATED_DESCRIPTION = "Settlement of the transaction has failed";

    private ReceiptEntity receiptEntity = EntityCreationUtils.buildReceiptEntity();

    @Autowired
    private ReceiptEventValidator receiptEventValidator;
    @Autowired
    private TransactionRejectReasonStandinService transactionRejectReasonStandinService;
    @Mock
    private TransactionRejectReasonStandinService mockedTransactionRejectReasonStandinService;
    @Autowired
    private CustomerAccount customerAccount;
    @Mock
    private CustomerAccount mockedCustomerAccount;

    @Autowired
    private MessageSender messageSender;
    @Autowired
    private SPIMessagingApis spiMessagingApisBean;
    @Mock
    private SPIMessagingApis mockedSpiMessagingApis;
    @Mock
    private MessagesApi mockedMessagesApi;
    @Captor
    private ArgumentCaptor<MessageSpecificationDTO> messageSpecificationDTOArgumentCaptor;

    @InjectMocks
    private MessageSendPacs002 messageSendPacs002;

    @Autowired
    private MessageReceiver messageReceiver;

    @Mock
    private WebhookTransactionValidationService mockWebhookTransactionValidationService;
    @Autowired
    private WebhookTransactionValidationService webhookTransactionValidationService;

    @Autowired
    private DirectPSPCreditEventValidator directPSPCreditEventValidator;

    @BeforeEach
    void setUp() {

        when(mockedSpiMessagingApis.messagesApi()).thenReturn(mockedMessagesApi);
        messageSender.setSpiMessagingApis(mockedSpiMessagingApis);

        ReflectionTestUtils.setField(directPSPCreditEventValidator, "transactionRejectReasonStandinService", mockedTransactionRejectReasonStandinService);
        ReflectionTestUtils.setField(directPSPCreditEventValidator, "customerAccount", mockedCustomerAccount);

        ReflectionTestUtils.setField(receiptEventValidator, "webhookTransactionValidationService", mockWebhookTransactionValidationService);

        when(mockWebhookTransactionValidationService.queryValidator(any(), any())).thenReturn(new TransactionIdValidationResponseDTO().shouldReceive(true).motive("Web hook rejection."));
    }

    @AfterEach
    void tearDown() {
        messageSender.setSpiMessagingApis(spiMessagingApisBean);

        ReflectionTestUtils.setField(directPSPCreditEventValidator, "transactionRejectReasonStandinService", transactionRejectReasonStandinService);
        ReflectionTestUtils.setField(directPSPCreditEventValidator, "customerAccount", customerAccount);
        ReflectionTestUtils.setField(receiptEventValidator, "webhookTransactionValidationService", webhookTransactionValidationService);
    }

    @Test
    void shouldACSPPacs002() {
        when(mockedCustomerAccount.validateCredit((ReceiptEventEntity) receiptEntity.getEvent())).thenReturn(true);
        Document xmlDocument = sendMessageAndReturnDocumet(RIGHT_BRANCH, RIGHT_ACCOUNT, RIGHT_ACCOUN_TYPE, RIGHT_TAXID);
        assertThat(xmlDocument, hasXPath("/Envelope/Document/FIToFIPmtStsRpt/TxInfAndSts/TxSts[.=\"ACSP\"]"));
        containsTagCdAndAddtlInf(TransactionStatus.ACSP, xmlDocument);

    }
    @Test
    void shouldRJCTBranchPacs002() throws EventValidatorException {
        doThrow(RestBadRequestException.class).when(mockedCustomerAccount).validateCredit((ReceiptEventEntity) any());
        doThrow(new EventValidatorException(CREDIT_ON_ACCOUNT_NOT_VALIDATED_CODE,CREDIT_ON_ACCOUNT_NOT_VALIDATED_DESCRIPTION)).when(
            mockedTransactionRejectReasonStandinService).transactionRejectReasonToRejectReasonStandin(any(),any());
        Document xmlDocument = sendMessageAndReturnDocumet(INCORRECT_BRANCH, RIGHT_ACCOUNT, RIGHT_ACCOUN_TYPE, RIGHT_TAXID);
        assertThat(xmlDocument, hasXPath("/Envelope/Document/FIToFIPmtStsRpt/TxInfAndSts/TxSts[.=\"RJCT\"]"));
        containsTagCdAndAddtlInf(TransactionStatus.RJCT, xmlDocument);
    }

    @Test
    void shouldRJCTAccountPacs002() throws EventValidatorException {
        doThrow(RestBadRequestException.class).when(mockedCustomerAccount).validateCredit((ReceiptEventEntity) any());
        doThrow(new EventValidatorException(CREDIT_ON_ACCOUNT_NOT_VALIDATED_CODE,CREDIT_ON_ACCOUNT_NOT_VALIDATED_DESCRIPTION)).when(
            mockedTransactionRejectReasonStandinService).transactionRejectReasonToRejectReasonStandin(any(),any());
        Document xmlDocument = sendMessageAndReturnDocumet(RIGHT_BRANCH, INCORRECT_ACCOUNT, RIGHT_ACCOUN_TYPE, RIGHT_TAXID);
        assertThat(xmlDocument, hasXPath("/Envelope/Document/FIToFIPmtStsRpt/TxInfAndSts/TxSts[.=\"RJCT\"]"));
        containsTagCdAndAddtlInf(TransactionStatus.RJCT, xmlDocument);
    }

    @Test
    void shouldRJCTAccountTypePacs002()  throws EventValidatorException {
        doThrow(RestBadRequestException.class).when(mockedCustomerAccount).validateCredit((ReceiptEventEntity) any());
        doThrow(new EventValidatorException(CREDIT_ON_ACCOUNT_NOT_VALIDATED_CODE,CREDIT_ON_ACCOUNT_NOT_VALIDATED_DESCRIPTION)).when(
            mockedTransactionRejectReasonStandinService).transactionRejectReasonToRejectReasonStandin(any(),any());
        Document xmlDocument = sendMessageAndReturnDocumet(RIGHT_BRANCH, RIGHT_ACCOUNT, INCORRECT_ACCOUN_TYPE, RIGHT_TAXID);
        assertThat(xmlDocument, hasXPath("/Envelope/Document/FIToFIPmtStsRpt/TxInfAndSts/TxSts[.=\"RJCT\"]"));
        containsTagCdAndAddtlInf(TransactionStatus.RJCT, xmlDocument);
    }

    @Test
    void shouldRJCTTaxIdPacs002() throws EventValidatorException {
        doThrow(RestBadRequestException.class).when(mockedCustomerAccount).validateCredit((ReceiptEventEntity) any());
        doThrow(new EventValidatorException(CREDIT_ON_ACCOUNT_NOT_VALIDATED_CODE,CREDIT_ON_ACCOUNT_NOT_VALIDATED_DESCRIPTION)).when(
            mockedTransactionRejectReasonStandinService).transactionRejectReasonToRejectReasonStandin(any(),any());
        Document xmlDocument = sendMessageAndReturnDocumet(RIGHT_BRANCH, RIGHT_ACCOUNT, RIGHT_ACCOUN_TYPE, INCORRECT_TAXID);
        assertThat(xmlDocument, hasXPath("/Envelope/Document/FIToFIPmtStsRpt/TxInfAndSts/TxSts[.=\"RJCT\"]"));
        containsTagCdAndAddtlInf(TransactionStatus.RJCT, xmlDocument);
    }

    private String buildPac008(String branch, String account, String accountType, String taxId) {
        String expectedPiResourceId = new String("ResourceId-"+Math.random());
        return "{\"piResourceId\": \"" + expectedPiResourceId + "\",\"xml\": \"<?xml version= \\\"1.0\\\" encoding= \\\"UTF-8\\\" standalone= \\\"no\\\" ?><Envelope xmlns= \\\"pacs.008.spi.1.2.xsd\\\"><AppHdr><Fr><FIId><FinInstnId><Othr><Id>00038166</Id></Othr></FinInstnId></FIId></Fr><To><FIId><FinInstnId><Othr><Id>13370835</Id></Othr></FinInstnId></FIId></To><BizMsgIdr>M005737687cd679d901c941d0aad880a</BizMsgIdr><MsgDefIdr>pacs.008.spi.1.2</MsgDefIdr><CreDt>2020-04-01T11:28:05.801Z</CreDt><Sgntr></Sgntr></AppHdr><Document><FIToFICstmrCdtTrf><GrpHdr><MsgId>M005737687cd679d901c941d0aad880a</MsgId><CreDtTm>2020-04-01T11:28:05.801Z</CreDtTm><NbOfTxs>10</NbOfTxs><SttlmInf><SttlmMtd>CLRG</SttlmMtd></SttlmInf><PmtTpInf><InstrPrty>HIGH</InstrPrty></PmtTpInf></GrpHdr><CdtTrfTxInf><PmtId><EndToEndId>" + CorrelationIdGenerator
            .generateCorrelactionIdPacs008(ISPB) + "</EndToEndId><TxId>12555487</TxId></PmtId><IntrBkSttlmAmt Ccy= \\\"BRL\\\">4256018.82</IntrBkSttlmAmt><AccptncDtTm>2020-04-01T11:28:05.801Z</AccptncDtTm><ChrgBr>SLEV</ChrgBr><Dbtr><Id><PrvtId><Othr><Id>97399508041</Id></Othr></PrvtId></Id></Dbtr><DbtrAcct><Id><Othr><Id>6722035</Id><Issr>6097</Issr></Othr></Id><Tp><Cd>CACC</Cd></Tp></DbtrAcct><DbtrAgt><FinInstnId><ClrSysMmbId><MmbId>60394079</MmbId></ClrSysMmbId></FinInstnId></DbtrAgt><CdtrAgt><FinInstnId><ClrSysMmbId><MmbId>13370835</MmbId></ClrSysMmbId></FinInstnId></CdtrAgt><Cdtr><Id><PrvtId><Othr><Id>" + taxId + "</Id></Othr></PrvtId></Id></Cdtr><CdtrAcct><Id><Othr><Id>" + account + "</Id><Issr>" + branch + "</Issr></Othr></Id><Tp><Cd>" + accountType + "</Cd></Tp></CdtrAcct><RmtInf><Ustrd>campo livre</Ustrd></RmtInf></CdtTrfTxInf></FIToFICstmrCdtTrf></Document></Envelope>\"}";
    }

    @Test
    void shouldThrowNullPointerException() {
        Assertions.assertThrows(NullPointerException.class, () -> messageSendPacs002.send(ContentPacs002.builder().build()));
    }

    private Document sendMessageAndReturnDocumet(String rightBranch, String rightAccount, String rightAccounType, String rightTaxid) {
        MessageSentResponseDTO dtoResponse = new MessageSentResponseDTO();
        dtoResponse.setPiResourceID("ResourceId-" + Math.random());
        Mockito.when(mockedMessagesApi.sendsMessageV1(any())).thenReturn(dtoResponse);
        messageReceiver.readIncomingMessage(buildPac008(rightBranch, rightAccount, rightAccounType, rightTaxid));
        Mockito.verify(mockedMessagesApi).sendsMessageV1(messageSpecificationDTOArgumentCaptor.capture());
        MessageSpecificationDTO messageSpecificationDTO = messageSpecificationDTOArgumentCaptor.getValue();
        @NotNull String xml = messageSpecificationDTO.getMessageContent();
        return DocumentUtils.stringToXmlDocument(xml);
    }

    private void containsTagCdAndAddtlInf(TransactionStatus status, Document xmlDocument){
        if(status.equals(RJCT)){
            assertThat(xmlDocument, hasXPath("/Envelope/Document/FIToFIPmtStsRpt/TxInfAndSts/StsRsnInf/Rsn/Cd"));
            assertThat(xmlDocument, hasXPath("/Envelope/Document/FIToFIPmtStsRpt/TxInfAndSts/StsRsnInf/AddtlInf"));
        }else{
            assertThat(xmlDocument, not(hasXPath("/Envelope/Document/FIToFIPmtStsRpt/TxInfAndSts/StsRsnInf/Rsn/Cd")));
            assertThat(xmlDocument, not(hasXPath("/Envelope/Document/FIToFIPmtStsRpt/TxInfAndSts/StsRsnInf/AddtlInf")));
        }
    }

}
