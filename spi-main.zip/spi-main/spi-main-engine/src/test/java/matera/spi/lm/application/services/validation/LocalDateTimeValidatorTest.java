package matera.spi.lm.application.services.validation;

import matera.spi.lm.application.service.validation.LocalDateTimeValidation.LocalDateTimeValidator;
import matera.spi.lm.exception.LiquidityManagementException;
import matera.spi.utils.LocalDateTimeUtils;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import java.time.LocalDate;
import java.time.LocalDateTime;

import static matera.spi.lm.application.service.validation.LocalDateTimeValidation.LocalDateTimeValidator.DAY;
import static matera.spi.lm.application.service.validation.LocalDateTimeValidation.LocalDateTimeValidator.MINUTES;

public class LocalDateTimeValidatorTest {

    @Spy
    private LocalDateTimeValidator localDateTimeValidator;

    @BeforeEach
    void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void shouldThrowExceptionWhenStartTimeStampIsGreaterThenEndTimestamp() {
        final LocalDateTime startTimestamp = LocalDateTime.of(2020, 1, 1, 1, 3);
        final LocalDateTime endTimestamp = LocalDateTime.of(2020, 1, 1, 1, 0);
        Assertions.assertThrows(LiquidityManagementException.class,
            () -> localDateTimeValidator.validatePeriodBetween(startTimestamp, endTimestamp));
    }

    @Test
    public void shouldThrowExceptionWhenStartTimestampNull() {
        final LocalDateTime endTimestamp = LocalDateTime.of(2020, 1, 1, 1, 0);
        Assertions.assertThrows(LiquidityManagementException.class,
            () -> localDateTimeValidator.validatePeriodBetween(null, endTimestamp));
    }

    @Test
    public void shouldThrowExceptionWhenEndTimestampNull() {
        final LocalDateTime startTimestamp = LocalDateTime.of(2020, 1, 1, 1, 3);
        Assertions.assertThrows(LiquidityManagementException.class,
            () -> localDateTimeValidator.validatePeriodBetween(startTimestamp, null));
    }

    @Test
    public void shouldThrowExceptionWhenReferenteDate1IsAfterThanReferenceDate2() {
        final LocalDate referenceDate = LocalDateTimeUtils.getTodayUTC().plusDays(1);
        Assertions.assertThrows(LiquidityManagementException.class,
            () -> localDateTimeValidator.validateCanNotBeFutureDate(referenceDate, LocalDateTimeUtils.getTodayUTC()));
    }

    @Test
    public void shouldThrowExceptionWhenDifferenceBetweenDatesIsMoreThenExpected() {
        Assertions.assertThrows(LiquidityManagementException.class, () -> localDateTimeValidator
            .validateDiffBetweenDates(LocalDateTimeUtils.getUtcLocalDateTime(),
                LocalDateTimeUtils.getUtcLocalDateTime().plusDays(2), DAY));
    }

}
