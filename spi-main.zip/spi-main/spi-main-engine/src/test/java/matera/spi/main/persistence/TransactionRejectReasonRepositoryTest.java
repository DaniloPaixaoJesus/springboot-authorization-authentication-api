package matera.spi.main.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.transaction.TransactionRejectReasonEntity;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.opentest4j.AssertionFailedError;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.jupiter.api.Assertions.assertEquals;

@IntegrationTest
class TransactionRejectReasonRepositoryTest   {

    @Autowired
    private TransactionRejectReasonRepository repository;

    @Test
    void shouldBeFindEntityWhenInserted() {
        TransactionRejectReasonEntity expected = new TransactionRejectReasonEntity();
        expected.setCode("abcd");
        expected.setDescription("Reason rejection description");
        expected.setName("Reason Name of rejection");

        repository.saveAndFlush(expected);

        TransactionRejectReasonEntity actual = repository.findById(expected.getCode()).orElse(null);
        Assertions.assertEquals(expected, actual);
    }

    @DisplayName("Verifying if the ME_TRANSACTION_REJECT_REASON default values are added correctly")
    @ParameterizedTest(name = "code: {0} | name: {1} | description: {2}")
    @CsvFileSource(resources = "/parameterized/csv/TransactionRejectReasonRepositoryTest-default-values.csv", numLinesToSkip = 1, delimiter = ';')
    void shouldEventTypeDefaultValuesBeAdded(String code, String name, String description) {
        TransactionRejectReasonEntity transactionRejectReason = repository.findById(code)
                .orElseThrow(() -> new AssertionFailedError("not found TransactionRejectReasonEntity with id: " + code));;
        assertEquals(code, transactionRejectReason.getCode());
        assertEquals(name, transactionRejectReason.getName());
        assertEquals(description, transactionRejectReason.getDescription());
    }


}
