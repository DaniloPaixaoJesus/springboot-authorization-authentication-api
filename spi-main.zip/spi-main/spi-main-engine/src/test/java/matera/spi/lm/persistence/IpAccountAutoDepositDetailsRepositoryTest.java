package matera.spi.lm.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.lm.domain.model.IpAccountAutoDepositDetailsEntity;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasSize;

@IntegrationTest
class IpAccountAutoDepositDetailsRepositoryTest {

    @Autowired
    private IpAccountAutoDepositDetailsRepository repository;

    @AfterEach
    void afterEach() {
        repository.deleteAll();
    }

    @Test
    void testInsertEntity() {
        IpAccountAutoDepositDetailsEntity ipAccountAutoDepositDetailsEntity = createEntity();

        repository.saveAndFlush(ipAccountAutoDepositDetailsEntity);

        List<IpAccountAutoDepositDetailsEntity> all = repository.findAll();
        assertThat(all, hasSize(1));
    }

    @NotNull
    private IpAccountAutoDepositDetailsEntity createEntity() {
        IpAccountAutoDepositDetailsEntity ipAccountAutoDepositDetailsEntity = new IpAccountAutoDepositDetailsEntity();
        ipAccountAutoDepositDetailsEntity.setReceivers("email1@domain.com");
        ipAccountAutoDepositDetailsEntity.setSituation("1");
        ipAccountAutoDepositDetailsEntity.setTransactionTimestampUtc(LocalDateTime.now());
        return ipAccountAutoDepositDetailsEntity;
    }

}
