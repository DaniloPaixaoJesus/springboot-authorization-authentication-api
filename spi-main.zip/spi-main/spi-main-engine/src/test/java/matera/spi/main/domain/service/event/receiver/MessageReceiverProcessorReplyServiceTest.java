package matera.spi.main.domain.service.event.receiver;

import matera.spi.main.domain.model.event.EventTypeEntity;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.domain.service.event.Event;
import matera.spi.main.domain.service.event.EventFactory;
import matera.spi.main.domain.service.util.MessageBinderXpathReda016Utils;
import matera.spi.utils.DocumentUtils;
import matera.spi.main.dto.MessageReceiverEventDTO;
import matera.spi.main.dto.event.EventSpecificationFromReceivedMessageDTO;
import matera.spi.main.exception.DuplicateMessageException;
import matera.spi.main.utils.EntityCreationUtils;

import org.assertj.core.api.Assertions;
import org.assertj.core.api.SoftAssertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import static matera.spi.main.utils.FileUtils.getDocumentFromXmlFile;
import static matera.spi.mainengine.utils.Asserts.assertThat;
import static matera.spi.utils.DocumentUtils.stringToXmlDocument;
import static matera.spi.main.utils.EntityCreationUtils.PACS_002_REPLY_ELEMENT;
import static matera.spi.main.utils.EntityCreationUtils.buildPacs008MessageEntity;
import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class MessageReceiverProcessorReplyServiceTest {

	private static final String PACS_002_SPI_1_2_SPI_10_MSG = "pacs.002/pacs.002.spi.1.2_SPI_10_msg.xml";
	private static final Document PACS_002_DOCUMENT = stringToXmlDocument(getStringFromXmlFile(PACS_002_SPI_1_2_SPI_10_MSG));
	private static final String CAMT_053_SALDO_MOMENTO_MSG = "camt.053/camt.053_SALDO_MOMENTO_msg.xml";
	private static final Document CAMT_053_SALDO_MOMENTO_DOCUMENT = stringToXmlDocument(getStringFromXmlFile(CAMT_053_SALDO_MOMENTO_MSG));
	private static final int TEN = 10;

	@InjectMocks
	private MessageReceiverProcessorReplyService messageReceiverReplyService;

	@Mock
	private MessageElementNodeProcessorService messageElementNodeProcessorService;

	@Mock
	private EventFactory eventFactory;

	@Test
	@DisplayName("when message entity does not have reply element and message type doesn't have original event type should thrown IllegalStateException")
	void shouldThrownIllegalStateExceptionWhenDoesNotHaveOriginalEventType() {
		MessageEntity messageEntity = buildPacs008MessageEntity();
		messageEntity.getMessageTypeEntity().setCorrelationIdElement("");
		MessageReceiverEventDTO dto = MessageReceiverEventDTO.builder()
				.messageDocument(mock(Document.class))
				.messageEntity(messageEntity)
				.build();
		assertThatThrownBy(() -> messageReceiverReplyService.processEvent(dto))
				.isInstanceOf(IllegalStateException.class)
				.hasMessage("Not found original event type for %s", messageEntity.getMessageTypeEntity());
	}

	@DisplayName("when processing a pacs.002 replied message with ten elements should process the ten nodes")
    @ParameterizedTest
    @MethodSource("getValueFromIntegerList")
	void shouldProcessTheTenElementsNodesWhenADocumentWithTenElementsWasProvided(List<Integer> value) {
        MessageReceiverEventDTO messageReceiverEventDTO =
            createMessageReceiverEventDTO(EntityCreationUtils.buildPacs002MessageEntity(), PACS_002_DOCUMENT, value);
		messageReceiverReplyService.processEvent(messageReceiverEventDTO);

		NodeList nodeList = DocumentUtils.getElementsByExpression(PACS_002_DOCUMENT, PACS_002_REPLY_ELEMENT);
		List<EventSpecificationFromReceivedMessageDTO> possibleEventSpecDTOs = IntStream.range(0, 10).mapToObj(nodeList::item)
				.map(node -> new EventSpecificationFromReceivedMessageDTO(messageReceiverEventDTO, node)).collect(Collectors.toList());
		verify(messageElementNodeProcessorService, times(TEN))
				.processElementNodeFromReplyMessage(argThat(possibleEventSpecDTOs::contains));
	}

    @DisplayName("when processing a pacs.002 replied message with specific elements should process the specific nodes")
    @Test
    void shouldProcessTheSpecificElementsNodesWhenADocumentWithSpecificElementsWasProvided() {
        List<Integer> indexes = List.of(2, 4, 9);
        MessageReceiverEventDTO messageReceiverEventDTO =
            createMessageReceiverEventDTO(EntityCreationUtils.buildPacs002MessageEntity(), PACS_002_DOCUMENT, indexes);
        messageReceiverReplyService.processEvent(messageReceiverEventDTO);

        NodeList nodeList = DocumentUtils.getElementsByExpression(PACS_002_DOCUMENT, PACS_002_REPLY_ELEMENT);
        List<EventSpecificationFromReceivedMessageDTO> possibleEventSpecDTOs = indexes.stream().map(nodeList::item)
            .map(node -> new EventSpecificationFromReceivedMessageDTO(messageReceiverEventDTO, node)).collect(Collectors.toList());
        verify(messageElementNodeProcessorService, times(3))
            .processElementNodeFromReplyMessage(argThat(possibleEventSpecDTOs::contains));
    }

	@Test
    @Disabled("MOVE TO TEST MESSAGE RECEIVER PROCESSOR")
	@DisplayName("when processElementNodeFromReplyMessage throws DuplicatedMessageException should ignore it")
	void shouldIgnoreDuplicatedMessageExceptionThrownByProcessElementNodeFromReplyMessage() {
		MessageReceiverEventDTO messageReceiverEventDTO = MessageReceiverEventDTO.builder()
				.messageEntity(EntityCreationUtils.buildPacs002MessageEntity())
				.messageDocument(PACS_002_DOCUMENT)
				.build();

		doThrow(DuplicateMessageException.class)
				.when(messageElementNodeProcessorService)
				.processElementNodeFromReplyMessage(any());

		assertDoesNotThrow(() -> messageReceiverReplyService.processEvent(messageReceiverEventDTO));

		NodeList nodeList = DocumentUtils.getElementsByExpression(PACS_002_DOCUMENT, PACS_002_REPLY_ELEMENT);
		List<EventSpecificationFromReceivedMessageDTO> possibleEventSpecDTOs = IntStream.range(0, 10).mapToObj(nodeList::item)
				.map(node -> new EventSpecificationFromReceivedMessageDTO(messageReceiverEventDTO, node)).collect(Collectors.toList());
		verify(messageElementNodeProcessorService, times(TEN))
				.processElementNodeFromReplyMessage(argThat(possibleEventSpecDTOs::contains));
	}

	@DisplayName("when message entity does not have correlation id or reply element should process the message")
    @ParameterizedTest
    @MethodSource("getValueFromIntegerList")
	void shouldProcessMessagesThatNotHaveCorrelationIdAndReplyElement(List<Integer> value) {
		MessageEntity camt053 = EntityCreationUtils.buildCamt053MessageEntity();
        MessageReceiverEventDTO messageReceiverEventDTO =
            createMessageReceiverEventDTO(camt053, CAMT_053_SALDO_MOMENTO_DOCUMENT, value);

		EventTypeEntity originalEventType = camt053.getMessageTypeEntity().getOriginalEventType();

		Event eventMock = mock(Event.class);
		when(eventFactory.findFirstOriginalEventWithoutReply(same(originalEventType)))
				.thenReturn(eventMock);

		messageReceiverReplyService.processEvent(messageReceiverEventDTO);

		verifyNoInteractions(messageElementNodeProcessorService);
		verify(eventFactory).findFirstOriginalEventWithoutReply(same(originalEventType));

		verify(eventMock).receiveReplyMessage(new EventSpecificationFromReceivedMessageDTO(messageReceiverEventDTO));
	}

    @Test
    @DisplayName("when processing a reda.016 replied message should get the reply element node")
    void shouldProcessReda016Message() {
        Document reda016 = getDocumentFromXmlFile("reda.016/reda.016_sucesso_msg.xml");

        MessageEntity messageEntity = EntityCreationUtils.buildReda016MessageEntity();
        MessageReceiverEventDTO messageReceiverEventDTO = MessageReceiverEventDTO.builder()
            .messageEntity(messageEntity)
            .messageDocument(reda016)
            .build();
        messageReceiverReplyService.processEvent(messageReceiverEventDTO);

        String reda016ReplyElementXpath = messageEntity.getMessageTypeEntity().getReplyElement();

        Node expectedReplyElementNode =  DocumentUtils
            .getElementsByExpression(reda016, reda016ReplyElementXpath).item(0);

        EventSpecificationFromReceivedMessageDTO expectedDTO =
            new EventSpecificationFromReceivedMessageDTO(messageReceiverEventDTO, expectedReplyElementNode);

        verify(messageElementNodeProcessorService).processElementNodeFromReplyMessage(expectedDTO);
    }

    private MessageReceiverEventDTO createMessageReceiverEventDTO(MessageEntity messageEntity, Document messageDocument,
                                                                  List<Integer> consumableMessageIndexes) {
        return MessageReceiverEventDTO.builder()
            .messageEntity(messageEntity)
            .messageDocument(messageDocument)
            .consumableMessageIndexes(consumableMessageIndexes)
            .build();
    }

    private static Stream<Arguments> getValueFromIntegerList() {
        return Stream.of(Arguments.of(List.of(0,1,2,3,4,5,6,7,8,9)), Arguments.of(List.of()), null);
    }
}
