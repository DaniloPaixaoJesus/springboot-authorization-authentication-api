package matera.spi.indirect.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.indirect.domain.model.ParticipantMipIndirectStatusEntity;
import matera.spi.indirect.domain.model.enums.IndirectParticipantStatusEnum;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;

@IntegrationTest
@Transactional
class ParticipantMipIndirectStatusRepositoryTest {

    private static final String THE_ENUM_ITEM_S_WAS_NOT_FOUND_IN_DATABASE =
        "The Enum item %s was not found in database";
    private static final String THE_STATUS_ENTITY_S_WAS_NOT_FOUND_IN_ENUM =
        "The status entity %s was not found in Enum";

    @Autowired
    private ParticipantMipIndirectStatusRepository participantMipIndirectStatusRepository;

    @Test
    void shouldEnumBeSynchronizedWithTheDatabase() {
        final List<ParticipantMipIndirectStatusEntity> allStatus = participantMipIndirectStatusRepository.findAll();

        Arrays.stream(IndirectParticipantStatusEnum.values()).forEach(enumItem -> {
            assertTrue(allStatus.stream().anyMatch(statusEntity -> statusEntity.getId().equals(enumItem.getId())),
                String.format(THE_ENUM_ITEM_S_WAS_NOT_FOUND_IN_DATABASE, enumItem.name()));
        });

        allStatus.stream().forEach(statusEntity -> {
            assertTrue(Arrays.stream(IndirectParticipantStatusEnum.values())
                    .anyMatch(enumItem -> enumItem.getId().equals(statusEntity.getId())),
                String.format(THE_STATUS_ENTITY_S_WAS_NOT_FOUND_IN_ENUM, statusEntity.getStatus()));
        });
    }

}
