package matera.spi.main.utils;

import lombok.SneakyThrows;
import org.springframework.core.io.Resource;

import javax.xml.XMLConstants;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import java.io.StringReader;

public class XmlValidator {

    public static final String APPHDR_ELEMENT_STRING = "<xs:element name=\"AppHdr\" type=\"SPI.head.001.001.01\"/>";

    private XmlValidator() {}

    @SneakyThrows
    public static void validateWithXSD(String xmlMessage, Resource xsdResource) {

        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);

        String xsd = FileUtils.resourceAsString(xsdResource);

        xsd = xsd.replace(APPHDR_ELEMENT_STRING, "");

        Schema schema = sf.newSchema(new StreamSource(new StringReader(xsd)));
        Validator validator = schema.newValidator();
        Source source = new StreamSource(new StringReader(xmlMessage));
        validator.validate(source);
    }
}
