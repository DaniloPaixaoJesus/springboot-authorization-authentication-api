package matera.spi.indirect.application.service.mapper;

import matera.spi.dto.IndirectParticipantDTO;
import matera.spi.dto.IndirectParticipantStatusDTO;
import matera.spi.indirect.domain.model.ParticipantMipIndirectEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectStatusEntity;
import matera.spi.indirect.domain.model.enums.IndirectParticipantStatusEnum;
import matera.spi.indirect.persistence.ParticipantMipIndirectStatusRepository;
import matera.spi.indirect.util.ParticipantMipIndirectDataSetUtil;
import matera.spi.main.domain.model.ParticipantMipEntity;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doReturn;

@ExtendWith(MockitoExtension.class)
class ParticipantMipIndirectMapperTest {

    @Mock
    private ParticipantMipIndirectStatusRepository participantMipIndirectStatusRepository;

    @Test
    void shouldMapEntityToDTO() {
        doReturn(Optional.of(ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectStatusEntity()))
            .when(participantMipIndirectStatusRepository).findById(Mockito.any());

        final ParticipantMipEntity participantMip = ParticipantMipIndirectDataSetUtil.createParticipantMip();
        final ParticipantMipIndirectEntity entity = ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository, participantMip);
        final IndirectParticipantDTO dto = ParticipantMipIndirectMapper.mapEntityToIndirectParticipantDTO(entity);

        assertEquals(participantMip.getIspb(), dto.getIspb());
        assertEquals(entity.getName(), dto.getName());
        assertEquals(entity.getCorporateName(), dto.getCorporateName());
        assertEquals(extractStatusAsEnum(entity.getStatus()), dto.getStatus());
        assertEquals(String.valueOf(entity.getTaxId()), dto.getTaxId());
        assertEquals(entity.getContractInitDate(), dto.getContractInitDate());
        assertEquals(entity.getContractEndDate(), dto.getContractEndDate());
        assertEquals(String.valueOf(participantMip.getBranch()), dto.getBranch());
        assertEquals(String.valueOf(participantMip.getAccountNumber()), dto.getAccountNumber());
        assertNotNull(dto.getContacts());
        assertNotNull(dto.getFinancial());

        //Consider including a lib of tests for static methods, similar to PowerMock.
    }

    private IndirectParticipantStatusDTO extractStatusAsEnum(ParticipantMipIndirectStatusEntity status) {
        return IndirectParticipantStatusDTO.fromValue(IndirectParticipantStatusEnum.getEnumById(status.getId()).name());
    }

    @Test
    void shouldThrowExceptionsWhenArgumentIsNull() {
        final NullPointerException nullPointerException = assertThrows(NullPointerException.class,
            () -> ParticipantMipIndirectMapper.mapEntityToIndirectParticipantDTO(null));

        assertEquals(ParticipantMipIndirectMapper.THE_PARTICIPANT_MIP_INDIRECT_ENTITY_PARAMETER_IS_REQUIRED,
            nullPointerException.getMessage());
    }

}
