package matera.spi.lm.application.services;

import matera.spi.lm.application.service.balanceIPAccountService.IndirectBalanceIPAccountService;
import matera.spi.lm.exception.IndirectParticipantOperationInvalidException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;

@ExtendWith(MockitoExtension.class)
public class IndirectBalanceIPAccountServiceTest {

    @Spy
    private IndirectBalanceIPAccountService indirectBalanceIPAccountService;

    @Test
    void shouldThrowExceptionWhenRequestDeposit() {
        Assertions.assertThrows(IndirectParticipantOperationInvalidException.class,
            () -> indirectBalanceIPAccountService.requestDeposit(any()));
    }

    @Test
    void shouldThrowExceptionWhenRequestWithdraw() {
        Assertions.assertThrows(IndirectParticipantOperationInvalidException.class,
            () -> indirectBalanceIPAccountService.requestWithdraw(any()));
    }

    @Test
    void shouldThrowExceptionWhenRequestbalanceIPAccount() {
        Assertions.assertThrows(IndirectParticipantOperationInvalidException.class,
            () -> indirectBalanceIPAccountService.requestBalanceIPAccount(any()));
    }

    @Test
    void shouldThrowExceptionWhenGetBalanceAccountIP() {
        Assertions.assertThrows(IndirectParticipantOperationInvalidException.class,
            () -> indirectBalanceIPAccountService.getBalanceAccountIP());
    }

    @Test
    void shouldThrowExceptionWhenGetPageableBalanceAccountIP() {
        Assertions.assertThrows(IndirectParticipantOperationInvalidException.class, () -> indirectBalanceIPAccountService
            .getIPAccountBalance(any(LocalDateTime.class), any(LocalDateTime.class), anyInt(), anyInt(), anyString()));
    }

    @Test
    void shouldThrowExceptionWhenGetOutstandingBalanceAccountIP() {
        Assertions.assertThrows(IndirectParticipantOperationInvalidException.class,
            () -> indirectBalanceIPAccountService.getOutstandingBalanceQuery(anyString()));
    }

}
