package matera.spi.lm.domain.service.extractor.message;

import matera.spi.lm.dto.Lpi0006ExtractMessageDTO;

import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static matera.spi.utils.DocumentUtils.stringToXmlDocument;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.comparesEqualTo;
import static org.hamcrest.core.Is.is;

class Lpi0006MessageExtractorTest {

    private static final String LPI_0006_MSG = "lpi0006/lpi0006_EXAMPLE_SUCCESS.xml";
    private static final Document LPI_0006_DOCUMENT = stringToXmlDocument(getStringFromXmlFile(LPI_0006_MSG));

    @Test
    void extractValues() {
        Lpi0006MessageExtractor instance = Lpi0006MessageExtractor.getInstance();
        Lpi0006ExtractMessageDTO lpi0006ExtractMessageDTO = instance.extractValues(LPI_0006_DOCUMENT);

        LocalDate expectedDtMovto = LocalDate.of(2020, 4, 27);
        LocalDateTime expectedDtHrSit = LocalDateTime.of(2020, 4, 27, 7, 30, 20);

        assertThat(lpi0006ExtractMessageDTO.getCodMsg(), is("LPI0006"));
        assertThat(lpi0006ExtractMessageDTO.getIspbPspi(), is("12345678"));
        assertThat(lpi0006ExtractMessageDTO.getNumCtrlStr(), is("STR20111010000065983"));
        assertThat(lpi0006ExtractMessageDTO.getTpCtBc(), is("RL"));
        assertThat(lpi0006ExtractMessageDTO.getPercSldCcme(), comparesEqualTo(BigDecimal.valueOf(15.45)));
        assertThat(lpi0006ExtractMessageDTO.getVlrLanc(), comparesEqualTo(BigDecimal.valueOf(1500)));
        assertThat(lpi0006ExtractMessageDTO.getSitLancStr(), is("7"));
        assertThat(lpi0006ExtractMessageDTO.getDtHrSit(), is(expectedDtHrSit));
        assertThat(lpi0006ExtractMessageDTO.getDtMovto(), is(expectedDtMovto));
    }

}
