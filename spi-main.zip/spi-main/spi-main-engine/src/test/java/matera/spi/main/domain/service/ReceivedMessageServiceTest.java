package matera.spi.main.domain.service;

import matera.spi.main.domain.model.ConfigEntity;
import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.domain.model.account.AccountTypeEntity;
import matera.spi.main.domain.model.account.PayerAccountEntity;
import matera.spi.main.domain.model.account.ReceiverAccountEntity;
import matera.spi.main.domain.model.event.transaction.ReceiptEventEntity;
import matera.spi.main.domain.model.transaction.ReceiptEntity;
import matera.spi.main.domain.model.transaction.TransactionPriorityEntity;
import matera.spi.main.exception.IllegalProcessException;
import matera.spi.main.exception.InvalidIspbException;
import matera.spi.utils.DocumentUtils;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;

import static org.assertj.core.api.Assertions.assertThatThrownBy;

@ExtendWith(MockitoExtension.class)
class ReceivedMessageServiceTest {

    private static final String PACS_008_SPI_1_4_END_1_MSG = "pacs.008/pacs.008.spi.1.4_END_1_msg.xml";
    private static final String EXPRESSION_CDT_TRF_TX_INF = "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf";
    private static final String END_TO_END_ID = "E008921002020021708289943624de78";
    private static final String CACC_CODE = "CACC";
    private static final String CACC_DESCRIPTION = "FOO CACC";
    private static final String SVGS_CODE = "SVGS";
    private static final String SVGS_DESCRIPTION = "FOO SVGS";
    private static final Integer ISPB_PAYER = 13370835;
    private static final String ISPB_NAME_PAYER = "FOO ISPB";
    private static final Integer ISPB_RECEIVER = 250699;
    private static final String ISPB_NAME_RECEIVER = "FOO ISPB";
    private static final String TRANSACTION_CODE = "HIGH";
    private static final String TRANSACTION_DESCRIPTION = "FOO HIGH";
    private static final String ADDITIONAL_INFORMATION = "Campo livre [0]";
    private static final String CHARGE_BEARER = "SLEV";
    private static final String ACCOUNT_PAYER = "7668710";
    private static final String BRANCH_PAYER = "4072";
    private static final String TAX_ID_PAYER = "95234889211";
    private static final String ACCOUNT_RECEIVER = "52031188285";
    private static final String BRANCH_RECEIVER = "8395";
    private static final String TAX_ID_RECEIVER = "48303675922";
    private static final String KEY_RECEIVER = "idContaTransacional0@bc.com.br";
    private static final BigDecimal VALUE = new BigDecimal("980644.93");
    private static final String SETTLEMENT_METHOD = "CLRG";
    private static final String PATTERN_TIME_STAMP_UTC = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
    private static final String CREATION_DATE_TIME = "2020-01-01T08:30:00.000Z";
    private static final LocalDateTime CREATION_DATE_TIME_IN_LOCAL_DATE_TIME = getLocalDateTime();
    private static final String SOME_PAYER_NAME = "Fulano da Silva";
    private static final String RECEIVER_RECON_IDENTIFIER = "90000";

    private static Document documentPacs008;
    private static Node nodeCdtTrfTxInf;
    private static final ReceiptEventEntity receiptEventEntity = new ReceiptEventEntity();

    @Mock
    private ParticipantService participantService;

    @Mock
    private AccountTypeService accountTypeService;

    @Mock
    private TransactionPriorityService transactionPriorityService;

    @Mock
    private ConfigurationService configurationService;

    @InjectMocks
    private ReceivedMessageService receivedMessageService;

    @BeforeAll
    static void beforeAll() {
        String xmlPacs008 = getStringFromXmlFile(PACS_008_SPI_1_4_END_1_MSG);
        documentPacs008 = DocumentUtils.stringToXmlDocument(xmlPacs008);
        nodeCdtTrfTxInf = getNodeCdtTrfTxInf(documentPacs008);
        receiptEventEntity.setCorrelationId(END_TO_END_ID);
    }

    @BeforeEach
    void setUp() {
        ConfigEntity configEntity = new ConfigEntity();
        configEntity.setIspb(ISPB_RECEIVER);
        Mockito.when(configurationService.findConfig()).thenReturn(configEntity);
    }

    @Test
    void shouldFillAllAttributed() {
        Mockito.when(participantService.findByIspb(ISPB_PAYER)).thenReturn(Optional.of(payerParticipantEntityMock()));
        Mockito.when(participantService.findByIspb(ISPB_RECEIVER)).thenReturn(Optional.of(receiverParticipantEntityMock()));
        Mockito.when(transactionPriorityService.getPriorityByCode(TRANSACTION_CODE)).thenReturn(transactionPriorityEntityMock());

        receivedMessageService.fillAllAttributed(receiptEventEntity, documentPacs008, nodeCdtTrfTxInf);

        Assertions.assertNotNull(receiptEventEntity);
        Assertions.assertNotNull(receiptEventEntity.getReceiptEntity());

        ReceiptEntity receiptEntity = receiptEventEntity.getReceiptEntity();

        assertionReceiptEvent(receiptEventEntity, receiptEntity);

        Assertions.assertNull(receiptEntity.getInitiatingInstitutionTaxId());

        Assertions.assertEquals(payerParticipantEntityMock(), receiptEntity.getPayerParticipant());
        Assertions.assertEquals(payerAccountEntityMock(), receiptEntity.getPayerAccount());
        Assertions.assertEquals(receiverParticipantEntityMock(), receiptEntity.getReceiverParticipant());
        Assertions.assertEquals(receiverAccountEntityMock(), receiptEntity.getReceiverAccount());
        Assertions.assertEquals(transactionPriorityEntityMock(), receiptEntity.getPriority());
    }

    @Test
    void shouldThrowNullPointerException() {
        Mockito.reset(configurationService);
        Assertions.assertThrows(NullPointerException.class, () -> receivedMessageService.fillAllAttributed(null, null, null));
    }

    @Test
    void shouldFillSomeAttributed() {
        Mockito.when(participantService.findByIspb(ISPB_PAYER)).thenReturn(Optional.of(payerParticipantEntityMock()));
        Mockito.when(participantService.findByIspb(ISPB_RECEIVER)).thenReturn(Optional.of(receiverParticipantEntityMock()));
        receivedMessageService.fillAllAttributed(receiptEventEntity, documentPacs008, nodeCdtTrfTxInf);

        Assertions.assertNotNull(receiptEventEntity);
        Assertions.assertNotNull(receiptEventEntity.getReceiptEntity());

        ReceiptEntity receiptEntity = receiptEventEntity.getReceiptEntity();

        assertionReceiptEvent(receiptEventEntity, receiptEntity);

        Assertions.assertNotNull(receiptEntity.getPayerAccount().getAccountType());
        Assertions.assertNotNull(receiptEntity.getReceiverAccount().getAccountType());
        Assertions.assertNull(receiptEntity.getInitiatingInstitutionTaxId());
        Assertions.assertNull(receiptEntity.getPriority());
    }

    @Test
    void shouldThrowInvalidIspbExceptionOnInvalidParticipant() {
        Mockito.when(participantService.findByIspb(ISPB_PAYER)).thenReturn(Optional.of(payerParticipantEntityMock()));

        assertThatThrownBy(() -> receivedMessageService.fillAllAttributed(receiptEventEntity, documentPacs008, nodeCdtTrfTxInf))
            .isInstanceOf(InvalidIspbException.class);
    }

    @Test
    void shouldThrowIllegalProcessExceptionWithExternalParticipant() {
        Mockito.when(participantService.findByIspb(ISPB_PAYER)).thenReturn(Optional.of(payerParticipantEntityMock()));

        ConfigEntity configEntity = new ConfigEntity();
        configEntity.setIspb(12345678);
        Mockito.when(configurationService.findConfig()).thenReturn(configEntity);

        assertThatThrownBy(() -> receivedMessageService.fillAllAttributed(receiptEventEntity, documentPacs008, nodeCdtTrfTxInf))
            .isInstanceOf(IllegalProcessException.class);
    }

    private static void assertionReceiptEvent(ReceiptEventEntity receiptEventEntity, ReceiptEntity receiptEntity) {
        Assertions.assertEquals(END_TO_END_ID, receiptEntity.getEndToEndId());
        Assertions.assertEquals(ADDITIONAL_INFORMATION, receiptEntity.getAdditionalInformation());
        Assertions.assertEquals(CHARGE_BEARER, receiptEntity.getChargeBearer());
        Assertions.assertEquals(CREATION_DATE_TIME_IN_LOCAL_DATE_TIME, receiptEntity.getCustomerInitTimestampUtc());
        Assertions.assertEquals(RECEIVER_RECON_IDENTIFIER, receiptEntity.getReceiverReconIdentifier());
        Assertions.assertEquals(SETTLEMENT_METHOD, receiptEntity.getSettlementMethod());
        Assertions.assertEquals(VALUE, receiptEntity.getEvent().getValue());
    }

    private static Node getNodeCdtTrfTxInf(Document document) {
        NodeList nodeList = DocumentUtils.getElementsByExpression(document, EXPRESSION_CDT_TRF_TX_INF);
        return nodeList.item(0);
    }

    private ReceiverAccountEntity receiverAccountEntityMock() {
        ReceiverAccountEntity receiverAccountEntity = new ReceiverAccountEntity();
        receiverAccountEntity.setAccountType(CACC_CODE);//receiverAccountTypeEntityMock()
        receiverAccountEntity.setAccount(ACCOUNT_RECEIVER);
        receiverAccountEntity.setBranch(BRANCH_RECEIVER);
        receiverAccountEntity.setTaxId(TAX_ID_RECEIVER);
        receiverAccountEntity.setAddressingKey(KEY_RECEIVER);
        return receiverAccountEntity;
    }

    private PayerAccountEntity payerAccountEntityMock() {
        PayerAccountEntity payerAccountEntity = new PayerAccountEntity();
        payerAccountEntity.setAccountType(SVGS_CODE);//payerAccountTypeEntityMock()
        payerAccountEntity.setBranch(BRANCH_PAYER);
        payerAccountEntity.setAccount(ACCOUNT_PAYER);
        payerAccountEntity.setTaxId(TAX_ID_PAYER);
        payerAccountEntity.setName(SOME_PAYER_NAME);
        return payerAccountEntity;
    }

    private TransactionPriorityEntity transactionPriorityEntityMock() {
        TransactionPriorityEntity transactionPriorityEntity = new TransactionPriorityEntity();
        transactionPriorityEntity.setCode(TRANSACTION_CODE);
        transactionPriorityEntity.setDescription(TRANSACTION_DESCRIPTION);
        return transactionPriorityEntity;
    }

    private AccountTypeEntity payerAccountTypeEntityMock() {
        AccountTypeEntity accountTypeEntity = new AccountTypeEntity();
        accountTypeEntity.setCode(SVGS_CODE);
        accountTypeEntity.setDescription(SVGS_DESCRIPTION);
        return accountTypeEntity;
    }

    private ParticipantEntity payerParticipantEntityMock() {
        ParticipantEntity participantEntity = new ParticipantEntity();
        participantEntity.setIspb(ISPB_PAYER);
        participantEntity.setName(ISPB_NAME_PAYER);
        return participantEntity;
    }

    private ParticipantEntity receiverParticipantEntityMock() {
        ParticipantEntity participantEntity = new ParticipantEntity();
        participantEntity.setIspb(ISPB_RECEIVER);
        participantEntity.setName(ISPB_NAME_RECEIVER);
        return participantEntity;
    }

    private AccountTypeEntity receiverAccountTypeEntityMock() {
        AccountTypeEntity accountTypeEntity = new AccountTypeEntity();
        accountTypeEntity.setCode(CACC_CODE);
        accountTypeEntity.setDescription(CACC_DESCRIPTION);
        return accountTypeEntity;
    }

    private static LocalDateTime getLocalDateTime() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(PATTERN_TIME_STAMP_UTC);
        return LocalDateTime.parse(CREATION_DATE_TIME, formatter);
    }

}
