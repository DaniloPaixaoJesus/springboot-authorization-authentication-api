package matera.spi.indirect.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.indirect.domain.model.ParticipantMipIndirectEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectHistoryEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectStatusEntity;
import matera.spi.indirect.util.ParticipantMipIndirectDataSetUtil;
import matera.spi.main.domain.model.ParticipantMipEntity;
import matera.spi.main.persistence.ParticipantMipRepository;

import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.opentest4j.AssertionFailedError;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.assertThat;

@IntegrationTest
class ParticipantMipIndirectHistoryRepositoryTest {

    private static final Integer ISPB = 12345434;
    private static final Integer ID = 1;

    @Autowired
    private ParticipantMipRepository participantMipRepository;

    @Autowired
    private ParticipantMipIndirectRepository participantMipIndirectRepository;

    @Autowired
    private ParticipantMipIndirectStatusRepository participantMipIndirectStatusRepository;

    @Autowired
    private ParticipantMipIndirectHistoryRepository participantMipIndirectHistoryRepository;

    @Autowired
    private ParticipantMipIndirectContactsRepository participantMipIndirectContactsRepository;

    @BeforeEach
    @AfterEach
    void cleanData() {
        ParticipantMipIndirectDataSetUtil.cleanIndirectParticipantTablesData(participantMipIndirectHistoryRepository,
            participantMipIndirectContactsRepository, participantMipIndirectRepository, participantMipRepository);
    }

    @Test
    void shouldAddAndFindNewParticipantMipIndirectHistory() {
        Optional<ParticipantMipIndirectStatusEntity> participantMipIndirectStatus =
            participantMipIndirectStatusRepository.findById(1);

        ParticipantMipEntity participantMip = createParticipantMip();
        ParticipantMipIndirectEntity participantMipIndirect = createParticipantMipIndirect(participantMip);

        ParticipantMipIndirectHistoryEntity participantMipIndirectHistory =
            createParticipantMipIndirectHistoryEntity(participantMipIndirectStatus, participantMipIndirect);

        ParticipantMipIndirectHistoryEntity searchedParticipantMipIndirectHistory =
            participantMipIndirectHistoryRepository.findById(participantMipIndirectHistory.getId())
                .orElseThrow(() -> new AssertionFailedError("Not found INDIRECT PARTICIPANT MIP HISTORY " + ISPB));

        assertThat(searchedParticipantMipIndirectHistory.getId()).isEqualTo(participantMipIndirectHistory.getId());
    }

    @Test
    void shouldFindTopParticipantMipIndirectHistoryOrderedByEventDateTimeDesc() {
        Optional<ParticipantMipIndirectStatusEntity> participantMipIndirectStatus =
            participantMipIndirectStatusRepository.findById(1);

        ParticipantMipEntity participantMip = createParticipantMip();
        ParticipantMipIndirectEntity participantIndirect = createParticipantMipIndirect(participantMip);

        ParticipantMipIndirectHistoryEntity oldestParticipantMipIndirectHistory =
            createParticipantMipIndirectHistoryEntity(participantMipIndirectStatus, participantIndirect);

        try {
            TimeUnit.SECONDS.sleep(2);
        } catch (InterruptedException e) {
            e.getMessage();
        }

        ParticipantMipIndirectHistoryEntity newestParticipantMipIndirectHistory =
            createParticipantMipIndirectHistoryEntity(participantMipIndirectStatus, participantIndirect);

        ParticipantMipIndirectHistoryEntity searchedParticipantMipIndirectHistory =
            participantMipIndirectHistoryRepository.findTopByParticipantMipOrderByEventDateTimeDesc(participantIndirect);

        assertThat(searchedParticipantMipIndirectHistory).isEqualToComparingFieldByField(newestParticipantMipIndirectHistory);
    }

    @NotNull
    private ParticipantMipIndirectHistoryEntity createParticipantMipIndirectHistoryEntity(Optional<ParticipantMipIndirectStatusEntity> participantMipIndirectStatus,
                                                                                          ParticipantMipIndirectEntity participantMipIndirect) {
        ParticipantMipIndirectHistoryEntity participantMipIndirectHistory = new ParticipantMipIndirectHistoryEntity();

        participantMipIndirectHistory.setType(ParticipantMipIndirectHistoryEntity.Type.LOCAL_UPDATE);
        participantMipIndirectHistory.setParticipantMip(participantMipIndirect);
        participantMipIndirectHistory.setPreviousStatus(participantMipIndirectStatus.get());
        participantMipIndirectHistory.setEventDateTime(LocalDateTime.now());

        participantMipIndirectHistoryRepository.saveAndFlush(participantMipIndirectHistory);
        return participantMipIndirectHistory;
    }

    private ParticipantMipEntity createParticipantMip() {
        ParticipantMipEntity participantMip = new ParticipantMipEntity();
        participantMip.setIspb(ISPB);
        participantMip.setBranch(123);
        participantMip.setAccountNumber(BigDecimal.valueOf(444555));
        participantMip.setDebTransactionType(12);
        participantMip.setCredTransactionType(344);
        participantMip.setDepositTransactionType(4789);
        participantMip.setWithdrawTransactionType(1147);
        participantMip.setDrawbackSentTransactType(11);
        participantMip.setDrawbackReceiveTransactType(77);
        participantMip.setBalanceValidationThreshold(true);
        participantMip.setBalanceLowerThreshold(BigDecimal.valueOf(1002430.57));
        participantMip.setBalanceLowerThresholdPerc(10);
        participantMip.setDirectParticipant(false);
        participantMip.setQrcodeCredTransactionType(9875);

        return participantMip;
    }

    private ParticipantMipIndirectEntity createParticipantMipIndirect(ParticipantMipEntity participantMip) {
        Optional<ParticipantMipIndirectStatusEntity> participantMipIndirectStatus =
            participantMipIndirectStatusRepository.findById(1);

        ParticipantMipIndirectEntity participantMipIndirect = new ParticipantMipIndirectEntity();

        participantMipIndirect.setParticipantMip(participantMip);
        participantMipIndirect.setName("Participant Indirect");
        participantMipIndirect.setCorporateName("Indirect");
        participantMipIndirect.setTaxId(new BigDecimal("123"));
        participantMipIndirect.setStatus(participantMipIndirectStatus.get());
        participantMipIndirect.setContractInitDate(LocalDate.of(2020, 8, 13));
        participantMipIndirect.setContractEndDate(LocalDate.of(2020, 8, 20));

        return participantMipIndirectRepository.saveAndFlush(participantMipIndirect);
    }

}


