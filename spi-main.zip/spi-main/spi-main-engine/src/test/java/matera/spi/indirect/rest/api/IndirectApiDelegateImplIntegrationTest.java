package matera.spi.indirect.rest.api;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.IndirectParticipantDTO;
import matera.spi.dto.IndirectParticipantInformationResponseDTO;
import matera.spi.dto.IndirectParticipantInformationResponseWrapperDTO;
import matera.spi.indirect.domain.model.ParticipantMipIndirectEntity;
import matera.spi.indirect.application.service.mapper.ParticipantMipIndirectMapper;
import matera.spi.indirect.domain.model.enums.IndirectParticipantStatusEnum;
import matera.spi.indirect.persistence.ParticipantMipIndirectContactsRepository;
import matera.spi.indirect.persistence.ParticipantMipIndirectRepository;
import matera.spi.indirect.persistence.ParticipantMipIndirectStatusRepository;
import matera.spi.indirect.util.ParticipantMipIndirectDataSetUtil;
import matera.spi.main.domain.model.ParticipantMipEntity;
import matera.spi.main.persistence.ParticipantMipRepository;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.ExtractableResponse;
import io.restassured.response.Response;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;

import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

@IntegrationTest
class IndirectApiDelegateImplIntegrationTest {

    private static final String URL = "/api/v1/indirects";
    private static final String ENTITY_NOT_FOUND_WITH_ISPB = "Entity not found with ispb %d.";
    private static final String ISPB_QUERY_NAME = "ispb";
    private static final String ONLY_ACTIVE_INDIRECTS_QUERY_NAME = "onlyActiveIndirects";
    private static final String SHOW_CANCELED_INDIRECTS = "showCanceledIndirects";
    private static final Integer ISPB = 12345678;
    private static final Integer ANOTHER_ISPB = 12345670;

    @Autowired
    private ParticipantMipRepository participantMipRepository;

    @Autowired
    private ParticipantMipIndirectStatusRepository participantMipIndirectStatusRepository;

    @Autowired
    private ParticipantMipIndirectRepository participantMipIndirectRepository;

    @Autowired
    private ParticipantMipIndirectContactsRepository participantMipIndirectContactsRepository;

    @LocalServerPort
    private int port;

    @BeforeEach
    void beforeEach() {
        RestAssured.port = port;
    }

    @BeforeEach
    @AfterEach
    void cleanData() {
        ParticipantMipIndirectDataSetUtil
            .cleanIndirectParticipantTablesData(null, participantMipIndirectContactsRepository,
                participantMipIndirectRepository, participantMipRepository);
    }

    @Test
    void shouldReturnTheValueAccordingFilters() {
        final ParticipantMipIndirectEntity participantMipIndirectEntity = participantMipIndirectRepository.saveAndFlush(
            ParticipantMipIndirectDataSetUtil.createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                ParticipantMipIndirectDataSetUtil.createParticipantMip()));

        final ParticipantMipEntity participantMipEntity = participantMipIndirectEntity.getParticipantMip();

        participantMipIndirectContactsRepository.saveAndFlush(
            ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectContactsEntity(participantMipIndirectEntity));

        //@formatter:off
        final ExtractableResponse<Response> response = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(StringUtils.EMPTY)
            .queryParam(ISPB_QUERY_NAME, participantMipEntity.getIspb())
            .queryParam(ONLY_ACTIVE_INDIRECTS_QUERY_NAME, false)
            .when()
            .get(URL)
            .then()
            .statusCode(HttpStatus.SC_OK)
            .extract();
        //@formatter:on

        final List<IndirectParticipantDTO> indirectParticipantDTO = participantMipIndirectRepository
            .findByIspbJoinFetchParticipantAndContacts(participantMipEntity.getIspb()).stream()
            .map(ParticipantMipIndirectMapper::mapEntityToIndirectParticipantDTO).collect(Collectors.toList());

        final IndirectParticipantInformationResponseDTO expectedDTO = new IndirectParticipantInformationResponseDTO();

        expectedDTO.setIndirectParticipants(indirectParticipantDTO);

        final IndirectParticipantInformationResponseWrapperDTO wrapperDTO = new IndirectParticipantInformationResponseWrapperDTO();

        wrapperDTO.setData(expectedDTO);

        assertEquals(wrapperDTO, response.body().as(IndirectParticipantInformationResponseWrapperDTO.class));
    }

    @Test
    void shouldReturnOnlyActiveIndirects() {
        participantMipIndirectRepository.saveAndFlush(
            ParticipantMipIndirectDataSetUtil.createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                ParticipantMipIndirectDataSetUtil.createParticipantMip()));

        participantMipIndirectRepository.saveAndFlush(ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                IndirectParticipantStatusEnum.CANCELED.getId(),
                ParticipantMipIndirectDataSetUtil.createParticipantMip(ISPB)));

        //@formatter:off
        final ExtractableResponse<Response> response = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(StringUtils.EMPTY)
            .queryParam(ONLY_ACTIVE_INDIRECTS_QUERY_NAME, true)
            .queryParam(SHOW_CANCELED_INDIRECTS, true)
            .when()
            .get(URL)
            .then()
            .statusCode(HttpStatus.SC_OK)
            .extract();
        //@formatter:on

        List<IndirectParticipantDTO> participants =
            response.body().jsonPath().getList("data.indirectParticipants", IndirectParticipantDTO.class);

        assertEquals(1, participants.size());
        assertEquals(IndirectParticipantStatusEnum.ACTIVE.toString(), participants.get(0).getStatus().toString());
    }

    @Test
    void shouldReturnAllIndirects() {
        participantMipIndirectRepository.saveAndFlush(
            ParticipantMipIndirectDataSetUtil.createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                ParticipantMipIndirectDataSetUtil.createParticipantMip()));

        participantMipIndirectRepository.saveAndFlush(ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                IndirectParticipantStatusEnum.CANCELED.getId(),
                ParticipantMipIndirectDataSetUtil.createParticipantMip(ISPB)));

        //@formatter:off
        final ExtractableResponse<Response> response = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(StringUtils.EMPTY)
            .queryParam(ONLY_ACTIVE_INDIRECTS_QUERY_NAME, false)
            .queryParam(SHOW_CANCELED_INDIRECTS, true)
            .when()
            .get(URL)
            .then()
            .statusCode(HttpStatus.SC_OK)
            .extract();
        //@formatter:on

        List<IndirectParticipantDTO> participants =
            response.body().jsonPath().getList("data.indirectParticipants", IndirectParticipantDTO.class);

        assertEquals(2, participants.size());
    }

    @Test
    void shouldReturnAllIndirectsButCanceled() {
        participantMipIndirectRepository.saveAndFlush(
            ParticipantMipIndirectDataSetUtil.createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                ParticipantMipIndirectDataSetUtil.createParticipantMip()));

        participantMipIndirectRepository.saveAndFlush(ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                IndirectParticipantStatusEnum.CANCELED.getId(),
                ParticipantMipIndirectDataSetUtil.createParticipantMip(ISPB)));

        participantMipIndirectRepository.saveAndFlush(ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                IndirectParticipantStatusEnum.REGISTRATION_SENT_TO_CLEARING.getId(),
                ParticipantMipIndirectDataSetUtil.createParticipantMip(ANOTHER_ISPB)));

        //@formatter:off
        final ExtractableResponse<Response> response = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(StringUtils.EMPTY)
            .queryParam(ONLY_ACTIVE_INDIRECTS_QUERY_NAME, false)
            .queryParam(SHOW_CANCELED_INDIRECTS, false)
            .when()
            .get(URL)
            .then()
            .statusCode(HttpStatus.SC_OK)
            .extract();
        //@formatter:on

        List<IndirectParticipantDTO> participants =
            response.body().jsonPath().getList("data.indirectParticipants", IndirectParticipantDTO.class);

        assertEquals(2, participants.size());
        participants.forEach(participant ->
            assertNotEquals(IndirectParticipantStatusEnum.CANCELED.toString(), participant.getStatus().toString()));
    }

    @Test
    void shouldReturnOnlyActiveIndirectsOfSpecifiedIspb() {
        ParticipantMipEntity participantMip = ParticipantMipIndirectDataSetUtil.createParticipantMip();

        participantMipIndirectRepository.saveAndFlush(
            ParticipantMipIndirectDataSetUtil
                .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository, participantMip));

        //@formatter:off
        final ExtractableResponse<Response> response = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(StringUtils.EMPTY)
            .queryParam(ISPB_QUERY_NAME, participantMip.getIspb())
            .queryParam(ONLY_ACTIVE_INDIRECTS_QUERY_NAME, true)
            .queryParam(SHOW_CANCELED_INDIRECTS, true)
            .when()
            .get(URL)
            .then()
            .statusCode(HttpStatus.SC_OK)
            .extract();
        //@formatter:on

        List<IndirectParticipantDTO> participants =
            response.body().jsonPath().getList("data.indirectParticipants", IndirectParticipantDTO.class);

        assertEquals(1, participants.size());
        assertEquals(IndirectParticipantStatusEnum.ACTIVE.toString(), participants.get(0).getStatus().toString());
    }

    @Test
    void shouldReturnNoIndirectsOfSpecifiedIspbBecauseItsCanceled() {
        ParticipantMipEntity participantMip = ParticipantMipIndirectDataSetUtil.createParticipantMip();

        participantMipIndirectRepository.saveAndFlush(ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                IndirectParticipantStatusEnum.CANCELED.getId(),
                participantMip));

        //@formatter:off
        final ExtractableResponse<Response> response = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(StringUtils.EMPTY)
            .queryParam(ISPB_QUERY_NAME, participantMip.getIspb())
            .queryParam(ONLY_ACTIVE_INDIRECTS_QUERY_NAME, false)
            .queryParam(SHOW_CANCELED_INDIRECTS, false)
            .when()
            .get(URL)
            .then()
            .statusCode(HttpStatus.SC_OK)
            .extract();
        //@formatter:on

        List<IndirectParticipantDTO> participants =
            response.body().jsonPath().getList("data.indirectParticipants", IndirectParticipantDTO.class);

        assertEquals(0, participants.size());
    }

    @Test
    void shouldReturnCanceledIndirectsOfSpecifiedIspbBecauseShowCanceledIsTrue() {
        ParticipantMipEntity participantMip = ParticipantMipIndirectDataSetUtil.createParticipantMip();

        participantMipIndirectRepository.saveAndFlush(ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                IndirectParticipantStatusEnum.CANCELED.getId(),
                participantMip));

        //@formatter:off
        final ExtractableResponse<Response> response = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(StringUtils.EMPTY)
            .queryParam(ISPB_QUERY_NAME, participantMip.getIspb())
            .queryParam(ONLY_ACTIVE_INDIRECTS_QUERY_NAME, false)
            .queryParam(SHOW_CANCELED_INDIRECTS, true)
            .when()
            .get(URL)
            .then()
            .statusCode(HttpStatus.SC_OK)
            .extract();
        //@formatter:on

        List<IndirectParticipantDTO> participants =
            response.body().jsonPath().getList("data.indirectParticipants", IndirectParticipantDTO.class);

        assertEquals(1, participants.size());
        assertEquals(IndirectParticipantStatusEnum.CANCELED.toString(), participants.get(0).getStatus().toString());
    }

    @Test
    void shouldReturnAllButCanceledIndirectsOfSpecifiedIspbByDefaultWhenDontReceiveShowOnlyActiveAndShowCanceledParameters() {
        ParticipantMipEntity participantMip = ParticipantMipIndirectDataSetUtil.createParticipantMip();

        participantMipIndirectRepository.saveAndFlush(
            ParticipantMipIndirectDataSetUtil
                .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository, participantMip));

        //@formatter:off
        final ExtractableResponse<Response> response = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(StringUtils.EMPTY)
            .queryParam(ISPB_QUERY_NAME, participantMip.getIspb())
            .when()
            .get(URL)
            .then()
            .statusCode(HttpStatus.SC_OK)
            .extract();
        //@formatter:on

        List<IndirectParticipantDTO> participants =
            response.body().jsonPath().getList("data.indirectParticipants", IndirectParticipantDTO.class);

        assertEquals(1, participants.size());
        assertEquals(IndirectParticipantStatusEnum.ACTIVE.toString(), participants.get(0).getStatus().toString());
    }
}
