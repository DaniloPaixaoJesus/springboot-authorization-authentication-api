package matera.spi.main.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.lm.domain.model.event.IpAccountBalanceQueryDetailsEntity;
import matera.spi.lm.domain.model.event.IpAccountBalanceQueryEventEntity;
import matera.spi.lm.persistence.IpAccountBalanceQueryDetailsRepository;
import matera.spi.main.domain.model.event.EventStatusEntity;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Optional;

import static matera.spi.utils.LocalDateTimeUtils.getMinLocalDateTime;
import static matera.spi.utils.LocalDateTimeUtils.getTodayUTC;
import static matera.spi.utils.LocalDateTimeUtils.getUtcLocalDateTime;

@IntegrationTest
public class IpAccountBalanceQueryDetailsRepositoryTest  {

    @Autowired
    private IpAccountBalanceQueryDetailsRepository repository;

    private IpAccountBalanceQueryDetailsEntity expectedEntity;

    @BeforeEach
    void init() {
        expectedEntity = buildBalanceDetails(Boolean.TRUE);
    }

    @AfterEach
    void clearDatabase() {
        repository.deleteAll();
    }

    @Test
    void shouldBeFindEntityWhenInserted() {
        final Optional<IpAccountBalanceQueryDetailsEntity> optionalActual = repository.findById(expectedEntity.getUuid());
        Assertions.assertTrue(optionalActual.isPresent());

        final IpAccountBalanceQueryDetailsEntity actualEntity = optionalActual.get();
        Assertions.assertEquals(expectedEntity, actualEntity);
    }

    @Test
    void shouldReturnPageableResponseWithNoParameters() {
        final PageRequest pageable = PageRequest.of(0, 1);
        final LocalDateTime midNightStartTimestamp = getMinLocalDateTime(getTodayUTC());
        final LocalDateTime midNightEndTimestamp = getMinLocalDateTime(getTodayUTC().plusDays(1));

        final Page<IpAccountBalanceQueryDetailsEntity> pageableResponse =
            repository.findByParameters(pageable, midNightStartTimestamp, midNightEndTimestamp, null);
        Assertions.assertNotNull(pageableResponse);
        Assertions.assertEquals(pageableResponse.getTotalElements(), 1L);

        final IpAccountBalanceQueryDetailsEntity queryDetailsEntity = pageableResponse.getContent().get(0);
        Assertions.assertEquals(expectedEntity, queryDetailsEntity);
    }

    @Test
    void shouldReturnPageableResponseWithIsCurrentBalanceEqualTrue() {
        final PageRequest pageable = PageRequest.of(0, 1);
        final LocalDateTime midNightStartTimestamp = getMinLocalDateTime(getTodayUTC());
        final LocalDateTime midNightEndTimestamp = getMinLocalDateTime(getTodayUTC().plusDays(1));

        final Page<IpAccountBalanceQueryDetailsEntity> pageableResponse =
            repository.findByParameters(pageable, midNightStartTimestamp, midNightEndTimestamp, true);
        Assertions.assertNotNull(pageableResponse);
        Assertions.assertEquals(pageableResponse.getTotalElements(), 1L);

        final IpAccountBalanceQueryDetailsEntity queryDetailsEntity = pageableResponse.getContent().get(0);
        Assertions.assertEquals(expectedEntity, queryDetailsEntity);
    }

    @Test
    void shouldReturnNoContentInPageableResponseWithIsCurrentBalanceEqualFalse() {
        final PageRequest pageable = PageRequest.of(0, 1);
        final LocalDateTime midNightStartTimestamp = getMinLocalDateTime(getTodayUTC());
        final LocalDateTime midNightEndTimestamp = getMinLocalDateTime(getTodayUTC().plusDays(1));

        final Page<IpAccountBalanceQueryDetailsEntity> pageableResponse =
            repository.findByParameters(pageable, midNightStartTimestamp, midNightEndTimestamp, false);
        Assertions.assertNotNull(pageableResponse);
        Assertions.assertEquals(pageableResponse.getTotalElements(), 0);
        Assertions.assertTrue(pageableResponse.getContent().isEmpty());
    }

    private IpAccountBalanceQueryDetailsEntity buildBalanceDetails(Boolean isCurrentBalance) {
        final IpAccountBalanceQueryDetailsEntity newInstance = new IpAccountBalanceQueryDetailsEntity();
        newInstance.setBalanceAvailable(BigDecimal.valueOf(1500.88));
        newInstance.setBalanceAvailableTimeUTC(getUtcLocalDateTime().truncatedTo(ChronoUnit.SECONDS));
        newInstance.setBalanceBlocked(BigDecimal.valueOf(88.45));
        newInstance.setBalanceBlockedTimeUTC(getUtcLocalDateTime().truncatedTo(ChronoUnit.SECONDS));
        newInstance.setIsCurrentBalance(isCurrentBalance);
        newInstance.setDateSent(getTodayUTC());
        newInstance.setIpAccountBalanceQueryEventEntity(buildQueryEventEntity(newInstance));
        return repository.save(newInstance);
    }

    private IpAccountBalanceQueryEventEntity buildQueryEventEntity(IpAccountBalanceQueryDetailsEntity queryDetailsEntity) {
        final IpAccountBalanceQueryEventEntity queryEventEntity = new IpAccountBalanceQueryEventEntity();
        queryEventEntity.setCorrelationId("E00539039202002170828063aec68f6e");
        queryEventEntity.setClearingTimestampUTC(getUtcLocalDateTime());
        queryEventEntity.setInitiationTimestampUTC(getUtcLocalDateTime());
        queryEventEntity.setResponsible("SOME RESPONSIBLE");
        queryEventEntity.setInitiatorIspb(12345);
        queryEventEntity.setValue(BigDecimal.ONE);
        EventStatusEntity eventStatus = new EventStatusEntity();
        eventStatus.setCode(1);
        eventStatus.setDescription("");
        eventStatus.setFinalStatus(true);
        queryEventEntity.setStatus(eventStatus);
        queryEventEntity.setIpAccountBalanceQueryDetailsEntity(queryDetailsEntity);

        return queryEventEntity;
    }
}
