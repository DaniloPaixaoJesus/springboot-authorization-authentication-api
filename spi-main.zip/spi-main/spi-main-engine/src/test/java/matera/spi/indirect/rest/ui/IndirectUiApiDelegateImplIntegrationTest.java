package matera.spi.indirect.rest.ui;

import com.matera.spi.messaging.api.MessagesApi;
import com.matera.spi.messaging.api.SPIMessagingApis;
import com.matera.spi.messaging.model.MessageSentResponseDTO;
import com.matera.spi.messaging.model.MessageSpecificationDTO;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.ErrorDTO;
import matera.spi.dto.IndirectParticipantCancelmentResponseDTO;
import matera.spi.dto.IndirectParticipantContactDTO;
import matera.spi.dto.IndirectParticipantCreationRequestDTO;
import matera.spi.dto.IndirectParticipantCreationResponseDTO;
import matera.spi.dto.IndirectParticipantFinancialFieldsUIDTO;
import matera.spi.dto.IndirectParticipantHistoryDTO;
import matera.spi.dto.IndirectParticipantHistoryEventTypeDTO;
import matera.spi.dto.IndirectParticipantIdentificationUIDTO;
import matera.spi.dto.IndirectParticipantPossibleActionsDTO;
import matera.spi.dto.IndirectParticipantPossibleActionsResponseDTO;
import matera.spi.dto.IndirectParticipantRegistrationResponseDTO;
import matera.spi.dto.IndirectParticipantStatusDTO;
import matera.spi.dto.IndirectParticipantUpdateRequestDTO;
import matera.spi.dto.IndirectParticipantUpdateResponseDTO;
import matera.spi.dto.PageableIndirectParticipantHistoryResponseDTO;
import matera.spi.indirect.application.service.mapper.IndirectParticipantPossibleActionsDTOMapper;
import matera.spi.indirect.domain.model.ParticipantMipIndirectEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectHistoryEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectStatusEntity;
import matera.spi.indirect.domain.model.enums.IndirectParticipantStatusEnum;
import matera.spi.indirect.domain.service.IndirectParticipantHistoryService;
import matera.spi.indirect.domain.service.IndirectParticipantInformationRetriever;
import matera.spi.indirect.domain.service.IndirectParticipantMipService;
import matera.spi.indirect.domain.service.IndirectParticipantStatusService;
import matera.spi.indirect.exception.message.ExceptionMessages;
import matera.spi.indirect.persistence.ParticipantMipIndirectContactsRepository;
import matera.spi.indirect.persistence.ParticipantMipIndirectHistoryRepository;
import matera.spi.indirect.persistence.ParticipantMipIndirectRepository;
import matera.spi.indirect.persistence.ParticipantMipIndirectStatusRepository;
import matera.spi.indirect.util.EventDataSetUtil;
import matera.spi.indirect.util.ParticipantMipIndirectDataSetUtil;
import matera.spi.main.domain.model.ParticipantMipEntity;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventStatus;
import matera.spi.main.domain.service.MessageSender;
import matera.spi.main.domain.service.event.receiver.MessageReceiver;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.EventStatusRepository;
import matera.spi.main.persistence.EventStatusTransitionRepository;
import matera.spi.main.persistence.EventTypeRepository;
import matera.spi.main.persistence.ParticipantMipRepository;
import matera.spi.main.utils.MessageCreationUtils;
import matera.spi.utils.IspbUtils;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.ExtractableResponse;
import io.restassured.response.Response;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.hamcrest.Matcher;
import org.hamcrest.MatcherAssert;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.opentest4j.AssertionFailedError;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

import static matera.spi.indirect.domain.model.ParticipantMipIndirectHistoryEntity.Type.CLEARING_RESCISSION_REQUEST;
import static matera.spi.indirect.domain.model.ParticipantMipIndirectHistoryEntity.Type.CLEARING_RESCISSION_RESPONSE;
import static matera.spi.indirect.util.ParticipantMipIndirectDataSetUtil.createParticipantMip;
import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ISPB;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import static java.lang.Integer.valueOf;

@IntegrationTest
class IndirectUiApiDelegateImplIntegrationTest {

    private static final String FROM_SUCCESS_REDA016 = "reda.016/reda.016_sucesso_msg.xml";
    private static final String FROM_REJECT_REDA016 = "reda.016/reda.016_erro_msg.xml";
    private static final String FROM_QUEUED_REDA016 = "reda.016/reda.016_queued_msg.xml";
    private static final String STATUS_PARAM_NAME = "status";
    private static final String ISPB_PARAM_NAME = "ispb";
    private static final String PI_RESOURCE_ID = "PI-RESOURCE-ID-TEST-STATEMENT";
    private static final String FIND_INDIRECT_POSSIBLE_ACTIONS_URL = "/ui/v1/indirect/possible-actions/{status}";
    private static final String UNREGISTER_INDIRECT_PARTICIPANT_URL = "/ui/v1/indirect/rescission/{ispb}";
    private static final String STATUS_NOT_FOUND_WITH_NAME = "Status not found with name %s.";
    private static final String INDIRECT_PART_REGISTER_URL = "/ui/v1/indirect/registration/{ispb}";
    private static final String ISBP_PARAM_NAME = "ispb";
    private static final String NOT_FOUND_ISBP = "123456";
    private static final IndirectParticipantStatusDTO INDIRECT_REGISTRATION_REQUEST_PENDING_STATUS =
        IndirectParticipantStatusDTO.WAITING_TO_SEND_REGISTRATION_TO_CLEARING;
    private static final IndirectParticipantStatusDTO INDIRECT_REGISTRATION_REQUESTED_STATUS =
        IndirectParticipantStatusDTO.REGISTRATION_SENT_TO_CLEARING;
    private static final IndirectParticipantStatusDTO INDIRECT_REGISTRATION_QUEUED_STATUS =
        IndirectParticipantStatusDTO.WAITING_CLEARING_SUSPENSION_RESPONSE;
    public static final ParticipantMipIndirectHistoryEntity.Type CLEARING_REGISTRATION_RESPONSE_HIST_TYPE =
        ParticipantMipIndirectHistoryEntity.Type.CLEARING_REGISTRATION_RESPONSE;
    public static final ParticipantMipIndirectHistoryEntity.Type CLEARING_QUEUED_REG_RESPONSE_HIST_TYPE =
        ParticipantMipIndirectHistoryEntity.Type.CLEARING_REGISTRATION_QUEUED_RESPONSE;
    private static final String UNREGISTER_INDIRECT_PARTICIPANT_REQUIRED_BODY_REQUEST =
        "{\"reason\": \"USER_REQUEST\"}";
    private static final String THE_INDIRECT_PARTICIPANT_COULD_NOT_BE_FOUND =
        "The indirect participant could not be found.";
    private static final String SPI_IND_001 = "SPI-IND-001";
    private static final String SPI_IND_006 = "SPI-IND-006";
    private static final String URL_FILTERS = "/ui/v1/indirect/";
    private static final String URL_PART_COMPLETE = "/ui/v1/indirect/{ispb}";
    private static final String URL_PART_HISTORY = "/ui/v1/indirect/history/{ispb}";
    private static final Integer PAGE_SIZE = 2;
    private static final Integer PAGE_NUMBER = 0;
    private static final String ORDERING = "contractInitDate";
    private static final String ORDERING_DIRECTION = "ASC";
    private static final String TX_ID = "79610132000195";
    private static final String NEW_TX_ID = "10567635000129";
    private static final BigDecimal TAX_ID = new BigDecimal(TX_ID);
    private static final String ACCOUNT_NUMBER = "123";
    private static final String BRANCH = "1";
    private static final LocalDate CONTRACT_END_DATE = LocalDate.now().plusDays(1);
    private static final LocalDate CONTRACT_INIT_DATE = LocalDate.now();
    private static final LocalDate CONTRACT_INIT_DATE_BIGGER_THAN_END_DATE = LocalDate.now().plusDays(2);
    private static final String CORPORATE_NAME = "CORP_NAME";
    private static final Integer ISPB = 192555;
    private static final Integer NEW_ISPB = 999999;
    private static final String NAME = "name";
    private static final String PAGE_SIZE_PARAM_NAME = "pageSize";
    private static final String PAGE_NUMBER_PARAM_NAME = "pageNumber";
    private static final String PARENT_HISTORY = "parentHistory";
    private static final String PREVIOUS_STATUS = "previousStatus";
    private static final String ID_PROPERTY_NAME = "id";
    private static final String REJECT_REASON_CODE = "rejectReasonCode";

    private static final String EXPECTED_INDIRECT_PARTICIPANT_NAME_2 = "Indirect 2";
    private static final String EXPECTED_INDIRECT_ISPB_2 = "00123452";
    private static final BigDecimal EXPECTED_INDIRECT_TAX_ID_2 = BigDecimal.valueOf(237423000120l);

    @Autowired
    private MessageReceiver messageReceiver;

    @Autowired
    private IndirectParticipantStatusService indirectParticipantStatusService;

    @Autowired
    private IndirectParticipantMipService indirectParticipantMipService;

    @Autowired
    private IndirectParticipantInformationRetriever indirectParticipantInformationRetriever;

    @Autowired
    private EventRepository eventRepository;

    @Autowired
    private EventTypeRepository eventTypeRepository;

    @Autowired
    private ParticipantMipRepository participantMipRepository;

    @Autowired
    private ParticipantMipIndirectRepository participantMipIndirectRepository;

    @Autowired
    private ParticipantMipIndirectStatusRepository participantMipIndirectStatusRepository;

    @Autowired
    private ParticipantMipIndirectHistoryRepository participantMipIndirectHistoryRepository;

    @Autowired
    private MessageSender messageSender;

    @Mock
    private SPIMessagingApis mockedSpiMessagingApis;

    @Mock
    private MessagesApi mockedMessagesApi;

    @Autowired
    private ParticipantMipIndirectContactsRepository participantMipIndirectContactsRepository;

    @Autowired
    private IndirectParticipantHistoryService indirectParticipantHistoryService;

    @LocalServerPort
    private int port;

    @Autowired
    private SPIMessagingApis spiMessagingApisBean;

    @Autowired
    private EventStatusTransitionRepository eventStatusTransitionRepository;

    @Autowired
    private EventStatusRepository eventStatusRepository;

    @BeforeEach
    void setUpRestAssuredPort() {
        RestAssured.port = port;
    }

    @BeforeEach
    @AfterEach
    void cleanData() {
        ParticipantMipIndirectDataSetUtil.cleanIndirectParticipantTablesData(participantMipIndirectHistoryRepository,
            participantMipIndirectContactsRepository, participantMipIndirectRepository, participantMipRepository);

    }

    @BeforeEach
    void setup() {
        when(mockedSpiMessagingApis.messagesApi()).thenReturn(mockedMessagesApi);
        messageSender.setSpiMessagingApis(mockedSpiMessagingApis);
    }

    @AfterEach
    void tearDown() {
        messageSender.setSpiMessagingApis(spiMessagingApisBean);
    }

    @Test
    void shouldReturnExpectedActionsAccordingFilters() {
        //@formatter:off
        final ExtractableResponse<Response> response = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(StringUtils.EMPTY)
            .pathParam(STATUS_PARAM_NAME, IndirectParticipantStatusDTO.ACTIVE.name())
            .when()
            .get(FIND_INDIRECT_POSSIBLE_ACTIONS_URL)
            .then()
            .statusCode(HttpStatus.SC_OK)
            .extract();
        //@formatter:on

        final ParticipantMipIndirectStatusEntity indirectPossibleActions = indirectParticipantStatusService
            .findById(IndirectParticipantStatusEnum.valueOf(IndirectParticipantStatusDTO.ACTIVE.name()).getId())
            .orElseThrow(() -> {
                throw new AssertionFailedError(
                    String.format(STATUS_NOT_FOUND_WITH_NAME, IndirectParticipantStatusDTO.ACTIVE.name()));
            });

        final IndirectParticipantPossibleActionsDTO indirectParticipantPossibleActionsDTO =
            IndirectParticipantPossibleActionsDTOMapper.mapEntityToDto(indirectPossibleActions);

        final IndirectParticipantPossibleActionsResponseDTO expectedDTO =
            new IndirectParticipantPossibleActionsResponseDTO();

        expectedDTO.setData(indirectParticipantPossibleActionsDTO);

        assertEquals(expectedDTO, response.body().as(IndirectParticipantPossibleActionsResponseDTO.class));
    }

    @Test
    void shouldDeregisterIndirectParticipantWithStatusActive() {
        prepareDeregisterTest(IndirectParticipantStatusEnum.ACTIVE.getId());

        //@formatter:off
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(UNREGISTER_INDIRECT_PARTICIPANT_REQUIRED_BODY_REQUEST)
            .pathParam(ISPB_PARAM_NAME, ParticipantMipIndirectDataSetUtil.ISPB)
            .when()
            .post(UNREGISTER_INDIRECT_PARTICIPANT_URL)
            .then()
            .statusCode(HttpStatus.SC_ACCEPTED)
            .assertThat()
            .body("data.status", equalTo(IndirectParticipantStatusEnum.DEREGISTRATION_SENT_TO_CLEARING.name()));
        //@formatter:on

        final EventEntity eventEntity = eventRepository.findByStatus(
            eventStatusRepository.getOne(EventStatus.WAITING_INDIRECT_CLEARING_RESCISSION_CONFIRM.getCode())).get(0);

        final String reda016 =
            getStringFromXmlFile(FROM_SUCCESS_REDA016).replace("<Id>99999010</Id>", "<Id>" + PARTICIPANT_ISPB + "</Id>")
                .replace("<MsgId>M9999901012345678901234567890123</MsgId>",
                    "<MsgId>" + eventEntity.getCorrelationId() + "</MsgId>");

        messageReceiver.readIncomingMessage(MessageCreationUtils.buildMessageReceiverJson(reda016));

        final List<ParticipantMipIndirectHistoryEntity> histories = participantMipIndirectHistoryRepository.findAll();
        final ParticipantMipIndirectEntity participantMipIndirectEntityUpdated = indirectParticipantInformationRetriever
            .findIndirectParticipantByIspbAndClearingStatusAndShowCanceled(ParticipantMipIndirectDataSetUtil.ISPB, false, true).get(0);

        /*
         * EventStatus sequence:
         * 1. -> 24 / Initialized
         * 2. -> 40 / Waiting indirect clearing rescission confirm
         * 3. -> 03 / Success
         * */
        //@formatter:off
        assertThat(histories).hasSize(2);
        MatcherAssert.assertThat(histories, allOf(
            hasItem(hasARequestWithNoParent(IndirectParticipantStatusEnum.ACTIVE)),
            hasItem(hasAResponseWithARequestParent(IndirectParticipantStatusEnum.DEREGISTRATION_SENT_TO_CLEARING,
                IndirectParticipantStatusEnum.ACTIVE))));
        //@formatter:on
        assertEquals(participantMipIndirectEntityUpdated.getStatus().getId(),
            IndirectParticipantStatusEnum.getIdByDto(IndirectParticipantStatusDTO.DEREGISTERED));
    }

    @Test
    void shouldNotDeregisterIndirectParticipantWhenRejected() {
        prepareDeregisterTest(IndirectParticipantStatusEnum.ACTIVE.getId());

        //@formatter:off
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(UNREGISTER_INDIRECT_PARTICIPANT_REQUIRED_BODY_REQUEST)
            .pathParam(ISPB_PARAM_NAME, ParticipantMipIndirectDataSetUtil.ISPB)
            .when()
            .post(UNREGISTER_INDIRECT_PARTICIPANT_URL)
            .then()
            .statusCode(HttpStatus.SC_ACCEPTED)
            .assertThat()
            .body("data.status", equalTo(IndirectParticipantStatusEnum.DEREGISTRATION_SENT_TO_CLEARING.name()));
        //@formatter:on

        final EventEntity eventEntity = eventRepository.findByStatus(
            eventStatusRepository.getOne(EventStatus.WAITING_INDIRECT_CLEARING_RESCISSION_CONFIRM.getCode())).get(0);
        final String expectedRejectReason = "IND5";
        final String reda016 = formatRejectReda016Message(expectedRejectReason, eventEntity);

        assertTrue(participantMipIndirectHistoryRepository.findAll().stream()
            .noneMatch(containsReasonCode(expectedRejectReason)));

        messageReceiver.readIncomingMessage(MessageCreationUtils.buildMessageReceiverJson(reda016));

        final List<ParticipantMipIndirectHistoryEntity> histories = participantMipIndirectHistoryRepository.findAll();
        final ParticipantMipIndirectEntity participantMipIndirectEntityUpdated = indirectParticipantInformationRetriever
            .findIndirectParticipantByIspbAndClearingStatusAndShowCanceled(ParticipantMipIndirectDataSetUtil.ISPB, false, true).get(0);

        /*
         * EventStatus sequence:
         * 1. -> 24 / Initialized
         * 2. -> 40 / Waiting indirect clearing rescission confirm
         * 3. -> 36 / Rejected
         * */
        //@formatter:off
        assertThat(histories).hasSize(2);
        MatcherAssert.assertThat(histories, allOf(
            hasItem(hasARequestWithNoParent(IndirectParticipantStatusEnum.ACTIVE)),
            hasItem(allOf(
                hasProperty(REJECT_REASON_CODE, equalTo(expectedRejectReason)),
                hasAResponseWithARequestParent(
                    IndirectParticipantStatusEnum.DEREGISTRATION_SENT_TO_CLEARING,
                    IndirectParticipantStatusEnum.ACTIVE)))));
        //@formatter:on
        assertEquals(participantMipIndirectEntityUpdated.getStatus().getId(),
            IndirectParticipantStatusEnum.getIdByDto(IndirectParticipantStatusDTO.ACTIVE));
    }

    @NotNull
    private Matcher<Object> hasType(ParticipantMipIndirectHistoryEntity.Type type) {
        return hasProperty("type", equalTo(type));
    }

    @NotNull
    private Matcher<Object> hasARequestWithNoParent(IndirectParticipantStatusEnum previousStatus) {
        //@formatter:off
        return allOf(
            hasType(CLEARING_RESCISSION_REQUEST),
            hasProperty(PARENT_HISTORY, nullValue()),
            hasProperty(PREVIOUS_STATUS, hasProperty(ID_PROPERTY_NAME, equalTo(previousStatus.getId())))
        );
        //@formatter:off
    }

    @NotNull
    private Matcher<Object> hasAResponseWithARequestParent(IndirectParticipantStatusEnum firstPreviousStatus,
                                                           IndirectParticipantStatusEnum lastPreviousStatus) {
        return allOf(
            hasType(CLEARING_RESCISSION_RESPONSE),
            hasProperty(PARENT_HISTORY, hasARequestWithNoParent(lastPreviousStatus)),
            hasProperty(PREVIOUS_STATUS, hasProperty(ID_PROPERTY_NAME, equalTo(firstPreviousStatus.getId()))));
    }

    @ParameterizedTest
    @ValueSource(ints = {2, 3, 4, 5, 6, 7, 8, 13})
    void shouldDenyTheDeregisterOfAnIndirectParticipantWithStatusNonActive(Integer statusId) {
        prepareDeregisterTest(statusId);

        //@formatter:off
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(UNREGISTER_INDIRECT_PARTICIPANT_REQUIRED_BODY_REQUEST)
            .pathParam(ISPB_PARAM_NAME, ParticipantMipIndirectDataSetUtil.ISPB)
            .when()
            .post(UNREGISTER_INDIRECT_PARTICIPANT_URL)
            .then()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .assertThat()
            .body("error.code[0]", equalTo(SPI_IND_001))
            .body("error.message[0]", equalTo("The indirect participant could not be found."));
        //@formatter:on
    }

    @ParameterizedTest
    @ValueSource(ints = {9, 11, 12})
    void shouldDenyTheDeregisterOfAnIndirectParticipantWithStatusThatNotAllowRescission(Integer statusId) {
        final ParticipantMipIndirectEntity participantMipIndirectEntity = prepareDeregisterTest(statusId);
        final ParticipantMipIndirectStatusEntity status = participantMipIndirectEntity.getStatus();
        final String message = "The current status " + status.getStatus() + " does not allow rescission operation.";

        //@formatter:off
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(UNREGISTER_INDIRECT_PARTICIPANT_REQUIRED_BODY_REQUEST)
            .pathParam(ISPB_PARAM_NAME, ParticipantMipIndirectDataSetUtil.ISPB)
            .when()
            .post(UNREGISTER_INDIRECT_PARTICIPANT_URL)
            .then()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .assertThat()
            .body("error.code[0]", equalTo(SPI_IND_006))
            .body("error.message[0]", equalTo(message));
        //@formatter:on
    }

    private ParticipantMipIndirectEntity prepareDeregisterTest(Integer statusId) {
        final ParticipantMipEntity participantMip = ParticipantMipIndirectDataSetUtil.createParticipantMip();
        final ParticipantMipIndirectEntity participantMipIndirectEntity = ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository, statusId, participantMip);

        participantMipIndirectRepository.saveAndFlush(participantMipIndirectEntity);

        when(mockedMessagesApi.sendsMessageV1(any(MessageSpecificationDTO.class)))
            .thenReturn(EventDataSetUtil.createMessageSentResponseDTO());

        return participantMipIndirectEntity;
    }

    @Test
    void shouldReturnBadRequestWhenDeregisterANonexistentIndirectParticipant() {
        //@formatter:off
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(UNREGISTER_INDIRECT_PARTICIPANT_REQUIRED_BODY_REQUEST)
            .pathParam(ISPB_PARAM_NAME, ParticipantMipIndirectDataSetUtil.ISPB)
            .when()
            .post(UNREGISTER_INDIRECT_PARTICIPANT_URL)
            .then()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .assertThat()
            .body("error.code[0]", equalTo(SPI_IND_001))
            .body("error.message[0]", equalTo(THE_INDIRECT_PARTICIPANT_COULD_NOT_BE_FOUND));

        //@formatter:on
    }

    @Test
    void shouldReturnIndirectParticipantsSummaryInfoWhenInformationAllFilters() {
        participantMipIndirectRepository.saveAndFlush(ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                ParticipantMipIndirectDataSetUtil.createParticipantMip()));

        //@formatter:off
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .header(PAGE_SIZE_PARAM_NAME, PAGE_SIZE)
            .header(PAGE_NUMBER_PARAM_NAME, PAGE_NUMBER)
            .queryParam("ordering", ORDERING)
            .queryParam("orderingDirection", ORDERING_DIRECTION)
            .queryParam("indirectIspb", ParticipantMipIndirectDataSetUtil.ISPB)
            .queryParam("indirectName", ParticipantMipIndirectDataSetUtil.INDIRECT_PARTICIPANT_NAME)
            .queryParam("indirectTaxId", TAX_ID)
            .queryParam("status", IndirectParticipantStatusDTO.ACTIVE)
            .queryParam("contractInitDate", ParticipantMipIndirectDataSetUtil.CONTRACT_INIT_DATE
                .format(DateTimeFormatter.ISO_LOCAL_DATE))
            .queryParam("contractEndDate", ParticipantMipIndirectDataSetUtil.CONTRACT_END_DATE
                .format(DateTimeFormatter.ISO_LOCAL_DATE))
            .when()
            .get(URL_FILTERS)
            .then()
            .statusCode(HttpStatus.SC_OK)
            .assertThat()
            .body("data.content[0].name", equalTo(ParticipantMipIndirectDataSetUtil.INDIRECT_PARTICIPANT_NAME));
        //@formatter:on
    }

    @Test
    void shouldReturnIndirectParticipantsSummaryInfoOrdered() {
        final ParticipantMipEntity participantMip = createParticipantMip();
        final ParticipantMipEntity participantMip2 = createParticipantMip(valueOf(EXPECTED_INDIRECT_ISPB_2));

        participantMipIndirectRepository.saveAndFlush(ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository, participantMip));

        final ParticipantMipIndirectEntity participantMipIndirectEntity2 =
            ParticipantMipIndirectDataSetUtil.createCustomParticipantMipIndirectEntity(participantMipIndirectStatusRepository, participantMip2,
                EXPECTED_INDIRECT_PARTICIPANT_NAME_2, EXPECTED_INDIRECT_PARTICIPANT_NAME_2, EXPECTED_INDIRECT_TAX_ID_2, IndirectParticipantStatusEnum.ACTIVE);
        participantMipIndirectRepository.save(participantMipIndirectEntity2);

        //@formatter:off
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .header(PAGE_SIZE_PARAM_NAME, PAGE_SIZE)
            .header(PAGE_NUMBER_PARAM_NAME, PAGE_NUMBER)
            .when()
            .get(URL_FILTERS)
            .then()
            .statusCode(HttpStatus.SC_OK)
            .assertThat()
            .body("data.content[0].name", equalTo(EXPECTED_INDIRECT_PARTICIPANT_NAME_2))
            .body("data.content[1].name", equalTo(ParticipantMipIndirectDataSetUtil.INDIRECT_PARTICIPANT_NAME));
        //@formatter:on
    }

    @Test
    void shouldReturnIndirectParticipantsSummaryInfoFiltredByName() {
        final ParticipantMipEntity participantMip = createParticipantMip();
        final ParticipantMipEntity participantMip2 = createParticipantMip(valueOf(EXPECTED_INDIRECT_ISPB_2));

        participantMipIndirectRepository.saveAndFlush(ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository, participantMip));

        final ParticipantMipIndirectEntity participantMipIndirectEntity2 =
            ParticipantMipIndirectDataSetUtil.createCustomParticipantMipIndirectEntity(participantMipIndirectStatusRepository, participantMip2,
                EXPECTED_INDIRECT_PARTICIPANT_NAME_2, EXPECTED_INDIRECT_PARTICIPANT_NAME_2, EXPECTED_INDIRECT_TAX_ID_2, IndirectParticipantStatusEnum.ACTIVE);
        participantMipIndirectRepository.save(participantMipIndirectEntity2);

        //@formatter:off
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .header(PAGE_SIZE_PARAM_NAME, PAGE_SIZE)
            .header(PAGE_NUMBER_PARAM_NAME, PAGE_NUMBER)
            .queryParam("indirectName", "Participant")
            .when()
            .get(URL_FILTERS)
            .then()
            .statusCode(HttpStatus.SC_OK)
            .assertThat()
            .body("data.content[0].name", equalTo(ParticipantMipIndirectDataSetUtil.INDIRECT_PARTICIPANT_NAME))
            .body("data.totalElements", equalTo(1));
        //@formatter:on
    }

    @Test
    void shouldReturnIndirectParticipantsSummaryInfoWhenNoFilterIsGiven() {
        participantMipIndirectRepository.saveAndFlush(ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                ParticipantMipIndirectDataSetUtil.createParticipantMip()));

        //@formatter:off
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .header(PAGE_SIZE_PARAM_NAME, PAGE_SIZE)
            .header(PAGE_NUMBER_PARAM_NAME, PAGE_NUMBER)
            .when()
            .get(URL_FILTERS)
            .then()
            .statusCode(HttpStatus.SC_OK)
            .assertThat()
            .body("data.content[0].name", equalTo(ParticipantMipIndirectDataSetUtil.INDIRECT_PARTICIPANT_NAME));
        //@formatter:on
    }

    @Test
    void shouldReturnIndirectParticipantWhenFindByIspb() {
        final ParticipantMipIndirectEntity entity = ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                ParticipantMipIndirectDataSetUtil.createParticipantMip());

        entity.setContacts(
            Arrays.asList(ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectContactsEntity(entity)));

        participantMipIndirectRepository.saveAndFlush(entity);

        //@formatter:off
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(StringUtils.EMPTY)
            .pathParam("ispb", ParticipantMipIndirectDataSetUtil.ISPB)
            .when()
            .get(URL_PART_COMPLETE)
            .then()
            .statusCode(HttpStatus.SC_OK)
            .assertThat()
            .body("data.name", equalTo(ParticipantMipIndirectDataSetUtil.INDIRECT_PARTICIPANT_NAME))
            .body("data.contacts[0].name", equalTo(ParticipantMipIndirectDataSetUtil.CONTACT_NAME));
        //@formatter:on
    }

    @Test
    void shouldCreateIndirectParticipant() {

        //@formatter:off
        final ExtractableResponse<Response> response = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(createIndirectParticipantCreationRequestMock())
            .when()
            .post(URL_FILTERS)
            .then()
            .statusCode(HttpStatus.SC_CREATED)
            .extract();
        //@formatter:on

        assertNotNull(response);
        IndirectParticipantCreationResponseDTO responseDto =
            response.body().jsonPath().getObject("data", IndirectParticipantCreationResponseDTO.class);
        assertNotNull(responseDto.getStatus());
    }

    @Test
    void shouldReturnBadRequestOnCreateIndirectParticipantWithInvalidInformation() {

        IndirectParticipantCreationRequestDTO creationRequestDTO = createIndirectParticipantCreationRequestMock();
        creationRequestDTO.setContractInitDate(CONTRACT_INIT_DATE_BIGGER_THAN_END_DATE);

        //@formatter:off
        final ExtractableResponse<Response> response = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(creationRequestDTO)
            .when()
            .post(URL_FILTERS)
            .then()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .extract();
        //@formatter:on

    }

    @Test
    void shouldUpdateIndirectParticipant() {

        IndirectParticipantCreationRequestDTO creationRequestDTO = createIndirectParticipantCreationRequestMock();

        //@formatter:off
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(creationRequestDTO)
            .when()
            .post(URL_FILTERS)
            .then()
            .statusCode(HttpStatus.SC_CREATED)
            .extract();
        //@formatter:on

        //@formatter:off
        final ExtractableResponse<Response> response = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(createIndirectParticipantUpdateRequestMock())
            .pathParam(ISPB_PARAM_NAME, creationRequestDTO.getIspb())
            .when()
            .post(URL_PART_COMPLETE)
            .then()
            .statusCode(HttpStatus.SC_OK)
            .extract();
        //@formatter:on

        assertNotNull(response);
        IndirectParticipantUpdateResponseDTO responseDto =
            response.body().jsonPath().getObject("data", IndirectParticipantUpdateResponseDTO.class);
        assertEquals(IndirectParticipantStatusDTO.WAITING_TO_SEND_REGISTRATION_TO_CLEARING, responseDto.getStatus());
    }

    @Test
    void shouldReturnBadRequestOnUpdateIndirectParticipantWithInvalidInformation() {

        IndirectParticipantCreationRequestDTO creationRequestDTO = createIndirectParticipantCreationRequestMock();

        //@formatter:off
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(creationRequestDTO)
            .when()
            .post(URL_FILTERS)
            .then()
            .statusCode(HttpStatus.SC_CREATED)
            .extract();
        //@formatter:on

        IndirectParticipantUpdateRequestDTO updateRequestDTO = createIndirectParticipantUpdateRequestMock();
        updateRequestDTO.setContractInitDate(CONTRACT_INIT_DATE_BIGGER_THAN_END_DATE);

        //@formatter:off
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(updateRequestDTO)
            .pathParam(ISPB_PARAM_NAME, creationRequestDTO.getIspb())
            .when()
            .post(URL_PART_COMPLETE)
            .then()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .extract();
        //@formatter:on

    }

    @Test
    void shouldReturnBadRequestOnUpdateIndirectParticipantWhenHadStatusActiveAndIsUpdatingISPBAndCNPJ() {

        IndirectParticipantCreationRequestDTO creationRequestDTO = createIndirectParticipantCreationRequestMock();

        //@formatter:off
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(creationRequestDTO)
            .when()
            .post(URL_FILTERS)
            .then()
            .statusCode(HttpStatus.SC_CREATED)
            .extract();
        //@formatter:on

        ParticipantMipIndirectEntity indirectParticipantEntity =
            indirectParticipantMipService.findByIspb(Integer.valueOf(creationRequestDTO.getIspb())).get();

        indirectParticipantEntity.setStatus(participantMipIndirectStatusRepository
            .findById(IndirectParticipantStatusEnum.getIdByDto(IndirectParticipantStatusDTO.ACTIVE)).get());

        List<ParticipantMipIndirectHistoryEntity> histories =
            participantMipIndirectHistoryRepository.findAllByParticipantMip(indirectParticipantEntity);

        histories.add(indirectParticipantHistoryService.createHistoryEntityByType(indirectParticipantEntity,
            ParticipantMipIndirectHistoryEntity.Type.LOCAL_UPDATE));

        participantMipIndirectHistoryRepository.saveAll(histories);

        IndirectParticipantUpdateRequestDTO updateRequestDTO = createIndirectParticipantUpdateRequestMock();
        updateRequestDTO.setIspb(IspbUtils.leftPadIspb(NEW_ISPB));

        //@formatter:off
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(updateRequestDTO)
            .pathParam(ISPB_PARAM_NAME, creationRequestDTO.getIspb())
            .when()
            .post(URL_PART_COMPLETE)
            .then()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .extract();
        //@formatter:on

        updateRequestDTO.setIspb(IspbUtils.leftPadIspb(ISPB));
        updateRequestDTO.setTaxId(NEW_TX_ID);

        //@formatter:off
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(updateRequestDTO)
            .pathParam(ISPB_PARAM_NAME, creationRequestDTO.getIspb())
            .when()
            .post(URL_PART_COMPLETE)
            .then()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .extract();
        //@formatter:on

        updateRequestDTO.setIspb(IspbUtils.leftPadIspb(ISPB));
        updateRequestDTO.setTaxId(TX_ID);

        //@formatter:off
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(updateRequestDTO)
            .pathParam(ISPB_PARAM_NAME, creationRequestDTO.getIspb())
            .when()
            .post(URL_PART_COMPLETE)
            .then()
            .statusCode(HttpStatus.SC_OK)
            .extract();
        //@formatter:on

    }

    @Test
    void shouldReturnIndirectParticipantHistoryWhenIspbIsGiven() {

        IndirectParticipantCreationRequestDTO creationRequestDTO = createIndirectParticipantCreationRequestMock();

        //@formatter:off
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(creationRequestDTO)
            .when()
            .post(URL_FILTERS)
            .then()
            .statusCode(HttpStatus.SC_CREATED)
            .extract();
        //@formatter:on

        //@formatter:off
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(createIndirectParticipantUpdateRequestMock())
            .pathParam(ISPB_PARAM_NAME, creationRequestDTO.getIspb())
            .when()
            .post(URL_PART_COMPLETE)
            .then()
            .statusCode(HttpStatus.SC_OK);
        //@formatter:on

        //@formatter:off
        final ExtractableResponse<Response> response = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(StringUtils.EMPTY)
            .header(PAGE_SIZE_PARAM_NAME, PAGE_SIZE)
            .header(PAGE_NUMBER_PARAM_NAME, PAGE_NUMBER)
            .pathParam(ISPB_PARAM_NAME, creationRequestDTO.getIspb())
            .when()
            .get(URL_PART_HISTORY)
            .then()
            .statusCode(HttpStatus.SC_OK)
            .extract();
        //@formatter:on

        List<IndirectParticipantHistoryDTO> histories =
            response.body().jsonPath().getObject("data", PageableIndirectParticipantHistoryResponseDTO.class)
                .getContent();

        assertEquals(1, histories.stream()
            .filter(h -> IndirectParticipantHistoryEventTypeDTO.LOCAL_REGISTRATION.equals(h.getHistoryType())).count());
        assertEquals(1, histories.stream()
            .filter(h -> IndirectParticipantHistoryEventTypeDTO.LOCAL_UPDATE.equals(h.getHistoryType())).count());
    }

    @Test
    void shouldReturnBadRequestWhenRegisteringIndirectParticipantNotFound() {
        //@formatter:off
        final ExtractableResponse<Response> response = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(StringUtils.EMPTY)
            .pathParam(ISBP_PARAM_NAME, NOT_FOUND_ISBP)
            .when()
            .post(INDIRECT_PART_REGISTER_URL)
            .then()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .extract();
        //@formatter:on

        assertTrue(response.body().asString().contains("SPI-IND-001"));
    }

    @Test
    void shouldReturnBadRequestWhenRegisteringIndirectParticipantWithStatusNotAllowed() {
        ParticipantMipEntity participantMip = ParticipantMipIndirectDataSetUtil.createParticipantMip();
        ParticipantMipIndirectEntity participantMipIndirectEntity = ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository, participantMip);
        ParticipantMipIndirectStatusEntity participantMipIndirectStatus =
            ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectStatusEntity();

        participantMipIndirectEntity.setStatus(participantMipIndirectStatus);

        participantMipIndirectRepository.save(participantMipIndirectEntity);

        //@formatter:off
        final ExtractableResponse<Response> response = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(StringUtils.EMPTY)
            .pathParam(ISBP_PARAM_NAME, participantMip.getIspb())
            .when()
            .post(INDIRECT_PART_REGISTER_URL)
            .then()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .extract();
        //@formatter:on

        assertTrue(response.body().asString().contains("SPI-IND-008"));
    }

    @Test
    void shouldRegisterIndirectParticipantAndUpdateStatusToActiveWhenReceiveSuccessResponse() {
        when(mockedMessagesApi.sendsMessageV1(any(MessageSpecificationDTO.class)))
            .thenReturn(buildMessageSentResponseDTO());

        final ParticipantMipIndirectEntity participantMipIndirectEntity = ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                ParticipantMipIndirectDataSetUtil.createParticipantMip());
        final ParticipantMipIndirectStatusEntity participantMipIndirectStatus = participantMipIndirectStatusRepository
            .findById(IndirectParticipantStatusEnum.getIdByDto(INDIRECT_REGISTRATION_REQUEST_PENDING_STATUS))
            .orElse(null);

        participantMipIndirectEntity.setStatus(participantMipIndirectStatus);
        participantMipIndirectRepository.saveAndFlush(participantMipIndirectEntity);

        //@formatter:off
        final ExtractableResponse<Response> response = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(StringUtils.EMPTY)
            .pathParam(ISBP_PARAM_NAME, ParticipantMipIndirectDataSetUtil.ISPB)
            .when()
            .post(INDIRECT_PART_REGISTER_URL)
            .then()
            .statusCode(HttpStatus.SC_ACCEPTED)
            .extract();
        //@formatter:on

        final IndirectParticipantRegistrationResponseDTO registrationResponseDTO =
            response.body().jsonPath().getObject("data", IndirectParticipantRegistrationResponseDTO.class);

        assertNotNull(registrationResponseDTO);
        assertEquals(INDIRECT_REGISTRATION_REQUESTED_STATUS, registrationResponseDTO.getStatus());

        final EventEntity eventEntity = eventRepository
            .findByStatus(eventStatusRepository.getOne(EventStatus.WAITING_INDIRECT_REGISTRY_CONFIRM.getCode())).get(0);
        final String reda016 =
            getStringFromXmlFile(FROM_SUCCESS_REDA016).replace("<Id>99999010</Id>", "<Id>" + PARTICIPANT_ISPB + "</Id>")
                .replace("<MsgId>M9999901012345678901234567890123</MsgId>",
                    "<MsgId>" + eventEntity.getCorrelationId() + "</MsgId>");

        messageReceiver.readIncomingMessage(MessageCreationUtils.buildMessageReceiverJson(reda016));

        final List<ParticipantMipIndirectHistoryEntity> histories = participantMipIndirectHistoryRepository.findAll();
        final ParticipantMipIndirectEntity participantMipIndirectEntityUpdated = indirectParticipantInformationRetriever
            .findIndirectParticipantByIspbAndClearingStatusAndShowCanceled(ParticipantMipIndirectDataSetUtil.ISPB, false, true).get(0);

        assertTrue(histories.size() == 2);
        assertTrue(histories.stream().anyMatch(h -> h.getType().equals(CLEARING_REGISTRATION_RESPONSE_HIST_TYPE)));
        assertTrue(participantMipIndirectEntityUpdated.getStatus().getId() ==
                   IndirectParticipantStatusEnum.getIdByDto(IndirectParticipantStatusDTO.ACTIVE));
    }

    @Test
    void shouldRegisterIndirectParticipantAndUpdateStatusToActiveWhenReceiveRejectedWithIND2Response() {
        when(mockedMessagesApi.sendsMessageV1(any(MessageSpecificationDTO.class)))
            .thenReturn(buildMessageSentResponseDTO());

        final ParticipantMipIndirectEntity participantMipIndirectEntity = ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                ParticipantMipIndirectDataSetUtil.createParticipantMip());
        final ParticipantMipIndirectStatusEntity participantMipIndirectStatus = participantMipIndirectStatusRepository
            .findById(IndirectParticipantStatusEnum.getIdByDto(INDIRECT_REGISTRATION_REQUEST_PENDING_STATUS))
            .orElse(null);

        participantMipIndirectEntity.setStatus(participantMipIndirectStatus);
        participantMipIndirectRepository.saveAndFlush(participantMipIndirectEntity);

        //@formatter:off
        final ExtractableResponse<Response> response = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(StringUtils.EMPTY)
            .pathParam(ISBP_PARAM_NAME, ParticipantMipIndirectDataSetUtil.ISPB)
            .when()
            .post(INDIRECT_PART_REGISTER_URL)
            .then()
            .statusCode(HttpStatus.SC_ACCEPTED)
            .extract();
        //@formatter:on

        final IndirectParticipantRegistrationResponseDTO registrationResponseDTO =
            response.body().jsonPath().getObject("data", IndirectParticipantRegistrationResponseDTO.class);

        assertNotNull(registrationResponseDTO);
        assertEquals(INDIRECT_REGISTRATION_REQUESTED_STATUS, registrationResponseDTO.getStatus());

        final EventEntity eventEntity = eventRepository
            .findByStatus(eventStatusRepository.getOne(EventStatus.WAITING_INDIRECT_REGISTRY_CONFIRM.getCode())).get(0);
        final String reda016 =
            getStringFromXmlFile(FROM_REJECT_REDA016).replace("<Id>99999010</Id>", "<Id>" + PARTICIPANT_ISPB + "</Id>")
                .replace("<MsgId>M9999901012345678901234567890123</MsgId>",
                    "<MsgId>" + eventEntity.getCorrelationId() + "</MsgId>");

        messageReceiver.readIncomingMessage(MessageCreationUtils.buildMessageReceiverJson(reda016));

        final List<ParticipantMipIndirectHistoryEntity> histories = participantMipIndirectHistoryRepository.findAll();
        final ParticipantMipIndirectEntity participantMipIndirectEntityUpdated = indirectParticipantInformationRetriever
            .findIndirectParticipantByIspbAndClearingStatusAndShowCanceled(ParticipantMipIndirectDataSetUtil.ISPB, false, false).get(0);

        assertTrue(histories.size() == 2);
        assertTrue(histories.stream().anyMatch(h -> h.getType().equals(CLEARING_REGISTRATION_RESPONSE_HIST_TYPE)));
        assertTrue(participantMipIndirectEntityUpdated.getStatus().getId() ==
                   IndirectParticipantStatusEnum.getIdByDto(IndirectParticipantStatusDTO.ACTIVE));
    }

    @Test
    void shouldUpdateStatusToRejectedWhenReceiveClearingRejectedRegistrationResponse() {
        when(mockedMessagesApi.sendsMessageV1(any(MessageSpecificationDTO.class)))
            .thenReturn(buildMessageSentResponseDTO());

        final ParticipantMipIndirectEntity participantMipIndirectEntity = ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                ParticipantMipIndirectDataSetUtil.createParticipantMip());
        final ParticipantMipIndirectStatusEntity participantMipIndirectStatus = participantMipIndirectStatusRepository
            .findById(IndirectParticipantStatusEnum.getIdByDto(INDIRECT_REGISTRATION_REQUEST_PENDING_STATUS))
            .orElse(null);

        participantMipIndirectEntity.setStatus(participantMipIndirectStatus);
        participantMipIndirectRepository.saveAndFlush(participantMipIndirectEntity);

        //@formatter:off
        final ExtractableResponse<Response> response = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(StringUtils.EMPTY)
            .pathParam(ISBP_PARAM_NAME, ParticipantMipIndirectDataSetUtil.ISPB)
            .when()
            .post(INDIRECT_PART_REGISTER_URL)
            .then()
            .statusCode(HttpStatus.SC_ACCEPTED)
            .extract();
        //@formatter:on

        final String expectedRejectReason = "IND5";
        final List<ParticipantMipIndirectHistoryEntity> historyBeforeResponse =
            participantMipIndirectHistoryRepository.findAll();

        assertThat(historyBeforeResponse).hasSize(1);
        assertTrue(historyBeforeResponse.stream().noneMatch(containsReasonCode(expectedRejectReason)));

        final IndirectParticipantRegistrationResponseDTO registrationResponseDTO =
            response.body().jsonPath().getObject("data", IndirectParticipantRegistrationResponseDTO.class);

        assertNotNull(registrationResponseDTO);
        assertEquals(INDIRECT_REGISTRATION_REQUESTED_STATUS, registrationResponseDTO.getStatus());

        final EventEntity eventEntity = eventRepository
            .findByStatus(eventStatusRepository.getOne(EventStatus.WAITING_INDIRECT_REGISTRY_CONFIRM.getCode())).get(0);
        final String reda016 = formatRejectReda016Message(expectedRejectReason, eventEntity);

        messageReceiver.readIncomingMessage(MessageCreationUtils.buildMessageReceiverJson(reda016));

        final List<ParticipantMipIndirectHistoryEntity> histories = participantMipIndirectHistoryRepository.findAll();
        final ParticipantMipIndirectEntity participantMipIndirectEntityUpdated = indirectParticipantInformationRetriever
            .findIndirectParticipantByIspbAndClearingStatusAndShowCanceled(ParticipantMipIndirectDataSetUtil.ISPB, false, true).get(0);

        assertThat(histories).hasSize(2);
        assertTrue(histories.stream().map(ParticipantMipIndirectHistoryEntity::getType)
            .anyMatch(CLEARING_REGISTRATION_RESPONSE_HIST_TYPE::equals));
        assertTrue(histories.stream().anyMatch(containsReasonCode(expectedRejectReason)));
        assertEquals(participantMipIndirectEntityUpdated.getStatus().getId(),
            IndirectParticipantStatusEnum.getIdByDto(IndirectParticipantStatusDTO.REJECTED));
    }

    @NotNull
    private String formatRejectReda016Message(String expectedRejectReason, EventEntity eventEntity) {
        return getStringFromXmlFile(FROM_REJECT_REDA016)
            .replace("<Id>99999010</Id>", "<Id>" + PARTICIPANT_ISPB + "</Id>").replace("IND2", expectedRejectReason)
            .replace("<MsgId>M9999901012345678901234567890123</MsgId>",
                "<MsgId>" + eventEntity.getCorrelationId() + "</MsgId>");
    }

    @NotNull
    private Predicate<ParticipantMipIndirectHistoryEntity> containsReasonCode(String expectedRejectReason) {
        return history -> {
            final String rejectReasonCode = history.getRejectReasonCode();

            return rejectReasonCode != null && rejectReasonCode.equalsIgnoreCase(expectedRejectReason);
        };
    }

    @Test
    void shouldUpdateIndirectStatusToRejectAfterQueuedClearingResponseFollowedByRejectedMessage() {
        when(mockedMessagesApi.sendsMessageV1(any(MessageSpecificationDTO.class)))
            .thenReturn(buildMessageSentResponseDTO());

        ParticipantMipEntity participantMip = ParticipantMipIndirectDataSetUtil.createParticipantMip();
        ParticipantMipIndirectEntity participantMipIndirectEntity = ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository, participantMip);
        ParticipantMipIndirectStatusEntity participantMipIndirectStatus = participantMipIndirectStatusRepository
            .findById(IndirectParticipantStatusEnum.getIdByDto(INDIRECT_REGISTRATION_REQUEST_PENDING_STATUS))
            .orElse(null);

        participantMipIndirectEntity.setStatus(participantMipIndirectStatus);
        participantMipIndirectRepository.saveAndFlush(participantMipIndirectEntity);

        //@formatter:off
        final ExtractableResponse<Response> response = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(StringUtils.EMPTY)
            .pathParam(ISBP_PARAM_NAME, participantMip.getIspb())
            .when()
            .post(INDIRECT_PART_REGISTER_URL)
            .then()
            .statusCode(HttpStatus.SC_ACCEPTED)
            .extract();
        //@formatter:on

        IndirectParticipantRegistrationResponseDTO registrationResponseDTO =
            response.body().jsonPath().getObject("data", IndirectParticipantRegistrationResponseDTO.class);
        assertNotNull(registrationResponseDTO);
        assertEquals(INDIRECT_REGISTRATION_REQUESTED_STATUS, registrationResponseDTO.getStatus());

        var event = eventRepository
            .findByStatus(eventStatusRepository.getOne(EventStatus.WAITING_INDIRECT_REGISTRY_CONFIRM.getCode())).get(0);

        String reda016 =
            getStringFromXmlFile(FROM_QUEUED_REDA016).replace("<Id>99999010</Id>", "<Id>" + PARTICIPANT_ISPB + "</Id>")
                .replace("<MsgId>M9999901012345678901234567890123</MsgId>",
                    "<MsgId>" + event.getCorrelationId() + "</MsgId>");

        messageReceiver.readIncomingMessage(MessageCreationUtils.buildMessageReceiverJson(reda016));

        assertEquals(INDIRECT_REGISTRATION_QUEUED_STATUS, IndirectParticipantStatusEnum.getDtoById(
            participantMipIndirectRepository.findByIspbJoinFetchParticipantAndContacts(participantMip.getIspb())
                .orElse(null).getStatus().getId()));

        reda016 =
            getStringFromXmlFile(FROM_REJECT_REDA016).replace("<Id>99999010</Id>", "<Id>" + PARTICIPANT_ISPB + "</Id>")
                .replace("<MsgId>M9999901012345678901234567890123</MsgId>",
                    "<MsgId>" + event.getCorrelationId() + "</MsgId>");

        messageReceiver.readIncomingMessage(MessageCreationUtils.buildMessageReceiverJson(reda016));

        List<ParticipantMipIndirectHistoryEntity> histories = participantMipIndirectHistoryRepository.findAll();
        ParticipantMipIndirectEntity participantMipIndirectEntityUpdated = indirectParticipantInformationRetriever
            .findIndirectParticipantByIspbAndClearingStatusAndShowCanceled(participantMip.getIspb(), false, true).get(0);

        assertTrue(histories.size() == 3);
        assertTrue(histories.stream().anyMatch(h -> h.getType().equals(CLEARING_QUEUED_REG_RESPONSE_HIST_TYPE)));
        assertTrue(participantMipIndirectEntityUpdated.getStatus().getId() ==
                   IndirectParticipantStatusEnum.getIdByDto(IndirectParticipantStatusDTO.REJECTED));
    }

    @Test
    void shouldCancelIndirectParticipant() {
        IndirectParticipantCreationRequestDTO creationRequestDTO = createIndirectParticipantCreationRequestMock();

        //@formatter:off
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(creationRequestDTO)
            .when()
            .post(URL_FILTERS)
            .then()
            .statusCode(HttpStatus.SC_CREATED)
            .extract();
        //@formatter:on

        //@formatter:off
        final ExtractableResponse<Response> response = RestAssured
            .given()
            .pathParam(ISPB_PARAM_NAME, creationRequestDTO.getIspb())
            .when()
            .delete(URL_PART_COMPLETE)
            .then()
            .statusCode(HttpStatus.SC_OK)
            .extract();
        //@formatter:on

        assertNotNull(response);
        IndirectParticipantCancelmentResponseDTO responseDto =
            response.body().jsonPath().getObject("data", IndirectParticipantCancelmentResponseDTO.class);
        assertEquals(IndirectParticipantStatusDTO.CANCELED, responseDto.getStatus());
    }

    @Test
    void shouldReturnBadRequestOnCancelIndirectParticipantWhenStatusIsOtherThanWaitingToSendRegistrationToClearing() {
        IndirectParticipantCreationRequestDTO creationRequestDTO = createIndirectParticipantCreationRequestMock();

        //@formatter:off
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .body(creationRequestDTO)
            .when()
            .post(URL_FILTERS)
            .then()
            .statusCode(HttpStatus.SC_CREATED)
            .extract();
        //@formatter:on

        ParticipantMipIndirectEntity indirectParticipantEntity =
            indirectParticipantMipService.findByIspb(Integer.valueOf(creationRequestDTO.getIspb())).get();

        indirectParticipantEntity.setStatus(participantMipIndirectStatusRepository
            .findById(IndirectParticipantStatusEnum.getIdByDto(IndirectParticipantStatusDTO.ACTIVE)).get());

        List<ParticipantMipIndirectHistoryEntity> histories =
            participantMipIndirectHistoryRepository.findAllByParticipantMip(indirectParticipantEntity);

        histories.add(indirectParticipantHistoryService.createHistoryEntityByType(indirectParticipantEntity,
            ParticipantMipIndirectHistoryEntity.Type.LOCAL_UPDATE));

        participantMipIndirectHistoryRepository.saveAll(histories);
        participantMipIndirectRepository.save(indirectParticipantEntity);

        //@formatter:off
        final ExtractableResponse<Response> response = RestAssured
            .given()
            .pathParam(ISPB_PARAM_NAME, creationRequestDTO.getIspb())
            .when()
            .delete(URL_PART_COMPLETE)
            .then()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .extract();
        //@formatter:on

        assertNotNull(response);
        ErrorDTO responseDto =
            response.body().jsonPath().getList("error", ErrorDTO.class).get(0);
        assertEquals(ExceptionMessages.SPI_IND_011.getCode(), responseDto.getCode());

    }

    @Test
    void shouldReturnBadRequestOnCancelIndirectParticipantWhenIndirectParticipantIsNotFound() {

        //@formatter:off
        final ExtractableResponse<Response> response = RestAssured
            .given()
            .pathParam(ISPB_PARAM_NAME, IndirectUiApiDelegateImplIntegrationTest.ISPB)
            .when()
            .delete(URL_PART_COMPLETE)
            .then()
            .statusCode(HttpStatus.SC_BAD_REQUEST)
            .extract();
        //@formatter:on

        assertNotNull(response);
        ErrorDTO responseDto =
            response.body().jsonPath().getList("error", ErrorDTO.class).get(0);
        assertEquals(ExceptionMessages.SPI_IND_001.getCode(), responseDto.getCode());

    }

    @Test
    void shouldReturnOnlyActiveIndirect() {
        participantMipIndirectRepository.saveAndFlush(ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                ParticipantMipIndirectDataSetUtil.createParticipantMip()));

        participantMipIndirectRepository.saveAndFlush(ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                IndirectParticipantStatusEnum.CANCELED.getId(),
                ParticipantMipIndirectDataSetUtil.createParticipantMip(ISPB)));

        //@formatter:off
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .header(PAGE_SIZE_PARAM_NAME, PAGE_SIZE)
            .header(PAGE_NUMBER_PARAM_NAME, PAGE_NUMBER)
            .queryParam("ordering", ORDERING)
            .queryParam("orderingDirection", ORDERING_DIRECTION)
            .queryParam("status", IndirectParticipantStatusDTO.ACTIVE)
            .queryParam("showCanceledIndirects", true)
            .when()
            .get(URL_FILTERS)
            .then()
            .statusCode(HttpStatus.SC_OK)
            .assertThat()
            .body("data.content[0].status", equalTo(IndirectParticipantStatusEnum.ACTIVE.toString()));

        //@formatter:on
    }

    @Test
    void shouldReturnAllIndirectsIncludingCanceled() {
        participantMipIndirectRepository.saveAndFlush(ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                ParticipantMipIndirectDataSetUtil.createParticipantMip()));

        participantMipIndirectRepository.saveAndFlush(ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                IndirectParticipantStatusEnum.CANCELED.getId(),
                ParticipantMipIndirectDataSetUtil.createParticipantMip(ISPB)));

        //@formatter:off
        ExtractableResponse<Response> response = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .header(PAGE_SIZE_PARAM_NAME, PAGE_SIZE)
            .header(PAGE_NUMBER_PARAM_NAME, PAGE_NUMBER)
            .queryParam("ordering", ORDERING)
            .queryParam("orderingDirection", ORDERING_DIRECTION)
            .queryParam("showCanceledIndirects", true)
            .when()
            .get(URL_FILTERS)
            .then()
            .statusCode(HttpStatus.SC_OK)
            .extract();
        //@formatter:on

        int data = response.body().jsonPath().getList("data.content", IndirectParticipantIdentificationUIDTO.class).size();
        assertEquals(2, data);
    }

    @Test
    void shouldReturnAllExceptCanceledIndirects() {
        participantMipIndirectRepository.saveAndFlush(ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                ParticipantMipIndirectDataSetUtil.createParticipantMip()));

        participantMipIndirectRepository.saveAndFlush(ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                IndirectParticipantStatusEnum.CANCELED.getId(),
                ParticipantMipIndirectDataSetUtil.createParticipantMip(ISPB)));

        //@formatter:off
        RestAssured
            .given()
            .contentType(ContentType.JSON)
            .header(PAGE_SIZE_PARAM_NAME, PAGE_SIZE)
            .header(PAGE_NUMBER_PARAM_NAME, PAGE_NUMBER)
            .queryParam("ordering", ORDERING)
            .queryParam("orderingDirection", ORDERING_DIRECTION)
            .queryParam("showCanceledIndirects", false)
            .when()
            .get(URL_FILTERS)
            .then()
            .statusCode(HttpStatus.SC_OK)
            .assertThat()
            .body("data.content[0].status", equalTo(IndirectParticipantStatusEnum.ACTIVE.toString()));
        //@formatter:on
    }

    private IndirectParticipantCreationRequestDTO createIndirectParticipantCreationRequestMock() {
        IndirectParticipantCreationRequestDTO indirectParticipant = new IndirectParticipantCreationRequestDTO();
        indirectParticipant.setStatus(IndirectParticipantStatusDTO.WAITING_TO_SEND_REGISTRATION_TO_CLEARING);
        indirectParticipant.setAccountNumber(ACCOUNT_NUMBER);
        indirectParticipant.setBranch(BRANCH);
        indirectParticipant.setContacts(createIndirectParticipantContactListMock());
        indirectParticipant.setContractEndDate(CONTRACT_END_DATE);
        indirectParticipant.setContractInitDate(CONTRACT_INIT_DATE);
        indirectParticipant.setCorporateName(CORPORATE_NAME);
        indirectParticipant.setIspb(IspbUtils.leftPadIspb(ISPB));
        indirectParticipant.setFinancial(createIndirectParticipantFinancialFieldsMock());
        indirectParticipant.setName(NAME);
        indirectParticipant.setTaxId(TX_ID);
        return indirectParticipant;
    }

    private IndirectParticipantUpdateRequestDTO createIndirectParticipantUpdateRequestMock() {
        IndirectParticipantUpdateRequestDTO indirectParticipant = new IndirectParticipantUpdateRequestDTO();
        indirectParticipant.setStatus(IndirectParticipantStatusDTO.WAITING_TO_SEND_REGISTRATION_TO_CLEARING);
        indirectParticipant.setAccountNumber(ACCOUNT_NUMBER);
        indirectParticipant.setBranch(BRANCH);
        indirectParticipant.setContacts(createIndirectParticipantContactListMock());
        indirectParticipant.setContractEndDate(CONTRACT_END_DATE);
        indirectParticipant.setContractInitDate(CONTRACT_INIT_DATE);
        indirectParticipant.setCorporateName(CORPORATE_NAME);
        indirectParticipant.setIspb(IspbUtils.leftPadIspb(ISPB));
        indirectParticipant.setFinancial(createIndirectParticipantFinancialFieldsMock());
        indirectParticipant.setName(NAME);
        indirectParticipant.setTaxId(TX_ID);
        return indirectParticipant;
    }

    private IndirectParticipantFinancialFieldsUIDTO createIndirectParticipantFinancialFieldsMock() {
        IndirectParticipantFinancialFieldsUIDTO indirectParticipantFinancialFields =
            new IndirectParticipantFinancialFieldsUIDTO();
        indirectParticipantFinancialFields.setBalanceLowerThreshold(new BigDecimal("100"));
        indirectParticipantFinancialFields.setBalanceValidationThreshold(true);
        indirectParticipantFinancialFields.setCredTransactionType(123);
        indirectParticipantFinancialFields.setDebitTransactionType(555);
        indirectParticipantFinancialFields.setDrawbackReceiveTransactType(999);
        indirectParticipantFinancialFields.setDrawbackSentTransactType(111);
        indirectParticipantFinancialFields.setQrcodeCredTransactionType(789);
        return indirectParticipantFinancialFields;
    }

    private List<IndirectParticipantContactDTO> createIndirectParticipantContactListMock() {
        List<IndirectParticipantContactDTO> indirectParticipantContactList = new ArrayList<>();
        IndirectParticipantContactDTO indirectParticipantContact = new IndirectParticipantContactDTO();
        indirectParticipantContact.setDepartment("DEPARTMENT");
        indirectParticipantContact.setEmail("EMAIL@EMAIL.COM");
        indirectParticipantContact.setName("CONTACT_NAME");
        indirectParticipantContact.setPhone("555555555");
        indirectParticipantContactList.add(indirectParticipantContact);
        return indirectParticipantContactList;
    }

    private static MessageSentResponseDTO buildMessageSentResponseDTO() {
        MessageSentResponseDTO messageSentResponseDTO = new MessageSentResponseDTO();
        messageSentResponseDTO.setPiResourceID(PI_RESOURCE_ID);
        return messageSentResponseDTO;
    }

}
