package matera.spi.main.domain.service;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.persistence.ParticipantRepository;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@IntegrationTest
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class ParticipantServiceTest  {

    private static final int AMOUNT_PARTICIPANT = 2;
    public static final Integer ISPB_BAR = 123;
    public static final Integer ISPB_FOO = 456;
    public static final String NAME_BAR = "BAR";
    public static final String NAME_FOO = "FOO";

    @Autowired
    private ParticipantRepository participantRepository;

    @Autowired
    private ParticipantService participantService;

    @AfterAll
    void cleanData(){
        participantRepository.deleteById(ISPB_BAR);
        participantRepository.deleteById(ISPB_FOO);
    }

    @Test
    void testFindByIspb() {

        // Given
        var ispb = 123;

        var participantEntity = participantEntityMock(ISPB_BAR, NAME_BAR);
        var expected = Optional.of(participantEntity);

        participantRepository.save(participantEntity);

        // When
        var actual = participantService.findByIspb(ispb);

        // Then,
        assertEquals(expected, actual);
    }

    @Test
    void testSave() {

        // Given
        var ispb = 123;

        var participantEntity = participantEntityMock(ISPB_BAR, NAME_BAR);
        var expected = Optional.of(participantEntity);

        // When
        participantService.save(participantEntity);

        var actual = participantRepository.findByIspb(ispb);

        // Then
        assertEquals(expected, actual);
    }

    @Test
    void shouldFindAllParticipant() {
        participantRepository.saveAll(participantsEntityMock());

        var participants = participantService.findAllParticipant();

        assertFalse(participants.isEmpty());
        assertTrue(participants.size() >= AMOUNT_PARTICIPANT);
    }

    private List<ParticipantEntity> participantsEntityMock() {
        return List.of(participantEntityMock(ISPB_BAR, NAME_BAR), participantEntityMock(ISPB_FOO, NAME_FOO));
    }

    private ParticipantEntity participantEntityMock(Integer ispb, String name) {

        var participantEntity = new ParticipantEntity();

        participantEntity.setIspb(ispb);
        participantEntity.setName(name);
        participantEntity.setDirectParticipant(false);
        participantEntity.setActive(true);

        return participantEntity;
    }

}
