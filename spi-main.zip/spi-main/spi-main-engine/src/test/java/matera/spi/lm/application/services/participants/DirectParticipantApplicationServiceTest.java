package matera.spi.lm.application.services.participants;

import matera.spi.dto.IspbQueryDTO;
import matera.spi.lm.application.service.participantService.DirectParticipantApplicationService;
import matera.spi.lm.domain.service.ParticipantDomainService;
import matera.spi.lm.domain.service.event.IspbUtils;
import matera.spi.lm.transactions.port.IndirectParticipantPort;
import matera.spi.main.config.MainEngineConfiguration;
import matera.spi.main.domain.model.ConfigEntity;
import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.domain.service.ConfigurationService;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.anyString;

import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;

@ExtendWith(MockitoExtension.class)
public class DirectParticipantApplicationServiceTest {

    private static final Integer MOCKED_ISPB_INTEGER = 1234567;
    private static final String MOCKED_ISPB_STRING = "01234567";
    private static final String MOCKED_NAME_STRING = "Test name";

    private static final String INDIRECT1_ISPB = "07654321";
    private static final String INDIRECT2_ISPB = "03216547";
    private static final String INDIRECT1_NAME = "Indirect1";
    private static final String INDIRECT2_NAME = "Indirect2";

    @InjectMocks
    private DirectParticipantApplicationService directParticipantService;

    @Mock
    private ConfigurationService configurationService;

    @Mock
    private ParticipantDomainService participantDomainService;

    @Mock
    private MainEngineConfiguration mainEngineConfiguration;

    @Mock
    private IndirectParticipantPort indirectParticipantPort;

    @BeforeEach
    void init() {
        final ParticipantEntity participantEntity = buildParticipantEntity();
        final ConfigEntity mockedConfigEntity = buildConfigEntity();
        final List<IspbQueryDTO> indirectIspbList = buildIndirectIspb();

        Mockito.doReturn(true).when(mainEngineConfiguration).isDirectPsp();
        Mockito.lenient().when(configurationService.findConfig()).thenReturn(mockedConfigEntity);
        Mockito.doReturn(IspbUtils.leftPadIspb(MOCKED_ISPB_INTEGER.toString())).when(configurationService).findByIspb();
        Mockito.lenient().doReturn(participantEntity).when(participantDomainService).getParticipant(anyString());
        Mockito.doReturn(indirectIspbList).when(indirectParticipantPort).getIndirectParticipantByIspb(anyString());
    }

    private List<IspbQueryDTO> buildIndirectIspb() {
        List<IspbQueryDTO> indirectIspbList = new ArrayList<>();
        indirectIspbList.add(buildIndirectIspbDTO(INDIRECT1_ISPB, INDIRECT1_NAME));
        indirectIspbList.add(buildIndirectIspbDTO(INDIRECT2_ISPB, INDIRECT2_NAME));
        return indirectIspbList;
    }

    private IspbQueryDTO buildDirectIspbDTO(String ispb, String name) {
        final IspbQueryDTO ispbQueryDTO = new IspbQueryDTO();
        ispbQueryDTO.setName(name);
        ispbQueryDTO.setIspb(ispb);
        ispbQueryDTO.setIsLocalIspb(TRUE);
        return ispbQueryDTO;
    }

    private IspbQueryDTO buildIndirectIspbDTO(String ispb, String name) {
        final IspbQueryDTO ispbQueryDTO = new IspbQueryDTO();
        ispbQueryDTO.setName(name);
        ispbQueryDTO.setIspb(ispb);
        ispbQueryDTO.setIsLocalIspb(FALSE);
        return ispbQueryDTO;
    }

    @Test
    void shouldReturnListWithDirectAndIndirectIspb() {
        final List<IspbQueryDTO> expectedIspbQueryList = buildExpectedList();
        final List<IspbQueryDTO> actualIspbQueryList = directParticipantService.getIspbQueryList();

        Assertions.assertEquals(expectedIspbQueryList, actualIspbQueryList);
    }

    private List<IspbQueryDTO> buildExpectedList() {
        List<IspbQueryDTO> ispbQueryDTOList = new ArrayList<>();
        ispbQueryDTOList.add(buildDirectIspbDTO(MOCKED_ISPB_STRING, MOCKED_NAME_STRING));
        ispbQueryDTOList.addAll(buildIndirectIspb());
        return ispbQueryDTOList;
    }

    private ConfigEntity buildConfigEntity() {
        final ConfigEntity configEntity = new ConfigEntity();
        configEntity.setIspb(MOCKED_ISPB_INTEGER);
        return configEntity;
    }

    private ParticipantEntity buildParticipantEntity() {
        final ParticipantEntity participantEntity = new ParticipantEntity();
        participantEntity.setName(MOCKED_NAME_STRING);
        participantEntity.setIspb(MOCKED_ISPB_INTEGER);

        return participantEntity;
    }
}
