package matera.spi.main.domain.service.config;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.service.event.financial.action.CreditFinancialAction;
import matera.spi.main.domain.service.event.financial.action.DoNothingFinancialAction;
import matera.spi.main.domain.service.event.financial.action.FinancialActionHandler;
import matera.spi.main.domain.service.event.financial.action.RevertFinancialAction;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

@IntegrationTest
class FinancialActionConfigurationTest {

	@Autowired
	@Qualifier(FinancialActionConfiguration.FINANCIAL_ACTION_HANDLER)
	private Map<String, FinancialActionHandler> financialActionHandlers;

	@Test
	void shouldConfigureTheMapWithTheFinancialActionHandlers() {
		assertThat(financialActionHandlers.get("CREDIT")).isInstanceOf(CreditFinancialAction.class);
		assertThat(financialActionHandlers.get("NOTHING")).isInstanceOf(DoNothingFinancialAction.class);
		assertThat(financialActionHandlers.get("REVERT")).isInstanceOf(RevertFinancialAction.class);
	}

}
