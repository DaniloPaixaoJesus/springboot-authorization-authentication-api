package matera.spi.indirect.application.service.mapper;

import matera.spi.dto.IndirectParticipantRescissionResponseDTO;
import matera.spi.dto.IndirectParticipantStatusDTO;
import matera.spi.indirect.domain.model.ParticipantMipIndirectEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectHistoryEntity;
import matera.spi.indirect.util.EventDataSetUtil;
import matera.spi.indirect.util.ParticipantMipIndirectDataSetUtil;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class IndirectParticipantRescissionResponseDTOMapperTest {

    public static final String STATUS_ATTR_NAME = "status";

    @Test
    void shouldMapEntityToDto() {
        final ParticipantMipIndirectEntity participantMipIndirectEntity = ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(
                ParticipantMipIndirectDataSetUtil.getMockedStatusRepoReturningActiveById(),
                ParticipantMipIndirectDataSetUtil.createParticipantMip());

        final ParticipantMipIndirectHistoryEntity participantMipIndirectHistoryEntity =
            ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectHistoryEntity(participantMipIndirectEntity);

        final IndirectParticipantRescissionResponseDTO expectedDto =
            IndirectParticipantRescissionResponseDTOMapper.mapEntityToDto(participantMipIndirectHistoryEntity);

        final IndirectParticipantStatusDTO expectedStatus =
            EventDataSetUtil.INDIRECT_PARTICIPANT_STATUS_ENUM.toDto();

        assertThat(expectedDto).hasFieldOrPropertyWithValue(STATUS_ATTR_NAME, expectedStatus);
    }

}
