package matera.spi.lm.rest;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.matera.spi.messaging.api.MessagesApi;
import com.matera.spi.messaging.api.SPIMessagingApis;
import com.matera.spi.messaging.model.MessageSentResponseDTO;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import matera.spi.commons.IntegrationTest;
import matera.spi.dto.DetailsDTO;
import matera.spi.dto.EndToEndIDRequestDTO;
import matera.spi.dto.EventStatusDTO;
import matera.spi.dto.MipEventDTO;
import matera.spi.dto.PageableTransactionDetailDTO;
import matera.spi.dto.PageableTransactionDetailResponseUIDTO;
import matera.spi.dto.TransactionDetailDTO;
import matera.spi.dto.TransactionDetailsRequestUIDTO;
import matera.spi.main.domain.model.ConfigEntity;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.domain.service.ConfigurationService;
import matera.spi.main.domain.service.MessageSender;
import matera.spi.main.domain.service.event.receiver.MessageReceiver;
import matera.spi.main.dto.MessageReceiverDTO;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.MessageRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.messaging.support.GenericMessage;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static matera.spi.utils.LocalDateTimeUtils.formatToQueryParamPattern;
import static matera.spi.utils.LocalDateTimeUtils.getMinLocalDateTime;
import static matera.spi.utils.LocalDateTimeUtils.getTodayUTC;
import static org.mockito.Mockito.when;

@IntegrationTest
public class TransactionQueryDetailsFlowTest  {

    // -- URIs --
    private static final String POST_END_TO_END_ID_URI = "/ui/v1/return/end-to-end-id";
    private static final String TRANSACTION_QUERY_URI = "/ui/v1/transaction/details/queries";

    // -- VARIABLES --
    private static final Integer INTEGER_ONE = 1;
    private static final String PI_RESOURCE_ID = "PI-RESOURCE-ID-TEST-TRANSACTION";
    private static final String PI_RESOURCE_ID_2 = "PI-RESOURCE-ID-TEST-TRANSACTION_2";
    private static String END_TO_END_ID;
    private static UUID TRANSACTION_QUERY_EVENT_UUID;

    private static final String CAMT_054_CONSULTA_LANCAMENTO_PATH = "camt.054/camt.054_consulta_lancamento.xml";

    @LocalServerPort
    private int port;

    @Autowired
    private ConfigurationService configurationService;

    @Autowired
    private MessageReceiver messageReceiver;

    @Autowired
    private MessageRepository messageRepository;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private EventRepository eventRepository;

    @Autowired
    private MessageSender messageSender;
    @Autowired
    private SPIMessagingApis spiMessagingApisBean;
    @Mock
    private SPIMessagingApis mockedSpiMessagingApis;
    @Mock
    private MessagesApi mockedMessagesApi;

    @BeforeEach
    void init() {
        RestAssured.port = port;
        when(mockedSpiMessagingApis.messagesApi()).thenReturn(mockedMessagesApi);
        messageSender.setSpiMessagingApis(mockedSpiMessagingApis);
    }

    @AfterEach
    void clearDB() {
        eventRepository.deleteAll();
        messageRepository.deleteAll();

        messageSender.setSpiMessagingApis(spiMessagingApisBean);
    }

    @Test
    void shouldExecuteAllTransactionFlow() {
        shouldGetEndToEndIdFromLocalISPB();
        shouldReturnEventUUIDWhenSendPostRequestToTransactionQueryDetails();
        shouldReturnPageableResponseWithoutDetailsDTOFilledWhenMessagingNotSentAnyCAMT054Response();
        shouldProccessRequestWhenMessagingSentCAMT054Response();
        shouldReturnPageableResponseWithDetailsDTOFilledWhenMessagingSentCAMT054Response();
    }

    void shouldGetEndToEndIdFromLocalISPB() {
        final String endToEndId = RestAssured.given()
            .log().all()
            .contentType(ContentType.JSON)
            .body(buildEndToEndIdRequest())
            .when()
            .post(POST_END_TO_END_ID_URI)
            .getBody().jsonPath()
            .getString("data.endToEndID");

        Assertions.assertNotNull(endToEndId);
        END_TO_END_ID = endToEndId;
    }

    void shouldReturnEventUUIDWhenSendPostRequestToTransactionQueryDetails() {
        Mockito.doReturn(buildMessageSentResponseDTO()).when(mockedMessagesApi).sendsMessageV1(Mockito.any());

        final UUID eventUUID = RestAssured.given()
            .log().all()
            .contentType(ContentType.JSON)
            .body(buildTransactionDetailsRquestUI())
            .when()
            .post(TRANSACTION_QUERY_URI)
            .getBody().jsonPath()
            .getUUID("data.eventUuid");

        Assertions.assertNotNull(eventUUID);

        TRANSACTION_QUERY_EVENT_UUID = eventUUID;
    }

    void shouldReturnPageableResponseWithoutDetailsDTOFilledWhenMessagingNotSentAnyCAMT054Response() {
        final PageableTransactionDetailResponseUIDTO pageableTransactionDetailResonseDTO =
            RestAssured.given()
                .log().all()
                .given()
                .header("pageSize", 5)
                .header("pageNumber", 0)
                .queryParam("startTimestampUtc", formatDateTimeToQueryParamFormat(getTodayUTC()))
                .queryParam("endTimestampUtc", formatDateTimeToQueryParamFormat(getTodayUTC().plusDays(1))).when()
                .get(TRANSACTION_QUERY_URI)
                .then().extract()
                .as(PageableTransactionDetailResponseUIDTO.class);

        Assertions.assertNotNull(pageableTransactionDetailResonseDTO);
        Assertions.assertNotNull(pageableTransactionDetailResonseDTO.getData());

        final PageableTransactionDetailDTO pageableTransactionDTO = pageableTransactionDetailResonseDTO.getData();
        Assertions.assertEquals(INTEGER_ONE, pageableTransactionDTO.getNumberOfElements());

        final TransactionDetailDTO content = pageableTransactionDetailResonseDTO.getData().getContent().get(0);
        final MipEventDTO actualMipEvent = content.getMipEvent();
        Assertions.assertEquals(new DetailsDTO(), content.getDetails());
        assertMipEventDTO(buildExpectedMipEvent(14, "Query sent"), actualMipEvent);
    }

    void shouldProccessRequestWhenMessagingSentCAMT054Response() {
        final MessageEntity messageEntity = messageRepository.findMessageEntityByPiResourceId(PI_RESOURCE_ID).get();
        final String camt054 = formatCamt054(messageEntity);

        messageReceiver.onMessage(new GenericMessage(buildMessageReceiverDTO(camt054)));
    }

    void shouldReturnPageableResponseWithDetailsDTOFilledWhenMessagingSentCAMT054Response() {
        final PageableTransactionDetailResponseUIDTO pageableTransactionDetailResonseDTO =
            RestAssured.given()
                .log().all()
                .given()
                .header("pageSize", 5)
                .header("pageNumber", 0)
                .queryParam("startTimestampUtc", formatDateTimeToQueryParamFormat(getTodayUTC()))
                .queryParam("endTimestampUtc", formatDateTimeToQueryParamFormat(getTodayUTC().plusDays(1))).when()
                .get(TRANSACTION_QUERY_URI)
                .then().extract()
                .as(PageableTransactionDetailResponseUIDTO.class);

        Assertions.assertNotNull(pageableTransactionDetailResonseDTO);
        Assertions.assertNotNull(pageableTransactionDetailResonseDTO.getData());

        final PageableTransactionDetailDTO pageableTransactionDTO = pageableTransactionDetailResonseDTO.getData();
        Assertions.assertEquals(INTEGER_ONE, pageableTransactionDTO.getNumberOfElements());

        final TransactionDetailDTO content = pageableTransactionDetailResonseDTO.getData().getContent().get(0);
        final MipEventDTO actualMipEvent = content.getMipEvent();
        assertMipEventDTO(buildExpectedMipEvent(3, "Success"), actualMipEvent);

        final DetailsDTO expectedDetails = buildExpectedDetailsDTO();
        final DetailsDTO actualDetails = content.getDetails();
        Assertions.assertEquals(expectedDetails, actualDetails);
    }

    private void assertMipEventDTO(MipEventDTO expected, MipEventDTO actual) {
        Assertions.assertEquals(expected.getEndToEndId(), actual.getEndToEndId());
        Assertions.assertEquals(expected.getEventUUID(), actual.getEventUUID());
        Assertions.assertEquals(expected.getHasPermission(), actual.getHasPermission());

        final EventStatusDTO expectedStatus = expected.getStatus();
        final EventStatusDTO actualStatus = actual.getStatus();
        Assertions.assertEquals(expectedStatus.getCode(), actualStatus.getCode());
        Assertions.assertEquals(expectedStatus.getDescription(), actualStatus.getDescription());
    }

    private MipEventDTO buildExpectedMipEvent(Integer code, String description) {
        MipEventDTO mipEventDTO = new MipEventDTO();
        mipEventDTO.setEndToEndId(END_TO_END_ID);
        mipEventDTO.setEventUUID(TRANSACTION_QUERY_EVENT_UUID);
        mipEventDTO.setStatus(buildEventDTO(code, description));
        mipEventDTO.setHasPermission(Boolean.TRUE);
        return mipEventDTO;
    }

    private EventStatusDTO buildEventDTO(Integer code, String description) {
        EventStatusDTO eventStatusDTO = new EventStatusDTO();
        eventStatusDTO.setCode(code);
        eventStatusDTO.setDescription(description);
        return  eventStatusDTO;
    }

    private DetailsDTO buildExpectedDetailsDTO() {
        final DetailsDTO detailsDTO = new DetailsDTO();
        detailsDTO.setEffectuationBalanceTimestamp(LocalDateTime.parse("2020-01-01T08:30:12.000Z", DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")));
        detailsDTO.setTransactionType(DetailsDTO.TransactionTypeEnum.DEBIT);
        detailsDTO.setValue(new BigDecimal("1000.00"));
        detailsDTO.setIspbDebtor("13370835");
        detailsDTO.setIspbCreditor("00255564");
        return detailsDTO;
    }

    private MessageSentResponseDTO buildMessageSentResponseDTO() {
        final MessageSentResponseDTO messageSentResponseDTO = new MessageSentResponseDTO();
        messageSentResponseDTO.setPiResourceID(PI_RESOURCE_ID);
        return messageSentResponseDTO;
    }

    private String formatCamt054(MessageEntity messageEntity) {
        final String stringFromXmlFile = getStringFromXmlFile(CAMT_054_CONSULTA_LANCAMENTO_PATH);
        return String.format(stringFromXmlFile, messageEntity.getMessageIdXml());
    }

    private String buildMessageReceiverDTO(String camt054) {
        final MessageReceiverDTO messageReceiverDTO =
            MessageReceiverDTO.builder()
                .messageType("camt.054.spi.1.2")
                .piResourceId(PI_RESOURCE_ID_2)
                .xml(camt054)
                .build();
        try {
            return objectMapper.writeValueAsString(messageReceiverDTO);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        return "";
    }

    private String formatDateTimeToQueryParamFormat(LocalDate referenceDate) {
        return formatToQueryParamPattern(getMinLocalDateTime(referenceDate));
    }

    private TransactionDetailsRequestUIDTO buildTransactionDetailsRquestUI() {
        final TransactionDetailsRequestUIDTO transactionDetailsRequestDTO = new TransactionDetailsRequestUIDTO();
        transactionDetailsRequestDTO.setEndToEndId(END_TO_END_ID);

        return transactionDetailsRequestDTO;
    }

    private EndToEndIDRequestDTO buildEndToEndIdRequest() {
        final ConfigEntity config = configurationService.findConfig();
        final EndToEndIDRequestDTO requestDTO = new EndToEndIDRequestDTO();
        requestDTO.setIspb(config.getIspb());

        return requestDTO;
    }
}
