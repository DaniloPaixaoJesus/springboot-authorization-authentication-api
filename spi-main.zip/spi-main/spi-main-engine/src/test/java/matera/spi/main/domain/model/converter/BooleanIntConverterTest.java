package matera.spi.main.domain.model.converter;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;


public class BooleanIntConverterTest {

    private static final int ONE = 1;
    private static final int ZERO = 0;
    private static final int VALUE_GREATER_THAN_ONE = 2;
    private static final int VALUE_LOWER_THAN_ONE = -1;

    @Test
    @DisplayName("Should return 'true' if the column value is '1 (one)'.")
    public void returnTrueWhenColumnValueIsOne(){

        BooleanIntConverter converter = new BooleanIntConverter();

        Boolean actualValue = converter.convertToEntityAttribute(ONE);

        assertTrue(actualValue);
    }

    @Test
    @DisplayName("Should return 'false' if the column value is greater than '1 (one)'.")
    public void returnFalseWhenColumnValueIsGreaterThanOne(){

        BooleanIntConverter converter = new BooleanIntConverter();

        Boolean actualValue = converter.convertToEntityAttribute(VALUE_GREATER_THAN_ONE);

        assertFalse(actualValue);
    }

    @Test
    @DisplayName("Should return 'false' if the column value is lower than '1 (one)'.")
    public void returnFalseWhenColumnValueIsLowerThanOne(){

        BooleanIntConverter converter = new BooleanIntConverter();

        Boolean actualValue = converter.convertToEntityAttribute(VALUE_LOWER_THAN_ONE);

        assertFalse(actualValue);
    }

    @Test
    @DisplayName("Should return 'false' if the column value is 'null'.")
    public void returnFalseWhenColumnValueIsNull(){

        BooleanIntConverter converter = new BooleanIntConverter();

        Boolean actualValue = converter.convertToEntityAttribute(null);

        assertFalse(actualValue);
    }

    @Test
    @DisplayName("Should return '1 (one)' if the attribute value is 'true'.")
    public void returnOneWhenAttributeValueIsTrue(){

        BooleanIntConverter converter = new BooleanIntConverter();

        Integer actualValue = converter.convertToDatabaseColumn(true);

        assertEquals(ONE, actualValue);
    }

    @Test
    @DisplayName("Should return '0 (zero)' if the attribute value is 'false'.")
    public void returnZeroWhenAttributeValueIsFalse(){

        BooleanIntConverter converter = new BooleanIntConverter();

        Integer actualValue = converter.convertToDatabaseColumn(false);

        assertEquals(ZERO, actualValue);
    }

    @Test
    @DisplayName("Should return '0 (zero)' if the attribute value is 'null'.")
    public void returnZeroWhenAttributeValueIsNull(){

        BooleanIntConverter converter = new BooleanIntConverter();

        Integer actualValue = converter.convertToDatabaseColumn(null);

        assertEquals(ZERO, actualValue);
    }
}

