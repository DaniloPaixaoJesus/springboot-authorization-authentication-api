package matera.spi.main.domain.service.event.financial.action;

import matera.spi.main.domain.service.event.Event;
import matera.spi.main.domain.service.transaction.AccountTransactionReverter;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;

@ExtendWith(MockitoExtension.class)
class RevertFinancialActionTest {

	@InjectMocks
	private RevertFinancialAction revertFinancialAction;
	@Mock
	private AccountTransactionReverter accountTransactionReverter;

	//TODO: verificar o porque não está vindo o TransactionResultEntity
	@Disabled
	@Test
	@DisplayName("when event entity does not have a transaction result entity should thrown IllegalStateException")
	void shouldThrownIllegalStateExceptionWhenEventEntityDoesNotHaveATransactionResultEntity() {
		Event event = mock(Event.class);

		assertThatThrownBy(() -> revertFinancialAction.handle(event))
			.isInstanceOf(IllegalStateException.class)
			.hasMessage("No EventEntity to revert");
	}
}
