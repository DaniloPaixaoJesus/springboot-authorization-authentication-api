package matera.spi.indirect.domain.service;

import matera.spi.indirect.domain.model.ParticipantMipIndirectStatusEntity;
import matera.spi.indirect.domain.model.enums.IndirectParticipantStatusEnum;
import matera.spi.indirect.persistence.ParticipantMipIndirectStatusRepository;
import matera.spi.indirect.util.ParticipantMipIndirectDataSetUtil;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.opentest4j.AssertionFailedError;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class IndirectParticipantStatusServiceTest {

    @Mock
    private ParticipantMipIndirectStatusRepository participantMipIndirectStatusRepository;

    @InjectMocks
    private IndirectParticipantStatusService indirectParticipantStatusService;

    @Test
    void shouldFindIndirectPossibleActions() {
        final ParticipantMipIndirectStatusEntity entityToMock =
            ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectStatusEntity();

        doReturn(Optional.of(entityToMock)).when(participantMipIndirectStatusRepository)
            .findById(eq(IndirectParticipantStatusEnum.ACTIVE.getId()));

        final ParticipantMipIndirectStatusEntity entityFromRepository =
            indirectParticipantStatusService.findById(IndirectParticipantStatusEnum.ACTIVE.getId())
                .orElseThrow(AssertionFailedError::new);

        verify(participantMipIndirectStatusRepository).findById(eq(IndirectParticipantStatusEnum.ACTIVE.getId()));
        assertNotNull(entityFromRepository);
        assertEquals(entityToMock, entityFromRepository);
    }

}
