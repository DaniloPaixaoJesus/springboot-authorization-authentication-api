package matera.spi.lm.application.services;

import com.matera.client.exception.BadRequestException;
import com.matera.client.exception.InternalServerErrorException;
import com.matera.client.exception.SecurityErrorException;
import com.matera.client.exception.ServiceUnavailableException;

import matera.spi.dto.BalanceLocalIPAccountDTO;
import matera.spi.dto.PostBalanceAdjustmentRequestDTO;
import matera.spi.lm.application.service.balanceAdjustmentApplicationService.DirectBalanceAdjustmentApplicationService;
import matera.spi.lm.application.service.balanceIPAccountService.DirectBalanceIPAccountService;
import matera.spi.lm.application.service.validation.BalanceAdjustmentValidator;
import matera.spi.lm.domain.model.enums.EnumMessageType;
import matera.spi.lm.domain.model.event.IpAccountBalanceAdjustmentDetailsEntity;
import matera.spi.lm.domain.model.event.IpAccountBalanceAdjustmentEventEntity;
import matera.spi.lm.domain.model.event.MessageType;
import matera.spi.lm.domain.service.event.IpAccountBalanceAdjustmentEvent;
import matera.spi.lm.exception.LiquidityManagementException;
import matera.spi.lm.persistence.IpAccountBalanceAdjustmentRepository;
import matera.spi.main.apisInterface.EventFactoryApiService;
import matera.spi.main.apisInterface.IpAccountApiService;
import matera.spi.main.config.MainEngineConfiguration;
import matera.spi.main.domain.model.enums.EnumTransactionType;
import matera.spi.utils.LocalDateTimeUtils;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;

@ExtendWith(MockitoExtension.class)
public class BalanceAdjustmentApplicationServiceTest {

    private static final String TRANSACTION_ID = "E008921002020021708289943624de78";

    @InjectMocks
    private DirectBalanceAdjustmentApplicationService balanceAdjustmentApplicationService;

    @Mock
    BalanceAdjustmentValidator balanceAdjustmentValidator;

    @Mock
    EventFactoryApiService eventFactoryApiService;

    @Mock
    IpAccountBalanceAdjustmentEvent balanceAdjustmentEventMock;

    @Mock
    IpAccountBalanceAdjustmentEventEntity balanceAdjustmentEventEntityMock;

    @Mock
    IpAccountBalanceAdjustmentDetailsEntity balanceAdjustmentDetailsEntityMock;

    @Mock
    MainEngineConfiguration mainEngineConfiguration;

    @Mock
    DirectBalanceIPAccountService balanceIPAccountService;

    @Mock
    IpAccountApiService mirrorIpAccountService;

    @Mock
    IpAccountBalanceAdjustmentRepository balanceAdjustmentRepository;

    @BeforeEach
    void init() {
        doNothing().when(balanceAdjustmentValidator).validatePostBalanceAdjustmentRequest(any());
        doReturn("1234").when(mainEngineConfiguration).getClearingIspb();
        doReturn(UUID.randomUUID()).when(balanceAdjustmentEventEntityMock).getId();
        doReturn(balanceAdjustmentDetailsEntityMock).when(balanceAdjustmentEventEntityMock).getIpAccountBalanceAdjustmentDetailsEntity();
        doReturn(buildMessageType()).when(balanceAdjustmentDetailsEntityMock).getMessageType();
        doReturn(balanceAdjustmentEventEntityMock).when(balanceAdjustmentEventMock).getEventEntity();
        doReturn(buildBalanceAccountIP()).when(balanceIPAccountService).getBalanceAccountIP();
        Mockito.when(eventFactoryApiService.createNewEvent(any())).thenReturn(balanceAdjustmentEventMock);
        doReturn(balanceAdjustmentEventEntityMock).when(balanceAdjustmentRepository).saveAndFlush(any());
    }

    @Test
    void shouldThrowLiquidityManagementExceptionWhenStandinReturnBadRequestException() {
        Mockito.doThrow(BadRequestException.class).when(mirrorIpAccountService).makeCredit(any(), any());
        final LiquidityManagementException liquidityManagementException =
            assertThrows(LiquidityManagementException.class,
                () -> balanceAdjustmentApplicationService.sendRequestBalanceAdjustment(buildBalanceAdjustmentDTO()));
        assertEquals("SPI-LM-019", liquidityManagementException.getCode());
    }

    @Test
    void shouldThrowLiquidityManagementExceptionWhenStandinReturnInternalServerErrorException() {
        Mockito.doThrow(InternalServerErrorException.class).when(mirrorIpAccountService).makeCredit(any(), any());
        final LiquidityManagementException liquidityManagementException =
            assertThrows(LiquidityManagementException.class,
                () -> balanceAdjustmentApplicationService.sendRequestBalanceAdjustment(buildBalanceAdjustmentDTO()));
        assertEquals("SPI-LM-020", liquidityManagementException.getCode());
    }

    @Test
    void shouldThrowLiquidityManagementExceptionWhenStandinReturnSecurityErrorException() {
        Mockito.doThrow(SecurityErrorException.class).when(mirrorIpAccountService).makeCredit(any(), any());
        final LiquidityManagementException liquidityManagementException =
            assertThrows(LiquidityManagementException.class,
                () -> balanceAdjustmentApplicationService.sendRequestBalanceAdjustment(buildBalanceAdjustmentDTO()));
        assertEquals("SPI-LM-021", liquidityManagementException.getCode());
    }

    @Test
    void shouldThrowLiquidityManagementExceptionWhenStandinReturnServiceUnavailableException() {
        Mockito.doThrow(ServiceUnavailableException.class).when(mirrorIpAccountService).makeCredit(any(), any());
        final LiquidityManagementException liquidityManagementException =
            assertThrows(LiquidityManagementException.class,
                () -> balanceAdjustmentApplicationService.sendRequestBalanceAdjustment(buildBalanceAdjustmentDTO()));
        assertEquals("SPI-LM-022", liquidityManagementException.getCode());
    }

    @Test
    void shouldThrowLiquidityManagementExceptionWhenStandinReturnRuntimeExceptionException() {
        Mockito.doThrow(RuntimeException.class).when(mirrorIpAccountService).makeCredit(any(), any());
        final LiquidityManagementException liquidityManagementException =
            assertThrows(LiquidityManagementException.class,
                () -> balanceAdjustmentApplicationService.sendRequestBalanceAdjustment(buildBalanceAdjustmentDTO()));
        assertEquals("SPI-LM-023", liquidityManagementException.getCode());
    }

    private MessageType buildMessageType() {
        final MessageType messageType = new MessageType();
        messageType.setMessageType(EnumMessageType.LPI0001);
        messageType.setTransactionType(EnumTransactionType.CREDIT);
        return messageType;
    }

    private BalanceLocalIPAccountDTO buildBalanceAccountIP() {
        final BalanceLocalIPAccountDTO balanceLocalIPAccountDTO = new BalanceLocalIPAccountDTO();
        balanceLocalIPAccountDTO.setValue(BigDecimal.valueOf(10000));
        return balanceLocalIPAccountDTO;
    }

    private PostBalanceAdjustmentRequestDTO buildBalanceAdjustmentDTO() {
        final PostBalanceAdjustmentRequestDTO dto = new PostBalanceAdjustmentRequestDTO();

        dto.setMessageType(PostBalanceAdjustmentRequestDTO.MessageTypeEnum.PACS_004);
        dto.setPiAccountDatetime(LocalDateTimeUtils.getUtcLocalDateTime());
        dto.setTransactionId(TRANSACTION_ID);
        dto.setTransactionType(PostBalanceAdjustmentRequestDTO.TransactionTypeEnum.DEBIT);
        dto.setValue(BigDecimal.TEN);

        return dto;
    }

}
