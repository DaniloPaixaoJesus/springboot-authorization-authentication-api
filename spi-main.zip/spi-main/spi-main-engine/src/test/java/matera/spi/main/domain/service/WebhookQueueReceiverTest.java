package matera.spi.main.domain.service;

import com.matera.client.exception.SecurityErrorException;
import com.matera.spi.webhook.transaction.model.InstantPaymentSettlementCallbackRequestDTO;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.service.event.receiver.WebhookQueueReceiver;
import matera.spi.main.dto.WebhookTransactionDTO;
import matera.spi.utils.JsonService;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.assertj.core.api.Assertions.assertThatThrownBy;

@Slf4j
@IntegrationTest
class WebhookQueueReceiverTest {

    @Autowired
    private WebhookQueueReceiver webhookQueueReceiver;

    @Autowired
    private JsonService jsonUtils;


    @Disabled("rever este teste pois não esta fazendo sentido um sucesso retornar uma exception")
    @SneakyThrows
    @Test
    public void testSendMessageSuccess(){
        WebhookTransactionDTO webhookTransactionDTO = createWebhookTransactionDTO("123456", Boolean.TRUE);
        String message = getJsonMessage(webhookTransactionDTO);

        assertThatThrownBy(() -> webhookQueueReceiver.readIncomingMessage(message))
            .isInstanceOf(SecurityErrorException.class);
    }

    private WebhookTransactionDTO createWebhookTransactionDTO(String transactionId, boolean paymentConfirmed){
        WebhookTransactionDTO webhookTransactionDTO = new WebhookTransactionDTO();
        webhookTransactionDTO.setTransactionId(transactionId);
        webhookTransactionDTO.setPaymentSettlementCallbackRequest(new InstantPaymentSettlementCallbackRequestDTO());
        webhookTransactionDTO.getPaymentSettlementCallbackRequest().setAdditionalInfo("additional info");
        webhookTransactionDTO.getPaymentSettlementCallbackRequest().setPaymentConfirmed(paymentConfirmed);
        return webhookTransactionDTO;
    }

    private String getJsonMessage(WebhookTransactionDTO webhookTransactionDTO) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(webhookTransactionDTO);
        return json;
    }

}
