package matera.spi.main.domain.service.event;

import com.matera.client.exception.ApiRequestException;
import com.matera.commons.utils.validation.MateraErrorDTO;

import org.assertj.core.internal.bytebuddy.utility.RandomString;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
class ExtractStackTraceUtilsTest {

    @Test
    void shouldReturnStackTraceStringWhenExceptionIsApiRequestExceptionAndLengthIsSmallerLessThanThousand() {
        MateraErrorDTO materaErrorDTO = new MateraErrorDTO();
        String messageRandom = RandomString.make(933);
        materaErrorDTO.setMessage(messageRandom);

        ApiRequestException apiRequestException = new ApiRequestException(materaErrorDTO);
        String result = ExtractStackTraceUtils.getOnlyThousandCharactersFromStackTrace(apiRequestException);

        MateraErrorDTO expected = new MateraErrorDTO();
        expected.setMessage(messageRandom);

        assertThat(result).hasSize(996);
        assertThat(result).contains(expected.getMessage());
    }

    @Test
    void shouldReturnStackTraceStringWithThousandCharactersWhenTheExceptionMessageIsGreaterThanThousand() {
        MateraErrorDTO materaErrorDTO = new MateraErrorDTO();
        String messageRandom = RandomString.make(1008);
        materaErrorDTO.setMessage(messageRandom);

        ApiRequestException apiRequestException = new ApiRequestException(materaErrorDTO);
        String result = ExtractStackTraceUtils.getOnlyThousandCharactersFromStackTrace(apiRequestException);

        assertThat(result).hasSize(1000);
    }

    @Test
    void shouldReturnStackTraceStringWhenExceptionTypeIsNotApiRequestException() {
        String result = ExtractStackTraceUtils.getOnlyThousandCharactersFromStackTrace(new RuntimeException());

        assertThat(result).contains("| stacktrace: ");
    }

}
