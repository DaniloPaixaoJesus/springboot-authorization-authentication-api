package matera.spi.lm.domain.service.model.event;

import com.matera.commons.utils.exception.BusinessException;

import matera.spi.lm.domain.model.event.MessageType;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

import static matera.spi.lm.domain.model.enums.EnumMessageType.*;
import static matera.spi.main.domain.model.enums.EnumTransactionType.*;

import static org.hamcrest.CoreMatchers.instanceOf;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class MessageTypeTest {

    @Test
    void shouldThrowExceptionWhenTransactionTypeIsCreditAndMessageTypeIsNotPresentInCreditSet() {
        assertThrows(BusinessException.class, () -> new MessageType(CREDIT, LPI0003));
    }

    @Test
    void shouldThrowExceptionWhenTransactionTypeIsDebitAndMessageTypeIsNotPresentInDebitSet() {
        assertThrows(BusinessException.class, () -> new MessageType(DEBIT, LPI0001));
    }

    @Test
    void shouldCreateNewInstanceWhenValidCreditValuesIsPassed() {
        Assert.assertThat(new MessageType(CREDIT, LPI0001), instanceOf(MessageType.class));
    }

    @Test
    void shouldCreateNewInstanceWhenValidDebitValuesIsPassed() {
        Assert.assertThat(new MessageType(DEBIT, LPI0003), instanceOf(MessageType.class));
    }
}
