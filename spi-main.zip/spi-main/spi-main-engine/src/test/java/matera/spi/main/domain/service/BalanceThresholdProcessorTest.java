package matera.spi.main.domain.service;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.ParticipantMipEntity;
import matera.spi.main.domain.service.scheduling.BalanceThresholdScheduling;
import matera.spi.main.dto.BalanceAccountThresholdProcessorDTO;
import matera.spi.main.dto.BalanceThresholdProcessorDTO;
import matera.spi.main.persistence.ParticipantMipRepository;

import org.assertj.core.api.SoftAssertions;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.test.context.support.TestPropertySourceUtils;

import java.math.BigDecimal;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.verify;

@IntegrationTest
@Disabled
public class BalanceThresholdProcessorTest  {

    public static final int ISPB = 44444444;
    private static final int TIME_BEFORE_SCHEDULER_STARTS_COUNT_SECONDS = 5;
    public static final String SCHEDULER_PROPERTY = "spi.mainengine.scheduler.balance-threshold-processor.expression";
    public static final String SCHEDULER_EXPRESSION = "0/2 * * * * *";

    @Autowired
    private BalanceThresholdProcessorDTO balanceThresholdProcessorDTO;

    @Autowired
    private ConfigurableEnvironment configurableEnvironment;

    @Autowired
    private ParticipantMipRepository participantMipRepository;

    @Autowired
    private ParticipantMipService participantMipService;

    //@SpyBean
    private BalanceThresholdScheduling balanceThresholdScheduling;

    @BeforeEach
    public void removeThresholdProperty() {

        changeTimeInterval("");
    }

    @AfterEach
    public void removeInsertedData() {

        if(participantMipRepository.existsById(ISPB)) {
            participantMipRepository.deleteById(ISPB);
        }
    }

    @Test
    public void shouldRunBalanceVerificationEvery3SecondsIfNoConfigurationIsFound() throws Exception {

        awaitBeforeTest(TIME_BEFORE_SCHEDULER_STARTS_COUNT_SECONDS);

        verify(balanceThresholdScheduling, atLeast(1)).reloadBalanceThresholdProcessorDTO();
    }

    @Test
    public void shouldRunBalanceVerificationAtScheduledInterval() throws Exception {

        changeTimeInterval(SCHEDULER_EXPRESSION);

        awaitBeforeTest(TIME_BEFORE_SCHEDULER_STARTS_COUNT_SECONDS + 3);

        verify(balanceThresholdScheduling, atLeast(2)).reloadBalanceThresholdProcessorDTO();
    }

    @Test
    public void shouldLoadLoadTheBalanceThresholdProcessor() throws Exception {
        Map< Integer, BalanceAccountThresholdProcessorDTO> balanceAccountThresholds = balanceThresholdProcessorDTO.getBalanceAccountThresholds();

        assertThat(balanceAccountThresholds).isNotEmpty();

        BalanceAccountThresholdProcessorDTO balanceAccountThresholdProcessorDTO = balanceAccountThresholds.entrySet().stream().findFirst().get().getValue();

        SoftAssertions softAssertions = new SoftAssertions();

        softAssertions.assertThat(balanceAccountThresholdProcessorDTO.getBalance()).isNotNull();

        softAssertions.assertAll();
    }

    @Test
    public void shouldCreateABeanOfTypeBalanceThresholdProcessorDTO() {

        assertThat(balanceThresholdProcessorDTO).isNotNull();
    }

    @Test
    public void shouldReloadTheBalanceThresholdProcessorBeanAfterEveryCronExecution() throws Exception {

        changeTimeInterval(SCHEDULER_EXPRESSION);

        awaitBeforeTest(TIME_BEFORE_SCHEDULER_STARTS_COUNT_SECONDS + 2);

        int initialSize = balanceThresholdProcessorDTO.getBalanceAccountThresholds().size();

        ParticipantMipEntity newParticipantMipEntity = insertNewParticipantMip();

        awaitBeforeTest(TIME_BEFORE_SCHEDULER_STARTS_COUNT_SECONDS + 2);

        int sizeAfterInsertion = balanceThresholdProcessorDTO.getBalanceAccountThresholds().size();

        assertThat(sizeAfterInsertion).isEqualTo(initialSize + 1);
    }

    private ParticipantMipEntity insertNewParticipantMip() {

        ParticipantMipEntity participantMip = new ParticipantMipEntity();
        participantMip.setIspb(ISPB);
        participantMip.setBranch(123);
        participantMip.setAccountNumber(BigDecimal.valueOf(444555));
        participantMip.setDebTransactionType(12);
        participantMip.setCredTransactionType(344);
        participantMip.setDepositTransactionType(4789);
        participantMip.setWithdrawTransactionType(1147);
        participantMip.setDrawbackSentTransactType(11);
        participantMip.setDrawbackReceiveTransactType(77);
        participantMip.setBalanceValidationThreshold(true);
        participantMip.setBalanceLowerThreshold(BigDecimal.valueOf(1002430.57));
        participantMip.setBalanceLowerThresholdPerc(10);
        participantMip.setDirectParticipant(false);

        return participantMipRepository.saveAndFlush(participantMip);

    }

    private void changeTimeInterval(String s) {
        TestPropertySourceUtils.addInlinedPropertiesToEnvironment(
                configurableEnvironment, SCHEDULER_PROPERTY + "=" + s);
    }

    private void awaitBeforeTest(int seconds) throws Exception {

        Thread.sleep(seconds * 1000);
    }
}
