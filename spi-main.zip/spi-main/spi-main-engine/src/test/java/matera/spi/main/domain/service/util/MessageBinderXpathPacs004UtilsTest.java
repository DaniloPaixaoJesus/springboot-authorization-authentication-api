package matera.spi.main.domain.service.util;

import matera.spi.utils.DocumentUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;

import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static org.assertj.core.api.Assertions.assertThat;

class MessageBinderXpathPacs004UtilsTest {

	private static final String PACS_004_ONE_TXINF = "pacs.004/pacs.004.spi.1.0_msg.xml";
    private static final String PACS_004_THREE_TXINF = "pacs.004/pacs.004.spi.1.0_three_msg.xml";

    private static final String RTR_ID = "D0003816620200318155430bd330e8f3";
    private static final String ORGN_END_TO_END_ID = "E000381662020031815545319832763a";
    private static final String RTR_INTR_BK_STTLM_AMT = "1637.13";
    private static final String CHRG_BR = "SLEV";
    private static final String MSG_ID = "M000381662ceb081139184c1b8e63c84";
    private static final String CREDT_TM = "2020-03-18T18:54:31.650Z";
    private static final String SGNTR_TM = "1";
    private static final String STTLM_MTD = "CLRG";
    private static final String CD = "UPAY";
    private static final String MMB_ID_DB = "00038166";
    private static final String MMB_ID_CD = "00038166";
    private static final String STTLM_PRTY = "HIGH";
    private static final String USTRD = "227d3f8099b3c81d8ffa52283ac038a4d38541a9644477953f166b96549399be9b6d61ef3ed0b0625597cd77c55b8c6cbac94413415743c7a0ec9ec1f4f79b862e219ac3632b601ccf4f3e3c0123a6e4";
    private static final String ADDTL_INF = "c78804f349745a9377cd8bc2b65f621f1d6819401477455cec7bcbcb5b4011b14e5a6d93068ebb3e9a18e14b240f187b35aad891dccc6b2f77ba8cffe152eef8af8561e6ec72a25ec73ef895c7099063";

    private static final int THREE = 3;
    private static final int ONE = 1;

    @Test
    @DisplayName("Get All TxInfAndSts Node Test.")
    void shouldOneTxInf() {
        Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_004_ONE_TXINF));
        NodeList nodeList = MessageBinderXpathPacs004Utils.getTxInfAllNode(document);
        assertThat(nodeList.getLength()).isEqualTo(ONE);
    }

    @Test
    @DisplayName("Get All IntrBkSttlmDt Node Test.")
    void shouldThreeTxInf() {
        Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_004_THREE_TXINF));
        NodeList nodeList = MessageBinderXpathPacs004Utils.getTxInfAllNode(document);
        assertThat(nodeList.getLength()).isEqualTo(THREE);
    }

    @Test
	@DisplayName("Get All Children TxInf One TxInf.")
	void shouldGetAllChildrenTxInfOneTxInf() {
        ArrayList<String> itens = new ArrayList<>();
		Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_004_ONE_TXINF));
		NodeList nodeList = MessageBinderXpathPacs004Utils.getTxInfAllNode(document);
        for (int i =0; i<nodeList.getLength();i++){
            itens.add(MessageBinderXpathPacs004Utils.getRtrId(nodeList.item(i)));
            itens.add(MessageBinderXpathPacs004Utils.getOrgnEndToEndId(nodeList.item(i)));
            itens.add(MessageBinderXpathPacs004Utils.getRtrIntrBkSttlmAmt(nodeList.item(i)));
            itens.add(MessageBinderXpathPacs004Utils.getChrgBr(nodeList.item(i)));
        }
        assertThat(itens.get(0)).isEqualTo(RTR_ID);
        assertThat(itens.get(1)).isEqualTo(ORGN_END_TO_END_ID);
        assertThat(itens.get(2)).isEqualTo(RTR_INTR_BK_STTLM_AMT);
        assertThat(itens.get(3)).isEqualTo(CHRG_BR);
	}

    @Test
    @DisplayName("Get MsgId.")
    void shouldGetMsgIdOneTxInf() {
        Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_004_ONE_TXINF));
        String msgId = MessageBinderXpathPacs004Utils.getMsgId(document);
        assertThat(msgId).isEqualTo(MSG_ID);
    }

    @Test
    @DisplayName("Get CreDtTM.")
    void shouldGetCredtOneTxInf() {
        Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_004_ONE_TXINF));
        String credtDtTm = MessageBinderXpathPacs004Utils.getCreDtTM(document);
        assertThat(credtDtTm).isEqualTo(CREDT_TM);
    }

    @Test
    @DisplayName("Get NbOfTXS.")
    void shouldGetNbOfTXSOneTxInf() {
        Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_004_ONE_TXINF));
        String nbOfTXS = MessageBinderXpathPacs004Utils.getNbOfTXS(document);
        assertThat(nbOfTXS).isEqualTo(SGNTR_TM);
    }

    @Test
    @DisplayName("Get MsgId One TxInf.")
    void shouldGetnbOfTXS() {
        Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_004_ONE_TXINF));
        String nbOfTXS = MessageBinderXpathPacs004Utils.getSttlmMtd(document);
        assertThat(nbOfTXS).isEqualTo(STTLM_MTD);
    }

    @Test
    @DisplayName("Get Cd.")
    void shouldGetCd() {
        Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_004_ONE_TXINF));
        String cd = null;
        NodeList nodeList = MessageBinderXpathPacs004Utils.getTxInfAllNode(document);
        for (int i =0; i<nodeList.getLength();i++){
            cd = MessageBinderXpathPacs004Utils.getCD(nodeList.item(i));
        }
        assertThat(cd).isEqualTo(CD);
    }

    @Test
    @DisplayName("Get MsgId One TxInf.")
    void shouldGetMmbIdCd() {
        Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_004_ONE_TXINF));
        String mmbIdCd = null;
        NodeList nodeList = MessageBinderXpathPacs004Utils.getTxInfAllNode(document);
        for (int i =0; i<nodeList.getLength();i++){
            mmbIdCd = MessageBinderXpathPacs004Utils.getMmbIdCd(nodeList.item(i));
        }
        assertThat(mmbIdCd).isEqualTo(MMB_ID_CD);
    }

    @Test
    @DisplayName("Get MmbIdDb.")
    void shouldGetMmbIdDb() {
        Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_004_ONE_TXINF));
        String mmbIdDb = null;
        NodeList nodeList = MessageBinderXpathPacs004Utils.getTxInfAllNode(document);
        for (int i =0; i<nodeList.getLength();i++){
            mmbIdDb = MessageBinderXpathPacs004Utils.getMmbIdDb(nodeList.item(i));
        }
        assertThat(mmbIdDb).isEqualTo(MMB_ID_DB);
    }

    @Test
    @DisplayName("Get SttlmPrty.")
    void shouldGetSttlmPrty() {
        Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_004_ONE_TXINF));
        String sttlmPrty = null;
        NodeList nodeList = MessageBinderXpathPacs004Utils.getTxInfAllNode(document);
        for (int i =0; i<nodeList.getLength();i++){
            sttlmPrty = MessageBinderXpathPacs004Utils.getSttlmPrty(nodeList.item(i));
        }
        assertThat(sttlmPrty).isEqualTo(STTLM_PRTY);
    }

    @Test
    @DisplayName("Get Ustrd.")
    void shouldGetUstrd() {
        Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_004_ONE_TXINF));
        String ustrd = null;
        NodeList nodeList = MessageBinderXpathPacs004Utils.getTxInfAllNode(document);
        for (int i =0; i<nodeList.getLength();i++){
            ustrd = MessageBinderXpathPacs004Utils.getUstrd(nodeList.item(i));
        }
        assertThat(ustrd).isEqualTo(USTRD);
    }

    @Test
    @DisplayName("Get addtlInf.")
    void shouldGetAddtlInf() {
        Document document = DocumentUtils.stringToXmlDocument(getXml(PACS_004_ONE_TXINF));
        String addtlInf = null;
        NodeList nodeList = MessageBinderXpathPacs004Utils.getTxInfAllNode(document);
        for (int i =0; i<nodeList.getLength();i++){
            addtlInf = MessageBinderXpathPacs004Utils.getAddtlInf(nodeList.item(i));
        }
        assertThat(addtlInf).isEqualTo(ADDTL_INF);
    }

	private String getXml(String arquivo) {
		return getStringFromXmlFile(arquivo);
	}
}
