package matera.spi.main.domain.service;

import matera.spi.main.domain.model.transaction.TransactionPriorityEntity;
import matera.spi.main.persistence.TransactionPriorityRepository;

import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TransactionPriorityServiceTest {

    private static final String PRIORITY_CODE_HIGH = "HIGH";
    public static final String SOME_PRIORITY_CODE = "SOME_PRIORITY_CODE";

    @Mock
    private TransactionPriorityRepository transactionPriorityRepository;

    @InjectMocks
    private TransactionPriorityService transactionPriorityService;

    @ParameterizedTest
    @ValueSource(strings = {PRIORITY_CODE_HIGH})
    @NullAndEmptySource
    void shouldGetPriorityHighByCodeWhen(String priorityCode) {
        when(transactionPriorityRepository.findById(PRIORITY_CODE_HIGH))
            .thenReturn(Optional.of(transactionPriorityHigh()));

        TransactionPriorityEntity priorityCodeEntity = transactionPriorityService.getPriorityByCode(priorityCode);

        assertThat(priorityCodeEntity).isEqualTo(transactionPriorityHigh());
        Mockito.verify(transactionPriorityRepository, Mockito.times(1)).findById(PRIORITY_CODE_HIGH);
    }

    @NotNull
    private TransactionPriorityEntity transactionPriorityHigh() {
        TransactionPriorityEntity transactionPriorityEntity = new TransactionPriorityEntity();
        transactionPriorityEntity.setCode(PRIORITY_CODE_HIGH);
        return transactionPriorityEntity;
    }

    @Test
    void shouldThrowIllegalArgumentExceptionWhenRepositoryRepositoryReturnEmpty() {
        when(transactionPriorityRepository.findById(SOME_PRIORITY_CODE)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> transactionPriorityService.getPriorityByCode(SOME_PRIORITY_CODE))
            .isInstanceOf(IllegalArgumentException.class)
            .hasMessage("The instruction at priority %s was not found.", SOME_PRIORITY_CODE);
    }

}
