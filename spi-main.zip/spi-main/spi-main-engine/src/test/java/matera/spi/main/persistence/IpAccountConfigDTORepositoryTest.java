package matera.spi.main.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.IpAccountConfigEntity;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@IntegrationTest
class IpAccountConfigDTORepositoryTest  {

    @Autowired
    private IpAccountConfigRepository ipAccountConfigRepository;

    private IpAccountConfigEntity expected;

    @BeforeEach
    void init() {
        expected = buildAndSaveIpAccountConfig();
    }

    @AfterEach
    void clearDatabase() {
        ipAccountConfigRepository.delete(expected);
    }

    private IpAccountConfigEntity buildAndSaveIpAccountConfig() {
        IpAccountConfigEntity ipAccountConfigEntity = new IpAccountConfigEntity();
        ipAccountConfigEntity.setAccountNumber(BigDecimal.valueOf(12345678));
        ipAccountConfigEntity.setBranch(4321);
        ipAccountConfigEntity.setCreditTransactionType(5678);
        ipAccountConfigEntity.setBalanceValidationThreshold(true);
        ipAccountConfigEntity.setDrawbackReceiveTransactType(5823);
        ipAccountConfigEntity.setDrawbackSentTransactType(1111);
        ipAccountConfigEntity.setDebitTransactionType(1234);
        ipAccountConfigEntity.setBalanceLowerThreshold(new BigDecimal("2000000000.00"));
        ipAccountConfigEntity.setBalanceLowerThresholdPercent(BigDecimal.valueOf(0.25));
        ipAccountConfigEntity.setBalanceUpperThreshold(new BigDecimal("666666666.66"));
        ipAccountConfigEntity.setBalanceUpperThresholdPercent(BigDecimal.valueOf(0.75));
        ipAccountConfigEntity.setDepositTransactionType(9876);
        ipAccountConfigEntity.setWithdrawTransactionType(5432);
        ipAccountConfigEntity.setQrcodeCredTransactionType(1111);
        ipAccountConfigEntity.setBalanceAdjustmentCredit(4561);
        ipAccountConfigEntity.setBalanceAdjustmentDebit(1748);

        return ipAccountConfigRepository.saveAndFlush(ipAccountConfigEntity);
    }

    @Test
    void shouldBeFindEntityWhenInserted() {
        IpAccountConfigEntity actual = ipAccountConfigRepository.findById(expected.getUuid()).orElse(null);

        assertNotNull(actual);
        assertEquals(expected.getDebitTransactionType(), actual.getDebitTransactionType());
        assertEquals(expected.getBranch(), actual.getBranch());
        assertEquals(expected.getAccountNumber(), actual.getAccountNumber());
        assertEquals(expected.getCreditTransactionType(), actual.getCreditTransactionType());
        assertEquals(expected.isBalanceValidationThreshold() , actual.isBalanceValidationThreshold());
        assertEquals(expected.getDrawbackReceiveTransactType() , actual.getDrawbackReceiveTransactType());
        assertEquals(expected.getDrawbackSentTransactType() , actual.getDrawbackSentTransactType());
        assertEquals(expected.getDepositTransactionType(), actual.getDepositTransactionType());
        assertEquals(expected.getWithdrawTransactionType(), actual.getWithdrawTransactionType());
        assertEquals(expected.getBalanceLowerThresholdPercent(), actual.getBalanceLowerThresholdPercent());
        assertEquals(expected.getBalanceUpperThresholdPercent(), actual.getBalanceUpperThresholdPercent());
        assertEquals(expected.getBalanceAdjustmentDebit(), actual.getBalanceAdjustmentDebit());
        assertEquals(expected.getBalanceAdjustmentCredit(), actual.getBalanceAdjustmentCredit());
        assertEquals(0, expected.getBalanceLowerThreshold().compareTo(actual.getBalanceLowerThreshold()));
        assertEquals(0, expected.getBalanceUpperThreshold().compareTo(actual.getBalanceUpperThreshold()));
        assertEquals(expected.getQrcodeCredTransactionType(), actual.getQrcodeCredTransactionType());


    }

}
