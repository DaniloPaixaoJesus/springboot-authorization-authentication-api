package matera.spi.indirect.domain.service;

import matera.spi.dto.IndirectParticipantStatusDTO;
import matera.spi.indirect.domain.model.ParticipantMipIndirectEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectHistoryEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectStatusEntity;
import matera.spi.indirect.domain.model.enums.IndirectParticipantStatusEnum;
import matera.spi.indirect.persistence.ParticipantMipIndirectHistoryRepository;
import matera.spi.indirect.persistence.ParticipantMipIndirectRepository;
import matera.spi.indirect.persistence.ParticipantMipIndirectStatusRepository;
import matera.spi.indirect.util.ParticipantMipIndirectDataSetUtil;
import matera.spi.main.domain.model.ParticipantMipEntity;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class IndirectParticipantInformationRetrieverTest {

    private static final Integer ISPB = 123454;
    private static final Integer CURRENT_PAGE = 0;
    private static final Integer PAGE_SIZE = 2;
    private static final Integer TOTAL_ELEMENTS = 1;
    private static final Integer TOTAL_PAGES = 1;

    @Mock
    private IndirectParticipantMipService indirectParticipantMipService;

    @Mock
    private ParticipantMipIndirectStatusRepository participantMipIndirectStatusRepository;

    @Mock
    private ParticipantMipIndirectRepository participantMipIndirectRepository;

    @Mock
    private ParticipantMipIndirectHistoryRepository participantMipIndirectHistoryRepository;

    @Mock
    private IndirectParticipantHistoryService indirectParticipantHistoryService;

    @InjectMocks
    private IndirectParticipantInformationRetriever indirectParticipantInformationRetriever;

    @Test
    void shouldReturnIndirectParticipantCompleteInfo() {
        final ParticipantMipIndirectStatusEntity statusEntity =
            ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectStatusEntity();

        when(participantMipIndirectStatusRepository.findById(IndirectParticipantStatusEnum.ACTIVE.getId()))
            .thenReturn(Optional.of(statusEntity));

        final ParticipantMipIndirectEntity participantMipIndirectEntity =
                ParticipantMipIndirectDataSetUtil.createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                    ParticipantMipIndirectDataSetUtil.createParticipantMip());
        participantMipIndirectEntity.setContacts(
            List.of(ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectContactsEntity(participantMipIndirectEntity)));

        when(participantMipIndirectRepository.findByIspbJoinFetchParticipantAndContacts(ISPB)).thenReturn(Optional.of(participantMipIndirectEntity));

        ParticipantMipIndirectEntity result =
            indirectParticipantInformationRetriever.findIndirectParticipantCompleteInformation(ISPB);

        assertEquals(participantMipIndirectEntity, result);

    }

    @Test
    void shouldReturnIndirectParticipantHistoriesByIspb() {
        Pageable page = PageRequest.of(CURRENT_PAGE, PAGE_SIZE);

        final ParticipantMipIndirectStatusEntity statusEntity =
            ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectStatusEntity();

        when(participantMipIndirectStatusRepository.findById(IndirectParticipantStatusEnum.ACTIVE.getId()))
            .thenReturn(Optional.of(statusEntity));

        ParticipantMipIndirectHistoryEntity participantMipIndirectHistory =
            ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectHistoryEntity(
                ParticipantMipIndirectDataSetUtil.createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                    ParticipantMipIndirectDataSetUtil.createParticipantMip()));

        Page<ParticipantMipIndirectHistoryEntity>
            pageEntity = new PageImpl<>(List.of(participantMipIndirectHistory), page, TOTAL_ELEMENTS);

        when(indirectParticipantHistoryService.findHistoryByIspb(page, ISPB)).thenReturn(pageEntity);

        Page<ParticipantMipIndirectHistoryEntity>
            result = indirectParticipantInformationRetriever.findHistory(page, ISPB);

        assertEquals(result, pageEntity);
    }

    @Test
    void shouldReturnIndirectParticipantSummaryInfo() {
        Pageable page = PageRequest.of(CURRENT_PAGE, PAGE_SIZE);

        final ParticipantMipIndirectStatusEntity statusEntity =
            ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectStatusEntity();

        when(participantMipIndirectStatusRepository.findById(IndirectParticipantStatusEnum.ACTIVE.getId()))
            .thenReturn(Optional.of(statusEntity));

        ParticipantMipIndirectEntity participantMipIndirect =
                ParticipantMipIndirectDataSetUtil.createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                    ParticipantMipIndirectDataSetUtil.createParticipantMip());

        final Page<ParticipantMipIndirectEntity>
            pageEntity = new PageImpl<>(List.of(participantMipIndirect), page, TOTAL_ELEMENTS);

        doReturn(pageEntity).when(participantMipIndirectRepository).findAll(any(Specification.class), eq(page));

        Page<ParticipantMipIndirectEntity> result = indirectParticipantInformationRetriever.findIndirectParticipantSummaryInfo(page,
            ISPB,
            ParticipantMipIndirectDataSetUtil.INDIRECT_PARTICIPANT_NAME,
            ParticipantMipIndirectDataSetUtil.TAX_ID,
            IndirectParticipantStatusDTO.ACTIVE,
            ParticipantMipIndirectDataSetUtil.CONTRACT_INIT_DATE,
            ParticipantMipIndirectDataSetUtil.CONTRACT_END_DATE, true);

        assertEquals(pageEntity, result);

    }

    @Test
    void shouldFindParticipantByIspb() {
        doReturn(Optional.of(ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectStatusEntity()))
            .when(participantMipIndirectStatusRepository).findById(any());

        final ParticipantMipEntity participantMip = ParticipantMipIndirectDataSetUtil.createParticipantMip();
        final ParticipantMipIndirectEntity participantMipIndirectEntity = ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository, participantMip);

        doReturn(Arrays.asList(participantMipIndirectEntity)).when(participantMipIndirectRepository)
            .findAll(any(Specification.class));

        final List<ParticipantMipIndirectEntity> participantMipIndirectListFound = indirectParticipantInformationRetriever
            .findIndirectParticipantByIspbAndClearingStatusAndShowCanceled(ParticipantMipIndirectDataSetUtil.ISPB, false, true);

        verify(participantMipIndirectRepository)
            .findAll(any(Specification.class));
        assertNotNull(participantMipIndirectListFound);
        assertThat(participantMipIndirectListFound).hasOnlyOneElementSatisfying(participantMipIndirectEntity::equals);
    }

    @Test
    void shouldFindParticipantByIspbOnlyActive() {
        doReturn(Optional.of(ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectStatusEntity()))
            .when(participantMipIndirectStatusRepository).findById(any());

        final ParticipantMipEntity participantMip = ParticipantMipIndirectDataSetUtil.createParticipantMip();
        final ParticipantMipIndirectEntity participantMipIndirectEntity = ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository, participantMip);

        doReturn(Arrays.asList(participantMipIndirectEntity)).when(participantMipIndirectRepository)
            .findAllByIspbAndStatusIsActiveIsTrueJoinFetchParticipantAndContacts(
                eq(ParticipantMipIndirectDataSetUtil.ISPB));

        final List<ParticipantMipIndirectEntity> participantMipIndirectListFound = indirectParticipantInformationRetriever
            .findIndirectParticipantByIspbAndClearingStatusAndShowCanceled(ParticipantMipIndirectDataSetUtil.ISPB, true, true);

        verify(participantMipIndirectRepository).findAllByIspbAndStatusIsActiveIsTrueJoinFetchParticipantAndContacts(
            eq(ParticipantMipIndirectDataSetUtil.ISPB));
        assertNotNull(participantMipIndirectListFound);
        assertThat(participantMipIndirectListFound).hasOnlyOneElementSatisfying(participantMipIndirectEntity::equals);
    }

    @Test
    void shouldFindAllParticipantsAndStatusIsActiveIsTrueJoinFetchParticipantAndContacts() {
        doReturn(Optional.of(ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectStatusEntity()))
            .when(participantMipIndirectStatusRepository).findById(any());

        final ParticipantMipEntity participantMip = ParticipantMipIndirectDataSetUtil.createParticipantMip();
        final ParticipantMipIndirectEntity participantMipIndirectEntity = ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository, participantMip);

        doReturn(Arrays.asList(participantMipIndirectEntity)).when(participantMipIndirectRepository)
            .findAllAndStatusIsActiveIsTrueJoinFetchParticipantAndContacts();

        final List<ParticipantMipIndirectEntity> participantMipIndirectListFound =
            indirectParticipantInformationRetriever.findAllIndirectParticipantByClearingStatusAndShowCanceled(true, true);

        verify(participantMipIndirectRepository).findAllAndStatusIsActiveIsTrueJoinFetchParticipantAndContacts();
        assertNotNull(participantMipIndirectListFound);
        assertThat(participantMipIndirectListFound).hasOnlyOneElementSatisfying(participantMipIndirectEntity::equals);
    }

    @Test
    void shouldFindAllParticipantsJoinFetchParticipantAndContacts() {
        doReturn(Optional.of(ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectStatusEntity()))
            .when(participantMipIndirectStatusRepository).findById(any());

        final ParticipantMipEntity participantMip = ParticipantMipIndirectDataSetUtil.createParticipantMip();
        final ParticipantMipIndirectEntity participantMipIndirectEntity = ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository, participantMip);

        doReturn(Arrays.asList(participantMipIndirectEntity)).when(participantMipIndirectRepository)
            .findAll(any(Specification.class));

        final List<ParticipantMipIndirectEntity> participantMipIndirectListFound =
            indirectParticipantInformationRetriever.findAllIndirectParticipantByClearingStatusAndShowCanceled(false, true);

        verify(participantMipIndirectRepository).findAll(any(Specification.class));
        assertNotNull(participantMipIndirectListFound);
        assertThat(participantMipIndirectListFound).hasOnlyOneElementSatisfying(participantMipIndirectEntity::equals);
    }

    @Test
    void shouldReturnIndirectParticipantWhenInformationAllFilters() {
        Sort sort = Sort.by("contractInitDate");
        Pageable page = PageRequest.of(CURRENT_PAGE, PAGE_SIZE, sort);
        IndirectParticipantStatusDTO statusDTO = IndirectParticipantStatusDTO.fromValue("ACTIVE");

        doReturn(Optional.of(ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectStatusEntity()))
            .when(participantMipIndirectStatusRepository).findById(any());

        List<ParticipantMipIndirectEntity> participantMipIndirects = List.of(ParticipantMipIndirectDataSetUtil.createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository,
                ParticipantMipIndirectDataSetUtil.createParticipantMip()));

        final Page<ParticipantMipIndirectEntity> pageEntity = new PageImpl<>(participantMipIndirects, page,
            TOTAL_ELEMENTS);

        doReturn(pageEntity).when(participantMipIndirectRepository).findAll(any(Specification.class), eq(page));

        Page<ParticipantMipIndirectEntity> result = indirectParticipantInformationRetriever
            .findIndirectParticipantSummaryInfo(page, ISPB, ParticipantMipIndirectDataSetUtil.INDIRECT_PARTICIPANT_NAME,
                ParticipantMipIndirectDataSetUtil.TAX_ID, statusDTO,
                ParticipantMipIndirectDataSetUtil.CONTRACT_INIT_DATE,
                ParticipantMipIndirectDataSetUtil.CONTRACT_END_DATE, true);

        assertEquals(result.getContent().get(0).getName(), participantMipIndirects.get(0).getName());
    }

}
