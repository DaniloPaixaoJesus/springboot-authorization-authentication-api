package matera.spi.lm.rest;

import com.matera.commons.rest.dto.MateraRestReturnDTO;
import com.matera.spi.messaging.api.MessagesApi;
import com.matera.spi.messaging.api.SPIMessagingApis;
import com.matera.spi.messaging.model.MessageSpecificationDTO;

import matera.spi.commons.IntegrationTest;
import matera.spi.dto.InstantPaymentsUIDTO;
import matera.spi.dto.SettlementInfoListResponseDTO;
import matera.spi.main.application.service.PaymentsService;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventType;
import matera.spi.main.domain.service.CorrelationIdGenerator;
import matera.spi.main.domain.service.MessageCatalogSpecificationService;
import matera.spi.main.domain.service.MessageSender;
import matera.spi.main.domain.service.event.receiver.MessageReceiver;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.utils.AccountTransactionMocker;
import matera.spi.main.utils.InstantPaymentCreationUtils;
import matera.spi.main.utils.WireMockUtils;

import com.github.tomakehurst.wiremock.WireMockServer;
import io.restassured.RestAssured;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.api.SoftAssertions;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.List;
import java.util.Random;

import static matera.spi.main.utils.InstantPaymentCreationUtils.CREATION_DATE_TIME;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ACCOUNT;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_BRANCH;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.createInstantPaymentsUIDTOMock;
import static matera.spi.main.utils.InstantPaymentCreationUtils.createMessageSentResponseDTO;
import static matera.spi.main.utils.InstantPaymentCreationUtils.getRandomPiResourceId;
import static matera.spi.main.utils.MessageCreationUtils.buildCamt014RptTag;
import static matera.spi.main.utils.MessageCreationUtils.buildReceivedCamt014;
import static matera.spi.main.utils.MessageCreationUtils.buildReceivedPacs008;

import static com.github.tomakehurst.wiremock.client.WireMock.resetAllRequests;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@IntegrationTest
public class EventsApiDelegateTest {

    public static class SettlementInfoMateraRestReturnDTO
        extends MateraRestReturnDTO<SettlementInfoListResponseDTO> {
    }

    public static final String HTTP_LOCALHOST = "http://localhost:";
    public static final String API_V1_SETTLEMENTS = "/api/v1/settlements";
    public static final String PAGE_SIZE = "10";
    public static final String PAGE_NUMBER = "0";
    public static final String ALL_EVENT_TYPE = "ALL";

    public static final String ALL_EVENT_STATUS = "ALL";
    public static final String TYPE_INDIRECT = "IDRT";
    public static final String STATUS_ENABLE = "ENBL";

    public static final String CAMT014_ENVELOPE_NAMESPACE = "https://www.bcb.gov.br/pi/camt.014/1.0";

    @LocalServerPort
    private int port;

    @Autowired
    private PaymentsService paymentsService;

    @Mock
    private SPIMessagingApis mockedSpiMessagingApis;

    @Mock
    private MessagesApi mockedMessagesApi;

    @Autowired
    private MessageCatalogSpecificationService messageCatalogSpecificationService;

    private String pacs008CurrentVersion;

    @Autowired
    private MessageSender messageSender;

    @Autowired
    private MessageReceiver messageReceiver;

    @Autowired
    private SPIMessagingApis spiMessagingApisBean;

    @Autowired
    private AccountTransactionMocker accountTransactionMocker;

    private static WireMockServer wireMockServer;

    @BeforeAll
    static void beforeAll() {
        wireMockServer = WireMockUtils.start();
        WireMockUtils.stubMessaging();
        WireMockUtils.stubStandin();
    }

    @AfterAll
    static void afterAll() {
        wireMockServer.stop();
    }

    @BeforeEach
    void setUp() {
        RestAssured.port = port;
        resetAllRequests();

        accountTransactionMocker.mockReverter();
        accountTransactionMocker.spyExecutor();

        pacs008CurrentVersion = messageCatalogSpecificationService.findMessageCatalogSpecificationByCode("pacs.008").getVersion();

        when(mockedSpiMessagingApis.messagesApi()).thenReturn(mockedMessagesApi);
        ReflectionTestUtils.setField(messageSender, "spiMessagingApis", mockedSpiMessagingApis);
    }

    @AfterEach
    void tearDown() {
        ReflectionTestUtils.setField(messageSender, "spiMessagingApis", spiMessagingApisBean);
        accountTransactionMocker.restoreAll();
    }

    @Autowired
    private EventRepository eventRepository;

    @Test
    void shouldThrowHttpClientErrorExceptionWhenWithoutEventTypeAndEventStatusQueryParameter() {
        SoftAssertions assertions = new SoftAssertions();
        assertions.assertThatThrownBy(() -> getV1SettlementsApi(port, null, null))
            .isInstanceOf(HttpClientErrorException.class);
    }

    @Test
    void shouldNotReturnEventWhenInvalidEventTypeParameter() {
        SoftAssertions assertions = new SoftAssertions();
        assertions.assertThatThrownBy(() -> getV1SettlementsApi(port, "TYPE", ALL_EVENT_STATUS))
            .isInstanceOf(HttpClientErrorException.class);
    }

    @Test
    void shouldNotReturnEventWhenInvalidEventStatusParameter() {
        SoftAssertions assertions = new SoftAssertions();
        assertions.assertThatThrownBy(() -> getV1SettlementsApi(port, ALL_EVENT_TYPE, "STATUS"))
            .isInstanceOf(HttpClientErrorException.class);
    }

    @Test
    void shouldReturnTransactionalEventWhenFilteredByExistentAccountAndBranchNumber() {

        receiptCamt014();
        String paymentEndToEndId1 = sendPayment();
        String paymentEndToEndId2 = sendPayment();
        String receiptEndToEndId = receivePayment();

        SettlementInfoListResponseDTO settlementsResponse =
            getV1SettlementsApi(port, ALL_EVENT_TYPE, ALL_EVENT_STATUS, PARTICIPANT_BRANCH, PARTICIPANT_ACCOUNT).getBody().getData();

        SoftAssertions assertions = new SoftAssertions();

        List<EventEntity> eventsEntity = eventRepository.findAll();

        assertions.assertThat(eventsEntity).hasSize(4);

        assertions.assertThat(settlementsResponse.getContent()).hasSize(3);

        assertions.assertThat(settlementsResponse.getContent())
            .filteredOn(s -> s.getEndToEndId().equals(paymentEndToEndId1)
                             && s.getEventType().name().equals(EventType.PAYMENT.name())).hasSize(1);

        assertions.assertThat(settlementsResponse.getContent())
            .filteredOn(s -> s.getEndToEndId().equals(paymentEndToEndId2)
                             && s.getEventType().name().equals(EventType.PAYMENT.name())).hasSize(1);

        assertions.assertThat(settlementsResponse.getContent())
            .filteredOn(s -> s.getEndToEndId().equals(receiptEndToEndId)
                             && s.getEventType().name().equals(EventType.RECEIPT.name())).hasSize(1);

        assertions.assertAll();

    }

    @Test
    void shouldNotReturnTransactionalEventWhenNotFoundBranchAndAccountNumberFilter() {

        receiptCamt014();
        sendPayment();
        receivePayment();

        Integer branch = new Random().nextInt(99);
        Integer accountNumber = new Random().nextInt(99);
        SettlementInfoListResponseDTO settlementsResponse =
            getV1SettlementsApi(port, ALL_EVENT_TYPE, ALL_EVENT_STATUS, branch.toString(), accountNumber.toString())
                .getBody()
                .getData();

        List<EventEntity> eventsEntity = eventRepository.findAll();

        SoftAssertions assertions = new SoftAssertions();
        assertions.assertThat(eventsEntity).hasSize(3);
        assertions.assertThat(settlementsResponse.getContent()).isNullOrEmpty();
        assertions.assertAll();

    }

    @Test
    void shouldReturnAllTransactionalEventWhenAllEventStatusAndEventType() {

        receiptCamt014();
        String paymentEndToEndId = sendPayment();
        String receiptEndToEndId = receivePayment();

        SettlementInfoListResponseDTO settlementsResponse =
            getV1SettlementsApi(port, ALL_EVENT_TYPE, ALL_EVENT_STATUS).getBody().getData();

        SoftAssertions assertions = new SoftAssertions();

        List<EventEntity> eventsEntity = eventRepository.findAll();

        assertions.assertThat(eventsEntity).hasSize(3);

        assertions.assertThat(settlementsResponse.getContent()).hasSize(2);

        assertions.assertThat(settlementsResponse.getContent())
                .filteredOn(s -> s.getEndToEndId().equals(paymentEndToEndId)
                                 && s.getEventType().name().equals(EventType.PAYMENT.name())).hasSize(1);

        assertions.assertThat(settlementsResponse.getContent())
            .filteredOn(s -> s.getEndToEndId().equals(receiptEndToEndId)
                             && s.getEventType().name().equals(EventType.RECEIPT.name())).hasSize(1);

        assertions.assertAll();

    }


    private ResponseEntity<SettlementInfoMateraRestReturnDTO> getV1SettlementsApi(Integer port, String eventType, String eventStatus) {
        return getV1SettlementsApi(port, eventType, eventStatus, null, null);
    }

    private ResponseEntity<SettlementInfoMateraRestReturnDTO> getV1SettlementsApi(Integer port, String eventType, String eventStatus,
                                                                                  String branch, String accountNumber) {
        RestTemplate restTemplate = new RestTemplate();

        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", "Bearer " + RandomStringUtils.randomAlphanumeric(10));

        String url = HTTP_LOCALHOST + port + API_V1_SETTLEMENTS;

        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(url)
            .queryParam("pageSize", PAGE_SIZE)
            .queryParam("pageNumber", PAGE_NUMBER);

        if(StringUtils.isNotEmpty(eventStatus)){
            uriBuilder.queryParam("eventStatus", eventStatus);
        }

        if(StringUtils.isNotEmpty(eventType)){
            uriBuilder.queryParam("eventType", eventType);
        }

        if(StringUtils.isNotEmpty(branch)){
            uriBuilder.queryParam("branch", branch);
        }

        if(StringUtils.isNotEmpty(accountNumber)){
            uriBuilder.queryParam("accountNumber", accountNumber);
        }

        ResponseEntity<SettlementInfoMateraRestReturnDTO> settlementInfoListResponseDTO =
            restTemplate.getForEntity(uriBuilder.toUriString(), SettlementInfoMateraRestReturnDTO.class);

        return settlementInfoListResponseDTO;
    }

    private String sendPayment() {
        String endToEndId = CorrelationIdGenerator.generateCorrelactionIdPacs008(String.valueOf(PARTICIPANT_ISPB));
        String expectedPiResourceId = mockMessageSender();
        InstantPaymentsUIDTO instantPayment = createInstantPaymentsUIDTOMock(
                                                    endToEndId, InstantPaymentCreationUtils.OperationType.PAYMENT);
        paymentsService.sendPayments(instantPayment);
        return endToEndId;
    }

    private String receivePayment() {

        mockMessageSender();

        String endToEndId = CorrelationIdGenerator.generateCorrelactionIdPacs008(String.valueOf(PARTICIPANT_ISPB));

        InstantPaymentsUIDTO instantPaymentsUIDTO = createInstantPaymentsUIDTOMock(endToEndId, InstantPaymentCreationUtils.OperationType.RECEIPT);

        String messageReceivedVersion = "1.3";
        String receivedPacs008PiResourceId = getRandomPiResourceId();
        messageReceiver.readIncomingMessage(buildReceivedPacs008(receivedPacs008PiResourceId, instantPaymentsUIDTO, messageReceivedVersion));

        return endToEndId;
    }

    private void receiptCamt014() {
        String camt014RptTag = buildCamt014RptTag("67676767", "", TYPE_INDIRECT, STATUS_ENABLE);
        String camt014Message = buildReceivedCamt014("", camt014RptTag,"1.0", CAMT014_ENVELOPE_NAMESPACE,
            CREATION_DATE_TIME);

        messageReceiver.readIncomingMessage(camt014Message);
    }

    protected String mockMessageSender() {
        String expectedPiResourceId = getRandomPiResourceId();
        when(mockedMessagesApi.sendsMessageV1(any(MessageSpecificationDTO.class))).thenReturn(createMessageSentResponseDTO(expectedPiResourceId));
        return expectedPiResourceId;
    }

}
