package matera.spi.lm.application.services.validation;

import matera.spi.lm.application.service.validation.PageableValidation.PageableValidator;
import matera.spi.lm.exception.LiquidityManagementException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

public class PageableValidatorTest {

    @Spy
    private PageableValidator pageableValidator;

    @BeforeEach
    void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void shouldThrowExceptionWhenPageSizeIsNull() {
        Assertions.assertThrows(LiquidityManagementException.class, () -> pageableValidator.validate(null, 0));
    }

    @Test
    void shouldThrowExceptionWhenPageSizeIsNotGreaterOrEqualToOne() {
        Assertions.assertThrows(LiquidityManagementException.class, () -> pageableValidator.validate(0, 0));
    }

    @Test
    void shouldThrowExceptionWhenPageNumberIsNull() {
        Assertions.assertThrows(LiquidityManagementException.class, () -> pageableValidator.validate(1, null));
    }

    @Test
    void shouldThrowExceptionWhenPageSizeIsNotGreaterOrEqualToZero() {
        Assertions.assertThrows(LiquidityManagementException.class, () -> pageableValidator.validate(0, -1));
    }

    @Test
    void shouldThrowExceptionWhenOrderingDirectionHasInvalidValue() {
        Assertions.assertThrows(LiquidityManagementException.class, () -> pageableValidator.validate(1, 0, "DESCTest"));
    }

}
