package matera.spi.main.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.event.EventTypeEntity;
import matera.spi.main.domain.model.message.MessageTypeEntity;
import matera.spi.main.domain.model.message.RelMsgTypeOriginalEventEntity;
import matera.spi.main.domain.model.message.RelMsgTypeOriginalEventPK;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.opentest4j.AssertionFailedError;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.function.Supplier;

import static org.assertj.core.api.Assertions.assertThat;

@IntegrationTest
class RelMsgTypeOriginalEventRepositoryTest {

    private static final String ENTITY_NOT_FOUND_WITH_ID = "Entity not found with id ";

    @Autowired
    private RelMsgTypeOriginalEventRepository relMsgTypeOriginalEventRepository;

    @Autowired
    private MessageTypeRepository messageTypeRepository;

    @Autowired
    private EventTypeRepository eventTypeRepository;

    @Test
    void shouldBeFindEntityWhenInserted() {
        RelMsgTypeOriginalEventEntity expected = new RelMsgTypeOriginalEventEntity();
        expected.setId(buildPK());

        relMsgTypeOriginalEventRepository.saveAndFlush(expected);

        RelMsgTypeOriginalEventEntity actual =
            relMsgTypeOriginalEventRepository.findById(expected.getId()).orElse(null);
        Assertions.assertEquals(expected, actual);
        relMsgTypeOriginalEventRepository.delete(expected);

        eventTypeRepository.deleteById(1002);
    }

    @DisplayName("verifying if defaults was inserted correctly at me_rel_msg_type_original_event")
    @ParameterizedTest(name = "Message type: {0} | Original event type: {1}")
    @CsvFileSource(resources = "/parameterized/csv/RelMsgTypeOriginalEventRepositoryTest-default-values.csv", numLinesToSkip = 1)
    void shouldFindDefaultValuesInsertedAtMeRelMsgTypeOriginalEvent(String messageType,
                                                                    String expectedOriginalEventType) {

        EventTypeEntity expectedEventType = eventTypeRepository.findByDescription(expectedOriginalEventType)
            .orElseThrow(() -> new AssertionFailedError("Not found eventType " + expectedOriginalEventType));

        MessageTypeEntity messageTypeEntity = messageTypeRepository.findById(messageType)
            .orElseThrow(() -> new AssertionFailedError("Not found messageType " + messageType));

        RelMsgTypeOriginalEventPK id = buildPK(messageTypeEntity, expectedEventType);
        RelMsgTypeOriginalEventEntity actual = relMsgTypeOriginalEventRepository.findById(id).orElse(null);

        assertThat(actual).isNotNull();
    }

    private RelMsgTypeOriginalEventPK buildPK() {
        return buildPK(buildMessageTypeEntity(), buildEventTypeEntity());
    }

    private RelMsgTypeOriginalEventPK buildPK(MessageTypeEntity messageTypeEntity, EventTypeEntity eventTypeEntity) {
        RelMsgTypeOriginalEventPK pk = new RelMsgTypeOriginalEventPK();
        pk.setReceivedMessageTypeCode(messageTypeEntity);
        pk.setOriginalEventTypeCode(eventTypeEntity);
        return pk;
    }

    private MessageTypeEntity buildMessageTypeEntity() {
        MessageTypeEntity entity = new MessageTypeEntity();
        entity.setCode("MessageCodeTest");
        entity.setIsFinancial(false);

        messageTypeRepository.saveAndFlush(entity);

        return entity;
    }

    private EventTypeEntity buildEventTypeEntity() {
        EventTypeEntity entity = new EventTypeEntity();
        entity.setCode(1002);
        entity.setDescription("Description Event Type 2");

        eventTypeRepository.saveAndFlush(entity);

        return entity;
    }

    @Test
    void shouldExistsReda031Relation() {
        final int expectedEventTypeId = 18;
        final String expectedMessageType = "reda.016";

        //@formatter:off
        final EventTypeEntity eventTypeEntity = eventTypeRepository
            .findById(expectedEventTypeId)
            .orElseThrow(entityNotFoundWithId(expectedEventTypeId));

        final MessageTypeEntity messageTypeEntity = messageTypeRepository
            .findById(expectedMessageType)
            .orElseThrow(entityNotFoundWithId(expectedMessageType));

        final RelMsgTypeOriginalEventPK relMsgTypeOriginalEventPK = RelMsgTypeOriginalEventPK
            .builder()
            .originalEventTypeCode(eventTypeEntity)
            .receivedMessageTypeCode(messageTypeEntity)
            .build();

        final RelMsgTypeOriginalEventEntity entity = relMsgTypeOriginalEventRepository
            .findById(relMsgTypeOriginalEventPK)
            .orElseThrow(entityNotFoundWithId(relMsgTypeOriginalEventPK));

        //@formatter:on
        org.assertj.core.api.Assertions.assertThat(entity).isNotNull();
    }

    private Supplier<RuntimeException> entityNotFoundWithId(Object entityId) {
        return () -> {
            throw new AssertionFailedError(ENTITY_NOT_FOUND_WITH_ID.concat(String.valueOf(entityId)));
        };
    }
}
