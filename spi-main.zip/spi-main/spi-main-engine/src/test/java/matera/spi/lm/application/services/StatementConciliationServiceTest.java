package matera.spi.lm.application.services;

import matera.spi.dto.ConciliationPeriodRequiredDTO;
import matera.spi.lm.application.service.statements.StatementConciliationService;
import matera.spi.lm.domain.model.event.IpAccountStatementQueryDetailsEntity;
import matera.spi.mainengine.utils.Asserts;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@ExtendWith(MockitoExtension.class)
class StatementConciliationServiceTest {

    @InjectMocks
    private StatementConciliationService statementConciliationService;

    @BeforeEach
    void beforeEach() {
    }

    @Test
    void shouldReturnListConciliationPeriodRequired() throws Exception {

        List<IpAccountStatementQueryDetailsEntity> listDetailsEntity = new ArrayList<>();

        listDetailsEntity.add(mockDetailsEntityConciliationPeriod(
            LocalDateTime.of(2020,6, 6, 17, 0, 0),
            LocalDateTime.of(2020,6, 8, 12, 0, 0)));

        listDetailsEntity.add(mockDetailsEntityConciliationPeriod(
            LocalDateTime.of(2020,7, 8, 11, 0, 0),
            LocalDateTime.of(2020,7, 13, 10, 34, 16)));

        listDetailsEntity.add(mockDetailsEntityConciliationPeriod(
            LocalDateTime.of(2020,6, 10, 13, 5, 45),
            LocalDateTime.of(2020,6, 10, 15, 34, 16)));

        listDetailsEntity.add(mockDetailsEntityConciliationPeriod(
            LocalDateTime.of(2020,7, 8, 11, 10, 45),
            LocalDateTime.of(2020,7, 10, 10, 34, 16)));

        listDetailsEntity.add(mockDetailsEntityConciliationPeriod(
            LocalDateTime.of(2020,6, 7, 16, 10, 45),
            LocalDateTime.of(2020,6, 8, 10, 34, 16)));

        LocalDateTime startTime = LocalDateTime.of(2020,6, 1, 8, 0, 0);
        LocalDateTime endTime = LocalDateTime.of(2020,10, 31, 21, 0, 0);

        List<ConciliationPeriodRequiredDTO> result = statementConciliationService.extractPeriodNotConciliated(listDetailsEntity, startTime, endTime);

        Asserts.assertEquals(LocalDateTime.of(2020, 6, 1, 8, 0, 0), result.get(0).getStartPeriodTimestamp());
        Asserts.assertEquals(LocalDateTime.of(2020, 6, 6, 17, 0,0), result.get(0).getEndPeriodTimestamp());

        Asserts.assertEquals(LocalDateTime.of(2020, 6, 8, 12, 0,0), result.get(1).getStartPeriodTimestamp());
        Asserts.assertEquals(LocalDateTime.of(2020, 6, 10, 13, 5,45), result.get(1).getEndPeriodTimestamp());

        Asserts.assertEquals(LocalDateTime.of(2020, 6, 10, 15, 34,16), result.get(2).getStartPeriodTimestamp());
        Asserts.assertEquals(LocalDateTime.of(2020, 7, 8, 11, 0,0), result.get(2).getEndPeriodTimestamp());

        Asserts.assertEquals(LocalDateTime.of(2020, 7, 13, 10, 34,16), result.get(3).getStartPeriodTimestamp());
        Asserts.assertEquals(LocalDateTime.of(2020, 10, 31, 21, 0,0), result.get(3).getEndPeriodTimestamp());
    }

    @Test
    void shouldReturnListConciliationPeriodRequiredWithAdjacentPeriod() throws Exception {

        List<IpAccountStatementQueryDetailsEntity> listDetailsEntity = new ArrayList<>();

        listDetailsEntity.add(mockDetailsEntityConciliationPeriod(
            LocalDateTime.of(2020,6, 6, 17, 0, 0),
            LocalDateTime.of(2020,6, 8, 12, 0, 0)));

        listDetailsEntity.add(mockDetailsEntityConciliationPeriod(
            LocalDateTime.of(2020,6, 8, 12, 0, 0),
            LocalDateTime.of(2020,6, 10, 13, 5, 45)));

        listDetailsEntity.add(mockDetailsEntityConciliationPeriod(
            LocalDateTime.of(2020,6, 10, 13, 5, 45),
            LocalDateTime.of(2020,6, 10, 15, 34, 16)));

        LocalDateTime startTime = LocalDateTime.of(2020,6, 1, 8, 0, 0);
        LocalDateTime endTime = LocalDateTime.of(2020,10, 31, 21, 0, 0);

        List<ConciliationPeriodRequiredDTO> result = statementConciliationService.extractPeriodNotConciliated(listDetailsEntity, startTime, endTime);

        Asserts.assertEquals(LocalDateTime.of(2020, 6, 1, 8, 0, 0), result.get(0).getStartPeriodTimestamp());
        Asserts.assertEquals(LocalDateTime.of(2020, 6, 6, 17, 0,0), result.get(0).getEndPeriodTimestamp());

        Asserts.assertEquals(LocalDateTime.of(2020, 6, 10, 15, 34,16), result.get(1).getStartPeriodTimestamp());
        Asserts.assertEquals(LocalDateTime.of(2020, 10, 31, 21, 0,0), result.get(1).getEndPeriodTimestamp());

    }

    @Test
    void shouldReturnListConciliationPeriodRequiredWithInitialPeriodAfterStartTimeParameter() throws Exception {

        List<IpAccountStatementQueryDetailsEntity> listDetailsEntity = new ArrayList<>();

        listDetailsEntity.add(mockDetailsEntityConciliationPeriod(
            LocalDateTime.of(2020,6, 1, 8, 0, 0),
            LocalDateTime.of(2020,6, 8, 12, 0, 0)));

        LocalDateTime startTime = LocalDateTime.of(2020,6, 1, 8, 0, 0);
        LocalDateTime endTime = LocalDateTime.of(2020,6, 20, 21, 0, 0);

        List<ConciliationPeriodRequiredDTO> result = statementConciliationService.extractPeriodNotConciliated(listDetailsEntity, startTime, endTime);

        Asserts.assertEquals(LocalDateTime.of(2020, 6, 8,12, 0, 0), result.get(0).getStartPeriodTimestamp());
        Asserts.assertEquals(LocalDateTime.of(2020, 6, 20, 21, 0,0), result.get(0).getEndPeriodTimestamp());

    }

    @Test
    void shouldReturnListConciliationPeriodRequiredWithEndPeriodBeforeEndTimeParameter() throws Exception {

        List<IpAccountStatementQueryDetailsEntity> listDetailsEntity = new ArrayList<>();

        listDetailsEntity.add(mockDetailsEntityConciliationPeriod(
            LocalDateTime.of(2020,6, 4, 8, 0, 0),
            LocalDateTime.of(2020,6, 10, 21, 0, 0)));

        listDetailsEntity.add(mockDetailsEntityConciliationPeriod(
            LocalDateTime.of(2020,6, 15, 8, 0, 0),
            LocalDateTime.of(2020,6, 20, 21, 0, 0)));

        LocalDateTime startTime = LocalDateTime.of(2020,6, 1, 8, 0, 0);
        LocalDateTime endTime = LocalDateTime.of(2020,6, 25, 21, 0, 0);

        List<ConciliationPeriodRequiredDTO> result = statementConciliationService.extractPeriodNotConciliated(listDetailsEntity, startTime, endTime);

        Asserts.assertEquals(LocalDateTime.of(2020, 6, 1,8, 0, 0), result.get(0).getStartPeriodTimestamp());
        Asserts.assertEquals(LocalDateTime.of(2020, 6, 4, 8, 0,0), result.get(0).getEndPeriodTimestamp());

        Asserts.assertEquals(LocalDateTime.of(2020, 6, 10,21, 0, 0), result.get(1).getStartPeriodTimestamp());
        Asserts.assertEquals(LocalDateTime.of(2020, 6, 15, 8, 0,0), result.get(1).getEndPeriodTimestamp());

        Asserts.assertEquals(LocalDateTime.of(2020, 6, 20,21, 0, 0), result.get(2).getStartPeriodTimestamp());
        Asserts.assertEquals(LocalDateTime.of(2020, 6, 25, 21, 0,0), result.get(2).getEndPeriodTimestamp());

    }

    @Test
    void shouldReturnListConciliationPeriodRequiredWithreturnOfRepositoryNull() throws Exception {

        LocalDateTime startTime = LocalDateTime.of(2020,6, 1, 8, 0, 0);
        LocalDateTime endTime = LocalDateTime.of(2020,6, 25, 21, 0, 0);

        List<ConciliationPeriodRequiredDTO> retorno = statementConciliationService.createNotConciliatedFullPeriod(startTime, endTime);

        Asserts.assertEquals(LocalDateTime.of(2020,6, 1, 8, 0, 0), retorno.get(0).getStartPeriodTimestamp());
        Asserts.assertEquals(LocalDateTime.of(2020,6, 25, 21, 0, 0), retorno.get(0).getEndPeriodTimestamp());

    }

    private IpAccountStatementQueryDetailsEntity mockDetailsEntityConciliationPeriod(LocalDateTime startTime, LocalDateTime EndTime) {

        IpAccountStatementQueryDetailsEntity detailsEntity = new IpAccountStatementQueryDetailsEntity();
        detailsEntity.setStartTimestampUtc(startTime);
        detailsEntity.setEndTimestampUtc(EndTime);

        return detailsEntity;
    }

}
