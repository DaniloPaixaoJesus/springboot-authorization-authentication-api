package matera.spi.main.domain.model;

import matera.spi.main.domain.model.event.EventStatusTransitionEntity;
import matera.spi.main.domain.model.event.EventTypeEntity;
import matera.spi.main.domain.model.event.transaction.PaymentEventEntity;
import matera.spi.main.domain.model.event.transaction.ReceiptEventEntity;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.domain.model.message.MessageTypeEntity;
import matera.spi.main.domain.model.transaction.PaymentEntity;
import matera.spi.main.domain.model.transaction.ReceiptEntity;
import org.assertj.core.api.SoftAssertions;
import org.junit.jupiter.api.Test;

import java.util.List;

public class BidirectionalRelationshipEqualsHashCodeToStringTest {

    @Test
    public void equalsShouldNotThrowsException() {

        List<Object> entities = getEntities();
        List<Object> entitiesToCheck = getEntities();

        SoftAssertions assertions = new SoftAssertions();

        for(int i = 0; i < entities.size(); i++) {

            assertions.assertThat(entities.get(0).equals(entitiesToCheck.get(0))).isTrue();
        }

        assertions.assertAll();
    }

    @Test
    public void hashCodeShouldNotThrowsException() {

        List<Object> entities = getEntities();
        List<Object> entitiesToCheck = getEntities();

        SoftAssertions assertions = new SoftAssertions();

        for(int i = 0; i < entities.size(); i++) {

            assertions.assertThat(entities.get(0).hashCode() == entitiesToCheck.get(0).hashCode()).isTrue();
        }

        assertions.assertAll();
    }

    @Test
    public void toStringShouldNotThrowsException() {

        List<Object> entities = getEntities();
        List<Object> entitiesToCheck = getEntities();

        SoftAssertions assertions = new SoftAssertions();

        for(int i = 0; i < entities.size(); i++) {

            assertions.assertThat(entities.get(0).toString().equals(entitiesToCheck.get(0).toString())).isTrue();
        }

        assertions.assertAll();
    }

    private List<Object> getEntities() {

        EventStatusTransitionEntity eventStatusTransitionEntity = new EventStatusTransitionEntity();
        PaymentEventEntity paymentEventEntity = new PaymentEventEntity();
        eventStatusTransitionEntity.setEvent(paymentEventEntity);

        MessageEntity messageEntity = new MessageEntity();
        messageEntity.setEvents(List.of(paymentEventEntity));
        paymentEventEntity.setMessages(List.of(messageEntity));

        MessageTypeEntity messageTypeEntity = new MessageTypeEntity();

        EventTypeEntity eventType = new EventTypeEntity();
        messageTypeEntity.setOriginalEventType(eventType);
        messageTypeEntity.setNewEventType(eventType);
        eventType.setMessageTypeToSend(messageTypeEntity);

        PaymentEntity paymentEntity = new PaymentEntity();

        paymentEntity.setEvent(paymentEventEntity);
        paymentEventEntity.setPaymentEntity(paymentEntity);

        ReceiptEntity receiptEntity = new ReceiptEntity();

        ReceiptEventEntity receiptEventEntity = new ReceiptEventEntity();
        receiptEntity.setEvent(receiptEventEntity);
        receiptEventEntity.setReceiptEntity(receiptEntity);

        return List.of(
                eventStatusTransitionEntity,
                eventType,
                messageEntity,
                messageTypeEntity,
                paymentEntity,
                paymentEventEntity,
                receiptEntity,
                receiptEventEntity);

    }
}
