package matera.spi.main.domain.service;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.ConfigEntity;
import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventStatus;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.persistence.MessageRepository;
import matera.spi.main.persistence.MessageTypeRepository;
import matera.spi.main.persistence.ParticipantRepository;
import matera.spi.main.utils.EntityCreationUtils;
import matera.spi.main.utils.FileUtils;
import matera.spi.main.utils.PaymentTransactionUtils;
import matera.spi.main.utils.WireMockUtils;

import com.github.tomakehurst.wiremock.WireMockServer;
import io.restassured.RestAssured;
import net.javacrumbs.jsonunit.JsonAssert;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import static matera.spi.main.utils.WireMockUtils.V_1_MESSAGES;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.resetAllRequests;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;

@IntegrationTest
public class MessageApiServiceTest  {

    private final Integer ISPB_BACEN = 38166;
    private final UUID FAKE_UUID_EVENT = UUID.fromString("03aa0c62-a87c-4df8-a55b-0eda1333af24");
    private final String RESPONSE_TRANSACTIONS_GET_XML_CONTENT = FileUtils.getStringFromJsonFile(
        "transactions/response_transactions_get_xml_content.json");

    @LocalServerPort
    protected int port;

    @Autowired
    private MessageService messageService;

    @Autowired
    private PaymentTransactionUtils paymentTransactionUtils;

    @Autowired
    private MessageTypeRepository messageTypeRepository;

    @Autowired
    private ConfigurationService configurationService;

    @Autowired
    private ParticipantRepository participantRepository;

    @Autowired
    private MessageRepository messageRepository;

    private EventEntity eventEntity;
    private String piResourceId;

    private static final WireMockServer wireMockServer = WireMockUtils.start();

    @BeforeAll
    static void beforeAll() {
        WireMockUtils.stubMessaging();
    }

    @AfterAll
    static void afterAll() {
        wireMockServer.stop();
    }


    @BeforeEach
    public void beforeEach() {
        RestAssured.port = port;
        resetAllRequests();

        buildContext();
    }

    @Test
    void shouldReturnXmlContentWhenValidPiResourceIdFound() {
        String messagesEndpoint = V_1_MESSAGES + "?piResourceIds=" + piResourceId;
        stubFor(get(messagesEndpoint)
            .withQueryParam("piResourceIds", equalTo(piResourceId))
            .willReturn(aResponse()
                .withStatus(HttpStatus.OK.value())
                .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE)
                .withBody(getResponseBody())));
        final String replyMessage = messageService.getReplyMessage(eventEntity.getId());
        Assertions.assertTrue(getXmlContent().equals(replyMessage));
    }

    @Test
    void shouldReturnNullWhenPiResourceIdListIsEmpty() {
        final String replyMessage = messageService.getReplyMessage(FAKE_UUID_EVENT);
        Assertions.assertNull(replyMessage);
    }

    @Test
    void shouldReturnNullWhenResponseIsEmptyMessage() {
        String messagesEndpoint = V_1_MESSAGES + "?piResourceIds=" + piResourceId;
        stubFor(get(messagesEndpoint)
            .withQueryParam("piResourceIds", equalTo(piResourceId))
            .willReturn(aResponse()
                .withStatus(HttpStatus.OK.value())
                .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE)
                .withBody("{\"data\": {\"messages\": []}}")));
        final String replyMessage = messageService.getReplyMessage(FAKE_UUID_EVENT);
        Assertions.assertNull(replyMessage);
    }

    @Test
    void shouldReturn204NoContentInTransactionsApisWhenDontHavaAnyXmlContent() {
        String messagesEndpoint = V_1_MESSAGES + "?piResourceIds=" + piResourceId;
        stubFor(get(messagesEndpoint)
            .withQueryParam("piResourceIds", equalTo(piResourceId))
            .willReturn(aResponse()
                .withStatus(HttpStatus.OK.value())
                .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE)
                .withBody("{\"messages\": []}")));

        RestAssured.given()
            .when()
            .get("/ui/v1/transaction/"+FAKE_UUID_EVENT+"/xml-content")
            .then()
            .assertThat()
            .statusCode(HttpStatus.NO_CONTENT.value());
    }

    @Test
    void shouldReturnValidResponseInTransactionApi() {
        String messagesEndpoint = V_1_MESSAGES + "?piResourceIds=" + piResourceId;
        stubFor(get(messagesEndpoint)
            .withQueryParam("piResourceIds", equalTo(piResourceId))
            .willReturn(aResponse()
                .withStatus(HttpStatus.OK.value())
                .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE)
                .withBody(getResponseBody())));

        final String responseBody =
            RestAssured.given()
                .when().get("/ui/v1/transaction/" + eventEntity.getId() + "/xml-content")
                .thenReturn().body().asString();

        JsonAssert.assertJsonEquals(RESPONSE_TRANSACTIONS_GET_XML_CONTENT, responseBody);
    }

    private String getResponseBody() {
        return "{\"data\":{\"messages\":[{\"piResourceId\":\""+piResourceId+"\",\"messageType\":\"pacs.008\",\"xml\":\""+getXmlContent()+"\",\"timestamp\":\"2020-05-28T10:44:47\"}]}}";
    }

    private String getXmlContent() {
        return "<pacs.0008><test>This is test response<'/'test><'/'pacs.0008>";
    }

    private void buildContext() {
        final ConfigEntity config = configurationService.findConfig();
        final ParticipantEntity bacen = participantRepository.findByIspb(ISPB_BACEN).get();
        final ParticipantEntity localIspb = participantRepository.findByIspb(config.getIspb()).get();

        eventEntity =
            paymentTransactionUtils.newPaymentEntity(BigDecimal.TEN, EventStatus.INITIALIZED.getCode()).getEvent();
        createAndSaveMessage(bacen, localIspb);
        createAndSaveMessage(localIspb, bacen);
        piResourceId = getPiResourceIds(eventEntity, config);
    }

    private MessageEntity createAndSaveMessage(ParticipantEntity sender, ParticipantEntity receiver) {

        MessageEntity messageEntity = EntityCreationUtils.buildPacs008MessageEntity();

        messageEntity.setMessageTypeEntity(messageTypeRepository.findById("pacs.008").get());
        messageEntity.setSenderParticipant(sender);
        messageEntity.setReceiverParticipant(receiver);
        messageEntity.setHasPermission(true);
        messageEntity.setEvents(List.of(eventEntity));

        return messageRepository.saveAndFlush(messageEntity);
    }

    private String getPiResourceIds(EventEntity eventEntity, ConfigEntity configEntity) {
        return messageRepository.findPiResourceIdMessagesByEventId(eventEntity.getId(), configEntity.getIspb()).get(0);
    }
}
