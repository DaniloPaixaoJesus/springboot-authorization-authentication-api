package matera.spi.main.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.event.EventStatusEntity;
import matera.spi.main.domain.model.event.EventTypeEntity;
import matera.spi.main.domain.model.message.MessageTypeEntity;
import matera.spi.main.domain.model.message.RelMsgStatusEvtStatusEntity;

import org.assertj.core.api.Assertions;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.opentest4j.AssertionFailedError;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Optional;
import java.util.function.Supplier;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@IntegrationTest
class RelMsgStatusEvtStatusRepositoryTest {

    private static final String THE_ENTITY_ENTITY_HAS_NO_NEXT_EVENT_STATUS =
        "The entity %d (RelMsgStatusEvtStatusEntity) has no next EventStatus";
    private static final String ENTITY_NOT_FOUND_WITH_ID = "Entity not found with id ";
    private RelMsgStatusEvtStatusEntity relMsgStatusEvtStatusEntity;

    @Autowired
    private RelMsgStatusEvtStatusRepository relMsgStatusEvtStatusRepository;

    @Autowired
    private EventStatusRepository eventStatusRepository;

    @Autowired
    private MessageTypeRepository messageTypeRepository;

    @Autowired
    private EventTypeRepository eventTypeRepository;

    @BeforeEach
    void init() {
        relMsgStatusEvtStatusEntity = buildRelMsgStatusEvtStatusEntity();
    }

    @AfterEach
    void deleteInsertedValues() {
        relMsgStatusEvtStatusRepository.delete(relMsgStatusEvtStatusEntity);
        eventTypeRepository.deleteById(1003);
        eventStatusRepository.deleteById(1000);
    }

    @Test
    void shouldBeFindEntityWhenInserted() {
        relMsgStatusEvtStatusEntity.setNewEventStatusCode(buildEventStatusEntity());

        relMsgStatusEvtStatusRepository.saveAndFlush(relMsgStatusEvtStatusEntity);

        RelMsgStatusEvtStatusEntity actual =
            relMsgStatusEvtStatusRepository.findById(relMsgStatusEvtStatusEntity.getId()).orElse(null);

        assertEquals(relMsgStatusEvtStatusEntity, actual);
    }

    @Test
    void shouldBeAbleToFindNextEventStatusGivenEventTypeTheCurrentEventStatusAMessageTypeAndTheMessageElementStatus() {
        RelMsgStatusEvtStatusEntity eventTypeMessageTypeRelation =
            relMsgStatusEvtStatusRepository.saveAndFlush(relMsgStatusEvtStatusEntity);
        EventStatusEntity nextEventStatus = relMsgStatusEvtStatusRepository
            .findNextEventStatus(relMsgStatusEvtStatusEntity.getEventTypeCode(),
                relMsgStatusEvtStatusEntity.getMessageTypeEntity(), relMsgStatusEvtStatusEntity.getNewEventStatusCode(),
                relMsgStatusEvtStatusEntity.getReportedStatus()).orElseThrow(AssertionFailedError::new);

        assertEquals(eventTypeMessageTypeRelation.getNewEventStatusCode(), nextEventStatus);
    }

    @Test
    void shouldReturnEmptyOptionalWhenNotFoundNextEventStatus() {
        Optional<EventStatusEntity> possibleNextEventStatus = relMsgStatusEvtStatusRepository
            .findNextEventStatus(relMsgStatusEvtStatusEntity.getEventTypeCode(),
                relMsgStatusEvtStatusEntity.getMessageTypeEntity(), relMsgStatusEvtStatusEntity.getNewEventStatusCode(),
                "NON EXISTING STATUS");

        assertThat(possibleNextEventStatus).isEmpty();
    }

    @NotNull
    private RelMsgStatusEvtStatusEntity buildRelMsgStatusEvtStatusEntity() {
        RelMsgStatusEvtStatusEntity relMsgStatusEvtStatusEntity = new RelMsgStatusEvtStatusEntity();
        relMsgStatusEvtStatusEntity.setEventTypeCode(buildEventTypeEntity());
        relMsgStatusEvtStatusEntity.setMessageTypeEntity(buildMessageTypeEntity());
        relMsgStatusEvtStatusEntity.setReportedStatus("ReportedStatusTest");
        relMsgStatusEvtStatusEntity.setNewEventStatusCode(buildEventStatusEntity());
        return relMsgStatusEvtStatusEntity;
    }

    @DisplayName("Searching for newEventStatus default values given the current status a message type and the event type")
    @ParameterizedTest(name = "Event Type: {0} | Message Type: {1} | Reported Status: {2} | Current Status: {3} | Expected New Event Status: {4}")
    @CsvFileSource(resources = "/parameterized/csv/RelMsgStatusEvtStatusRepositoryTest-default-values.csv", numLinesToSkip = 1)
    void shouldFindTheNodeListWhenGivenADocumentThatIsNotNamespaceAware(String eventTypeDescription,
                                                                        String messageTypeId,
                                                                        String reportedStatus,
                                                                        String currentStatus,
                                                                        String expectedNewEventStatus) {

        EventTypeEntity eventTypeEntity = eventTypeRepository.findByDescription(eventTypeDescription)
            .orElseThrow(() -> new AssertionFailedError("Not found eventType " + eventTypeDescription));

        MessageTypeEntity messageTypeEntity = messageTypeRepository.findById(messageTypeId)
            .orElseThrow(() -> new AssertionFailedError("Not found messageType " + messageTypeId));

        EventStatusEntity currentEventStatusEntity = null;
        if (currentStatus != null) {
            currentEventStatusEntity = eventStatusRepository.findByDescription(currentStatus)
                .orElseThrow(() -> new AssertionFailedError("Not found event status " + currentStatus));
        }

        EventStatusEntity nextEventStatus = relMsgStatusEvtStatusRepository
            .findNextEventStatus(eventTypeEntity, messageTypeEntity, currentEventStatusEntity, reportedStatus)
            .orElseThrow(() -> new AssertionFailedError("Fail to findNextEventStatus"));

        EventStatusEntity expectedEventStatusEntity = eventStatusRepository.findByDescription(expectedNewEventStatus)
            .orElseThrow(() -> new AssertionFailedError("Not found event status " + expectedNewEventStatus));

        assertEquals(expectedEventStatusEntity, nextEventStatus);
    }

    @DisplayName("Searching for newEventStatus default values given the current status a message type, the event type and reason code")
    @ParameterizedTest(name = "Event Type: {0} | Message Type: {1} | Reported Status: {2} | Current Status: {3} | Expected New Event Status: {4} | Reason Code: {5}")
    @CsvFileSource(resources = "/parameterized/csv/RelMsgStatusEvtStatusRepositoryTestWithReasonCode.csv", numLinesToSkip = 1)
    void shouldFindTheNodeListWhenGivenADocumentThatIsNotNamespaceAwareWithReasonCode(String eventTypeDescription,
                                                                        String messageTypeId,
                                                                        String reportedStatus,
                                                                        String currentStatus,
                                                                        String expectedNewEventStatus,
                                                                        String reasonCode) {

        EventTypeEntity eventTypeEntity = eventTypeRepository.findByDescription(eventTypeDescription)
            .orElseThrow(() -> new AssertionFailedError("Not found eventType " + eventTypeDescription));

        MessageTypeEntity messageTypeEntity = messageTypeRepository.findById(messageTypeId)
            .orElseThrow(() -> new AssertionFailedError("Not found messageType " + messageTypeId));

        EventStatusEntity currentEventStatusEntity = null;
        if (currentStatus != null) {
            currentEventStatusEntity = eventStatusRepository.findByDescription(currentStatus)
                .orElseThrow(() -> new AssertionFailedError("Not found event status " + currentStatus));
        }

        EventStatusEntity nextEventStatus = relMsgStatusEvtStatusRepository
            .findNextEventStatusWithReasonCode(eventTypeEntity, messageTypeEntity, currentEventStatusEntity, reportedStatus, reasonCode)
            .orElseThrow(() -> new AssertionFailedError("Fail to findNextEventStatus"));

        EventStatusEntity expectedEventStatusEntity = eventStatusRepository.findByDescription(expectedNewEventStatus)
            .orElseThrow(() -> new AssertionFailedError("Not found event status " + expectedNewEventStatus));

        assertEquals(expectedEventStatusEntity, nextEventStatus);
    }

    private MessageTypeEntity buildMessageTypeEntity() {
        MessageTypeEntity entity = new MessageTypeEntity();
        entity.setCode("MessageCodeTest");
        entity.setIsFinancial(false);

        messageTypeRepository.saveAndFlush(entity);

        return entity;
    }

    private EventStatusEntity buildEventStatusEntity() {
        EventStatusEntity entity = new EventStatusEntity();
        entity.setCode(1000);
        entity.setDescription("Event teste");
        entity.setFinalStatus(false);

        eventStatusRepository.saveAndFlush(entity);
        return entity;
    }

    private EventTypeEntity buildEventTypeEntity() {
        EventTypeEntity entity = new EventTypeEntity();
        entity.setCode(1003);
        entity.setDescription("Description Event Type 3");

        eventTypeRepository.saveAndFlush(entity);

        return entity;
    }

    @ParameterizedTest(name = "The ID {arguments} should have a next event status.")
    @ValueSource(ints = {1, 2, 3, 6, 7, 8, 9, 12})
    void shouldExistsANextEventStatus(int relMsgStatusEvtStatusId) {
        //@formatter:off
        final RelMsgStatusEvtStatusEntity entity =
            relMsgStatusEvtStatusRepository
                .findById(relMsgStatusEvtStatusId)
                .orElseThrow(entityNotFoundWithId(relMsgStatusEvtStatusId)); ;

        final EventStatusEntity nextEventStatus = relMsgStatusEvtStatusRepository
            .findNextEventStatus(
                entity.getEventTypeCode(),
                entity.getMessageTypeEntity(),
                entity.getNewEventStatusCode(),
                entity.getReportedStatus())
            .orElseThrow(() -> {
                throw new AssertionFailedError(
                    String.format(THE_ENTITY_ENTITY_HAS_NO_NEXT_EVENT_STATUS, entity.getId()));
            });

        assertEquals(entity.getNewEventStatusCode(), nextEventStatus);
        //@formatter:on
    }

    @ParameterizedTest(name = "The ID {arguments} should NOT have a next event status.")
    @ValueSource(ints = {4, 5, 10, 11, 13, 14, 15})
    void shouldNotExistsANextEventStatus(int relMsgStatusEvtStatusId) {
        //@formatter:off
        final RelMsgStatusEvtStatusEntity entity =
            relMsgStatusEvtStatusRepository
                .findById(relMsgStatusEvtStatusId)
                .orElseThrow(entityNotFoundWithId(relMsgStatusEvtStatusId)); ;

        final Optional<EventStatusEntity> nextEventStatus = relMsgStatusEvtStatusRepository
            .findNextEventStatus(
                entity.getEventTypeCode(),
                entity.getMessageTypeEntity(),
                entity.getNewEventStatusCode(),
                entity.getReportedStatus());

        assertTrue(nextEventStatus.isEmpty());
        //@formatter:on
    }

    @Test
    void shouldExistsReda031RelationForRejection() {
        final int reda031RelationIdForRejection = 24;
        final int expectedEventTypeId = 18;
        final int expectedCurrentEventStatusId = 40;
        final int expectedNewEventStatusId = 36;
        final String expectedMessageType = "reda.016";

        //@formatter:off
        final RelMsgStatusEvtStatusEntity entity = relMsgStatusEvtStatusRepository
            .findById(reda031RelationIdForRejection)
            .orElseThrow(entityNotFoundWithId(reda031RelationIdForRejection));

        final EventTypeEntity eventTypeEntity = eventTypeRepository
            .findById(expectedEventTypeId)
            .orElseThrow(entityNotFoundWithId(expectedEventTypeId));

        final MessageTypeEntity messageTypeEntity = messageTypeRepository
            .findById(expectedMessageType)
            .orElseThrow(entityNotFoundWithId(expectedMessageType));

        final EventStatusEntity eventCurrentStatusEntity = eventStatusRepository
            .findById(expectedCurrentEventStatusId)
            .orElseThrow(entityNotFoundWithId(expectedCurrentEventStatusId));

        final EventStatusEntity eventNewStatusEntity = eventStatusRepository
            .findById(expectedNewEventStatusId)
            .orElseThrow(entityNotFoundWithId(expectedNewEventStatusId));
        //@formatter:on

        Assertions
            .assertThat(entity)
            .isNotNull()
            .hasFieldOrPropertyWithValue("eventTypeCode", eventTypeEntity)
            .hasFieldOrPropertyWithValue("messageTypeEntity", messageTypeEntity)
            .hasFieldOrPropertyWithValue("reportedStatus", "REJT")
            .hasFieldOrPropertyWithValue("currentEventStatus", eventCurrentStatusEntity)
            .hasFieldOrPropertyWithValue("newEventStatusCode", eventNewStatusEntity);
    }

    @Test
    void shouldExistsReda031RelationForComplete() {
        final int reda031RelationIdForRejection = 25;
        final int expectedEventTypeId = 18;
        final int expectedCurrentEventStatusId = 40;
        final int expectedNewEventStatusId = 3;
        final String expectedMessageType = "reda.016";

        //@formatter:off
        final RelMsgStatusEvtStatusEntity entity = relMsgStatusEvtStatusRepository
            .findById(reda031RelationIdForRejection)
            .orElseThrow(entityNotFoundWithId(reda031RelationIdForRejection));

        final EventTypeEntity eventTypeEntity = eventTypeRepository
            .findById(expectedEventTypeId)
            .orElseThrow(entityNotFoundWithId(expectedEventTypeId));

        final MessageTypeEntity messageTypeEntity = messageTypeRepository
            .findById(expectedMessageType)
            .orElseThrow(entityNotFoundWithId(expectedMessageType));

        final EventStatusEntity eventCurrentStatusEntity = eventStatusRepository
            .findById(expectedCurrentEventStatusId)
            .orElseThrow(entityNotFoundWithId(expectedCurrentEventStatusId));

        final EventStatusEntity eventNewStatusEntity = eventStatusRepository
            .findById(expectedNewEventStatusId)
            .orElseThrow(entityNotFoundWithId(expectedNewEventStatusId));
        //@formatter:on

        Assertions
            .assertThat(entity)
            .isNotNull()
            .hasFieldOrPropertyWithValue("eventTypeCode", eventTypeEntity)
            .hasFieldOrPropertyWithValue("messageTypeEntity", messageTypeEntity)
            .hasFieldOrPropertyWithValue("reportedStatus", "COMP")
            .hasFieldOrPropertyWithValue("currentEventStatus", eventCurrentStatusEntity)
            .hasFieldOrPropertyWithValue("newEventStatusCode", eventNewStatusEntity);
    }

    private Supplier<RuntimeException> entityNotFoundWithId(Object entityId) {
        return () -> {
            throw new AssertionFailedError(ENTITY_NOT_FOUND_WITH_ID.concat(String.valueOf(entityId)));
        };
    }

}
