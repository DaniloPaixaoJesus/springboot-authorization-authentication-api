package matera.spi.main.domain.service;

import org.apache.commons.lang.StringUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class EndToEndIdGeneratorTest {

    private static final String ISPB = "12345678";
    private static final String ISPB_LENGTH_THREE = "123";
    private static final String PREFIX_TO_COMPARE_ISPB_THREE = "E00000123";
    private static final int LENGTH_MAX_END_TO_END_ID = 32;

    @Test
    void shouldReturnCorrectEndToEndId() {
        String returnedValue = CorrelationIdGenerator.generateCorrelactionIdPacs008(ISPB);
        String timestamp = returnedValue.substring(9, 21);

        Instant instant = Instant.now();
        ZonedDateTime zonedDateTime = ZonedDateTime.ofInstant(instant, ZoneOffset.UTC);

        assertEquals(true, returnedValue.matches("[A-Za-z0-9]+"));
        assertEquals(LENGTH_MAX_END_TO_END_ID ,returnedValue.length());
        assertEquals('E', returnedValue.charAt(0));
        assertEquals(ISPB.toString(), returnedValue.substring(1, 9));

        //Verificação do timestamp em milisegundos
        assertEquals(12, timestamp.length());

        //Compara data e hora do timestamp com a data e hora atual, deve ser igual pois são gerados quase no mesmo momento
        assertEquals(ZonedDateTime.now(ZoneOffset.UTC).getYear(), zonedDateTime.getYear());
        assertEquals(ZonedDateTime.now(ZoneOffset.UTC).getMonth(), zonedDateTime.getMonth());
        assertEquals(ZonedDateTime.now(ZoneOffset.UTC).getDayOfMonth(), zonedDateTime.getDayOfMonth());
        assertEquals(ZonedDateTime.now(ZoneOffset.UTC).getHour(), zonedDateTime.getHour());
    }

    @Test
    void shouldThrowIllegalStateException() {
        Assertions.assertThrows(IllegalStateException.class, () -> CorrelationIdGenerator.generateCorrelactionIdPacs008(StringUtils.EMPTY));
    }

    @Test
    void shouldGenerateAEndToEndIDWhenLengthIspbForLessThanEight() {
        String EndToEndID = CorrelationIdGenerator.generateCorrelactionIdPacs008(ISPB_LENGTH_THREE);

        assertTrue(EndToEndID.startsWith(PREFIX_TO_COMPARE_ISPB_THREE));
        assertEquals(LENGTH_MAX_END_TO_END_ID, EndToEndID.length());
    }

}
