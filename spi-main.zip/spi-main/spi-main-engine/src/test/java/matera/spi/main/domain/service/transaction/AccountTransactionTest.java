package matera.spi.main.domain.service.transaction;

import matera.spi.main.dto.AccountTransactionRequestDTO;
import matera.spi.main.dto.AccountTransactionResponseDTO;
import matera.spi.main.dto.QueryBalanceRequestDTO;
import matera.spi.main.dto.QueryBalanceResponseDTO;
import matera.spi.main.transactions.port.AccountTransactionExecutorPort;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Random;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AccountTransactionTest {

    private static final Random RANDOM = new Random();

    @Mock
    private AccountTransactionExecutorPort accountTransactionExecutorPort;

    @InjectMocks
    private AccountTransaction accountTransaction;

    @Test
    void shouldMakeTransaction() {
        AccountTransactionRequestDTO requestDTO = mock(AccountTransactionRequestDTO.class);
        BigDecimal expectedTransactionId = BigDecimal.valueOf(RANDOM.nextLong());
        when(accountTransactionExecutorPort.makeTransaction(requestDTO))
            .thenReturn(AccountTransactionResponseDTO.builder().transactionId(expectedTransactionId).build());

        BigDecimal transactionID = accountTransaction.makeTransaction(requestDTO).getTransactionId();

        assertThat(transactionID).isEqualTo(expectedTransactionId);
        verify(accountTransactionExecutorPort).makeTransaction(requestDTO);
    }

    @Test
    void shouldQueryBalance() {
        QueryBalanceRequestDTO queryRequestDTO = mock(QueryBalanceRequestDTO.class);
        BigDecimal expectedBalanceAvailable = BigDecimal.valueOf(RANDOM.nextLong());
        when(accountTransactionExecutorPort.queryBalance(queryRequestDTO))
            .thenReturn(QueryBalanceResponseDTO.builder().balanceAvailable(expectedBalanceAvailable).build());

        BigDecimal balance = accountTransaction.queryBalance(queryRequestDTO);
        assertThat(balance).isEqualTo(expectedBalanceAvailable);
        verify(accountTransactionExecutorPort).queryBalance(queryRequestDTO);
    }

}
