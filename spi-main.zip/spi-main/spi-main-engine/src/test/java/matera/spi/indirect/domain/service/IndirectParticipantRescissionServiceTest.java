package matera.spi.indirect.domain.service;

import com.matera.commons.rest.controller.MateraErrorListException;
import com.matera.commons.utils.exception.BusinessException;

import matera.spi.indirect.domain.model.ParticipantMipIndirectEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectHistoryEntity;
import matera.spi.indirect.dto.event.IndirectParticipantRescissionEventSpecificationDTO;
import matera.spi.indirect.util.ParticipantMipIndirectDataSetUtil;
import matera.spi.main.domain.model.ConfigEntity;
import matera.spi.main.domain.model.ParticipantMipEntity;
import matera.spi.main.domain.service.ConfigurationService;
import matera.spi.main.domain.service.PrincipalAuthenticationService;
import matera.spi.main.domain.service.event.EventFactory;
import matera.spi.main.exception.EventErrorException;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.transaction.annotation.Transactional;

import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.time.ZoneOffset;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class IndirectParticipantRescissionServiceTest {

    @Mock
    private EventFactory eventFactory;

    @Mock
    private ConfigurationService configurationService;

    @Mock
    private PrincipalAuthenticationService principalAuthenticationService;

    @Mock
    private IndirectParticipantHistoryService indirectParticipantHistoryService;

    @InjectMocks
    private IndirectParticipantRescissionService indirectParticipantRescissionService;

    @Test
    void shouldCreateRescissionEvent() {
        final ParticipantMipEntity participantMip = ParticipantMipIndirectDataSetUtil.createParticipantMip();
        final ParticipantMipIndirectEntity participantMipIndirectEntity = ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(
                ParticipantMipIndirectDataSetUtil.getMockedStatusRepoReturningActiveById(), participantMip);
        final ConfigEntity configEntity = new ConfigEntity();
        final ArgumentCaptor<IndirectParticipantRescissionEventSpecificationDTO> dtoCaptor =
            prepareMocksToCreateNewEvent(configEntity);
        final LocalDateTime dateTimeBeforeEvent = LocalDateTime.now(ZoneOffset.UTC).minusSeconds(10);

        indirectParticipantRescissionService.createRescissionRequest(participantMipIndirectEntity);

        final LocalDateTime dateTimeAfterEvent = LocalDateTime.now(ZoneOffset.UTC);

        verify(eventFactory).createNewEvent(dtoCaptor.capture());
        verify(configurationService).findConfig();
        verify(principalAuthenticationService).getPrincipalAuthentication();

        final IndirectParticipantRescissionEventSpecificationDTO dtoCaptorValue = dtoCaptor.getValue();
        final ParticipantMipIndirectHistoryEntity participantMipIndirectHistory =
            dtoCaptorValue.getParticipantMipIndirectHistory();

        assertThat(participantMipIndirectHistory).isNotNull()
            .hasFieldOrPropertyWithValue("participantMip", participantMipIndirectEntity)
            .hasFieldOrPropertyWithValue("type", ParticipantMipIndirectHistoryEntity.Type.CLEARING_RESCISSION_REQUEST);

        final LocalDateTime eventDateTime = participantMipIndirectHistory.getEventDateTime();

        assertNotNull(eventDateTime);
        assertTrue(eventDateTime.isBefore(dateTimeAfterEvent));
        assertTrue(eventDateTime.isAfter(dateTimeBeforeEvent));
    }

    private ArgumentCaptor<IndirectParticipantRescissionEventSpecificationDTO> prepareMocksToCreateNewEvent(ConfigEntity configEntity) {
        configEntity.setIspb(ParticipantMipIndirectDataSetUtil.ISPB);

        final ArgumentCaptor<IndirectParticipantRescissionEventSpecificationDTO> dtoCaptor =
            ArgumentCaptor.forClass(IndirectParticipantRescissionEventSpecificationDTO.class);

        when(indirectParticipantHistoryService.createHistoryEntityByType(any(), any()))
            .thenCallRealMethod();
        when(configurationService.findConfig()).thenReturn(configEntity);
        when(principalAuthenticationService.getPrincipalAuthentication()).thenReturn(StringUtils.SPACE);
        when(eventFactory.createNewEvent(Mockito.any(IndirectParticipantRescissionEventSpecificationDTO.class)))
            .thenReturn(null);

        return dtoCaptor;
    }

    @Test
    void shouldDoNotRollbackForEventErrorExceptionAndBusinessExceptionAnd() {
        final Method createRescissionEventMethod = Assertions.assertDoesNotThrow(
            () -> indirectParticipantRescissionService.getClass()
                .getMethod("createRescissionRequest", ParticipantMipIndirectEntity.class));

        final Transactional transactionalAnnotation = createRescissionEventMethod.getAnnotation(Transactional.class);

        assertNotNull(transactionalAnnotation);

        final Class<? extends Throwable>[] noRollbackFor = transactionalAnnotation.noRollbackFor();

        org.assertj.core.api.Assertions.assertThat(noRollbackFor)
            .contains(EventErrorException.class, BusinessException.class, MateraErrorListException.class);
    }

}
