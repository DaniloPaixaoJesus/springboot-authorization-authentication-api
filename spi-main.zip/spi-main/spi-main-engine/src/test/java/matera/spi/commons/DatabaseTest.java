package matera.spi.commons;

import org.springframework.test.context.ActiveProfiles;

import java.lang.annotation.*;

@ActiveProfiles(resolver = DatabaseTestProfileResolver.class)
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface DatabaseTest {
}
