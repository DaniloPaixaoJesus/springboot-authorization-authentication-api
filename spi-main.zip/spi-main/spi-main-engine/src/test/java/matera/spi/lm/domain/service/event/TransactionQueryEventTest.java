package matera.spi.lm.domain.service.event;

import matera.spi.lm.domain.model.TransactionQueryEntity;
import matera.spi.lm.domain.model.event.TransactionQueryEventEntity;
import matera.spi.lm.dto.event.TransactionQueryEventSpecificationDTO;
import matera.spi.main.domain.model.event.EventStatus;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.dto.event.EventSpecificationFromReceivedMessageDTO;
import matera.spi.utils.DocumentUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static matera.spi.utils.DocumentUtils.stringToXmlDocument;
import static matera.spi.utils.LocalDateTimeUtils.parseLocalDateTimeUTC;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;

public class TransactionQueryEventTest {

    private static final String CAMT_054_CONSULTA_LANCAMENTO_PATH = "camt.054/camt.054_consulta_lancamento.xml";
    private static final Document CAMT_054_DOCUMENT = stringToXmlDocument(getStringFromXmlFile(CAMT_054_CONSULTA_LANCAMENTO_PATH));

    @Test
    void shouldPerformActionForReplyMessage() {
        final EventSpecificationFromReceivedMessageDTO eventSpecificationDTO = buildMessageReceivedDTO();
        final MyTransactionQueryEventTest actualQueryEventTest = getTransactionQuery();

        assertTransactionQueryEventBeforeActions(actualQueryEventTest.getEventEntity().getTransactionQueryEntity());
        actualQueryEventTest.actionsForReplyMessage(eventSpecificationDTO);
        assertTransactionQueryEventAfterActions(actualQueryEventTest.getEventEntity().getTransactionQueryEntity());
    }

    private void assertTransactionQueryEventBeforeActions(TransactionQueryEntity transactionQueryEntity) {
        Assertions.assertNull(transactionQueryEntity.getEffectiveTimestamp());
        Assertions.assertNull(transactionQueryEntity.getType());
        Assertions.assertNull(transactionQueryEntity.getValue());
        Assertions.assertNull(transactionQueryEntity.getIspbDebtor());
        Assertions.assertNull(transactionQueryEntity.getIspbCreditor());
    }

    private void assertTransactionQueryEventAfterActions(TransactionQueryEntity transactionQueryEntity) {
        final LocalDateTime effetiveTimestamp = parseLocalDateTimeUTC("2020-01-01T08:30:12.000Z");

        Assertions.assertEquals(effetiveTimestamp, transactionQueryEntity.getEffectiveTimestamp());
        Assertions.assertEquals("D", transactionQueryEntity.getType());
        Assertions.assertEquals(new BigDecimal("1000.00"), transactionQueryEntity.getValue());
        Assertions.assertEquals("13370835", transactionQueryEntity.getIspbDebtor());
        Assertions.assertEquals("00255564", transactionQueryEntity.getIspbCreditor());
    }

    private MyTransactionQueryEventTest getTransactionQuery() {
        final TransactionQueryEventSpecificationDTO transactionQueryEventSpecificationDTO = buildSpecification();
        final MyTransactionQueryEventTest transactionQueryEvent = Mockito.spy(new MyTransactionQueryEventTest(transactionQueryEventSpecificationDTO));
        transactionQueryEvent.getEventEntity().setTransactionQueryEntity(new TransactionQueryEntity());

        doNothing().when(transactionQueryEvent).fireStatusTransition(any(EventStatus.class));
        return transactionQueryEvent;
    }

    private TransactionQueryEventSpecificationDTO buildSpecification() {
        final TransactionQueryEventSpecificationDTO queryEventSpecificationDTO =
            new TransactionQueryEventSpecificationDTO();
        queryEventSpecificationDTO.setEndToEndId("TestEndToEndId");
        return queryEventSpecificationDTO;
    }

    private EventSpecificationFromReceivedMessageDTO buildMessageReceivedDTO() {
        final NodeList nodeList = DocumentUtils.getElementsByExpression(CAMT_054_DOCUMENT, "Envelope/Document/BkToCstmrDbtCdtNtfctn");
        final Node currentNode = nodeList.item(0);

        return EventSpecificationFromReceivedMessageDTO
            .builder()
            .messageEntity(mock(MessageEntity.class))
            .document(CAMT_054_DOCUMENT)
            .specificElement(currentNode)
            .build();
    }

    class MyTransactionQueryEventTest extends TransactionQueryEvent {

        public MyTransactionQueryEventTest(TransactionQueryEventSpecificationDTO transactionQueryEventSpecificationDTO) {
            super(transactionQueryEventSpecificationDTO);
        }

        @Override
        protected void actionsForReplyMessage(EventSpecificationFromReceivedMessageDTO eventSpecification) {
            super.actionsForReplyMessage(eventSpecification);
        }

        @Override
        protected TransactionQueryEventEntity getEventEntity() {
            return super.getEventEntity();
        }

    }
}
