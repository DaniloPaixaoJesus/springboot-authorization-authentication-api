package matera.spi.lm.exception;

import matera.spi.commons.IntegrationTest;

import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;

import java.text.NumberFormat;
import java.util.Locale;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

@IntegrationTest
class BalanceThresholdViolationExceptionTest  {

    public static final Locale LOCALE_BR = Locale.forLanguageTag("pt-br");
    public static final Locale LOCALE_US = Locale.forLanguageTag("en-US");

    @Autowired
    private ReloadableResourceBundleMessageSource messageSource;

    @Test
    void validateLm001MessageEn() {
        NumberFormat currencyInstance = NumberFormat.getCurrencyInstance(LOCALE_US);
        String formattedCurrency = currencyInstance.format(115L);
        BalanceThresholdViolationException ex = new BalanceThresholdViolationException("SPI-LM-001", 50, formattedCurrency);
        String expected = "With this operation, the resulting balance (50) would be lesser than the minimum balance threshold ($115.00)";
        String formatedMessage = getMessage(ex,LOCALE_US);

        assertThat(formatedMessage, is(expected));
    }

    @Test
    void validateLm002MessageEn() {
        NumberFormat currencyInstance = NumberFormat.getCurrencyInstance(LOCALE_US);
        String formattedCurrency = currencyInstance.format(200);
        BalanceThresholdViolationException ex = new BalanceThresholdViolationException("SPI-LM-002", 350, formattedCurrency);
        String expected = "With this operation, the resulting balance (350) would be upper than the maximum balance threshold ($200.00)";
        String formatedMessage = getMessage(ex, LOCALE_US);

        assertThat(formatedMessage, is(expected));
    }

    @Test
    void validateLm001MessagePtBR() {
        LocaleContextHolder.setLocale(LOCALE_BR);
        NumberFormat currencyInstance = NumberFormat.getCurrencyInstance(LOCALE_BR);
        String formattedCurrency = currencyInstance.format(115L);
        BalanceThresholdViolationException ex = new BalanceThresholdViolationException("SPI-LM-001", 50, formattedCurrency);
        String expected = "Com esta operação, o saldo resultante (50) seria menor que o limite mínimo do saldo (R$ 115,00)";
        String formatedMessage = getMessage(ex, LOCALE_BR);

        assertThat(formatedMessage, is(expected));
    }

    @Test
    void validateLm002MessagePtBR() {
        LocaleContextHolder.setLocale(LOCALE_BR);
        NumberFormat currencyInstance = NumberFormat.getCurrencyInstance(LOCALE_BR);
        String formattedCurrency = currencyInstance.format(200);
        BalanceThresholdViolationException ex = new BalanceThresholdViolationException("SPI-LM-002", 350, formattedCurrency);
        String expected = "Com esta operação, o saldo resultante (350) seria maior que o limite máximo do saldo (R$ 200,00)";
        String formatedMessage = getMessage(ex, LOCALE_BR);

        assertThat(formatedMessage, is(expected));
    }

    @Test
    void validateLm003Message() {
        BalanceThresholdViolationException ex = new BalanceThresholdViolationException("SPI-LM-003", 123);

        String expected = "There is a pending IP Account Withdraw Event. Event ID=123";
        String formatedMessage = getMessage(ex, LOCALE_US);

        assertThat(formatedMessage, is(expected));
    }

    @Test
    void validateLm004Message() {
        BalanceThresholdViolationException ex = new BalanceThresholdViolationException("SPI-LM-004", 123);
        String expected = "There is a pending IP Account Deposit Event. Event ID=123";
        String formatedMessage = getMessage(ex, LOCALE_US);

        assertThat(formatedMessage, is(expected));
    }

    @NotNull
    private String getMessage(BalanceThresholdViolationException ex, Locale locale) {
        // Replacing non-breaking spaces
        return messageSource.getMessage(ex.getCode(), ex.getArgs(), locale).replaceAll("\\u00a0", " ");
    }

}
