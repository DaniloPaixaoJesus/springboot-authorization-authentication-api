package matera.spi.main.utils;

import matera.spi.utils.DocumentUtils;

import org.springframework.core.io.Resource;
import org.springframework.util.FileCopyUtils;
import org.w3c.dom.Document;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

public class FileUtils {

	private static final String XML_DIR = "src/test/resources/examples";
	private static final String JSON_DIR = "src/test/resources/examples/json";

	private FileUtils() {/* utility class should not be instantiated*/}

	public static String getStringFromXmlFile(String filePath) {
		return getStringFromFile(XML_DIR, filePath);
	}

    public static Document getDocumentFromXmlFile(String filePath) {
        return DocumentUtils.stringToXmlDocument(getStringFromXmlFile(filePath));
    }

	public static String getStringFromJsonFile(String filePath) {
		return getStringFromFile(JSON_DIR, filePath);
	}

    public static String getStringFromFile(String fileDirectory, String filePath) {
        try {
            return Files.readString(Paths.get(fileDirectory, filePath), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new RuntimeException("Failed to read file: " + filePath, e);
        }
    }

    public static String getStringFromFile(String filePath) {
        try {
            return Files.readString(Paths.get(filePath), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new RuntimeException("Failed to read file: " + filePath, e);
        }
    }

	public static String resourceAsString(Resource resource) {
		try (Reader reader = new InputStreamReader(resource.getInputStream(), StandardCharsets.UTF_8)) {
			return FileCopyUtils.copyToString(reader);
		} catch (IOException e) {
			throw new UncheckedIOException("Not found resource: " + resource, e);
		}
	}
}
