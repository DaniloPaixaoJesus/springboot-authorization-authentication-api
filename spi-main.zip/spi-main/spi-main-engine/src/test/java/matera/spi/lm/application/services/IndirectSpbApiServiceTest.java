package matera.spi.lm.application.services;

import matera.spi.lm.application.service.spbService.IndirectSpbApiService;
import matera.spi.lm.exception.IndirectParticipantOperationInvalidException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class IndirectSpbApiServiceTest {

    @Spy
    private IndirectSpbApiService indirectSpbApiService;

    @Test
    void shouldThrowExceptionWhenRequestToProccessSpbReply() {
        Assertions.assertThrows(IndirectParticipantOperationInvalidException.class,
            () -> indirectSpbApiService.proccessSpbReply(Mockito.any()));
    }

}
