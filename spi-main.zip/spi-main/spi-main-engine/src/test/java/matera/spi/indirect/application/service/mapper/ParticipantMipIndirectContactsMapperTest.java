package matera.spi.indirect.application.service.mapper;

import matera.spi.dto.IndirectParticipantContactDTO;
import matera.spi.indirect.domain.model.ParticipantMipIndirectContactsEntity;
import matera.spi.indirect.domain.model.ParticipantMipIndirectEntity;
import matera.spi.indirect.persistence.ParticipantMipIndirectStatusRepository;
import matera.spi.indirect.util.ParticipantMipIndirectDataSetUtil;
import matera.spi.main.domain.model.ParticipantMipEntity;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doReturn;

@ExtendWith(MockitoExtension.class)
class ParticipantMipIndirectContactsMapperTest {

    @Mock
    private ParticipantMipIndirectStatusRepository participantMipIndirectStatusRepository;

    @Test
    void shouldMapEntityToDTO() {
        doReturn(Optional.of(ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectStatusEntity()))
            .when(participantMipIndirectStatusRepository).findById(Mockito.any());

        final ParticipantMipEntity participantMip = ParticipantMipIndirectDataSetUtil.createParticipantMip();
        final ParticipantMipIndirectEntity participantMipIndirectEntity = ParticipantMipIndirectDataSetUtil
            .createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository, participantMip);
        final ParticipantMipIndirectContactsEntity entity =
            ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectContactsEntity(participantMipIndirectEntity);
        final IndirectParticipantContactDTO dto =
            ParticipantMipIndirectContactsMapper.mapToIndirectParticipantContactDTO(entity);

        assertEquals(entity.getDepartment(), dto.getDepartment());
        assertEquals(entity.getEmail(), dto.getEmail());
        assertEquals(entity.getName(), dto.getName());
        assertEquals(entity.getPhone(), dto.getPhone());

        assertEquals(ParticipantMipIndirectDataSetUtil.DEPARTMENT, dto.getDepartment());
        assertEquals(ParticipantMipIndirectDataSetUtil.EMAIL, dto.getEmail());
        assertEquals(ParticipantMipIndirectDataSetUtil.CONTACT_NAME, dto.getName());
        assertEquals(ParticipantMipIndirectDataSetUtil.PHONE, dto.getPhone());
    }

    @Test
    void shouldThrowExceptionWhenArgumentIsNull() {
        final NullPointerException nullPointerException = assertThrows(NullPointerException.class,
            () -> ParticipantMipIndirectContactsMapper.mapToIndirectParticipantContactDTO(null));

        assertEquals(
            ParticipantMipIndirectContactsMapper.THE_PARTICIPANT_MIP_INDIRECT_CONTACTS_ENTITY_PARAMETER_IS_REQUIRED,
            nullPointerException.getMessage());
    }

}
