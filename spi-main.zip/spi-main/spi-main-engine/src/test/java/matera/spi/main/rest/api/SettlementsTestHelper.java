package matera.spi.main.rest.api;

import matera.spi.dto.AccountTypeDTO;
import matera.spi.dto.InstantPaymentSettlementRequestDTO;
import matera.spi.dto.LocalAccountBaseDTO;
import matera.spi.dto.PaymentsUIDTO;
import matera.spi.dto.ReceiverDTO;
import matera.spi.dto.RemoteAccountDTO;
import matera.spi.dto.SettlementPayerDTO;
import matera.spi.main.domain.service.CorrelationIdGenerator;
import matera.spi.main.utils.constants.TransactionConstants;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SettlementsTestHelper {

    private static final String PAYER_NAME = "João da Silva";

    private SettlementsTestHelper() {}

    public static InstantPaymentSettlementRequestDTO createInvalidInstantPaymentSettlementRequestDTO() {

        return createInstantPaymentSettlementRequestDTO(createPayerInvalidUIDTOMock(), createReceiverInvalidUIDTOMock());
    }

    public static Map<String, String> createJsonXmlMapping(boolean hasAddressingKey) {

        Map<String, String> jsonXmlMapping = new HashMap<>();

        jsonXmlMapping.put("$.customerInitiationTimestampUTC", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/AccptncDtTm");
        jsonXmlMapping.put("$.receiver.receiverTaxId", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Cdtr/Id/PrvtId/Othr/Id");
        jsonXmlMapping.put("$.receiver.account.accountNumber", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAcct/Id/Othr/Id");
        jsonXmlMapping.put("$.receiver.account.branch", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAcct/Id/Othr/Issr");

        if (hasAddressingKey) {
            jsonXmlMapping.put("$.receiver.addressingKey", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAcct/Prxy/Id");
        }

        jsonXmlMapping.put("$.payer.account.accountNumber", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/DbtrAcct/Id/Othr/Id");
        jsonXmlMapping.put("$.payer.name", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Dbtr/Nm");
        jsonXmlMapping.put("$.receiver.account.accountType", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAcct/Tp/Cd");
        jsonXmlMapping.put("$.receiver.receiverInstitutionISPB", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAgt/FinInstnId/ClrSysMmbId/MmbId");
        jsonXmlMapping.put("$.value", "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/IntrBkSttlmAmt");

        return jsonXmlMapping;
    }

    public static InstantPaymentSettlementRequestDTO createValidInstantPaymentSettlementRequestDTO(String addressingKey) {

        return createInstantPaymentSettlementRequestDTO(createSettlementPayerDTOMock(), createReceiverDTOMock(addressingKey));
    }

    private static InstantPaymentSettlementRequestDTO createInstantPaymentSettlementRequestDTO(SettlementPayerDTO settlementPayerDTO, ReceiverDTO receiverDTO) {

        InstantPaymentSettlementRequestDTO instantPaymentSettlementRequestDTO = new InstantPaymentSettlementRequestDTO();
        instantPaymentSettlementRequestDTO.setCustomerInitiationTimestampUTC(LocalDateTime.parse("2020-04-14T20:55:28.678", DateTimeFormatter.ISO_DATE_TIME));

        instantPaymentSettlementRequestDTO.setPayer(settlementPayerDTO);
        instantPaymentSettlementRequestDTO.setReceiver(receiverDTO);
        instantPaymentSettlementRequestDTO.setOriginalSystemTransactionIdentifier("147258369");
        instantPaymentSettlementRequestDTO.setInitiatingInstitution(68021144000168L);

        instantPaymentSettlementRequestDTO.setValue(BigDecimal.valueOf(100_000.65));

        instantPaymentSettlementRequestDTO.setAdditionalInformation("Some additional information.");

        instantPaymentSettlementRequestDTO.setOriginSystem("matera");

        return instantPaymentSettlementRequestDTO;
    }

    private static SettlementPayerDTO createPayerInvalidUIDTOMock() {

        SettlementPayerDTO settlementPayerDTO = new SettlementPayerDTO();
        settlementPayerDTO.setAccount(createLocalAccountDTOMock());
        settlementPayerDTO.setCheckCustomerAccountBalance(false);

        return settlementPayerDTO;
    }

    private static SettlementPayerDTO createSettlementPayerDTOMock() {
        return createSettlementPayerDTOMock(PAYER_NAME);
    }

    private static SettlementPayerDTO createSettlementPayerDTOMock(String payerName) {

        SettlementPayerDTO settlementPayerDTO = new SettlementPayerDTO();
        settlementPayerDTO.setName(payerName);
        settlementPayerDTO.setAccount(createLocalAccountDTOMock());
        settlementPayerDTO.setCheckCustomerAccountBalance(false);

        return settlementPayerDTO;
    }

    private static ReceiverDTO createReceiverInvalidUIDTOMock() {

        ReceiverDTO receiverDTO = new ReceiverDTO();
        receiverDTO.setAddressingKey("ADDRESSING_KEY");
        receiverDTO.setReceiverInstitutionISPB(38121);
        receiverDTO.setReceiverTaxId("109876543210");
        receiverDTO.setAccount(createRemoteAccountDTOMock());

        return receiverDTO;
    }

    private static ReceiverDTO createReceiverDTOMock(String addressingKey) {

        ReceiverDTO receiverDTO = new ReceiverDTO();
        receiverDTO.setAddressingKey(addressingKey);
        receiverDTO.setReceiverInstitutionISPB(38121);
        receiverDTO.setReceiverTaxId("28837107080");
        receiverDTO.setAccount(createRemoteAccountDTOMock());

        return receiverDTO;
    }

    private static LocalAccountBaseDTO createLocalAccountDTOMock() {

        LocalAccountBaseDTO localAccountBaseDTO = new LocalAccountBaseDTO();
        localAccountBaseDTO.setAccountNumber(123456L);
        //localAccountBaseDTO.setBranch(777);

        return localAccountBaseDTO;
    }

    private static RemoteAccountDTO createRemoteAccountDTOMock() {

        RemoteAccountDTO remoteAccountDTO = new RemoteAccountDTO();
        remoteAccountDTO.setAccountNumber("123456");
        remoteAccountDTO.setBranch("777");
        remoteAccountDTO.setAccountType(AccountTypeDTO.CACC);

        return remoteAccountDTO;
    }
}
