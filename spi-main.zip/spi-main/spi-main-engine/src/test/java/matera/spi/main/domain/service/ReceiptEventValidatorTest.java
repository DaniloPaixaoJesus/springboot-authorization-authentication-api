package matera.spi.main.domain.service;

import com.matera.client.rest.exception.RestBadRequestException;
import com.matera.commons.rest.dto.MateraRestErrorDTO;
import com.matera.spi.webhook.transaction.model.TransactionIdValidationResponseDTO;

import matera.spi.main.config.MainEngineConfiguration;
import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.domain.model.RejectionReasonEntity;
import matera.spi.main.domain.model.account.PayerAccountEntity;
import matera.spi.main.domain.model.account.ReceiverAccountEntity;
import matera.spi.main.domain.model.event.transaction.ReceiptEventEntity;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.domain.model.message.MessageTypeEntity;
import matera.spi.main.domain.model.transaction.CreditEntity;
import matera.spi.main.domain.model.transaction.ReceiptEntity;
import matera.spi.main.domain.service.event.transaction.customer.ReceiptCustomerValidator;
import matera.spi.main.domain.service.event.transaction.validation.CreditEventValidator;
import matera.spi.main.domain.service.transaction.CustomerAccount;
import matera.spi.main.domain.service.util.RejectionReasonService;
import matera.spi.main.dto.event.EventSpecificationFromReceivedMessageDTO;
import matera.spi.main.exception.EventValidatorException;
import matera.spi.main.utils.EntityCreationUtils;
import matera.spi.utils.DocumentUtils;

import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import static matera.spi.main.domain.service.util.MessageBinderXpathPacs008Utils.getAdditionalInformation;
import static matera.spi.main.domain.service.util.MessageBinderXpathPacs008Utils.getChargeBearer;
import static matera.spi.main.domain.service.util.MessageBinderXpathPacs008Utils.getClearingTimeStampUTC;
import static matera.spi.main.domain.service.util.MessageBinderXpathPacs008Utils.getEndToEnd;
import static matera.spi.main.domain.service.util.MessageBinderXpathPacs008Utils.getInterbankSettlementAmount;
import static matera.spi.main.domain.service.util.MessageBinderXpathPacs008Utils.getPayerAccount;
import static matera.spi.main.domain.service.util.MessageBinderXpathPacs008Utils.getPayerBranch;
import static matera.spi.main.domain.service.util.MessageBinderXpathPacs008Utils.getPayerParticipant;
import static matera.spi.main.domain.service.util.MessageBinderXpathPacs008Utils.getPayerTaxId;
import static matera.spi.main.domain.service.util.MessageBinderXpathPacs008Utils.getPayerTypeAccount;
import static matera.spi.main.domain.service.util.MessageBinderXpathPacs008Utils.getReceiverAccount;
import static matera.spi.main.domain.service.util.MessageBinderXpathPacs008Utils.getReceiverBranch;
import static matera.spi.main.domain.service.util.MessageBinderXpathPacs008Utils.getReceiverParticipant;
import static matera.spi.main.domain.service.util.MessageBinderXpathPacs008Utils.getReceiverTypeAccount;
import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static matera.spi.utils.DocumentUtils.stringToXmlDocument;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import static java.time.format.DateTimeFormatter.ISO_DATE_TIME;


@ExtendWith(MockitoExtension.class)
public class ReceiptEventValidatorTest {

    private static final String PACS_008_PACS_008_SPI_1_2_CONTA_1_MSG_NO_RECEIVER_ACCOUNT_VALUE_XML = "pacs.008/pacs.008.spi.1.2_CONTA_1_msg_NO_RECEIVER_ACCOUNT.xml";
    private static final Document PACS_008_PACS_008_SPI_CONTA_1_DOCUMENT_NO_RECEIVER_ACCOUNT_VALUE = stringToXmlDocument(getStringFromXmlFile(PACS_008_PACS_008_SPI_1_2_CONTA_1_MSG_NO_RECEIVER_ACCOUNT_VALUE_XML));

    private static final String PACS_008_PACS_008_SPI_1_2_CONTA_1_MSG_NO_EVENT_VALUE_XML = "pacs.008/pacs.008.spi.1.2_CONTA_1_msg_NO_EVENT_VALUE.xml";
    private static final Document PACS_008_PACS_008_SPI_CONTA_1_DOCUMENT_NO_EVENT_VALUE = stringToXmlDocument(getStringFromXmlFile(PACS_008_PACS_008_SPI_1_2_CONTA_1_MSG_NO_EVENT_VALUE_XML));

    private static final String PACS_008_PACS_008_SPI_1_2_CONTA_1_MSG_XML = "pacs.008/pacs.008.spi.1.2_CONTA_1_msg.xml";
    private static final Document PACS_008_PACS_008_SPI_CONTA_1_DOCUMENT = stringToXmlDocument(getStringFromXmlFile(PACS_008_PACS_008_SPI_1_2_CONTA_1_MSG_XML));

    private static final String PACS_008_PACS_008_SPI_1_2_CONTA_1_MSG_WITHOUT_TRANSACTION_ID_XML = "pacs.008/pacs.008.spi.1.2_CONTA_1_msg_without_transaction_id.xml";
    private static final Document PACS_008_PACS_008_SPI_CONTA_1_DOCUMENT_WITHOUT_TRANSACTION_ID = stringToXmlDocument(getStringFromXmlFile(PACS_008_PACS_008_SPI_1_2_CONTA_1_MSG_WITHOUT_TRANSACTION_ID_XML));

    private static final String PACS_008_PACS_008_SPI_1_2_CONTA_1_MSG_NO_CPF_CNPJ_XML = "pacs.008/pacs.008.spi.1.2_CONTA_1_msg_NO_CPF_CNPJ.xml";
    private static final Document PACS_008_PACS_008_SPI_CONTA_1_DOCUMENT_NO_CPF_CNPJ = stringToXmlDocument(getStringFromXmlFile(PACS_008_PACS_008_SPI_1_2_CONTA_1_MSG_NO_CPF_CNPJ_XML));

    private static final String PACS_008_PACS_008_SPI_1_2_CONTA_1_MSG_INVALID_CPF_CNPJ_XML = "pacs.008/pacs.008.spi.1.2_CONTA_1_msg_INVALID_CPF_CNPJ.xml";
    private static final Document PACS_008_PACS_008_SPI_CONTA_1_DOCUMENT_INVALID_CPF_CNPJ = stringToXmlDocument(getStringFromXmlFile(PACS_008_PACS_008_SPI_1_2_CONTA_1_MSG_INVALID_CPF_CNPJ_XML));

    private static final String ENVELOPE_DOCUMENT_FITO_FICSTMR_CDT_TRF_CDT_TRF_TX_INF = "/Envelope/Document/FIToFICstmrCdtTrf/CdtTrfTxInf";

    private static final String INVALID_RECEIVER_TAX_ID_ERROR = "CH11";
    private static final String RECEIVER_ACCOUNT_NOT_FOUND_ERROR = "AC03";
    private static final String EVENT_VALUE_NOT_FOUND_ERROR = "AM09";
    private static final String CREDIT_ON_ACCOUNT_NOT_VALIDATED_CODE = "ED05";
    private static final String CREDIT_ON_ACCOUNT_NOT_VALIDATED_DESCRIPTION = "Settlement of the transaction has failed";
    public static final String WEB_HOOK_REJECTION = "Web hook rejection.";

    @InjectMocks
    @Spy
    private ReceiptEventValidator receiptEventValidator;

    @Mock
    private CustomerAccount customerAccount;

    @Mock
    private ReceiptService receiptService;

    @Mock
    private TransactionRejectReasonStandinService transactionRejectReasonStandinService;

    private ReceiptEntity receiptEntity = EntityCreationUtils.buildReceiptEntity();

    @Mock
    private ReceiptCustomerValidator receiptCustomerValidator;

    @Mock
    private WebhookTransactionValidationService webhookTransactionValidationService;

    @Mock
    private MainEngineConfiguration mainEngineConfiguration;

    @Mock
    private RejectionReasonService rejectionReasonService;

    @Mock
    private CreditEventValidator creditEventValidator;

    @Test
    public void shouldValidateOk() throws EventValidatorException {

        MessageEntity messageEntity = getMessageEntity();

        NodeList nodeList = DocumentUtils.getElementsByExpression(PACS_008_PACS_008_SPI_CONTA_1_DOCUMENT,
            ENVELOPE_DOCUMENT_FITO_FICSTMR_CDT_TRF_CDT_TRF_TX_INF);
        Node currentNode = nodeList.item(0);

        EventSpecificationFromReceivedMessageDTO specificationFromMessageDTO = EventSpecificationFromReceivedMessageDTO
            .builder()
            .messageEntity(messageEntity)
            .document(PACS_008_PACS_008_SPI_CONTA_1_DOCUMENT)
            .specificElement(currentNode)
            .build();

        doNothing().when(receiptEventValidator).validateTransactionIdentifier(any(), any());

        receiptEventValidator.validate(specificationFromMessageDTO, receiptEntity);
    }

    @Test
    public void shouldThrowExceptionWhenOrderIsRejected() throws EventValidatorException {


        MessageEntity messageEntity = getMessageEntity();

        NodeList nodeList = DocumentUtils.getElementsByExpression(PACS_008_PACS_008_SPI_CONTA_1_DOCUMENT,
            ENVELOPE_DOCUMENT_FITO_FICSTMR_CDT_TRF_CDT_TRF_TX_INF);
        Node currentNode = nodeList.item(0);

        fillReceiptDTO(currentNode);

        EventSpecificationFromReceivedMessageDTO specificationFromMessageDTO = EventSpecificationFromReceivedMessageDTO
            .builder()
            .messageEntity(messageEntity)
            .document(PACS_008_PACS_008_SPI_CONTA_1_DOCUMENT)
            .specificElement(currentNode)
            .build();

        fillReceiptDTO(currentNode);

        when(mainEngineConfiguration.isTransactionIdentificationActivated()).thenReturn(true);

        when(rejectionReasonService.findById(6)).thenReturn(new RejectionReasonEntity());

        when(webhookTransactionValidationService.queryValidator(any(), any())).thenReturn(new TransactionIdValidationResponseDTO().shouldReceive(false).motive(WEB_HOOK_REJECTION));

        receiptEntity.setReceiverReconIdentifier("159753852654");

        assertThatThrownBy(() -> receiptEventValidator.validate(specificationFromMessageDTO, receiptEntity))
            .isInstanceOf(EventValidatorException.class)
            .hasMessage("Order rejected");

    }

    @Test
    public void shouldValidateWithoutEventValue() throws EventValidatorException {
        MessageEntity messageEntity = getMessageEntity();

        NodeList nodeList = DocumentUtils.getElementsByExpression(PACS_008_PACS_008_SPI_CONTA_1_DOCUMENT_NO_EVENT_VALUE,
            ENVELOPE_DOCUMENT_FITO_FICSTMR_CDT_TRF_CDT_TRF_TX_INF);
        Node currentNode = nodeList.item(0);

        EventSpecificationFromReceivedMessageDTO specificationFromMessageDTO = EventSpecificationFromReceivedMessageDTO
            .builder()
            .messageEntity(messageEntity)
            .document(PACS_008_PACS_008_SPI_CONTA_1_DOCUMENT)
            .specificElement(currentNode)
            .build();

        EventValidatorException exception = assertThrows(EventValidatorException.class, () -> {
            receiptEventValidator.validate(specificationFromMessageDTO, receiptEntity);
        });

        String actualRejectCode = exception.getRejectCode();
        assertTrue(actualRejectCode.equals(EVENT_VALUE_NOT_FOUND_ERROR));
    }

    @Test
    public void shouldValidateWithoutReceiverAccount() throws EventValidatorException {
        MessageEntity messageEntity = getMessageEntity();

        NodeList nodeList = DocumentUtils.getElementsByExpression(PACS_008_PACS_008_SPI_CONTA_1_DOCUMENT_NO_RECEIVER_ACCOUNT_VALUE,
            ENVELOPE_DOCUMENT_FITO_FICSTMR_CDT_TRF_CDT_TRF_TX_INF);
        Node currentNode = nodeList.item(0);

        EventSpecificationFromReceivedMessageDTO specificationFromMessageDTO = EventSpecificationFromReceivedMessageDTO
            .builder()
            .messageEntity(messageEntity)
            .document(PACS_008_PACS_008_SPI_CONTA_1_DOCUMENT)
            .specificElement(currentNode)
            .build();

        EventValidatorException exception = assertThrows(EventValidatorException.class, () -> {
            receiptEventValidator.validate(specificationFromMessageDTO, receiptEntity);
        });

        String actualRejectCode = exception.getRejectCode();
        assertTrue(actualRejectCode.contains(RECEIVER_ACCOUNT_NOT_FOUND_ERROR));
    }

    @Test
    public void shouldValidateWithoutCpfCnpj() throws EventValidatorException {
        MessageEntity messageEntity = getMessageEntity();

        NodeList nodeList = DocumentUtils.getElementsByExpression(PACS_008_PACS_008_SPI_CONTA_1_DOCUMENT_NO_CPF_CNPJ,
            ENVELOPE_DOCUMENT_FITO_FICSTMR_CDT_TRF_CDT_TRF_TX_INF);
        Node currentNode = nodeList.item(0);

        EventSpecificationFromReceivedMessageDTO specificationFromMessageDTO = EventSpecificationFromReceivedMessageDTO
            .builder()
            .messageEntity(messageEntity)
            .document(PACS_008_PACS_008_SPI_CONTA_1_DOCUMENT)
            .specificElement(currentNode)
            .build();

        EventValidatorException exception = assertThrows(EventValidatorException.class, () -> {
            receiptEventValidator.validate(specificationFromMessageDTO, receiptEntity);
        });

        String actualRejectCode = exception.getRejectCode();
        assertTrue(actualRejectCode.contains(INVALID_RECEIVER_TAX_ID_ERROR));
    }

    @Test
    public void shouldValidateInvalidCpf() throws EventValidatorException {
        MessageEntity messageEntity = getMessageEntity();

        NodeList nodeList = DocumentUtils.getElementsByExpression(PACS_008_PACS_008_SPI_CONTA_1_DOCUMENT_INVALID_CPF_CNPJ,
            ENVELOPE_DOCUMENT_FITO_FICSTMR_CDT_TRF_CDT_TRF_TX_INF);
        Node currentNode = nodeList.item(0);

        EventSpecificationFromReceivedMessageDTO specificationFromMessageDTO = EventSpecificationFromReceivedMessageDTO
            .builder()
            .messageEntity(messageEntity)
            .document(PACS_008_PACS_008_SPI_CONTA_1_DOCUMENT)
            .specificElement(currentNode)
            .build();

        EventValidatorException exception = assertThrows(EventValidatorException.class, () -> {
            receiptEventValidator.validate(specificationFromMessageDTO, receiptEntity);
        });

        String actualRejectCode = exception.getRejectCode();
        assertTrue(actualRejectCode.contains(INVALID_RECEIVER_TAX_ID_ERROR));
    }

    @Test
    public void shouldValidateCredit() throws EventValidatorException {
        MessageEntity messageEntity = getMessageEntity();

        NodeList nodeList = DocumentUtils.getElementsByExpression(PACS_008_PACS_008_SPI_CONTA_1_DOCUMENT,
            ENVELOPE_DOCUMENT_FITO_FICSTMR_CDT_TRF_CDT_TRF_TX_INF);
        Node currentNode = nodeList.item(0);

        EventSpecificationFromReceivedMessageDTO specificationFromMessageDTO = EventSpecificationFromReceivedMessageDTO
            .builder()
            .messageEntity(messageEntity)
            .document(PACS_008_PACS_008_SPI_CONTA_1_DOCUMENT)
            .specificElement(currentNode)
            .build();

        fillReceiptDTO(currentNode);

        RestBadRequestException restBadRequestException = new RestBadRequestException(1, null, CREDIT_ON_ACCOUNT_NOT_VALIDATED_CODE, (MateraRestErrorDTO[]) null);


        EventValidatorException eventValidatorException = new EventValidatorException(CREDIT_ON_ACCOUNT_NOT_VALIDATED_CODE, CREDIT_ON_ACCOUNT_NOT_VALIDATED_DESCRIPTION);

        doThrow(eventValidatorException).when(creditEventValidator).validateCredit(any(CreditEntity.class));

        EventValidatorException exception = assertThrows(EventValidatorException.class, () -> {
            receiptEventValidator.validate(specificationFromMessageDTO, receiptEntity);
        });

        String actualRejectCode = exception.getRejectCode();
        assertTrue(actualRejectCode.contains(CREDIT_ON_ACCOUNT_NOT_VALIDATED_CODE));
    }

    @NotNull
    private MessageEntity createMessage(MessageTypeEntity messageTypeEntity) {
        MessageEntity messageEntity = new MessageEntity();
        messageEntity.setMessageTypeEntity(messageTypeEntity);
        messageEntity.setPiResourceId("bla");
        return messageEntity;
    }

    @NotNull
    private MessageEntity getMessageEntity() {
        MessageTypeEntity messageTypeEntity =  new MessageTypeEntity();
        MessageEntity messageEntity = createMessage(messageTypeEntity);
        messageEntity.setMessageTypeEntity(messageTypeEntity);
        return messageEntity;
    }

    private void fillReceiptDTO(Node node) {

        String additionalInformation = getAdditionalInformation(node);
        String chargeBearer = getChargeBearer(node);
        LocalDateTime clearingTimeStampUTC = LocalDateTime.parse(getClearingTimeStampUTC(node), ISO_DATE_TIME);
        String endToEnd = getEndToEnd(node);
        Long initiatingInstitutionTaxId = null;
        BigDecimal interbankSettlementAmount = new BigDecimal(getInterbankSettlementAmount(node));
        String payerAccount = getPayerAccount(node);
        String payerAccountType = getPayerTypeAccount(node);
        String payerBranch = getPayerBranch(node);
        String payerTaxId = getPayerTaxId(node);
        Integer payerParticipantIspb = Integer.valueOf(getPayerParticipant(node));
        String receiverAccount = getReceiverAccount(node);
        String receiverAccountType = getReceiverTypeAccount(node);
        String receiverBranch = getReceiverBranch(node);
        Integer receiverParticipantIspb = Integer.valueOf(getReceiverParticipant(node));

        receiptEntity.setAdditionalInformation(additionalInformation);
        receiptEntity.setChargeBearer(chargeBearer);
        receiptEntity.setCustomerInitTimestampUtc(clearingTimeStampUTC);
        receiptEntity.setEndToEndId(endToEnd);
        receiptEntity.setEvent(new ReceiptEventEntity());
        receiptEntity.getEvent().setTransactionEntity(new ReceiptEntity());
        receiptEntity.getEvent().getTransactionEntity().setInitiatingInstitutionTaxId(initiatingInstitutionTaxId);
        receiptEntity.getEvent().setValue(interbankSettlementAmount);
        receiptEntity.setPayerAccount(new PayerAccountEntity());
        receiptEntity.getPayerAccount().setAccount(payerAccount);
        receiptEntity.getPayerAccount().setAccountType(payerAccountType);
        receiptEntity.getPayerAccount().setBranch(payerBranch);
        receiptEntity.getPayerAccount().setTaxId(payerTaxId);
        receiptEntity.setPayerParticipant(new ParticipantEntity());
        receiptEntity.getPayerParticipant().setIspb(payerParticipantIspb);
        receiptEntity.setReceiverAccount(new ReceiverAccountEntity());
        receiptEntity.getReceiverAccount().setAccount(receiverAccount);
        receiptEntity.getReceiverAccount().setAccountType(receiverAccountType);
        receiptEntity.getReceiverAccount().setBranch(receiverBranch);
        receiptEntity.setReceiverParticipant(new ParticipantEntity());
        receiptEntity.getReceiverParticipant().setIspb(receiverParticipantIspb);
    }
}
