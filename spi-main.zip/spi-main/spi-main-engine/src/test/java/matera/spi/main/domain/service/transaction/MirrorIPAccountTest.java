package matera.spi.main.domain.service.transaction;

import matera.spi.main.config.MainEngineConfiguration;
import matera.spi.main.domain.model.IpAccountConfigEntity;
import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.domain.model.event.transaction.PaymentEventEntity;
import matera.spi.main.domain.model.event.transaction.ReceiptEventEntity;
import matera.spi.main.domain.model.event.transaction.ReturnReceivedEventEntity;
import matera.spi.main.domain.model.event.transaction.ReturnSentEventEntity;
import matera.spi.main.domain.model.transaction.PaymentEntity;
import matera.spi.main.domain.model.transaction.ReceiptEntity;
import matera.spi.main.domain.model.transaction.ReturnReceivedEntity;
import matera.spi.main.domain.model.transaction.ReturnSentEntity;
import matera.spi.main.domain.model.transaction.TransactionResultEntity;
import matera.spi.main.domain.service.IpAccountConfigurationService;
import matera.spi.main.dto.AccountTransactionRequestDTO;
import matera.spi.main.dto.AccountTransactionResponseDTO;
import matera.spi.main.dto.QueryBalanceRequestDTO;
import matera.spi.main.dto.TransactionEventEntityDTO;
import matera.spi.utils.IspbUtils;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class MirrorIPAccountTest {

    private static final Random RANDOM = new Random();
    private static final BigDecimal TRANSACTION_ID = BigDecimal.valueOf(RANDOM.nextLong());
    private static final AccountTransactionResponseDTO ACCOUNT_TRANSACTION_RESPONSE_DTO = AccountTransactionResponseDTO.builder().transactionId(TRANSACTION_ID).build();
    private static final BigDecimal IP_ACCOUNT_NUMBER = BigDecimal.valueOf(RANDOM.nextInt());
    private static final int IP_ACCOUNT_BRANCH = RANDOM.nextInt();
    private static final int CREDIT_TRANSACTION_TYPE = RANDOM.nextInt();
    private static final int DEBIT_TRANSACTION_TYPE = RANDOM.nextInt();
    private static final int DRAWB_RCV_TRANSACTION_TYPE = RANDOM.nextInt();
    private static final int DRAWB_SENT_TRANSACTION_TYPE = RANDOM.nextInt();
    private static final int QRCODE_CRED_TRANSACTION_TYPE = RANDOM.nextInt();
    private static final BigDecimal BALANCE_LOWER_THRESHOLD = BigDecimal.valueOf(100);
    private static final BigDecimal BALANCE_AVAILABLE = BigDecimal.valueOf(1000);
    private static final BigDecimal TRANSACTION_VALUE = BigDecimal.valueOf(RANDOM.nextInt());
    private static final UUID EVENT_ID = UUID.randomUUID();
    private static final String END_TO_END_ID = UUID.randomUUID().toString();

    private static final Integer MOCKED_PAYER_ISPB = 123456;
    private static final Integer MOCKED_RECEIVER_ISPB = 987654;

    @InjectMocks
    private MirrorIPAccount mirrorIPAccount;

    @Mock
    private AccountTransaction accountTransaction;

    @Mock
    private IpAccountConfigurationService ipAccountConfigurationService;

    @Mock
    private MainEngineConfiguration mainEngineConfiguration;

    @BeforeEach
    void setup() {
        when(ipAccountConfigurationService.findConfig()).thenReturn(Optional.of(buildIpAccountConfigMock()));
        lenient().when(mainEngineConfiguration.isUseHistoricComplementAtMirror()).thenReturn(false);
    }

    @Test
    void shouldQueryAndGetBalance() {
        //Given:
        when(accountTransaction.queryBalance(any(QueryBalanceRequestDTO.class)))
            .thenReturn(BALANCE_AVAILABLE);
        //When:
        BigDecimal balance = mirrorIPAccount.queryBalance();
        //Then:
        assertThat(balance).isEqualTo(BALANCE_AVAILABLE);
        verify(accountTransaction).queryBalance(getExpectedQueryBalanceRequestDTO());
        verifyNoMoreInteractions(accountTransaction);
    }

    @ParameterizedTest(name = "isDynamicQrCode {0}")
    @ValueSource(booleans = {true, false})
    void shouldMakeIpAccountCredit(boolean isDynamicQrCode) {
        //Given:
        when(accountTransaction.makeTransaction(any(AccountTransactionRequestDTO.class)))
            .thenReturn(ACCOUNT_TRANSACTION_RESPONSE_DTO);
        //When:
        ReceiptEventEntity receiptEventEntity = buildReceiptEventEntity();
        receiptEventEntity.getTransactionEntity().setIsDynamicQrCode(isDynamicQrCode);
        mirrorIPAccount.makeCredit(receiptEventEntity);
        //Then:
        int creditTransactionType = isDynamicQrCode ? QRCODE_CRED_TRANSACTION_TYPE : CREDIT_TRANSACTION_TYPE;
        verify(accountTransaction)
            .makeTransaction(
                eq(getExpectedAccountTransactionRequestDTO(creditTransactionType, IdempotencePrefix.CREDIT_MIRROR_IP_ACCOUNT_PREFIX))
            );
        verifyNoMoreInteractions(accountTransaction);

        assertThat(receiptEventEntity.getIpAccountTransactionResult().getTransactionIdInDdaSystem()).isEqualTo(TRANSACTION_ID);
    }

    @Test
    void shouldMakeIpAccountDebitByDto() {
        //Given:
        when(accountTransaction.makeTransaction(any(AccountTransactionRequestDTO.class)))
            .thenReturn(ACCOUNT_TRANSACTION_RESPONSE_DTO);
        //When:
        TransactionResultEntity transactionResultEntity = mirrorIPAccount.makeDebit(getTransactionEventEntityDto(), IpAccountConfigEntity::getDebitTransactionType);
        //Then:
        verify(accountTransaction)
            .makeTransaction(
                eq(getExpectedAccountTransactionRequestDTO(DEBIT_TRANSACTION_TYPE, IdempotencePrefix.DEBIT_MIRROR_IP_ACCOUNT_PREFIX))
            );
        verifyNoMoreInteractions(accountTransaction);

        assertThat(transactionResultEntity.getTransactionIdInDdaSystem()).isEqualTo(TRANSACTION_ID);
    }

    private TransactionEventEntityDTO getTransactionEventEntityDto() {
        return TransactionEventEntityDTO.builder()
            .eventId(EVENT_ID)
            .endToEndId(END_TO_END_ID)
            .informationAccountHolderTransaction(END_TO_END_ID.toString())
            .operationComplement("ISPBC:" + IspbUtils.leftPadIspb(MOCKED_RECEIVER_ISPB) + "#ISPBD:" + IspbUtils.leftPadIspb(MOCKED_PAYER_ISPB))
            .value(TRANSACTION_VALUE)
            .build();
    }

    @Test
    void shouldMakeIpAccountCreditByDto() {
        //Given:
        when(accountTransaction.makeTransaction(any(AccountTransactionRequestDTO.class)))
            .thenReturn(ACCOUNT_TRANSACTION_RESPONSE_DTO);
        //When:
        TransactionResultEntity transactionResultEntity =
            mirrorIPAccount.makeCredit(getTransactionEventEntityDto(), IpAccountConfigEntity::getCreditTransactionType);
        //Then:
        verify(accountTransaction)
            .makeTransaction(
                eq(getExpectedAccountTransactionRequestDTO(CREDIT_TRANSACTION_TYPE, IdempotencePrefix.CREDIT_MIRROR_IP_ACCOUNT_PREFIX))
            );
        verifyNoMoreInteractions(accountTransaction);

        assertThat(transactionResultEntity.getTransactionIdInDdaSystem()).isEqualTo(TRANSACTION_ID);
    }

    @Test
    void shouldMakeIpAccountDebit() {
        //Given:
        when(accountTransaction.makeTransaction(any(AccountTransactionRequestDTO.class)))
            .thenReturn(ACCOUNT_TRANSACTION_RESPONSE_DTO);
        //When:
        PaymentEventEntity paymentEventEntity = buildPaymentEventEntity();
        mirrorIPAccount.makeDebit(paymentEventEntity);
        //Then:
        verify(accountTransaction)
            .makeTransaction(
                eq(getExpectedAccountTransactionRequestDTO(DEBIT_TRANSACTION_TYPE, IdempotencePrefix.DEBIT_MIRROR_IP_ACCOUNT_PREFIX))
            );
        verifyNoMoreInteractions(accountTransaction);

        assertThat(paymentEventEntity.getIpAccountTransactionResult().getTransactionIdInDdaSystem()).isEqualTo(TRANSACTION_ID);
    }

    @Test
    void shouldMakeIpAccountReturnReceived() {
        //Given:
        when(accountTransaction.makeTransaction(any(AccountTransactionRequestDTO.class)))
            .thenReturn(ACCOUNT_TRANSACTION_RESPONSE_DTO);
        //When:
        ReturnReceivedEventEntity returnReceivedEventEntity = buildReturnReceivedEventEntity();
        mirrorIPAccount.returnReceived(returnReceivedEventEntity);
        //Then:
        verify(accountTransaction)
            .makeTransaction(
                eq(getExpectedAccountTransactionRequestDTO(DRAWB_RCV_TRANSACTION_TYPE, IdempotencePrefix.RETURN_RECEIVED_MIRROR_IP_ACCOUNT_PREFIX))
            );
        verifyNoMoreInteractions(accountTransaction);

        assertThat(returnReceivedEventEntity.getIpAccountTransactionResult().getTransactionIdInDdaSystem()).isEqualTo(TRANSACTION_ID);
    }

    @Test
    void shouldMakeIpAccountReturnSent() {
        //Given:
        when(accountTransaction.makeTransaction(any(AccountTransactionRequestDTO.class)))
            .thenReturn(ACCOUNT_TRANSACTION_RESPONSE_DTO);
        //When:
        ReturnSentEventEntity returnSentEventEntity = buildReturnSentEventEntity();
        mirrorIPAccount.returnSent(returnSentEventEntity);
        //Then:
        verify(accountTransaction)
            .makeTransaction(
                eq(getExpectedAccountTransactionRequestDTO(DRAWB_SENT_TRANSACTION_TYPE, IdempotencePrefix.RETURN_SENT_MIRROR_IP_ACCOUNT_PREFIX))
            );
        verifyNoMoreInteractions(accountTransaction);

        assertThat(returnSentEventEntity.getIpAccountTransactionResult().getTransactionIdInDdaSystem()).isEqualTo(TRANSACTION_ID);

    }

    private static QueryBalanceRequestDTO getExpectedQueryBalanceRequestDTO() {
        return QueryBalanceRequestDTO.builder()
            .branch(IP_ACCOUNT_BRANCH)
            .account(IP_ACCOUNT_NUMBER)
            .includeLimit(null)
            .dMinusOne(null)
            .build();
    }

    private static AccountTransactionRequestDTO getExpectedAccountTransactionRequestDTO(int transactionType, String idempotencePrefix) {
        return AccountTransactionRequestDTO.builder()
            .idempotenceId(idempotencePrefix + END_TO_END_ID)
            .branch(IP_ACCOUNT_BRANCH)
            .account(IP_ACCOUNT_NUMBER)
            .transactionType(transactionType)
            .groupEntries(false)
            .validateBalance(true)
            .endToEndId(END_TO_END_ID)
            .eventId(EVENT_ID)
            .details(EVENT_ID.toString())
            .informationAccountHolderTransaction(END_TO_END_ID.toString())
            .operationComplement("ISPBC:" + IspbUtils.leftPadIspb(MOCKED_RECEIVER_ISPB) + "#ISPBD:" + IspbUtils.leftPadIspb(MOCKED_PAYER_ISPB))
            .value(TRANSACTION_VALUE)
            .build();
    }

    private static PaymentEventEntity buildPaymentEventEntity() {
        PaymentEventEntity paymentEventEntity = new PaymentEventEntity();
        paymentEventEntity.setId(EVENT_ID);
        paymentEventEntity.setCorrelationId(END_TO_END_ID);
        paymentEventEntity.setValue(TRANSACTION_VALUE);

        paymentEventEntity.setPaymentEntity(new PaymentEntity());

        paymentEventEntity.getPaymentEntity().setPayerParticipant(new ParticipantEntity());
        paymentEventEntity.getPaymentEntity().getPayerParticipant().setIspb(MOCKED_PAYER_ISPB);
        paymentEventEntity.getPaymentEntity().setReceiverParticipant(new ParticipantEntity());
        paymentEventEntity.getPaymentEntity().getReceiverParticipant().setIspb(MOCKED_RECEIVER_ISPB);

        return paymentEventEntity;
    }

    private static ReceiptEventEntity buildReceiptEventEntity() {
        ReceiptEventEntity receiptEventEntity = new ReceiptEventEntity();
        receiptEventEntity.setId(EVENT_ID);
        receiptEventEntity.setCorrelationId(END_TO_END_ID);
        receiptEventEntity.setValue(TRANSACTION_VALUE);
        receiptEventEntity.setReceiptEntity(new ReceiptEntity());

        receiptEventEntity.getReceiptEntity().setPayerParticipant(new ParticipantEntity());
        receiptEventEntity.getReceiptEntity().getPayerParticipant().setIspb(MOCKED_PAYER_ISPB);
        receiptEventEntity.getReceiptEntity().setReceiverParticipant(new ParticipantEntity());
        receiptEventEntity.getReceiptEntity().getReceiverParticipant().setIspb(MOCKED_RECEIVER_ISPB);

        return receiptEventEntity;
    }

    private static ReturnSentEventEntity buildReturnSentEventEntity() {

        ReturnSentEventEntity returnSentEventEntity = new ReturnSentEventEntity();
        returnSentEventEntity.setId(EVENT_ID);
        returnSentEventEntity.setCorrelationId(END_TO_END_ID);
        returnSentEventEntity.setValue(TRANSACTION_VALUE);

        returnSentEventEntity.setReturnSentEntity(new ReturnSentEntity());
        returnSentEventEntity.getReturnSentEntity().setPayerParticipant(new ParticipantEntity());
        returnSentEventEntity.getReturnSentEntity().getPayerParticipant().setIspb(MOCKED_PAYER_ISPB);
        returnSentEventEntity.getReturnSentEntity().setReceiverParticipant(new ParticipantEntity());
        returnSentEventEntity.getReturnSentEntity().getReceiverParticipant().setIspb(MOCKED_RECEIVER_ISPB);

        return returnSentEventEntity;
    }

    private static ReturnReceivedEventEntity buildReturnReceivedEventEntity() {

        ReturnReceivedEventEntity returnReceivedEventEntity = new ReturnReceivedEventEntity();
        returnReceivedEventEntity.setId(EVENT_ID);
        returnReceivedEventEntity.setCorrelationId(END_TO_END_ID);
        returnReceivedEventEntity.setValue(TRANSACTION_VALUE);

        returnReceivedEventEntity.setReturnReceivedEntity(new ReturnReceivedEntity());
        returnReceivedEventEntity.getReturnReceivedEntity().setPayerParticipant(new ParticipantEntity());
        returnReceivedEventEntity.getReturnReceivedEntity().getPayerParticipant().setIspb(MOCKED_PAYER_ISPB);
        returnReceivedEventEntity.getReturnReceivedEntity().setReceiverParticipant(new ParticipantEntity());
        returnReceivedEventEntity.getReturnReceivedEntity().getReceiverParticipant().setIspb(MOCKED_RECEIVER_ISPB);

        return returnReceivedEventEntity;
    }

    private static IpAccountConfigEntity buildIpAccountConfigMock() {
        IpAccountConfigEntity ipAccountConfigEntity = new IpAccountConfigEntity();
        ipAccountConfigEntity.setBranch(IP_ACCOUNT_BRANCH);
        ipAccountConfigEntity.setAccountNumber(IP_ACCOUNT_NUMBER);
        ipAccountConfigEntity.setCreditTransactionType(CREDIT_TRANSACTION_TYPE);
        ipAccountConfigEntity.setDebitTransactionType(DEBIT_TRANSACTION_TYPE);
        ipAccountConfigEntity.setDrawbackReceiveTransactType(DRAWB_RCV_TRANSACTION_TYPE);
        ipAccountConfigEntity.setDrawbackSentTransactType(DRAWB_SENT_TRANSACTION_TYPE);
        ipAccountConfigEntity.setBalanceValidationThreshold(true);
        ipAccountConfigEntity.setBalanceLowerThreshold(BALANCE_LOWER_THRESHOLD);
        ipAccountConfigEntity.setQrcodeCredTransactionType(QRCODE_CRED_TRANSACTION_TYPE);
        return ipAccountConfigEntity;
    }
}
