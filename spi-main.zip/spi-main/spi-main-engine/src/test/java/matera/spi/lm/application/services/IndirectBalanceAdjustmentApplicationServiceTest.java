package matera.spi.lm.application.services;

import matera.spi.lm.application.service.balanceAdjustmentApplicationService.IndirectBalanceAdjustmentApplicationService;
import matera.spi.lm.exception.IndirectParticipantOperationInvalidException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;

@ExtendWith(MockitoExtension.class)
public class IndirectBalanceAdjustmentApplicationServiceTest {

    @Spy
    private IndirectBalanceAdjustmentApplicationService indirectBalanceAdjustmentApplicationService;

    @Test
    void shouldThrowExceptionWhenGetAdjustmentsType() {
        Assertions.assertThrows(IndirectParticipantOperationInvalidException.class,
            () -> indirectBalanceAdjustmentApplicationService.getAdjustmentsTypes(Mockito.any()));
    }

    @Test
    void shouldThrowExceptionWhenGetPageBalanceAdjustment() {
        Assertions.assertThrows(IndirectParticipantOperationInvalidException.class,
            () -> indirectBalanceAdjustmentApplicationService.getPageBalancesAdjustmentV1(anyInt(), anyInt(), any(), any(), anyString(), anyString(), any(), anyString(), any(), any()));
    }

    @Test
    void shouldThrowExceptionWhenSendRequestToBalanceAdjusment() {
        Assertions.assertThrows(IndirectParticipantOperationInvalidException.class,
            () -> indirectBalanceAdjustmentApplicationService.sendRequestBalanceAdjustment(Mockito.any()));
    }

}
