package matera.spi.main.domain.service;

import org.apache.commons.lang.StringUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class MessageIdGeneratorTest {

    @Test
    void shouldBeMsgIdWhenIspbWith8Numbers() {
        String msgId = MessageIdGenerator.generate("12345678");
        Assertions.assertTrue(msgId.length() == 32 && msgId.startsWith("M12345678"));
    }

    @Test
    void shouldBeMsgIdWhenIspbWithLeast8Numbers() {
        String msgId = MessageIdGenerator.generate("12345");
        Assertions.assertTrue(msgId.length() == 32 && msgId.startsWith("M00012345"));
    }

    @Test
    void shouldThrowIllegalStateException() {
        Assertions.assertThrows(IllegalStateException.class, () -> MessageIdGenerator.generate(StringUtils.EMPTY));
    }
}