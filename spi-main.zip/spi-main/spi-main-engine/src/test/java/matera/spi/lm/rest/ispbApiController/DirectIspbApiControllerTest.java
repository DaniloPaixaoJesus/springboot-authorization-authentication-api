package matera.spi.lm.rest.ispbApiController;

import matera.spi.dto.IspbQueryDTO;
import matera.spi.dto.IspbQueryListResponseDTO;
import matera.spi.indirect.domain.model.ParticipantMipIndirectEntity;
import matera.spi.indirect.domain.model.enums.IndirectParticipantStatusEnum;
import matera.spi.indirect.persistence.ParticipantMipIndirectRepository;
import matera.spi.indirect.persistence.ParticipantMipIndirectStatusRepository;
import matera.spi.indirect.util.ParticipantMipIndirectDataSetUtil;
import matera.spi.main.domain.model.ParticipantMipEntity;
import matera.spi.main.persistence.ParticipantMipRepository;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import static matera.spi.indirect.util.ParticipantMipIndirectDataSetUtil.createParticipantMip;

import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;
import static java.lang.Integer.valueOf;

public class DirectIspbApiControllerTest extends AbstractIspbApiControllerTest{

    private static final String EXPECTED_DIRECT_ISPB_NAME = "BPP IP S.A.";
    private static final String EXPECTED_DIRECT_ISPB = "13370835";
    private static final Boolean EXPECTED_DIRECT_IS_LOCAL_ISPB = TRUE;

    private static final String EXPECTED_INDIRECT_ISPB_NAME = "Indirect Participant";
    private static final String EXPECTED_INDIRECT_ISPB = "00123454";
    private static final Boolean EXPECTED_INDIRECT_IS_LOCAL_ISPB = FALSE;

    private static final String EXPECTED_INDIRECT_ISPB_NAME_2 = "Indirect Participant 2";
    private static final String EXPECTED_INDIRECT_ISPB_2 = "00123452";
    private static final Boolean EXPECTED_INDIRECT_IS_LOCAL_ISPB_2 = FALSE;
    private static final BigDecimal EXPECTED_INDIRECT_TAX_ID_2 = BigDecimal.valueOf(237423000120l);

    @Autowired
    private ParticipantMipIndirectRepository participantMipIndirectRepository;

    @Autowired
    private ParticipantMipRepository participantMipRepository;

    @Autowired
    private ParticipantMipIndirectStatusRepository participantMipIndirectStatusRepository;

    @AfterEach
    void afterEach() {
        participantMipIndirectRepository.deleteAll();
    }

    @BeforeEach
    void cleanIndirects() {
        participantMipIndirectRepository.deleteAll();
    }

    @Test
    void givenDirectParticipantThenShouldReturnListThatContainDirectAndIndirectParticipantsFromSearchedBank() {
        final ParticipantMipEntity participantMip = createParticipantMip();
        final ParticipantMipEntity participantMip2 = createParticipantMip(valueOf(EXPECTED_INDIRECT_ISPB_2));

        final ParticipantMipIndirectEntity participantMipIndirectEntity =
            ParticipantMipIndirectDataSetUtil.createDefaultParticipantMipIndirectEntity(participantMipIndirectStatusRepository, participantMip);
        participantMipIndirectRepository.save(participantMipIndirectEntity);

        final ParticipantMipIndirectEntity participantMipIndirectEntity2 =
            ParticipantMipIndirectDataSetUtil.createCustomParticipantMipIndirectEntity(participantMipIndirectStatusRepository, participantMip2,
                EXPECTED_INDIRECT_ISPB_NAME_2, EXPECTED_INDIRECT_ISPB_NAME_2, EXPECTED_INDIRECT_TAX_ID_2, IndirectParticipantStatusEnum.ACTIVE);
        participantMipIndirectRepository.save(participantMipIndirectEntity2);

        final List<IspbQueryDTO> expectedIspbQueryDTOList = buildExpectedIspbQueryDTOList();
        final IspbQueryListResponseDTO ispbListResponse = executeRequest();

        Assertions.assertNotNull(ispbListResponse);
        final List<IspbQueryDTO> ispbList = ispbListResponse.getData();
        Assertions.assertEquals(3, ispbList.size());
        Assertions.assertArrayEquals(expectedIspbQueryDTOList.toArray(), ispbList.toArray());
    }

    private List<IspbQueryDTO> buildExpectedIspbQueryDTOList() {
        final IspbQueryDTO directIspbQueryDTO = buildIspbQueryDTO(EXPECTED_DIRECT_ISPB_NAME, EXPECTED_DIRECT_ISPB, EXPECTED_DIRECT_IS_LOCAL_ISPB);
        final IspbQueryDTO indirectIspbQueryDTO1 = buildIspbQueryDTO(EXPECTED_INDIRECT_ISPB_NAME, EXPECTED_INDIRECT_ISPB, EXPECTED_INDIRECT_IS_LOCAL_ISPB);
        final IspbQueryDTO indirectIspbQueryDTO2 = buildIspbQueryDTO(EXPECTED_INDIRECT_ISPB_NAME_2, EXPECTED_INDIRECT_ISPB_2, EXPECTED_INDIRECT_IS_LOCAL_ISPB_2);

        return Arrays.asList(directIspbQueryDTO, indirectIspbQueryDTO1, indirectIspbQueryDTO2);
    }
}
