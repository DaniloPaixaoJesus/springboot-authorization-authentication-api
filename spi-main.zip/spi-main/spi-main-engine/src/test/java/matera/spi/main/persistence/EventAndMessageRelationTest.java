package matera.spi.main.persistence;

import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.ParticipantEntity;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventStatusEntity;
import matera.spi.main.domain.model.event.EventTypeEntity;
import matera.spi.main.domain.model.message.MessageEntity;

import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.Test;
import org.opentest4j.AssertionFailedError;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.transaction.annotation.Transactional;

import static matera.spi.main.utils.EntityCreationUtils.PAYMENT_EVENT_TYPE_CODE;
import static matera.spi.main.utils.EntityCreationUtils.buildEventEntity;
import static matera.spi.main.utils.EntityCreationUtils.buildPacs008MessageEntity;
import static matera.spi.main.utils.InstantPaymentCreationUtils.EXTERNAL_ISPB;
import static matera.spi.main.utils.InstantPaymentCreationUtils.PARTICIPANT_ISPB;

import static org.junit.jupiter.api.Assertions.assertThrows;

@IntegrationTest
@Transactional
class EventAndMessageRelationTest  {

	@Autowired
	private EventRepository eventRepository;
	@Autowired
	private EventTypeRepository eventTypeRepository;
	@Autowired
	private EventStatusRepository eventStatusRepository;
	@Autowired
	private MessageRepository messageRepository;
	@Autowired
	private MessageTypeRepository messageTypeRepository;
	@Autowired
	private ParticipantRepository participantRepository;

	@Test
	void shouldThrowsExceptionWhenInsertingADuplicatedRelMessageEntity() {
		EventEntity eventEntity = createEvent();
		MessageEntity messageEntity = createMessageEntity();
		eventEntity.relateToNewMessage(messageEntity);
		eventEntity.relateToNewMessage(messageEntity);
		assertThrows(DataIntegrityViolationException.class, () -> eventRepository.saveAndFlush(eventEntity));
	}

	@NotNull
	private MessageEntity createMessageEntity() {
		MessageEntity messageEntity = buildPacs008MessageEntity();
		messageEntity.setMessageTypeEntity(messageTypeRepository.getOne("pacs.008"));
		ParticipantEntity receiverEntity = participantRepository.findByIspb(PARTICIPANT_ISPB).orElse(null);
		messageEntity.setReceiverParticipant(receiverEntity);
		ParticipantEntity senderEntity = participantRepository.findByIspb(EXTERNAL_ISPB).orElse(null);
		messageEntity.setSenderParticipant(senderEntity);
		messageRepository.saveAndFlush(messageEntity);
		return messageEntity;
	}

	@NotNull
	private EventEntity createEvent() {
		EventEntity expectedEvent = buildEventEntity();
		EventStatusEntity eventStatus = eventStatusRepository.findByDescription("Payment initialized")
				.orElseThrow(() -> new AssertionFailedError("Not found 'Payment initialized' Event status"));
		expectedEvent.setStatus(eventStatus);
		EventTypeEntity eventTypeEntity = eventTypeRepository.findById(PAYMENT_EVENT_TYPE_CODE)
				.orElseThrow(() -> new AssertionFailedError("Not found Payment Type"));
		expectedEvent.setEventTypeEntity(eventTypeEntity);
		expectedEvent = eventRepository.saveAndFlush(expectedEvent);
		return expectedEvent;
	}
}
