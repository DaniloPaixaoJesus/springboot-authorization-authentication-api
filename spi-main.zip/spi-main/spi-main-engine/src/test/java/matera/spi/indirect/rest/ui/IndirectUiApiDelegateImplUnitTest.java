package matera.spi.indirect.rest.ui;

import matera.spi.dto.IndirectParticipantCancelmentResponseDTO;
import matera.spi.dto.IndirectParticipantPossibleActionsDTO;
import matera.spi.dto.IndirectParticipantRescissionResponseDTO;
import matera.spi.dto.IndirectParticipantStatusDTO;
import matera.spi.indirect.application.service.IndirectParticipantApplicationUIService;
import matera.spi.indirect.application.service.mapper.IndirectParticipantPossibleActionsDTOMapper;
import matera.spi.indirect.domain.model.ParticipantMipIndirectStatusEntity;
import matera.spi.indirect.util.ParticipantMipIndirectDataSetUtil;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class IndirectUiApiDelegateImplUnitTest {

    @Mock
    private IndirectParticipantApplicationUIService indirectUiApiApplicationService;

    @Mock
    private HttpServletRequest httpServletRequest;

    @Mock
    private HttpServletResponse httpServletResponse;

    @InjectMocks
    private IndirectUiApiDelegateImpl indirectUiApiDelegate;

    @Test
    void shouldFindIndirectPossibleActions() {
        final ParticipantMipIndirectStatusEntity entity =
            ParticipantMipIndirectDataSetUtil.createParticipantMipIndirectStatusEntity();
        final IndirectParticipantPossibleActionsDTO dtoToMock =
            IndirectParticipantPossibleActionsDTOMapper.mapEntityToDto(entity);

        doReturn(dtoToMock).when(indirectUiApiApplicationService)
            .findIndirectPossibleActions(eq(IndirectParticipantStatusDTO.ACTIVE));

        final IndirectParticipantPossibleActionsDTO dtoFound = indirectUiApiDelegate
            .findIndirectPossibleActions(IndirectParticipantStatusDTO.ACTIVE, httpServletRequest, httpServletResponse);

        verify(indirectUiApiApplicationService).findIndirectPossibleActions(eq(IndirectParticipantStatusDTO.ACTIVE));

        assertEquals(dtoToMock, dtoFound);
    }

    @Test
    void shouldCallCancelIndirectParticipant() {
        IndirectParticipantCancelmentResponseDTO dto = new IndirectParticipantCancelmentResponseDTO();
        when(indirectUiApiDelegate.cancelIndirectParticipant(ParticipantMipIndirectDataSetUtil.ISPB, httpServletRequest, httpServletResponse)).thenReturn(dto);

        IndirectParticipantCancelmentResponseDTO responseDTO =
            indirectUiApiDelegate.cancelIndirectParticipant(ParticipantMipIndirectDataSetUtil.ISPB, httpServletRequest, httpServletResponse);

        verify(indirectUiApiApplicationService).cancelIndirectParticipant(ParticipantMipIndirectDataSetUtil.ISPB);
        assertEquals(dto, responseDTO);
    }

    @Test
    void shouldUnregisterIndirectParticipant() {
        final IndirectParticipantRescissionResponseDTO dto = new IndirectParticipantRescissionResponseDTO();

        when(
            indirectUiApiApplicationService.createIndirectParticipantRescissionRequest(ParticipantMipIndirectDataSetUtil.ISPB))
            .thenReturn(dto);

        final IndirectParticipantRescissionResponseDTO indirectParticipantRescissionResponseDTO = indirectUiApiDelegate
            .unregisterIndirectParticipant(ParticipantMipIndirectDataSetUtil.ISPB, null, httpServletRequest,
                httpServletResponse);

        assertEquals(dto, indirectParticipantRescissionResponseDTO);
    }

}
