package matera.spi.main.domain.service.idempotency;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.junit.Test;
import org.junit.jupiter.api.Disabled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import lombok.AllArgsConstructor;
import lombok.Data;
import matera.spi.commons.IntegrationTest;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventType;
import matera.spi.main.domain.service.event.Event;

@IntegrationTest
@Transactional
class IdempotencyExecutorTest {

	@Autowired
	private IdempotencyExecutor executor;
	
	@Test
	//@Disabled
	public void idempotencyTests() {
		String idempotencyId = "1234";
		String additionalArg = "A";
		String originSystem = "system";
		
		executor.executeWithIdempotency(idempotencyId, originSystem, "SERVICE",
				() -> {return createNewEvent();},
				ResultDTO.class, EventType.PAYMENT,
				this::produceResult, additionalArg);
		
	}
	
	public ResultDTO produceResult(SampleEvent createdEvent, String additionalArg) {
		return null;
	}
	
	public SampleEvent createNewEvent() {
		return new SampleEvent(sampleEntity());
	}
	
	private SampleEventEntity sampleEntity() {
		SampleEventEntity event = new SampleEventEntity(3l, LocalDate.now());
		event.setCorrelationId("ble");
		event.setInitiationTimestampUTC(LocalDateTime.now());
		return event;
	}

	@AllArgsConstructor
	public static class SampleEventEntity extends EventEntity {

		private Long id;
		private LocalDate date;

		@Override
		public EventType getEventType() {
			return EventType.PAYMENT;
		}

	}
	
	public static class SampleEvent extends Event {

		public SampleEvent(SampleEventEntity eventEntity) {
			super(eventEntity);
		}
	}
	
	@Data
	@AllArgsConstructor
	public static class ResultDTO {
		private Long id;
		private String description;
		private LocalDate date;
	}
	
}
