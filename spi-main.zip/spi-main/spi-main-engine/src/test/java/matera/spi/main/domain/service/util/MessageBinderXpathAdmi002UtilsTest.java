package matera.spi.main.domain.service.util;

import matera.spi.utils.DocumentUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;

import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static org.assertj.core.api.Assertions.assertThat;

class MessageBinderXpathAdmi002UtilsTest {

	private static final String ADMI_002_SPI_1_2_SPI_M = "admi.002/admi.002.spi.1.2_SPI_M_msg.xml";
	private static final String REF = "M000381660700b6f479d44254b649997";
	private static final String RJCTG_PTY_RSN = "Assinatura XML inválida";
	private static final String RJCTN_DT_TM = "2020-03-18T18:54:31.591Z";
	private static final String ERR_LCTN = "SignatureValue";
	private static final String RSN_DESC = "Assinatura não confere com digests ou certificado";
	private static final String ADDTL_DATA = "dados adicionais erro";


	@Test
	@DisplayName("Business reference of the present message assigned by the party issuing the message. This reference must be unique amongst all messages of the same name sent by the same party.")
	void shouldRef() {
		Document document = DocumentUtils.stringToXmlDocument(getXml());
		String ref = MessageBinderXpathAdmi002Utils.getRef(document);
		assertThat(ref).isEqualTo(REF);
	}

	@Test
	@DisplayName("Reason of the rejection provided by the rejecting party")
	void shouldRjctgPtyRsn() {
		Document document = DocumentUtils.stringToXmlDocument(getXml());
		String rjctgPtyRsn = MessageBinderXpathAdmi002Utils.getRjctgPtyRsn(document);
		assertThat(rjctgPtyRsn).isEqualTo(RJCTG_PTY_RSN);
	}

	@Test
	@DisplayName("Date and time at which the rejection was generated")
	void shouldRjctnDtTm() {
		Document document = DocumentUtils.stringToXmlDocument(getXml());
		String rjctnDtTm = MessageBinderXpathAdmi002Utils.getRjctnDtTm(document);
		assertThat(rjctnDtTm).isEqualTo(RJCTN_DT_TM);
	}

	@Test
	@DisplayName("Description of the precise location of the potential error in a message")
	void shouldErrLctn() {
		Document document = DocumentUtils.stringToXmlDocument(getXml());
		String errLctn = MessageBinderXpathAdmi002Utils.getErrLctn(document);
		assertThat(errLctn).isEqualTo(ERR_LCTN);
	}

	@Test
	@DisplayName("Additional information related to the rejection and meant to allow for the precise identification of the rejection reason. This could include a copy of the rejected message in part or in full.")
	void shouldRsnDesc() {
		Document document = DocumentUtils.stringToXmlDocument(getXml());
		String rsnDesc = MessageBinderXpathAdmi002Utils.getRsnDesc(document);
		assertThat(rsnDesc).isEqualTo(RSN_DESC);
	}

	@Test
	@DisplayName("Additional information related to the rejection and meant to allow for the precise identification of the rejection reason. This could include a copy of the rejected message in part or in full.")
	void shouldAddltData() {
		Document document = DocumentUtils.stringToXmlDocument(getXml());
		String addltData = MessageBinderXpathAdmi002Utils.getAddltData(document);
		assertThat(addltData).isEqualTo(ADDTL_DATA);
	}

	private String getXml() {
		return getStringFromXmlFile(ADMI_002_SPI_1_2_SPI_M);
	}
}