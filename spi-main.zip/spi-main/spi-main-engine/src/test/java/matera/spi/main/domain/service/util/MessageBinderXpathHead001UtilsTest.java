package matera.spi.main.domain.service.util;

import matera.spi.utils.DocumentUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;

import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static org.assertj.core.api.Assertions.assertThat;

class MessageBinderXpathHead001UtilsTest {

	private static final String ADMI_002_SPI_1_2_SPI_M = "admi.002/admi.002.spi.1.2_SPI_M_msg.xml";
	private static final String BIZMSGIDR = "M00038166eefa4489bd8f40049d809eb";
	private static final String MSGDEFIDR = "admi.002.spi.1.2";
	private static final String CREDT = "2020-03-18T18:54:31.591Z";
	private static final String SGNTR = "";
	private static final String FR_OTHR_ID = "00038166";
	private static final String TO_OTHR_ID = "13370835";


	@Test
	@DisplayName("Unambiguously identifies the Business Message to the MessagingEndpoint that has created the Business Message")
	void shouldBizMsgIdr() {
		Document document = DocumentUtils.stringToXmlDocument(getXml());
		String bizMsgIdr = MessageBinderXpathHead001Utils.getBizMsgIdr(document);
		assertThat(bizMsgIdr).isEqualTo(BIZMSGIDR);
	}

	@Test
	@DisplayName("Contains the MessageIdentifier that defines the BusinessMessage. It must contain a MessageIdentifier published on the ISO 20022 website. example camt.001.001.03.")
	void shouldMsgDefIdr() {
		Document document = DocumentUtils.stringToXmlDocument(getXml());
		String msgDefIdr = MessageBinderXpathHead001Utils.getMsgDefIdr(document);
		assertThat(msgDefIdr).isEqualTo(MSGDEFIDR);
	}

	@Test
	@DisplayName("Date and time when this Business Message (header) was created. Note Times must be normalized, using the \"Z\" annotation.")
	void shouldCredt() {
		Document document = DocumentUtils.stringToXmlDocument(getXml());
		String credt = MessageBinderXpathHead001Utils.getCredt(document);
		assertThat(credt).isEqualTo(CREDT);
	}

	@Test
	@DisplayName("Contains the digital signature of the Business Entity authorised to sign this Business Message.")
	void shouldSgntr() {
		Document document = DocumentUtils.stringToXmlDocument(getXml());
		String sgntr = MessageBinderXpathHead001Utils.getSgntr(document);
		assertThat(sgntr).isEqualTo(SGNTR);
	}

	@Test
	@DisplayName("Unique and unambiguous identification of a person.")
	void shouldFrOthrId() {
		Document document = DocumentUtils.stringToXmlDocument(getXml());
		String frOthrId = MessageBinderXpathHead001Utils.getFrOthrId(document);
		assertThat(frOthrId).isEqualTo(FR_OTHR_ID);
	}

	@Test
	@DisplayName("Unique and unambiguous identification of a person.")
	void shouldToOthrId() {
		Document document = DocumentUtils.stringToXmlDocument(getXml());
		String toOthrId = MessageBinderXpathHead001Utils.getToOthrId(document);
		assertThat(toOthrId).isEqualTo(TO_OTHR_ID);
	}

	private String getXml() {
		return getStringFromXmlFile(ADMI_002_SPI_1_2_SPI_M);
	}

}
