package matera.spi.main.domain.service.event;

import com.matera.spi.messaging.api.MessagesApi;
import com.matera.spi.messaging.api.SPIMessagingApis;
import com.matera.spi.messaging.model.MessageSentResponseDTO;
import com.matera.spi.messaging.model.MessageSpecificationDTO;

import matera.spi.commons.IntegrationTest;
import matera.spi.lm.domain.service.IpAccountBalanceQueryEvent;
import matera.spi.main.domain.model.event.EventEntity;
import matera.spi.main.domain.model.event.EventTypeEntity;
import matera.spi.main.domain.model.message.MessageEntity;
import matera.spi.main.domain.service.MessageSender;
import matera.spi.main.domain.service.event.transaction.ReceiptEvent;
import matera.spi.main.dto.event.EventSpecificationFromReceivedMessageDTO;
import matera.spi.main.persistence.EventRepository;
import matera.spi.main.persistence.EventTypeRepository;
import matera.spi.main.persistence.MessageRepository;
import matera.spi.main.persistence.MessageTypeRepository;
import matera.spi.main.persistence.ParticipantRepository;
import matera.spi.utils.DocumentUtils;

import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.opentest4j.AssertionFailedError;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.Optional;

import static matera.spi.main.utils.EntityCreationUtils.BALANCE_QUERY_EVENT_TYPE_CODE;
import static matera.spi.main.utils.EntityCreationUtils.PACS_008_REPLY_ELEMENT;
import static matera.spi.main.utils.EntityCreationUtils.buildEventEntity;
import static matera.spi.main.utils.EntityCreationUtils.buildPacs008MessageEntity;
import static matera.spi.main.utils.FileUtils.getStringFromXmlFile;
import static matera.spi.utils.DocumentUtils.stringToXmlDocument;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@IntegrationTest
@Transactional
public class EventFactoryTest  {

	private static final String PACS_008_SPI_END_1_MSG = "pacs.008/pacs.008.spi.1.4_END_1_msg.xml";
	private static final Document DOCUMENT = stringToXmlDocument(getStringFromXmlFile(PACS_008_SPI_END_1_MSG));
	private static final String PI_RESOURCE_ID = "PiResourceID";
	private static final Integer ISPB_CONFIG = 13370835;

	@Autowired
	private MessageRepository messageRepository;

	@Autowired
	private MessageTypeRepository messageTypeRepository;

	@Autowired
	private ParticipantRepository participantRepository;

	@Autowired
	private EventFactory eventFactory;

	@Autowired
	private EventTypeRepository eventTypeRepository;

	@Autowired
	private EventRepository eventRepository;

    @Autowired
    private MessageSender messageSender;
    @Autowired
    private SPIMessagingApis spiMessagingApisBean;
    @Mock
    private SPIMessagingApis mockedSpiMessagingApis;
    @Mock
    private MessagesApi mockedMessagesApi;

    @BeforeEach
    void beforeEach() {
        when(mockedSpiMessagingApis.messagesApi()).thenReturn(mockedMessagesApi);
        messageSender.setSpiMessagingApis(mockedSpiMessagingApis);
    }

    @AfterEach
    void tearDown() {
        messageSender.setSpiMessagingApis(spiMessagingApisBean);
    }

	@Test
	public void createEventFromMessageTest() {
		when(mockedMessagesApi.sendsMessageV1(any(MessageSpecificationDTO.class))).thenReturn(messageSentResponseDTOMock());

		MessageEntity messageEntity = createAndSaveMessage();

        String stringFromXmlFile = getStringFromXmlFile(PACS_008_SPI_END_1_MSG);
        stringFromXmlFile = stringFromXmlFile.replaceAll("250699", "13370835");

        Document document = stringToXmlDocument(stringFromXmlFile);

        NodeList nodeList = DocumentUtils.getElementsByExpression(
            document, PACS_008_REPLY_ELEMENT);
		Node currentNode = nodeList.item(0);

		EventSpecificationFromReceivedMessageDTO specificationFromMessageDTO = EventSpecificationFromReceivedMessageDTO
				.builder()
				.document(DOCUMENT)
				.specificElement(currentNode)
				.messageEntity(messageEntity)
				.build();

		Event event = eventFactory.createNewEventFromReceivedMessage(specificationFromMessageDTO);

		Assertions.assertNotNull(event);

		Assertions.assertTrue(event instanceof ReceiptEvent);

		Optional<Event> eventFound = eventFactory.findById(event.getId());

		Assertions.assertTrue(eventFound.isPresent());

		Assertions.assertTrue(eventFound.get() instanceof ReceiptEvent);
	}

	@Test
	void shouldFindFirstNonFinalEventGivenAnEventType() {
		EventEntity eventEntity = createEvent(BALANCE_QUERY_EVENT_TYPE_CODE);

		Event event = eventFactory.findFirstOriginalEventWithoutReply(eventTypeRepository.getOne(BALANCE_QUERY_EVENT_TYPE_CODE));

		Assertions.assertNotNull(event);
        Assertions.assertTrue(event instanceof IpAccountBalanceQueryEvent);
		Assertions.assertEquals(eventEntity, event.getEventEntity());

	}

	@Test
	void shouldThrowAnIllegalStateExceptionWhenNotFoundAnyEventForAGivenType() {

		EventTypeEntity balanceQueryEventType = eventTypeRepository.getOne(BALANCE_QUERY_EVENT_TYPE_CODE);
		assertThatThrownBy(() ->
				eventFactory.findFirstOriginalEventWithoutReply(balanceQueryEventType)
		)
				.isInstanceOf(IllegalStateException.class)
				.hasMessage("Not found EventEntity with a non final status and type %s", balanceQueryEventType.getDescription());

	}


	@NotNull
	private EventEntity createEvent(int eventTypeCode) {
		EventEntity expectedEvent = buildEventEntity(eventTypeCode);
		EventTypeEntity eventTypeEntity = eventTypeRepository.findById(eventTypeCode)
				.orElseThrow(() -> new AssertionFailedError("Not found Event Type: " + eventTypeCode));
		expectedEvent.setEventTypeEntity(eventTypeEntity);
		expectedEvent.setStatus(eventTypeEntity.getInitialStatus());
		expectedEvent = eventRepository.saveAndFlush(expectedEvent);
		return expectedEvent;
	}


	private MessageEntity createAndSaveMessage() {

		MessageEntity messageEntity = buildPacs008MessageEntity();

		messageEntity.setMessageTypeEntity(messageTypeRepository.findById("pacs.008").get());
		messageEntity.setSenderParticipant(participantRepository.findByIspb(ISPB_CONFIG).get());
		messageEntity.setReceiverParticipant(participantRepository.findByIspb(ISPB_CONFIG).get());

		return messageRepository.saveAndFlush(messageEntity);
	}

	private MessageSentResponseDTO messageSentResponseDTOMock() {
		MessageSentResponseDTO messageSentResponseDTO = new MessageSentResponseDTO();
		messageSentResponseDTO.setPiResourceID(PI_RESOURCE_ID);
		return messageSentResponseDTO;
	}

}
