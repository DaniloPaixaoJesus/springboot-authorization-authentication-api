package matera.spi.main.domain.service;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class CpfCnpjValidatorTest {

	@Test
	public void cpfTest() {
		Assertions.assertTrue(CpfCnpjValidator.isCPF(4435739640L));
		Assertions.assertTrue(CpfCnpjValidator.isCPF(22309885819L));
		Assertions.assertFalse(CpfCnpjValidator.isCPF(4435739641L));
		Assertions.assertFalse(CpfCnpjValidator.isCPF(22309885817L));
	}
	
	@Test
	public void cnpjTest() {
		Assertions.assertTrue(CpfCnpjValidator.isCNPJ(47450396000132L));
		Assertions.assertTrue(CpfCnpjValidator.isCNPJ(50171215000143L));
		Assertions.assertTrue(CpfCnpjValidator.isCNPJ(69145573000100L));
		Assertions.assertFalse(CpfCnpjValidator.isCNPJ(47450396000135L));
		Assertions.assertFalse(CpfCnpjValidator.isCNPJ(50171215000142L));
		Assertions.assertFalse(CpfCnpjValidator.isCNPJ(69145573000101L));
	}
}
