package matera.spi.main.application.service.validator;

import com.matera.commons.utils.exception.BusinessException;

import matera.spi.dto.IpAccountOwnerRequestDTO;
import matera.spi.main.domain.model.IpAccountOwnerEntity;
import matera.spi.main.utils.EntityCreationUtils;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.test.util.ReflectionTestUtils;

import static matera.spi.main.application.service.validator.IpAccountOwnerUIValidator.validateIfActiveOwnerHasSameValuesOfUpdateRequestDTO;
import static matera.spi.main.application.service.validator.IpAccountOwnerUIValidator.validateIpAccountOwnerRequestDTO;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

class IpAccountOwnerUIValidatorTest {

    @ParameterizedTest(name= "{0} and value {1}")
    @DisplayName("it should throws BusinessException when receiving a IpAccountOwnerRequestDTO with invalid field")
    @CsvSource({
        "directorName,, directorName is not a valid",
        "directorName,'', directorName is not a valid",
        "directorTaxId, 12448201000135, directorTaxId is not a valid CPF",
        "directorTaxId, 12448201000135, directorTaxId is not a valid CPF",
        "directorTaxId,, directorTaxId is not a valid CPF",
        "directorPhone, '', directorPhone is not a valid phone",
        "directorPhone,, directorPhone is not a valid phone",
        "directorPhone, '', directorPhone is not a valid phone",
        "directorMobile, +5512315155151, directorMobile is not a valid phone",
        "employeePhone, 55-12315155151, employeePhone is not a valid phone",
        "employeePhone,, employeePhone is not a valid phone",
        "employeePhone, '', employeePhone is not a valid phone",
        "employeeMobile, (11)111111111, employeeMobile is not a valid phone",
        "employeeMobile, ' ', employeeMobile is not a valid phone",
        "employeeFax, invalid_phone, employeeFax is not a valid phone",
        "employeeFax, ' ', employeeFax is not a valid phone",
        "directorEmail, invalid_mail, directorEmail is not a valid email",
        "directorEmail, , directorEmail is not a valid email",
        "directorEmail, '', directorEmail is not a valid email",
        "employeeEmail, invalid_mail.com, employeeEmail is not a valid email",
        "employeeEmail, , employeeEmail is not a valid email",
        "employeeEmail, ' ', employeeEmail is not a valid email",
        "passPhrase, 1234567, passPhrase is invalid",
        "passPhrase,, passPhrase is invalid",
        "passPhrase, '', passPhrase is invalid",
        "passPhrase, 123456789, passPhrase is invalid",
        "passPhrase, 1234567*, passPhrase is invalid",
        "passPhrase, 1234567!, passPhrase is invalid",
        "passPhrase, 1234567&, passPhrase is invalid",
        "passPhrase, 1234567@, passPhrase is invalid",
        "passPhrase, 1234567#, passPhrase is invalid",
        "passPhrase, 1234567., passPhrase is invalid",
    })
    void shouldThrowBusinessExceptionWhenReceivedRequestDTOWithInvalidInput(String fieldWithInvalidData, String invalidData, String expectedErrorMessage) {
        IpAccountOwnerRequestDTO requestDTOWithAllFields = EntityCreationUtils.buildIpAccountOwnerRequestDTOWithAllFields();
        ReflectionTestUtils.setField(requestDTOWithAllFields, fieldWithInvalidData, invalidData);
        String expectedErrorCode = "SPI-ME-016";
        assertThatThrownBy(() -> validateIpAccountOwnerRequestDTO(requestDTOWithAllFields))
            .isInstanceOf(BusinessException.class)
            .hasMessageContaining(expectedErrorCode)
            .hasMessageContaining(expectedErrorMessage);
    }

    @ParameterizedTest(name= "{0} with value {1}")
    @DisplayName("it should validates ok valid input")
    @CsvSource({
        "directorTaxId, 04072610011,",
        "directorMobile, +55-12315155151",
        "directorMobile,", //null non-required phone
        "directorMobile, ''", //null non-required phone
        "employeeMobile,", //null non-required phone
        "employeeMobile, ''", //null non-required phone
        "employeeFax,", //null non-required phone
        "employeeFax, ''", //null non-required phone
        "employeeEmail, valid_mail@mail.com",
        "passPhrase, 1234567a",
    })
    void shouldDoesNotThrowAnyExceptionWhenValidatingAValidInput(String fieldWithValidData, String data) {
        IpAccountOwnerRequestDTO requestDTOWithAllFields = EntityCreationUtils.buildIpAccountOwnerRequestDTOWithAllFields();
        ReflectionTestUtils.setField(requestDTOWithAllFields, fieldWithValidData, data);
        assertDoesNotThrow(() -> validateIpAccountOwnerRequestDTO(requestDTOWithAllFields));
    }

    @Test
    void shouldThrowBusinessExceptionWhenActiveOwnerIsEqualToRequestDTO() {
        IpAccountOwnerEntity activeOwnerWithRequiredFields = EntityCreationUtils.buildIpAccountOwnerEntityWithRequiredFields();
        IpAccountOwnerRequestDTO requestDTOWithRequiredFields = EntityCreationUtils.buildIpAccountOwnerRequestDTO();

        assertThatThrownBy(() -> validateIfActiveOwnerHasSameValuesOfUpdateRequestDTO(activeOwnerWithRequiredFields, requestDTOWithRequiredFields))
            .isInstanceOf(BusinessException.class)
            .hasMessageContaining("SPI-ME-018");

        IpAccountOwnerEntity activeOwnerWithAllFields = EntityCreationUtils.buildIpAccountOwnerEntityWithAllFields();
        IpAccountOwnerRequestDTO requestDTOWithAllFields = EntityCreationUtils.buildIpAccountOwnerRequestDTOWithAllFields();

        assertThatThrownBy(() -> validateIfActiveOwnerHasSameValuesOfUpdateRequestDTO(activeOwnerWithAllFields, requestDTOWithAllFields))
            .isInstanceOf(BusinessException.class)
            .hasMessageContaining("SPI-ME-018");

    }

}

