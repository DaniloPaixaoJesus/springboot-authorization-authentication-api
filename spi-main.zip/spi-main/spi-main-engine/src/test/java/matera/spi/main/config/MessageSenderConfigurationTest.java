package matera.spi.main.config;

import com.matera.spi.messaging.api.SPIMessagingApis;

import matera.spi.commons.IntegrationTest;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.TestPropertySource;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@IntegrationTest
class MessageSenderConfigurationTest {

	@Autowired
	private SPIMessagingApis messagingApis;

	@Test
	@DisplayName("the SPIMessagingApis bean should be loaded to context through the MessageSenderConfiguration")
	void shouldLoadTheSPIMessagingApisBean() {
		assertNotNull(messagingApis);
	}

}
